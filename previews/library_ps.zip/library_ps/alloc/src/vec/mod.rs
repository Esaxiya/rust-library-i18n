//! د هپ مختص شوي مینځپانګو سره د ودې او کښت وړ سري ډول ، `Vec<T>` لیکل شوی.
//!
//! Vectors د `O(1)` انډیکشنګ ، اموریت لرونکي `O(1)` فشار (پای ته) او `O(1)` پاپ (له پای څخه) لري.
//!
//!
//! Vectors ډاډ ترلاسه کوي چې دوی هیڅکله د `isize::MAX` بایټونو څخه زیات تخصیص نه ورکوي.
//!
//! # Examples
//!
//! تاسو کولی شئ په څرګنده توګه د [`Vec::new`] سره [`Vec`] رامینځته کړئ:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... یا د [`vec!`] میکرو په کارولو سره:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // لس صفر
//! ```
//!
//! تاسو کولی شئ د vector پای کې د [`push`] ارزښتونه (کوم چې د اړتیا سره vector وده وکړي):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! د کوکنارو ارزښتونه په ورته ډول کار کوي:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors هم د شاخص ملاتړ کوي (د [`Index`] او [`IndexMut`] traits له لارې):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// یو متناسب وده کونکي سرې ډول ، د `Vec<T>` په نوم لیکل شوی او تلفظ شوی 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// د [`vec!`] میکرو چمتو کولو لپاره چمتو شوی چې خورا اسانه وي:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// دا کولی شي د ورکړل شوي ارزښت سره د `Vec<T>` هر عنصر پیل کړي.
/// دا ممکن په جلا مرحلو کې د تخصیص او ابتکار ترسره کولو څخه خورا اغیزمن وي ، په ځانګړي توګه کله چې د زیروز vector پیل کول:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // لاندې مساوي دي ، مګر احتمالي ورو
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// د نورو معلوماتو لپاره ، [Capacity and Reallocation](#capacity-and-reallocation) وګورئ.
///
/// د `Vec<T>` د اغیزمن سټیک په توګه وکاروئ:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3 ، 2 ، 1 چاپ کوي
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// د `Vec` ډول د انډیکس لخوا ارزښتونو ته لاسرسی ته اجازه ورکوي ، ځکه چې دا د [`Index`] trait پلي کوي.یوه بیلګه به نور هم څرګنده شي:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // دا به '2' ښکاره کړي
/// ```
///
/// په هرصورت محتاط اوسئ: که تاسو یوې داسې شاخص ته لاسرسي هڅه وکړئ کوم چې په `Vec` کې ندي ، نو ستاسو سافټویر به panic!تاسو دا نشئ کولی:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// [`get`] او [`get_mut`] وکاروئ که تاسو غواړئ چیک کړئ که چیرې شاخص یې په `Vec` کې دی.
///
/// # Slicing
///
/// یو `Vec` کیدلی شي بدلون ومومي.له بلې خوا ، ټوټې یوازې د لوستلو شيان دي.
/// د [slice][prim@slice] ترلاسه کولو لپاره ، [`&`] وکاروئ.مثال:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... او دا ټول دي!
/// // تاسو کولی شئ دا هم داسې وکړئ:
/// let u: &[usize] = &v;
/// // یا دا خوښ کړئ:
/// let u: &[_] = &v;
/// ```
///
/// په Rust کې ، دا د vectors په پرتله د دلیلونو په څیر سلیزونه ورکول معمول دي کله چې تاسو غواړئ لوستلو لاسرسی چمتو کړئ.ورته د [`String`] او [`&str`] لپاره ځي.
///
/// # ظرفیت او بیا ځای په ځای کول
///
/// د vector ظرفیت د کومې future عناصرو لپاره مختص شوي ځای مقدار دی چې په vector کې به اضافه شي.دا د vector * * اوږدوالي * سره ګډوډ نشو ، کوم چې د vector دننه د اصلي عناصرو شمیر مشخص کوي.
/// که چیرې د vector اوږدوالی د دې وړتیا لوړه کړي ، نو د دې ظرفیت به په اتوماتيک ډول لوړ شي ، مګر د هغې عناصر به بیا له سره تنظیم شي.
///
/// د مثال په توګه ، د vector 10 ظرفیت او اوږدوالی 0 به د 10 نورو عناصرو لپاره ځای سره خالي vector وي.په vector کې د 10 یا لږو عناصرو کښل به د دې وړتیا بدله نکړي یا د بیا پیل کیدو لامل شي.
/// په هرصورت ، که چیرې د vector اوږدوالی 11 ته لوړ شي ، نو دا به بیا راپورته شي ، کوم چې ورو کیدی شي.د دې دلیل لپاره ، دا د [`Vec::with_capacity`] کارولو سپارښتنه کیږي کله چې امکان ولري د مشخص کولو لپاره څومره لوی vector ترلاسه کولو تمه کیږي.
///
/// # Guarantees
///
/// د دې غیر معمولي بنسټیز طبیعت له امله ، `Vec` د دې ډیزاین په اړه ډیر تضمینات ورکوي.دا ډاډ ورکوي چې دا په عمومي حالت کې د امکان تر حده ټیټ سر دی ، او د ناخوندي کوډ په واسطه په سمه توګه په لومړي ډول سمبالیدای شي.په یاد ولرئ چې دا تضمینات غیر معتبر `Vec<T>` ته اشاره کوي.
/// که اضافي ډول پیرامیټونه اضافه شي (د بیلګې په توګه ، د دودیز تخصیص کونکو ملاتړ کول) ، د دوی د ډیفالټ تاکید کول ممکن چلند بدل کړي.
///
/// ډیری اساسا ، `Vec` دی او تل به یو (نښه کوونکی ، ظرفیت ، اوږدوالی) ټرپلټ وي.نور نه ، هیڅ نه.د دې برخو حکم په بشپړ ډول غیر مشخص شوی دی ، او تاسو باید د دې تعدیل لپاره مناسبې میتودونه وکاروئ.
/// پوائنټور به هیڅکله خالي نه وي ، نو دا ډول نوال-پوائنټر-مطلوب دی.
///
/// په هرصورت ، نښې ممکن واقعیا تخصیص شوي حافظې ته اشاره نکړي.
/// په ځانګړي توګه ، که تاسو د X004 ، [`vec![]`][`vec!`] ، [`Vec::with_capacity(0)`][`Vec::with_capacity`] له لارې 0 ظرفیت سره `Vec` جوړ کړئ یا په خالي Vec کې د [`shrink_to_fit`] تلیفون کولو سره ، دا به حافظه مختص نکړي.په ورته ډول ، که تاسو د `Vec` دننه د صفر اندازې ډولونه ذخیره کړئ ، نو دا به د دوی لپاره ځای مختص نه کړي.
/// *یادونه وکړئ چې پدې حالت کې `Vec` ممکن د 0*[`capacity`] راپور نه کړي.
/// `Vec` که ځانګړې او که یوازې [`ميم: : د اندازې_او::<T>`]`() * capacity()> 0`.
/// په عموم کې ، د `Vec` د تخصیص جزیات خورا پیچلي دي-که تاسو د `Vec` په کارولو سره حافظه تخصیص کړئ او دا د کوم بل څه لپاره وکاروئ (یا غیر خوندي کوډ ته واستوئ ، یا خپل د حافظې ملاتړ شوي ټولګه رامینځته کړئ) ، ډاډه اوسئ د دې حافظې ضایع کول د `from_raw_parts` په کارولو سره د `Vec` ترلاسه کولو لپاره او بیا یې له سره غورځول.
///
/// که چیرې یو `Vec` * تخصیص شوی حافظه ولري ، نو هغه حافظه چې دې ته اشاره کوي هغه په اسپا isه کې دی (لکه څنګه چې د تخصیص کونکي لخوا ټاکل شوی Rust د ډیفالټ په واسطه کارولو لپاره تنظیم شوی) ، او د دې نښې [`len`] پیل شوي ، متناسب عناصرو ته په ترتیب سره په نښه کوي (څه چې تاسو به یې کوئ وګورئ چې ایا تاسو دې ټوټې ته اړ ایستلي) ، د [`وړتیا`]`،`[`لین`] په منطقي توګه بې ځایه شوي ، متناسب عناصر.
///
///
/// یو vector د `'a'` او `'b'` عناصرو لرونکي 4 ظرفیت سره لاندې لید کیدی شي.پورتنۍ برخه د `Vec` جوړښت دی ، دا د تیلو ، اوږدوالي او ظرفیت کې د تخصیص سر ته اشاره لري.
/// لاندنۍ برخه د ګیر باندې تخصیص دی ، د حافظې یو دوامداره بلاک.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **غیر منحل** د حافظې نمایندګي کوي چې پیل نه دی شوی ، [`MaybeUninit`] وګورئ.
/// - Note: ABI ثبات نلري او `Vec` د دې حافظې ترتیب په اړه تضمین نه کوي (پشمول د ساحو ترتیب).
///
/// `Vec` هیڅکله به "small optimization" ترسره نکړي چیرې چې عناصر په حقیقت کې د دوه دلیلونو لپاره په دلۍ کې ساتل کیږي:
///
/// * دا به د غیر خوندي کوډ لپاره ډیر مشکل رامینځته کړي چې په سمه توګه د `Vec` اداره کړئ.د `Vec` مینځپانګې به مستحکم پته نلري که چیرې دا یوازې لیږدول شوي وي ، او دا به خورا ستونزمن وي چې مشخص شي که `Vec` واقعیا حافظه مختص کړې وه.
///
/// * دا به عمومي قضیه جزا ورکړي ، په هر لاسرسي کې د اضافي branch په شمول.
///
/// `Vec` هیڅکله به په اوتومات ډول خپل ځان لږ نه کړي ، حتی که بشپړ خالي وي.دا ډاډ ورکوي چې هیڅ غیر ضروري تخصیص یا تخفیف پیښ نشي.د `Vec` خالي کول او بیا ورته ورته [`len`] ډکول باید تخصیص کونکي ته هیڅ زنګ وانه خلي.که تاسو نه غواړئ حافظه پاکه کړئ ، نو [`shrink_to_fit`] یا [`shrink_to`] وکاروئ.
///
/// [`push`] او [`insert`] به هیڅکله (بیا) تخصیص نکړي که راپور شوي ظرفیت کافی وي.[`push`] او [`insert`]*به*(بیا) اختصاص کړي که [`len`]`==`[`وړتیا`].دا ، راپور شوی ظرفیت په بشپړ ډول درست دی ، او تکیه کیدی شي.دا حتی د `Vec` لخوا مختص شوي حافظه په لاسي ډول د آزادولو لپاره کارول کیدی شي که وغواړي.
/// د حجم داخلولو میتودونه *ممکن* بیا پیل شي ، حتی کله چې اړین هم نه وي.
///
/// `Vec` هیڅکله د ودې ځانګړي ستراتیژی تضمین نه کوي کله چې ډک وي کله بیرته ډکول ، او نه هم کله چې [`reserve`] نومیږي.اوسنۍ ستراتیژي لومړنۍ ده او دا ممکن د دوامداره ودې عنصر کارولو لپاره مطلوب ثابت کړي.هرهغه ستراتیژي چې کارول کیږي دقیقا به تضمین *O*(1) Amorised [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` ، او [`Vec::with_capacity(n)`][`Vec::with_capacity`] ، ټول به د غوښتل شوي ظرفیت سره یو `Vec` تولید کړي.
/// که [`len`]`==`[`وړتیا`] ، (لکه څنګه چې د [`vec!`] میکرو لپاره قضیه ده) ، نو بیا `Vec<T>` د [`Box<[T]>`][owned slice] څخه بدلیدلی شي او د عناصرو له سره تنظیم یا حرکت کولو پرته.
///
/// `Vec` به په مشخص ډول به کومې ډاټا ته له هغې څخه حذف شوي تاثیر نکړي ، مګر په ځانګړي ډول به یې خوندي نکړي.د دې بې بنسټه حافظه د سکریچ ځای دی چې دا ممکن وکاروي که څه هم دا غواړي.دا به عموما هر هغه څه وکړي چې خورا اغیزمن وي یا بل ډول پلي کول یې اسانه وي.د امنیتي اهدافو لپاره له مینځه وړل شوي معلوماتو باندې تکیه مه کوئ.
/// حتی که تاسو `Vec` واخلئ ، نو د دې بفر ممکن په ساده ډول د بل `Vec` لخوا بیا وکارول شي.
/// حتی که تاسو لومړی د `Vec` حافظه صفر کړئ ، نو ممکن واقعیا داسې نه وي ځکه چې مطلوب کونکی دا اړخ اړخ نه ګ .ي چې باید خوندي وساتل شي.
/// یوه قضیه شتون لري چې موږ به یې مات نکړو ، په هرصورت: د اضافي ظرفیت لیکلو لپاره د `unsafe` کوډ کارول ، او بیا یې میچ ته اوږدوالی زیاتول تل معتبر دي.
///
/// اوس مهال ، `Vec` د امر ضمانت نه کوي په کوم کې چې عناصر غورځول شوي.
/// حکم په تیرو وختونو کې بدل شوی او ممکن بیا بدلون ومومي.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// اصلي میتودونه
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// نوی ، خالي `Vec<T>` جوړوي.
    ///
    /// vector به تر هغه پورې تخصیص ونلري تر څو چې عناصر دې ته اړ نه وي.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// د ټاکل شوي ظرفیت سره نوی ، خالي `Vec<T>` جوړوي.
    ///
    /// vector به وکولی شي دقیقا د `capacity` عناصر ونیسي پرته له دې چې بیرته راټول شي.
    /// که `capacity` 0 وي ، vector به تخصیص نه کړي.
    ///
    /// دا په یاد ولرئ چې مهمه ده که څه هم بیرته راغلی vector د ټاکل شوي *ظرفیت* لري ، vector به صفر *اوږدوالی* ولري.
    ///
    /// د اوږدوالي او ظرفیت تر مینځ د توپیر وضاحت لپاره ،*[ظرفیت او له سره غورځول]* وګورئ.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector هیڅ توکي نلري ، که څه هم دا د ډیرو لپاره ظرفیت لري
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // دا ټول د بیا ځلې پرته ترسره شوي ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... مګر دا ممکن د vector بیا پیل وکړي
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// د بل vector خام برخو څخه مستقیم `Vec<T>` رامینځته کوي.
    ///
    /// # Safety
    ///
    /// دا خورا خوندي نه دی ، د بریدګرو شمیر له امله چې نه یې چیک شوی:
    ///
    /// * `ptr` دې ته اړتیا وه چې مخکې د [`سټرینګ]/ec Vec له لارې تخصیص شوي وي<T>`(لږترلږه ، دا خورا احتمال لري غلط وي که دا نه و).
    /// * `T` ورته ورته کچه او اړین والي ته اړتیا لري د هغه څه سره چې د `ptr` مختص شوی و.
    ///   (`T` د لږ سخت سمون درلودل کافي ندي ، الینینګ واقعیا د [`dealloc`] اړتیا پوره کولو لپاره مساوي اړتیا ته اړتیا لري چې حافظه باید ورته ورته ترتیب سره مختص او تخریب شي.)
    ///
    /// * `length` د `capacity` څخه کم یا مساوي ته اړتیا لري.
    /// * `capacity` اړتیا ده هغه ظرفیت ته چې پوائنټر ورسره مختص شوی و.
    ///
    /// د دې سرغړونه ممکن د اختصاصي داخلي معلوماتو جوړښتونو فاسدولو په څیر ستونزې رامینځته کړي.د مثال په توګه دا **نه** د `Vec<u8>` جوړولو لپاره خوندي دی له نښې څخه C `char` سرنی ته د `size_t` اوږدوالي سره.
    /// دا د `Vec<u16>` او د هغې د اوږدوالي څخه د یو جوړولو لپاره هم خوندي ندي ، ځکه چې تخصیص کونکي د سیدای کولو په اړه پاملرنه کوي ، او دا دوه ډولونه مختلف سمون لري.
    /// بفر د سمون 2 سره تخصیص شوی و (د `u16` لپاره) ، مګر وروسته له دې چې دا په `Vec<u8>` بدل کړئ نو دا به د ساحاتو 1 سره ضایع شي.
    ///
    /// د `ptr` ملکیت په مؤثره توګه `Vec<T>` ته لیږدول شوی کوم چې بیا کولی شي د غوښتونکي لخوا په نښه شوي حافظې مینځپانګې له مینځه ویسي ، له سره تنظیم او یا بدل کړي.
    /// ډاډ ترلاسه کړئ چې بل هیڅ شی د دې فنکشن زنګ وهلو وروسته نښې نه کاروي.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME دا تازه کړئ کله چې vec_into_raw_parts مستحکم وي.
    ///     // د `v` ویجاړونکي چلولو مخه ونیسئ نو موږ د تخصیص بشپړ کنټرول کې یو.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // د `v` په اړه د معلوماتو مختلف مهمې برخې وخورئ
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // د 4 ، 5 ، 6 سره حافظه پراخه کړئ
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // هرڅه بیرته په Vec کې یوځای کړئ
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// نوی ، خالي `Vec<T, A>` جوړوي.
    ///
    /// vector به تر هغه پورې تخصیص ونلري تر څو چې عناصر دې ته اړ نه وي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// د چمتو شوي مختص کونکي سره د ټاکل شوي ظرفیت سره نوی ، خالي `Vec<T, A>` جوړوي.
    ///
    /// vector به وکولی شي دقیقا د `capacity` عناصر ونیسي پرته له دې چې بیرته راټول شي.
    /// که `capacity` 0 وي ، vector به تخصیص نه کړي.
    ///
    /// دا په یاد ولرئ چې مهمه ده که څه هم بیرته راغلی vector د ټاکل شوي *ظرفیت* لري ، vector به صفر *اوږدوالی* ولري.
    ///
    /// د اوږدوالي او ظرفیت تر مینځ د توپیر وضاحت لپاره ،*[ظرفیت او له سره غورځول]* وګورئ.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector هیڅ توکي نلري ، که څه هم دا د ډیرو لپاره ظرفیت لري
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // دا ټول د بیا ځلې پرته ترسره شوي ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... مګر دا ممکن د vector بیا پیل وکړي
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// د بل vector خام برخو څخه مستقیم `Vec<T, A>` رامینځته کوي.
    ///
    /// # Safety
    ///
    /// دا خورا خوندي نه دی ، د بریدګرو شمیر له امله چې نه یې چیک شوی:
    ///
    /// * `ptr` دې ته اړتیا وه چې مخکې د [`سټرینګ]/ec Vec له لارې تخصیص شوي وي<T>`(لږترلږه ، دا خورا احتمال لري غلط وي که دا نه و).
    /// * `T` ورته ورته کچه او اړین والي ته اړتیا لري د هغه څه سره چې د `ptr` مختص شوی و.
    ///   (`T` د لږ سخت سمون درلودل کافي ندي ، الینینګ واقعیا د [`dealloc`] اړتیا پوره کولو لپاره مساوي اړتیا ته اړتیا لري چې حافظه باید ورته ورته ترتیب سره مختص او تخریب شي.)
    ///
    /// * `length` د `capacity` څخه کم یا مساوي ته اړتیا لري.
    /// * `capacity` اړتیا ده هغه ظرفیت ته چې پوائنټر ورسره مختص شوی و.
    ///
    /// د دې سرغړونه ممکن د اختصاصي داخلي معلوماتو جوړښتونو فاسدولو په څیر ستونزې رامینځته کړي.د مثال په توګه دا **نه** د `Vec<u8>` جوړولو لپاره خوندي دی له نښې څخه C `char` سرنی ته د `size_t` اوږدوالي سره.
    /// دا د `Vec<u16>` او د هغې د اوږدوالي څخه د یو جوړولو لپاره هم خوندي ندي ، ځکه چې تخصیص کونکي د سیدای کولو په اړه پاملرنه کوي ، او دا دوه ډولونه مختلف سمون لري.
    /// بفر د سمون 2 سره تخصیص شوی و (د `u16` لپاره) ، مګر وروسته له دې چې دا په `Vec<u8>` بدل کړئ نو دا به د ساحاتو 1 سره ضایع شي.
    ///
    /// د `ptr` ملکیت په مؤثره توګه `Vec<T>` ته لیږدول شوی کوم چې بیا کولی شي د غوښتونکي لخوا په نښه شوي حافظې مینځپانګې له مینځه ویسي ، له سره تنظیم او یا بدل کړي.
    /// ډاډ ترلاسه کړئ چې بل هیڅ شی د دې فنکشن زنګ وهلو وروسته نښې نه کاروي.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME دا تازه کړئ کله چې vec_into_raw_parts مستحکم وي.
    ///     // د `v` ویجاړونکي چلولو مخه ونیسئ نو موږ د تخصیص بشپړ کنټرول کې یو.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // د `v` په اړه د معلوماتو مختلف مهمې برخې وخورئ
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // د 4 ، 5 ، 6 سره حافظه پراخه کړئ
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // هرڅه بیرته په Vec کې یوځای کړئ
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// د دې خام برخو کې `Vec<T>` راکموي.
    ///
    /// زیرمو ډیټا ته خام نښې ، د vector اوږدوالی (په عناصرو کې) ، او د ډیټا ټاکل شوي ظرفیت (عناصرو کې) بیرته راګرځوي.
    /// دا په ورته ترتیب کې ورته دلیلونه دي د [`from_raw_parts`] ته دلیلونو په څیر.
    ///
    /// د دې فنکشن غږولو وروسته ، زنګ وهونکی د `Vec` لخوا دمخه اداره شوي حافظې لپاره مسؤل دی.
    /// د دې کولو یوازینۍ لار د [`from_raw_parts`] فنکشن سره خام پوائنټر ، اوږدوالی ، او ظرفیت بیرته په `Vec` کې بدلول دي ، نو ویجاړونکي ته د پاکولو ترسره کولو اجازه ورکوي.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // موږ اوس کولی شو برخو کې بدلونونه رامینځته کړو ، لکه د خامو نقطې متناسب ډول ته لیږدول.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// د دې خام برخو کې `Vec<T>` راکموي.
    ///
    /// زیرمو ډیټا ته خام نښې ، د vector اوږدوالی (په عناصرو کې) ، د ډیټا ټاکل شوي ظرفیت (په عناصرو کې) ، او تخصیص کونکي بیرته راګرځوي.
    /// دا په ورته ترتیب کې ورته دلیلونه دي د [`from_raw_parts_in`] ته دلیلونو په څیر.
    ///
    /// د دې فنکشن غږولو وروسته ، زنګ وهونکی د `Vec` لخوا دمخه اداره شوي حافظې لپاره مسؤل دی.
    /// د دې کولو یوازینۍ لار د [`from_raw_parts_in`] فنکشن سره خام پوائنټر ، اوږدوالی ، او ظرفیت بیرته په `Vec` کې بدلول دي ، نو ویجاړونکي ته د پاکولو ترسره کولو اجازه ورکوي.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // موږ اوس کولی شو برخو کې بدلونونه رامینځته کړو ، لکه د خامو نقطې متناسب ډول ته لیږدول.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Z2vector0Z کولی شي د عناصرو شمیر بیرته راټول کړي پرته له مینځه وړي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// په ورکړل شوي `Vec<T>` کې د لږترلږه `additional` نورو عناصرو لپاره ظرفیت خوندي کړئ.
    /// راټولول ممکن د پرله پسې بیاکتنې مخه نیولو لپاره ډیر ځای خوندي کړي.
    /// د `reserve` تلیفون کولو وروسته ، ظرفیت به د `self.len() + additional` څخه لوی یا مساوي وي.
    /// هیڅ نه کوي که چیرې ظرفیت دمخه کافی وي.
    ///
    /// # Panics
    ///
    /// Panics که نوی ظرفیت د `isize::MAX` بایټونو څخه ډیر شي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// په سمه توګه د `additional` نورو عناصرو لپاره لږترلږه ظرفیت زیرمه کړئ ترڅو ورکړل شوي `Vec<T>` کې دننه شي.
    ///
    /// د `reserve_exact` تلیفون کولو وروسته ، ظرفیت به د `self.len() + additional` څخه لوی یا مساوي وي.
    /// هیڅ نه کوي که چیرې ظرفیت دمخه کافی وي.
    ///
    /// په یاد ولرئ چې تخصیص کونکي ممکن د دې غوښتنې څخه خورا ډیر ځای ورکړي.
    /// نو له دې امله ، ظرفیت په دقیقه توګه لږ نه تکیه کیدی شي.
    /// `reserve` ته ترجیح ورکړئ که چیرې د future زیاتوالي تمه کیږي.
    ///
    /// # Panics
    ///
    /// Panics که نوی ظرفیت له `usize` ډیر شي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// په ورکړل شوي `Vec<T>` کې د لږترلږه `additional` نورو عناصرو لپاره ظرفیت خوندي کولو هڅه کوي.
    /// راټولول ممکن د پرله پسې بیاکتنې مخه نیولو لپاره ډیر ځای خوندي کړي.
    /// د `try_reserve` تلیفون کولو وروسته ، ظرفیت به د `self.len() + additional` څخه لوی یا مساوي وي.
    /// هیڅ نه کوي که چیرې ظرفیت دمخه کافی وي.
    ///
    /// # Errors
    ///
    /// که چیرې د ظرفیت له مخې جریان کیږي ، یا تخصیص د ناکامۍ راپور ورکوي ، نو بیا یوه تېروتنه راستون شوې.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // له حافظې مخکې زېرمه ، رخصت کېدل که نه شو کولی
    ///     output.try_reserve(data.len())?;
    ///
    ///     // اوس موږ پوهیږو چې دا زموږ د پیچلي کار په مینځ کې OOM نشي کولی
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ډیر پیچلی
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// په سمه توګه د `additional` عناصرو لپاره لږترلږه ظرفیت خوندي کولو هڅه کوي په ورکړل شوي `Vec<T>` کې دننه شي.
    /// د `try_reserve_exact` تلیفون کولو وروسته ، ظرفیت به د `self.len() + additional` څخه لوی یا مساوي وي که دا د `Ok(())` بیرته راشي.
    ///
    /// هیڅ نه کوي که چیرې ظرفیت دمخه کافی وي.
    ///
    /// په یاد ولرئ چې تخصیص کونکي ممکن د دې غوښتنې څخه خورا ډیر ځای ورکړي.
    /// نو له دې امله ، ظرفیت په دقیقه توګه لږ نه تکیه کیدی شي.
    /// `reserve` ته ترجیح ورکړئ که چیرې د future زیاتوالي تمه کیږي.
    ///
    /// # Errors
    ///
    /// که چیرې د ظرفیت له مخې جریان کیږي ، یا تخصیص د ناکامۍ راپور ورکوي ، نو بیا یوه تېروتنه راستون شوې.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // له حافظې مخکې زېرمه ، رخصت کېدل که نه شو کولی
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // اوس موږ پوهیږو چې دا زموږ د پیچلي کار په مینځ کې OOM نشي کولی
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ډیر پیچلی
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// د vector ظرفیت تر هرڅه حده راکموي.
    ///
    /// دا به د امکان تر حده پورې اوږدوالي ته راښکته شي مګر اختصاص کونکي لاهم vector خبرداری ورکوي چې د یو څو نورو عناصرو لپاره ځای شتون لري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // ظرفیت هیڅکله د اوږدوالي څخه کم ندی ، او هیڅ شی کولو لپاره هیڅ نلري کله چې دوی مساوي وي ، نو موږ کولی شو په `RawVec::shrink_to_fit` کې د panic قضیه یوازې د لوی ظرفیت سره زنګ وهلو څخه مخنیوی وکړو.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// د ټیټ حد سره د vector ظرفیت ټیټوي.
    ///
    /// ظرفیت به لږترلږه دومره لوی وي لکه دواړه د عرض او ورکړل شوي ارزښت.
    ///
    ///
    /// که چیرې اوسنی ظرفیت د ټیټ حد څخه لږ وي ، نو دا انتخاب ندي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector په [`Box<[T]>`][owned slice] بدلوي.
    ///
    /// په یاد ولرئ چې دا به اضافي ظرفیت پریږدي.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// هر اضافي ظرفیت له مینځه وړل کیږي:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// د vector لنډوي ، د لومړي `len` عناصر ساتي او پاتې نور غورځوي.
    ///
    /// که `len` د vector اوسني اوږدوالي څخه لوی وي ، دا هیڅ اغیزه نلري.
    ///
    /// د [`drain`] میتود کولی شي `truncate` تقلید کړي ، مګر د ډیرو عناصرو د غورځیدو پرځای بیرته راستنیدو لامل کیږي.
    ///
    ///
    /// په یاد ولرئ چې دا طریقه د vector مختص شوي ظرفیت باندې هیڅ اغیزه نلري.
    ///
    /// # Examples
    ///
    /// دوه عناصرو ته د پنځه عنصر vector ټریک کول:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// هیڅ تنګی نه پیښیږي کله چې `len` د vector اوسني اوږدوالي څخه لوړ وي:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// تعقیب کول کله چې `len == 0` د [`clear`] میتود زنګ وهلو سره مساوي وي.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // دا خوندي دی ځکه چې:
        //
        // * ټوټه `drop_in_place` ته د اعتبار وړ ده؛د `len > self.len` قضیه د ناباوره ټوټې جوړولو څخه مخنیوی کوي ، او
        // * د vector `len` د `drop_in_place` زنګ وهلو دمخه سکور شوی ، داسې چې هیڅ ارزښت به دوه ځله نه راټیټ شي که چیرې X02 یو ځل panic ته وی (که دا دوه ځله panics وي ، برنامه بنده شي).
        //
        //
        //
        unsafe {
            // Note: دا قصد دی چې دا `>` دی او نه `>=`.
            //       `>=` ته د دې بدلول په ځینو مواردو کې د منفي فعالیت اغیزه لري.
            //       د نورو لپاره #78884 وګورئ.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// یوه ټوټه استخراجوي چې ټوله vector لري.
    ///
    /// د `&s[..]` سره مساوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// د ټول vector یوه تغیر وړ سلیس راوباسي.
    ///
    /// د `&mut s[..]` سره مساوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// د vector بفر ته خام پواینټ راستنوي.
    ///
    /// زنګ وهونکی باید ډاډ ترلاسه کړي چې vector د دې فنټر بیرته راګرځیدونکي پوائنټ لیټ کوي ، یا بل دا به د کثافاتو په نښه کولو پای ته ورسیږي.
    /// د vector تغیر کول ممکن د دې بفر د بیا پیل کیدو لامل شي ، کوم چې به دې ته کوم نکات هم غیرقانوني کړي.
    ///
    /// زنګ وهونکی هم باید ډاډ ترلاسه کړي چې یادداشت (non-transitively) ته اشاره کوي هیڅکله نه دې لیکل شوی (پرته د `UnsafeCell` دننه) د دې نښې یا کوم نښې چې له دې څخه اخیستل شوي په کارولو سره لیکل کیږي.
    /// که تاسو اړتیا لرئ د سلایس مینځپانګې بدل کړئ ، نو [`as_mut_ptr`] وکاروئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // موږ د ورته نوم سلیز میتود سیوری کوو ترڅو د `deref` له لارې تیریدو څخه مخنیوی وکړو ، کوم چې منځمهاله حواله رامینځته کوي.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// د vector بفر ته غیر خوندي محافظت کونکي پوائنټر ته راستنوي.
    ///
    /// زنګ وهونکی باید ډاډ ترلاسه کړي چې vector د دې فنټر بیرته راګرځیدونکي پوائنټ لیټ کوي ، یا بل دا به د کثافاتو په نښه کولو پای ته ورسیږي.
    ///
    /// د vector تغیر کول ممکن د دې بفر د بیا پیل کیدو لامل شي ، کوم چې به دې ته کوم نکات هم غیرقانوني کړي.
    ///
    /// # Examples
    ///
    /// ```
    /// // vector د 4 عناصرو لپاره کافي غټ تنظیم کړئ.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // د خامو اشارو لیکلو له لارې عناصر پیل کړئ ، بیا اوږدوالی وټاکئ.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // موږ د ورته نوم سلیز میتود سیوری کوو ترڅو د `deref_mut` له لارې تیریدو څخه مخنیوی وکړو ، کوم چې منځمهاله حواله رامینځته کوي.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// لاندې اختصاص کونکي ته حواله ورکوي.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// د vector اوږدوالی `new_len` ته زور ورکوي.
    ///
    /// دا د ټیټې کچې عملیات دي چې د نوعیت هیڅ ډول عادي بریدګر نه ساتي.
    /// عموما د vector اوږدوالی بدلول د یو بل خوندي عملیاتو په کارولو سره ترسره کیږي ، لکه [`truncate`] ، [`resize`] ، [`extend`] ، یا [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` باید د [`capacity()`] څخه کم یا مساوي وي.
    /// - په `old_len..new_len` کې عناصر باید پیل شي.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// دا میتود د هغه شرایطو لپاره ګټور کیدی شي چیرې چې vector د نورو کوډونو لپاره د بفر په توګه کار کوي ، په ځانګړي توګه FFI باندې:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // دا د ډیک مثال لپاره لږترلږه کنکال دی؛
    /// # // دا د اصلي کتابتون لپاره د پیل ټکي په توګه مه کاروئ.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // د FFI میتود لاسوندونو پراساس ، "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // خوندي: کله چې `deflateGetDictionary` `Z_OK` بیرته راولي ، نو دا ساتي چې:
    ///     // 1. `dict_length` عناصر پیل شوي وو.
    ///     // 2.
    ///     // `dict_length` <=ظرفیت (32_768) کوم چې د زنګ وهلو لپاره `set_len` خوندي کوي.
    ///     unsafe {
    ///         // د FFI تلیفون وکړئ ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... او اوږدوالي یې هغه څه ته تازه کړئ چې پیل شوي و.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// پداسې حال کې چې لاندې مثال روښانه دی ، د حافظې لیک شتون لري ځکه چې داخلي vectors د `set_len` تلیفون دمخه آزاد شوی نه و:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` تشه ده نو هیڅ عناصر شروع کولو ته اړتیا نلري.
    /// // 2. `0 <= capacity` هرکله چې هر څه `capacity` وي هغه لري.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// عموما ، دلته ، یو به د دې پرځای [`clear`] وکاروي ترڅو مینځپانګې په سمه توګه وویستل شي او په دې توګه حافظه لیک نشي.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// له vector څخه یو عنصر لرې کوي او بیرته یې راستنوي.
    ///
    /// لرې شوی عنصر د vector وروستی عنصر لخوا ځای په ځای شوی.
    ///
    /// دا د سپارنې ساتنه نه کوي ، مګر دا O(1) دی.
    ///
    /// # Panics
    ///
    /// Panics که `index` له حد څخه وتلی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // موږ خپل ځان [شاخص] د وروستي عنصر سره ځای په ځای کوو.
            // په یاد ولرئ که چیرې پورتني حدونه بریالي شي نو باید وروستی عنصر شتون ولري (کوم چې پخپله پخپله [انډیکس] کیدی شي).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// په vector کې `index` موقعیت کې عنصر داخلوي ، وروسته ټول عناصر ښیې خوا ته اړوي.
    ///
    ///
    /// # Panics
    ///
    /// Panics که `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // د نوي عنصر لپاره ځای
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // د نوي ارزښت د ایښودلو ځای
            //
            {
                let p = self.as_mut_ptr().add(index);
                // د ځای جوړولو لپاره هرڅه ته اړول.
                // (په پرله پسې توګه دوه ځله د `index`th عنصر کاپي کول.)
                ptr::copy(p, p.offset(1), len - index);
                // په کې یې ولیکئ ، د `فهرست` عنصر لمړنۍ کاپي له سره لیکلو.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// عنصر لرې کوي او په vector کې `index` موقعیت کې راستنوي ، وروسته ټول عناصر کی it اړخ ته اړول.
    ///
    ///
    /// # Panics
    ///
    /// Panics که `index` له حد څخه وتلی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // هغه ځای چې موږ ترې اخلو.
                let ptr = self.as_mut_ptr().add(index);
                // دا کاپي کړئ ، په خوندي ډول په سټیک کې د ارزښت کاپي درلودل او په ورته وخت کې vector کې.
                //
                ret = ptr::read(ptr);

                // د ځای ځای ډکولو لپاره هرڅه لاندې کېږدئ.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// یوازې هغه عناصر ساتي چې د پیشو لخوا مشخص شوي دي.
    ///
    /// په نورو ټکو کې ، ټول عناصر `e` لرې کړئ لکه `f(&e)` `false` بیرته راوړي.
    /// دا میتود په ځای عمل کوي ، هر یو عنصر ته په اصلي ترتیب کې یو ځل لیدنه کوي ، او د ساتل شوي عناصر ترتیب ساتي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// ځکه چې عناصر په اصلي ترتیب کې یو ځل لیدل کیږي ، بهرني حالت ممکن د پریکړې کولو لپاره وکارول شي چې کوم عناصر وساتل شي.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // د دوه ځنډ څخه مخنیوی وکړئ که چیرې د قطع محافظ ونه اجرا شي ، ځکه چې موږ ممکن د پروسې په جریان کې ځینې سوري وکړو.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-پروسس شوي لین-> |^-د چیک کولو څنګ کې
        //                  | <-ړنګ شوی cnt-> |
        //      | <-original_len-> |ساتل شوی: هغه عنصر چې وړاندوینه یې په سمه کیږي.
        //
        // هول: د عنصر سلاټ حرکت یا غورځول شوی.
        // ناتول شوي: بې اعتباره اعتبار لرونکي عنصر.
        //
        // د دې غورځونکي ساتونکي به وغوښتل شي کله چې وړاندوینه یا د عنصر `drop` ویره شي.
        // دا ناپاک شوي عناصر د سوري او `set_len` پوښلو لپاره مناسب اوږدوالي ته اړوي.
        // په داسې قضیو کې کله چې پیشوونکی او `drop` هیڅکله هم مه غورځوي ، نو دا به غوره شي.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // امنیت: د نه چیک شوي توکو تعقیب باید باوري وي ځکه چې موږ هیڅکله دوی ته لاس ورنکړو.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // خوندي: د سوري ډکولو وروسته ، ټول توکي په حافظه کې دي.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // خوندي: ناتړل شوی عنصر باید باوري وي.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // مخکې له مخکې پرمختللی د دوه ځلې مخنیوي لپاره که `drop_in_place` ویره ولري.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // خوندي: موږ هیڅکله د دې عنصر له کښته کیدو وروسته هیڅکله لاس ورنکړو.
                unsafe { ptr::drop_in_place(cur) };
                // موږ دمخه کاونټ پرمختللی کړی.
                continue;
            }
            if g.deleted_cnt > 0 {
                // خوندي: `deleted_cnt`> 0 ، نو د سوراخ سلاټ باید د اوسني عنصر سره overlap نه وي.
                // موږ د تګ لپاره کاپي کاروو ، او هیڅکله به دې عنصر ته لاس ورنکړو.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // ټول توکي پروسس شوي دي.دا د LLVM لخوا `set_len` ته مطلوب کیدی شي.
        drop(g);
    }

    /// په vector کې د پرله پسې عناصرو څخه پرته ټول لرې کوي چې ورته کیلي ته حل کوي.
    ///
    ///
    /// که د vector ترتیب شوی وي ، نو دا ټول نقلونه لرې کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// په vector کې د پرله پسې عناصرو پرته مګر ټول لرې کوي د ورکړل شوي مساواتو اړیکې قناعت کوي.
    ///
    /// د `same_bucket` فنکشن د vector دوه عناصرو ته مآخذونه لیږدول کیږي او باید مشخص شي که چیرې عناصر مساوي پرتله کړي.
    /// عناصر په سلایس کې د دوی له حکم څخه په مقابل ترتیب کې تیریږي ، نو که `same_bucket(a, b)` `true` بیرته راشي ، `a` لیرې کیږي.
    ///
    ///
    /// که د vector ترتیب شوی وي ، نو دا ټول نقلونه لرې کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// د راټولولو شاته عنصر ضمیمه کوي.
    ///
    /// # Panics
    ///
    /// Panics که نوی ظرفیت د `isize::MAX` بایټونو څخه ډیر شي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // دا به panic یا ضایع شي که چیرې موږ> isize::MAX بایټونه تخصیص کړو یا که چیرې د اوږدوالي زیاتوالي به د صفر اندازو ډولونو لپاره ډیریږي.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// وروستی عنصر له vector څخه لرې کوي او بیرته یې ورکوي ، یا [`None`] که دا خالي وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// د `other` ټول عناصر په `Self` کې حرکت کوي ، د `other` خالي پریښودل.
    ///
    /// # Panics
    ///
    /// Panics که په vector کې د عناصرو شمیر د `usize` ډیر شي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// له نورو بفر څخه `Self` ته عناصر اضافه کوي.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// یو وچ ایټریټر رامینځته کوي چې په vector کې ټاکل شوی حد لرې کوي او حذف شوي توکي ترلاسه کوي.
    ///
    /// کله چې تکرار ** ** پریښودل شي ، نو په حد کې ټول عنصرونه د vector څخه حذف کیږي ، حتی که چیرې تکرار کونکی په بشپړه توګه ونه مصرف شوی وي.
    /// که چیرې تیریدونکی ** ** نه وي (د مثال په توګه د [`mem::forget`] سره) ، دا نامعلومه ده چې څومره عناصر لیرې شوي.
    ///
    /// # Panics
    ///
    /// Panics که چیرې د پیل ټکی د پای ټکي څخه لوی وي یا که پای ټکی د vector اوږدوالي څخه لوړ وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // بشپړه لړۍ د vector پاکوي
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // د حافظې خوندیتوب
        //
        // کله چې د Drain لومړی ځل رامینځته شو ، نو دا د سرچینې vector اوږدوالی لنډوي ترڅو ډاډ ترلاسه کړي چې بې بنسټه یا حرکت شوي عناصر په هرڅه کې د لاسرسي وړ ندي که چیرې د Drain ویجاړونکی هیڅکله هم پرمخ نه ځي.
        //
        //
        // Drain به ptr::read د لرې کولو ارزښتونه بهر کړي.
        // کله چې پای ته ورسید ، د رګونو پاتې کیږدۍ د سوري پوښ لپاره بیرته کاپي کیږي ، او د vector اوږدوالی نوي اوږدوالي ته بحال کیږي.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // د پیل لپاره د self.vec اوږدوالی تنظیم کړئ ، ترڅو د Drain لیک په صورت کې خوندي وي
            self.set_len(start);
            // په IterMut کې پور واخلئ ترڅو د ټول Drain تکرار پور ورکونکي چلند په ګوته کړئ (لکه د &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector پاکوي ، ټول ارزښتونه لرې کوي.
    ///
    /// په یاد ولرئ چې دا طریقه د vector مختص شوي ظرفیت باندې هیڅ اغیزه نلري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// په vector کې د عناصرو شمیر راوباسي ، چې د هغې 'length' په توګه هم راجع کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `true` راستنوي که چیرې vector هیڅ عنصر ونه لري.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ټولګه په ورکړل شوي شاخص کې دوه برخو ویشلې.
    ///
    /// د نوي مختص شوي vector بیرته راستنوي چې د `[at, len)` لړ کې عناصر لري.
    /// د زنګ وروسته ، اصلي vector به د `[0, at)` عناصر لرونکي پاتې شي چې د هغې پخوانی ظرفیت بدلې سره.
    ///
    ///
    /// # Panics
    ///
    /// Panics که `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // نوی vector کولی شي اصلي بفر ونیسي او د کاپي مخه ونیسي
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // په خوندي ډول `set_len` او توکي `other` ته کاپي کړئ.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// د `Vec` ځای ځای بدلوي ترڅو `len` د `new_len` سره مساوي وي.
    ///
    /// که `new_len` د `len` څخه لوی وي ، `Vec` د توپیر سره غزول شوی ، د هرې اضافي سلاټ سره د بند `f` زنګ وهلو پایله کې ډک شوی.
    ///
    /// د `f` څخه د بیرته راستنیدنې ارزښتونه به په `Vec` کې په ترتیب سره پای ته ورسي چې دوی تولید شوي.
    ///
    /// که `new_len` د `len` څخه کم وي ، نو `Vec` په ساده ډول لنډ شوی.
    ///
    /// دا میتود په هر فشار کې د نوي ارزښتونو رامینځته کولو لپاره بند کاروي.که تاسو د [`Clone`] پرځای ورکړل شوی ارزښت غواړئ ، نو [`Vec::resize`] وکاروئ.
    /// که تاسو غواړئ د ارزښتونو تولید لپاره [`Default`] trait وکاروئ ، نو تاسو کولی شئ [`Default::default`] د دوهم دلیل په توګه تېر کړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` مصرف او لیک کړئ ، مینځپانګې ته د بدلون وړ حواله بیرته راستنوي ، `&'a mut [T]`.
    /// په یاد ولرئ چې د `T` ډول باید غوره شوي وخت `'a` ضایع کړي.
    /// که دا ډول یوازې جامد مآخذ ولري ، یا هیڅ نه وي ، نو دا ممکن د `'static` غوره شي.
    ///
    /// دا فنکشن په [`Box`] کې د [`leak`][Box::leak] فنکشن سره ورته دی پرته لدې چې د لیک شوي حافظې بیرته ترلاسه کولو لپاره هیڅ لاره شتون نلري.
    ///
    ///
    /// دا فنکشن عموما د معلوماتو لپاره ګټور دی چې د برنامه پاتې ژوند لپاره ژوند کوي.
    /// د راستنیدونکي حوالې غورځول به د حافظې د راوتلو لامل شي.
    ///
    /// # Examples
    ///
    /// ساده کارول:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// د vector پاتې اضافي وړتیا د `MaybeUninit<T>` سلیس په توګه بیرته راولي.
    ///
    /// بیرته سلیس د vector د ډیټا سره ډکولو لپاره کارول کیدی شي (د مثال په توګه
    /// د فایل څخه لوستلو سره) مخکې لدې چې د [`set_len`] میتود په کارولو سره ارقام په نښه کړئ.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // vector د 10 عناصرو لپاره کافي غټ تنظیم کړئ.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // په لومړي 3 عناصرو کې ډک کړئ.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // د vector لومړني 3 عناصر د پیل په توګه نښه کړئ.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // دا طریقه د `split_at_spare_mut` په شرایطو کې نده پلي کیږي ، ترڅو بفر ته د نښو وتلو مخه ونیسي.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// د vector مینځپانګه د `T` سلیس په توګه ، د vector پاتې پاتې ظرفیت سره د `MaybeUninit<T>` سلیس په توګه بیرته راستنوي.
    ///
    /// د بیرته راستانه شوي ظرفیت سلیس د vector ډکولو لپاره کارول کیدی شي د مثال په توګه د [`set_len`] میتود په کارولو سره پیل شوي ډاټا په نښه کولو دمخه (د بیلګې په توګه د فایل څخه لوستل).
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// په یاد ولرئ چې دا د ټیټ کچې API دی ، کوم چې باید د مطلوب مقاصدو لپاره د پاملرنې سره وکارول شي.
    /// که تاسو اړتیا لرئ `Vec` ته ډاټا ضمیمه کړئ نو تاسو د [`push`] ، [`extend`] ، [`extend_from_slice`] ، [`extend_from_within`] ، [`insert`] ، [`append`] ، [`resize`] یا [`resize_with`] وکاروئ ، چې ستاسو دقیق اړتیاو پورې اړه لري.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // اضافي 10 د عناصرو لپاره لوی ځای وساتئ.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // په راتلونکو 4 عناصرو ډک کړئ.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // د پیل کولو په توګه د vector 4 عناصر په نښه کړئ.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - لین له پامه غورځول شوی دی او له همدې امله هیڅکله نه بدلیږي
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// خوندیتوب: بدل شوی .2 (&mut usize) د `.set_len(_)` زنګ وهلو ته ورته ګ .ل کیږي.
    ///
    /// دا میتود په `extend_from_within` کې په یوځل ټولو ویکتور برخو ته ځانګړي لاسرسي لپاره کارول کیږي.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` د `len` عناصرو لپاره د اعتبار وړ تضمین دی
        // - `spare_ptr` د بفر تیر یو عنصر په ګوته کوي ، نو دا د `initialized` سره پراخه نشي
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// د `Vec` ځای ځای بدلوي ترڅو `len` د `new_len` سره مساوي وي.
    ///
    /// که `new_len` د `len` څخه لوی وي ، `Vec` د توپیر سره غزول شوی ، د هر اضافي سلاټ سره د `value` ډک شوی.
    ///
    /// که `new_len` د `len` څخه کم وي ، نو `Vec` په ساده ډول لنډ شوی.
    ///
    /// دا میتود د [`Clone`] پلي کولو لپاره `T` ته اړتیا لري ، په دې ترتیب چې د قادر شوي ارزښت کلون کولو وړ وي.
    /// که تاسو ډیر انعطاف ته اړتیا ولرئ (یا غواړئ د [`Clone`] پرځای [`Default`] تکیه وکړئ) ، نو [`Vec::resize_with`] وکاروئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` ته په ټوټه کې ټول عناصر کلون کوي او ضمیمه کوي.
    ///
    /// د سلایس `other` په اوږدو کې تفریح ، هر عنصر کلون کوي ، او بیا یې دې `Vec` ته ضمیمه کوي.
    /// د `other` vector په ترتیب ترتیب شوی.
    ///
    /// په یاد ولرئ چې دا فنکشن د [`extend`] په څیر دی پرته لدې چې دا د دې پرځای د سلیزو سره کار کولو ته ځانګړی شوی وي.
    ///
    /// که او کله چې Rust تخصص ترلاسه شي نو دا فنکشن به احتمال له پامه وغورځول شي (مګر لاهم شتون لري).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// د `src` لړۍ څخه د vector پای پورې کاپي عناصر کاپي کړئ.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` تضمین ورکوي چې ورکړل شوې سلسله د ځان د تداوي لپاره معتبر ده
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// دا کوډ `extend_with_{element,default}` عمومي کوي.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// د ورکړل شوي جنراتور په کارولو سره ، د `n` ارزښتونو لخوا vector پراخ کړئ.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // د بګ شاوخوا کار کولو لپاره سیټ لین او ډراپ وکاروئ چیرې چې تالیف کونکی ممکن د `ptr` له لارې د self.set_len() له لارې توری ونه احساس کړي.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // ټول وروستي عناصر ولیکئ
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // د next() panics په قضیه کې هر مرحله کې اوږدوالی لوړ کړئ
                local_len.increment_len(1);
            }

            if n > 0 {
                // موږ کولی شو وروستي عنصر په مستقیم ډول پرته له کلون څخه په لیکلو ولیکو
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // د سکاو ساتونکي لخوا تنظیم شوی
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// د [`PartialEq`] trait پلي کولو له مخې په vector کې پرله پسې تکرار شوي عناصر لرې کوي.
    ///
    ///
    /// که د vector ترتیب شوی وي ، نو دا ټول نقلونه لرې کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// داخلي میتودونه او دندې
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` د اعتبار وړ شاخص ته اړتیا ده
    /// - `self.capacity() - self.len()` باید `>= src.len()` وي
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - لین یوازې د عناصرو له پیل وروسته ډیر شوی
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - زنګ وهونکي تضمین کوي چې src یو معتبره شاخص دی
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - عنصر یوازې د `MaybeUninit::write` سره پیل شوی و ، نو ځکه دا د انکشاف لین څخه ښه دی
            // - لین د هر عنصر وروسته ډیر شوی چې د لیک مخه ونیسي (د مسلې #82533 وګورئ)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - زنګ وهونکی تضمین کوي چې `src` یو معتبره شاخص دی
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - دواړه نښې د ځانګړي سلایډ حوالې (`&mut [_] mut) څخه رامینځته شوي دي نو دا معتبر دي او نه پوښل کیږي.
            //
            // - عنصرونه دي: کاپي نو د دوی کاپي کول سم دي ، پرته له اصلي ارزښتونو سره هیڅ شی
            // - `count` د `source` لین سره برابر دی ، نو سرچینه د `source` لوستلو لپاره معتبر ده
            // - `.reserve(count)` تضمین ورکوي چې د `spare.len() >= count` نو سپیر د `count` لیکلو لپاره معتبر دی
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - عناصر یوازې د `copy_nonoverlapping` لخوا پیل شوي و
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// د Vec لپاره عام trait پلي کول
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): د cfg(test) سره اصلي `[T]::to_vec` میتود ، کوم چې د دې میتود تعریف لپاره اړین دی ، شتون نلري.
    // پرځای یې د `slice::to_vec` فنکشن وکاروئ کوم چې یوازې د cfg(test) NB سره شتون لري د نورو معلوماتو لپاره په slice.rs کې د slice::hack ماډل وګورئ
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // هر هغه شی پریږدی چی له سره به نه تاوول کیږی
        self.truncate(other.len());

        // self.len <= other.len د پورتنۍ برخې د ټوټېدو له امله ، نو دلته ټوټې تل په دننه کې دي.
        //
        let (init, tail) = other.split_at(self.len());

        // موجود ارزښتونه allocations/resources بیا وکاروئ.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// مصرف کونکي تیریټر رامینځته کوي ، دا هغه یو دی چې هر ارزښت له vector څخه بهر (له پیل څخه تر پای پورې) حرکت کوي.
    /// vector د دې زنګ وهلو وروسته نشي کارول کیدلی.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ډول سټینګ لري ، نه &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // د پا leafې میتود چېرې چې د SpecFrom/SpecExtend پلي کولو بیلابیل استازیتوب کوي کله چې دوی د پلي کولو لپاره نور مطلوب نه وي
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // دا د عمومي تکرار کونکي قضیه ده.
        //
        // دا فنکشن باید د اخلاقي مساوي وي:
        //
        //      په تکرار کې توکي لپاره {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ډیر نشي کولی ځکه چې موږ به یې باید د پته ځای تخصیص کړی وای
                self.set_len(len + 1);
            }
        }
    }

    /// یو سپکیدونکی تکرار رامینځته کوي چې په ورکړل شوي `replace_with` تکرار سره په vector کې ټاکل شوې لړۍ ځای په ځای کوي او حذف شوي توکي ترلاسه کوي.
    ///
    /// `replace_with` د `range` په اندازه ورته اوږدوالي ته اړتیا نلري.
    ///
    /// `range` حتی حذف کیږي حتی که چیرې تکرارونکي تر پای پورې مصرف نه وي.
    ///
    /// دا نامعلومه ده چې څومره عناصر له vector څخه لرې شوي که چیرې د `Splice` ارزښت لیک شي.
    ///
    /// د آخذې تکرار `replace_with` یوازې هغه وخت مصرفیږي کله چې د `Splice` ارزښت راټیټ شي.
    ///
    /// دا مطلوب دی که:
    ///
    /// * لکۍ (له `range` وروسته په vector کې عناصر) خالي دي ،
    /// * یا `replace_with` د `حد` اوږدوالي په پرتله لږ یا مساوي عناصر ترلاسه کوي
    /// * یا د دې د `size_hint()` ټیټ حد دقیق دی.
    ///
    /// نور نو ، لنډمهاله vector مختص شوی او دم دوه ځله لیږدول کیږي.
    ///
    /// # Panics
    ///
    /// Panics که چیرې د پیل ټکی د پای ټکي څخه لوی وي یا که پای ټکی د vector اوږدوالي څخه لوړ وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// ایټریټر رامینځته کوي چې د تړلو لپاره کاروي ترڅو معلومه کړي چې ایا عنصر باید لرې شي.
    ///
    /// که چیرې بندیز ریښتیا راشي ، نو عنصر لرې کیږي او حاصل ورکول کیږي.
    /// که چیرې بندیز ناسم راستون شي ، عنصر به په vector کې پاتې شي او د تکرار کونکي لخوا به ترلاسه نشي.
    ///
    /// د دې میتود کارول د لاندې کوډ سره مساوي دي:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // دلته ستاسو کوډ
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// مګر `drain_filter` کارول اسانه دي.
    /// `drain_filter` هم ډیر اغیزمن دی ، ځکه چې دا کولی شي په لویه کچه د صف عناصرو ملاتړ وکړي.
    ///
    /// په یاد ولرئ چې `drain_filter` هم تاسو ته اجازه درکوي د فلټر بند کې هر عنصر بدل کړئ ، پرته لدې چې تاسو د دې ساتلو یا لرې کولو غوره کوئ.
    ///
    ///
    /// # Examples
    ///
    /// په شامونو او توپیرونو کې د یو ډول وېش ، د اصلي تخصیص څخه په کارولو سره:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // زموږ د ساتلو په مقابل کې ساتنه (د پیاوړتیا پراخه کول)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// د پلي کولو غځول چې عناصر یې د مآخذ څخه نقل کوي مخکې له دې چې په ویسیک کې فشار واچوي.
///
/// دا پلي کول د سلیس تکرارونکو لپاره ځانګړي شوي چیرې چې دا په یوځل کې د ټول سلیس ضمیمه کولو لپاره [`copy_from_slice`] کاروي.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// د vectors پرتله کولو پلي کول ، [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// د vectors سپارلو پلي کول ، [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // د [T] لپاره ډراپ کارول د خام ټوټې کاروي ترڅو د vector عناصرو ته د ضعیف لازمي ډول په توګه اشاره وکړي؛
            //
            // کیدی شي په ځینو مواردو کې د اعتبار له پوښتنو څخه مخنیوی وکړي
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec تخفیف اداره کوي
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// یو خالي `Vec<T>` رامینځته کوي.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: ازموینه په لیبسټډ کې راښکته کوي ، کوم چې دلته د غلطیو لامل کیږي
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: ازموینه په لیبسټډ کې راښکته کوي ، کوم چې دلته د غلطیو لامل کیږي
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// د `Vec<T>` ټول مینځپانګه د یو صف په توګه ترلاسه کوي ، که چیرې د هغې اندازه د غوښتل شوي صف سره ورته وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// که چیرې اوږدوالی سره سمون ونلري ، نو پیوستون یې په `Err` کې بیرته راځي:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// که تاسو د `Vec<T>` د مختاج ترلاسه کولو سره ښه یاست ، تاسو کولی شئ لومړی [`.truncate(N)`](Vec::truncate) ته زنګ ووهئ.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // خوندي: `.set_len(0)` تل تل ښه وي.
        unsafe { vec.set_len(0) };

        // : SA AYY: د ```` poin poin pointer terter alwayster always properly properly always properly properly. properly properly properly properly. properlyigned.. al وي او
        // د صف برابرول د توکي سره ورته دي.
        // موږ مخکې چیک کړی و چې موږ کافي توکي لرو.
        // توکي به دوه چنده نه غورځوي ځکه چې `set_len` `Vec` ته وايي چې دوی هم پریږدي.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}