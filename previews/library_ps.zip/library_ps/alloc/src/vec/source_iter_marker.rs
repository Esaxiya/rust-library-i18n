use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// په Vec کې د تکراري پایپ لاین راټولولو لپاره د تخصص نښه کول پداسې حال کې چې د سرچینې تخصیص بیا کاروي
/// د دې پایپ لاین پلي کیدل.
///
/// د SourceIter پلر trait تخصیص کولو فعالیت لپاره اړین دی چې تخصیص ته لاسرسی ومومي کوم چې باید له سره وکارول شي.
/// مګر دا د تخصص لپاره کافی ندي چې معتبر وي.
/// په امپراطورۍ باندې اضافي حدونه وګورئ.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// د std-داخلي SourceIter/InPlaceIterable traits یوازې د اډیپټر سلسلو لخوا پلي کیږي <Adapter<Adapter<IntoIter>>> (ټول د core/std ملکیت دی).
// د اډیپټر پلي کونکو باندې اضافي حدونه (د `impl<I: Trait> Trait for Adapter<I>` هاخوا) یوازې په نورو traits پورې اړه لري چې دمخه د تخصص traits په توګه نښه شوی (کاپي ، ټریسټډرډم اکاسیس ، FusedIterator).
//
// I.e. مارکر د کارونکي لخوا چمتو شوي ډولونو د ژوند وختونو پورې اړه نلري.Modulo د کاپي سوراخ ، کوم چې څو نور تخصصونه لا دمخه تکیه کوي.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // اضافي اړتیاوې چې د trait bound له لارې نشي څرګند کیدلی.موږ پرځای یې د کانال ضد باندې تکیه کوو:
        // الف) هیڅ ZSTs شتون نلري ځکه چې د بیا کارولو لپاره ځانګړی تخصیص شتون نلري او د پوائنټر ریاضي به panic B) اندازه میچ به د Alloc قرارداد له مخې اړین وي) د شراکتونو مسابقه لکه د Alloc قرارداد لخوا
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // د نورو عمومي تطبیقاتو کې بیکاره
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // له هغه وخته د کوښښ هڅه وکړئ
        // - دا د ځینې تکرار اډاپټرونو لپاره غوره ویکټوریزز کوي
        // - د ډیری داخلي تکرار میتودونو برعکس ، دا یوازې &mut پخپله اخلي
        // - دا موږ ته اجازه راکوي د لیکلو نښې د هغې د انګړ له لارې وتړو او په پای کې یې بیرته ترلاسه کړو
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // تکرار بریالی شو ، سر مه کوه
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // وګوره چې آیا د SourceIter تړون په کافي اندازه ساتل شوی و: که دوی نه و موږ ممکن حتی دې ټکي ته یې نه وایو
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // د داخل ساتلو وړ قرارداد چیک کړئ.دا یوازې امکان لري که چیرې تکرار کونکي په ټوله کې د سرچینې اشاره پرمختللي کړي.
        // که چیرې دا د TrustedRandomAccess له لارې غیر چیک شوي لاسرسی وکاروي نو د سرچینې اشاره به په خپل لومړني حالت کې پاتې وي او موږ یې د حوالې په توګه نه کاروو
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // نور سرچینې د سرچینې په پای کې پریږدئ مګر د ځان د تخصیص کمولو مخه ونیسئ یوځل چې دننه دننه له ساحې څخه ووځي که panics ډراپ شي نو بیا موږ هم په dst_buf کې راټول شوي عناصر لیکو
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // د InPlaceIteable تړون په دقیقه توګه نشي تصدیق کیدی ځکه چې هڅه_فولډ د سرچینې نښې ته ځانګړي حواله لري موږ ټول هغه څه چې کولی شو هغه یې وڅیړو چې ایا دا لاهم په حد کې دی
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}