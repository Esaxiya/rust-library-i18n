/// د [`Vec`] رامینځته کونکی رامینځته کوي.
///
/// `vec!` `Vec`s ته اجازه ورکوي د ورته وینډوز سره د سرسري څرګندونو په توګه تعریف شي.
/// د دې میکرو دوه ډولونه دي:
///
/// - د [`Vec`] رامینځته کړئ چې د عناصرو ورکړل شوي لیست لري:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - د ورکړل شوي عنصر او اندازې څخه [`Vec`] جوړ کړئ:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// په یاد ولرئ چې د صفونو څرګندونو برعکس دا ترکیب د ټولو عناصرو ملاتړ کوي کوم چې [`Clone`] پلي کوي او د عناصرو شمیر باید ثابت نه وي.
///
/// دا به د بیان نقل کولو لپاره `clone` وکاروي ، نو یو څوک باید د دې ډول ډولونو سره کارولو ته احتیاط وکړي چې د غیر معیاري `Clone` تطبیق لري.
/// د مثال په توګه ، `vec![Rc::new(1)؛]] `به ورته بکس شوي انټژیر ارزښت ته د پنځو مآخذونو vector رامینځته کړي ، نه هغه پنځه مآخذونه چې په مستقیم ډول بکس شوي انډیروز ته په ګوته کوي.
///
///
/// همچنان ، په یاد ولرئ چې `vec![expr; 0]` اجازه لري ، او خالي vector تولید کوي.
/// دا به لاهم د `expr` ارزونه وکړي ، په هرصورت ، او سمدلاسه د پایله ارزښت راوباسي ، نو د اړخیزو تاثیراتو په پام کې ونیسئ.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): د cfg(test) سره اصلي `[T]::into_vec` میتود ، کوم چې د دې میکرو تعریف لپاره اړین دی ، شتون نلري.
// پرځای یې د `slice::into_vec` فنکشن وکاروئ کوم چې یوازې د cfg(test) NB سره شتون لري د نورو معلوماتو لپاره په slice.rs کې د slice::hack ماډل وګورئ
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// د رن ټیم بیاناتو انتشار په کارولو سره `String` رامینځته کوي.
///
/// لومړی دلیل چې `format!` ترلاسه کوي د فارمیټ تار دی.دا باید د تار تار وي.د فارميټنګ سټینټ ځواک په `.}}` s کې دی.
///
/// اضافي پیرامیټونه `format!` ته لیږل شوي په ترتیب شوي فارمټ کې دننه string {} `replace په ترتیب شوي ترتیب کې ځای په ځای شوي پرته لدې چې نوم یا موقعیتي پیرامیټرې وکارول شي؛د نورو معلوماتو لپاره [`std::fmt`] وګورئ.
///
///
/// د `format!` لپاره عام استعمال د تارونو ترکیب او تقویه کول دي.
/// ورته کنوانسیون د [`print!`] او [`write!`] ماکروز سره کارول کیږي ، د سټینګ ټاکل شوي منزل پورې اړه لري.
///
/// د یو واحد ارزښت تار ته بدلولو لپاره ، د [`to_string`] میتود وکاروئ.دا به د [`Display`] بtingه trait وکاروي.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics که د trait تطبیقې ب formatه غلطه بیرته راشي.
/// دا یو غلط پلي کول په ګوته کوي ځکه چې `fmt::Write for String` هیڅکله پخپله خطا نه راستنوي.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// د نمونې په حالت کې د تشخیصاتو ښه کولو لپاره AST نوډ ته فشار ورکړئ.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}