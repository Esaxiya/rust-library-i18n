//! د لومړیتوب کتار د دوه لمبر بیس سره تطبیق شوی.
//!
//! د لوی عنصر دننه کول او پوپ کول د *O*(log(*n*)) وخت پیچلتیا لري.
//! ترټولو لوی عنصر چیک کول *O*(1) دي.د vector بدلول بائنري ډی ته په ځای کې کیدی شي ، او د *O*(*n*) پیچلتیا لري.
//! د بائنری غوړ هم په ترتیب سره ترتیب شوی vector ته بدل کیدی شي ، دا اجازه ورکوي چې د *O*(*n*\*log(* n*)) دننه ځای heapsort لپاره وکارول شي.
//!
//! # Examples
//!
//! دا لوی مثال دی چې په [directed graph][dir_graph] کې د [shortest path problem][sssp] حل کولو لپاره [Dijkstra's algorithm][dijkstra] پلي کوي.
//!
//! دا ښیې چې څنګه د دودیز ډولونو سره [`BinaryHeap`] وکاروئ.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // د لومړیتوب کتنه په `Ord` پورې اړه لري.
//! // په څرګنده توګه د trait پلي کړئ نو قطار د د اعظمي هپ پرځای د من-هیپ شي.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // په پام کې ونیسئ چې موږ د لګښتونو ترتیب ترتیب فلیپ کوو.
//!         // د ټای په حالت کې موږ دریځونه پرتله کوو ، دا مرحله د `PartialEq` او `Ord` تطبیقولو لپاره اړینه ده.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` هم باید پلي شي.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // هر نوډ د `usize` په توګه ښودل شوی ، د لنډ پلي کولو لپاره.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // د ډیجکستر لنډ لاره الګوریتم.
//!
//! // په `start` کې پیل کړئ او هر نوډ ته اوسني لنډه لنډه فاصله تعقیب لپاره `dist` وکاروئ.دا پلي کول د حافظې وړ ندي ځکه چې دا کیدی شي دوه لمبر نوډونه په قطار کې پاتې شي.
//! //
//! // دا د ساده پلي کولو لپاره ، د لیږل شوي ارزښت په توګه `usize::MAX` هم کاروي.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [نوډ]=د `start` څخه `node` ته ترټولو لنډه فاصله
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // موږ په `start` کې یو ، د یو صفر لګښت سره
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // لومړی د (min-heap) ټیټ لګښت نوډونو سره سرحدي ازموینه وکړئ
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // په بدیل توګه موږ کولی شو ټولې لنډې لارې موندلو ته ادامه ورکړو
//!         if position == goal { return Some(cost); }
//!
//!         // مهم لکه څنګه چې موږ ممکن دمخه غوره لاره موندلې وي
//!         if cost > dist[position] { continue; }
//!
//!         // د هرې نوډ لپاره چې موږ رسیدلی شو ، وګورو چې ایا موږ کولی شو د دې نوډ له لارې د لږ لګښت سره لاره ومومو
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // که داسې وي ، نو دا په سرحد کې اضافه کړئ او دوام ورکړئ
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // آرام ، موږ اوس غوره لاره موندلې ده
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // هدف د لاسرسي وړ نه دی
//!     None
//! }
//!
//! fn main() {
//!     // دا هغه لارښود ګراف دی چې موږ یې کاروو.
//!     // د نوډ شمیرې د مختلف ریاستونو سره مطابقت لري ، او د edge وزنونه له یو نوډ څخه بلې ته د تګ لګښت منعکس کوي.
//!     //
//!     // په یاد ولرئ چې څنډې یو طرفه دي.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |.
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ګراف د نږدې والي لیست په توګه ښودل شوی چیرې چې هر شاخص ، د نوډ ارزښت سره سم ، د وتلو څنډو لیست لري.
//!     // د دې موثریت لپاره غوره شوی.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // نوډ 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // نوډ 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // نوډ 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // نوډ 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // نوډ.
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// د لومړیتوب کتار د دوه لمبر بیس سره تطبیق شوی.
///
/// دا به اعظمي حد وي
///
/// دا د یو منطق غلطي ده چې د یو توکي په داسې ډول تعدیل شي چې د بل توکي سره په تړاو د توکي حکم ورکول ، لکه څنګه چې د `Ord` trait لخوا ټاکل شوی ، پداسې حال کې چې دا په ګیډۍ کې دی.
///
/// دا په نورمال ډول یوازې د `Cell` ، `RefCell` ، نړیوال دولت ، I/O ، یا غیر خوندي کوډ له لارې امکان لري.
/// چلند د داسې منطق خطا له امله رامینځته شوی نه دی مشخص شوی ، مګر د نامعلومه چلند په پایله کې به نه وي.
/// پدې کې ممکن panics ، غلطې پایلې ، بندیز ، حافظې لیک ، او نه ختمیدل شامل وي.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // د ډول ډول لارښوونه موږ ته اجازه راکوي چې یو څرګند ډول لاسلیک له لاسه ورکړو (کوم چې به دې مثال کې `BinaryHeap<i32>` وي).
/////
/// let mut heap = BinaryHeap::new();
///
/// // موږ کولی شو پوړ وکاروو په راتلونکي کې راتلونکي توکي لیدو لپاره.
/// // پدې حالت کې ، دلته لاهم توکي شتون نلري نو موږ هیڅ هم نه ترلاسه کوو.
/// assert_eq!(heap.peek(), None);
///
/// // راځئ چې یو څه نمرې اضافه کړو ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // اوس ټوکر د غوښې خورا مهم توکي ښیې.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // موږ کولی شو د زېرمې اوږدوالی چیک کړو.
/// assert_eq!(heap.len(), 3);
///
/// // موږ کولی شو هغه توکي په زېرمه کې تکرار کړو ، که څه هم دا په تصادفي ترتیب کې بیرته راځي.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // که موږ پرځای دا نمرې پاپ کړو ، دوی باید په ترتیب سره بیرته راشي.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // موږ کولی شو د پاتې توکو توکي پاک کړو.
/// heap.clear();
///
/// // ap The should shouldﺎ... should. empty. و.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// یا هم `std::cmp::Reverse` یا دودیز `Ord` پلي کول د `BinaryHeap` دقیقې نیولو لپاره کارول کیدی شي.
/// دا د `heap.pop()` رامینځته کوي ترټولو لوی ارزښت پرځای کوچنی ارزښت بیرته.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // په `Reverse` کې ارزښتونه نغاړل
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // که موږ دا نمرې اوس پاپ کړو ، نو دوی باید بیرته په ترتیب کې راشي.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # د وخت پیچلتیا
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// د `push` ارزښت متوقع لګښت دی؛د میتود اسناد یو ډیر مفصل تحلیل وړاندې کوي.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// جوړښت په `BinaryHeap` کې ترټولو لوی توکي ته د تغیر وړ حوالې ریپ کول.
///
///
/// دا `struct` په [`BinaryHeap`] کې د [`peek_mut`] میتود لخوا رامینځته شوی.
/// د نورو لپاره د دې اسناد وګورئ.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // خوندي: PeekMut یوازې د غیر خالي هګیو لپاره انسټینټ کیږي.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // خوندي: پیک مکټ یوازې د غیر خالي هګیو لپاره انسټینټید شوی دی
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // خوندي: پیک مکټ یوازې د غیر خالي هګیو لپاره انسټینټید شوی دی
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// ټوټې شوي ارزښت له غوټۍ لرې کوي او بیرته یې ورکوي.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// یو خالي `BinaryHeap<T>` رامینځته کوي.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// خالي `BinaryHeap` د اعظمي هپ په توګه رامینځته کوي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// د ځانګړي ظرفیت سره خالي `BinaryHeap` رامینځته کوي.
    /// دا د `capacity` عناصرو لپاره کافي حافظه وړاندې کوي ، نو د دې لپاره چې `BinaryHeap` بیا اړتیا ونلري تر هغه چې دا لږترلږه ډیری ارزښتونه ولري.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// د بائنري هپ ، یا `None` کې لوی توکي ته د بدلون معقول حواله ورکوي که دا خالي وي.
    ///
    /// Note: که چیرې د `PeekMut` ارزښت لیک شي ، نو ممکن ممکن غیر متضاد حالت کې وي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # د وخت پیچلتیا
    ///
    /// که توکي ترمیم شوي وي نو بیا د ټولو خراب حالت وخت پیچلتیا *O*(log(*n*)) ده ، که نه نو دا *O*(1) دی.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// د بائنري هپ څخه ترټولو لوی توکي لرې کوي او بیرته یې ورکوي ، یا `None` که دا خالي وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # د وخت پیچلتیا
    ///
    /// د x n1 عناصرو لرونکي په یوه برخه کې د `pop` ترټولو خراب حالت قیمت د *O*(log(*n*)) دی.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // خوندي: !self.is_empty() پدې معنی چې self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// یو توکي په دوه لمبر کې فشار اچوي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # د وخت پیچلتیا
    ///
    /// د `push` اټکل شوی لګښت ، د عناصرو د فشار ورکولو له هرې ممکنه حکم په اوسط ډول ، او په کافي اندازه د ډیرو فشارونو څخه ،*O*(1) دی.
    ///
    /// دا ترټولو معنی لرونکی لګښت میټریک دی کله چې عناصر فشار راوړي کوم چې * لا دمخه په کوم ترتیب شوي ب patternه کې ندي.
    ///
    /// د وخت پیچلتیا کمیږي که چیرې عناصر په عمده توګه د ختلو په ترتیب کې فشار واچول شي.
    /// په بدترین حالت کې ، عناصر په ترتیب شوي ترتیب شوي ب pushedه کې فشار اچول کیږي او د هر فشار امورز شوی قیمت د X NX عناصرو لرونکي apګ په مقابل کې *O*(log(*n*)) دی.
    ///
    /// د `push` ته د *واحد* کال خورا خراب قضیه قیمت *O*(*n*) دی.ترټولو خرابه قضیه پیښیږي کله چې ظرفیت له مینځه تللی وي او بیا आकार ته اړتیا وي
    /// د بیا رغونې لګښت په تیرو ارقامو کې تنظیم شوی.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // خوندي: له هغه ځایه چې موږ یو نوی توکی راکړ د دې معنی ده
        //  old_len= self.len() ، 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// د `BinaryHeap` مصرف کوي او په ترتیب شوي (ascending) ترتیب کې vector بیرته ورکوي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // خوندي: `end` له `self.len() - 1` څخه 1 ته ځي (دواړه شامل دي) ،
            //  نو دا د لاسرسي لپاره تل د اعتبار وړ شاخص دی.
            //  دا د شاخص 0 ته لاسرسی خوندي دی (د مثال په توګه `ptr`) ، ځکه چې
            //  1 <=پای <self.len() ، چې د self.len()>=2 معنی لري.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // خوندي: `end` له `self.len() - 1` څخه 1 ته ځي (دواړه شامل دي) نو:
            //  0 <1 <=پای <= self.len() ، 1 <self.len() چې معنی یې 0 <پای او پای <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // د سیفټ_پ او سیفټ_ډین پلي کول غیر محفوظه بلاکونه کاروي ترڅو د یو عنصر له vector څخه بهر شي (د یو سوري شاته پریښودل) ، د نورو سره وګرځئ او لرې شوی عنصر بیرته د سوري په وروستي موقعیت کې vector ته واړوئ.
    //
    // د `Hole` ډول د دې نمایش کولو لپاره کارول کیږي ، او ډاډ ترلاسه کړئ چې سوري د خپلې حوزې په پای کې بیرته ډک شوی ، حتی په panic کې.
    // د سوري کارول د تبادلې کارولو په پرتله دوامداره فاکتور کموي ، کوم چې دوه چنده دوه چنده پکې برخه لري.
    //
    //
    //
    //

    /// # Safety
    ///
    /// زنګ وهونکی باید تضمین وکړي چې `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // په `pos` کې ارزښت واخلئ او یو سوري رامینځته کړئ.
        // خوندي: زنګ وهونکی تضمین کوي چې << self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // خوندي: hole.pos()> پیل>=0 ، کوم چې د hole.pos()> 0 په معنی دی
            //  او نو hole.pos() ، 1 نشي کولی جریان ولري.
            //  دا تضمین کوي چې والدین <hole.pos() نو دا د اعتبار شاخص دی او هم!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // خوندي: د پورتني په څیر
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// په `pos` کې یو عنصر واخلئ او دا له ګرمۍ څخه وباسئ ، پداسې حال کې چې دا ماشومان لوی دي.
    ///
    ///
    /// # Safety
    ///
    /// زنګ وهونکی باید تضمین وکړي چې `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // خوندي: زنګ وهونکی تضمین کوي چې پوز <پای <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // لوپ انارینټ: ماشوم==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // د دوه ماشومانو لوی سره پرتله کړئ د خوندیتوب: ماشوم <پای ، 1 <self.len() او ماشوم + 1 <پای <= self.len() ، نو دا د اعتبار شاخصونه دي.
            //
            //  ماشوم==2 *hole.pos() + 1!= hole.pos() او ماشوم + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 یا 2* hole.pos() + 2 کیدلی شي که T ZST وي
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // که موږ دمخه په ترتیب کې یوو ، نو ودروئ.
            // : child: eitherY::child now either either either either oldړ old child child child or the orﺎ the the the child child child child child child
            //  موږ دمخه ثابته کړې چې دواړه <self.len() او!= hole.pos() دي
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // خوندي: د پورتني په څیر.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // خوندي: &لنډ سرکټ دی ، پدې معنی چې په
        //  دوهم حالت دا دمخه ریښتیا دی چې ماشوم==پای ، 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // خوندي: ماشوم دمخه د اعتبار وړ شاخص او
            //  ماشوم==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// زنګ وهونکی باید تضمین وکړي چې `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // خوندي: پوسټ <لین د تلیفون کونکي لخوا تضمین دی او
        //  په ښکاره ډول لین= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// په `pos` کې یو عنصر واخلئ او دا د ټولې برخې څخه د ڈھیر لاندې حرکت کړئ ، بیا یې خپل موقعیت ته پورته کړئ.
    ///
    ///
    /// Note: دا ګړندی دی کله چې عنصر لوی پیژندل کیږي/باید لاندې ته نږدې وي.
    ///
    /// # Safety
    ///
    /// زنګ وهونکی باید تضمین وکړي چې `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // خوندي: زنګ وهونکی تضمین کوي چې << self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // لوپ انارینټ: ماشوم==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // خوندي: د ماشوم <پای ، 1 <self.len() او
            //  ماشوم + 1 <پای <= self.len() ، نو دا د اعتبار وړ شاخصونه دي.
            //  ماشوم==2 *hole.pos() + 1!= hole.pos() او ماشوم + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 یا 2* hole.pos() + 2 کیدلی شي که T ZST وي
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // خوندي: د پورتني په څیر
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // خوندي: ماشوم==پای ، 1 <self.len() ، نو دا د اعتبار وړ شاخص دی
            //  او ماشوم==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // خوندي: پوز په سوراخ کې موقعیت لري او دمخه ثابت شوی
        //  د اعتبار وړ شاخص به وي.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // خوندي: n د self.len()/2 څخه پیل کیږي او 0 ته ښکته کیږي.
            //  یوازینی قضیه کله چې! (n <self.len()) که self.len() ==0 وي ، مګر دا د لوپ حالت لخوا رد شوی.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// د `other` ټول عناصر په `self` کې حرکت کوي ، د `other` خالي پریښودل.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` په بدترین حالت کې د O(len1 + len2) عملیات او شاوخوا 2 *(len1 + len2) پرتله کوي پداسې حال کې چې `extend` O(len2* log(len1)) عملیات ترسره کوي او په بد حالت کې د 1 *len2* log_2(len1) پرتله کوي ، د len1>= len2 په غاړه اخیستلو سره.
        // د لوی زېرمو لپاره ، د صلیب نقطه نور دا دلیل نه تعقیبوي او په احساساتي ډول ټاکل شوی.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// یو تیریدونکی راستنوي کوم چې د غوړې په ترتیب کې عنصرونه راوباسي.
    /// ترلاسه شوي عناصر د اصلي ګرمۍ څخه لرې شوي.
    /// پاتې عناصر به د ګرمو ترتیباتو په غورځولو سره لرې شي.
    ///
    /// Note:
    /// * `.drain_sorted()` د *O*(*n*\*log(* n*)) دی X د `.drain()` په پرتله خورا ورو دی.
    ///   تاسو باید وروسته د ډیرو قضیو لپاره وکاروئ.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // د عنصر ټول توکي لرې کوي
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// یوازې هغه عناصر ساتي چې د پیشو لخوا مشخص شوي دي.
    ///
    /// په نورو ټکو کې ، ټول عناصر `e` لرې کړئ لکه `f(&e)` `false` بیرته راوړي.
    /// عناصر په ترتیب شوي (او نامعلوم) ترتیب کې لیدنه کیږي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // یوازې حتی شمیرې وساتئ
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// یو تیریدونکی په خپل سر ترتیب vector کې د ټولو ارزښتونو لیدو ته راستنوي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1 ، 2 ، 3 ، 4 پخپل سري ترتیب کې چاپ کړئ
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// یو تیریدونکی راستنوي کوم چې د غوړې په ترتیب کې عنصرونه راوباسي.
    /// دا میتود اصلي غوړ مصرفوي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// په بائنري هیپ کې ترټولو لوی توکي بیرته راوړي ، یا `None` که دا خالي وي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # د وخت پیچلتیا
    ///
    /// لګښت په بد حالت کې *O*(1) دی.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// د عناصرو شمیر بیرته راولي چې بائنری هپ کولی شي له سره له سره محلول شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// په سمه توګه د `additional` نورو عناصرو لپاره لږترلږه ظرفیت زیرمه کړئ ترڅو ورکړل شوي `BinaryHeap` کې دننه شي.
    /// هیڅ نه کوي که چیرې ظرفیت دمخه کافی وي.
    ///
    /// په یاد ولرئ چې تخصیص کونکي ممکن د دې غوښتنې څخه خورا ډیر ځای ورکړي.
    /// نو له دې امله ظرفیت دقیقا دقیقیت باندې تکیه نشي کیدلی.
    /// [`reserve`] ته ترجیح ورکړئ که چیرې د future زیاتوالي تمه کیږي.
    ///
    /// # Panics
    ///
    /// Panics که نوی ظرفیت له `usize` ډیر شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// په `BinaryHeap` کې د اضافه کیدو لپاره لږترلږه `additional` نورو عناصرو لپاره ظرفیت خوندي کوي.
    /// راټولول ممکن د پرله پسې بیاکتنې مخه نیولو لپاره ډیر ځای خوندي کړي.
    ///
    /// # Panics
    ///
    /// Panics که نوی ظرفیت له `usize` ډیر شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// د امکان تر حده اضافي ظرفیت ضایع کول.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// د ټیټ حد سره ظرفیت ضایع کوي.
    ///
    /// ظرفیت به لږترلږه دومره لوی وي لکه دواړه د عرض او ورکړل شوي ارزښت.
    ///
    ///
    /// که چیرې اوسنی ظرفیت د ټیټ حد څخه لږ وي ، نو دا انتخاب ندي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// د `BinaryHeap` مصرفوي او په خپل مینځ ترتیب کې اصلي vector بیرته راستنوي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // په یو ترتیب به چاپ کړي
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// د بائنری هپ اوږدوالی راولی.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// چیک کوي چې ایا د بائنری زنګونه خالي دي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// د بائنري هپ پاکوي ، د حذف شوي عناصرو څخه تکرار بیرته راستنوي.
    ///
    /// عناصر په خپل سري ترتیب کې له مینځه وړل کیږي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ټول توکي د بائنري هپ څخه وغورځوئ.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// هول په سلیس کې سوري استازیتوب کوي د بیلګې په توګه ، د اعتبار ارزښت پرته یو شاخص (ځکه چې دا لیږدول شوی یا ورته ورته شوی).
///
/// په ډراپ کې ، `Hole` به د سوري موقعیت ډکولو سره سلیس د هغه ارزښت سره ډک کړي چې په اصل کې لرې شوی و.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// په شاخص `pos` کې نوی `Hole` جوړ کړئ.
    ///
    /// غیر محفوظ ځکه چې پوز باید د معلوماتو سلیس کې وي.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // خوندي: پوز باید د سلیس دننه وي
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// لرې شوي عنصر ته حواله ورکوي.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// په `index` کې عنصر ته مراجعه کوي.
    ///
    /// غیر محفوظ ځکه چې شاخص باید د معلوماتو سلیس کې وي او د پوسټ سره مساوي نه وي.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// سوري نوي ځای ته خوځول
    ///
    /// غیر محفوظ ځکه چې شاخص باید د معلوماتو سلیس کې وي او د پوسټ سره مساوي نه وي.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // سوري بیا ډک کړئ
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// د `BinaryHeap` عناصرو باندې تکرارونکی.
///
/// دا `struct` د [`BinaryHeap::iter()`] لخوا رامینځته شوی.
/// د نورو لپاره د دې اسناد وګورئ.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) د `#[derive(Clone)]` په ګټه لرې کړئ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// د `BinaryHeap` عناصر باندې د ملکیت لرونکی.
///
/// دا `struct` د [`BinaryHeap::into_iter()`] لخوا رامینځته شوی (د `IntoIterator` trait لخوا چمتو شوی).
/// د نورو لپاره د دې اسناد وګورئ.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// د `BinaryHeap` د عناصرو په اساس د اوبو ایریټریټر.
///
/// دا `struct` د [`BinaryHeap::drain()`] لخوا رامینځته شوی.
/// د نورو لپاره د دې اسناد وګورئ.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// د `BinaryHeap` د عناصرو په اساس د اوبو ایریټریټر.
///
/// دا `struct` د [`BinaryHeap::drain_sorted()`] لخوا رامینځته شوی.
/// د نورو لپاره د دې اسناد وګورئ.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// د ګ orderې په ترتیب کې د عنصر عنصرونه لرې کوي.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` په `BinaryHeap<T>` بدلوي.
    ///
    /// دا تبادله په ځای کې پیښیږي ، او د *O*(*n*) وخت پیچلتیا لري.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` په `Vec<T>` بدلوي.
    ///
    /// دا تبادله هیڅ ډاټا حرکت یا تخصیص ته اړتیا نلري ، او د دوامداره وخت پیچلتیا لري.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// مصرف کونکي تیریټر رامینځته کوي ، دا هغه یو دی چې هر ارزښت په منطقه ترتیب کې د دوه لمبر څخه بهر حرکت کوي.
    /// د دې غږ کولو وروسته دوه لمریزې ګانې نشي کارول کیدی.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1 ، 2 ، 3 ، 4 پخپل سري ترتیب کې چاپ کړئ
    /// for x in heap.into_iter() {
    ///     // x ډول i32 لري ، نه &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}