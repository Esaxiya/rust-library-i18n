use core::intrinsics;
use core::mem;
use core::ptr;

/// دا د اړونده فنکشن په زنګ وهلو سره د `v` ځانګړي حوالې تر شا ارزښت بدلوي.
///
///
/// که چیرې panic د `change` بند کې واقع شي ، نو ټوله پروسه به بنده شي.
#[allow(dead_code)] // د توضیحي په توګه وساتئ او د future کارونې لپاره
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// دا د اړونده فنکشن په زنګ وهلو سره د `v` ځانګړي حوالې تر شا ارزښت بدلوي ، او د لارې په اوږدو کې ترلاسه شوې پایله بیرته راستنوي.
///
///
/// که چیرې panic د `change` بند کې واقع شي ، نو ټوله پروسه به بنده شي.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}