use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// د دوه خروج تیریدونکو اتحاد څخه ټول د کیلي ارزښت جوړه جوړه کوي ، د لارې په اوږدو کې د `length` متغیره ډیروي.وروستی د زنګ وهونکي لپاره دا اسانه کوي چې د لیک مخنیوی وکړي کله چې قطره کونکي مینځته راشي.
    ///
    /// که چیرې دواړه تکرار کونکي ورته کیلي تولید کړي ، دا طریقه جوړه د کی iteې تیریدونکي څخه غورځوي او جوړه د ښي تیریدونکي څخه ضمیمه کوي.
    ///
    /// که تاسو وغواړئ چې ونه په کلکه توګه خروج ترتیب سره پای ته ورسي ، لکه د `BTreeMap` لپاره ، دواړه تکرار کونکي باید په کلکه د خروج ترتیب کې کلي پیدا کړي ، هر یو یې په ونې کې له ټولو کلیدونو څخه لوی دی ، پداسې حال کې چې د ننوتلو په وخت کې په کلي کې کلیدونه شامل دي.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // موږ چمتو کوو چې `left` او `right` په ترتیب شوي وخت کې ترتیب شوي ترتیب کې ضم کړئ.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // په عین وخت کې ، موږ په خطي وخت کې د ترتیب شوي ترتیب څخه یوه ونه جوړه کوو.
        self.bulk_push(iter, length)
    }

    /// د ونې پای ته ټولې کلیدي ارزښت جوړه جوړه کړه ، د لارې په اوږدو کې د `length` تغیر وده.
    /// وروستی د زنګ وهونکي لپاره دا اسانه کوي چې د لیک مخه ونیسي کله چې تکرار کونکي وخندل.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // د ټولو کلیدي ارزښت جوړو له لارې تکرار کړئ ، دوی په سم سطح کې نوډونو ته اړول.
        for (key, value) in iter {
            // هڅه وکړئ د اوسني پا leafې نوډ ته د کیلي ارزښت ارزښت ورکړئ.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // هیڅ ځای پاتې ندی ، پورته لاړشئ او هلته فشار ورکړئ.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // د پاتې کیدلو سره نوډ وموند ، دلته فشار ورکړئ.
                                open_node = parent;
                                break;
                            } else {
                                // بیا ځه.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // موږ په سر کې یو ، یو نوی ریټ نوډ رامینځته کړئ او هلته مو فشار ورکړئ.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // د کیلي-ارزښت جوړه او نوي ښیې فرعي پش کش کړئ.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // لاندې ښي پا mostې ته لاندې لاړشئ.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // د هر تکرار اوږدوالی زیاتوالی ، ترڅو ډاډ ترلاسه شي چې نقشه ضمیمه شوي عناصر راټیټوي حتی که چیرې د تکرار کونکي حرکت وکړي.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// په یو ډول د دوه ترتیب شوي ترتیبونو د یوځای کولو لپاره تکرارونکی
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// که دوه کیلي مساوي وي ، د سمې سرچینې څخه د کیلي ارزښت جوړه بیرته راولي.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}