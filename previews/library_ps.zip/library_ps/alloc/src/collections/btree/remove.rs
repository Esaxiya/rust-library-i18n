use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// د ونې څخه د کلیدي ارزښت جوړه لرې کوي ، او دا جوړه بیرته راولي ، په بیله بیا پا theه edge د پخوانۍ جوړه سره ورته.
    /// دا امکان لري چې دا د ریښی نوډ خالي کړي چې داخلي وي ، کوم چې زنګ وهونکی باید د نقشه څخه ونې ته وخیژي.
    /// زنګ وهونکی هم باید د نقشې اوږدوالی کم کړي.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // موږ باید په لنډ وخت کې د ماشوم ډول هیر کړو ، ځکه چې د پا ofو سمدستي مور او پلار لپاره هیڅ ډول نوډ ډول شتون نلري.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // خوندي: `new_pos` هغه پا leafه ده چې موږ له هغه څخه پیل کړی یا یو ورو .ه.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // یوازې که چیرې موږ یوځای شو ، والدین (که کوم یو) غوړ شوی وي ، مګر د لاندې مرحلې پرېښودل نور نو په معیارونو کې تادیه نه کوي.
            //
            // خوندي: موږ به پا destroyه له لاسه ورنکړو او تنظیم یې نکړو چیرته چې `pos` وي
            // د دې والدین په مکرر ډول اداره کولو سره lingپه بدترین ډول به موږ د مور او پلار له لارې مور او پلار له مینځه ویسي یا تنظیم کړئ ، پدې توګه د پا insideې دننه مور او پلار سره لینک بدل کړئ.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // د دې پا leafې سره یوځای کیی لرې کړئ او بیا یې د عنصر ځای کې ځای په ځای کړئ چې له موږ څخه د لرې کولو غوښتنه شوې.
        //
        // په `choose_parent_kv` کې لست شوي دلایلو لپاره کی adj اړخ ته نږدې KV غوره کړئ.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // داخلي نوډ ممکن غلا شوی یا ترکیب شوی وي.
        // ښی لاستی ته لاړشئ ترڅو ومومئ چیرې چې اصلي KV پای ته رسیدلی.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}