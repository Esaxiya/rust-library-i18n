// دا د تطبیق یوه هڅه ده چې د ایډیال تعقیب شي
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// څنګه چې Rust په حقیقت کې انحصار ډولونه او پولیمورفیک تکرار نلري ، نو موږ د ډیری بې باورۍ سره ترسره کوو.
//

// د دې ماډل لوی هدف دا دی چې د ونې درملنې (د عجیب ډول سره ب)ه شوي) کانټینر په توګه د ونې درملنه او د B-Tree برید کونکو ډیری سره معامله کولو څخه ډډه کول د پیچلتیا څخه مخنیوی وشي.
//
// د ورته په څیر ، دا ماډل پروا نلري چې ایا ننوتنې ترتیب شوي وي ، کوم نوډونه لاندې کیدی شي ، یا حتی د ځمکې لاندې معنی څه ده.په هرصورت ، موږ په یو څو بریدګرو تکیه کوو:
//
// - ونې باید یوشان depth/height ولري.دا پدې مانا ده چې هره لاره د ورکړل شوي نوډ څخه پا leafو ته ښکته ورته اوږدوالي لري.
// - د `n` اوږدوالي نوډ د `n` کیلي ، `n` ارزښتونه ، او `n + 1` څنډې لري.
//   دا پدې معنی ده چې حتی یو خالي نوډ لږترلږه یو edge لري.
//   د پا leafی نوډ لپاره ، "having an edge" یوازې پدې معنی دی چې موږ کولی شو نوډ کې موقعیت وپیژنو ، ځکه چې د پا leafو څنډې خالي دي او د معلوماتو نمایندګۍ ته اړتیا نلري.
// په داخلي نوډ کې ، edge دواړه یو موقعیت په ګوته کوي او د ماشوم نوډ ته یو نښې لري.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// د پا leafو نوډونو اصلي نمایندګۍ او د داخلي نوډونو نمایندګي برخه.
struct LeafNode<K, V> {
    /// موږ غواړو په `K` او `V` کې همپالنه اوسو.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// د اصلي نوډ د `edges` صفونو کې د دې نوډ شاخص.
    /// `*node.parent.edges[node.parent_idx]` باید د `node` په څیر ورته شی وي.
    /// دا یوازې د پیل کیدو تضمین دی کله چې `parent` غیر خالي وي.
    parent_idx: MaybeUninit<u16>,

    /// د دې نوډ پلورنځیو کې د کیلو او ارزښتونو شمیر.
    len: u16,

    /// سري د نوډ اصلي ډاټا ذخیره کوي.
    /// یوازې د هر صف لومړني `len` عناصر پیل او معتبر دي.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// په ځای کې نوی `LeafNode` پیلوي.
    unsafe fn init(this: *mut Self) {
        // د عمومي پالیسۍ په توګه ، موږ ساحې بې بنسټه پریږدو که چیرې دوی کیدی شي ، ځکه چې دا باید په Valgrind کې د تعقیب کولو لپاره یو څه ګړندي او اسانه وي.
        //
        unsafe {
            // اصلي_وینډیکس ، کیګانې او والونه ټول ممکن یوټیوب شي
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// نوی بکس شوی `LeafNode` رامینځته کوي.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// د داخلي نوډونو اساس نمایش.لکه څنګه چې د `LeafNode`s سره ، دا باید د`BoxedNode`s شاته پټول شي ترڅو د نه منل شوي کیلي او ارزښتونو له لاسه ورکولو مخه ونیسي.
/// هر ایکس ایکس ایکس ایکس ایکس ته د نوډ لاندې `LeafNode` برخې ته نښې ته مستقیم کاسټ کیدی شي ، کوډ ته اجازه ورکوي چې په پا andو او داخلي نوډونو کې په عمودي ډول عمل وکړي پرته لدې چې چیک کړئ چې کوم دوه نښې په نښه کوي.
///
/// دا ملکیت د `repr(C)` کارولو سره فعال شوی.
///
#[repr(C)]
// gdb_providers.py د ځان پېژندنې لپاره دا ډول نوم کاروي.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// د دې نوډ ماشومانو ته نښې.
    /// `len + 1` له دې څخه ابتدايي او معتبره ګ areل کیږي ، پرته لدې چې پای ته نږدې ، پداسې حال کې چې ونه د `Dying` پور پور له لارې ساتل کیږي ، له دې څخه ځینې نښې په جریان کې دي.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// نوی بکس شوی `InternalNode` رامینځته کوي.
    ///
    /// # Safety
    /// د داخلي نوډونو یو انارینټ دا دی چې دوی لږترلږه یو پیل شوی او معتبر edge ولري.
    /// دا فنکشن د داسې edge تنظیم نه کوي.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // موږ یوازې د معلوماتو لومړني کولو ته اړتیا لرو؛څنډې کیدای شي یونټ.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// یو نوډ ته مدیریت شوی ، غیر خالي نقطه.دا یا `LeafNode<K, V>` ته د ملکیت نښه وي یا `InternalNode<K, V>` ته د ملکیت نښه وي.
///
/// په هرصورت ، `BoxedNode` هیڅ معلومات نلري پدې اړه چې دا په حقیقت کې کوم دوه ډوله نوډونه لري ، او ، د معلوماتو د دې نشتوالي له امله یو جلا ډول ندی او هیڅ تخریب کونکی نلري.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// د ملکیت لرونکي ونې ریښه نوډ.
///
/// په یاد ولرئ چې دا تخریب کونکی نلري ، او باید په لاسي ډول پاک شي.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// نوی ملکیت لرونکی ونې راستنوي ، د هغې د خپل ریښې نوډ سره چې په پیل کې خالي وي.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` باید صفر نه وي.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// په متناسب ډول د ملکیت ریښه نوډ پور اخلي.
    /// د `reborrow_mut` په خلاف ، دا خوندي دی ځکه چې د راستنیدو ارزښت نشي کولی د ریښې له مینځه وړلو لپاره وکارول شي ، او په ونه کې نور حوالې شتون نلري.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// یو څه په متناسب ډول د ملکیت ریښه نوډ پور اخلي.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// په مکرر ډول هغه حوالې ته لیږدول چې د تګ مخه ونیسي او ویجاړونکي میتودونه وړاندې کوي او نور لږ څه.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// یو نوی داخلي نوډ اضافه کړئ د یو واحد edge سره چې پخوانۍ ریښې نوډ ته په ګوته کوي ، دا نوی نوډ د ریښې نوډ رامینځته کړئ ، او بیرته یې راستون کړئ.
    /// دا د 1 لخوا لوړوالی ډیروي او د `pop_internal_level` برعکس دی.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, پرته لدې چې موږ یوازې هیر کړی چې موږ اوس داخلي یو
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// داخلي ریښه نوډ لرې کوي ، د لومړي ریټ نوډ په توګه د هغې لومړی ماشوم کاروي.
    /// لکه څنګه چې دا یوازې ویل کیږي کله چې د ریښی نوډ یوازې یو ماشوم ولري ، نو په کوم کلي ، ارزښتونو او نورو ماشومانو هیڅ ډول پاکول نه کیږي.
    ///
    /// دا د 1 لخوا لوړوالی کموي او د `push_internal_level` مخالف دی.
    ///
    /// د `Root` څیز ته ځانګړي لاسرسي ته اړتیا لري مګر نه روټ نوډ ته؛
    /// دا به نور لاسونه یا د ریښی نوډ ته مآخذونه باطله نه کړي.
    ///
    /// Panics که چیرې داخلي کچه شتون ونلري ، د بیلګې په توګه ، که د ریښی نوډ پا leafه وي.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // : SA asYY: as as as. we.. internal.. be.. internal internal internal. be be.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // امنیت: موږ `self` په ځانګړي ډول پور اخیستی او د دې پور نوع خاص دی.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // خوندي: لومړی edge تل پیل شوی.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` تل په `K` او `V` کې همیشه وي ، حتی کله چې `BorrowType` `Mut` وي.
// دا تخنیکي پلوه غلط دی ، مګر د `NodeRef` د داخلي کارونې له امله هیڅ ډول بې پایلې نشي رامینځته کیدی ځکه چې موږ د `K` او `V` څخه په بشپړ ډول جنرالي پاتې شو.
//
// په هرصورت ، هرکله چې یو عامه ډول `NodeRef` وتړي ، ډاډ ترلاسه کړئ چې دا درست توپیر لري.
//
/// نوډ ته اشاره.
///
/// دا ډول یو شمیر پیرامیټرې لري چې دا کنټرولوي چې دا څنګه عمل کوي:
/// - `BorrowType`: یو پیچلی ډول چې د پور ډول بیانوي او د ژوند په اوږدو کې.
///    - کله چې دا `Immut<'a>` وي ، نو `NodeRef` د `&'a Node` په څیر عمل کوي.
///    - کله چې دا `ValMut<'a>` وي ، نو `NodeRef` د `&'a Node` په څیر د کلیدونو او ونو جوړښت ته په پام سره عمل کوي ، مګر د ونې په اوږدو کې ډیری بدلونونو ته اجازه ورکوي چې یوځای شي.
///    - کله چې دا `Mut<'a>` وي ، نو `NodeRef` د `&'a mut Node` په څیر عمل کوي ، که څه هم د داخلولو میتودونه د تبادلې تبادلې ارزښت ته د وتلو اجازه ورکوي.
///    - کله چې دا `Owned` وي ، `NodeRef` د `Box<Node>` په څیر عمل کوي ، مګر ویجاړونکی نلري ، او باید په لاسي ډول پاک شي.
///    - کله چې دا `Dying` وي ، نو `NodeRef` لاهم د `Box<Node>` په څیر عمل کوي ، مګر میتودونه لري چې یو څه په واسطه ونې له مینځه یوسي ، او عادي میتودونه ، پداسې حال کې چې د زنګ وهلو لپاره خوندي نه پیژندل شوي ، کولی شي UB وغواړي که چیرې په غلط ډول وبلل شي.
///
///   لدې چې هر `NodeRef` د ونې له لارې تګ راتګ ته اجازه ورکوي ، `BorrowType` په مؤثره توګه په ټوله ونه کې پلي کیږي ، نه یوازې پخپله نوډ ته.
/// - `K` او `V`: دا د ت keysیو او ارزښتونو ډولونه دي چې په نوډونو کې زیرمه شوي.
/// - `Type`: دا کیدی شي `Leaf` ، `Internal` ، یا `LeafOrInternal`.
/// کله چې دا `Leaf` وي ، نو `NodeRef` پا leafې نوډ ته ګوته کوي ، کله چې دا `Internal` وي نو `NodeRef` داخلي نوډ ته ګوته کوي ، او کله چې دا `LeafOrInternal` وي نو `NodeRef` دواړه نوډونو ته ګوته نیسي.
///   `Type` د `NodeType` نوم دی کله چې د `NodeRef` څخه بهر کارول کیږي.
///
/// دواړه د `BorrowType` او `NodeType` محدود کړي چې کوم میتودونه پلي کوو ، د جامد ډول خوندیتوب ګټې اخیستنې لپاره.په لاره کې محدودیتونه شتون لري چې موږ کولی شو دا ډول محدودیتونه پلي کړو:
/// - د هر ډول پیرامیټر لپاره ، موږ یوازې یا یوازې په ساده ډول یا یو ځانګړي ډول لپاره میتود تعریف کولی شو.
/// د مثال په توګه ، موږ نشو کولی د `into_kv` په څیر میتود د ټولو `BorrowType` لپاره په عمومي ډول تعریف کړو ، یا یوځل د ټولو ډولونو لپاره چې ټول عمر تیروي ، ځکه چې موږ غواړو دا د `&'a` حوالې بیرته راوړو.
///   نو ځکه ، موږ دا یوازې د لږترلږه قوي ډول `Immut<'a>` لپاره تعریف کوو.
/// - موږ نشو کولی د `Mut<'a>` څخه `Immut<'a>` ته ضمیمه جبر ترلاسه کړو.
///   نو ځکه ، موږ باید په څرګنده د `reborrow` په ډیر ځواکمن `NodeRef` تلیفون وکړو ترڅو د `into_kv` په څیر میتود ته رسیدو لپاره.
///
/// په `NodeRef` ټول میتودونه چې یو ډول حواله بیرته راولي ، نو:
/// - د ارزښت له مخې `self` واخلئ ، او د `BorrowType` لخوا ترسره شوي ژوند ته راستون شئ.
///   ځینې وختونه ، د داسې میتود غوښتنه کولو لپاره ، موږ اړتیا لرو چې `reborrow_mut` تلیفون وکړو.
/// - د حوالې په واسطه `self` واخلئ ، او (implicitly) د حوالې ژوند بیرته راستانه کړئ ، د هغه ژوند پرځای چې د `BorrowType` لخوا پرمخ وړل شوی.
/// په دې توګه ، د پور چیکر تضمین کوي چې `NodeRef` پور پاتې وي تر هغه چې بیرته راستنیدونکی حواله کارول کیږي.
///   هغه میتودونه چې د داخل کولو ملاتړ کوي دا قانون د خام پوائنټر بیرته راستنولو سره ماته کوي ، د بیلګې په توګه ، پرته له کوم ژوند څخه حواله.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// د کچې شمیره چې نوډ او د پا levelو کچه سره جلا دي ، د نوډ یو ثابت چې د `Type` لخوا په بشپړ ډول توضیح کیدی نشي ، او دا چې نوډ پخپله نه ساتي.
    /// موږ یوازې دې ته اړتیا لرو چې د ریډ نوډ لوړوالی ذخیره کړو ، او له هغې څخه د نورو هر نوډ لوړوالی واخلو.
    /// باید صفر وي که `Type` `Leaf` وي او غیر صفر که `Type` `Internal` وي.
    ///
    ///
    height: usize,
    /// پا leafې یا داخلي نوډ ته نغدي
    /// د `InternalNode` تعریف تعریف کوي چې نښې په هر ډول معتبر دي.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// د نوډ حوالې خلاص کړئ چې د `NodeRef::parent` په توګه بسته شوی و.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// د داخلي نوډ ډاټا افشا کوي.
    ///
    /// دې نوډ ته د نورو مآخذونو باطل کیدو څخه مخنیوی لپاره یو خام ptr راوباسي.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // خوندي: د مستحکم نوډ ډول د `Internal` دی.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// د داخلي نوډ ډیټا ته ځانګړي لاسرسي پور اخلي.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// د نوډ اوږدوالی لټوي.دا د کیلي یا ارزښتونو شمیر دی.
    /// د څنډو شمیره `len() + 1` ده.
    /// په یاد ولرئ ، د خوندي کیدو سره سره ، د دې فنلندي کول کولی شي د ناقانونه بدلیدونکي مراجعونو ضمني اغیز ولري چې غیر محفوظ کوډ رامینځته کړی.
    ///
    pub fn len(&self) -> usize {
        // په جدي ډول ، موږ یوازې دلته د `len` ساحې ته لاسرسی لرو.
        // که چیرې پورټایپ marker::ValMut وي ، نو ممکن ارزښتونو ته خورا بدلیدونکي بدلونونه شتون ولري چې موږ یې باید باطله نه کړو.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// د کچې شمیره راوباسي چې نوډ او پا leavesې یو له بل سره جلا وي.
    /// د صفر قد مطلب دا دی چې نوډ پخپله پا leafه ده.
    /// که تاسو ونې د ریښې سره په پورتنۍ برخه کې انځور کړئ ، نو شمیره وایی چې په کوم لوړوالی کې نوډ څرګندیږي.
    /// که تاسو ونې د پا leavesو سره په پورتنۍ برخه کې انځور کړئ ، نو شمیره به دا وایې چې ونې د نوډ څخه پورته څومره لوړ دي.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// په عارضي ډول ورته نوډ ته بل ، ناقانونه حواله اخلي.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// د هرې پا leafې یا داخلي نوډ پا theو برخه توضیح کوي.
    ///
    /// دې نوډ ته د نورو مآخذونو باطل کیدو څخه مخنیوی لپاره یو خام ptr راوباسي.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // نوډ باید لږترلږه د پاfی نوډ برخې لپاره معتبر وي.
        // دا د نوډ ریف ډول کې حواله نده ځکه چې موږ نه پوهیږو چې دا باید ځانګړی وي یا شریک شي.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// د اوسني نوډ والدین لټوي.
    /// `Ok(handle)` راستنوي که چیرې موجوده نوډ واقعیا یو مور ولري ، چیرې چې `handle` د والدین edge ته اشاره کوي چې اوسني نوډ ته په ګوته کوي.
    ///
    /// `Err(self)` راستنوي که چیرې اوسني نوډ والدین ونه لري ، اصلي `NodeRef` بیرته ورکوي.
    ///
    /// د میتود نوم ستاسو په غاړه د ونې عکس په غاړه اخلي.
    ///
    /// `edge.descend().ascend().unwrap()` او `node.ascend().unwrap().descend()` دواړه باید ، په بریا سره ، هیڅ هم ونه کړي.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // موږ نوډونو ته د خام نښې کارولو ته اړتیا لرو ځکه چې ، که بورینټایپ marker::ValMut وي ، نو ممکن ارزښتونو ته خورا بدلیدونکي بدلونونه شتون ولري چې موږ یې باید باطله نه کړو.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// په یاد ولرئ چې `self` باید هیڅ نه وي.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// په یاد ولرئ چې `self` باید هیڅ نه وي.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// په غیر منقسم ونه کې د هرې پا portionې یا داخلي نوډ پا theو برخه توضیح کوي.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // امنیت: د `Immut` په نوم پور اخیستل شوي دې ونې کې هیڅ بدلیدونکي مراجع نشي کیدلی.
        unsafe { &*ptr }
    }

    /// په نوډ کې زیرمو کیلي ګانو ته کتنه اخلي.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// د `ascend` سره ورته ، د نوډ والدین نوډ ته مراجعه کوي ، مګر په پروسه کې اوسني نوډ هم ضعیف کوي.
    /// دا غیر محفوظ دی ځکه چې اوسني نوډ به د تخریب کیدو سره سره لاهم د لاسرسي وړ وي.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// په خوندي ډول تثبیت کونکي مرتب معلومات ته تاکید کوي چې دا نوډ د `Leaf` دی.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// په خوندي ډول تثبیت کونکي مرتب معلومات ته تاکید کوي چې دا نوډ د `Internal` دی.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// په عارضي ډول ورته نوډ ته بل ، متغیر حواله اخلي.خبر اوسئ ، ځکه چې دا طریقه خورا خطرناکه ده ، دوه ځله نو ځکه چې دا سمدلاسه خطرناک نه ښکاري.
    ///
    /// ځکه چې بدلون موندونکي نښې کولی شي د ونې په شاوخوا کې چیرته وګرځي ، بیرته راغلی پوینټر په اسانۍ سره د اصلي پوائنټر ځړلو لپاره کارول کیدی شي ، حدود څخه بهر ، یا د پور شوي قواعدو سره سم ناباوره.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) په `NodeRef` کې د بل ډول پیرامیټر اضافه کول په پام کې ونیسئ چې په کارډیدونکي نښو کې د نیویګیشن میتودونو کارول محدودوي ، د دې بې پروایی مخه نیسي.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// د هرې پا leafې یا داخلي نوډ پا theو برخې ته ځانګړې لاسرسي پور اخلي.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // خوندي: موږ ټول نوډ ته ځانګړي لاسرسی لرو.
        unsafe { &mut *ptr }
    }

    /// د هرې پا leafې یا داخلي نوډ پا theو برخې ته ځانګړي لاسرسي وړاندیز کوي.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // خوندي: موږ ټول نوډ ته ځانګړي لاسرسی لرو.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// د کیلي ذخیره کولو ساحې عنصر ته ځانګړي لاسرسي پور لري.
    ///
    /// # Safety
    /// `index` د 0..CAPACITY حدود کې دی
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // خوندي: زنګ وهونکی به نشي کولی په ځان باندې نور میتودونه زنګ ووهي
        // ترهغې پورې چې د کلی سلیس حوالې لرې شي ، ځکه چې موږ د پور په جریان کې ځانګړي لاسرسی لرو.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// د نوډ د ارزښت ذخیره کولو ساحې ته عنصر یا ټوټې ته ځانګړي لاسرسي پور اخلي.
    ///
    /// # Safety
    /// `index` د 0..CAPACITY حدود کې دی
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // خوندي: زنګ وهونکی به نشي کولی په ځان باندې نور میتودونه زنګ ووهي
        // ترهغې چې د ارزښت ټوټې حواله پرېښودل شي ، ځکه چې موږ د پور په جریان کې ځانګړي لاسرسی لرو.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// د edge مینځپانګې لپاره د نوډ د ذخیره کولو ساحې ته عنصر یا سلیس ته ځانګړي لاسرسي پور اخلي.
    ///
    /// # Safety
    /// `index` د 0..CAPACITY + 1 په حدود کې دی
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // خوندي: زنګ وهونکی به نشي کولی په ځان باندې نور میتودونه زنګ ووهي
        // تر هغه وخته چې د edge سلیز حواله پریږدو ، ځکه چې موږ د پور اخیستونکي ژوندانه لپاره ځانګړي لاسرسی لرو.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - نوډ د `idx` څخه ډیر پیل شوي عنصر لري.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // موږ یوازې هغه یو عنصر ته مراجعه کوو چې موږ یې لیوالتیا لرو ، ترڅو نورو عناصرو ته د عالي حواله ورکولو سره د علیز کولو مخه ونیسو ، په ځانګړي توګه هغه کسان چې په تیرو تکرارونو کې زنګ وهونکي ته بیرته راستانه شوي.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // موږ باید د Rust د مسلې #74679 له امله غیر منل شوي صفونو نښو ته مجبور کړو.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// د نوډ اوږدوالي ته ځانګړې لاسرسي پور اخلي.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// د نوډ اړیکې خپل اصلي edge ته وټاکي ، پرته له دې چې نوډ ته نور حوالې باطلې کړي.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// د دې پلر edge ته د ریښې لینک پاکوي.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// د نوډ پای کې د کلیدي ارزښت جوړه اضافه کوي.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// د `range` لخوا بیرته راستنیدونکي هر توکی د نوډ لپاره د اعتبار وړ edge شاخص دی.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// د کیډ ارزښت ارزښت ، او د edge اضافه کوي ترڅو د دې جوړه ښي لور ته ، د نوډ پای ته لاړ شي.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ګوري چې ایا نوډ د `Internal` نوډ دی یا `Leaf` نوډ.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// د نوډ دننه د ځانګړي کیلي-ارزښت جوړه یا edge ته مراجعه.
/// د `Node` پیرامیټر باید `NodeRef` وي ، پداسې حال کې چې `Type` کیدی شي `KV` وي (د کیلي-ارزښت جوړه کې یو لاسي نښه کوي) یا `Edge` (په edge کې د لاستی نښه کول).
///
/// په یاد ولرئ چې حتی د `Leaf` نوډونه کولی شي `Edge` لاستي ولري.
/// د ماشوم نوډ ته د نښې ښودلو پرځای ، دا هغه ځایونه استازیتوب کوي چیرې چې د ماشومانو نښې به د کلیدي ارزښت جوړو تر مینځ ځي.
/// د مثال په توګه ، په نوډ کې د 2 اوږدوالی سره ، به د 3 ممکن edge موقعیتونه وي ، یو د نوډ کی the اړخ ته ، یو د دوه جوړو ترمینځ ، او یو د نوډ په ښي کې.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// موږ د `#[derive(Clone)]` بشپړ عموميیت ته اړتیا نلرو ، ځکه چې یوازینی وخت `Node` به وي `کلوناییبل هغه وخت وي کله چې دا غیر متمرکز حواله وي او له همدې امله `Copy` دی.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// نوډ ترلاسه کوي چې د edge یا د کیلي ارزښت ارزښت جوړه لري چې دا هینډل په ګوته کوي.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// په نوډ کې د دې هینډل حیثیت راستنوي.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// په `node` کې د کلیدي ارزښت جوړې ته نوی هینډل رامینځته کوي.
    /// غیر محفوظ ځکه چې زنګ وهونکی باید ډاډ ترلاسه کړي چې `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// د پارټ ایق عامه پلي کیدلی شي ، مګر یوازې په دې موډل کې کارول شوی.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// په عارضي ډول په عین موقعیت کې یو بل ، نه بدلیدونکی لاستی لرې کوي.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // موږ نشو کولی Handle::new_kv یا Handle::new_edge ځکه چې موږ خپل ډول نه پوهیږو
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// په خوندي ډول تثبیت شوي جامع معلومات ته تاکید کوي چې د هینڈل نوډ د `Leaf` دی.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// په عارضي ډول په ورته موقعیت کې یو بل ، د بدلون وړ لاسي کار اخلي.
    /// خبر اوسئ ، ځکه چې دا طریقه خورا خطرناکه ده ، دوه ځله نو ځکه چې دا سمدلاسه خطرناک نه ښکاري.
    ///
    ///
    /// د نورو معلوماتو لپاره ، `NodeRef::reborrow_mut` وګورئ.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // موږ نشو کولی Handle::new_kv یا Handle::new_edge ځکه چې موږ خپل ډول نه پوهیږو
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// په `node` کې edge ته نوی لاستی جوړوي.
    /// غیر محفوظ ځکه چې زنګ وهونکی باید ډاډ ترلاسه کړي چې `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// د edge شاخص ورکړل شوی چیرې چې موږ غواړو د ظرفیت څخه ډکو نوډ ته دننه کړو ، د ویشلو ځای د پوهې وړ KV شاخص پرتله کوو او چیرې چې داخل کول ترسره کوو.
///
/// د تقسیم کولو نقطه هدف د دې کلیدي او ارزښت لپاره دی چې په اصلي مورد کې پای ته ورسي؛
/// کيلي ، ارزښتونه او څنډې د تقسيمي نقطې کي left اړخ ته کي child ماشوم پاتې کيږي.
/// کليزې ، ارزښتونه او څنډې د تقسيمي نقطې ښي خوا ته سم ماشوم شي.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // د Rust مسله #74834 د دې سمبوليکي قواعدو تشریح کولو هڅه کوي.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// د دې edge ښیې او کی to ته د کلیدي ارزښت جوړه تر مینځ نوی د کلیدي ارزښت جوړه جوړه کړئ.
    /// دا میتود فرض کوي چې د نوي جوړه کولو لپاره په نوډ کې کافي ځای شتون لري.
    ///
    /// راستنیدونکی نښې ورکړل شوي ارزښت ته ګوته نیسي.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// د دې edge ښیې او کی to ته د کلیدي ارزښت جوړه تر مینځ نوی د کلیدي ارزښت جوړه جوړه کړئ.
    /// دا میتود نوډ ویشلی که چیرې کافي خونه شتون ونلري.
    ///
    /// راستنیدونکی نښې ورکړل شوي ارزښت ته ګوته نیسي.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// د ماشوم نوډ کې اصلي نښې او شاخص اصلاح کوي چې دا edge سره اړیکه لري.
    /// دا ګټور دی کله چې د څنډو ترتیب بدل شوی وي ،
    fn correct_parent_link(self) {
        // نوډ ته د نورو مراجعونو باطلولو پرته بیک پوینټر جوړ کړئ.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// یو نوی کیلي-ارزښت جوړه او یو edge دننه کړئ چې دا به د دې edge او د دې edge ښیې خوا ته د کلیدي ارزښت جوړه تر مینځ د نوې جوړه ښیې لور ته لاړ شي.
    /// دا میتود فرض کوي چې د نوي جوړه کولو لپاره په نوډ کې کافي ځای شتون لري.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// یو نوی کیلي-ارزښت جوړه او یو edge دننه کړئ چې دا به د دې edge او د دې edge ښیې خوا ته د کلیدي ارزښت جوړه تر مینځ د نوې جوړه ښیې لور ته لاړ شي.
    /// دا میتود نوډ ویشلی که چیرې کافي خونه شتون ونلري.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// د دې edge ښیې او کی to ته د کلیدي ارزښت جوړه تر مینځ نوی د کلیدي ارزښت جوړه جوړه کړئ.
    /// دا میتود نوډ سره جلا کوي که چیرې کافي خونه شتون ونلري ، او هڅه کوي چې د جلا برخې برخې په تکراري ډول دننه کړي ، تر هغه چې ریښې ته رسیدلی وي.
    ///
    ///
    /// که بیرته راستانه شوې پایله `Fit` وي ، نو د دې هینډل نوډ کولی شي د دې edge نوډ یا پخوانی وي.
    /// که راستنیدونکی پایله `Split` وي ، نو د `left` ډګر به د ریښې نوډ وي.
    /// راستنیدونکی نښې ورکړل شوي ارزښت ته ګوته نیسي.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// د دې edge لخوا اشاره شوی نوډ ومومئ.
    ///
    /// د میتود نوم ستاسو په غاړه د ونې عکس په غاړه اخلي.
    ///
    /// `edge.descend().ascend().unwrap()` او `node.ascend().unwrap().descend()` دواړه باید ، په بریا سره ، هیڅ هم ونه کړي.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // موږ نوډونو ته د خام نښې کارولو ته اړتیا لرو ځکه چې ، که بورینټایپ marker::ValMut وي ، نو ممکن ارزښتونو ته خورا بدلیدونکي بدلونونه شتون ولري چې موږ یې باید باطله نه کړو.
        // هیڅ اندیښنه شتون نلري د لوړوالي ساحې ته لاسرسی ځکه چې دا ارزښت کاپي شوی.
        // خبرداری ورکړئ ، یوځل چې د نوډ پوائنټر ته درناوی وشي ، موږ د حوالې (Rust مسله #73987) سره څنډو ته لاسرسی کوو او په صف کې یا دننه کوم بل حواله باطله کوو ، کوم چې باید شاوخوا وي.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // موږ نشو کولی جلا کیلي او د ارزښت بیلابیل میتودونه زنګ ووایو ، ځکه چې دوهم ته زنګ وهل د لومړي لخوا راستنیدونکي حواله باطله کوي.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// هغه کیلي او ارزښت بدل کړئ چې KV هینڈل ورته اشاره کوي.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// د پا leafو د معلوماتو په پام کې نیولو سره ، د ځانګړي `NodeType` لپاره د `split` پلي کولو کې مرسته کوي.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// لاندې نوډ په دریو برخو ویشئ:
    ///
    /// - نوډ یوازې د دې لاستی کی left اړخ کې د کیلي ارزښت جوړو لرلو لپاره غوړ شوی.
    /// - د دې هینډل لخوا په ګوته شوي کیلي او ارزښت را ایستل شوی دی.
    /// - د دې لاستی ښیې خوا ته ټولې کلیدي ارزښت جوړه نوي نوي تخصیص شوي نوډ کې اچول کیږي.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// د دې هینډل لخوا اشاره شوي د کلیدي ارزښت جوړه لرې کوي او دا د edge سره بیرته راستنوي چې د کیلي ارزښت جوړه په کې نسکوره شوې.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// لاندې نوډ په دریو برخو ویشئ:
    ///
    /// - نوډ یوازې د دې لاستی کی the اړخ کې د څنډو او کیلي-ارزښت جوړو لرلو لپاره غوړ شوی.
    /// - د دې هینډل لخوا په ګوته شوي کیلي او ارزښت را ایستل شوی دی.
    /// - د دې لاستی ښیې خوا ته ټولې څنډې او د کلیدي ارزښت جوړه نوي نوي ټاکل شوي نوډ ته کیښودل شوې.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// د داخلي کیلي-ارزښت جوړه شاوخوا شاوخوا د توازن عملیاتو ارزولو او ترسره کولو لپاره سیشن وړاندې کوي.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// د ماشوم په توګه د نوډ پورې اړه لرونکی متوازن شرایط غوره کوي ، پدې توګه د KV تر مینځ سمدلاسه کی left اړخ ته او ښیې خوا ته په والدین نوډ کې.
    /// `Err` راستنوي که مور او پلار شتون نلري.
    /// Panics که پلرونه خالي وي.
    ///
    /// کی side اړخ ته ترجیح ورکوي تر څو مطلوب وي که ورکړل شوی نوډ یو څه لاندې لاندې وي ، پدې معنی چې دلته یوازې دا د کی left ورور څخه لږ عنصرونه لري او د ښیې ورور ور څخه که چیرې شتون ولري.
    /// پدې حالت کې ، د کی sي ورور سره یوځای کیدل ګړندي دي ، ځکه چې موږ یوازې د نوډ N عناصر حرکت ته اړتیا لرو ، د دې پرځای چې دوی ښي خوا ته واړوو او په مقابل کې د N عناصرو څخه ډیر حرکت وکړو.
    /// د کی sي ورور څخه غلا کول هم معمولا ګړندۍ دي ، ځکه چې موږ یوازې اړتیا لرو چې د نوډ N عناصر ښي خوا ته واړوو ، د دې په ځای چې لږترلږه د وروibو عناصر کی N اړخ ته واړوئ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// بیرته راګرځي که چیرې ولیدل ممکن وي ، د بیلګې په توګه ، ایا په نوډ کې کافي خونه شتون لري چې د مرکزي KV دواړه سره نږدې ماشومانو نوډونو سره یوځای کړي.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// یوځای کیدل ترسره کوي او یو بند ته اجازه ورکوي چې بیرته راستنیدو پریکړه وکړي.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // امنیت: د نوډونو انډول کیدلو لوړوالی له لوړوالی څخه یو دی
                // د دې edge نوډ ، پدې توګه د صفر څخه پورته ، نو دا داخلي دي.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// د والدین کلیدي ارزښت جوړه او دواړه سره نږدې ماشوم نوډونو ته کی child شوي ماشوم نوډ ته داخلیږي او راټیټ شوي والدین نوډ ته راستنوي.
    ///
    ///
    /// Panics پرته لدې چې موږ `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// د والدین کلیدي ارزښت جوړه او دواړه سره نږدې ماشوم نوډونو ته کی child شوي ماشوم نوډ ته یوځای کوي او د ماشوم نوډ ته راستنوي.
    ///
    ///
    /// Panics پرته لدې چې موږ `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// د والدین کلیدي ارزښت جوړه او دواړه سره نږدې ماشوم نوډونو ته کی the شوي ماشوم نوډ ته یوځای کوي او د edge هینڈل بیرته په هغه ماشوم نوډ کې ځای په ځای کوي چیرې چې تعقیب شوی ماشوم edge پای ته رسیږي ،
    ///
    ///
    /// Panics پرته لدې چې موږ `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// د کی child ماشوم څخه د کلیدي ارزښت جوړه لرې کوي او دا د والدینو کلیدي ارزښت ذخیره کې ځای په ځای کوي ، پداسې حال کې چې زاړه والدین کلیدي ارزښت جوړه په سم ماشوم کې فشاروي.
    ///
    /// په سم ماشوم کې د edge ته یو هینډل بیرته راستنوي چیرې چې د `track_right_edge_idx` لخوا ټاکل شوی اصلي edge پای ته ورسید.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// د ښي ماشوم څخه د کلیدي ارزښت جوړه لرې کوي او دا د والدینو کلیدي ارزښت ذخیره کې ځای په ځای کوي ، پداسې حال کې چې زاړه والدین کلیدي ارزښت جوړه په چپ لور کې فشاروي.
    ///
    /// د `track_left_edge_idx` لخوا مشخص شوي کی child ماشوم کې edge ته یو هینډل بیرته راستنوي ، کوم چې حرکت نه کوي.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// دا د `steal_left` په څیر غلا کوي مګر په یوځل کې ډیری عنصرونه غلا کوي.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ډاډ ترلاسه کړئ چې موږ ممکن په خوندي ډول غلا وکړو.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // د پا leafو ډاټا حرکت کړئ.
            {
                // په سم ماشوم کې د غلا شوي عناصرو لپاره خونه جوړه کړئ.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // عناصر له کی child ماشوم څخه ښیې لور ته واړوئ.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // کی left ترټولو غلا شوې جوړه والدین ته واستوئ.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // د والدینو کلیدي ارزښت جوړه جوړه په سم ماشوم کېږدئ.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // د غلا شویو څنډو لپاره خونه جوړه کړئ.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // څنډې غلا کړئ.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// د `bulk_steal_left` سیمالټ کلون.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ډاډ ترلاسه کړئ چې موږ ممکن په خوندي ډول غلا وکړو.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // د پا leafو ډاټا حرکت کړئ.
            {
                // ښي-خورا غلا شوې جوړه والدین ته واستوئ.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // کی parent ماشوم ته د والدینو کلیدي ارزښت جوړه جوړه کړئ.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // عناصر د ښي ماشوم څخه کی one لور ته واړوئ.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // تشې ډکې کړئ چیرې چې غلا شوي عناصر و.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // څنډې غلا کړئ.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // تشې ډکې کړئ چیرې چې غلا شوي څنډې وې
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// هر ډول جامد معلومات لرې کوي چې دا تثبیتوي چې دا نوډ د `Leaf` نوډ دی.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// هر ډول جامد معلومات لرې کوي چې دا تاکید کوي چې دا نوډ د `Internal` نوډ دی.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// چیک کوي چې ایا اصلي نوډ د `Internal` نوډ دی یا `Leaf` نوډ.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// د `self` وروسته لاستی له یو نوډ څخه بل ته وخوځوئ.`right` باید خالي وي.
    /// د `right` لومړی edge لاهم پاتې دی.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// د اضافه کولو پایله ، کله چې نوډ د خپل ظرفیت څخه هاخوا پراخولو ته اړتیا ولري.
pub struct SplitResult<'a, K, V, NodeType> {
    // په عناصرو او څنډو سره په موجوده ونې کې تذکره بدله شوې چې د `kv` کی the اړخ پورې تړاو لري.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // ځینې کیلي او ارزښت ویشل ، د بل ځای دننه کیدل.
    pub kv: (K, V),
    // ملکیت لرونکی ، نه تړل شوی ، نوی نوډ د عناصرو او څنډو سره چې د `kv` ښیې پورې تړاو لري.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // که چیرې د دې پور نوعې نوډ حوالې په ونې کې نورو نوډونو ته د تلو اجازه ورکړي.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ټراورسل اړتیا نلري ، دا د `borrow_mut` د پایلو په کارولو سره پیښیږي.
        // د ټراورسل معلول کولو سره ، او یوازې ریښو ته نوي حوالې رامینځته کولو سره ، موږ پوهیږو چې د `Owned` ډول هر حواله د ریښی نوډ ته دی.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// د پیل شوي عناصرو ټوټې کې ارزښت داخلوي وروسته د یو ناکراره شوي عنصر لخوا تعقیب کیږي.
///
/// # Safety
/// سلیس له `idx` ډیر عناصر لري.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// د ټولو پیل شوي عناصرو له ټوټې څخه ارزښت لرې کوي او بیرته راګرځوي ، چې د شا تعقیب بې بنسټه عنصر شاته.
///
///
/// # Safety
/// سلیس له `idx` ډیر عناصر لري.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// عناصر په سلایز `distance` پوستونو کې کی to اړخ ته واړوئ.
///
/// # Safety
/// سلیس لږترلږه `distance` عناصر لري.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// عناصر په سلایډ `distance` پوستونو کې ښیې خوا ته واړوئ.
///
/// # Safety
/// سلیس لږترلږه `distance` عناصر لري.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// ټول ارزښتونه د پیل شوي عناصرو له ټوټې څخه بې بنسټه عناصرو سلیس ته لیږدوي ، د `src` شاته پاتې د ټول بې بنسټه.
///
/// د `dst.copy_from_slice(src)` په څیر کار کوي مګر اړتیا نلري `T` د `Copy` وي.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;