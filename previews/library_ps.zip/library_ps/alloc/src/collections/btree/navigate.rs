use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// په عارضي ډول د ورته سلسلې یو بل ، بې عیب مساوي راوړي.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ځانګړې پا edې څنډې وموند چې په ونه کې مشخص شوي حد محدود کوي.
    /// یا یو جوړه مختلف وینډوز په ورته ونې کې یا یوه جوړه خالي انتخابونو ته راستنوي.
    ///
    /// # Safety
    ///
    /// غیر لدې چې `BorrowType` `Immut` وي ، دوه ځله ورته KV لیدلو لپاره د نقل هیډونه ونه کاروئ.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// د `(root1.first_leaf_edge() ، root2.last_leaf_edge())` سره مساوي مګر ډیر اغیزمن.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// د پا leafی څنډو جوړه وموندله کوم چې په ونه کې ځانګړي حد لري.
    ///
    /// پایله یوازې معنی لرونکې ده که چیرې ونې د کیلي لخوا ترتیب شوي وي ، لکه په `BTreeMap` کې ونه.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // : SAFY type: د orrowورو typeورو ډول ut imm .ut... دی.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// د پا edې څنډو جوړه جوړه کړه چې د ټولې ونې ډډ کوي.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// د پا leafې څنډو جوړه کې یو ځانګړی حواله د ځانګړي حد محدودولو لپاره ځانګړي کوي.
    /// پایله غیر غیر معمولي مآخذونه دي چې د (some) تغیراتو ته اجازه ورکوي ، کوم چې باید په دقت سره وکارول شي.
    ///
    /// پایله یوازې معنی لرونکې ده که چیرې ونې د کیلي لخوا ترتیب شوي وي ، لکه په `BTreeMap` کې ونه.
    ///
    ///
    /// # Safety
    /// د ورته KV دوه ځله لیدلو لپاره د نقل لاسونه مه کاروئ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// د پا leafو څنډو ته یوه جوړه ځانګړی حواله تقسیم کړئ د ونې بشپړه لړۍ محدودوي.
    /// پایله غیر غیر معمولي حوالې دي چې بدلون ته اجازه ورکوي (یوازې د ارزښتونو) ، نو باید د پاملرنې سره وکارول شي.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // موږ دلته د ریښې نوډیرف نقل کوو-موږ به هیڅکله هم ورته KV دوه ځله ونه ګورو ، او هیڅکله به د ارزونې ارزښت حوالې سره پای ته ونه رسیږو.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// د پا leafو څنډو ته یوه جوړه ځانګړی حواله تقسیم کړئ د ونې بشپړه لړۍ محدودوي.
    /// پایلې غیر ځانګړې مآخذونه دي چې په پراخه کچه ویجاړونکي بدلون ته اجازه ورکوي ، نو باید د خورا پاملرنې سره وکارول شي.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // موږ دلته د ریښې نوډیرف نقل کوو-موږ به هیڅکله ورته لاسرسی ته لاسرسی ونلرو چې له ریښې څخه ترلاسه شوي مادې له مخې وپیژندل شي.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// د پا leafې edge لاستی ورکول ، [`Result::Ok`] د لاستی سره په ښي خوا کې ګاونډي KV ته بیرته راستنوي ، کوم چې یا په ورته پا leafې نوډ کې دی یا په پلور نوډ کې.
    ///
    /// که پا Zه edge په ونه کې وروستی وي ، نو د ریښي نوډ سره [`Result::Err`] بیرته راشي.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// د پا0ې edge هینډ ورکړئ ، [`Result::Ok`] بیرته د کی handle لاسي ګاونډي KV ته د لاسرسي سره بیرته راستنوي ، کوم چې یا په ورته پا leafې نوډ کې دی یا په پلور نوډ کې.
    ///
    /// که پا Zه edge په ونه کې لومړی یو وي ، د [`Result::Err`] بیرته د ریښې نوډ سره.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// د داخلي edge هینډ ورکړل شوی ، [`Result::Ok`] بیرته د ښیې خوا ته ګاونډي KV ته د لاسرسي سره بیرته راستنوي ، کوم چې یا په ورته داخلي نوډ کې دی یا په پلور نوډ کې.
    ///
    /// که چیرې داخلي edge په ونه کې وروستی وي ، نو د R00 نوډ سره [`Result::Err`] بیرته راشي.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// د پا leafې edge هډل په مړاوي ونې کې ورکړئ ، بله پا Zه edge په ښي اړخ کې بیرته ورکوي ، او په مینځ کې کلیدي ارزښت جوړه ، کوم چې یا په ورته پا leafې نوډ کې وي ، په انډر نوډ کې ، یا غیر موجود نه وي.
    ///
    ///
    /// دا میتود هم هر ډول node(s) ضایع کوي چې دا د پای پای ته رسي.
    /// دا پدې معنی ده چې که چیرې نور د کلي ارزښت ارزښت جوړه شتون ونلري ، نو د ونې ټوله پاتې به تخریب شوې وي او د بیرته راستنیدو لپاره هیڅ شی پاتې نه وي.
    ///
    /// # Safety
    /// ورکړل شوی edge باید مخکې د `deallocating_next_back` همکار لخوا بیرته نه وي راستن شوی.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// د پا leafې edge هډل په مړاوي ونې کې ورکړئ ، بله پا leftه edge په کی side اړخ کې ، او په مینځ کې د کلیدي ارزښت جوړه ، کوم چې یا په ورته پا leafې نوډ کې وي ، په انډر نوډ کې ، یا غیر موجود نه وي.
    ///
    ///
    /// دا میتود هم هر ډول node(s) ضایع کوي چې دا د پای پای ته رسي.
    /// دا پدې معنی ده چې که چیرې نور د کلي ارزښت ارزښت جوړه شتون ونلري ، نو د ونې ټوله پاتې به تخریب شوې وي او د بیرته راستنیدو لپاره هیڅ شی پاتې نه وي.
    ///
    /// # Safety
    /// ورکړل شوی edge باید مخکې د `deallocating_next` همکار لخوا بیرته نه وي راستن شوی.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// له پا fromی څخه تر ریښی پورې د نوډونو یوه ټاټوبی له مینځه وړی.
    /// دا د `deallocating_next` او `deallocating_next_back` وروسته د ونې پاتې برخه تخفیف کولو یوازینۍ لار ده چې د ونې په دواړو خواو کې ټیټیږي ، او ورته edge یې ټکولی دی.
    /// لکه څنګه چې دا یوازې ویل کیږي کله چې ټولې کیلي او ارزښتونه بیرته راستانه شوي ، په هیڅ کلید یا ارزښتونو باندې هیڅ ډول پاکول نه کیږي.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// د پا Zې edge لاستی راتلونکی پا Zه edge ته حرکت ورکوي او په مینځ کې کلیدي او ارزښت ته مراجعه کوي.
    ///
    ///
    /// # Safety
    /// هلته باید د سفر په لور یو بل KV وي.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// edge پا handleه edge پخوانۍ پا toې ته لیږدوي او په مینځ کې کلیدي او ارزښت ته مراجعه کوي.
    ///
    ///
    /// # Safety
    /// هلته باید د سفر په لور یو بل KV وي.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// د پا Zې edge لاستی راتلونکی پا Zه edge ته حرکت ورکوي او په مینځ کې کلیدي او ارزښت ته مراجعه کوي.
    ///
    ///
    /// # Safety
    /// هلته باید د سفر په لور یو بل KV وي.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // د دې کار ترسره کول ګړندي دي ، د معیارونو سره سم.
        kv.into_kv_valmut()
    }

    /// پا Zه edge هینڈل پخوانۍ پا leafې ته حرکت ورکوي او په مینځ کې کلیدي او ارزښت ته مراجعه کوي.
    ///
    ///
    /// # Safety
    /// هلته باید د سفر په لور یو بل KV وي.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // د دې کار ترسره کول ګړندي دي ، د معیارونو سره سم.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// پا Zه edge لاستی راتلونکی پا Zه edge ته خوځوي او په مینځ کې کیلي او ارزښت بیرته راولي ، کوم نوډ شاته پاتې له مینځه ځي پداسې حال کې چې اړونده edge په خپل اصلي نوډ جریان کې پریږدي.
    ///
    /// # Safety
    /// - هلته باید د سفر په لور یو بل KV وي.
    /// - دا KV مخکې د هم منصب `next_back_unchecked` لخوا د لاسي بمونو په کاپي باندې نه و راستون شوی چې د ونې تعقیب لپاره کارول کیږي.
    ///
    /// د تازه شوي لاسي سره د پرمخ تګ یوازینۍ خوندي لاره دا ده چې پرتله کړئ ، پریږدئ ، دا میتود بیا د خپل خوندیتوب شرایطو تابع کړئ ، یا د `next_back_unchecked` همکار سره د دې د خوندیتوب شرایطو سره اړیکه ونیسئ.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// د پا Zې edge هډل مخکینۍ پا Zې edge ته حرکت ورکوي او په مینځ کې کیلي او ارزښت بیرته راولي ، کوم نوډ شاته پاتې له مینځه ځي پداسې حال کې چې اړونده edge په خپل اصلي نوډ ډینګینګ کې پریږدي.
    ///
    /// # Safety
    /// - هلته باید د سفر په لور یو بل KV وي.
    /// - دا پا Zه edge دمخه د `next_unchecked` همکار لخوا د هغه لاسي کاپي په اړه نه وه راستول شوې چې د ونې څخه تیریدو لپاره کارول کیږي.
    ///
    /// د تازه شوي لاسي سره د پرمخ تګ یوازینۍ خوندي لاره دا ده چې پرتله کړئ ، پریږدئ ، دا میتود بیا د خپل خوندیتوب شرایطو تابع کړئ ، یا د `next_unchecked` همکار سره د دې د خوندیتوب شرایطو سره اړیکه ونیسئ.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// د پورتنۍ ونې پا leftه edge بیرته په نوډ کې یا بیرته راوړي ، په بل عبارت ، edge تاسو لومړی ته اړتیا لرئ کله چې مخکې حرکت وکړئ (یا وروستی کله چې شاته حرکت وکړئ).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// ښی ښی پا leafی edge په نوډ کې یا لاندې ، بیرته راوګرځی ، په بل عبارت ، edge چې تاسو وروستی ته اړتیا لرئ کله چې مخکې حرکت وکړئ (یا لومړی کله چې شاته حرکت وکړئ).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// د پورته کیدونکو کلیدونو په ترتیب کې د پا Visو نوډونو او داخلي KVs لیدنه کوي ، او همدارنګه په بشپړ ډول د لومړي امر ژور داخلي نوډونو څخه لیدنه کوي ، پدې معنی چې داخلي نوډونه د دوی انفرادي KVs او د ماشوم نوډونو څخه مخکې دي.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// په (فر) ونې کې د عناصرو شمیر محاسبه کوي.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// د پا navigationې edge د مخ نیویګریشن لپاره KV ته نږدې ته راستنوي.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// پا backwardه edge د شاته نیویګیشن لپاره KV ته نږدې ته راستنوي.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}