//! Windows SEH
//!
//! په Windows (دا مهال یوازې په MSVC کې) ، د استثنا د استثنایی ډیفالټ میکانیزم د جوړ شوي استثنایی کنټرول کولو (SEH) دی.
//! دا د Dwarf پر بنسټ استثنايي اداره کولو څخه خورا توپیر لري (د مثال په توګه ، کوم چې د unix نور کوم پلیټ فارمونه کاروي) د تالیف کونکي داخلي شرایطو کې ، نو LLVM د SEH لپاره د اضافي مالتړ ښه معاملې کولو لپاره اړین دی.
//!
//! په لنډه توګه ، دلته څه پیښیږي:
//!
//! 1. د `panic` فنکشن معیاري Windows فعالیت `_CxxThrowException` ته د C++ اچولو لپاره غږ کوي-لکه د استثنا په څیر ، د نه منلو وړ پروسس لامل کیږي.
//! 2.
//! د کمپیلر لخوا رامینځته شوي ټول د ځمکې پیډونه د شخصیت فن `__CxxFrameHandler3` کاروي ، په CRT کې یو فنکشن ، او په `__CxxFrameHandler3` کې غیر منطقي کوډ به پدې سټیټ کې د پاکولو ټول کوډ اجرا کولو لپاره د دې شخصیت فعالیت وکاروي.
//!
//! 3. `invoke` ته ټول تالیف شوي تلیفونونه د `cleanuppad` LLVM لارښوونې په توګه د ځمکني پیډ سیټ لري ، کوم چې د پاکولو د روټینټ پیل په ګوته کوي.
//! شخصیت (په مرحله 2 کې ، په CRT کې تعریف شوی) د پاکولو ورځینیو چلولو لپاره مسؤل دی.
//! 4. په نهایت کې د "catch" کوډ په `try` انترنیک کې (د کمپیلر لخوا رامینځته شوی) اجرا شوی او په ګوته کوي چې کنټرول باید بیرته Rust ته راشي.
//! دا د LLVM IR اصطلاحاتو کې د `catchswitch` پلس `catchpad` لارښوونې له لارې ترسره کیږي ، په نهایت کې د `catchret` لارښوونې سره برنامه ته نورمال کنټرول راستنوي.
//!
//! د gcc-پر بنسټ استثنايي سمبالولو څخه ځینې ځانګړي توپیرونه دي:
//!
//! * Rust د ګمرکي شخصیت فعالیت نلري ، دا پرځای دي *تل*`__CxxFrameHandler3`.سربیره پردې ، هیڅ اضافي فلټر کول ندي ترسره شوي ، نو موږ د C++ استثناء پای ته رسیدو چې د هغه ډول په څیر بریښي چې موږ یې ورکوو.
//! په یاد ولرئ چې په Rust کې د استثنا سپړل په هرصورت غیر تعریف شوي چلند دی ، نو دا باید سم وي.
//! * موږ د نه منلوونکې پولې په اوږدو کې د لیږد لپاره یو څه معلومات ترلاسه کړل ، په ځانګړي توګه یو `Box<dyn Any + Send>`.لکه د ډارف استثنااتو سره دا دوه نښې پخپله په استثنا کې د تادیې په توګه زیرمه شوي.
//! په MSVC کې ، په هرصورت ، د اضافي ډیرو تخصیص لپاره اړتیا شتون نلري ځکه چې د زنګ سټیک ساتل کیږي پداسې حال کې چې د فلټر فنکشنونه اجرا کیږي.
//! دا پدې مانا ده چې نښې په مستقیم ډول `_CxxThrowException` ته لیږدول شوي کوم چې بیا د فلټر فنکشن کې بیرته راوړل کیږي ترڅو د `try` انټرنیک سټیک چوکاټ ته لیکل شي.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // دا یو اختیار ته اړتیا لري ځکه چې موږ د حوالې په واسطه استثنا ګورو او د هغې ویجاړونکي د C++ رنټائم لخوا اعدام شوي.
    // کله چې موږ بکس له استثنا څخه لرې کوو ، موږ اړتیا لرو چې استثنا په باثباته حالت کې د هغې ویجاړونکي لپاره پریږدو ترڅو د صندوق دوه ځلې غورځولو پرته پرمخ وګرځي.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// لومړی ، د ډول تعریفونو ټوله ډله.دلته یو څو پلیټ فارم ځانګړي عیبونه شتون لري ، او ډیر څه چې یوازې په کلکه د LLVM څخه کاپي شوي.د دې ټولو هدف د `_CxxThrowException` ته د زنګ له لارې لاندې د `panic` فعالیت پلي کول دي.
//
// دا فنکشن دوه دلیلونه اخلي.لومړی هغه ډاټا ته اشاره کوي چې موږ تیروو ، کوم چې پدې حالت کې زموږ د trait څیز دی.خورا موندل اسانه!په هرصورت ، راتلونکی خورا پیچلی دی.
// دا د `_ThrowInfo` جوړښت ته اشاره کوي ، او دا عموما یوازې د استثنا د توضیح کولو لپاره ټاکل کیږي.
//
// اوس مهال د دې ډول [1] تعریف یو څه ویښتان دی ، او اصلي عجیبیت (او د آنلاین مقالې څخه توپیر) دا دی چې په 32 بټ کې پوینټرې پوائنټرې دي مګر په 64-bit کې نښې د 32-bit آفسیټ څخه څرګند شوي د `__ImageBase` سمبول.
//
// په لاندې ماډلونو کې د `ptr_t` او `ptr!` میکرو د دې څرګندولو لپاره کارول کیږي.
//
// د ډول تعریفونو لیونۍ هم نږدې تعقیبوي هغه څه چې LLVM د دې ډول عملیاتو لپاره جذب کوي.د مثال په توګه ، که تاسو دا C++ کوډ په MSVC کې تالیف کړئ او د LLVM IR خارج کړئ:
//
//      #include <stdint.h>
//
//      سټور رسټ_پینک {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2]؛}؛
//
//      باطل foo() { rust_panic a = {0, 1}؛
//          غورځول؛}
//
// دا په اصل کې هغه څه دي چې موږ یې د تقلید هڅه کوو.لاندې لاندې ډیری دوامدار ارزښتونه یوازې د LLVM څخه کاپي شوي ،
//
// په هر حالت کې ، دا جوړښتونه ټول په ورته ډول جوړ شوي ، او دا زموږ لپاره یوازې یو څه فعل دی.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// په یاد ولرئ چې موږ دلته په عمدي ډول د نوم منګولو قواعد له پامه غورځوو: موږ نه غواړو C++ د `struct rust_panic` په اعلانولو سره د Rust panics ونیسئ.
//
//
// کله چې تدوین کوئ ، ډاډ ترلاسه کړئ چې د ډول نوم سټینګ د `compiler/rustc_codegen_llvm/src/intrinsic.rs` کې کارول شوي سره سمون لري.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // دلته د مخکښ `\x01` بائټ په حقیقت کې LLVM ته یو جادویی سیګنال دی *ترڅو* د `_` کرکټر سره د مختاړي په څیر نور منګلینګ پلي نه کړي.
    //
    //
    // دا سمبول ویټبل دی چې د C++ s `std::type_info` لخوا کارول کیږي.
    // د `std::type_info` ډول ډول څیزونه ، د توزیع کونکي ډولونه ، دې جدول ته پوائنټر لري.
    // د ډول تشریح کونکي د C++ EH جوړښتونو لخوا اشاره شوي چې پورته تعریف شوي او دا چې موږ لاندې جوړوي.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// دا ډول توضیح کونکي یوازې هغه وخت کارول کیږي کله چې استثنا پکې غورځول کیږي.
// د کیچ برخه د هڅه انټرنسیک لخوا اداره شوې ، کوم چې خپل ټایپ ډیسکرټر رامینځته کوي.
//
// دا سم دی ځکه چې د MSVC رنټیم د ټایپډسریکټرونو سره د ټکي برابرۍ پرځای پرتله کولو لپاره د ټایپ نوم سره تار پرتله کوي.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// تخریب کونکي کارول شوي که چیرې د C++ کوډ پریکړه وکړي چې استثنا ترلاسه کړي او پرته له دې چې تبلیغات یې پریږدي.
// د کوښښ کولو انټرسټیک کیچ برخه به د استثنايي اعتراض لومړۍ کلمه 0 ته ټاکي ترڅو دا د تخریب کونکي لخوا پریښودل شي.
//
// په یاد ولرئ چې x86 Windows د C++ غړي افعال لپاره د "thiscall" زنګ وهلو کنونشن کاروي د ډیفالټ "C" تلیفون کنوانسیون پرځای.
//
// د استثنایی_ کاپي فعالیت دلته یو څه ځانګړی دی: دا د XVX بلاک لاندې د MSVC رنټیم لخوا غوښتل شوی او panic چې موږ یې دلته پیدا کوو د استثنایی کاپي پایلې په توګه به وکارول شي.
//
// دا د C++ رنټیم لخوا د std::exception_ptr سره د استثنا د نیول ملاتړ لپاره کارول کیږي ، کوم چې موږ یې نشو ملاتړ کولی ځکه چې بکس<dyn Any>مسخره نده.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException په بشپړ ډول د دې سټا چوکاټ کې اجرا کوي ، نو ځکه اړتیا نشته چې په بل ډول `data` هیر ته واستول شي.
    // موږ دې کار ته یوازې د حویلۍ نښه ورکوو.
    //
    // دستی ډراپ دلته اړین دی ځکه چې موږ نه غواړو استثنایی له کښته کیدو وروسته وغورځول شي.
    // پرځای به دا به د استثنایی_ کلېن اپ لخوا غورځول شي کوم چې د C++ رنټیم لخوا غوښتنه شوې.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // دا ... ممکن حیرانتیا ښکاري ، او په عادلانه ډول داسې.په 32 بټ MSVC کې د دې جوړښت ترمینځ نښې یوازې هغه دي ، نښې.
    // په 64 بټ MSVC کې ، په هرصورت ، د جوړښتونو ترمینځ نښې د `__ImageBase` څخه د 32-بټ آفسیټ په توګه څرګند شوي.
    //
    // په پایله کې ، په 32 بټ MSVC کې موږ کولی شو دا ټول نکات په پورتني `جامد کې اعلان کړو.
    // په 64 بټ MSVC کې ، موږ به په سټیټکس کې د نښو کمو څرګندونې وکړو ، کوم چې Rust اوس مهال اجازه نه ورکوي ، نو موږ نشو کولی واقعیا داسې وکړو.
    //
    // راتلونکی غوره شی ، بیا دا دی چې د جوړښت وخت کې دې جوړښتونو ډک کړئ (ویره کول لاهم په هرصورت "slow path" دي).
    // نو دلته موږ دا ټول پوینټر ساحې د 32-بټ انټیجرونو په توګه بیا تعبیر کوو او بیا اړونده ارزښت په هغې کې ذخیره کوو (په اتوماتيک ډول ، لکه څنګه چې په ورته ډول panics پیښ شي).
    //
    // په تخنیکي لحاظ به د وخت وخت شاید د دې برخو غیر اټومي مطالعه وکړي ، مګر په تیورۍ کې دوی هیڅکله د *غلط* ارزښت نه لوستل نو دا باید ډیر بد نه وي ...
    //
    // په هر حالت کې ، موږ اساسا اړتیا لرو د دې په څیر یو څه ترسره کړو تر هغه چې موږ وکولی شو په احصایه کې نور عملیات څرګند کړو (او موږ ممکن هیڅکله بریالي نه شو).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // د NULL تادیه کول پدې معنی دي چې موږ دلته د __rust_try د (...) کیچ څخه ترلاسه کړي.
    // دا پیښیږي کله چې یو غیر Rust بهرني استثنا ونیول شي.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// دا د تالیف کونکي لخوا شتون لري ترڅو شتون ولري (د بیلګې په توګه ، دا د لانګ توکی دی) ، مګر دا واقعیا هیڅکله د تالیف کونکي لخوا نه ویل کیږي ځکه چې __C_specific_handler یا _except_handler3 د شخصیت فعالیت دی چې تل کارول کیږي.
//
// نو له همدې امله دا یو له پامه غورځونکی ضبط دی.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}