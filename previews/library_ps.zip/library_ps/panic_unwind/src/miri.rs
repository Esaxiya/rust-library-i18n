//! د میري لپاره panics نه خلاصول.
use alloc::boxed::Box;
use core::any::Any;

// د تادیې ډول چې د میري انجن زموږ لپاره د نه منلو له لارې تبلیغ کوي.
// باید د اشارو اندازه وي.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// د میري چمتو شوي بیروني فعالیت د بندولو لپاره پیل کوي.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // موږ د `miri_start_panic` ته تادیه کول به دقیقا هغه دلیل وي چې موږ یې په `cleanup` کې ترلاسه کوو.
    // نو موږ دا یوازې یوځل بکس کړئ ، ترڅو د پوائنټر-اندازې یو څه ترلاسه کړئ.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // لاندې `Box` بیرته ترلاسه کړئ.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}