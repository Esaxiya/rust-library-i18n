//! د panics پلي کول د libgcc/libunwind لخوا ملاتړ شوي (په ځینې ب inه کې).
//!
//! د استثنا د اداره کولو او غیر منقولو سټایک کولو شالید لپاره مهرباني وکړئ د "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) او له دې څخه تړل شوي اسناد وګورئ.
//! دا هم ښه لوستل کیږي:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## یو لنډ لنډیز
//!
//! د استثناء اداره کول په دوه مرحلو کې پیښیږي: د لټون مرحله او د پاکولو مرحله.
//!
//! په دواړو مرحلو کې غیروانندر د ساک چوکاټ څخه د اوسني پروسې انډولونو برخې خلاصولو معلوماتو کارولو په واسطه د سټیک چوکاټونه پرمخ وړي ("module" دلته د OS انډول ته اشاره کوي ، د بیلګې په توګه ، د اجرا کولو وړ یا متحرک کتابتون).
//!
//!
//! د هر سټایل چوکاټ لپاره ، دا اړوند "personality routine" غوښتنه کوي ، چې پته یې هم د معلوماتو په برخه کې خوندي ده.
//!
//! د لټون مرحله کې ، د شخصیت معمول کار دا دی چې د استثنایی توکي غورځول په پام کې ونیسي ، او پریکړه وکړي چې ایا دا باید پدې سټیک چوکاټ کې ونیول شي.یوځل چې د لارښود چوکاټ وپیژندل شو ، د پاکولو مرحله پیل کیږي.
//!
//! د پاکولو په مرحله کې ، ناتیدونکي د هر شخصیت روټینان بیا غوښتنه کوي.
//! دا وخت پریکړه کوي چې کوم (که کوم دی) د پاکولو کوډ د اوسني سټیک چوکاټ لپاره چلولو ته اړتیا لري.که داسې وي ، نو کنټرول د فعالیت په بدن کې ځانګړي branch ته سپارل شوی ، "landing pad" ، کوم چې تخریب کونکي غوښتنه کوي ، حافظه یې آزادوي ، او داسې نور.
//! د لینډینګ پیډ په پای کې ، کنټرول بیرته غیر انوینډر او بې ځایه شوي بیرته راستنیدو ته لیږدول کیږي.
//!
//! یوځل چې سټیک د هډلر چوکاټ کچې ته ښکته شوی ، نه تړل شوي وقفې او د شخصیت وروستي معمول ورځنی کنټرول د کیچ بلاک ته لیږدوي.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// د Rust استثنا د ټولګي پیژندونکی.
// دا د شخصیت معمول لخوا کارول کیږي ترڅو مشخص کړي چې ایا استثنا د دوی د خپل وخت په واسطه غورځول شوې وه.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-پلورونکی ، ژبه
    0x4d4f5a_00_52555354
}

// د هرې معمارۍ لپاره د راجستر ایډونه د LLVM TargetLowering::getExceptionPointerRegister() او TargetLowering::getExceptionSelectorRegister() څخه ایستل شوي وو ، بیا د راجستریشن تعریف میزونو له لارې د DWARF راجستر شمیرو ته نقشه شوي (عموما<arch>ثبت کړئ ، د "DwarfRegNum" لپاره لټون وکړئ).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register هم وګورئ.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX ، EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX ، RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0 ، X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3 ، X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// لاندې کوډ د GCC د C او C++ د شخصیت معمولاتو پراساس دی.د حوالې لپاره ، وګورئ:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM د EHABI شخصیت ورځینۍ.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS پرځای یې اصلي ډیټا کاروي ځکه چې دا SjLj unwinding کاروي.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // په ARM کې بیکراسیس به د شخصیت ورځنۍ حالت سره اړیکه ونیسي==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // پدې حالتونو کې موږ غواړو د زړو تړلو ته دوام ورکړو ، که نه نو زموږ ټولې پښې به په __rust_try کې پای ومومي
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // د ډورف غیروونډر فرض کوي چې _ انواین_کینټکس د فنکشن او LSDA اشارو په څیر شیان لري ، په هرصورت ، آرمی EHABI دوی استثنایی څیز کې ځای په ځای کوي.
            // د _Unwind_GetLanguageSpecificData() په څیر د دندو لاسلیکونو ساتلو لپاره ، کوم چې یوازې شرایطو ته اشاره کوي ، د GCC شخصیت معمول په اشاره کې د استثناء-موضوع ته د اشارې ځای په ځای کوي ، د ARM "scratch register" (r12) لپاره ځای ځای په کارولو سره.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... یو ډیر اصولي چلند به دا وي چې زموږ د لیبونډ بانډونو کې د ARM_Uwwind_Context بشپړ تعریف چمتو کړي او د DWARF مطابقت افعال کولو په واسطه مستقیم له هغه ځایه اړین معلومات راوباسي.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI د شخصیت معمول ته اړتیا لري ترڅو د استثنایی موضوع په خنډ کېچ کې د SP ارزښت تازه کړي.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // په ارم اهنبي کې د شخصیت ورځینۍ د بیرته راستنیدو دمخه د حقیقت لپاره د یو سټیک چوکاټ بندول مسؤلیت لري (د آرم EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // په libgcc کې تعریف شوی
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // د ډیفالټ شخصیت معمول ، کوم چې په ډیری اهدافو کې مستقیم او په غیر مستقیم ډول د SEH له لارې په Windows x86_64 کې کارول کیږي.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // د x86_64 MinGW اهدافو کې ، د نه منلو میکانیزم SEH دی په هرصورت د unwind لاسي ډیټا (عرف LSDA) د GCC-مطابقت لرونکي کوډ ورکول کاروي.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // زموږ د ډیری هدفونو لپاره د شخصیت معمول.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // د راستنیدو پته 1 کال د ټلیفون لارښوونې په نښه کوي ، کوم چې ممکن په LSDA رینج جدول کې په راتلونکي IP لړ کې وي.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// چوکاټ د معلوماتو خوندي کول
//
// د هر ماډل عکس د چوکاټ پرانستې معلوماتو برخه لري (معمولا ".eh_frame").کله چې یو ماډل پروسس کې loaded/unloaded وي ، غیر انواندر باید په یاد کې د دې برخې موقعیت په اړه خبر شي.د ترلاسه کولو میتودونه چې د پلیټفارم لخوا توپیر لري.
// په ځینو (مثال په توګه ، Linux) کې ، غیرندر کولی شي پخپله د معلوماتو بې برخې برخې کشف کړي (په متحرک ډول د dl_iterate_phdr() API and finding their ".eh_frame" sections) له لارې په بار وړل شوي ماډلونو حساب کولو سره؛ نور ، د Windows په څیر ، ماډلونو ته اړتیا لري ترڅو په غیر فعاله توګه د دوی انډنډي معلوماتو برخې راجستر کړي ترڅو د Unvind API له لارې.
//
//
// دا موډل دوه سمبولونه ټاکي چې حواله شوي او له rsbegin.rs څخه غوښتل شوي ترڅو زموږ معلومات د GCC رنټیم سره ثبت کړي.
// د سټا انډونډ کولو پلي کول (د اوس لپاره) libgcc_eh ته ځنډول شوي ، په هرصورت Rust crates د دې Rust-مشخص ننوتلو ټکي کاروي ترڅو د کوم GCC رنټیم سره احتمالي نښتو مخه ونیسي.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}