use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // دا د سطحې مستحکم ساحه نده ، مګر د دوی تر مینځ د `?` ارزانه ساتلو کې مرسته کوي ، حتی که LLVM نشي کولی همدا اوس همدا اوس ګټه پورته کړي.
    //
    // (د خواشینۍ سره پایلې او اختیارونه یو له بل سره متناقض دي ، نو د کنټرولفلو دواړه سره میچ نشي کولی.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}