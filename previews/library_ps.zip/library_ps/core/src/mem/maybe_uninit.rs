use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// د `T` بې بنسټه مثالونو رامینځته کولو لپاره ریپر ډول.
///
/// # د پیل پیل
///
/// تالیف کونکی ، په عموم کې ، فرض کوي چې متغیر په سمه توګه د تغیر شوي ډول اړتیاو مطابق پیل شوی وي.د مثال په توګه ، د مرجع ډول بدلون باید اړونده وي او غیر NULL.
/// دا یو تیروتنه ده چې باید *تل* یې ملاتړ وشي حتی په غیر خوندي کوډ کې.
/// د پایلې په توګه ، د حوالې ډول متغیر صفر پیل کول د [undefined behavior][ub] فوري لامل کیږي ، هیڅ مسله نلري چې دا حواله کله هم حافظې ته لاسرسی لپاره کارول کیږي:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // نا څرګند چلند!⚠️
/// // د `MaybeUninit<&i32>` سره مساوي کوډ:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // نا څرګند چلند!⚠️
/// ```
///
/// دا د مختلف اصلاحاتو لپاره د مرتب کونکي لخوا کارول کیږي ، لکه د وخت وخت چکونه ساتل او د `enum` ترتیب اصلاح کول.
///
/// په ورته ډول ، په بشپړ ډول بې بنسټه حافظه ممکن کوم مینځپانګه ولري ، پداسې حال کې چې `bool` باید تل `true` یا `false` وي.نو ځکه ، د بې بنسټه `bool` رامینځته کول غیر تعریف شوي چلند دی:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // نا څرګند چلند!⚠️
/// // د `MaybeUninit<bool>` سره مساوي کوډ:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // نا څرګند چلند!⚠️
/// ```
///
/// سربیره پردې ، بې بنسټه حافظه پدې کې ځانګړې ده چې دا یو ټاکلی ارزښت نلري ("fixed" معنی "it won't change without being written to").د ورته بې بنسټه بایټ ډیری ځله لوستل کولی شي مختلفې پایلې ورکړي.
/// دا دا غیر متناسب چلند ته اړوي چې په متغیر کې غیر منسجم شوي ډاټا ولري حتی که چیرې دا متغیر یو بشپړ ډول ولري ، کوم چې بل ډول کولی شي کوم *ثابت* بیټ ب patternه وساتي:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // نا څرګند چلند!⚠️
/// // د `MaybeUninit<i32>` سره مساوي کوډ:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // نا څرګند چلند!⚠️
/// ```
/// (په پام کې ونیسئ چې د غیر منحل کونکو انټرنیټونو په اړه مقررات لاهم نهایی شوي ، مګر تر هغه چې دوی وي ، نو د دې څخه باید مخنیوی وشي.)
///
/// سربیره پردې ، په یاد ولرئ چې ډیری ډولونه اضافي ډولونه لري پرته لدې چې د نوعیت په سطح کې ابتدايي ګ consideredل کیږي.
/// د مثال په توګه ، د `1`-ابتدایی [`Vec<T>`] ابتدایی ګ isل کیږي (د اوسني پلي کونې لاندې؛ دا یو باثباته تضمین نه رامینځته کوي) ځکه چې یوازینی اړتیا چې تالیف کونکی یې په اړه پوهیږي دا دی چې د ډاټا نښه کونکی باید غیر خالي وي.
/// د داسې `Vec<T>` رامینځته کول د *سمدستي* نامعلومه چلند لامل نه کیږي ، مګر دا به د ډیرو خوندي عملیاتو سره د غیر تعریف شوي چلند لامل شي (په شمول د دې پریښودل).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` د غیر خوندي شوي ډاټا سره د معاملې لپاره غیر خوندي کوډ وړولو کې کار کوي.
/// دا تالیف کونکي ته سیګنال دی په ګوته کوي چې دلته ممکن ډاټا * نه پیل شي:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // په ښکاره ډول بې بنسټه حواله رامینځته کړئ.
/// // تالیف کونکی پوهیږي چې د `MaybeUninit<T>` دننه ډاټا ممکن غلط وي ، او له همدې امله دا UB نه دی:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // دا باوري ارزښت ته وټاکئ.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // پیل شوي ډاټا راوباسئ-دا یوازې د *وروسته* اجازه ورکړل شوې ده په مناسب ډول د `x` پیل!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// تالیف کونکی بیا پوهیږي چې پدې کوډ کې کوم غلط انګیرنې یا اصلاحات نلري.
///
/// تاسو کولی شئ د `MaybeUninit<T>` په څیر د `Option<T>` په څیر فکر وکړئ مګر پرته له کوم چې د ځنډ وخت تعقیب او د خوندیتوب چک پرته.
///
/// ## out-pointers
///
/// تاسو کولی شئ د "out-pointers" پلي کولو لپاره `MaybeUninit<T>` وکاروئ: د یوه فنکشن څخه د معلوماتو بیرته راګرځولو پرځای ، دې ته د (uninitialized) حافظې ته ځینې نښې واستوئ ترڅو پایله یې دننه کړئ.
/// دا کیدی شي ګټور وي کله چې د زنګ وهونکي لپاره دا مهم وي چې کنټرول شي چې څنګه حافظه پایله کې زیرمه کیږي ، او تاسو غواړئ د غیر ضروري حرکتونو مخه ونیسئ.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` زاړه مینځپانګه نه غورځوي ، کوم چې مهم دي.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // اوس موږ پوهیږو چې `v` پیل شوی دی!دا هم ډاډ ترلاسه کوي چې vector په سمه توګه غورځیدلی.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## د یو عنصر په اساس عنصر پیل کول
///
/// `MaybeUninit<T>` د عنصر په اساس د لوی سرنی عنصر پیل کولو لپاره کارول کیدی شي:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // د `MaybeUninit` بې بنسټه شوی صف جوړ کړئ.
///     // د `assume_init` خوندي دی ځکه چې هغه ډول چې موږ ادعا کوو دلته یې د ابتکار غوښتنه کړې د `شاید یوټینیټس یوه ډله ده ، کوم چې ابتکار ته اړتیا نلري.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // د `MaybeUninit` غورځول هیڅ نه کوي.
///     // پدې توګه د `ptr::write` پرځای د خام پوائنټر اسینیم کارول کارول د زوړ بې بنسټه ارزښت له مینځه وړو لامل نه کیږي.
/////
///     // همدارنګه که چیرې د دې لوپ پرمهال panic شتون ولري ، موږ د حافظې لیک لرو ، مګر د حافظې خوندیتوب کومه ستونزه شتون نلري.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // هرڅه پیل شوي.
///     // سرنی پیل شوی ډول ته واړوئ.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// تاسو کولی شئ د جزوي ابتکار شوي اریونو سره هم کار وکړئ ، کوم چې د ټیټ کچې ډیټاسټریکچرونو کې موندل کیدی شي.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // د `MaybeUninit` بې بنسټه شوی صف جوړ کړئ.
/// // د `assume_init` خوندي دی ځکه چې هغه ډول چې موږ ادعا کوو دلته یې د ابتکار غوښتنه کړې د `شاید یوټینیټس یوه ډله ده ، کوم چې ابتکار ته اړتیا نلري.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // موږ د عناصرو شمیر ګمارلی دی.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // په صف کې د هر توکي لپاره ، راکړئ که چیرې موږ دا ځانګړي کړي.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## په ساحه کې د جوړښت ساحه پیل کول
///
/// تاسو کولی شئ `MaybeUninit<T>` ، او `MaybeUninit<T>` میکرو وکاروئ ، ترڅو د ساحې په واسطه د سټریک ساحه پیل کړئ:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // د `name` ساحه پیل کول
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // د `list` ساحه پیل کول که چیرې دلته panic شتون ولري ، نو د `name` ساحې لیک کې `String`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ټول ساحې پیل شوي دي ، نو موږ د پیل شوي فو ترلاسه کولو لپاره `assume_init` تلیفون کوو.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` د `T` په څیر د ورته اندازې ، قطار ، او ABI درلودو تضمین دی:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// په هرصورت په یاد ولرئ چې یو ډول * * د `MaybeUninit<T>` درلودل لازمي ورته ورته ب layoutه نلري؛Rust په عمومي ډول تضمین نلري چې د `Foo<T>` ساحې د `Foo<U>` په څیر ورته حکم لري حتی که `T` او `U` ورته اندازه او سیده ولري.
///
/// سربیره پردې چې هرڅه ارزښت د `MaybeUninit<T>` لپاره د اعتبار وړ دی تالیف کونکی نشي کولی د non-zero/niche-filling مطلوبیت تطبیق کړي ، په احتمالي توګه د لوی اندازې پایله:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// که `T` د FFI خوندي وي ، نو بیا `MaybeUninit<T>` هم دی.
///
/// پداسې حال کې چې `MaybeUninit` د `#[repr(transparent)]` دی (په ګوته کوي چې دا د ورته اندازې ، الینینګ ، او ABI د `T` په توګه تضمین کوي) ، دا * هیڅکله د پخوانیو انتشاراتو بدلون نه کوي.
/// `Option<T>` او `Option<MaybeUninit<T>>` ممکن لاهم مختلف اندازې ولري ، او د `T` ډول لرونکی ډولونه ممکن د (او اندازې) په بیله ب beه ایښودل شي که چیرې دا ساحه `MaybeUninit<T>` وی.
/// `MaybeUninit` د اتحادیې ډول دی ، او په اتحادیه کې `#[repr(transparent)]` بې ثباته دی (وګورئ [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// د وخت په تیریدو سره ، په اتحادیو کې د `#[repr(transparent)]` دقیق تضمین ممکن وده وکړي ، او `MaybeUninit` ممکن `#[repr(transparent)]` پاتې شي یا نه.
/// ورته وویل ، `MaybeUninit<T>` به * تل تضمین ولري چې دا د `T` په څیر ورته اندازه ، سمون او ABI ولري؛دا بس دی چې د `MaybeUninit` پلي کولو لاره چې تضمین ممکن وده وکړي.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// لانګ توکی نو موږ کولی شو پدې کې نور ډولونه ولګوو.دا د جنراتورونو لپاره ګټور دی.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // د `T::clone()` تلیفون نه کول ، موږ نه پوهیږو چې ایا موږ د دې لپاره کافي پیل کړی یاست.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ورکړل شوی ارزښت سره نوی `MaybeUninit<T>` پیلوي.
    /// دا خوندي دی چې د دې فنکشن بیرته ستنیدو ارزښت باندې [`assume_init`] تلیفون وکړئ.
    ///
    /// په یاد ولرئ چې د `MaybeUninit<T>` غورځول به هیڅکله د `T` کود کوډ نه زنګ ووهي.
    /// دا ستاسو مسؤلیت دی چې ډاډ ترلاسه کړئ چې `T` راولویږي که چیرې دا پیل شوی وي.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// په بې بنسټه دولت کې نوی `MaybeUninit<T>` جوړوي.
    ///
    /// په یاد ولرئ چې د `MaybeUninit<T>` غورځول به هیڅکله د `T` کود کوډ نه زنګ ووهي.
    /// دا ستاسو مسؤلیت دی چې ډاډ ترلاسه کړئ چې `T` راولویږي که چیرې دا پیل شوی وي.
    ///
    /// د ځینې مثالونو لپاره [type-level documentation][MaybeUninit] وګورئ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// د `MaybeUninit<T>` توکي نوی صف جوړ کړئ ، په بې بنسټه حالت کې.
    ///
    /// Note: په future Rust نسخه کې دا میتود ممکن غیر ضروري شي کله چې د سرلیک سیرتکس [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ته اجازه ورکوي.
    ///
    /// لاندې مثال بیا د `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` کارول کیدی شي.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// د ډیټا (احتمالي کوچنۍ) ټوټه بیرته راوړي چې واقعیا لوستل شوي
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // خوندي: بې بنسټه `[MaybeUninit<_>; LEN]` د اعتبار وړ دی.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// په بې بنسټه حالت کې نوی `MaybeUninit<T>` رامینځته کوي ، د حافظې سره د `0` بایټونو ډک شوی.دا په `T` پورې اړه لري چې ایا دا دمخه د مناسب ابتدا لپاره رامینځته کیږي.
    ///
    /// د مثال په توګه ، `MaybeUninit<usize>::zeroed()` پیل شوی ، مګر `MaybeUninit<&'static i32>::zeroed()` دا ندی ځکه چې مآخذونه باید خالي نه وي.
    ///
    /// په یاد ولرئ چې د `MaybeUninit<T>` غورځول به هیڅکله د `T` کود کوډ نه زنګ ووهي.
    /// دا ستاسو مسؤلیت دی چې ډاډ ترلاسه کړئ چې `T` راولویږي که چیرې دا پیل شوی وي.
    ///
    /// # Example
    ///
    /// د دې فنکشن سمه کارول: د صفر سره جوړښت پیل کول ، چیرې چې د سټرک ټولې برخې کولی شي د اعتبار ارزښت په توګه د بټ-نمونه 0 وساتي.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *د دې فعالیت غلط* کارول: د `x.zeroed().assume_init()` تلیفون کول کله چې `0` د ډول لپاره معتبر بټ پیټرن ندی:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // د جوړه دننه ، موږ یو `NotZero` رامینځته کوو چې معقول امتیاز نلري.
    /// // دا غیر تعریف شوی چلند دی.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // خوندي: د تخصیص شوي حافظې ته `u.as_mut_ptr()` ټکي.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// د `MaybeUninit<T>` ارزښت ټاکي.
    /// دا کوم پخوانی ارزښت له مینځه وړلو پرته له مینځه ځي ، نو پام مو وکړئ چې دا دوه ځله وکاروئ پرته لدې چې تاسو غواړئ د تخریبونکي چلولو ته لاړشئ.
    ///
    /// ستاسو د اسانتیا لپاره ، دا د `self` مینځپانګې (اوس په خوندي ډول پیل شوي) مینځپانګې حواله هم ورکوي.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // امنیت: موږ یوازې دا ارزښت پیل کړی.
        unsafe { self.assume_init_mut() }
    }

    /// موجود ارزښت ته اشاره کوي.
    /// د دې نښې څخه لوستل یا حوالې ته اړول غیر تعریف شوي چلند دی غیر لدې چې د `MaybeUninit<T>` پیل نه وي.
    /// حافظې ته لیکل چې دا نښې (non-transitively) په ګوته کوي غیر تعریف شوي چلند دی (په استثنا د `UnsafeCell<T>` دننه).
    ///
    /// # Examples
    ///
    /// د دې میتود سمه کارول:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // په `MaybeUninit<T>` کې حواله رامینځته کړئ.دا سمه ده ځکه چې موږ دا پیل کړی.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *د دې میتود غلط* کارول:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // موږ بې بنسټه vector ته مراجعه جوړه کړې!دا غیر تعریف شوی چلند دی.⚠️
    /// ```
    ///
    /// (په پام کې ونیسئ چې د بې بنسټه معلوماتو په اړه د مراجعو شاوخوا قواعد لاهم نهایی شوي ، مګر تر هغه چې دوی وي ، نو د دې څخه باید مخنیوی وشي.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` او `ManuallyDrop` دواړه `repr(transparent)` دي نو موږ کولی شو پوسټ ورکړو.
        self as *const _ as *const T
    }

    /// موجود ارزښت ته بدلیدونکی نښه ورکوونکی ترلاسه کوي.
    /// د دې نښې څخه لوستل یا حوالې ته اړول غیر تعریف شوي چلند دی غیر لدې چې د `MaybeUninit<T>` پیل نه وي.
    ///
    /// # Examples
    ///
    /// د دې میتود سمه کارول:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // په `MaybeUninit<Vec<u32>>` کې حواله رامینځته کړئ.
    /// // دا سمه ده ځکه چې موږ دا پیل کړی.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *د دې میتود غلط* کارول:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // موږ بې بنسټه vector ته مراجعه جوړه کړې!دا غیر تعریف شوی چلند دی.⚠️
    /// ```
    ///
    /// (په پام کې ونیسئ چې د بې بنسټه معلوماتو په اړه د مراجعو شاوخوا قواعد لاهم نهایی شوي ، مګر تر هغه چې دوی وي ، نو د دې څخه باید مخنیوی وشي.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` او `ManuallyDrop` دواړه `repr(transparent)` دي نو موږ کولی شو پوسټ ورکړو.
        self as *mut _ as *mut T
    }

    /// د `MaybeUninit<T>` کانټینر څخه ارزښت راوباسي.دا د ډاډ ترلاسه کولو عالي لاره ده چې ډاډ ترلاسه کړئ چې ډاټا به راټیټ شي ، ځکه چې د `T` پایله به د معمول غورځولو اداره کولو تابع وي.
    ///
    /// # Safety
    ///
    /// دا زنګ وهونکي پورې اړه لري چې تضمین ورکړي چې `MaybeUninit<T>` واقعیا په ابتدایی حالت کې دی.دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د سمدستي نامعلومه چلند لامل کیږي.
    /// [type-level documentation][inv] د دې ابتکار بریدګر په اړه نور معلومات لري.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// سربیره پردې ، په یاد ولرئ چې ډیری ډولونه اضافي ډولونه لري پرته لدې چې د نوعیت په سطح کې ابتدايي ګ consideredل کیږي.
    /// د مثال په توګه ، د `1`-ابتدایی [`Vec<T>`] ابتدایی ګ isل کیږي (د اوسني پلي کونې لاندې؛ دا یو باثباته تضمین نه رامینځته کوي) ځکه چې یوازینی اړتیا چې تالیف کونکی یې په اړه پوهیږي دا دی چې د ډاټا نښه کونکی باید غیر خالي وي.
    ///
    /// د داسې `Vec<T>` رامینځته کول د *سمدستي* نامعلومه چلند لامل نه کیږي ، مګر دا به د ډیرو خوندي عملیاتو سره د غیر تعریف شوي چلند لامل شي (په شمول د دې پریښودل).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// د دې میتود سمه کارول:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *د دې میتود غلط* کارول:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` تر دې دمه نه دی پیل شوی ، نو دا وروستۍ لیکه د نه تعریف شوي چلند لامل شوې.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` پیل شوی.
        // دا د دې معنی هم لري چې `self` باید د `value` ډول ولري.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// د `MaybeUninit<T>` کانټینر څخه ارزښت لوستل.پایله شوې `T` د معمول غورځولو اداره کولو تابع ده.
    ///
    /// هرکله چې امکان ولري ، د [`assume_init`] پرځای کارول غوره دي ، کوم چې د `MaybeUninit<T>` مینځپانګې نقل کولو مخه نیسي.
    ///
    /// # Safety
    ///
    /// دا زنګ وهونکي پورې اړه لري چې تضمین ورکړي چې `MaybeUninit<T>` واقعیا په ابتدایی حالت کې دی.دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د نا څرګند چلند لامل کیږي.
    /// [type-level documentation][inv] د دې ابتکار بریدګر په اړه نور معلومات لري.
    ///
    /// سربیره پردې ، دا د ورته معلوماتو کاپي په `MaybeUninit<T>` کې شاته پریږدي.
    /// کله چې د ډیټا ډیری کاپيونه کاروئ (د `assume_init_read` ډیری ځل زنګ وهلو سره ، یا لومړی د `assume_init_read` او بیا [`assume_init`] زنګ وهلو سره) ، دا ستاسو مسؤلیت دی چې ډاډ ترلاسه کړئ چې دا معلومات واقعیا نقل کیدی شي.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// د دې میتود سمه کارول:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` دی ، نو موږ ممکن ډیری وختونه ولولئ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // د `None` ارزښت نقل کول سم دي ، نو موږ ممکن ډیری وختونه ولولئ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *د دې میتود غلط* کارول:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // موږ اوس د ورته vector دوه کاپيګانې رامینځته کړې ، چې د دوه ګونی نه خلاصې ته وړاندې کوي-کله چې دا دواړه راټیټ شي!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` پیل شوی.
        // د `self.as_ptr()` څخه لوستل خوندي دي ځکه چې `self` باید پیل شي.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// موجود ارزښت په ځای کې غورځوي.
    ///
    /// که تاسو د `MaybeUninit` ملکیت لرئ ، نو تاسو یې پرځای [`assume_init`] وکاروئ.
    ///
    /// # Safety
    ///
    /// دا زنګ وهونکي پورې اړه لري چې تضمین ورکړي چې `MaybeUninit<T>` واقعیا په ابتدایی حالت کې دی.دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د نا څرګند چلند لامل کیږي.
    ///
    /// سربیره پردې ، د `T` ډول ټول اضافي تیریدونکي باید مطمین وي ، ځکه چې د `Drop` پلي کول `T` (یا د دې غړي) ممکن پدې باندې تکیه وکړي.
    /// د مثال په توګه ، د `1`-ابتدایی [`Vec<T>`] ابتدایی ګ isل کیږي (د اوسني پلي کونې لاندې؛ دا یو باثباته تضمین نه رامینځته کوي) ځکه چې یوازینی اړتیا چې تالیف کونکی یې په اړه پوهیږي دا دی چې د ډاټا نښه کونکی باید غیر خالي وي.
    ///
    /// په هرصورت د داسې `Vec<T>` غورځول به د نامعلوم چلند لامل شي.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // امنیت: زنګ وهونکی باید تضمین وکړي چې `self` پیل شوی او
        // د `T` ټول بریدګر خوښوي.
        // په ځای کې د ارزښت پریښودل خوندي دي که دا قضیه وي.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// موجود ارزښت ته ګډه حواله ترلاسه کوي.
    ///
    /// دا ګټور کیدی شي کله چې موږ غواړو `MaybeUninit` ته لاسرسی وکړو چې پیل شوی مګر د `MaybeUninit` ملکیت نلري (د `.assume_init()`) کارولو مخه نیسي.
    ///
    /// # Safety
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د نامعلومه چلند لامل کیږي: دا د تلیفون کونکي پورې اړه لري ترڅو تضمین وکړي چې `MaybeUninit<T>` واقعیا په ابتدایی حالت کې دی.
    ///
    ///
    /// # Examples
    ///
    /// ### د دې میتود سمه کارول:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // د `x` پیل کړئ:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // اوس چې زموږ `MaybeUninit<_>` پیژندل شوی پیژندل شوی ، نو دا د دې لپاره ګډ شریک حواله رامینځته کول سم دي:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // خوندي: `x` پیل شوی.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *د دې میتود غلط* کارول:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // موږ بې بنسټه vector ته مراجعه جوړه کړې!دا غیر تعریف شوی چلند دی.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // د `Cell::set` په کارولو سره `MaybeUninit` پیل کړئ:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // بې بنسټه `Cell<bool>` ته مراجعه: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` پیل شوی.
        // دا د دې معنی هم لري چې `self` باید د `value` ډول ولري.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// موجود ارزښت ته د بدلون وړ (unique) حواله ترلاسه کوي.
    ///
    /// دا ګټور کیدی شي کله چې موږ غواړو `MaybeUninit` ته لاسرسی وکړو چې پیل شوی مګر د `MaybeUninit` ملکیت نلري (د `.assume_init()`) کارولو مخه نیسي.
    ///
    /// # Safety
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د نامعلومه چلند لامل کیږي: دا د تلیفون کونکي پورې اړه لري ترڅو تضمین وکړي چې `MaybeUninit<T>` واقعیا په ابتدایی حالت کې دی.
    /// د مثال په توګه ، `.assume_init_mut()` د `MaybeUninit` د پیل کولو لپاره نشي کارول کیدی.
    ///
    /// # Examples
    ///
    /// ### د دې میتود سمه کارول:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// د ننوت بفر ټول * بایټونه پیل کوي.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // د `buf` پیل کړئ:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // اوس موږ پوهیږو چې `buf` پیل شوی ، نو موږ یې دا `.assume_init()` شو.
    /// // په هرصورت ، د `.assume_init()` کارول ممکن د 2048 بایټونو `memcpy` محرک کړي.
    /// // د دې لپاره چې زموږ بفر د دې کاپي کولو پرته پیل شوی وي ، موږ `&mut MaybeUninit<[u8; 2048]>` ته `&mut [u8; 2048]` ته لوړ کړو:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // خوندي: `buf` پیل شوی.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // اوس موږ کولی شو `buf` د نورمال ټوټې په توګه وکاروو:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *د دې میتود غلط* کارول:
    ///
    /// تاسو د ارزښت د پیل لپاره `.assume_init_mut()` نشئ کاروالی:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // موږ بې بنسټه `bool` ته د (mutable) حواله جوړه کړې!
    ///     // دا غیر تعریف شوی چلند دی.⚠️
    /// }
    /// ```
    ///
    /// د مثال په توګه ، تاسو نشئ کولی بې اختیاره شوي بفر ته [`Read`]:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) بې بنسټه یادونې ته مراجعه!
    ///                             // دا غیر تعریف شوی چلند دی.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// او نه هم تاسو کولی شئ د ځمکې په سطحه تدریجي پیل کولو لپاره د ساحې مستقیم لاسرسی وکاروئ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) بې بنسټه یادونې ته مراجعه!
    ///                  // دا غیر تعریف شوی چلند دی.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) بې بنسټه یادونې ته مراجعه!
    ///                  // دا غیر تعریف شوی چلند دی.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): موږ دا مهال پورتني غلط باندې تکیه کوو ، د بیلګې په توګه ، موږ بې بنسټه معلوماتو ته مراجعه لرو (د مثال په توګه په `libcore/fmt/float.rs` کې).
    // موږ باید د ثبات څخه دمخه د مقرراتو په اړه وروستۍ پریکړه وکړو.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` پیل شوی.
        // دا د دې معنی هم لري چې `self` باید د `value` ډول ولري.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// د `MaybeUninit` کانټینرونو له یو صف څخه ارزښتونه راوباسي.
    ///
    /// # Safety
    ///
    /// دا زنګ وهونکي پورې اړه لري چې تضمین ورکړي چې د صفونو ټول عناصر په پیل شوي حالت کې دي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // خوندي: اوس خوندي دی لکه څنګه چې موږ ټول عناصر پیل کړل
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * زنګ وهونکی تضمین کوي چې د صفونو ټول عناصر پیل شوي دي
        // * `MaybeUninit<T>` او T تضمین لري چې ورته ترتیب ولري
        // * شاید یونټ ډراپ نه کړي ، نو هیڅ ډول ډبل آزادونه شتون نلري او پدې توګه بدلون خوندي دی
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// فرض کړئ چې ټول عناصر یې پیل شوي دي ، دوی ته یوه ټوټه ترلاسه کړئ.
    ///
    /// # Safety
    ///
    /// دا زنګ وهونکي پورې اړه لري چې تضمین ورکړي چې د `MaybeUninit<T>` عناصر واقعیا په پیل شوي حالت کې دي.
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د نا څرګند چلند لامل کیږي.
    ///
    /// د نورو جزیاتو او مثالونو لپاره [`assume_init_ref`] وګورئ.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // امنیت: `*const [T]` ته د ټوټې ټوټه کول خوندي دي ځکه چې زنګ وهونکی تضمین کوي
        // `slice` پیل شوی ، او `MaybeUninit` تضمین شوی چې د `T` ورته ب layoutه ولري.
        // ترلاسه شوی نښې باوري دي ځکه چې دا د `slice` ملکیت حافظې ته اشاره کوي کوم چې دا یو حواله ده او پدې توګه د لوستلو لپاره د اعتبار وړ تضمین شتون لري.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// فرض کړئ چې ټول عناصر یې پیل شوي دي ، دوی ته د بدلون وړ سلیس ترلاسه کړئ.
    ///
    /// # Safety
    ///
    /// دا زنګ وهونکي پورې اړه لري چې تضمین ورکړي چې د `MaybeUninit<T>` عناصر واقعیا په پیل شوي حالت کې دي.
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د نا څرګند چلند لامل کیږي.
    ///
    /// د نورو جزیاتو او مثالونو لپاره [`assume_init_mut`] وګورئ.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // خوندي: د `slice_get_ref` لپاره د خوندیتوب یادښتونو ته ورته ، مګر موږ یو
        // د بدلون وړ حواله چې د لیکلو لپاره د اعتبار وړ هم ده.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// د صف د لومړي عنصر ته اشاره ورکوي.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// د صفونو لومړي عنصر ته د تغیر وړ نښه ورکول کیږي.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// د `src` څخه `this` ته عناصر کاپي کوي ، د `this` اوسني پیل شوي مینځپانګې ته د بدلون وړ حواله راستنوي.
    ///
    /// که `T` `Copy` نه پلي کوي ، نو [`write_slice_cloned`] وکاروئ
    ///
    /// دا د [`slice::copy_from_slice`] سره ورته دی.
    ///
    /// # Panics
    ///
    /// دا فنکشن به panic وي که چیرې دوه ټوټې مختلف اوږدوالی ولري.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // امنیت: موږ د لین ټول عناصر په اضافي ظرفیت کې کاپي کړي
    /// // د Vec لومړي src.len() عناصر اوس معتبر دي.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // خوندي: &[T] او&[شایدUninit<T>] ورته ب haveه ولرئ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // خوندي: باوري عنصرونه یوازې په `this` کې کاپي شوي نو دا اصلي دی
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// د `src` څخه `this` ته عناصر کلون کوي ، د `this` اوسني پیل شوي مینځپانګې ته د بدلون وړ حواله راستنوي.
    /// هر څه دمخه ارثیت شوي عناصر به ونه غورځول شي.
    ///
    /// که `T` `Copy` تطبیقوي ، نو [`write_slice`] وکاروئ
    ///
    /// دا د [`slice::clone_from_slice`] سره ورته دی مګر موجود عناصر نه غورځوي.
    ///
    /// # Panics
    ///
    /// دا فنکشن به panic که چیرې دوه ټوټې مختلف اوږدوالی ولري ، یا که د `Clone` panics پلي کول.
    ///
    /// که چیرې panic شتون ولري ، دمخه کلون شوي عناصر به له مینځه ویسي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // امنیت: موږ یوازې د لین ټول عناصر په اضافي ظرفیت کې کلون کړي دي
    /// // د Vec لومړي src.len() عناصر اوس معتبر دي.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // د copy_from_slice برعکس دا په سلیس کې کلون_فرم_سلیس نه بولي ځکه چې `MaybeUninit<T: Clone>` کلون نه پلي کوي.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // خوندي: پدې خام ټوټه کې به یوازې پیل شوي توکي شامل وي
                // له همدې امله ، دا د پریښودو اجازه ده.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: موږ اړتیا لرو چې دا په روښانه ډول ورته ورته اوږدوالي ته ټوټې کړو
        // د حدود چیک کولو لپاره چې اړین وي ، او اصلاح کونکي به د ساده قضیو لپاره میکسي تولید کړي (د مثال په توګه T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // محافظ ته اړتیا ده b/c panic ممکن د کلون په جریان کې پیښ شي
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // خوندي: باوري عنصرونه یوازې په `this` کې لیکل شوي نو دا پیل شوی دی
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}