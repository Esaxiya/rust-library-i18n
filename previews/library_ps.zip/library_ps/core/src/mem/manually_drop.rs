use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// یو ریپر چې د automatically T` تخریب کونکي په اوتومات ډول زنګ وهلو څخه تالیف کونکی مخنیوی کوي.
/// دا ریپر د 0-قیمت دی.
///
/// `ManuallyDrop<T>` د `T` په څیر د ورته ترتیب اصلاح لپاره تابع دی.
/// د پایلې په توګه ، دا په انګیرنې باندې هیڅ اغیزه نلري * کوم چې جوړونکی د هغې مینځپانګې په اړه کوي.
/// د مثال په توګه ، د [`mem::zeroed`] سره د `ManuallyDrop<&mut T>` پیل غیر تعریف شوی چلند دی.
/// که تاسو بې بنسټه ډاټا اداره کولو ته اړتیا لرئ ، پرځای یې [`MaybeUninit<T>`] وکاروئ.
///
/// په یاد ولرئ چې د `ManuallyDrop<T>` دننه ارزښت لاسرسی خوندي دی.
/// دا پدې مانا ده چې `ManuallyDrop<T>` چې مینځپانګه پرې شوې باید د عامه خوندي API له لارې ښکاره نشي.
/// په ورته ډول ، `ManuallyDrop::drop` غیر محفوظ دی.
///
/// # `ManuallyDrop` د غورځولو امر.
///
/// Rust د [drop order] ارزښتونو ښه تعریف شوی.
/// د دې لپاره چې ډاډ ترلاسه شي چې ساحې یا ځایی خلک په یو ځانګړي ترتیب کې غورځول شوي ، اعلامیې یې تنظیم کړئ لکه د قطع کولو حکم درست دی.
///
/// دا امکان لري چې د غورځیدو امر کنټرول لپاره `ManuallyDrop` وکاروئ ، مګر دا غیر محفوظ کوډ ته اړتیا لري او د نه منلو په موجودیت کې په سمه توګه ترسره کول سخت دي.
///
///
/// د مثال په توګه ، که تاسو غواړئ ډاډ ترلاسه کړئ چې مشخص ساحه د نورو وروسته راښکته کیږي ، نو دا د جوړښت وروستی ډګر جوړ کړئ:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` د `children` وروسته به غورځول کیږي.
///     // Rust تضمین ورکوي چې ساحې د اعلان په ترتیب کې غورځول شوي.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// د ځان د غورځولو لپاره ارزښت وپلټئ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // تاسو لاهم کولی شئ په خوندي ډول په ارزښت کار وکړئ
    /// assert_eq!(*x, "Hello");
    /// // مګر `Drop` به دلته ونه چلول شي
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// د `ManuallyDrop` کانټینر څخه ارزښت راوباسي.
    ///
    /// دا اجازه راکوي چې ارزښت بیرته واخیستل شي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // دا د `Box` راټیټوي.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// د `ManuallyDrop<T>` کانټینر څخه ارزښت اخلي.
    ///
    /// دا میتود اساسا په ډراپ کې د ارزښتونو حرکت کولو لپاره دی.
    /// د [`ManuallyDrop::drop`] کارولو پرځای د دې لپاره چې لاسي لاس واخلئ ، تاسو کولی شئ دا طریقه وکاروئ ترڅو ارزښت واخلئ او که څه هم مطلوب یې وکاروئ.
    ///
    /// هرکله چې امکان ولري ، د [`into_inner`][`ManuallyDrop::into_inner`] پرځای کارول غوره دي ، کوم چې د `ManuallyDrop<T>` مینځپانګې نقل کولو مخه نیسي.
    ///
    ///
    /// # Safety
    ///
    /// دا فنکشن په ناڅاپي ډول پاتې ارزښت بهر کاروي پرته لدې چې د نورو کارولو مخه ونیسي ، د دې کانتینر حالت بدلیږي.
    /// دا ستاسو مسؤلیت دی چې ډاډ ترلاسه کړئ چې دا `ManuallyDrop` بیا نه کارول کیږي.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // خوندي: موږ له یوې حوالې څخه لوستو ، کوم چې تضمین دی
        // د لوستلو لپاره د اعتبار وړ وي.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// موجود ارزښت په لاسي ډول غورځوي.دا په بشپړ ډول د [`ptr::drop_in_place`] تلیفون کولو ته مساوي دی چې موجود ارزښت ته د نښې سره.
    /// د ورته په څیر ، پرته لدې چې ارزښت شتون یو کڅوړی جوړښت وي ، نو ناشونی به د ارزښت له حرکت کولو پرته په ځای کې بلل کیږي ، او پدې توګه د [pinned] ډیټا په خوندي ډول کارولو لپاره کارول کیدی شي.
    ///
    /// که تاسو د ارزښت ملکیت لرئ ، نو تاسو یې پرځای [`ManuallyDrop::into_inner`] وکاروئ.
    ///
    /// # Safety
    ///
    /// دا فنکشن د موجود ارزښت تخریب کونکي چلوي.
    /// د پخپله د ویجاړونکي لخوا رامینځته شوي بدلونونو پرته ، حافظه هیڅ بدله پاتې ده ، او تر هغه ځایه چې کمپیلر پورې اړه لري لاهم یو څه ب patternه لري چې د `T` ډول لپاره مناسب دی.
    ///
    ///
    /// په هرصورت ، دا د "zombie" ارزښت باید خوندي کوډ ته افشا نشي ، او دا فنکشن باید له یو ځل څخه ډیر ونه بلل شي.
    /// د ارزښت د راټیټیدو وروسته کارول ، یا یو ځل څو ځله ارزښت غورځول ، د نا تایید شوي چلند لامل کیدی شي (پدې پورې اړه لري چې `drop` څه کوي).
    /// دا په نورمال ډول د ډول سیسټم لخوا مخنیوی کیږي ، مګر د `ManuallyDrop` کاروونکي باید دا تضمینونه د تالیف کونکي مرستې پرته وساتي.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // خوندي: موږ د بدلون غوښتونکي ارزښت لخوا اشاره شوي ارزښت پریږدو
        // کوم چې د لیکلو لپاره د اعتبار وړ تضمین دی.
        // دا زنګ وهونکي پورې اړه لري ترڅو ډاډ ترلاسه کړي چې `slot` بیا له سره نه غورځول کیږي.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}