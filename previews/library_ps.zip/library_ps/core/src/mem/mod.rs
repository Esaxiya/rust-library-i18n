//! د حافظې سره معامله کولو لپاره بنسټیز دندې.
//!
//! په دې ماډل کې د ډولونو اندازې او ایلیینټ پوښتنې ، د حافظې پیل او مینځلو لپاره دندې شامل دي.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// د **ارزښت په اړه مالکیت او "forgets" اخلي پرته د دې تخریبونکي** پرمخ وړي.
///
/// هرې سرچینې چې ارزښت اداره کوي ، لکه د هپ حافظې یا د فایل هینڈل به د تل لپاره د لاسرسۍ وړ حالت کې پاتې وي.په هرصورت ، دا تضمین نه کوي چې دې حافظې ته اشارې به د اعتبار وړ وي.
///
/// * که تاسو غواړئ حافظه لیک کړئ ، نو [`Box::leak`] وګورئ.
/// * که تاسو غواړئ حافظې ته خامو اشاره ترلاسه کړئ ، نو [`Box::into_raw`] وګورئ.
/// * که تاسو غواړئ یو ارزښت په سمه توګه بې ځایه کړئ ، د دې ویجاړونکي چلول ، [`mem::drop`] وګورئ.
///
/// # Safety
///
/// `forget` د `unsafe` په نښه شوی ندی ، ځکه چې د Rust د خوندیتوب تضمین کې داسې تضمین شتون نلري چې ویجاړونکي به یې تل چلوي.
/// د مثال په توګه ، برنامه کولی شي د [`Rc`][rc] په کارولو سره د حویلۍ رامینځته شی رامینځته کړي ، یا [`process::exit`][exit] ته زنګ ووهي ترڅو د تخریبونکو پرمخ بیولو لپاره وځي.
/// پدې توګه ، د خوندي کوډ څخه `mem::forget` ته اجازه ورکول د Rust د خوندیتوب تضمین په بنسټیز ډول نه بدلوي.
///
/// دې وویل ، د سرچینو غځول لکه حافظه یا I/O توکي اکثرا ناپسندیدونکي دي.
/// اړتیا د FFI یا غیر خوندي کوډ لپاره په ځینې ځانګړي کارول شوي قضیو کې راځي ، مګر بیا هم ، [`ManuallyDrop`] عموما غوره دی.
///
/// ځکه چې د ارزښت هیرول اجازه لري ، هر `unsafe` کوډ چې تاسو یې لیکئ باید د دې امکان لپاره اجازه ورکړئ.تاسو نشئ کولی ارزښت بیرته راشئ او تمه وکړئ چې زنګ وهونکی به اړین د ارزښت ویجاړونکی پرمخ بوځي.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// د `mem::forget` کینونیکي خوندي کارول د `Drop` trait لخوا پلي شوي د ارزښت تخریب کونکي مخنیوی لپاره دی.د مثال په توګه ، دا به یو `File` لیک کړي ، یعنی
/// د متغیر لخوا نیول شوی ځای بیرته ادعا کړئ مګر هیڅکله د اصلي سیستم زیرمې بند مه کوئ:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// دا ګټور دی کله چې د زیرمې زیرمې ملکیت دمخه د Rust څخه بهر کوډ ته لیږدول شوی و ، د مثال په توګه د C کوډ ته د خام فایل توضیحي لیږدلو سره.
///
/// # د `ManuallyDrop` سره اړیکه
///
/// پداسې حال کې چې `mem::forget` د *حافظې* ملکیت لیږدولو لپاره هم کارول کیدی شي ، نو دا کار کول د خطا وړ دي.
/// [`ManuallyDrop`] پرځای باید وکارول شي.د مثال په توګه ، دا کوډ په پام کې ونیسئ:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // د `v` مینځپانګې په کارولو سره `String` جوړ کړئ
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // د `v` لیک ځکه چې د دې حافظه اوس د `s` لخوا اداره کیږي
/// mem::forget(v);  // ERROR، v ناباوره دی او باید فنکشن ته ونه لیږدول شي
/// assert_eq!(s, "Az");
/// // `s` په ناباوره توګه غورځول شوی او د دې حافظه له منځه تللې ده.
/// ```
///
/// د پورتني مثال سره دوه مسلې شتون لري:
///
/// * که چیرې د `String` جوړولو او `mem::forget()` بلنې تر مینځ نور کوډ اضافه شوی وای ، نو پدې کې یو panic به د دوه ګونی آزادیدو لامل شي ځکه چې ورته حافظه د `v` او `s` دواړه لخوا اداره کیږي.
/// * د `v.as_mut_ptr()` زنګ وهلو او `s` ته د معلوماتو ملکیت لیږد وروسته ، د `v` ارزښت ناباوره دی.
/// حتی کله چې یو ارزښت یوازې `mem::forget` ته لیږدول کیږي (کوم چې به یې نه معاینه کوي) ، ځینې ډولونه د دوی په ارزښتونو سختې اړتیاوې لري چې دا غیر معلول کوي کله چې ځنګل کیږي یا نور ملکیت نلري.
/// په هر ډول د ناقانونه ارزښتونو کارول ، په شمول د دوی څخه دندې یا دندو څخه بیرته راګرځول ، غیر تعریف شوی چلند رامینځته کوي او ممکن د تالیف کونکي لخوا انګیرنې مات کړي.
///
/// `ManuallyDrop` ته بدلول دواړه مسلې مخنیوی کوي:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // مخکې لدې چې موږ د دې خام برخو کې `v` جلا کړئ ، ډاډ ترلاسه کړئ چې دا له لاسه نه وځي!
/////
/// let mut v = ManuallyDrop::new(v);
/// // اوس د `v` جلا کول.دا عملیات panic نشي کولی ، نو دلته لیک نشي کیدی.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // په نهایت کې ، `String` جوړ کړئ.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` په ناباوره توګه غورځول شوی او د دې حافظه له منځه تللې ده.
/// ```
///
/// `ManuallyDrop` په کلکه د دوه ګونی څخه مخنیوی کوي ځکه چې موږ د بل څه کولو دمخه د تخریب کونکي معلول کوو.
/// `mem::forget()` دې ته اجازه مه ورکوئ ځکه چې دا خپل دلیل مصرفوي ، موږ مجبور کوو چې موږ د `v` څخه موږ ته اړتیا لرونکي هر هغه شی استخراج کولو وروسته یوازې دا تلیفون وکړو.
/// حتی که چیرې د panic د `ManuallyDrop` جوړولو او تار رامینځته کولو ترمینځ معرفي شوی وي (کوم چې په کوډ کې پیښ نشي لکه څنګه چې ښودل شوي) ، دا به د لیک لامل شي او نه ډبل آزاد.
/// په بل عبارت ، `ManuallyDrop` د (ډبل) ځنډیدو پرځای د غلطیدو پرځای د لیک په څنګ کې تیروتنه کوي.
///
/// همچنان ، `ManuallyDrop` موږ ته د "touch" `v` درلودو څخه مخنیوی کوي `s` ته د ملکیت لیږدولو وروسته-د `v` سره د تعامل وروستۍ مرحله د دې د تخریب کونکي پرمخ وړلو پرته تصفیه کول په بشپړ ډول مخنیوی دی.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// د [`forget`] په څیر ، مګر غیر منل شوي ارزښتونه هم مني.
///
/// دا فنکشن یوازې یو شیم دی چې د لرې کولو اراده لري کله چې د `unsized_locals` ب featureه ثبات شي.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// په بایټونو کې د ډول ډول راګرځوي.
///
/// په ځانګړي ډول ، دا په صف کې د متقابلو عناصرو په مینځ کې آفسیټ دی چې د ورته توکی سره د ساحاتو د پیډینګ په شمول.
///
/// پدې توګه ، د هر ډول `T` او اوږدوالي `n` لپاره ، `[T; n]` د `n * size_of::<T>()` اندازه لري.
///
/// په عموم کې ، د ډول اندازه اندازه د تالیفونو په اوږدو کې مستحکم ندي ، مګر مشخص ډولونه لکه لومړني دي.
///
/// لاندې جدول د لومړي ځل لپاره اندازه ورکوي.
///
/// ډول |اندازه_او: :<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 چار |.
///
/// سربیره پردې ، `usize` او `isize` ورته اندازه لري.
///
/// `*const T` ، `&T` ، `Box<T>` ، `Option<&T>` ، او `Option<Box<T>>` ډولونه یو شان اندازه لري.
/// که `T` اندازه شي ، نو دا ټول ډولونه د `usize` په اندازه ورته اندازه لري.
///
/// د نښې بدلېدل خپله اندازه نه بدلوي.د ورته په څیر ، `&T` او `&mut T` ورته اندازه لري.
/// په ورته ډول د `*const T` او `* mut T` لپاره.
///
/// # د `#[repr(C)]` توکو اندازه
///
/// د توکو لپاره د `C` نمایش یو ټاکل شوی ترتیب لري.
/// د دې ترتیب سره ، د توکو اندازه هم ثبات لري تر هغه چې ټول ساحې مستحکم اندازه ولري.
///
/// ## د فشارونو اندازه
///
/// د `structs` لپاره ، اندازه د لاندې الګوریتم لخوا ټاکل کیږي.
///
/// په جوړښت کې د هرې برخې لپاره د اعلامیې امر لخوا ترتیب شوی:
///
/// 1. د ساحې اندازه اضافه کړئ.
/// 2. د اوسني اندازې حد د بل ډګر د [alignment] نږدې ډیری ته ولټوئ.
///
/// په نهایت کې ، د جوړښت اندازه د دې د [alignment] نږدې ډیری ته راوباسئ.
/// د جوړښت سیده د معمول له مخې د دې ټولو ساحو ترټولو لوی سمون دی؛دا د `repr(align(N))` کارولو سره بدل کیدی شي.
///
/// د `C` برعکس ، د صفر اندازې سټرکونه د اندازې له یوې یوې بایټ څخه تر ګردې شوي ندي.
///
/// ## د Enums اندازه
///
/// هیمونه چې د امتیاز پرته بل هیڅ معلومات نه لیږدوي په ورته پلیټ فارم کې د C enums په څیر ورته اندازې لري چې دوی یې لپاره ترکیب شوي.
///
/// ## د اتحادیو اندازه
///
/// د اتحادیې اندازه د هغې ترټولو لوی ساحې اندازه ده.
///
/// د `C` په خلاف ، د صفر اندازې اتحادیې د اندازې له یوې یوې بایټ څخه نه جوړېږي.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // ځینې لومړني
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // ځینې تیرونه
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // د نښې اندازه برابرۍ
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// د `#[repr(C)]` کارول.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // د لومړي ساحې اندازه 1 ده ، نو 1 اندازې ته اضافه کړئ.اندازه 1 ده.
/// // د دوهم ساحې سیده 2 ده ، نو د تختو لپاره اندازې ته 1 اضافه کړئ.اندازه 2 ده.
/// // د دوهم ډګر اندازه 2 ده ، نو 2 اندازه ته یې اضافه کړئ.اندازه 4 ده.
/// // د دریمې ساحې سیده 1 ده ، نو 0 د تختو لپاره اندازې ته اضافه کړئ.اندازه 4 ده.
/// // د دریمې برخې اندازه 1 ده ، نو 1 کچې ته اضافه کړئ.اندازه 5 ده.
/// // په نهایت کې ، د جوړښت ساحه 2 ده (ځکه چې د دې د ساحو تر مینځ ترټولو لوی سیدل 2 دی) ، نو د تختو لپاره اندازې ته 1 اضافه کړئ.
/// // اندازه 6 ده.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // د ټوپک جوړښتونه ورته مقررات تعقیبوي.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // په یاد ولرئ چې د ساحو تنظیم کول کولی شي اندازه ټیټه کړي.
/// // موږ کولی شو د `second` دمخه د `third` په ساتلو سره دواړه ګادنې بایټونه لرې کړو.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // د اتحادیې اندازه د ترټولو لوی ځمکې اندازه ده.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// په ټکو کې د ټکي-ارزښت ارزښت اندازه ورکوي.
///
/// دا معمولا د `size_of::<T>()` په څیر دی.
/// په هرصورت ، کله چې `T` * هیڅ د احصایې نه پیژندل شوی اندازه نلري ، د بیلګې په توګه ، یو سلیس [`[T]`][slice] یا [trait object] ، نو بیا د `size_of_val` د متحرک پیژندل شوي اندازې ترلاسه کولو لپاره کارول کیدی شي.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // خوندي: `val` یو حواله ده ، نو دا یو معتبر خام نښې دي
    unsafe { intrinsics::size_of_val(val) }
}

/// په ټکو کې د ټکي-ارزښت ارزښت اندازه ورکوي.
///
/// دا معمولا د `size_of::<T>()` په څیر دی.په هرصورت ، کله چې `T` * هیڅ د احصایې نه پیژندل شوی اندازه نلري ، د بیلګې په توګه ، یوه سلیس [`[T]`][slice] یا [trait object] ، نو بیا د `size_of_val_raw` د متحرک پیژندل شوي اندازې ترلاسه کولو لپاره کارول کیدی شي.
///
/// # Safety
///
/// دا فنکشن یوازې د تلیفون کولو لپاره خوندي دی که لاندې شرایط ولري:
///
/// - که `T` `Sized` وي ، نو دا فنکشن تل د زنګ وهلو لپاره خوندي دی.
/// - که چیرې د `T` غیر منقوله جوړه وي:
///     - یو `isize`، بیا د سلیزې دم اوږدوالی باید لومړنی عدد وي ، او د * بشپړ ارزښت اندازه (د متحرک دم اوږدوالی + د احصایوي اندازې سابقه) باید په `isize` کې فټ شي.
///     - یو [trait object] ، بیا د نښې وتلی برخه باید باوري ویتبل ته په نښه کړي چې د نه قابو کولو فشار لخوا اخیستل شوی ، او د *بشپړ ارزښت* اندازه (د متحرک دم اوږدوالي + جامد اندازې سابقه) باید په `isize` کې فټ شي.
///
///     - یو (unstable) [extern type] ، بیا دا فنکشن تل د زنګ وهلو لپاره خوندي دی ، مګر ممکن panic یا بل ډول غلط ارزښت بیرته راشي ، ځکه چې د بهرني ډول ترتیب نه پیژندل کیږي.
///     دا د ایکس00 ایکس په څیر ورته چلند دی چې د بیروني ډول دم سره د نوعې په حواله.
///     - بل پلو ، دا په محافظه توګه اجازه نلري چې دا فنکشن ته زنګ ووهي.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // خوندي: زنګ وهونکی باید یو معتبر خامو اشاره چمتو کړي
    unsafe { intrinsics::size_of_val(val) }
}

/// د [ABI] لږترلږه لږترلږه د سم ډول سمون راستنوي.
///
/// د `T` ډول ډول ارزښت ته هر مراجعه باید د دې شمیرو ډیری وي.
///
/// دا د سید ساحو لپاره کارول کیږي.دا ممکن د ټاکل شوي صف څخه کوچنی وي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// د [ABI] ترالسه شوي لږترلږه د هغه ډول ډول سمون ته بیرته راګرځي چې `val` په ګوته کوي.
///
/// د `T` ډول ډول ارزښت ته هر مراجعه باید د دې شمیرو ډیری وي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // خوندي: وال حواله ده ، نو دا یو معتبر خام نخښه ده
    unsafe { intrinsics::min_align_of_val(val) }
}

/// د [ABI] لږترلږه لږترلږه د سم ډول سمون راستنوي.
///
/// د `T` ډول ډول ارزښت ته هر مراجعه باید د دې شمیرو ډیری وي.
///
/// دا د سید ساحو لپاره کارول کیږي.دا ممکن د ټاکل شوي صف څخه کوچنی وي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// د [ABI] ترالسه شوي لږترلږه د هغه ډول ډول سمون ته بیرته راګرځي چې `val` په ګوته کوي.
///
/// د `T` ډول ډول ارزښت ته هر مراجعه باید د دې شمیرو ډیری وي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // خوندي: وال حواله ده ، نو دا یو معتبر خام نخښه ده
    unsafe { intrinsics::min_align_of_val(val) }
}

/// د [ABI] ترالسه شوي لږترلږه د هغه ډول ډول سمون ته بیرته راګرځي چې `val` په ګوته کوي.
///
/// د `T` ډول ډول ارزښت ته هر مراجعه باید د دې شمیرو ډیری وي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// دا فنکشن یوازې د تلیفون کولو لپاره خوندي دی که لاندې شرایط ولري:
///
/// - که `T` `Sized` وي ، نو دا فنکشن تل د زنګ وهلو لپاره خوندي دی.
/// - که چیرې د `T` غیر منقوله جوړه وي:
///     - یو `isize`، بیا د سلیزې دم اوږدوالی باید لومړنی عدد وي ، او د * بشپړ ارزښت اندازه (د متحرک دم اوږدوالی + د احصایوي اندازې سابقه) باید په `isize` کې فټ شي.
///     - یو [trait object] ، بیا د نښې وتلی برخه باید باوري ویتبل ته په نښه کړي چې د نه قابو کولو فشار لخوا اخیستل شوی ، او د *بشپړ ارزښت* اندازه (د متحرک دم اوږدوالي + جامد اندازې سابقه) باید په `isize` کې فټ شي.
///
///     - یو (unstable) [extern type] ، بیا دا فنکشن تل د زنګ وهلو لپاره خوندي دی ، مګر ممکن panic یا بل ډول غلط ارزښت بیرته راشي ، ځکه چې د بهرني ډول ترتیب نه پیژندل کیږي.
///     دا د ایکس00 ایکس په څیر ورته چلند دی چې د بیروني ډول دم سره د نوعې په حواله.
///     - بل پلو ، دا په محافظه توګه اجازه نلري چې دا فنکشن ته زنګ ووهي.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // خوندي: زنګ وهونکی باید یو معتبر خامو اشاره چمتو کړي
    unsafe { intrinsics::min_align_of_val(val) }
}

/// د `T` ډوله ارزښتونو غورځولو په صورت کې `true` راستنوي.
///
/// دا په بشپړ ډول د اصلاح کولو نښه ده ، او ممکن په محافظه کار ډول پلي شي:
/// دا ممکن د ډولونو لپاره `true` بیرته راولي چې واقعیا یې غورځولو ته اړتیا نلري.
/// لکه څنګه چې تل د `true` بیرته راستنیدل به د دې کړنې معتبر پلي کول وي.په هرصورت که دا فن په حقیقت کې `false` بیرته راولي ، نو تاسو ممکن ډاډه اوسئ چې `T` پریښودل هیڅ اړخیزه اغیزه نلري.
///
/// د شیانو ټیټه کچه پلي کول لکه راټولونه ، کوم چې پخپله د دوی ډاټا پریښودلو ته اړتیا لري ، دا فنکشن باید وکاروي ترڅو غیر ضروري هڅه وکړي د دوی ټولې مینځپانګې پریږدي کله چې دوی ویجاړ شي.
///
/// دا ممکن د خوشې کولو جوړښتونو کې توپیر ونلري (چیرې چې یو لوپ چې هیڅ اړخیزې اغیزې نلري په اسانۍ سره کشف او له مینځه وړل کیږي) ، مګر اکثرا د ډیبګ جوړونو لپاره لویه بریا ده.
///
/// په یاد ولرئ چې [`drop_in_place`] دمخه دا چک ترسره کوي ، نو که ستاسو د کار کولو اندازه د [`drop_in_place`] تلیفونونو لږ شمیر ته راټیټه شي ، نو د دې کارول غیر ضروري دي.
/// په ځانګړي ډول په یاد ولرئ چې تاسو کولی شئ سلیس [`drop_in_place`] کړئ ، او دا به د ټولو ارزښتونو لپاره یو واحد اړتیاوې_ پیراډ چیک کړي.
///
/// د Vec په څیر ډولونه نو ځکه د `needs_drop` توضیحي کارولو پرته یوازې `drop_in_place(&mut self[..])`.
/// د [`HashMap`] په څیر ډولونه ، له بل پلوه ، باید په یو وخت کې یو ځل ارزښتونه وباسي او باید دا API وکاروي.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// دلته یوه بېلګه ده چې څنګه کولی شي ټولګه د `needs_drop` کاروي:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // معلومات راکښته کړئ
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// د `T` ډول ارزښت د صفر بایټ نمونې لخوا نمایندګي کوي.
///
/// دا پدې مانا ده چې ، د مثال په توګه ، په `(u8, u16)` کې د پیډینګ بایټ اړینه نه ده چې صفر شوې وي.
///
/// هیڅ تضمین شتون نلري چې د صفر بایټ نمونه د ځینې ډول `T` معتبر ارزښت استازیتوب کوي.
/// د مثال په توګه ، د ټولو صفر بایټ پیټرن د حوالې ډولونو (`&T` ، `&mut T`) او دندو اشارو لپاره معتبر ارزښت ندی.
/// په دا ډول ډولونو کې د `zeroed` کارول د سمدستي [undefined behavior][ub] لامل کیږي ځکه چې [the Rust compiler assumes][inv] چې تل په تغیر کې یو معتبر ارزښت شتون لري چې دا ابتدایی ګ .ي.
///
///
/// دا د [`MaybeUninit::zeroed().assume_init()`][zeroed] په څیر ورته تاثیر لري.
/// دا ځینې وختونه د FFI لپاره ګټور دی ، مګر په عمومي ډول باید مخنیوی وشي.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// د دې فنکشن درست استعمال: د صفر سره عدد پیل کول.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *د دې فعالیت غلط* کارول: د صفر سره د حوالې پیل کول.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // بې ټاکي چلند!
/// let _y: fn() = unsafe { mem::zeroed() }; // او بیا!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // خوندي: زنګ وهونکی باید تضمین وکړي چې د صفر ټول ارزښت د `T` لپاره د اعتبار وړ دی.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// د Rust عادي حافظې-ابتدايي چک بایپسیز د `T` ډول ډول ارزښت تولیدولو په پلمه چیک کوي پداسې حال کې چې هیڅ هیڅ نه کوي.
///
/// **دا فنکشن تخفیف شوی.** د دې پرځای [`MaybeUninit<T>`] وکاروئ.
///
/// د تخریب کولو دلیل دا دی چې فعالیت اساسا نشي کارول کیدلی: دا د [`MaybeUninit::uninit().assume_init()`][uninit] په څیر ورته تاثیر لري.
///
/// لکه څنګه چې [`assume_init` documentation][assume_init] تشریح کوي ، [the Rust compiler assumes][inv] چې ارزښتونه په سم ډول پیل شوي.
/// د پایلې په توګه ، زنګ وهل مثال
/// `mem::uninitialized::<bool>()` د `bool` بیرته راستنیدو لپاره سمدستي نامعلومه چلند رامینځته کوي چې حتما نه `true` یا `false` نه وي.
/// بدتر ، واقعیا بې بنسټه حافظه لکه هغه څه چې دلته بیرته راځي ځانګړي دي په دې کې تالیف کونکي پوهیږي چې دا یو ثابت ارزښت نلري.
/// دا دا غیر متناسب سلوک رامینځته کوي چې په متغیر کې غیر منسجم شوي ډاټا ولري حتی که چیرې دا بدله یو بشپړ ډول ولري.
/// (په پام کې ونیسئ چې د غیر منحل کونکو انټرنیټونو په اړه مقررات لاهم نهایی شوي ، مګر تر هغه چې دوی وي ، نو د دې څخه باید مخنیوی وشي.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // خوندي: زنګ وهونکی باید تضمین وکړي چې د یو واحد شوی ارزښت د `T` لپاره د اعتبار وړ دی.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// ارزښتونه په دوه اړونده ځایونو کې بدل کړئ ، پرته له دې چې یو یې هم تشخیص کړئ.
///
/// * که تاسو غواړئ د ډیفالټ یا ډمی ارزښت سره بدل کړئ ، نو [`take`] وګورئ.
/// * که تاسو غواړئ د تېر شوي ارزښت سره تغیر وکړئ ، زاړه ارزښت بیرته راستانه کړئ ، [`replace`] وګورئ.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // خوندي: خام نښې د خوندي تغیر وړ مآخذونو څخه رامینځته شوي چې ټول د رضایت وړ دي
    // په `ptr::swap_nonoverlapping_one` محدودیتونه
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` د `T` د ډیفالټ ارزښت سره بدلوي ، د پخواني `dest` ارزښت بیرته راستنوي.
///
/// * که تاسو غواړئ د دوه متغیر ارزښتونو ځای په ځای کړئ ، نو [`swap`] وګورئ.
/// * که تاسو غواړئ د ډیفالټ ارزښت پرځای تایید شوي ارزښت سره ځای ورکړئ ، نو [`replace`] وګورئ.
///
/// # Examples
///
/// یو ساده مثال:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` د "empty" ارزښت سره د دې په ځای کولو سره د جوړښت ساحې ملکیت اخیستلو ته اجازه ورکوي.
/// د `take` پرته تاسو کولی شئ پدې ډول مسلو ته ورشئ:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// په یاد ولرئ چې `T` لازمي ډول [`Clone`] نه پلي کوي ، نو دا حتی د `self.buf` کلون او بیا ځای نشی کولی.
/// مګر `take` د X002 څخه د `self.buf` اصلي ارزښت جلا کولو لپاره کارول کیدی شي ، دا بیرته راستنیدو ته اجازه ورکوي:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` په حواله شوي `dest` کې خوځوي ، د پخواني `dest` ارزښت بیرته راستنوي.
///
/// هیڅ ارزښت نه راکول کیږي.
///
/// * که تاسو غواړئ د دوه متغیر ارزښتونو ځای په ځای کړئ ، نو [`swap`] وګورئ.
/// * که تاسو غواړئ د ډیفالټ ارزښت سره ځای ونیسئ ، نو [`take`] وګورئ.
///
/// # Examples
///
/// یو ساده مثال:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` د یو بل ارزښت سره د دې په ځای کولو سره د جوړښت ساحې مصرف ته اجازه ورکوي.
/// د `replace` پرته تاسو کولی شئ پدې ډول مسلو ته ورشئ:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// په یاد ولرئ چې `T` لازمي ډول [`Clone`] نه پلي کوي ، نو موږ حتی نشو کولی د حرکت مخه ونیسئ `self.buf[i]` کلون وکړئ.
/// مګر `replace` د `self` څخه پدې شاخص کې اصلي ارزښت جلا کولو لپاره کارول کیدی شي ، دا بیرته راستنیدو ته اجازه ورکوي:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // خوندي: موږ د `dest` څخه لوستل مګر په مستقیم ډول وروسته پدې کې `src` لیکو ،
    // داسې چې زوړ ارزښت یې نه دی نقل شوی.
    // هیڅ شی نه غورځول شوی او هیڅ شی دلته panic نشي کولی.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// د ارزښت ضایع کول.
///
/// دا د [`Drop`][drop] د دلیل پلي کولو غږولو سره کوي.
///
/// دا په مؤثره توګه د ډولونو لپاره هیڅ نه کوي کوم چې `Copy` پلي کوي ، د بیلګې په توګه
/// integers.
/// دا ډول ارزښتونه کاپي کیږي او _then_ په فنکشن کې حرکت کوي ، نو ارزښت د دې فنکشن زنګ وروسته دوام لري.
///
///
/// دا کار جادو نه دی؛دا په لفظي ډول تعریف شوي
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// ځکه چې `_x` په فنکشن کې لیږدول شوی ، دا د فعالیت بیرته راستنیدو دمخه په اوتومات ډول غورځول کیږي.
///
/// [drop]: Drop
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // په څرګنده توګه vector وغورځوئ
/// ```
///
/// له هغه وخته چې [`RefCell`] په وخت کې د پور قواعد پلي کوي ، نو `drop` کولی شي د [`RefCell`] پور خوشې کړي:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // په دې سلاټ کې د بدلون وړ بدلون بیرته راوګرځئ
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// انټيجرز او نور ډولونه چې د [`Copy`] پلي کوي د `drop` لخوا اغیزمن ندي.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // د `x` کاپي لیږدول شوی او راکښته شوی دی
/// drop(y); // د `y` کاپي لیږدول شوی او راکښته شوی دی
///
/// println!("x: {}, y: {}", x, y.0); // تراوسه موجوددی
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` د `&U` ډول لرونکي په توګه تشریح کوي ، او بیا وروسته د موجود ارزښت حرکت کولو پرته `src` لوستل کوي.
///
/// دا فنکشن به په خوندي توګه تثبیت کړي `src` د `&T` بایټس لپاره د `&T` `&U` ته لیږدولو او بیا د `&U` لوستلو سره معتبر دی (په استثنا د دې سربیره دا سمه ده حتی که `&U` د `&T` په پرتله د سخت سمون اړتیاوې رامینځته کړي).
/// دا به په خوندي ډول د `src` څخه بهر حرکت کولو پرځای د موجود ارزښت یوه کاپي رامینځته کړي.
///
/// دا د تالیف وخت تېروتنه نده که `T` او `U` مختلف اندازې ولري ، مګر دا خورا هڅول کیږي چې یوازې دا فعالیت وغواړي چیرې چې `T` او `U` ورته اندازه لري.دا فعالیت [undefined behavior][ub] محرکوي که چیرې `U` د `T` څخه لوی وي.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // له 'foo_array' څخه ډاټا کاپي کړئ او د 'Foo' په توګه یې چلند وکړئ
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // کاپي شوي ډاټا بدل کړئ
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // د 'foo_array' مینځپانګه باید بدله نکړي
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // که چیرې U لوړه د سمون اړتیا ولري ، src ممکن مناسب مناسب نه وي.
    if align_of::<U>() > align_of::<T>() {
        // خوندي: `src` یو حواله ده چې تضمین یې د لوستلو لپاره د اعتبار وړ وي.
        // زنګ وهونکی باید تضمین وکړي چې اصلي لیږد خوندي دی.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // خوندي: `src` یو حواله ده چې تضمین یې د لوستلو لپاره د اعتبار وړ وي.
        // موږ یوازې چیک کړی چې `src as *const U` په سمه توګه تنظیم شوی و.
        // زنګ وهونکی باید تضمین وکړي چې اصلي لیږد خوندي دی.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// د اوپک ډول د اینوم امتیاز څرګندوي.
///
/// د نورو معلوماتو لپاره پدې ماډل کې د [`discriminant`] فعالیت وګورئ.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. دا trait تطبیقات نشي ګټلی ځکه چې موږ په T باندې هیڅ حد نه غواړو.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// په `v` کې د انیم ډول په ځانګړي ډول پیژندلو ارزښت بیرته راولي.
///
/// که `T` انوم نه وي ، د دې فعالیت په ویلو سره به د غیر تعریف شوي چلند پایله ونلري ، مګر د بیرته ستنیدو ارزښت نامعلومه دی.
///
///
/// # Stability
///
/// د اینوم ډول سره توپیر کولی شي بدل شي که چیرې د اینم تعریف بدل شي.
/// د ځینې ډولونو امتیاز به د ورته تالیف کونکي سره تالیفونو ترمینځ بدل نشي.
///
/// # Examples
///
/// دا د هغه انیمونو پرتله کولو لپاره کارول کیدی شي چې معلومات لیږدوي پداسې حال کې چې ریښتیني ډیټا په پام کې نه نیسي:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// د اینوم ډول `T` کې د مختلفو ډولونو راستنوي.
///
/// که `T` انوم نه وي ، د دې فعالیت په ویلو سره به د غیر تعریف شوي چلند پایله ونلري ، مګر د بیرته ستنیدو ارزښت نامعلومه دی.
/// مساوي ، که `T` د `usize::MAX` څخه ډیر ډولونو سره اینوم دی د بیرته ستنیدو ارزښت ټاکل شوی نه دی.
/// بې ځایه ډولونه به حساب شي.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}