//! د `Clone` trait د ډولونو لپاره چې نشي کولی په کاپي سره کاپي شي.
//!
//! په Rust کې ، ځینې ساده ډولونه "implicitly copyable" دي او کله چې تاسو دوی ګومارئ یا ورته د دلیلونو په توګه ورکړئ ، نو ترلاسه کونکی به یوه کاپي ترلاسه کړي ، اصلي ارزښت په ځای کې پریږدئ.
//! دا ډولونه د کاپي کولو لپاره تخصیص ته اړتیا نلري او نهایی نه لري (د بیلګې په توګه ، دوی مالکیت لرونکي بکسونه نلري یا [`Drop`] پلي کوي) ، نو تالیف کونکي دوی ارزانه او د کاپي کولو لپاره خوندي ګ .ي.
//!
//! د نورو ډولونو لپاره باید کاپي باید په واضح ډول جوړه شي ، د کنوانسیون لخوا د [`Clone`] trait پلي کول او د [`clone`] میتود زنګ وهلو سره.
//!
//! [`clone`]: Clone::clone
//!
//! د کارولو لومړني مثال:
//!
//! ```
//! let s = String::new(); // د سټینګ ډول کلون پلي کوي
//! let copy = s.clone(); // نو موږ دا کلون کولی شو
//! ```
//!
//! د کلون trait په اسانۍ سره پلي کولو لپاره ، تاسو کولی شئ `#[derive(Clone)]` هم وکاروئ.مثال:
//!
//! ```
//! #[derive(Clone)] // موږ کلون trait د مورفیس سټریک ته اضافه کوو
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // او اوس موږ دا کلون کولی شو!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// د یو شي په څرګند ډول د نقل کولو وړتیا لپاره یو عام trait.
///
/// د [`Copy`] څخه توپیر پدې کې چې [`Copy`] ضمیمه او خورا ارزانه وي ، پداسې حال کې چې `Clone` تل روښانه وي او ممکن ممکن وي یا نه وي.
/// د دې ځانګړتیاو پلي کولو لپاره ، Rust تاسو ته اجازه نه ورکوي [`Copy`] ریمپلیټ کړئ ، مګر تاسو ممکن `Clone` اصلاح کړئ او پخپل سري کوډ چل کړئ.
///
/// لکه څنګه چې `Clone` د [`Copy`] څخه ډیر عمومي دی ، نو تاسو کولی شئ په اتوماتيک ډول هرڅه [`Copy`] هم کړئ `Clone` هم.
///
/// ## Derivable
///
/// دا trait د `#[derive]` سره کارول کیدی شي که چیرې ټولې برخې `Clone` وي.د [`Clone`] `ډیروالي پلي کول په هر ډګر کې [`clone`] بولي.
///
/// [`clone`]: Clone::clone
///
/// د عمومي جوړښت لپاره ، `#[derive]` په عمومي ډول `Clone` تطبیقوي په عمومي پیرامیټونو کې د پابند `Clone` اضافه کولو سره.
///
/// ```
/// // `derive` د لوستلو لپاره کلون تطبیقوي<T>کله چې T کلون وي.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## زه څنګه کولی شم `Clone` تطبیق کړم؟
///
/// ډولونه چې د [`Copy`] دي باید د `Clone` کوچني تطبیق ولري.نور په رسمي ډول:
/// که `T: Copy` ، `x: T` ، او `y: &T` وي ، نو `let x = y.clone();` د `let x = *y;` سره مساوي دی.
/// لارښود پلي کول باید د دې یرغلګر ساتلو لپاره محتاط وي؛په هرصورت ، غیر خوندي کوډ باید پدې باندې تکیه ونکړي ترڅو د حافظې خوندیتوب ډاډمن شي.
///
/// یوه بیلګه یو عمومي جوړښت دی چې د فعالیت ښودونکی لري.پدې حالت کې ، د `Clone` پلي کول نشي کیدی ، مګر په لاندې ډول پلي کیدی شي:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## اضافي پلي کونکي
///
/// د [implementors listed below][impls] سربیره ، لاندې ډولونه هم د `Clone` پلي کوي:
///
/// * د فنکشن توکی ډولونه (د بیلګې په توګه ، د هر فعالیت لپاره ټاکل شوی مختلف ډولونه)
/// * د فعالیت د ښودونکي ډولونه (د بیلګې په توګه ، `fn() -> i32`)
/// * د صفونو ډولونه ، د ټولو اندازو لپاره ، که د توکي ډول هم `Clone` تطبیق کړي (د مثال په توګه ، `[i32; 123456]`)
/// * د دوه ډوله ډولونه ، که هر جز `Clone` هم پلي کوي (د مثال په توګه ، `()` ، `(i32, bool)`)
/// * د بندولو ډولونه ، که چیرې دوی د چاپیریال څخه هیڅ ارزښت لاسته نه راوړي یا دا ټول نیول شوي ارزښتونه پخپله `Clone` پلي کوي.
///   په یاد ولرئ چې د مشترکو حوالې لخوا نیول شوي تغیرات تل د `Clone` پلي کوي (حتی که چېرته یې هم نه وي) ، پداسې حال کې چې د متغیر حوالې لخوا نیول شوي تغیرات هیڅکله `Clone` نه پلي کوي.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// د ارزښت یوه کاپي راولي.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str کلون تطبیقوي
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// د `source` څخه کاپي ګمارنه ترسره کوي.
    ///
    /// `a.clone_from(&b)` په فعالیت کې د `a = b.clone()` سره مساوي دی ، مګر د `a` سرچینې بیا کارولو لپاره ودرول شي ترڅو د غیر ضروري تخصیصونو مخه ونیول شي.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// د trait `Clone` د تطبیق وړ میکرو تولید.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): دا سلسلې په بشپړ ډول د#[اخل شوي] لخوا کارول کیږي ترڅو دا ثابته کړي چې د نوعې هر جز کلون یا کاپي پلي کوي.
//
//
// دا سلسلې باید هیڅکله د کارونکي کوډ کې څرګند نشي.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// د لومړني ډولونو لپاره د `Clone` پلي کول.
///
/// تطبیقات چې په Rust کې توضیح کیدی نشي په `rustc_trait_selection` کې په `traits::SelectionContext::copy_clone_conditions()` کې پلي کیږي.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// شریک شوي مآخذونه کلون کیدلی شي ، مګر بدلیدونکي حوالې *نشي* کیدی
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// شریک شوي مآخذونه کلون کیدلی شي ، مګر بدلیدونکي حوالې *نشي* کیدی
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}