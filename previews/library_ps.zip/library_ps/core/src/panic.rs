//! Panic ملاتړ په معیاري کتابتون کې.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// یو جوړښت چې د panic په اړه معلومات چمتو کوي.
///
/// `PanicInfo` جوړښت د 0panic hook ته د [`set_hook`] فنکشن لخوا ټاکل شوی ته سپارل کیږي.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// د panic سره تړلی تادیه بیرته راوړي.
    ///
    /// دا به عام وي ، مګر تل نه ، `&'static str` یا [`String`] وي.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// که د `core` crate څخه د `panic!` میکرو (د `std` نه) د فارمیټ سټینګ او ځینې اضافي دلیلونو سره کارول شوی و ، نو دا پیغام بیرته راوړي چې د مثال په توګه د [`fmt::write`] سره وکارول شي
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// د هغه ځای په اړه معلومات بیرته راولي چې له کومه ځایه panic سرچینه کړې ، که شتون ولري.
    ///
    /// دا طریقه به دا مهال تل [`Some`] بیرته راشي ، مګر دا ممکن د future نسخو کې بدل شي.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: که دا ځینې وختونه هیڅکله بیرته راستنیدو ته بدل شي ،
        // په std::panicking::default_hook او std::panicking::begin_panic_fmt کې د دې قضیې سره معامله وکړئ.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: موږ نشو کارول کیدلی<String>() دلته
        // ځکه چې سټینګ په لیبر کې شتون نلري!
        // تادیه یو سټینګ دی کله چې `std::panic!` د ډیری دلیلونو سره ویل کیږي ، مګر پدې حالت کې پیغام هم شتون لري.
        //

        self.location.fmt(formatter)
    }
}

/// یو داسې جوړښت چې د panic موقعیت په اړه معلومات لري.
///
/// دا جوړښت د [`PanicInfo::location()`] لخوا رامینځته شوی.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// د مساواتو او ترتیب کولو لپاره پرتله کول په فایل ، کرښه ، بیا د کالم لومړیتوب کې رامینځته شوي.
/// فایلونه د تارونو په څیر پرتله کیږي ، نه `Path` ، کوم چې ناڅاپي کیدی شي.
/// د نورو بحث لپاره د [: : ځای::فایل`] اسناد وګورئ.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// د دې دندې زنګ وهونکي د سرچینې موقعیت راستنوي.
    /// که چیرې د فنکشن زنګ وهونکی تشریح شي نو د هغې د زنګ ځای به بیرته راشي ، او داسې نور د غیر تعقیب شوي فعالیت غړي کې لومړي کال ته سټیک اپ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] په کوم کې چې ورته ویل کیږي بیرته راګرځي.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// د دې فعالیت تعریف کې دننه څخه [`Location`] راستنوي.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // په یو بل ځای کې د ورته ناتړل شوي فنکشن چلول موږ ته ورته پایلې راکوي
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // په مختلف ځای کې د تعقیب شوي فعالیت چلول یو مختلف ارزښت رامینځته کوي
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// د سرچینې فایل نوم راټولیږي چې له هغه ځایه panic سرچینه کړې.
    ///
    /// # `&str`, نه `&Path`
    ///
    /// راستنیدونکی نوم د تالیف سیسټم کې سرچینې ته اشاره کوي ، مګر دا معقول ندي چې دا د `&Path` په توګه په مستقیم ډول استازیتوب وکړي.
    /// تالیف شوی کوډ ممکن په مختلف سیسټم کې پرمخ وړل شي د `Path` پلي کولو سره د سیسټم مینځپانګې چمتو کولو پراساس او دا کتابتون اوس مهال مختلف "host path" ډول نلري.
    ///
    /// خورا د حیرانتیا وړ چلند واقع کیږي کله چې د "the same" فایل د انډول سیسټم کې د ګ pathو لارو له لارې د لاسرسي وړ وي (معمولا د `#[path = "..."]` خاصیت یا ورته ورته کارولو سره) ، کوم چې د دې لامل کیدی شي کوم څه چې ورته فعالیت څخه بیلابیل ارزښتونه بیرته راوړي.
    ///
    ///
    /// # Cross-compilation
    ///
    /// دا ارزښت د `Path::new` یا ورته جوړونکو ته د تیریدو لپاره مناسب ندي کله چې کوربه پلیټ فارم او هدف پلیټ فارم توپیر ولري.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// د کرښې شمیره راټولیږي چې له هغه څخه panic سرچینه کړې.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// کالم بیرته راولي له کوم ځای څخه چې panic سرچینه اخیستې.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// یو داخلي trait د لیبسټډ لخوا کارول شوی د معلوماتو له لیبسټډ څخه تر `panic_unwind` او نورو panic ځلې وختونو ته انتقالوي.
/// د دې لپاره ندی چې ژر ژر هرکله ثبات شي ، مه کاروئ.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// د مینځپانګو بشپړ ملکیت واخلئ.
    /// د راستنیدو ډول په حقیقت کې `Box<dyn Any + Send>` دی ، مګر موږ نشو کولی په لیبر کې `Box` وکاروو.
    ///
    /// وروسته له دې چې دا طریقه وبلل شوه ، یوازې په `self` کې ځینې جعلي ډیفالټ ارزښت پاتې دی.
    /// د دې میتود دوه ځله زنګ وهل ، یا د دې میتود له زنګ وهلو وروسته د `get` زنګ وهل یوه تېروتنه ده.
    ///
    /// دلیل پور اخیستل شوی ځکه چې د panic رنټیم (`__rust_start_panic`) یوازې پور اخیستل شوی `dyn BoxMeUp` ترلاسه کوي.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// یوازې مینځپانګې پور کړئ.
    fn get(&mut self) -> &(dyn Any + Send);
}