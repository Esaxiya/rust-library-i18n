//! د تیرونو لپاره د `IntoIter` ملکیت تکرارونکی ټاکي.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// د ارزښت له مخې [array] تکرارونکی.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// دا هغه صف دی چې موږ یې تکرار کوو.
    ///
    /// د شاخص `i` سره عنصر چیرته چې `alive.start <= i < alive.end` تر دې دمه ترلاسه شوي ندي او د اعتبار وړ سرنو نښې دي.
    /// د شاخصونو `i < alive.start` یا `i >= alive.end` سره عناصر لا دمخه ترلاسه شوي او نور باید لاسرسی ونلري!دا وژل شوي عناصر حتی په بشپړ ډول بې بنسټه حالت کې وي!
    ///
    ///
    /// نو بریدګر داسې دي:
    /// - `data[alive]` ژوندی دی (د مثال په توګه معتبر عنصر)
    /// - `data[..alive.start]` او `data[alive.end..]` مړ شوي (د مثال په توګه عناصر لا دمخه لوستل شوي وو او باید نور لاس ورنشي!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// په `data` کې هغه عناصر چې تراوسه ندي ترلاسه شوي.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ورکړل شوي `array` باندې نوی تیتر جوړوي.
    ///
    /// *یادونه*: دا طریقه ممکن په [`IntoIterator` is implemented for arrays][array-into-iter] وروسته ، په future کې تخریب شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // د `value` ډول دلته د `&i32` پرځای `i32` دی
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // خوندي: دلته لیږد په حقیقت کې خوندي دی.د `MaybeUninit` لاسوندونه
        // promise:
        //
        // > `MaybeUninit<T>` د ورته اندازې او صف برابرۍ تضمین دی
        // > لکه د `T`.
        //
        // لاسوندونه حتی د `MaybeUninit<T>` له یو سرسي څخه د `T` سریز ته لیږد ښیې.
        //
        //
        // د دې سره ، دا ابتکار بریدګر راضي کوي.

        // FIXME(LukasKalbertodt): په حقیقت کې دلته `mem::transmute` وکاروئ ، یوځل چې دا د جنټ جنرکونو سره کار کوي:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // تر دې دمه ، موږ کولی شو `mem::transmute_copy` د مختلف ډول په څیر د بټ واټ کاپي رامینځته کولو لپاره وکاروو ، بیا `array` هیر کړئ ترڅو دا له مینځه نه وی وړل شوی.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// د ټولو عناصرو غیر متناسب ټوټې بیرته راولي چې تراوسه ندي ترلاسه شوي.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // خوندي: موږ پوهیږو چې د `alive` دننه ټول عناصر په سم ډول پیل شوي.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// د ټولو عناصرو متغیر ټوټې بیرته راولي چې تراوسه ندي ترلاسه شوي.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // خوندي: موږ پوهیږو چې د `alive` دننه ټول عناصر په سم ډول پیل شوي.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // راتلونکی شاخص د مخکښې څخه ترلاسه کړئ.
        //
        // د 1 لخوا د `alive.start` زیاتوالی د `alive` په اړه بریدګر ساتي.
        // په هرصورت ، د دې بدلون له امله ، د لنډ وخت لپاره ، ژوندي زون اوس `data[alive]` ندی ، مګر `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // عنصر له سرې څخه ولولئ.
            // خوندي: `idx` د X پخواني "alive" سیمې کې شاخص دی
            // صف.د دې عنصر لوستل پدې معنی دي چې `data[idx]` اوس د مړي په توګه پیژندل کیږي (د بیلګې په توګه مه ټکوئ).
            // لکه څنګه چې `idx` د ژوندي زون پیل و ، ژوندي زون اوس یوځل بیا `data[alive]` دی ، ټول بریدګر بیرته نیسي.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // راتلونکی شاخص د شا څخه ترلاسه کړئ.
        //
        // د 1 لخوا د `alive.end` کمول د `alive` په اړه تیاری ساتي.
        // په هرصورت ، د دې بدلون له امله ، د لنډ وخت لپاره ، ژوندي زون اوس `data[alive]` ندی ، مګر `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // عنصر له سرې څخه ولولئ.
            // خوندي: `idx` د X پخواني "alive" سیمې کې شاخص دی
            // صف.د دې عنصر لوستل پدې معنی دي چې `data[idx]` اوس د مړي په توګه پیژندل کیږي (د بیلګې په توګه مه ټکوئ).
            // لکه څنګه چې `idx` د ژوندي زون پای و ، ژوندي زون اوس یوځل بیا `data[alive]` دی ، د ټولو بریدګرو ساتل.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // خوندي: دا خوندي دی: `as_mut_slice` بالکل فرعي ټوټه بیرته راستنوي
        // د هغو عناصرو چې تراوسه نه ویستل شوی او پاتې کیدی شی.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // هیڅکله به د بریدګر `live.start <=له امله د اوبو لاندې نه وي
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// تکرار کونکی واقعیا د درست اوږدوالي راپور ورکوي.
// د "alive" عناصرو شمیر (کوم چې به بیا هم لاسته راوړل شي) د `alive` حدود اوږدوالی دی.
// دا حد په `next` یا `next_back` کې په اوږدوالي کې کم شوی.
// دا تل په ورته میتودونو کې 1 لخوا کم شوی ، مګر یوازې که `Some(_)` بیرته راشي.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // یادونه ، موږ واقعیا اړتیا نه لرو د ورته ورته ژوندي سلسلې سره مطابقت وکړو ، نو موږ یوازې د آفسیټ 0 کې کلون کولی شو پرته لدې چې د `self` چیرې وي.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // ټول ژوندي عناصر کلون کړئ.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // نوي صف کې یو کلون ولیکئ ، بیا یې د ژوندي رینج تازه کړئ.
            // که چیرې د panics کلون کول ، موږ به سم توکي پخواني توکي پریږدو.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // یوازې هغه عناصر چاپ کړئ چې تراوسه ندي ترلاسه شوي: موږ نور حاصل شوي عناصرو ته لاسرسی نه شو کولی.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}