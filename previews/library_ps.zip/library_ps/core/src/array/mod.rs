//! د شیانو پلي کول لکه د یوې اندازې اوږدوالي تیرې لپاره د `Eq` په څیر.
//! په نهایت کې ، موږ باید وړتیا ولرو چې اوږدوالي ته یې عمومي کړو.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// د `T` ته مراجعه د لمبې 1 سرې ته مآخذ ته اړوي (د کاپي کولو پرته).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // خوندي: د `&T` `&[T; 1]` ته اړول سم دي.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// د `T` ته د بدلون اړونده مبایل بدلولو ته د 1 لمبرې سرې ته بدلیږي (د کاپي کولو پرته).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // خوندي: د `&mut T` `&mut [T; 1]` ته اړول سم دي.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// یوټیلیټ trait یوازې د ټاکل شوي اندازې تیرونو باندې تطبیق شوی
///
/// دا trait کولی شي د ZDtraits0Z نور پلي کولو لپاره وکارول شي پرته له دې چې د ډیر میټاډاټا بلات لامل شي.
///
/// trait غیر خوندي نښه شوی ترڅو پلي کونکي د اندازې اندازې تیرونو ته محدود کړي.
/// د دې trait یو کارونکی کولی شي فرض کړي چې پلي کونکي د ټاکلې اندازې صفونو په یاد کې دقیق ب layoutه لري (د بیلګې په توګه ، د غیر خوندي پیل لپاره).
///
///
/// په یاد ولرئ چې traits [`AsRef`] او [`AsMut`] د ډولونو لپاره ورته میتودونه وړاندې کوي چې ممکن د اندازې اندازې تیرې نشي.
/// پلي کونکي باید د دې پرځای هغه traits غوره کړي.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// سرنی په ناقانونه ټوټې بدلوي
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// سرنی بدلیږي ټوټې ته اړوي
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// د خطا ډول بیرته راګرځیدلی کله چې له سلایس څخه یوې سري ته اړول ناکام شي.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // خوندي: سمه ده ځکه چې موږ یوازې چیک کړی چې اوږدوالی مناسب دی
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // خوندي: سمه ده ځکه چې موږ یوازې چیک کړی چې اوږدوالی مناسب دی
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: د کوډ بلاټ کمولو لپاره ځینې لږ مهم وړاندیزونه له مینځه وړل شوي
// ____پل__ژوند_ق_q!{ [A; $N], &'b [B; $N] } __mpl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// د تیرونو [lexicographically](Ord#lexicographical-comparison) پرتله پرتله کول.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// د ډیفالټ غوښتنې د قوي جینرونو سره نشي ترسره کیدی ځکه چې `[T; 0]` ډیفالټ پلي کولو ته اړتیا نلري ، او د مختلف شمیرو لپاره د بیلابیلو پروپوزلونو بلاکونه لاهم ندي ملاتړ شوي.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// د `self` په څیر د ورته اندازې صف راولی ، د `f` فعالیت سره په هر عنصر کې په ترتیب سره پلي شوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // خوندي: موږ د ډاډ لپاره پوهیږو چې دا تکرار کونکی به په سمه توګه `N` ترلاسه کړي
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'زیپ اپ' دوه قطارونو جوړو په یو واحد صف کې.
    ///
    /// `zip()` نوی صف راشي چیرته چې هر عنصر یو ګونګه وي چیرې چې لومړی عنصر له لومړي سر څخه راځي ، او دوهم عنصر د دویم صف څخه راځي.
    ///
    /// په بل عبارت ، دا یوځای کې دوه سریزونه یوځای کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // خوندي: موږ د ډاډ لپاره پوهیږو چې دا تکرار کونکی به په سمه توګه `N` ترلاسه کړي
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// یوه سلیس راستنوي چې ټوله صف پکې لري.د `&s[..]` سره مساوي.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// د بدلون وړ سلیس راستنوي چې ټوله صف کې لري.
    /// د `&mut s[..]` سره مساوي.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// هر عنصر پور اخلي او د ورته اندازې سره د `self` په څیر د حوالو یو لړ راستنوي.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// دا میتود په ځانګړي ډول ګټور دی که د نورو میتودونو سره یوځای وي ، لکه [`map`](#method.map).
    /// پدې توګه ، تاسو کولی شئ د اصلي صف حرکت کولو څخه مخنیوی وکړئ که چیرې د دې عناصر `Copy` نه وي.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // موږ لاهم اصلي صف ته لاسرسی کولی شو: دا حرکت نه دی شوی.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // خوندي: موږ د ډاډ لپاره پوهیږو چې دا تکرار کونکی به په سمه توګه `N` ترلاسه کړي
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// هر عنصر په متقابل ډول پور اخلي او د `self` ورته اندازې سره د بدلون وړ مآخذونو لړ کې راشي.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // خوندي: موږ د ډاډ لپاره پوهیږو چې دا تکرار کونکی به په سمه توګه `N` ترلاسه کړي
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// د `N` توکي د `iter` څخه وباسي او د صف په توګه یې بیرته راولي.
/// که چیرې تکرار کونکي د `N` توکي څخه لږ عاید ترلاسه کړي ، نو دا فعالیت غیر تعریف شوي چلند څرګندوي.
///
///
/// د نورو معلوماتو لپاره [`collect_into_array`] وګورئ.
///
/// # Safety
///
/// دا زنګ وهونکي پورې اړه لري چې تضمین ورکړي چې `iter` لږترلږه `N` توکي ترلاسه کوي.
/// د دې حالت سرغړونه د نه ټاکل شوي چلند لامل کیږي.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` دلته یو څه تجربه ده.دا یوازې یو دی
    // داخلي فعالیت ، نو د لرې کولو لپاره وړیا احساس وکړئ که دا حد یو بد نظر شي.
    // پدې حالت کې ، په یاد ولرئ چې لاندې `debug_assert!` ښکته حد هم لرې کړئ!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // خوندي: د فعالیت قرارداد لخوا پوښل شوی.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// د `N` توکي د `iter` څخه وباسي او د صف په توګه یې بیرته راولي.که چیرې تکرار کونکي د `N` توکو څخه لږ عاید ترلاسه کړي ، نو `None` بيرته راستون شو او ټول دمخه تولید شوي توکي راخیستل شوي.
///
/// له هغه ځایه چې تکرار کونکی د متغیره حوالې په توګه لیږدول شوی او دا فعالیت په `next` ډیر وخت `N` وخت کې تلیفون کوي ، نو بیا پاتې کیدونکی د وروسته پاتې توکو بیرته راټولولو لپاره کارول کیدی شي.
///
///
/// که `iter.next()` کښیناست ، ټول توکي چې دمخه د تکرار کونکي لخوا مینځ ته راوړل شوي.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // : AnFY::empty An empty arrayray always always always. inhab...... no and. no. no. no valid.. inv .arian... has.....
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // خوندي: پدې خام ټوټه کې به یوازې پیل شوي توکي شامل وي.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // خوندي: `guard.initialized` په 0 پیل کیږي ، په کې د یو لخوا ډیر شوی
        // یوځل چې N ته رسیږي (او کوم چې `array.len()`) دی) لوپ او لپ لغو کیږي.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // وګوره که ټوله صف پیل شوی وي.
        if guard.initialized == N {
            mem::forget(guard);

            // خوندي: د پورتنی حالت ډاډ ورکوي چې ټول عناصر دي
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // دا یوازې هغه وخت رسیږي که چیرې تکرار کونکی د `guard.initialized` `N` ته رسیدو دمخه ستړی شوی وي.
    //
    // دا هم په یاد ولرئ چې `guard` دلته غورځول شوی ، ټول دمخه پیل شوي عناصر یې غورځوي.
    None
}