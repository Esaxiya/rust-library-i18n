//! لومړني traits او ډولونه د ډولونو لومړني ملکیت نمایندګي کوي.
//!
//! د Rust ډولونه د دوی داخلي ملکیتونو مطابق په مختلف ګټورو لارو کې طبقه بندي کیدی شي.
//! دا طبقه بندي د traits په توګه ښودل کیږي.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ډولونه چې د تار حدونو کې لیږدول کیدی شي.
///
/// دا trait په اوتومات ډول تطبیق کیږي کله چې تالیف کونکي دا مناسب کړي.
///
/// د غیر `سینډ` ډول مثال د حوالې شمېرنې مرکز [`rc::Rc`][`Rc`] دی.
/// که چیرې دوه سلسلې د [`Rc`] s کلون هڅه کوي چې ورته ریفرنس-شمیرل شوي ارزښت ته اشاره وکړي ، دوی ممکن په ورته وخت کې د حوالې شمیره تازه کولو هڅه وکړي ، کوم چې [undefined behavior][ub] دی ځکه چې X01 اټومي عملیات نه کاروي.
///
/// د دې د تره/لور [`sync::Arc`][arc] اټومي عملیات کاروي (د یو څه سر پواسطه) او پدې توګه `Send` دی.
///
/// د نورو جزیاتو لپاره [the Nomicon](../../nomicon/send-and-sync.html) وګورئ.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// ډولونه د ثابت اندازه اندازې سره چې د کمپیل په وخت کې پیژندل شوي.
///
/// ټول ډول پیرامیټونه د `Sized` یو متقابل حد لري.ځانګړی ترکیب `?Sized` د دې حدود لرې کولو لپاره کارول کیدی شي که مناسب نه وي.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // جوړښت FooUse(Foo<[i32]>)؛//خطا: اندازه د [i32] لپاره ندي پلي شوي
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// یو استثنا د trait ضمیمه `Self` ډول دی.
/// یو trait ناباوره `Sized` پابند نه لري ځکه چې دا د [trait څیز] s سره مطابقت نلري چیرې چې ، د تعریف له مخې ، trait د ټولو ممکنه پلي کونکو سره کار کولو ته اړتیا لري ، او پدې توګه کوم اندازه کیدی شي.
///
///
/// که څه هم Rust به تاسو ته اجازه درکړي `Sized` Z8trait0Z سره وتړئ ، تاسو به ونه توانئ چې وروسته د trait څیز جوړولو لپاره وکاروئ:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // راځه y: &dyn بار= &Impl؛//خطا: trait `Bar` نشی کولی شي
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // د ډیفالټ لپاره ، د مثال په توګه ، کوم چې اړتیا لري `[T]: !Default` د ارزونې وړ وي
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// ډولونه چې د متحرک اندازې ډول ته "unsized" کیدی شي.
///
/// د مثال په توګه ، د اندازې سرې ډول `[i8; 2]` `Unsize<[i8]>` او `Unsize<dyn fmt::Debug>` پلي کوي.
///
/// د `Unsize` ټول پلي کول د کمپلر لخوا پخپله چمتو شوي.
///
/// `Unsize` د دې لپاره پلي کیږي:
///
/// - `[T; N]` دا `Unsize<[T]>` دی
/// - `T` `Unsize<dyn Trait>` دی کله چې `T: Trait`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` دی که:
///   - `T: Unsize<U>`
///   - Foo یو جوړښت دی
///   - یوازې د `Foo` وروستی ډګر د `T` ښکیل ډول لري
///   - `T` د نورو نورو برخو د ډول برخه نده
///   - `Bar<T>: Unsize<Bar<U>>`, که د `Foo` وروستی ډګر د `Bar<T>` ډول ولري
///
/// `Unsize` د [`ops::CoerceUnsized`] سره کارول کیږي د "user-defined" کانټینرونو لکه [`Rc`] ته اجازه ورکوي چې متحرک ډول لرونکي ډولونه ولري.
/// د نورو جزیاتو لپاره [DST coercion RFC][RFC982] او [the nomicon entry on coercion][nomicon-coerce] وګورئ.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// د نمونو میچونو کې کارول شوي ثابتونو لپاره اړین trait دی.
///
/// هر ډول چې د `PartialEq` ترلاسه کوي په اتومات ډول دا trait تطبیقوي ، پرته له دې چې د دې ډول پیرامیټونو `Eq` تطبیق کړي.
///
/// که چیرې د `const` توکي یو څه ډول ولري چې دا trait نه تطبیقوي ، نو بیا دا ډول (1.) `PartialEq` نه پلي کوي (پدې معنی چې دا به د پرتله کولو میتود چمتو نکړي ، کوم کوډ تولید ګumesل شتون لري) ، یا (2.) دا خپل تطبیق کوي * * د `PartialEq` نسخه (کوم چې موږ ګ .و د جوړښتي-مساواتو پرتله کولو سره سمون نلري).
///
///
/// په پورتني دوه سناریوګانو کې ، موږ د نمونې میچ کې د داسې ثابت کار کارول رد کوو.
///
/// [structural match RFC][RFC1445] ، او [issue 63438] هم وګورئ چې د دې trait ته د خاصیت پر اساس ډیزاین څخه مهاجرت هڅوي.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// د نمونو میچونو کې کارول شوي ثابتونو لپاره اړین trait دی.
///
/// هر ډول چې د `Eq` ترلاسه کوي په اتومات ډول دا trait پلي کوي ، پرته لدې چې د دې ډول پیرامیټونو `Eq` تطبیق کړي.
///
/// دا زموږ په ډول سیسټم کې د محدودیت شاوخوا کار کولو لپاره هیک دی.
///
/// # Background
///
/// موږ غواړو ورته اړتیا ولرو چې نمونې میچونو کې کارول شوي ډولونه د `#[derive(PartialEq, Eq)]` خاصیت لري.
///
/// په ډیر مثالي نړۍ کې ، موږ کولی شو دا اړتیا د دې په چیک کولو سره چیک کړو چې ورکړل شوی ډول دواړه د `StructuralPartialEq` trait *او*`Eq` trait دواړه پلي کوي.
/// په هرصورت ، تاسو کولی شئ ADTs ولرئ چې *یې کوي*`derive(PartialEq, Eq)` ، او داسې قضیه وي چې موږ تالیف کونکي ومنو ، او تر دې دمه د دوام ډول د `Eq` پلي کولو کې پاتې راځي.
///
/// د مثال په توګه ، داسې قضیه:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (په پورتني کوډ کې ستونزه دا ده چې `Wrap<fn(&())>` `PartialEq` نه پلي کوي ، او نه `Eq` ، ځکه چې <<'a> fn(&'a _)` does not implement those traits.) لپاره
///
/// له همدې امله ، موږ نشو کولی د `StructuralPartialEq` او یوازې `Eq` لپاره په ناداره چیک باندې تکیه وکړو.
///
/// د دې شاوخوا کار کولو لپاره د هیک په توګه ، موږ دوه جلا traits کاروو چې د هر یو دوه X (`#[derive(PartialEq)]` X او `#[derive(Eq)]`) لخوا انجیکشن شوي او چیک یې کوو چې دواړه د جوړښت-میچ چیک کولو برخې په توګه شتون لري.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ډولونه چې ارزښتونه یې د بټونو په کاپي کولو سره ساده کیدلی شي.
///
/// په ډیفالټ ، متغیر تړلو کې د 'حرکت سیمانټیکونه' شتون لري.په نورو ټکو:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` په `y` کې خوځیدلی ، او له دې امله نشي کارول کیدی
///
/// // چاپلین! ("{: ؟}"، x)؛//خطا: د لیږد شوي ارزښت کارول
/// ```
///
/// په هرصورت ، که یو ډول `Copy` تطبیق کړي ، دا یې پرځای 'کاپي سیمینټکس' لري:
///
/// ```
/// // موږ کولی شو د `Copy` تطبیق ترلاسه کړو.
/// // `Clone` هم اړین دی ، ځکه چې دا د `Copy` سوپر ټرایټ دی.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` د `x` کاپي ده
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// دا مهمه ده چې یادونه وکړئ چې پدې دوه مثالونو کې ، یوازینۍ توپیر دا دی چې ایا تاسو د ګمارنې وروسته `x` لاسرسی ته اجازه لرئ.
/// د هود لاندې ، دواړه کاپي او حرکت کولی شي بټونه په حافظه کې کاپي شي ، که څه هم دا ځینې وختونه غوره کیږي.
///
/// ## زه څنګه کولی شم `Copy` تطبیق کړم؟
///
/// ستاسو په ب onه د `Copy` پلي کولو لپاره دوه لارې شتون لري.د `derive` کارول خورا اسانه دی:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// تاسو کولی شئ د `Copy` او `Clone` لاسي پلي کړئ:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// د دواړو تر مینځ یو کوچنی توپیر شتون لري: د `derive` تګلاره به د `Copy` ډول په پیرامیټونو پورې وتړي ، کوم چې تل مطلوب ندي.
///
/// ## د `Copy` او `Clone` ترمنځ څه توپیر دی؟
///
/// کاپي په مبهم ډول پیښیږي ، د مثال په توګه د سپړنې `y = x` برخې برخې په توګه.د `Copy` چلند د پورته کولو وړ ندي؛دا تل یو ساده بټ وار کاپي دی.
///
/// کلونینګ یو څرګند عمل دی ، `x.clone()`.د [`Clone`] پلي کول کولی شي هر ډول ځانګړی چلند چمتو کړي چې د خوندي کولو ارزښتونو جعل کولو لپاره اړین وي.
/// د مثال په توګه ، د [`String`] لپاره د [`Clone`] پلي کول اړین دي چې په ګیډۍ کې د نښې-توضیحي بفر کاپي کړي.
/// د [`String`] ارزښتونو یو ساده بټوایس کاپي به یوازې د نښې کاپي وکړي ، د لاین له مخې ډبل آزاد کیدو لامل کیږي.
/// د دې دلیل لپاره ، [`String`] [`Clone`] دی مګر `Copy` نه.
///
/// [`Clone`] د `Copy` سپراټرایټ دی ، نو هرڅه چې `Copy` وي باید [`Clone`] هم پلي کړي.
/// که یو ډول یې `Copy` وي نو بیا د دې [`Clone`] تطبیق یوازې `*self` بیرته ورکولو ته اړتیا لري (پورته مثال وګورئ).
///
/// ## زما ډول کله `Copy` کیدی شي؟
///
/// یو ډول کولی شي `Copy` پلي کړي که چیرې د هغې ټولې برخې `Copy` پلي کړي.د مثال په توګه ، دا جوړښت کولی شي `Copy` وي:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// یو جوړښت کیدی شي `Copy` وي ، او [`i32`] `Copy` دی ، نو له همدې امله `Point` د `Copy` وړ دی.
/// برعکس ، پام وکړئ
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// جوړښت `PointList` نشي کولی `Copy` تطبیق کړي ، ځکه چې [`Vec<T>`] `Copy` ندی.که موږ د `Copy` پلي کولو هڅه وکړو ، نو موږ به یوه اشتباه ترلاسه کړو:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// د شریک شوي حوالې (`&T`) هم `Copy` دي ، نو یو ډول یې د `Copy` کیدی شي ، حتی کله چې دا د `T` ډولونو شریک مآخذونه لري چې *نه*`Copy` دي.
/// لاندې جوړښت په پام کې ونیسئ ، کوم چې کولی شي `Copy` تطبیق کړي ، ځکه چې دا زموږ له غیر `کاپي ډول `PointList` څخه یوازې * شریک شوی حواله لري:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## کله چې * زما ډول `Copy` نه شي؟
///
/// ځینې ډولونه په خوندي ډول نشي کاپي کیدی.د مثال په توګه ، د `&mut T` کاپي کول به د بدلیدو وړ بدلون رامینځته کړي.
/// د [`String`] کاپي کول به د [`سټرینګ] بفر اداره کولو لپاره مسؤلیت مسؤلیت نقل کړي ، چې د ډبل آزادیدو لامل کیږي.
///
/// د وروستۍ قضیې عمومي کول ، هر ډول د [`Drop`] پلي کول `Copy` نشي کیدی ، ځکه چې دا د [`size_of::<T>`] بایټونو سربیره ځینې سرچینې اداره کوي.
///
/// که تاسو هڅه وکړئ `Copy` په داسې جوړښت یا اینوم کې چې غیر `کاپي` ډاټا پکې وي پلي کړئ ، نو تاسو به تېروتنه [E0204] ترلاسه کړئ.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## کله *باید* زما ډول `Copy` وي؟
///
/// عموما خبرې کول ، که ستاسو ډول _can_ `Copy` پلي کوي ، نو دا باید.
/// په یاد ولرئ ، که څه هم ، چې د `Copy` پلي کول ستاسو د ډول عامه API برخه ده.
/// که چیرې دا ډول په future کې غیر op کاپي `شي ، نو دا د اوس لپاره د `Copy` تطبیق له پامه غورځول ممکن وي ، ترڅو د ماتونکي API بدلون مخه ونیسئ.
///
/// ## اضافي پلي کونکي
///
/// د [implementors listed below][impls] سربیره ، لاندې ډولونه هم د `Copy` پلي کوي:
///
/// * د فنکشن توکی ډولونه (د بیلګې په توګه ، د هر فعالیت لپاره ټاکل شوی مختلف ډولونه)
/// * د فعالیت د ښودونکي ډولونه (د بیلګې په توګه ، `fn() -> i32`)
/// * د صفونو ډولونه ، د ټولو اندازو لپاره ، که د توکي ډول هم `Copy` پلي کوي (د مثال په توګه ، `[i32; 123456]`)
/// * د دوه ډوله ډولونه ، که هر جز `Copy` هم پلي کوي (د مثال په توګه ، `()` ، `(i32, bool)`)
/// * د بندولو ډولونه ، که چیرې دوی د چاپیریال څخه هیڅ ارزښت لاسته نه راوړي یا دا ټول نیول شوي ارزښتونه پخپله `Copy` پلي کوي.
///   په یاد ولرئ چې د مشترکو حوالې لخوا نیول شوي تغیرات تل د `Copy` پلي کوي (حتی که چېرته یې هم نه وي) ، پداسې حال کې چې د متغیر حوالې لخوا نیول شوي تغیرات هیڅکله `Copy` نه پلي کوي.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) دا د داسې ډول کاپي کولو ته اجازه ورکوي چې `Copy` نه پلي کوي ځکه چې د نامناسب ژوند عمر حدونو له امله (د `A<'_>` کاپي کول کله چې یوازې `A<'static>: Copy` او `A<'_>: Clone`).
// موږ دا ځانګړتیا دلته د اوس لپاره لرو ځکه چې دلته په `Copy` کې یو څه شتون شتون لري چې دمخه یې په معیاري کتابتون کې شتون لري ، او اوس مهال د دې چلند خوندي ساتلو لپاره هیڅ لاره شتون نلري.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// د trait `Copy` د تطبیق وړ میکرو تولید.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ډولونه د کوم لپاره چې دا د سلسلو تر منځ مآخذ شریکولو خوندي دی.
///
/// دا trait په اوتومات ډول تطبیق کیږي کله چې تالیف کونکي دا مناسب کړي.
///
/// دقیقه تعریف دا دی: یو ډول `T` [`Sync`] دی که یوازې او یوازې که `&T` [`Send`] وي.
/// په بل عبارت ، که چیرې د [undefined behavior][ub] احتمال شتون ونلري (د ډیټا ریس په شمول) کله چې د موضوعاتو ترمینځ د `&T` حوالې تیروي.
///
/// لکه څنګه چې یو څوک به تمه وکړي ، لومړني ډولونه لکه [`u8`] او [`f64`] ټول [`Sync`] دي ، او پدې ډول ساده مجموعي ډولونه لري چې پکې شامل دي ، لکه ټیپلز ، سټرېکونه او اینومونه.
/// د لومړني [`Sync`] ډولونو ډیرې مثالونه د "immutable" ډولونه لکه `&T` شامل دي ، او دا چې د ساده میراث وړ بدلونونه لري ، لکه [`Box<T>`][box] ، [`Vec<T>`][vec] او ډیری نور ټولګه ډولونه.
///
/// (عمومي پیرامیټرې د دوی کانټینر لپاره باید [`Sync`] وي [`Sync`].)
///
/// د تعریف یو څه حیرانونکې پایله دا ده چې `&mut T` د `Sync` دی (که `T` `Sync` وي) که څه هم داسې بریښي چې غیر منظم جوړښت رامینځته کوي.
/// چل دا دی چې د شریک حوالې شاته یو بدلون مآخذ حواله (چې دا `& &mut T` ده) یوازې د لوستلو وړ کیږي ، لکه څنګه چې دا `& &T` وي.
/// له همدې امله د معلوماتو ریس هیڅ خطر نلري.
///
/// ډولونه چې د `Sync` نه دي هغه دي چې په غیر تار-خوندي ب formه کې "interior mutability" لري ، لکه [`Cell`][cell] او [`RefCell`][refcell].
/// دا ډولونه د دوی د مینځپانګې بدلیدو ته اجازه ورکوي حتی د غیر منقول ، ګډ ریفرنس له لارې.
/// د مثال په توګه په [`Cell<T>`][cell] کې د `set` میتود `&self` اخلي ، نو دا یوازې شریک ریفرنس ته اړتیا لري [`&Cell<T>`][cell].
/// میتود هیڅ همغږی نه ترسره کوي ، نو پدې توګه [`Cell`][cell] `Sync` نشي کیدی.
///
/// د غیر ySync` ډول بله بله بیلګه د حوالې د شمېرنې مرکز [`Rc`][rc] دی.
/// هرې [`&Rc<T>`][rc] X حوالې ته ، تاسو کولی شئ یو نوی [`Rc<T>`][rc] کلون وکړئ ، په غیر اټمي ب wayه د حوالې شمیرې ته بدلون ورکړئ.
///
/// د قضیو لپاره کله چې یو چا ته د کور خوندي داخلي بدلون ته اړتیا وي ، Rust [atomic data types] چمتو کوي ، او همدارنګه د [`sync::Mutex`][mutex] او [`sync::RwLock`][rwlock] له لارې څرګند تالاشي.
/// دا ډولونه باوري کوي چې هیڅ بدلون نشي کولی د ډیټا ریس رامینځته کړي ، له همدې امله ډولونه یې `Sync` دي.
/// په ورته ډول ، [`sync::Arc`][arc] د [`Rc`][rc] سلسله خوندي اینلاګ وړاندې کوي.
///
/// د داخلي بدلون سره هر ډول ډولونه باید د value(s) شاوخوا د [`cell::UnsafeCell`][unsafecell] ریپر هم وکاروي کوم چې د ګډ ریفرنس له لارې بدلیدلی شي.
/// د دې کولو کې پاتې راتلل [undefined behavior][ub] دی.
/// د مثال په توګه ، [`transmute`][transmute]-ing له `&T` څخه `&mut T` ته غیرقانوني دی.
///
/// د `Sync` په اړه د نورو معلوماتو لپاره [the Nomicon][nomicon-send-and-sync] وګورئ.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): یوځل په بیټا کې د `rustc_on_unimplemented` ځمکې کې نوټونو اضافه کولو کې ملاتړ وکړئ ، او دا پراخه شوې ترڅو دا وګوري چې ایا بند د اړتیا په لړ کې چیرته دی ، ورته د (#48534) په څیر پراخه کړئ:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// د صفر اندازې ډول د شیانو نښه کولو لپاره کارول شوي چې د "act like" دوی لري `T`.
///
/// ستاسو ډول ته د `PhantomData<T>` ساحه اضافه کونکي ته وايي چې ستاسو ډول داسې عمل کوي لکه څنګه چې دا د `T` ډول ډول ارزښت ساتي ، که څه هم واقعیا داسې ندي.
/// دا معلومات کارول کیږي کله چې د خوندیتوب ځینې ملکیتونو کمپیوټري کوي.
///
/// د `PhantomData<T>` کارولو څرنګوالي د ژور وضاحت لپاره ، مهرباني وکړئ [the Nomicon](../../nomicon/phantom-data.html) وګورئ.
///
/// # یو په زړه پوری یادونه 👻👻👻
///
/// که څه هم دا دواړه ډارونکي نومونه لري ، `PhantomData` او 'پریت ډولونه' تړاو لري ، مګر یوشان ندي.د فینټم ډول پیرامیټر په ساده ډول یو پیرامیټر دی چې هیڅکله نه کارول کیږي.
/// په Rust کې ، دا ډیری وختونه مرتب کونکي شکایت کوي ، او حل یې د `PhantomData` په واسطه د "dummy" کارول اضافه کول دي.
///
/// # Examples
///
/// ## د ژوند پیرامیډونه نه کارول شوي
///
/// شاید د `PhantomData` لپاره د عام استعمال قضیه یو داسې جوړښت دی چې د ژوند نه کاریدونکي پیرامیټر لري ، په ځانګړي ډول د ځینې غیر خوندي کوډ برخې برخې په توګه.
/// د مثال په توګه ، دلته یو سټراټ `Slice` دی چې د `*const T` ډول دوه نښې لري ، په احتمال سره یو ځای ته په ګوته کوي:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// اراده دا ده چې اصلي معلومات یوازې د ژوند `'a` لپاره د اعتبار وړ دي ، نو ځکه `Slice` باید `'a` ضعیف نه کړي.
/// په هرصورت ، دا اراده په کوډ کې نه ښودل کیږي ، ځکه چې دلته د ژوند `'a` هیڅ ډول کارونې شتون نلري او له همدې امله دا روښانه نده چې دا په کوم ډیټا باندې پلي کیږي.
/// موږ دا د کمپلر په ویلو سره سم عمل کولی شو * د عمل کولو لپاره لکه څنګه چې د `Slice` جوړښت کې د `&'a T` حواله شتون لري:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// دا په بدل کې تشریح `T: 'a` ته هم اړتیا لري ، په ګوته کوي چې په `T` کې کوم حوالې د `'a` X X په اوږدو کې د اعتبار وړ دي.
///
/// کله چې د `Slice` پیل کول تاسو په ساده ډول د `phantom` ساحې لپاره د `PhantomData` ارزښت چمتو کوئ:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ناکارېدلي ډول پیرامیټونه
///
/// دا ځینې وختونه پیښیږي چې تاسو نه کارول شوي ډول پیرامیټونه لرئ کوم چې په ګوته کوي چې کوم ډول ډیټابیس د "tied" پورې اړه لري ، پداسې حال کې چې دا معلومات پخپله پخپله جوړښت کې نه موندل کیږي.
/// دلته یو مثال دی چیرې چې دا د [FFI] سره راپورته کیږي.
/// بهرني انٹرفیس د `*mut ()` ډوله لاسي کاروي ترڅو د مختلف ډولونو Rust ارزښتونو ته مراجعه وکړي.
/// موږ په Rust ډول په سټریکټ `ExternalResource` کې د فینټوم ډول پیرامیټر په کارولو سره تعقیب کوو کوم چې یو لاستی پوښي.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## د ملکیت او غورځولو چک
///
/// د `PhantomData<T>` د ډول ساحې اضافه کول په ګوته کوي چې ستاسو ډول د `T` ډول ډوله ملکیت لري.دا په بدل کې معنی لري کله چې ستاسو ډول پریښودل شي ، نو دا د `T` ډول یو یا ډیر مثالونه غورځوي.
/// دا د Rust تالیف کونکي [drop check] تحلیل لري.
///
/// که ستاسو جوړښت په حقیقت کې د `T` ډول ډاټا *نه* لري ، نو غوره به وي چې د مرجع ډول وکاروئ ، لکه `PhantomData<&'a T>` (ideally) یا `PhantomData<*const T>` (که نه د ژوند موده غوښتنه کیږي) ، نو د ملکیت په نښه کولو نه.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// د کمپیلر داخلي trait د اینوم امتیازاتو ډول په ګوته کولو لپاره کارول شوی.
///
/// دا trait په اوتومات ډول د هر ډول لپاره پلي کیږي او په [`mem::Discriminant`] کې هیڅ تضمین نه اضافه کوي.
/// دا **نامعلومه سلوک** د `DiscriminantKind::Discriminant` او `mem::Discriminant` تر مینځ لیږدول دي.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// د تبعیض ډول ، کوم چې باید د `mem::Discriminant` لخوا اړین trait bounds پوره کړي.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// د کمپیلر داخلي trait د دې معلومولو لپاره کارول شوی چې ایا یو ډول په کور دننه کوم `UnsafeCell` لري ، مګر د لارښوونې له لارې نه.
///
/// دا اغیزه کوي ، د مثال په توګه ، ایا د دې ډول `static` یوازې د لوستلو جامد حافظه کې یا د لیکلو وړ جامد حافظه کې ځای په ځای کیږي.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ډولونه چې کولی شي د پین کولو وروسته په خوندي ډول حرکت وکړي.
///
/// Rust پخپله د غیر منقولو ډولونو تصور نلري ، او حرکتونه ګ considي (د بیلګې په توګه ، د ګمارنې یا [`mem::replace`] له لارې) تل خوندي وي.
///
/// د [`Pin`][Pin] ډول د دې پرځای کارول کیږي ترڅو د ډول سیسټم له لارې د حرکت مخه ونیسي.په [`Pin<P<T>>`][Pin] ریپر کې نښې ایښودل شوي نښې `P<T>` بهر نشي حرکت کولی.
/// د پن کولو په اړه د نورو معلوماتو لپاره د [`pin` module] اسناد وګورئ.
///
/// د `T` لپاره د `Unpin` trait پلي کول د ډول بندیدلو محدودیتونه لرې کوي ، کوم چې بیا اجازه ورکوي `T` له [`Pin<P<T>>`][Pin] څخه د [`mem::replace`] په څیر فعالیتونو سره حرکت کوي.
///
///
/// `Unpin` د بې پنډ شوي ډاټا لپاره هیڅ پایله نلري.
/// په ځانګړي توګه ، [`mem::replace`] په خوښۍ سره د `!Unpin` ډاټا حرکت کوي (دا د کوم `&mut T` لپاره کار کوي ، نه یوازې کله چې `T: Unpin`).
/// په هرصورت ، تاسو نشئ کولی [`mem::replace`] د [`Pin<P<T>>`][Pin] دننه لړل شوي ډیټا باندې وکاروئ ځکه چې تاسو نشئ کولی هغه `&mut T` ترلاسه کړئ چې تاسو ورته اړتیا لرئ ، او *دا* هغه څه دي چې دا سیسټم کار کوي.
///
/// نو دا ، د مثال په توګه ، یوازې د `Unpin` پلي کونکي ډولونو باندې ترسره کیدی شي:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // موږ د `mem::replace` تلیفون کولو لپاره بدلون ته اړتیا لرئ.
/// // موږ کولی شو دا ډول مرجع د (implicitly) په واسطه د `Pin::deref_mut` غوښتنه وکړئ ، مګر دا یوازې امکان لري ځکه چې `String` `Unpin` پلي کوي.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// دا trait په اوتومات ډول د هر ډول لپاره پلي کیږي.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// د مارکر ډول چې `Unpin` نه پلي کوي.
///
/// که یو ډول `PhantomPinned` ولري ، نو دا به د ډیفالټ لخوا `Unpin` نه پلي کوي.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// د لومړني ډولونو لپاره د `Copy` پلي کول.
///
/// تطبیقات چې په Rust کې توضیح کیدی نشي په `rustc_trait_selection` کې په `traits::SelectionContext::copy_clone_conditions()` کې پلي کیږي.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// شریک شوي مآخذونه کاپي کیدلی شي ، مګر بدلیدونکي حوالې *نشي کولی*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}