#![stable(feature = "futures_api", since = "1.36.0")]

//! غیر همزولي ارزښتونه.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// دا ډول ته اړتیا ده ځکه چې:
///
/// a) جنراتورونه `for<'a, 'b> Generator<&'a mut Context<'b>>` نشي پلي کولی ، نو ځکه موږ اړتیا لرو چې خام پوائنټر پاس کړو (<https://github.com/rust-lang/rust/issues/68923> وګورئ).
///
/// b) خام نښې او `NonNull` `Send` یا `Sync` نه دي ، نو دا به هر future non-Send/Sync هم جوړ کړي ، او موږ دا نه غواړو.
///
/// دا د `.await` HIR ټیټ کول هم اسانوي.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// په future کې یو جنراتور ولګوه.
///
/// دا فنکشن لاندې `GenFuture` بیرته راولي ، مګر دا په `impl Trait` کې پټوي ترڅو غوره خطا پیغامونه ورکړي (د `GenFuture<[closure.....]>` پرځای `impl Future`).
///
// دا د `const` دی ترڅو د `const async fn` څخه بیرته ترلاسه کولو وروسته د اضافي غلطیو مخه ونیسو
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // موږ پدې حقیقت باندې تکیه کوو چې د async/await futures په لاندې جنریټر کې د ځان راجع کونکي پورونو رامینځته کولو لپاره غیر منحصر دي.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // خوندي: خوندي ځکه چې موږ د !Unpin + !Drop یو ، او دا یوازې د فیلډ پروجیکشن دی.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // جنریټر بیا پیل کړئ ، `&mut Context` په `NonNull` خام نښې بدل کړئ.
            // د `.await` راټیټیدل به په خوندي ډول بیرته `&mut Context` ته واچوي.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // خوندي: زنګ وهونکی باید تضمین وکړي چې `cx.0` یو درست ټکي دی
    // چې د بدلون غوښتنې ټولې اړتیاوې پوره کوي.
    unsafe { &mut *cx.0.as_ptr().cast() }
}