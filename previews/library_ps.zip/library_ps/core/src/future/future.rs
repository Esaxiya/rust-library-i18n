#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future د بې عیب کمپیوټري نمایندګي کوي.
///
/// A future یو داسې ارزښت دی چې شاید کمپیوټري یې نه وي بشپړه کړې.
/// د "asynchronous value" دا ډول دا ممکنه کوي چې د یوې تار لپاره ګټور کار ته دوام ورکړي پداسې حال کې چې دا د شتون ارزښت ته انتظار باسي.
///
///
/// # د `poll` میتود
///
/// د future ، `poll` اصلي میتود ،*هڅه کوي* ترڅو future حتمي ارزښت ته حل کړي.
/// دا میتود نه مخنیوی کوي که چیرې ارزښت چمتو نه وي.
/// پرځای یې ، اوسنی دنده به ویښ شي کله چې امکان ولري د رایې ورکولو له لارې نور پرمختګ هم وکړي.
/// د `context` میتود ته لیږدول شوی `context` کولی شي [`Waker`] چمتو کړي ، کوم چې د اوسنۍ دندې د پاڅولو لپاره یو هینډل دی.
///
/// کله چې د future کاروئ ، نو تاسو به عموما په مستقیم ډول `poll` نه زنګ ووهئ ، مګر د دې پرځای به `.await` ارزښت وکړئ.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// د بشپړیدو پر مهال تولید شوي ارزښت ډول.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// نهایی ارزښت ته د future حل کولو هڅه ، د ویښولو لپاره اوسني دنده راجستر کول که چیرې ارزښت لاهم شتون نلري.
    ///
    /// # د راستنیدو ارزښت
    ///
    /// دا فعالیت بیرته راګرځي:
    ///
    /// - [`Poll::Pending`] که future لاهم چمتو نه دی
    /// - [`Poll::Ready(val)`] د دې future پایلو `val` سره که دا په بریالیتوب سره پای ته ورسي.
    ///
    /// یوځل چې د future پای ته ورسید ، پیرودونکي باید دا بیا `poll` ونه کړي.
    ///
    /// کله چې future لاهم چمتو نه وي ، `poll` `Poll::Pending` بیرته راولي او د موجوده [`Context`] څخه کاپي شوي [`Waker`] کلون ذخیره کړي.
    /// دا [`Waker`] بیا راپورته شو یوځل چې د future پرمختګ کولی شي.
    /// د مثال په توګه ، یو future د ساکټ لپاره د لوستلو وړتیا لپاره انتظار کوي به په `.clone()` X باندې `.clone()` زنګ ووهي او دا به یې ذخیره کړي.
    /// کله چې سیګنال بل چیرې راشي نو دا په ګوته کوي چې ساکټ د لوستلو وړ دی ، [`Waker::wake`] ویل کیږي او ساکټ د future دنده راویښ شوې.
    /// یوځل چې یو کار له لاسه وتلی وي ، نو دا باید د `poll` future بیا هڅه وکړي ، کوم چې ممکن حتمي ارزښت تولید کړي یا نه.
    ///
    /// په یاد ولرئ چې `poll` ته په ډیری تلیفونونو کې ، له [`Context`] څخه یوازې [`Waker`] وروستي کال ته انتقال شوی باید د ویک اپ ترلاسه کولو لپاره مهالویش شي.
    ///
    /// # د وخت وخت ځانګړتیاوې
    ///
    /// Futures یوازې *غیرضر* دي؛دوی باید د پرمختګ لپاره *په فعاله توګه* ټولپوښتنه وشي ، پدې معنی چې هرځل چې اوسنی دنده پاڅیدلی وي ، دا باید په فعاله توګه د futures زیرمه پاتې .poll` بیا پیل کړي چې دا لاهم علاقه لري.
    ///
    /// د `poll` فنکشن په کلکه لوپ کې تکرار نه ویل کیږي-پرځای یې ، دا باید تلیفون شي کله چې future اشاره کوي چې پرمختګ ته چمتو دی (د `wake()`) تلیفون کولو سره).
    /// که تاسو د `poll(2)` یا `select(2)` سیسټمونو سره په Unix سره اشنا یاست نو د یادونې وړ ده چې futures په عموم ډول *د* X * X ورته ستونزې نه رنځوي؛دوی د `epoll(4)` په څیر ډیر دي.
    ///
    /// د `poll` پلي کول باید ژر تر ژره بیرته راستنیدو لپاره هڅه وکړي ، او نه باید مخنیوی وکړي.په چټکۍ سره بیرته راستنیدنه د غیر ضروري ډول د موضوعاتو یا پیښې لوګو بندیدو مخه نیسي.
    /// که چیرې دا دمخه پیژندل شوي وي چې `poll` ته زنګ ممکن یو څه وخت ونیسي ، کار باید د تالاب حوض (یا ورته ورته یو څه) ته وسپارل شي ترڅو ډاډ ترلاسه شي چې `poll` ژر تر ژره بیرته راستون شي.
    ///
    /// # Panics
    ///
    /// یوځل چې د future بشپړ شو (د X0 `poll` څخه `Ready` بیرته راوګرځید) ، د دې `poll` میتود بیا تلیفون کول ممکن panic ، د تل لپاره بلاک کړي ، یا د نورو ډوله ستونزو لامل شي؛د `Future` trait د داسې زنګ تاثیراتو لپاره هیڅ اړتیا نلري.
    /// په هرصورت ، لکه څنګه چې د `poll` میتود په `unsafe` نښه شوی ندی ، د Rust معمول قواعد پلي کیږي: زنګونه باید هیڅکله د نا تایید شوي چلند لامل نشي (د حافظې فساد ، د `unsafe` افعال غلط استعمال ، یا ورته) ، پرته لدې چې د future حالت څخه.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}