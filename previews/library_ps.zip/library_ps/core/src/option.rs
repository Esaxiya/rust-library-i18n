//! اختیاري ارزښتونه.
//!
//! د [`Option`] ډول اختیاري ارزښت استازیتوب کوي: هر [`Option`] یا هم [`Some`] دی او یو ارزښت لري ، یا [`None`] ، او نه لري.
//! [`Option`] ډولونه په Rust کوډ کې خورا عام دي ، ځکه چې دوی یو شمیر کارونې لري:
//!
//! * لومړني ارزښتونه
//! * د وظایفو لپاره بیرته ستنیدونکي ارزښتونه چې د دوی د بشپړ آخذې حد پورې نه ټاکل شوي (جزوي دندې)
//! * د بل ساده غلطیو راپور ورکولو لپاره د راستنیدنې ارزښت ، چیرې چې [`None`] په غلطۍ سره راستون شوی
//! * د اختیاري جوړښت ساحې
//! * هغه ساحې جوړ کړئ چې پور ورکول کیدی شي یا "taken"
//! * اختیاري دلایل
//! * د نه منلو وړ نښې
//! * له سختو شرایطو څخه د شیانو بدلول
//!
//! [`اختیار`] s معمولا د نمونې سره برابر وي ترڅو د ارزښت موجودیت پوښتنه وکړي او اقدام وکړي ، تل د [`None`] قضیې لپاره محاسبه کیږي.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // د فعالیت بیرته ستنیدو ارزښت یو انتخاب دی
//! let result = divide(2.0, 3.0);
//!
//! // د ارزښت ترلاسه کولو لپاره د پیټرنګ میچ
//! match result {
//!     // څانګه د اعتبار وړ وه
//!     Some(x) => println!("Result: {}", x),
//!     // وېشنه باطله وه
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: وښایاست چې څنګه `Option` په عمل کې کارول کیږي ، د ډیری میتودونو سره
//
//! # اختیارونه او نښې ("nullable" نښې)
//!
//! د Rust د اشاري ډولونه باید تل معتبر موقعیت ته ګوته ونیسي؛د "null" حوالې شتون نلري.پرځای یې ، Rust *اختیاري* نښې لري ، لکه د اختیاري ملکیت بکس ، [`اختیار`]`<`[`بکس<T>`]`>`.
//!
//! لاندې مثال د [`i32`] اختیاري بکس رامینځته کولو لپاره [`Option`] کاروي.
//! په یاد ولرئ چې لومړی د داخلي [`i32`] ارزښت کارولو لپاره ، د `check_optional` فنکشن د نمونې پرتله کولو ته اړتیا لري ترڅو معلومه کړي چې ایا بکس ارزښت لري (د بیلګې په توګه ، دا [`Some(...)`][`Some`]) دی یا نه ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust تضمین کوي ترڅو لاندې ډولونه `T` اصلاح کړي لکه [`Option<T>`] د `T` ورته اندازه لري:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` په دې لیست کې د ډولونو څخه شاوخوا جوړ کړئ.
//!
//! دا نور تضمین هم دی چې د پورته قضیو لپاره ، یو څوک کولی شي د `T` ټولو معتبر ارزښتونو څخه `Option<T>` ته او له `Some::<T>(_)` څخه `T` ته [`mem::transmute`] (مګر د `None::<T>` څخه `T` ته لیږدول غیر تعریف شوي چلند دی).
//!
//! # Examples
//!
//! د [`Option`] سره ورته جوړښت لومړني نمونه:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // موجود سټینګ ته مراجعه وکړئ
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // لرونکې تار لرې کړئ ، اختیار له منځه یوسئ
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! د لوپ دمخه [`None`] ته پایلې پیل کړئ:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // د لټون کولو لپاره د معلوماتو لیست.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // موږ د ترټولو لوی څاروي نوم په لټه کې یو ، مګر د پیل لپاره موږ یوازې `None` ترلاسه کړی.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // اوس موږ د یو څه لوی څاروي نوم موندلی دی
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// د `Option` ډول.د نورو لپاره [the module level documentation](self) وګورئ.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// هیڅ ارزښت نلري
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// یو څه ارزښت `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// ډول پلي کول
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // موجود ارزښتونه لټول
    /////////////////////////////////////////////////////////////////////////

    /// `true` راستنوي که چیرې انتخاب د [`Some`] ارزښت وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// `true` راستنوي که چیرې انتخاب د [`None`] ارزښت وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// `true` راستنوي که چیرې انتخاب د [`Some`] ارزښت وي چې ورکړل شوی ارزښت لري.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // د مراجعینو سره کار کولو لپاره اډیپټر
    /////////////////////////////////////////////////////////////////////////

    /// له `&Option<T>` څخه `Option<&T>` ته بدلیږي.
    ///
    /// # Examples
    ///
    /// اصلي ving اختیار <`[` سټرینګ] `>` په `اختیار <` [`usize`]`>`بدلوي ، اصلي ساتنه کوي.
    /// د [`map`] میتود د ارزښت په واسطه د `self` دلیل اخلي ، اصلي مصرف کوي ، نو دا تخنیک `as_ref` کاروي ترڅو لومړی د اصلي دننه ارزښت ته راجع کولو لپاره `Option` واخلي.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // لومړی ، `Option<String>` د `as_ref` سره `Option<&String>` ته کاسټ کړئ ، بیا *هغه* مصرف کړئ د `map` سره ، په سټا کې `text` پریږدئ.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// له `&mut Option<T>` څخه `Option<&mut T>` ته بدلیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// د [`Pin`]`<او اختیار څخه بدلېږي<T>>`تر ption اختیار <`[`پن`]` <&T>> `.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // امنیت: د `x` تضمین تضمین دی ځکه چې دا د `self` څخه راځي
        // چې پن شوی دی.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// د [`Pin`]`<څخه بدلولو اختیار<T>>`تر ption اختیار <`[`Pin`]` <&mut T>> `.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // خوندي: `get_unchecked_mut` هیڅکله د X002 دننه د `Option` حرکت لپاره نه کارول کیږي.
        // `x` د تضمین تضمین دی ځکه چې دا د `self` څخه راځي کوم چې پن شوی.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // موجود ارزښتونو ته رسيدل
    /////////////////////////////////////////////////////////////////////////

    /// موجود [`Some`] ارزښت بیرته راوړي ، د `self` ارزښت مصرفوي.
    ///
    /// # Panics
    ///
    /// Panics که قیمت د `msg` لخوا چمتو شوي د دودیز panic پیغام سره [`None`] وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// موجود [`Some`] ارزښت بیرته راوړي ، د `self` ارزښت مصرفوي.
    ///
    /// ځکه چې دا فنکشن ممکن ممکن panic ، د دې کارول عموما حوصله کیږي.
    /// پرځای یې ، غوره توب وکړئ چې نمونې میچ وکاروئ او د [`None`] قضیه په واضح ډول اداره کړئ ، یا [`unwrap_or`] ، [`unwrap_or_else`] ، یا [`unwrap_or_default`] تلیفون وکړئ.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics که د ځان ارزښت [`None`] سره مساوي وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// موجود [`Some`] ارزښت یا ورکړل شوی ډیفالټ راستنوي.
    ///
    /// `unwrap_or` ته ورکړل شوي دلیلونه په ډیر لیوالتیا سره ارزول کیږي؛که تاسو د فنکشن کال پایله تیریږئ ، نو د [`unwrap_or_else`] کارولو سپارښتنه کیږي ، کوم چې په کافي اندازې سره ارزول کیږي.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// موجود [`Some`] ارزښت راستنوي یا د بندیدو څخه یې پرتله کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// موجود [`Some`] ارزښت بیرته راګرځوي ، د `self` ارزښت مصرف کوي ، پرته لدې چې چیک کړئ چې ارزښت یې [`None`] ندی.
    ///
    ///
    /// # Safety
    ///
    /// په [`None`] د دې میتود زنګ وهل *دي [غیر تعریف شوي چلند]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // بې ټاکي چلند!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // خوندي: د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // بدلون ارزښتونه لري
    /////////////////////////////////////////////////////////////////////////

    /// یو موجود ارزښت ته د فعالیت په پلي کولو سره `Option<T>` ته `Option<T>` ته نقشه کړئ.
    ///
    /// # Examples
    ///
    /// د `اختیار <` [`سټرینګ]`> `ته په` اختیار <`[` usize`]`> Con بدلوي ، اصلي مصرف کوي:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` ځان د ارزښت له مخې * اخلي ، د `maybe_some_string` مصرف
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// په موجود ارزښت باندې فنکشن تطبیقوي (که شتون لري) ، یا چمتو شوي ډیفالټ بیرته راګرځوي (که نه).
    ///
    /// `map_or` ته ورکړل شوي دلیلونه په ډیر لیوالتیا سره ارزول کیږي؛که تاسو د فنکشن کال پایله تیریږئ ، نو د [`map_or_else`] کارولو سپارښتنه کیږي ، کوم چې په کافي اندازې سره ارزول کیږي.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// په موجود ارزښت باندې فنکشن تطبیقوي (که شتون لري) ، یا ډیفالټ حسابوي (که نه).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` په [`Result<T, E>`] کې بدلوي ، [`Some(v)`] ته [`Ok(v)`] او [`None`] ته [`Err(err)`] ته ځای ورکوي.
    ///
    /// `ok_or` ته ورکړل شوي دلیلونه په ډیر لیوالتیا سره ارزول کیږي؛که تاسو د فنکشن کال پایله تیریږئ ، نو د [`ok_or_else`] کارولو سپارښتنه کیږي ، کوم چې په کافي اندازې سره ارزول کیږي.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` په [`Result<T, E>`] کې بدلوي ، [`Some(v)`] ته [`Ok(v)`] او [`None`] ته [`Err(err())`] ته ځای ورکوي.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// په اختیار کې `value` اضافه کوي بیا دې ته د تغیر وړ حواله ورکوي.
    ///
    /// که چیرې انتخاب دمخه یو ارزښت ولري ، زاړه ارزښت پریښودل کیږي.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // خوندي: پورته کوډ یوازې انتخاب ډک کړی
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // د ایټریټر جوړونکي
    /////////////////////////////////////////////////////////////////////////

    /// د احتمالي ارزښت لرونکي تکرار بیرته راګرځوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// د ممکنه حجم ارزښت څخه بدلیدونکی تکرار بیرته راګرځوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // په ارزښتونو د بولین عملیات ، لیواله او سست
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] راګرځوي که چیرې اختیار [`None`] وي ، نو بلکه `optb` بیرته راوړي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// [`None`] راګرځوي که چیرې اختیار [`None`] وي ، نو بلکه د خراب شوي ارزښت سره `f` زنګ وهلی او پایله یې بیرته راوړي.
    ///
    ///
    /// ځینې ژبې دې عملیاتو ته فلیټ میپ وایی.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// [`None`] راګرځوي که چیرې اختیار [`None`] وي ، نو بلکه د W0 ارزښت سره `predicate` زنګ وهلی او بیرته راشي:
    ///
    ///
    /// - [`Some(t)`] که چیرې `predicate` `true` بیرته راشي (چیرې چې د `t` ریپټ شوی ارزښت دی) ، او
    /// - [`None`] که `predicate` `false` بیرته راولي.
    ///
    /// دا فنکشن د [`Iterator::filter()`] سره ورته کار کوي.
    /// تاسو تصور کولی شئ `Option<T>` د یو یا صفر عناصرو څخه تیریدونکی وي.
    /// `filter()` اجازه درکوي چې پریکړه وکړئ کوم عناصر وساتئ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// اختیار بیرته راګرځوي که چیرې دا یو ارزښت ولري ، نو بلکه `optb` بیرته راګرځي.
    ///
    /// `or` ته ورکړل شوي دلیلونه په ډیر لیوالتیا سره ارزول کیږي؛که تاسو د فنکشن کال پایله تیریږئ ، نو د [`or_else`] کارولو سپارښتنه کیږي ، کوم چې په کافي اندازې سره ارزول کیږي.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// اختیار بیرته راګرځوي که چیرې دا ارزښت ولري نو په بل ډول `f` ته زنګ ووهي او پایله یې راوباسي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// [`Some`] ته راستنوي که چیرې یو له `self` څخه ، `optb` [`Some`] وي ، نو په [`None`] کې بیرته راستنوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // د ننوتلو په شان عملیات د دې لپاره چې داخل نه کړي او یو حواله بیرته راشي
    /////////////////////////////////////////////////////////////////////////

    /// په اختیار کې `value` داخلوي که چیرې دا [`None`] وي ، نو بیا موجود ارزښت ته تغیر ورکوونکی حواله ورکوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// په اختیار کې د ډیفالټ ارزښت داخل کړئ که چیرې دا [`None`] وي ، نو بیا موجود ارزښت ته تغیر ورکول حواله ورکوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// په انتخاب کې د `f` څخه محاسبه شوي ارزښت داخل کړئ که چیرې دا [`None`] وي ، نو بیا موجود ارزښت ته تغیر ورکوونکی حواله ورکوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // خوندي: د `self` لپاره د `None` ډول به د `Some` لخوا ځای په ځای شوی وی
            // پورتني کوډ کې بدلون
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// له اختیار څخه ارزښت لرې ، په خپل ځای کې [`None`] پریښودل.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// په اختیار کې اصلي ارزښت په پیرامیټر کې ورکړل شوي ارزښت سره بدلوي ، زاړه ارزښت بیرته راوړي که شتون ولري ، د [`Some`] په خپل ځای کې پریږدئ پرته له دې چې یو یې هم ډیناټایی کړئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// زپ `self` د بل `Option` سره.
    ///
    /// که `self` `Some(s)` وي او `other` `Some(o)` وي ، دا طریقه `Some((s, o))` بیرته راوړي.
    /// بلکه ، `None` بيرته راستون شوی.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// زپ `self` او بل `Option` د `f` فعالیت سره.
    ///
    /// که `self` `Some(s)` وي او `other` `Some(o)` وي ، دا طریقه `Some(f(s, o))` بیرته راوړي.
    /// بلکه ، `None` بيرته راستون شوی.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// د اختیار مینځپانګې کاپي کولو سره `Option<&T>` X ته `Option<&T>` نقشه کړئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// د اختیار مینځپانګې کاپي کولو سره `Option<&mut T>` X ته `Option<&mut T>` نقشه کړئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// د اختیار مینځپانګې کلونیک کولو سره `Option<&T>` X ته `Option<&T>` نقشه کړئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// د اختیار مینځپانګې کلون کولو سره `Option<&mut T>` X ته `Option<&mut T>` نقشه کړئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// د `self` تمه کوي پداسې حال کې چې د [`None`] تمه کیږي او هیڅ شی بیرته نه راځي.
    ///
    /// # Panics
    ///
    /// Panics که ارزښت د [`Some`] وي ، د panic پیغام سره د لیږل شوي پیغام په شمول ، او د [`Some`] مینځپانګه.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // دا به panic ونه کړي ، ځکه چې ټولې کليګانې ځانګړې ندي.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// د `self` تمه کوي پداسې حال کې چې د [`None`] تمه کیږي او هیڅ شی بیرته نه راځي.
    ///
    /// # Panics
    ///
    /// Panics که ارزښت [`Some`] وي ، د دودیز panic پیغام سره چې د [`Some`] ارزښت لخوا چمتو شوی.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // دا به panic ونه کړي ، ځکه چې ټولې کليګانې ځانګړې ندي.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// موجود [`Some`] ارزښت یا یو تلواله بیرته راولي
    ///
    /// بیا د `self` دلیل مصرف کوي ، که [`Some`] ، موجود ارزښت بیرته راولي ، که نه نو [`None`] ، د دې ډول لپاره [default value] بیرته راستنوي.
    ///
    ///
    /// # Examples
    ///
    /// تار مزي ته بدلوي ، د خراب جوړ شوي تارونه 0 ته بدلوي (د عدد لپاره ډیفالټ ارزښت).
    /// [`parse`] تار په بل ډول کې بدلوي چې [`FromStr`] تطبیقوي ، په غلطۍ سره [`None`] راستنوي.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// له `Option<T>` (یا `&Option<T>`) څخه `Option<&T::Target>` ته واړوئ.
    ///
    /// اصلي اختیار په ځای کې پریږدي ، د اصلي حوالې سره یو نوی جوړ کړئ ، سربیره پردې د [`Deref`] له لارې مینځپانګې قوي کول.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// له `Option<T>` (یا `&mut Option<T>`) څخه `Option<&mut T::Target>` ته واړوئ.
    ///
    /// اصلي `Option` په ځای کې پریږدي ، یو نوی رامینځته کړي چې د داخلي ډول `Deref::Target` ډول ته یې اړونده حواله لري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// د [`Result`] `Option` د `Option` ایکس ایکس ایکس ایکس ته واړوئ.
    ///
    /// [`None`] به [`Ok`]`(`[`هیڅ``] `)` ته نقشه شی.
    /// [`ځینې`]`(`[`Ok`] `(_))` او [`ځینې`]`(`[`ایرر]`(_)) به [`Ok`] to ته نقشه شي `[` ځینې`]`(_))`او [`ایرر]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// دا د .expect() پخپله د کوډ اندازه کمولو لپاره جلا فعالیت دی.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// دا د .expect_none() پخپله د کوډ اندازه کمولو لپاره جلا فعالیت دی.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// د Trait پلي کول
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] راستنوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// د امکان لرونکي ارزښت څخه مصرفي تیریټر ته راستنوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` په نوي `Some` کې کاپي کړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// له `&Option<T>` څخه `Option<&T>` ته بدلیږي.
    ///
    /// # Examples
    ///
    /// اصلي ving اختیار <`[` سټرینګ] `>` په `اختیار <` [`usize`]`>`بدلوي ، اصلي ساتنه کوي.
    /// د [`map`] میتود د ارزښت په واسطه د `self` دلیل اخلي ، اصلي مصرف کوي ، نو دا تخنیک `as_ref` کاروي ترڅو لومړی د اصلي دننه ارزښت ته راجع کولو لپاره `Option` واخلي.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// له `&mut Option<T>` څخه `Option<&mut T>` ته بدلیږي
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// د اختیار چلوونکي
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// د [`Some`] متغیر ته د [`Option`] حوالې په اړه تکرارونکی.
///
/// تکرار یو ارزښت لاسته راوړي که [`Option`] [`Some`] وي ، نو بل هیڅ نه.
///
/// دا `struct` د [`Option::iter`] فنکشن لخوا رامینځته شوی.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// د [`Some`] متغیر ته د [`Option`] متغیر حواله باندې تکرارونکی.
///
/// تکرار یو ارزښت لاسته راوړي که [`Option`] [`Some`] وي ، نو بل هیڅ نه.
///
/// دا `struct` د [`Option::iter_mut`] فنکشن لخوا رامینځته شوی.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// د [`Some`] مختلف ډول کې د [`Option`] مختلف ډول کې تکرارونکی.
///
/// تکرار یو ارزښت لاسته راوړي که [`Option`] [`Some`] وي ، نو بل هیڅ نه.
///
/// دا `struct` د [`Option::into_iter`] فنکشن لخوا رامینځته شوی.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// په [`Iterator`] کې هر عنصر اخلي: که دا [`None`][Option::None] وي ، نور عناصر نه نیول کیږي ، او [`None`][Option::None] بیرته راستانه کیږي.
    /// که چیرې [`None`][Option::None] واقع نشي ، نو د هر [`Option`] ارزښتونو سره یو کانټینر بیرته راځي.
    ///
    /// # Examples
    ///
    /// دلته یو مثال شتون لري چې په vector کې هر عدد وده کوي.
    /// موږ د `add` چک شوي ب useه کار کوو چې `None` بیرته راګرځوي کله چې محاسبه به د ډیر جریان لامل شي.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// لکه څنګه چې تاسو لیدلی شئ ، دا به تمه شوي ، معتبر توکي بیرته راولي.
    ///
    /// دلته یو بل مثال دی چې هڅه کوي د بل بشپړ کونکي لیست څخه یو له مینځه یوسي ، دا ځل د اوبو جریان ګوري:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// څنګه چې وروستی عنصر صفر دی ، نو دا به جریان ولري.پدې توګه ، پایله شوې قیمت `None` دی.
    ///
    /// دلته په تیرو مثالونو کې تغیر شتون لري ، دا په ګوته کوي چې نور لومړي عناصر د لومړي `None` وروسته د `iter` څخه ندي اخیستل شوي.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// لکه څنګه چې دریم عنصر د انفلوژن لامل شوی ، نور عناصر ندي نیول شوي ، نو د `shared` وروستی ارزښت 6 (= `3 + 2 + 1`) دی ، نه 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): دا د Iterator::scan سره بدلیدلی شي کله چې د دې فعالیت بګ بند شي.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// د خطا ډول چې د هڅه کونکي آپریټر (`?`) `None` ارزښت ته د پلي کولو پایله لري.
/// که تاسو غواړئ چې `x?` (چیرې چې `x` `Option<T>` دی) ته اجازه ورکړئ چې ستاسو د خطا ډول کې بدل شي ، نو تاسو د `YourErrorType` لپاره `impl From<NoneError>` پلي کولی شئ.
///
/// په دې حالت کې ، په یوه فنکشن کې دننه `x?` چې `Result<_, YourErrorType>` بیرته راولي د `None` ارزښت به د `Err` پایله کې وژباړي.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// له `Option<Option<T>>` څخه `Option<T>` ته بدلیږي
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// فلیټینګ یوازې په یو وخت کې د ځناور یوه کچه لرې کوي:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}