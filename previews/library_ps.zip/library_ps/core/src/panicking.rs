//! د لیبکور لپاره Panic ملاتړ
//!
//! اصلي کتابتون د ډارونې تعبیر نشي کولی ، مګر دا د *اعلان* ویره کول دي.
//! دا پدې مانا ده چې د لیبکور دننه افعال panic ته اجازه لري ، مګر د کار لپاره د پورته جریان crate باید د لیبرکور د کارولو لپاره ویره څرګنده کړي.
//! د ډارولو لپاره اوسنی انٹرفیس دا دی:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! دا تعریف د کوم عمومي پیغام سره د ویره کولو لپاره اجازه ورکوي ، مګر دا د `Box<Any>` ارزښت سره ناکامیدو ته اجازه نه ورکوي.
//! (`PanicInfo` یوازې `&(dyn Any + Send)` لري ، د دې لپاره موږ په `PanicInfo: : داخلي_کونټریکټر کې جعلي ارزښت ډک کوو.) د دې لپاره دلیل دا دی چې لیبکور د تخصیص کولو اجازه نلري.
//!
//!
//! دا ماډل یو څو نور د ویرې کولو افعانې لري ، مګر دا یوازې د کمپیلر لپاره لازمي لانګ توکي دي.ټول panics د دې یوه فنکشن له لارې جذب شوي.
//! اصلي سمبول د `#[panic_handler]` خاصیت له لارې اعلان شوی.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// د لیبکور د `panic!` میکرو اساسي پلي کول کله چې هیڅ ډول ب .ه نه کارول کیږي.
#[cold]
// هیڅکله په لیکه کې ن unless شئ ترڅو چې د تلیفون سایټونو کې د امکان تر حده د کوډ بلاټ کیدو څخه مخنیوی وشي
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // د جریان او نورو `Assert` MIR ترمینټرونو کې د panic لپاره د کوډګین لخوا اړین دی
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // په احتمالي توګه د اندازې د سر کمولو لپاره د format_args! ("{}" ، expr) پرځای Arguments::new_v1 وکاروئ.
    // ب_ه_جګړه!میکرو د توسعې لیکلو لپاره د str دسپلین trait کاروي ، کوم چې Formatter::pad بولي ، کوم چې باید د تار ټرنکشن او پیډینګ ځای ونیسي (که څه هم دلته هیڅ نه کارول کیږي).
    //
    // د Arguments::new_v1 کارول ممکن کمپلر ته اجازه ورکړي Formatter::pad له وتلي بائنری څخه حذف کړي ، تر څو کیلوبایټ پورې خوندي کوي.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // د ضبط شوي ارزونې panics لپاره اړین دی
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // په OOB array/slice لاسرسي کې د panic لپاره د کوډګین لخوا اړین دی
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// د لیبکور د `panic!` میکرو اساسي پلي کول کله چې ب formatه کارول کیږي.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // یادونه دا فنکشن هیڅکله د FFI حد نه تیریږي؛دا د Rust-to-Rust زنګ دی چې د `#[panic_handler]` فعالیت ته حل کیږي.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // خوندي: `panic_impl` په خوندي Rust کوډ کې تعریف شوی او پدې توګه تلیفون کول خوندي دي.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// د `assert_eq!` او `assert_ne!` میکرو لپاره داخلي فعالیت
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}