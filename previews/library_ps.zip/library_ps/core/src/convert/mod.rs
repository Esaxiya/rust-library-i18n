//! د ډولونو تر منځ د تبادلې لپاره Traits.
//!
//! پدې ماډل کې traits د یو ډول څخه بل ډول ته اړولو لپاره لاره چمتو کوي.
//! هر trait مختلف مقصد وړاندې کوي:
//!
//! - د ارزانه حواله تر حوالې تبادلې لپاره د [`AsRef`] trait تطبیق کړئ
//! - د ارزانه بدلون څخه بدلیدونکي تبادلو لپاره د [`AsMut`] trait تطبیق کړئ
//! - د ارزښت څخه تر ارزښت تبادلې مصرف لپاره د [`From`] trait تطبیق کړئ
//! - د اوسني crate څخه بهر ډولونو ته د ارزښت څخه تر ارزښت د تبادلې مصرف لپاره [`Into`] trait تطبیق کړئ
//! - د [`TryFrom`] او [`TryInto`] traits د [`From`] او [`Into`] په څیر چلند کوي ، مګر باید پلي شي کله چې تبادله ناکام شي.
//!
//! پدې ماډل کې traits اکثرا د trait bounds په توګه د عمومي کارونو لپاره کارول کیږي لکه د ډیری ډولونو دلیلونو ملاتړ کیږي.د مثالونو لپاره د هر trait سند وګورئ.
//!
//! د کتابتون لیکوال په توګه ، تاسو باید تل د [`From<T>`][`From`] یا [`TryFrom<T>`][`TryFrom`] پرځای د [`Into<U>`][`Into`] یا [`TryInto<U>`][`TryInto`] پلي کولو ته ترجیح ورکړئ ، ځکه چې [`From`] او [`TryFrom`] لوی انعطاف چمتو کوي او د وړیا لپاره د [`Into`] یا [`TryInto`] پلي کولو وړاندیز کوي ، په معیاري کتابتون کې د کمپلې پلي کولو څخه مننه.
//! کله چې د Rust 1.41 دمخه نسخه په نښه کول ، نو ممکن د [`Into`] یا [`TryInto`] پلي کولو لپاره اړین وي کله چې د موجوده crate څخه بهر یو ډول ته واړوئ.
//!
//! # عمومي تطبیقونه
//!
//! - [`AsRef`] او [`AsMut`] اتومات-که د داخلي ډول حواله وي
//! - [`له``]`<U>د T` مطلب [`In``]`لپاره</u><T><U>د U` لپاره</u>
//! - [`TryFrom`]`<U>د T` لپاره معنی لري [`TryInto`]`</u><T><U>د U` لپاره</u>
//! - [`From`] او [`Into`] انعطاف منونکي دي ، پدې معنی چې ټول ډولونه کولی شي پخپله `into` او پخپله `from`
//!
//! د کارولو مثالونو لپاره هر trait وګورئ.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// د پیژندنې دنده.
///
/// د دې فعالیت په اړه دوه شیان یادداشت کول مهم دي:
///
/// - دا تل د `|x| x` په څیر د بند سره مساوي ندي ، ځکه چې دغه بندیز ممکن `x` په مختلف ډول مجبور کړي.
///
/// - دا وظیفې ته د تېر شوي `x` ان پټ حرکت کوي.
///
/// پداسې حال کې چې دا ممکن عجیب بریښي چې داسې یو فعالیت ولرئ چې یوازې بیرته راستنوي ، ځینې په زړه پورې کارونې شتون لري.
///
///
/// # Examples
///
/// د `identity` کارول د نورو ، په زړه پوري ، دندو په ترتیب کې هیڅ نه کولو لپاره:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // راځئ چې وړاندوینه وکړو چې یو اضافه کول په زړه پوري فعالیت دی.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// په مشروط ډول د `identity` اساس قضیې په توګه د `identity` کارول:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // نور په زړه پوري شیان ترسره کړئ ...
///
/// let _results = do_stuff(42);
/// ```
///
/// د `Option<T>` د تکرار کونکي `Some` تغیراتو ساتلو لپاره د `identity` کارول:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// د ارزانه حواله تر حوالې تبادلې ترسره کولو لپاره کارول کیږي.
///
/// دا trait د [`AsMut`] سره ورته دی کوم چې د بدلون وړ مآخذونو تر مینځ د تبادلې لپاره کارول کیږي.
/// که تاسو اړتیا لرئ ګران تبادله ترسره کړئ نو دا غوره ده چې د `&T` ډول سره [`From`] پلي کړئ یا دودیز فعالیت ولیکئ.
///
/// `AsRef` د [`Borrow`] په څیر ورته لاسلیک لري ، مګر [`Borrow`] په څو برخو کې توپیر لري:
///
/// - د `AsRef` برعکس ، [`Borrow`] د هر `T` لپاره د کمپلې امپیل لري ، او یا هم د حوالې یا ارزښت منلو لپاره کارول کیدی شي.
/// - [`Borrow`] همدارنګه اړتیا لري چې د پور اخیستل شوي ارزښت لپاره [`Hash`] ، [`Eq`] او [`Ord`] د ملکیت ارزښت سره مساوي وي.
/// د دې دلیل لپاره ، که تاسو غواړئ یوازې د یو واحد ساحه پور واخلئ تاسو کولی شئ `AsRef` پلي کړئ ، مګر [`Borrow`] نه.
///
/// **Note: دا trait باید ناکام نشي **.که تبادله ناکامه شي ، یو وقف شوی میتود وکاروئ کوم چې [`Option<T>`] یا [`Result<T, E>`] بیرته راولي.
///
/// # عمومي تطبیقونه
///
/// - `AsRef` د آٹو ریفرنسز که د داخلي ډول حواله وي یا یو بدلون مآخذ حواله وي (د مثال په توګه: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// د trait bounds په کارولو سره موږ کولی شو د مختلف ډولونو دلیلونه ومنو تر هغه چې دوی مشخص شوي ډول `T` ته واړول شي.
///
/// د مثال په توګه: د عمومي فعالیت رامینځته کولو سره چې د `AsRef<str>` اخلي موږ څرګند کوو چې موږ غواړو ټول هغه مآخذونه ومنو چې د دلیل په توګه [`&str`] ته بدل شي.
/// له دې چې دواړه [`String`] او [`&str`] `AsRef<str>` پلي کوي موږ کولی شو دواړه د انلاین دلیل په توګه ومنو.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// تبادله ترسره کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// د ارزانه بدلون څخه د بدل کېدونکي حوالې تبادلې ترسره کولو لپاره کارول کیږي.
///
/// دا trait د [`AsRef`] سره ورته دی مګر د بدلون وړ مآخذونو ترمنځ د تبادلې لپاره کارول کیږي.
/// که تاسو اړتیا لرئ ګران تبادله ترسره کړئ نو دا غوره ده چې د `&mut T` ډول سره [`From`] پلي کړئ یا دودیز فعالیت ولیکئ.
///
/// **Note: دا trait باید ناکام نشي **.که تبادله ناکامه شي ، یو وقف شوی میتود وکاروئ کوم چې [`Option<T>`] یا [`Result<T, E>`] بیرته راولي.
///
/// # عمومي تطبیقونه
///
/// - `AsMut` د اتومات لارښوونې که چیرې داخلي ډول یو بدلون منبع وي (د مثال په توګه: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// د عمومي فعالیت لپاره د `AsMut` د trait bound په توګه کارول موږ کولی شو ټول هغه بدلونونه ومنو چې د `&mut T` ډول ته بدل شي.
/// ځکه چې [`Box<T>`] `AsMut<T>` تطبیق کوي موږ کولی شو فنلیک `add_one` ولیکو چې ټول دلیلونه اخلي چې `&mut u64` ته بدلیدلی شي.
/// ځکه چې [`Box<T>`] `AsMut<T>` تطبیقوي ، نو `add_one` د `&mut Box<u64>` ډول ډولونه هم مني:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// تبادله ترسره کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// د ارزښت څخه تر ارزښت بدلونه چې د وتلو ارزښت مصرفوي.د [`From`] برعکس.
///
/// یو څوک باید د [`Into`] پلي کولو څخه مخنیوی وکړي او پرځای یې [`From`] پلي کړي.
/// د [`From`] پلي کول په اتوماتيک ډول د معیاري کتابتون کې د کمپلې پلي کولو څخه مننه د [`Into`] پلي کولو سره چمتو کوي.
///
/// د [`Into`] X په پرتله د [`Into`] کارولو ته ترجیح ورکړئ کله چې trait bound په عمومي فعالیت کې مشخص کړئ ترڅو دا ډاډ ترلاسه شي چې هغه ډولونه چې یوازې [`Into`] پلي کوي هم کارول کیدی شي.
///
/// **Note: دا trait باید ناکام نشي **.که تبادله ناکامه شي ، نو [`TryInto`] وکاروئ.
///
/// # عمومي تطبیقونه
///
/// - [`له`]`<T>د U` لپاره `Into<U> for T` معنی لري
/// - [`Into`] انعطاف منونکی دی ، په دې معنی چې `Into<T> for T` تطبیق شوی
///
/// # د Rust زاړه نسخو کې خارجي ډولونو ته د تبادلې لپاره د [`Into`] پلي کول
///
/// د Rust 1.41 دمخه ، که د منزل ډول د اوسني crate برخه نه وي نو تاسو نشئ کولی مستقیم [`From`] پلي کړئ.
/// د مثال په توګه ، دا کوډ واخلئ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// دا به د ژبې په زړو نسخو کې تثبیت کولو کې پاتې راشي ځکه چې د Rust د یتیم قواعد یو څه نور ډیر سخت وو.
/// د دې لرې کولو لپاره ، تاسو کولی شئ په مستقیم ډول [`Into`] پلي کړئ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// دا پوهیدل مهم دي چې [`Into`] د [`From`] تطبیق نه وړاندې کوي (لکه څنګه چې [`From`] د [`Into`] سره کوي).
/// نو ځکه ، تاسو باید تل د [`From`] پلي کولو هڅه وکړئ او بیا [`Into`] ته ستون شئ که [`From`] نشي پلي کیدی.
///
/// # Examples
///
/// [`String`] تطبیقات [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// د دې د څرګندولو لپاره چې موږ عمومي حرکت غواړو ټول هغه دلیلونه واخلو چې مشخص ډول `T` ته بدل کیدی شي ، موږ کولی شو د [`IN``] of trait bound وکاروو<T>`.
///
/// د مثال په توګه: فنکشن `is_hello` ټول هغه دلیلونه نیسي چې په [`Vec`]`<`[`u8`] `>` کې بدلیدلی شي.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// تبادله ترسره کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// د ارزښت څخه تر ارزښت تبادلې ترسره کولو په وخت کې د ان پټ ارزښت مصرف کولو لپاره کارول کیږي.دا د [`Into`] تکرار دی.
///
/// یو څوک باید تل د `From` X په پرتله د `From` پلي کولو ته ترجیح ورکړي ځکه چې د `From` پلي کول پخپله د معیاري کتابتون کې د کمپلې پلي کولو څخه مننه د [`Into`] پلي کولو چمتو کوي.
///
///
/// یوازې [`Into`] تطبیق کړئ کله چې د Rust 1.41 دمخه نسخه په نښه کول او د اوسني crate څخه بهر یو ډول ته اړول.
/// `From` په زړو نسخو کې د دې ډول خبرو اترو توان نه درلود ځکه چې د Rust د یتیمو قواعدو له امله.
/// د نورو جزیاتو لپاره [`Into`] وګورئ.
///
/// د [`Into`] د کارولو پر مهال د [`Into`] کارولو ته ترجیح ورکړئ کله چې په عمومي فعالیت کې د trait bounds مشخص کړئ.
/// پدې توګه ، ډولونه چې مستقیم [`Into`] پلي کوي د دلیلونو په توګه هم کارول کیدی شي.
///
/// `From` هم خورا ګټور دی کله چې د خطا کولو اداره کول ترسره کوي.کله چې د داسې فنکشن جوړول چې د ناکامۍ وړ وي ، د راستنولو ډول به عموما د `Result<T, E>` ب formه وي.
/// د `From` trait د غلطۍ اداره کولو ته ساده کوي د فنکشن ته اجازه ورکوي چې د یوې خطا ډول راوباسي چې د غلطی ډیری ډولونه راوباسي.د نورو جزیاتو لپاره د "Examples" برخه او [the book][book] وګورئ.
///
/// **Note: دا trait باید ناکام نشي **.که تبادله ناکامه شي ، نو [`TryFrom`] وکاروئ.
///
/// # عمومي تطبیقونه
///
/// - `From<T> for U` د [T`لپاره][`داخل`] <U>lies کوي</u>
/// - `From` انعطاف منونکی دی ، په دې معنی چې `From<T> for T` تطبیق شوی
///
/// # Examples
///
/// [`String`] د `From<&str>` پلي کول:
///
/// له `&str` څخه سټینګ ته څرګند بدلون په لاندې ډول ترسره کیږي:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// پداسې حال کې چې د غلطۍ اداره کولو ترسره کول اکثرا ستاسو د غلطي ډول لپاره د `From` پلي کولو کې ګټور وي.
/// د داخلي تیروتنو ډولونو زموږ خپل دودیز غلطي ډول ته بدلولو سره چې د داخلي تیروتنو ډول خوندي کوي ، موږ کولی شو د غلط علت یو ډول بیرته راستنیدو پرته پرته له دې چې د معلوماتو لامل له لاسه ورکړو.
/// د '?' آپریټر په اتومات ډول زموږ د ګمرکي غلطي ډول ته د `Into<CliError>::into` تلیفون کولو له لارې اصلي تیروت ډول بدلوي کوم چې په اوتومات ډول چمتو کیږي کله چې د `From` پلي کول.
/// کمپیلر بیا انفراس کوي چې د `Into` پلي کول باید وکارول شي.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// تبادله ترسره کوي.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// یوه هڅه شوې تبادله چې `self` مصرفوي ، کوم چې ممکن ممکن وي یا نه وي.
///
/// د کتابتون لیکوالان باید معمولا دا trait تطبیق نکړي ، مګر د [`TryFrom`] trait پلي کول غوره ګ preferي ، کوم چې ډیر انعطاف وړاندیز کوي او د وړیا لپاره د `TryInto` مساوي پلي چمتو کوي ، په معیاري کتابتون کې د کمپلې پلي کولو څخه مننه.
/// پدې اړه د نورو معلوماتو لپاره ، د [`Into`] لپاره اسناد وګورئ.
///
/// # د `TryInto` پلي کول
///
/// دا د ورته [`Into`] پلي کولو په څیر ورته محدودیتونو او دلیلونو سره مخ دی ، د توضیحاتو لپاره دلته وګورئ.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// ډول د تبادلې تېروتنې په صورت کې راستون شو.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// تبادله ترسره کوي.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// ساده او خوندي ډول تبادلې چې ممکن په ځینې شرایطو کې په کنټرول شوې لاره کې ناکام شي.دا د [`TryInto`] تکرار دی.
///
/// دا ګټور دی کله چې تاسو یو ډول تبادله کوئ چې ممکن په لنډ ډول بریالي وي مګر ممکن ځانګړي اداره کولو ته هم اړتیا ولري.
/// د مثال په توګه ، د [`From`] trait په کارولو سره [`i64`] په [`i32`] کې بدلولو لپاره هیڅ لاره شتون نلري ، ځکه چې [`i64`] ممکن داسې ارزښت ولري چې [`i32`] نشي کولی استازیتوب وکړي او له دې امله تبادله به ډاټا له لاسه ورکړي.
///
/// دا ممکن د [`i64`] [`i32`] ته راکښل (په لازمي ډول د [`i64`] ارزښت ماډولو [`i32::MAX`] ورکول) یا په ساده ډول د [`i32::MAX`] راستنولو سره ، یا د کوم بل میتود لخوا اداره شي.
/// د [`From`] trait د کامل تبادلو لپاره دی ، نو د `TryFrom` trait پروګرامر ته خبر ورکوي کله چې یو ډول تبادله خرابه شي او دوی ته اجازه ورکوي چې د دې اداره کولو څرنګوالي پریکړه وکړي.
///
/// # عمومي تطبیقونه
///
/// - `TryFrom<T> for U` <U>د T`لپاره</u> [`TryInto`] <U>lies ضمیمه کوي</u>
/// - [`try_from`] انعطاف منونکی دی ، پدې معنی چې `TryFrom<T> for T` تطبیق شوی او ناکام نشی کیدی-د `T` ډول ارزښت باندې د `T::try_from()` زنګ وهلو لپاره اړوند `Error` ډول د [`Infallible`] دی.
/// کله چې د [`!`] ډول [`Infallible`] مستحکم شي او [`!`] به مساوي وي.
///
/// `TryFrom<T>` په لاندې ډول پلي کیدی شي:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// لکه څنګه چې تشریح شوي ، [`i32`] تطبیق کوي `د TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // په خاموشی سره `big_number` ټرنیکټ کوي ، د واقعیت وروسته ټرنیکشن کشف او اداره کول غواړي.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // یوه تېروتنه راستنوي ځکه چې `big_number` په `i32` کې د فټ کولو لپاره خورا لوی دی.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` راستنوي.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// ډول د تبادلې تېروتنې په صورت کې راستون شو.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// تبادله ترسره کوي.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// عام عکسونه
////////////////////////////////////////////////////////////////////////////////

// لکه څنګه چې پورته پورته&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// لکه څنګه چې د &mut څخه پورته لفټونه
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): د&/&mut لپاره پورتني وړاندیزونه د لاندې نور عمومي عمومي سره ځای په ځای کړئ:
// // لکه څنګه چې د ډیف څخه پورته
// پلي کول <D: ?Sized + Deref<Target: AsRef<U>> ، U:؟ اندازه شوي> <U>د D {fn as_ref(&self) لپاره> AsRef-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut د &mut څخه پورته پورته کوي
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): د &mut لپاره پورتني امپلیټ د لاندې نور عمومي عمومي سره ځای په ځای کړئ:
// // AsMut د DerefMut څخه پورته کوي
// پلي کول <D: ?Sized + Deref<Target: AsMut<U>> ، U:؟ اندازه شوي> <U>د D {fn as_mut(&mut self) لپاره> AsMut-> &mut U</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// له تطبیق څخه
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// له (او پدې ډول دننه) انعطاف منونکی دی
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **د ثبات یادونه:** دا امتیاز لاهم شتون نلري ، مګر موږ "reserving space" یو چې دا په future کې اضافه کړو.
/// د توضیحاتو لپاره [rust-lang/rust#64715][#64715] وګورئ.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): پرځای یې اصولي اصلاح وکړئ.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ټروایوم ټری انټرو معنی لري
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// غیرمعمولي تبادلې په غیر منطقي توګه د غیرمشروع خطا ډول سره د راوتلو بدلونونو سره برابر دي.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// د ګمراه کولو عکسونه
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// د بې خطا اشتباه کولو ډول
////////////////////////////////////////////////////////////////////////////////

/// د غلطیو لپاره د غلط ډول ډول چې هیڅکله پیښ نشي.
///
/// څنګه چې دا اینم هیڅ ډول نه لري ، نو د دې ډول ارزښت هیڅکله واقعیا شتون نشي کولی.
/// دا د عمومي APIs لپاره ګټور کیدی شي چې [`Result`] کاروي او د غلط ډول ډول پیرامیټرایز کړي ، د دې ښودلو لپاره چې پایله تل د [`Ok`] وي.
///
/// د مثال په توګه ، د [`TryFrom`] trait (هغه تبادله چې [`Result`] بیرته راوړي) د ټولو ډولونو لپاره د کمپلې تطبیق لري چیرې چې معکوض [`Into`] تطبیق شتون لري.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # د Future توافق
///
/// دا اینوم د [the `!`“never”type][never] په څیر ورته رول لري ، کوم چې د Rust پدې نسخه کې بې ثبات دی.
/// کله چې `!` مستحکم شي ، نو موږ پلان کوو چې `Infallible` دې ته یو ډول عرف کړو.
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... او په نهایت کې د `Infallible` تخفیف.
///
/// په هرصورت داسې یوه قضیه شتون لري چیرې چې د `!` ترکیب د `!` د بشپړ بشپړ ډول په توګه ثبات کیدو دمخه وکارول شي: د فعالیت بیرته ستنیدو ډول کې موقعیت کې.
/// په ځانګړي توګه ، دا د دوه مختلف فعالیت نښې ډولونو لپاره ممکن پلي کول دي:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// د `Infallible` اینوم کیدو سره ، دا کوډ معتبر دی.
/// په هرصورت ، کله چې `Infallible` د never type لپاره یو عرف شي ، نو دوه تطبیقات به یې پیل شي او له همدې امله به د ژبې trait همغږي قواعدو څخه انکار شي.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}