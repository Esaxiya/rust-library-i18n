use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// د غیر مترقي تکرارونو سره معامله کولو لپاره یو انٹرفیس.
///
/// دا اصلي جریان دی trait.
/// په عمومي ډول د جریانونو د مفهوم په اړه د نورو معلوماتو لپاره ، مهرباني وکړئ [module-level documentation] وګورئ.
/// په ځانګړي توګه ، تاسو ممکن وغواړئ پوه شئ چې د [implement `Stream`][impl] څرنګوالی.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// د جریاناتو لخوا د حاصلاتو ډولونه.
    type Item;

    /// د دې جریان راتلونکي ارزښت د راښکلو هڅه ، د ویګ اپ لپاره د اوسني کار راجستر کول که چیرې ارزښت لاهم شتون نلري ، او د `None` بیرته راستنیدل که چیرې جریان له مینځه تللی وي.
    ///
    /// # د راستنیدو ارزښت
    ///
    /// د راستنیدو ډیری احتمالي ارزښتونه شتون لري ، هر یو یې د جریان جریان حالت په ګوته کوي:
    ///
    /// - `Poll::Pending` پدې معنی چې د دې جریان راتلونکی ارزښت لاهم چمتو نه دی.پلي کول به ډاډ ترلاسه کړي چې اوسنی دنده به هغه مهال مطلع شي کله چې راتلونکی ارزښت ممکن چمتو وي.
    ///
    /// - `Poll::Ready(Some(val))` پدې معنی چې جریان په بریالیتوب سره یو ارزښت تولید کړی ، `val` ، او ممکن په راتلونکي `poll_next` تلیفونونو کې نور ارزښتونه تولید کړي.
    ///
    /// - `Poll::Ready(None)` پدې معنی چې جریان ختم شوی ، او `poll_next` باید بیا غوښتنه ونه کړي.
    ///
    /// # Panics
    ///
    /// یوځل چې جریان پای ته ورسید (`Ready(None)` from `poll_next`) بیرته راستون شو ، د دې `poll_next` میتود بیا زنګ راوړي ممکن panic ، د تل لپاره بلاک کړي ، یا د نورو ډول ډول ستونزو لامل شي the د `Stream` trait د داسې زنګ اغیزو لپاره هیڅ اړتیا نلري.
    ///
    /// په هرصورت ، لکه څنګه چې د `poll_next` میتود په `unsafe` نښه شوی ندی ، د Rust معمول قواعد پلي کیږي: زنګونه باید هیڅکله د نا تایید شوي چلند لامل نشي (د حافظې فساد ، د `unsafe` افعال غلط غلط استعمال ، یا ورته) ، پرته لدې چې د جریان حالت په پام کې ونیسي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// د جریان په پاتې اوږدوالي محدودیتونه راوباسي.
    ///
    /// په ځانګړي توګه ، `size_hint()` یو ګونګه بیرته راګرځوي چیرې چې لومړی عنصر ښکته حد دی ، او دوهم عنصر د پورتنۍ حد دی.
    ///
    /// دوهم نیمه برخه چې بیرته راستانه کیږي هغه د [[اختیار`]`<`[`usize`]`> `دی.
    /// دلته د [`None`] معنی دا ده چې یا ته هیڅ پورتنی حد شتون نلري ، یا پورتنی حد د [`usize`] څخه لوی دی.
    ///
    /// # د تطبیق یادښتونه
    ///
    /// دا ندی پلي شوی چې د جریان پلي کول د اعلان شویو عناصرو شمیر لاسته راوړي.د بادغیس جریان ممکن د ټیټ حد یا د عنصرونو د پورتنۍ حد څخه ډیر ترلاسه وکړي.
    ///
    /// `size_hint()` اساسا د اصلاح لپاره کارول کیږي لکه د جریان عناصرو لپاره ځای خوندي کول ، مګر باید باور ونلري د مثال په توګه ، په غیر خوندي کوډ کې د حدود چیکونه له لاسه ورکول.
    /// د `size_hint()` غلط پلي کول باید د حافظې خوندیتوب سرغړونې لامل نه کړي.
    ///
    /// دې وویل ، پلې کول باید سم اټکل وړاندې کړي ، ځکه چې که نه نو دا به د trait پروتوکول سرغړونه وي.
    ///
    /// د ډیفالټ پلي کول `(0 ،` [`هیڅ نه]]`) returns بیرته راولي کوم چې د کومې جریان لپاره سم دی.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}