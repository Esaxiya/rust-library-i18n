use crate::iter::FromIterator;

/// د تکرارونکي څخه ټول واحد واحد توکي په یو کې ماتوي.
///
/// دا ډیر ګټور دی کله چې د لوړې کچې خلاصونونو سره ګډ وي ، لکه `Result<(), E>` راټولول چیرې چې تاسو یوازې د غلطیو په اړه پاملرنه کوئ:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}