/// د زنګ اپریټر نسخه چې نه بې اعتباره اخیستونکي اخلي.
///
/// د `Fn` مثالونه په تکراري حالت کې پرته له تغیراتو څخه بلل کیدی شي.
///
/// *دا trait (`Fn`) د [function pointers] (`fn`) سره مغشوش نه وي.*
///
/// `Fn` د بندونو لخوا په اوتومات ډول تطبیق کیږي کوم چې یوازې نیول شوي متغیرو ته غیر مستقیم حوالې اخلي یا هیڅ شی نه نیول کیږي ، په بیله بیا (safe) [function pointers] (د ځینې احتیاطاتو سره ، د نورو معلوماتو لپاره د دوی اسناد وګورئ).
///
/// اضافتا ، د هر ډول `F` لپاره چې `Fn` تطبیقوي ، `&F` هم `Fn` تطبیقوي.
///
/// له دې چې دواړه [`FnMut`] او [`FnOnce`] د `Fn` سوپرټریټونه دي ، د `Fn` هرډول د پیرامیټر په توګه کارول کیدی شي چیرې چې د [`FnMut`] یا [`FnOnce`] تمه کیږي.
///
/// `Fn` د حد په توګه وکاروئ کله چې تاسو غواړئ د ورته فعالیت پیرامیټر ومنئ او اړتیا لرئ دا تکرار کړئ او پرته له بدلون غوښتونکي حالت (مثلا کله چې ورته یوځل تلیفون وکړئ).
/// که تاسو ورته سخت غوښتنو ته اړتیا نلرئ ، نو د حدونو په توګه [`FnMut`] یا [`FnOnce`] وکاروئ.
///
/// په دې موضوع د نورو معلوماتو لپاره [chapter on closures in *The Rust Programming Language*][book] وګورئ.
///
/// د یادونې هم د `Fn` traits لپاره ځانګړي ترکیب دی (د مثال په توګه
/// `Fn(usize, bool) -> usize`).هغه څوک چې پدې تخنیکي توضیحاتو کې لیوالتیا لري کولی شي [the relevant section in the *Rustonomicon*][nomicon] ته مراجعه وکړي.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## د بند غږ کول
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## د `Fn` پیرامیټ کارول
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // نو ترڅو regex کولی شي پدې `&str: !FnMut` تکیه وکړي
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// د زنګ عملیات ترسره کوي.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// د کال آپریټر نسخه چې د بدلون وړ ریسیور اخلي.
///
/// د `FnMut` مثالونه په مکرر ډول سره غږیدلی شي او کیدی شي حالت بدل کړي.
///
/// `FnMut` د بندونو لخوا په اوتومات ډول پلي کیږي کوم چې نیول شوي متغیرو ته بدلیدونکي حوالې اخلي ، په بیله بیا ټول ډولونه چې [`Fn`] تطبیقوي ، د مثال په توګه ، (safe) [function pointers] (ځکه چې `FnMut` د [`Fn`] عالي سپریټ دی).
/// اضافتا ، د هر ډول `F` لپاره چې `FnMut` تطبیقوي ، `&mut F` هم `FnMut` تطبیقوي.
///
/// له هغه وخته چې [`FnOnce`] د `FnMut` لوی تعقیب دی ، نو د `FnMut` هرډول کارول کیدی شي چیرې چې د [`FnOnce`] تمه کیږي ، او له هغه وخته چې [`Fn`] د `FnMut` فرعي ټراټ دی ، نو د [`Fn`] کوم مثال کارول کیدی شي چیرې چې `FnMut` تمه کیږي.
///
/// `FnMut` د حد په توګه وکاروئ کله چې تاسو غواړئ د ورته فعالیت پیرامیټر ومنئ او ورته په تکرار سره تلیفون کولو ته اړتیا لرئ ، پداسې حال کې چې دا د متغیر حالت ته اجازه ورکوي.
/// که تاسو نه غواړئ پیرامیټر حالت بدل کړئ ، نو د [`Fn`] حد په توګه وکاروئ؛که تاسو اړتیا نلرئ چې دا تکرار تلیفون وکړئ ، نو [`FnOnce`] وکاروئ.
///
/// په دې موضوع د نورو معلوماتو لپاره [chapter on closures in *The Rust Programming Language*][book] وګورئ.
///
/// د یادونې هم د `Fn` traits لپاره ځانګړي ترکیب دی (د مثال په توګه
/// `Fn(usize, bool) -> usize`).هغه څوک چې پدې تخنیکي توضیحاتو کې لیوالتیا لري کولی شي [the relevant section in the *Rustonomicon*][nomicon] ته مراجعه وکړي.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## د متقابل کیدنې بندولو غږ کول
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## د `FnMut` پیرامیټ کارول
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // نو ترڅو regex کولی شي پدې `&str: !FnMut` تکیه وکړي
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// د زنګ عملیات ترسره کوي.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// د زنګ اپریټر نسخه چې د ارزښت له مخې اخیستونکي اخلي.
///
/// د `FnOnce` مثالونه کیدی شي زنګ ووهي ، مګر ممکن ډیری ځل د زنګ وهلو وړ نه وي.د دې له امله ، که یوازې د یو ډول په اړه پیژندل شوی شی دا وي چې دا `FnOnce` پلي کوي ، دا یوازې یو ځل ویل کیدی شي.
///
/// `FnOnce` د بندونو لخوا په اوتومات ډول تطبیق کیږي چې ممکن نیول شوي متغیرونه مصرف کړي ، په بیله بیا ټول ډولونه چې [`FnMut`] تطبیقوي ، د بیلګې په توګه ، (safe) [function pointers] (ځکه چې `FnOnce` د [`FnMut`] لوی سپریټ دی).
///
///
/// له هغه ځایه چې دواړه [`Fn`] او [`FnMut`] د `FnOnce` فرعيټونه دي ، نو د [`Fn`] یا [`FnMut`] هره بیلګه کارول کیدی شي چیرې چې د `FnOnce` تمه کیږي.
///
/// `FnOnce` د حد په توګه وکاروئ کله چې تاسو غواړئ د ورته فعالیت پیرامیټر ومنئ او یوازې یوځل یې تلیفون کولو ته اړتیا لرئ.
/// که تاسو اړتیا لرئ بار بار پیرامیټر ته زنګ ووهئ ، نو د [`FnMut`] د حد په توګه وکاروئ؛که تاسو دې ته هم اړتیا لرئ چې حالت بدل نه کړئ ، نو [`Fn`] وکاروئ.
///
/// په دې موضوع د نورو معلوماتو لپاره [chapter on closures in *The Rust Programming Language*][book] وګورئ.
///
/// د یادونې هم د `Fn` traits لپاره ځانګړي ترکیب دی (د مثال په توګه
/// `Fn(usize, bool) -> usize`).هغه څوک چې پدې تخنیکي توضیحاتو کې لیوالتیا لري کولی شي [the relevant section in the *Rustonomicon*][nomicon] ته مراجعه وکړي.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## د `FnOnce` پیرامیټ کارول
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` خپل نیول شوي تغیرات مصرفوي ، نو دا د یوځل څخه ډیر نشي چلیدلی.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // د `func()` بیا غوښتنه کولو هڅه کول به د `func` لپاره د `use of moved value` غلطي وغورځوي.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` نور نو پدې وخت کې بل غوښتنه نشي کیدی
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // نو ترڅو regex کولی شي پدې `&str: !FnMut` تکیه وکړي
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// د تلیفون آپریټر کارول کیدو وروسته بیرته راغلی ډول.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// د زنګ عملیات ترسره کوي.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}