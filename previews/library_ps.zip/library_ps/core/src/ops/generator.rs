use crate::marker::Unpin;
use crate::pin::Pin;

/// د جنراتور بیا پیل کولو پایله.
///
/// دا اینوم د `Generator::resume` میتود څخه راستون شوی او د جنراتور احتمالي بیرته راستنیدونکي ارزښتونو ته اشاره کوي.
/// اوس مهال دا د تعلیق ټکي (`Yielded`) یا د پای ټکي (`Complete`) سره مساوي دي.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// جنراتور د ارزښت سره وځنډول شو.
    ///
    /// دا ایالت په ګوته کوي چې یو جنراتور تعلیق شوی ، او عموما د `yield` بیان سره مطابقت لري.
    /// په دې تغیر کې چمتو شوي ارزښت د `yield` ته رسیدلي اظهار سره مطابقت لري او جنراتورونو ته اجازه ورکوي چې هرځل چې دوی تولید کړي ارزښت چمتو کړي.
    ///
    ///
    Yielded(Y),

    /// جنراتور د ستنیدو ارزښت سره بشپړ شو.
    ///
    /// دا دولت په ګوته کوي چې جنریټر د چمتو شوي ارزښت سره اجرا کول پای ته رسولي.
    /// یوځل چې یو جنراتور `Complete` بیرته راستون شو دا د پروګرامر غلطي ګ isل کیږي ترڅو بیا `resume` زنګ ووهي.
    ///
    Complete(R),
}

/// trait د جوړ شوي جنراتور ډولونو لخوا پلي شوی.
///
/// جنراتورونه ، چې معمولا د کورټینونو په توګه هم پیژندل شوي ، دا مهال په Rust کې د تجربوي ژبې ب featureه لري.
/// په [RFC 2033] جنراتورونو کې شامل شوي اوس مهال د لومړي ځل لپاره د async/await نحو لپاره د ودانۍ بلاک چمتو کول دي مګر احتمال به دا هم تکرار کړي چې د تکرار کونکو او نورو لومړیو لپاره ایرګونومیک تعریف چمتو کړي.
///
///
/// د جنراتورونو لپاره نحوي او سیمانټیک بې ثباته دی او د ثبات لپاره به نور RFC ته اړتیا ولري.پدې وخت کې ، که څه هم ، نحو د بند په څیر دی:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// د جنراتورونو ډیر اسناد په بې ثباته کتاب کې موندل کیدی شي.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// د ارزښت ډول چې دا جنراتور ورکوي.
    ///
    /// دا اړونده ډول د `yield` څرګندونې او ارزښتونو سره مطابقت لري کوم چې هرځل چې جنراتور ترلاسه کوي د بیرته راستنیدو اجازه ورکول کیږي.
    ///
    /// د مثال په توګه یو جنراتور به د `T` په څیر دا ډول ولري ، نو ډول یې تکرار کیږي.
    ///
    type Yield;

    /// د ارزښت ډول چې دا جنراتور بیرته راګرځي.
    ///
    /// دا د جنراتور څخه بیرته راوړل شوي ډول سره تړاو لري یا د `return` بیان سره یا په څرګند ډول د جنراتور لفظي وروستۍ څرګندونې په توګه.
    /// د مثال په توګه futures به دا د `Result<T, E>` په توګه وکاروي ځکه چې دا بشپړ شوی future استازیتوب کوي.
    ///
    ///
    type Return;

    /// د دې جنراتور عملي کول بیا پیل کوي.
    ///
    /// دا فنکشن به د جنراتور اجرا کول بیا پیل کړي یا اجراات پیل کړي که چیرې دا دمخه نه وي.
    /// دا زنګ به بیرته د جنراتور وروستي تعلیق ټکي ته راستانه شي ، چې د وروستي `yield` څخه اعدام بیا پیل کوي.
    /// جنراتور به اجرا کولو ته دوام ورکړي ترهغې پورې چې دا لاسته راوړي یا بیرته راشي ، پدې مرحله کې به دا فنکشن بیرته راشي.
    ///
    /// # د راستنیدو ارزښت
    ///
    /// د دې فنکشن څخه بیرته راګرځیدلی `GeneratorState` اینم په ډاګه کوي چې جنراتور په بیرته راستنیدو کې کوم حالت کې دی.
    /// که چیرې د `Yielded` تغیر بیرته راشي نو جنریټر د تعلیق نقطې ته رسیدلی او ارزښت یې ترلاسه شوی.
    /// پدې ایالت کې جنراتورونه په وروستي وخت کې د بیا پیل لپاره شتون لري.
    ///
    /// که `Complete` بیرته راستانه شي نو جنریټر د ورکړل شوي ارزښت سره په بشپړ ډول پای ته رسیدلی.دا د جنراتور لپاره بیا د سره پیل کیدو لپاره ناباوره دی.
    ///
    /// # Panics
    ///
    /// دا فنکشن panic کیدی شي که چیرې وروسته د `Complete` تغیر وروسته بیرته راستانه شي.
    /// پداسې حال کې چې په ژبې کې جنریټر لیکل د `Complete` وروسته د بیا پیل په اړه panic ته تضمین کیږي ، دا د `Generator` trait ټولو پلي کولو لپاره تضمین نلري.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}