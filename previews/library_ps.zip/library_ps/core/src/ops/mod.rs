//! د ډیر بار وړ وړ چلونکي
//!
//! د دې traits پلي کول تاسو ته اجازه درکوي ځینې ځانګړي آپریټرونه ډیر کړي.
//!
//! ځینې له دې traits د preolve لخوا وارد شوي ، نو دوی په هر Rust برنامه کې شتون لري.یوازې هغه چلوونکي چې د traits لخوا ملاتړ شوي کیدی شي ډیر شي.
//! د مثال په توګه ، اضافی آپریټر (`+`) د [`Add`] trait له لارې اوورلوډ کیدی شي ، مګر له هغه ځایه چې د ګمارنې آپریټر (`=`) د trait ملاتړ نه کوي ، نو د دې سیمانټیک د ډیرو بارولو لپاره هیڅ لاره شتون نلري.
//! سربیره پردې ، دا موډل د نوي آپریټرونو رامینځته کولو لپاره هیڅ میکانیزم نه وړاندې کوي.
//! که چیرې د ټریټلیس اوورلوډینګ یا دودیز چلونکي اړین وي ، نو تاسو باید د Rust ترکیب پراخولو لپاره میکرو یا تالیف کونکو پلگینونو ته ګورئ.
//!
//! د آپریټر traits پلي کول باید د دوی معمول معنی او [operator precedence] په پام کې نیولو سره ، په اړونده شرایطو کې حیرانتیا ونه لري.
//! د مثال په توګه ، کله چې د [`Mul`] پلي کول ، عملیات باید ضرب کولو سره یو څه ورته والی ولري (او د تمویل ملکیتونه لکه ملګرتیا شریک کړئ).
//!
//! په یاد ولرئ چې د `&&` او `||` آپریټرونه شارټ سرکټ ، د مثال په توګه ، دوی یوازې خپل دویم عملیاتي ارزونه کوي که چیرې دا پایله کې شراکت وکړي.له دې چې دا چلند د traits لخوا د تطبیق وړ ندی ، نو د `&&` او `||` د اوورلوډ وړ آپریټرانو په توګه ملاتړ نلري.
//!
//! ډیری آپریټر خپل ارزښتونه د ارزښت له مخې اخلي.په غیر عمومي شرایطو کې چې جوړ شوي ډولونه پکې شامل وي ، دا معمولا ستونزه نده.
//! په هرصورت ، په عمومي کوډ کې د دې آپریټرونو کارول ، یو څه پاملرنې ته اړتیا لري که چیرې ارزښتونه بیا وکارول شي ځکه چې آپریټرونه یې مصرفوي.یو اختیار دا دی چې کله ناکله [`clone`] وکاروئ.
//! بله لاره د مراجعینو لپاره د اضافي آپریټر پلي کولو چمتو کولو کې شامل ډولونو باندې تکیه کول دي.
//! د مثال په توګه ، د کارونکي لخوا ټاکل شوي ډول لپاره `T` کوم چې باید د ملاتړ مالتړ وکړي ، نو دا شاید ښه نظر وي چې دواړه `T` او `&T` د traits [`Add<T>`][`Add`] او [`Add<&T>`][`Add`] تطبیق کړي نو دا چې عمومي کوډ پرته د غیر ضروري کلینینګ لیکل کیدی شي.
//!
//!
//! # Examples
//!
//! دا مثال د `Point` جوړښت رامینځته کوي چې د [`Add`] او [`Sub`] تطبیق کوي ، او بیا د دوه ټکو adding ټکي اضافه کولو او منفي کولو ښیې.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! د مثال په توګه پلي کولو لپاره د هر trait لپاره اسناد وګورئ.
//!
//! د [`Fn`] ، [`FnMut`] ، او [`FnOnce`] traits د ډولونو لخوا پلي کیږي چې د دندو په څیر راوتلی کیدی شي.په یاد ولرئ چې [`Fn`] `&self` اخلي ، [`FnMut`] `&mut self` اخلي او [`FnOnce`] `self` اخلي.
//! دا د درې ډوله میتودونو سره مطابقت لري چې د مثال په توګه غوښتنه کیدی شي: د غوښتنې له مخې اړیکه ، د بدلون له لارې تغیر وړ مبایل ، او د ارزښت له مخې تلیفون کول.
//! د دې traits خورا عام کارول د لوړې کچې دندو لپاره د حدونو په توګه عمل کول دي چې د دلیلونو په توګه دندې یا بندونه نیسي.
//!
//! د پیرامیټر په توګه [`Fn`] اخیستل:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! د پیرامیټر په توګه [`FnMut`] اخیستل:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! د پیرامیټر په توګه [`FnOnce`] اخیستل:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` خپل نیول شوي تغیرات مصرفوي ، نو دا د یوځل څخه ډیر نشي چلیدلی
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // د `func()` بیا غوښتنه کولو هڅه کول به د `func` لپاره د `use of moved value` غلطي وغورځوي
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` نور نو پدې وخت کې بل غوښتنه نشي کیدی
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;