use crate::marker::Unsize;

/// Trait چې په ګوته کوي چې دا یو اشاره یا د یوه لپاره نانځکه ده ، چیرې چې unsizing په پوائنټینټ کې ترسره کیدی شي.
///
/// د نورو جزیاتو لپاره [DST coercion RFC][dst-coerce] او [the nomicon entry on coercion][nomicon-coerce] وګورئ.
///
/// د جوړ شوي پوینټر ډولونو لپاره ، `T` ته نښې به د `U` ته نښو ته اړ کړي که چیرې `T: Unsize<U>` د پتلي پوائنټر څخه د غوړ پوائنټر ته اړولو سره.
///
/// د دودیز ډولونو لپاره ، اجباري دلته د `Foo<T>` `Foo<U>` ته د فشار سره چمتو کوي د `CoerceUnsized<Foo<U>> for Foo<T>` امپلو شتون شتون لري.
/// دا ډول امپول یوازې هغه وخت لیکل کیدی شي که `Foo<T>` یوازې د غیر فانتوماتاټا ساحه لري چې پکې `T` شامل وي.
/// که د دې ساحې ډول `Bar<T>` وي ، نو د `CoerceUnsized<Bar<U>> for Bar<T>` تطبیق باید شتون ولري.
/// جبر به د `Bar<T>` ساحې په `Bar<U>` کې قوي کولو او د `Foo<T>` څخه د پاتې برخو ډکولو لپاره کار وکړي ترڅو د `Foo<U>` رامینځته کړي.
/// دا به په مؤثره توګه د نښې ساحې ته راوباسي او دې ته اړ باسي چې.
///
/// عموما ، د سمارټ اشارو لپاره تاسو به `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` پلي کړئ ، د اختیاري `?Sized` سره پخپله پخپله `T` پورې.
/// د ریپر ډولونو لپاره چې په مستقیم ډول `T` لکه `Cell<T>` او `RefCell<T>` ضمیمه کړي ، تاسو کولی شئ په مستقیم ډول `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` پلي کړئ.
///
/// دا به د `Cell<Box<T>>` کار په څیر ډولونو زورونو ته اجازه ورکړي.
///
/// [`Unsize`][unsize] د ډولونو په نښه کولو لپاره کارول کیږي کوم چې د DSTs ته اړ ایستل کیدی شي که د اشارو شا ته.دا د کمپیلر لخوا پخپله پلي کیږي.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * کانټ U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * کانټ U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *کانټ ټ->* کانټ U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// دا د څیز خوندیتوب لپاره کارول کیږي ، د دې لپاره چې چیک کړي چې د میتود ریسیور ډول راواستول شي.
///
/// د trait عملي کول:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *کانټ ټ->* کانټ U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}