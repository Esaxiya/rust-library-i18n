/// د غیر منقولو شرایطو کې د (`container[index]`) عملیاتو لړلو لپاره کارول کیږي.
///
/// `container[index]` په حقیقت کې د `*container.index(index)` لپاره مصنوعي شوګر دی ، مګر یوازې هغه وخت چې د غیر منل شوي ارزښت په توګه وکارول شي.
/// که د بدلیدو وړ ارزښت غوښتنه شوې وي ، نو پرځای یې [`IndexMut`] کارول کیږي.
/// دا ښه شیان ته اجازه ورکوي لکه `let value = v[index]` که د `value` ډول [`Copy`] تطبیق کړي.
///
/// # Examples
///
/// لاندې مثال د لوستلو لپاره یوازې `NucleotideCount` کانټینر کې `Index` تطبیق کوي ، د انفرادي حسابونو وړتیا ورکوي چې د شاخص ترکیب سره بیرته ترلاسه کړي.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// د ترتیب کولو نه وروسته بیرته راغلی ډول.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// د شاخص کولو (`container[index]`) عملیات ترسره کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// د بدلولو وړ شرایطو کې د (`container[index]`) عملیاتو لړلو لپاره کارول کیږي.
///
/// `container[index]` په حقیقت کې د `*container.index_mut(index)` لپاره مصنوعي شوګر دی ، مګر یوازې هغه وخت چې د بدلون وړ ارزښت په توګه وکارول شي.
/// که غیر متناسب ارزښت غوښتنه وشي ، د [`Index`] trait پرځای کارول کیږي.
/// دا ښه شیان لکه `v[index] = value` ته اجازه ورکوي.
///
/// # Examples
///
/// د `Balance` جوړښت خورا ساده پلي کول چې دوه اړخونه لري ، چیرته چې هر یو کولی شي په متناسب او بې عیب ډول ترتیب شي.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // پدې حالت کې ، `balance[Side::Right]` د `*balance.index(Side::Right)` لپاره شوګر دی ، ځکه چې موږ یوازې* لوستل * `balance[Side::Right]` ، نه لیکو.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // په هرصورت ، پدې حالت کې `balance[Side::Left]` د `*balance.index_mut(Side::Left)` لپاره شوګر دی ، ځکه چې موږ `balance[Side::Left]` لیکو.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// د متغیر شاخص (`container[index]`) عملیات ترسره کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}