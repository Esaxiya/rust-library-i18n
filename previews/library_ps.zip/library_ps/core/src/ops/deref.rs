/// د بې ځایه کیدونکي ډیفرینسي عملیاتو لپاره کارول کیږي ، لکه `*v`.
///
/// په غیر متناسب شرایطو کې د (unary) `*` آپریټر سره د واضح ډرایفرینګ عملیاتو لپاره کارول کیدو سربیره ، `Deref` په ډیری حاالتو کې د تالیف کونکي لخوا هم په څرګنده توګه کارول کیږي.
/// دا میکانیزم د ['`Deref` coercion'][more] په نوم یادیږي.
/// د بدلون وړ شرایطو کې ، [`DerefMut`] کارول کیږي.
///
/// د سمارټ اشارو لپاره د `Deref` پلي کول د دوی شاته معلوماتو ته لاسرسی اسانه کوي ، له همدې امله دوی د `Deref` پلي کوي.
/// له بلې خوا ، د `Deref` او [`DerefMut`] په اړه مقررات په ځانګړي ډول د سمارټ پوینټرو ځای په ځای کولو لپاره ډیزاین شوي و.
/// د دې له امله ،**re ډرایف باید یوازې د سمارټ اشارو** لپاره پلي شي ترڅو د ګډوډۍ څخه مخنیوی وشي.
///
/// د ورته دلیلونو لپاره ،**دا trait باید هیڅکله ناکام نشي**.د درناوي په جریان کې ناکامي کیدی شي ډیر مغشوش وي کله چې `Deref` په مستقیم ډول غوښتنه کیږي.
///
/// # نور په `Deref` جبر باندې
///
/// که `T` `Deref<Target = U>` تطبیقوي ، او `x` د `T` ډول ارزښت دی ، نو بیا:
///
/// * په نه بدلیدونکي شرایطو کې ، `*x` (چیرې چې `T` نه حواله کیږي او نه خام نښې) د `* Deref::deref(&x)` سره مساوي دي.
/// * د `&T` ډول ډول ارزښتونه د `&U` ډول اقدار ته اړ ایستل کیږي
/// * `T` په څرګنده توګه د `U` ډول ټولې (immutable) میتودونه پلي کوي.
///
/// د نورو جزیاتو لپاره ، [the chapter in *The Rust Programming Language*][book] او همدارنګه په [the dereference operator][ref-deref-op] ، [method resolution] او [type coercions] کې د حوالې برخې څخه لیدنه وکړئ.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// یو داسې جوړښت چې د یوې برخې سره شتون لري کوم چې د سټراټیژیک تړون په واسطه د لاسرسي وړ وي.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// د dereferences کولو وروسته د پایلې ډول.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// ارزښت درکوي.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// د بدلون وړ تحقیلي عملیاتو لپاره کارول کیږي ، لکه په `*v = 1;` کې.
///
/// په بدل کېدونکي شرایطو کې د (unary) `*` آپریټر سره د څرګند تحلیل عملیاتو لپاره کارول کیدو سربیره ، `DerefMut` هم په ډیری حاالتو کې د تالیف کونکي لخوا په څرګنده توګه کارول کیږي.
/// دا میکانیزم د ['`Deref` coercion'][more] په نوم یادیږي.
/// په غیر متناسب شرایطو کې ، [`Deref`] کارول کیږي.
///
/// د سمارټ اشارو لپاره د `DerefMut` پلي کول د دوی تر شا د معلوماتو بدلول رامینځته کوي ، له همدې امله دوی د `DerefMut` پلي کوي.
/// له بلې خوا ، د [`Deref`] او `DerefMut` په اړه مقررات په ځانګړي ډول د سمارټ پوینټرو ځای په ځای کولو لپاره ډیزاین شوي و.
/// د دې له امله ،**`ډیرفیمیټ باید یوازې د سمارټ اشارو** لپاره پلي شي ترڅو د ګډوډۍ څخه مخنیوی وشي.
///
/// د ورته دلیلونو لپاره ،**دا trait باید هیڅکله ناکام نشي**.د درناوي په جریان کې ناکامي کیدی شي ډیر مغشوش وي کله چې `DerefMut` په مستقیم ډول غوښتنه کیږي.
///
/// # نور په `Deref` جبر باندې
///
/// که `T` `DerefMut<Target = U>` تطبیقوي ، او `x` د `T` ډول ارزښت دی ، نو بیا:
///
/// * د بدلون وړ شرایطو کې ، `*x` (چیرې چې `T` نه حواله کیږي او نه خام نښې) د `* DerefMut::deref_mut(&mut x)` سره مساوي دي.
/// * د `&mut T` ډول ډول ارزښتونه د `&mut U` ډول اقدار ته اړ ایستل کیږي
/// * `T` په څرګنده توګه د `U` ډول ټولې (mutable) میتودونه پلي کوي.
///
/// د نورو جزیاتو لپاره ، [the chapter in *The Rust Programming Language*][book] او همدارنګه په [the dereference operator][ref-deref-op] ، [method resolution] او [type coercions] کې د حوالې برخې څخه لیدنه وکړئ.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// یو جوړښت چې د یو واحد ډګر سره وي چې د سټراټیژیک کولو له امله د سټراټیټ وړ دی.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// په معقول ډول ارزښت له سره غور کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// په ګوته کوي چې یو سټرټ د `arbitrary_self_types` ب featureه پرته ، د میتود استوونکي په توګه کارول کیدی شي.
///
/// دا د stdlib پوائنټر ډولونو لکه `Box<T>` ، `Rc<T>` ، `&T` ، او `Pin<P>` لخوا پلي کیږي.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}