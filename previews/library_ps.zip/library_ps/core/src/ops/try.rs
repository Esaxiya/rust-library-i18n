/// د `?` آپریټر چلند دودولو لپاره A trait.
///
/// د `Try` پلي کولو یو ډول هغه دی چې د success/failure ډیکوټومي په شرایطو کې د دې لیدلو لپاره کینونیکي لاره لري.
/// دا trait دواړه د موجوده مثال څخه د هغه بریا یا ناکامي ارزښتونو ایستلو او د بریا یا ناکامي ارزښت څخه نوي مثال رامینځته کولو ته اجازه ورکوي.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// د دې ارزښت ډول کله چې د بریالي په توګه کتل کیږي.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// د دې ارزښت ډول کله چې د ناکام په توګه کتل کیږي.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// د "?" چلوونکی پلي کوي.د `Ok(t)` بیرته راستنیدل پدې معنی دي چې اجراآت باید په نورمال ډول دوام وکړي ، او د `?` پایله د `t` ارزښت دی.
    /// د `Err(e)` بیرته راستنیدل پدې معنی دي چې اعدام باید branch د داخلي تړل شوي `catch` ته ، یا له فنکشن څخه بیرته راشي.
    ///
    /// که چیرې د `Err(e)` پایله بیرته راشي ، نو د `e` ارزښت به د تړلو ساحې بیرته ستنیدو کې "wrapped" وي (کوم چې باید پخپله `Try` پلي کړي).
    ///
    /// په ځانګړي ډول ، د `X::from_error(From::from(e))` ارزښت بیرته راستنیدل کیږي چیرې چې `X` د تړلو فعالیت بیرته ستنولو ډول دی.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// د مرکب پایلې جوړولو لپاره د خطا ارزښت نغاړل.
    /// د مثال په توګه ، `Result::Err(x)` او `Result::from_error(x)` مساوي دي.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// د مرکب پایلې رامینځته کولو لپاره د سم ارزښت نغښتل.
    /// د مثال په توګه ، `Result::Ok(x)` او `Result::from_ok(x)` مساوي دي.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}