//! د ټوټې ټوټې
//!
//! دا موډل د اورسن پیټرز نمونې ماتونکي نرخونو په اساس د ترتیب الګوریتم لري چې دلته خپور شوی: <https://github.com/orlp/pdqsort>
//!
//!
//! بې ثباتي ډلبندي د لیبکور سره مطابقت لري ځکه چې دا زموږ د مستحکم ترتیب کولو پلي کولو برعکس ، حافظه نه ورکوي.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// کله چې غورځول شوی ، نو له `src` څخه `dest` ته نقلونه.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // : SAYY::دا د erر... class class class.. ده.
        //          مهرباني وکړئ د سمونې لپاره یې کارول وکاروئ.
        //          په هرصورت ، یو څوک باید ډاډه شي چې `src` او `dst` د `ptr::copy_nonoverlapping` لخوا ورته اړتیا سره اوورلیپ ندي.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// لومړی عنصر ښي لور ته واړوئ تر هغه چې دا لوی یا مساوي عنصر سره مخ شي.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // امنیت: لاندې غیر محفوظ عملیات د پابلي چیک پرته لړلیک کولو کې شامل دي (`get_unchecked` او `get_unchecked_mut`)
    // او حافظه (`ptr::copy_nonoverlapping`) کاپي کول.
    //
    // د.لړلیک
    //  1. موږ>=2 ته د صفونو اندازه چیک کړه.
    //  2. ټول لیست کول چې موږ به یې وکړو تل د {0 <= index < len} ترمنځ خورا وي.
    //
    // ب.حافظه کاپي کول
    //  1. موږ حوالې ته اشارې ترلاسه کوو چې تضمین یې د اعتبار وړ وي.
    //  2. دوی نشي اوریدلی ځکه چې موږ د سلیس شاخصونو ته توپیر ورکولو لپاره نښې ترلاسه کوو.
    //     یعنی ، `i` او `i-1`.
    //  3. که چیرې سلیز په سمه توګه تنظیم شوي وي ، نو عناصر یې په سم ډول سره تنظیم شوي.
    //     دا د زنګ وهونکي مسؤلیت دی چې ډاډ ترلاسه کړي چې سلایس په سمه توګه سم شوی.
    //
    // د نورو تفصیل لپاره لاندې نظرونه وګورئ.
    unsafe {
        // که لومړی دوه عناصر د نظم څخه بهر وي ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // لومړی عنصر په سټیک تخصیص شوي متغیر کې ولولئ.
            // که چیرې د لاندې پرتله کولو عملیات panics ، `hole` به راټیټ شي او په اتوماتيک ډول به سلیس کې عنصر ولیکئ.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // عنصر یو ځای کی the لور ته خوځول ، په دې توګه سوري ښي ته اړول.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` راکښته کیږي او پدې توګه `tmp` په `v` کې پاتې سوري کې کاپي کوي.
        }
    }
}

/// وروستی عنصر کی the اړخ ته لیږدئ تر هغه چې دا کوچني یا مساوي عنصر سره مخ شي.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // امنیت: لاندې غیر محفوظ عملیات د پابلي چیک پرته لړلیک کولو کې شامل دي (`get_unchecked` او `get_unchecked_mut`)
    // او حافظه (`ptr::copy_nonoverlapping`) کاپي کول.
    //
    // د.لړلیک
    //  1. موږ>=2 ته د صفونو اندازه چیک کړه.
    //  2. ټول لیست کول چې موږ به یې وکړو تل د `0 <= index < len-1` ترمنځ خورا وي.
    //
    // ب.حافظه کاپي کول
    //  1. موږ حوالې ته اشارې ترلاسه کوو چې تضمین یې د اعتبار وړ وي.
    //  2. دوی نشي اوریدلی ځکه چې موږ د سلیس شاخصونو ته توپیر ورکولو لپاره نښې ترلاسه کوو.
    //     یعنی ، `i` او `i+1`.
    //  3. که چیرې سلیز په سمه توګه تنظیم شوي وي ، نو عناصر یې په سم ډول سره تنظیم شوي.
    //     دا د زنګ وهونکي مسؤلیت دی چې ډاډ ترلاسه کړي چې سلایس په سمه توګه سم شوی.
    //
    // د نورو تفصیل لپاره لاندې نظرونه وګورئ.
    unsafe {
        // که وروستي دوه عناصر د نظم څخه بهر وي ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // وروستی عنصر په سټیک تخصیص شوي متغیر کې ولولئ.
            // که چیرې د لاندې پرتله کولو عملیات panics ، `hole` به راټیټ شي او په اتوماتيک ډول به سلیس کې عنصر ولیکئ.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // element i`-th عنصر یو ځای ښیې خوا ته وخوځئ ، په دې توګه سوري کی the اړخ ته لیږدول.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` راکښته کیږي او پدې توګه `tmp` په `v` کې پاتې سوري کې کاپي کوي.
        }
    }
}

/// تر یوې اندازې شاوخوا د نظم څخه بهر د څو عناصرو په بدلېدو سره سلیز تنظیموي.
///
/// `true` راستنوي که چیرې سلا په پای کې ترتیب شوي وي.دا فنکشن د *O*(*n*) بدترین قضیه ده.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // د آرډر-آف آرډر جوړو اعظمي شمیر چې به ځای په ځای شي.
    const MAX_STEPS: usize = 5;
    // که چیرې سلیز د دې څخه لنډ وي ، نو هیڅ عنصر مه واستوئ.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // امنیت: موږ دمخه د `i < len` سره محدود چیک کړی.
        // زموږ ټول راتلونکی شاخصونه یوازې د `0 <= index < len` حد کې دي
        unsafe {
            // د آرډر-بهر حکم شوي عنصرونو جوړه جوړه ومومئ.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // ایا موږ ترسره شو؟
        if i == len {
            return true;
        }

        // په لنډو لنډو کې عناصر مه بدلوئ ، چې دا د فعالیت لګښت لري.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // د عناصرو جوړه جوړه بدل کړئ.دا دوی په سمه ترتیب کوي.
        v.swap(i - 1, i);

        // کوچنی عنصر کی the اړخ ته اړول.
        shift_tail(&mut v[..i], is_less);
        // لوی عنصر ښي لور ته واړوئ.
        shift_head(&mut v[i..], is_less);
    }

    // د محدود مرحلو په لړ کې د ټوټې ترتیب کولو اداره نه وه کړې.
    false
}

/// د داخل کولو ډول په کارولو سره سلیس ډلبندي کوي ، کوم چې د *O*(*n*^ 2) بدترین قضیه ده.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// د heapsort په کارولو سره `v` ب Sه کوي ، کوم چې د *O*(*n*\*log(* n*)) بدترین قضیه) تضمین کوي.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // دا بائنری غوړ د بریدګر `parent >= child` درناوی کوي.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // د `node` ماشومان:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // لوی ماشوم غوره کړئ.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // ودریږئ که چیرې بریدګر په `node` کې وساتي.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // د لوی ماشوم سره `node` بدل کړئ ، یو ګام لاندې حرکت وکړئ ، او تعقیب ته دوام ورکړئ.
            v.swap(node, greater);
            node = greater;
        }
    };

    // lineap line line line ararar time. time time..... Build Build........
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // له هغه څخه اعظمي عنصر پاپ کړئ.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` د `pivot` څخه کوچني عناصرو ته `v` برخې ، د `pivot` څخه لوی یا مساوي عناصر تعقیبوي.
///
///
/// د `pivot` څخه کوچني د عناصرو شمیر راولي.
///
/// پارټشنګ د شاخ فعالیتونو لګښت کمولو لپاره د بلاک په واسطه ترسره کیږي.
/// دا نظر په [BlockQuicksort][pdf] پا paperه کې وړاندې شوی.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // په یو ځانګړي بلاک کې د عناصرو شمیر.
    const BLOCK: usize = 128;

    // د تقسیم الګوریتم تر بشپړیدو پورې لاندې مرحلې تکراروي:
    //
    // 1. د لور څخه لوی یا مساوي عناصر پیژندلو لپاره د کی side اړخ څخه یو بلاک ومومئ.
    // 2. د پیلټ څخه کوچني عناصر پیژندلو لپاره د ښي خوا څخه یو بلاک ومومئ.
    // 3. پیژندل شوي عناصر د کی and او ښیې خوا ترمنځ تبادله کړئ.
    //
    // موږ د عناصرو د بلاک لپاره لاندې تغیرات ساتو:
    //
    // 1. `block` - په بلاک کې د عناصرو شمیر.
    // 2. `start` - پیلوونکی په `offsets` صف کې پیل کړئ.
    // 3. `end` - د `offsets` سرې ته د پای اشاره.
    // 4. se آفسیټونه ، په بلاک کې دننه د نظم څخه بهر د عناصرو شاخصونه.

    // په کی side اړخ کې اوسنی بلاک (له `l` څخه تر `l.add(block_l)`) پورې.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // اوسني بلاک په ښي خوا کې (د `r.sub(block_r)` to `r`) څخه.
    // خوندي: د .add() لپاره اسناد په ځانګړي ډول یادونه کوي چې `vec.as_ptr().add(vec.len())` تل خوندي وي
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: کله چې موږ VLAs ترلاسه کړو ، نو د `min(v.len() ، 2 * BLOCK) اوږدوالي یو ارام رامینځته کولو هڅه وکړئ `بلکه
    // د `BLOCK` اوږدوالي له دوه ټاکل شوي اندازې مزو څخه.VLAs ممکن ډیر زیرمه شوي وي.

    // د `l` (inclusive) او `r` (exclusive) ترمینځ د عناصرو شمیر راولي.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // موږ د بلاک په واسطه د تقسیم کولو سره ترسره شوي کله چې `l` او `r` ډیر نږدې وي.
        // بیا موږ ځینې پیچ پیچ کار کوو ترڅو په مینځ کې د پاتې عناصرو تقسیم.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // د پاتې عناصرو شمیر (لاهم د پییوټ سره نه پرتله کیږي).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // د بلاک اندازې تنظیم کړئ ترڅو چې کی left او ښیې بلاک تر پوښښ لاندې نه راشي ، مګر په بشپړ ډول صف بندي وکړئ ترڅو ټولې پاتې تشې پوښ کړئ.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // د کی side اړخ څخه د `block_l` عناصر ومومئ.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // خوندي: لاندې بې باکه عملیات د `offset` کارول شامل دي.
                //         د فعالیت لپاره اړین شرایطو سره سم ، موږ دوی خوښ کوو ځکه چې:
                //         1. `offsets_l` اسٹیک تخصیص شوی ، او پدې توګه جلا جلا اختصاص ګ consideredل کیږي.
                //         2. فنکشن `is_less` `bool` بیرته راستنوي.
                //            د `bool` کاسټ کول به هیڅکله د `isize` جریان ونه کړي.
                //         3. موږ تضمین کړی چې `block_l` به `<= BLOCK` وي.
                //            جمع ، `end_l` په پیل کې د `offsets_` پیل ټکي ته ترتیب شوی و چې په سټیک کې اعلان شوی و.
                //            پدې توګه ، موږ پوهیږو چې حتی په بدترین حالت کې (د `is_less` ټولې غوښتنې باطل راوړي) موږ به لږ تر لږه 1 بایټ پای ته ورسیږو.
                //        دلته بل ناامني عملیات د `elem` معزول دي.
                //        په هرصورت ، `elem` په پیل کې سلایس ته د پیل ټکی و چې تل د اعتبار وړ دی.
                unsafe {
                    // بې بنسټه پرتله کول.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // د ښي اړخ څخه د `block_r` عناصر ومومئ.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // خوندي: لاندې بې باکه عملیات د `offset` کارول شامل دي.
                //         د فعالیت لپاره اړین شرایطو سره سم ، موږ دوی خوښ کوو ځکه چې:
                //         1. `offsets_r` اسٹیک تخصیص شوی ، او پدې توګه جلا جلا اختصاص ګ consideredل کیږي.
                //         2. فنکشن `is_less` `bool` بیرته راستنوي.
                //            د `bool` کاسټ کول به هیڅکله د `isize` جریان ونه کړي.
                //         3. موږ تضمین کړی چې `block_r` به `<= BLOCK` وي.
                //            جمع ، `end_r` په پیل کې د `offsets_` پیل ټکي ته ترتیب شوی و چې په سټیک کې اعلان شوی و.
                //            پدې توګه ، موږ پوهیږو چې حتی په بدترین حالت کې (د `is_less` ټولې غوښتنې ریښتیا راستنوي) موږ به لږ تر لږه 1 بایټ پای ته ورسیږو.
                //        دلته بل ناامني عملیات د `elem` معزول دي.
                //        په هرصورت ، `elem` په پیل کې د پای دمخه `1 *sizeof(T)` و او موږ د لاسرسي دمخه یې د `1* sizeof(T)` لخوا کمو.
                //        جمع ، `block_r` د `BLOCK` څخه کم او د `elem` په اندازه تاکید شوی و نو له همدې امله به تر ډیره حده د سلیس پیل ته په ګوته شي.
                unsafe {
                    // بې بنسټه پرتله کول.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // د کي order او ښي اړخ تر منځ د بدلولو لپاره د ترتيب شوي عناصرو شمير.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // په هغه وخت کې د یوې جوړې بدلولو پرځای ، د سایکلیک جواز اجرا کولو لپاره خورا اغیزمن دی.
            // دا په کلکه د بدلولو سره مساوي ندي ، مګر د لږ حافظې عملیاتو په کارولو سره ورته پایلې رامینځته کوي.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // په کی block بلاک کې د ټول غیر ترتیب شوي عناصر لیږدول شوي و.بل بلاک ته لاړشئ.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // په ښي بلاک کې ټول د حکم څخه بهر عناصر لیږدول شوي و.پخواني بلاک ته لاړشئ.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // ټول هغه څه چې اوس پاتې دي لږترلږه یو بلاک دی (یا کی left یا ښي) د نظم څخه بهر عنصرونه چې حرکت ته اړتیا لري.
    // دا ډول پاتې عناصر په ساده ډول د دوی بلاک کې پای ته لیږدول کیدی شي.
    //

    if start_l < end_l {
        // کی block بلاک پاتې دی.
        // خپل پاتې شوي د حکم شوي عناصر لرې ښیې خوا ته واستوئ.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // سم بلاک پاتې دی.
        // خپل پاتې شوي آرډر عناصر لرې کی left لور ته حرکت کړئ.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // نور هیڅ نه کول ، موږ ترسره کړل.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` د `v[pivot]` څخه کوچني عناصرو ته `v` برخې ، د `v[pivot]` څخه لوی یا مساوي عناصر تعقیبوي.
///
///
/// بیرته راګرځي:
///
/// 1. د `v[pivot]` څخه کوچني د عناصرو شمیر.
/// 2. ریښتیا که `v` لا دمخه ویشل شوی و.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // محور د ټوټې په پیل کې ځای په ځای کړئ.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // پیلوټ د وړتیا لپاره اسٹیک تخصیص شوي متغیر ته ولولئ.
        // که چیرې د لاندې پرتله کولو عملیات panics ، نو پیلوټ به په اوتومات ډول سلیس کې ولیکل شي.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // د نظم نه بهر عنصرونو لومړۍ جوړه ومومئ.
        let mut l = 0;
        let mut r = v.len();

        // امنیت: لاندې بې باوري کې د صف لړل شامل دي.
        // د لومړي لپاره: موږ دمخه دلته د `l < r` سره حدونه چیک کوو.
        // د دوهم لپاره لپاره: موږ په پیل کې `l == 0` او `r == v.len()` لرو او موږ په هر فهرست کولو عملیاتو کې دا `l < r` چیک کړی.
        //                     له دې ځایه موږ پوهیږو چې `r` باید لږترلږه `r == l` وي کوم چې د لومړي څخه د اعتبار وړ ښودل شوی و.
        unsafe {
            // لومړی عنصر له مرکزي نه لوی یا مساوي ومومئ.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // وروستی عنصر کوچنی ومومئ چې اصلي.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` پراخه ساحه ته ځي او پیلوټ (کوم چې د ګ-و تخصیص شوي بدلونونو دی) بیرته سلیس ته لیږي چېرته چې اصلي و.
        // دا ګام د خوندیتوب تضمین کولو کې خورا مهم دی!
        //
    };

    // محور د دوه برخو په مینځ کې ځای په ځای کړئ.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` سره عناصرو کې `v` برخې XXX څخه لوی عناصر تعقیبوي.
///
/// پائیوټ سره د ورته عناصرو شمیر راولي.
/// داسې انګیرل کیږي چې `v` د پییوټ څخه کوچني عناصر نلري.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // محور د ټوټې په پیل کې ځای په ځای کړئ.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // پیلوټ د وړتیا لپاره اسٹیک تخصیص شوي متغیر ته ولولئ.
    // که چیرې د لاندې پرتله کولو عملیات panics ، نو پیلوټ به په اوتومات ډول سلیس کې ولیکل شي.
    // خوندي: دلته نښه کونکی معتبر دی ځکه چې دا د سلایډ ته د حوالې څخه ترلاسه شوی.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // اوس سلیز تقسیم کړئ.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // امنیت: لاندې بې باوري کې د صف لړل شامل دي.
        // د لومړي لپاره: موږ دمخه دلته د `l < r` سره حدونه چیک کوو.
        // د دوهم لپاره لپاره: موږ په پیل کې `l == 0` او `r == v.len()` لرو او موږ په هر فهرست کولو عملیاتو کې دا `l < r` چیک کړی.
        //                     له دې ځایه موږ پوهیږو چې `r` باید لږترلږه `r == l` وي کوم چې د لومړي څخه د اعتبار وړ ښودل شوی و.
        unsafe {
            // لومړنی عنصر له پییوټ څخه لوی ومومئ.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // وروستی عنصر د پیلوټ سره برابر ومومئ.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // ایا موږ ترسره شو؟
            if l >= r {
                break;
            }

            // د نظم څخه بهر عنصرونو موندلې جوړه بدل کړئ.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // موږ د `l` عنصرونه د پائیوټ سره برابر وموندل.1 د محور حساب لپاره ځان اضافه کړئ.
    l + 1

    // `_pivot_guard` پراخه ساحه ته ځي او پیلوټ (کوم چې د ګ-و تخصیص شوي بدلونونو دی) بیرته سلیس ته لیږي چېرته چې اصلي و.
    // دا ګام د خوندیتوب تضمین کولو کې خورا مهم دی!
}

/// ځینې عنصرونه د نمونو ماتولو په هڅه کې وریځوي چې ممکن په نرخونو کې د متوازن برخې لامل شي.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // د جورج مارسګالیا لخوا د "Xorshift RNGs" پا paperې څخه سیډورډوم نمبر جنریټر.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // په دې شمیرو کې بې ترتیب شمیرې واخلئ.
        // شمیره په `usize` کې فټ کیږي ځکه چې `len` د `isize::MAX` څخه لوی ندی.
        let modulus = len.next_power_of_two();

        // ځینې اصلي نوماندان به د دې شاخص ته نږدې وي.راځئ چې دوی تصادفي کړو.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // د ناڅرګنده شمیره ماډولو `len` تولید کړئ.
            // په هرصورت ، د قیمتي عملیاتو څخه مخنیوي لپاره موږ لومړی دا د دوه ځواک موډولو څخه اخلو ، او بیا د `len` لخوا راټیټیږو تر څو چې دا د `[0, len - 1]` اندازې کې مناسب نه وي.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` د `2 * len` څخه کم د تضمین دی.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// په `v` کې یو محور غوره کوي او شاخص او `true` بیرته راوړي که چیرې سلیز احتمال دمخه ترتیب شوی وي.
///
/// په `v` کې عناصر ممکن په پروسه کې تنظیم شي.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // د میډیا-میډینز میتود غوره کولو لپاره لږترلږه اوږدوالی.
    // لنډې سلیزې د درې میډیا-ساده میتود کاروي.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // د تبادلې اعظمي شمیر چې پدې فعالیت کې ترسره کیدی شي.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // درې شاخصونه چې موږ ورته نږدې یو محور غوره کوو.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // د بدلولو ټول شمیره حساب کوو چې موږ یې د ترسره کولو په مهال لرو د شاخصونو ترتیب پرمهال.
    let mut swaps = 0;

    if len >= 8 {
        // بدلول شاخصونه نو نو `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // بدلول شاخصونه نو نو `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // د `v[a - 1], v[a], v[a + 1]` مینځنۍ موندنه کوي او شاخص په `a` کې ذخیره کوي.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // د `a` ، `b` ، او `c` په ګاونډیو کې میډیان ومومئ.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // د `a` ، `b` ، او `c` تر مینځ میډین ومومئ.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // د تبادلې اعظمي شمیر ترسره شو.
        // چانسونه دا دي چې ټوټه ټوټه ټوټه ده یا ډیریږي ښکته ، نو بیرته سرته رسیدل ممکن د دې ګړندي تنظیم کې مرسته وکړي.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// د `v` تکرار ډول ب .ه کوي.
///
/// که سلیس په اصلي صف کې پیشو درلودونکی وي ، نو دا د `pred` په توګه ټاکل شوی.
///
/// `limit` د `heapsort` ته اړولو دمخه د اجازه ورکړل شوي متوازن برخو شمیر دی.
/// که صفر وي ، نو دا فنکشن به سمدلاسه د ګاز بندر ته واړوي.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // تر دې اندازې پورې ټوټې د اضافو ډول سره په ترتیب ډول ترتیب شوي.
    const MAX_INSERTION: usize = 20;

    // ریښتیا که وروستنۍ تقسیم مناسب معادل شوی وی.
    let mut was_balanced = true;
    // ریښتیا که چیرې وروستۍ تقسیم کولو عناصر نه وی بدل کړي (ټوټه لا دمخه ویشل شوې وه).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // د لنډیز ډولونه د اضافو ډول سره ترتیب شوي.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // که چیرې ډیر بد پیلوټ انتخابونه ترسره شوي وي ، نو د `O(n * log(n))` بدترین قضیې تضمین لپاره په ساده ډول بیرته د هیپس پورټ ته وګرځئ.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // که وروستۍ تقسیم متوازن وی ، نو د شاوخوا شاوخوا عناصرو بدلولو سره په سلیس کې نمونې ماتولو هڅه وکړئ.
        // امید لرو چې موږ به دا ځل یو غوره پیلوټ غوره کړو.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // یو پیلوټ غوره کړئ او د اټکل کولو هڅه وکړئ چې ایا ټوټه دمخه ترتیب شوې ده.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // که وروستۍ تقسیم په متناسب ډول متوازن وی او عناصر نه وی بدل کړی ، او که د پایټ انتخاب وړاندوینه کوي نو سلیس لا دمخه ترتیب شوی دی ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // هڅه وکړئ څو د نظم څخه بهر ځینې عناصر وپیژنئ او سم موقعیتونو ته یې واړوئ.
            // که چیرې ټوټه په بشپړ ډول ترتیب شوي پای ته ورسي ، نو موږ سرته رسیدلي.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // که ټاکل شوی پیلوټ د پیشو سره مساوي وي ، نو دا په سلاس کې ترټولو کوچنی عنصر دی.
        // سلائس په برابر عناصرو او عناصر له اصلي څخه لوی برخې کړئ.
        // دا قضیه عموما وهل کیږي کله چې ټوټه ډیری ډیری عنصرونه ولري.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // د پیلوټ څخه لوی عنصرونو ترتیب کولو ته دوام ورکړئ.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // سلیز تقسیم کړئ.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // سلائس په `left` ، `pivot` ، او `right` ویشل کړئ.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // یوازې د لنډ اړخ ته تکرار کړئ ترڅو د تکراري کالونو شمیر راکم شي او د لږ سټیک ځای مصرف کړي.
        // بیا یوازې د اوږدې غاړې سره دوام ورکړئ (دا د دم تکرار سره مساوي دی).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// د نمونې ماتونکي نرخونو په کارولو سره `v` ب Sه کوي ، کوم چې *O*(*n*\*log(* n*)) بدترین قضیه ده).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ترتیب ورکول د صفر اندازې ډولونو باندې هیڅ معنی لرونکی چلند نه لري.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // د متوازن برخو شمیر محدود کړئ `floor(log2(len)) + 1` ته.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // د دې اوږدوالي د ټوټې لپاره شاید دا په ساده ډول دوی ترتیب کړئ ګړندی وي.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // یو پیلوټ غوره کړئ
        let (pivot, _) = choose_pivot(v, is_less);

        // که ټاکل شوی پیلوټ د پیشو سره مساوي وي ، نو دا په سلاس کې ترټولو کوچنی عنصر دی.
        // سلائس په برابر عناصرو او عناصر له اصلي څخه لوی برخې کړئ.
        // دا قضیه عموما وهل کیږي کله چې ټوټه ډیری ډیری عنصرونه ولري.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // که موږ خپل شاخص تېر شو ، نو بیا موږ ښه یو.
                if mid > index {
                    return;
                }

                // نور نو د پیلوټ څخه د عنصرونو ډلبندۍ ته دوام ورکړئ.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // سلائس په `left` ، `pivot` ، او `right` ویشل کړئ.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // که مینځ==شاخص ، نو بیا مو ترسره کړی ، ځکه چې partition() تضمین لري چې د مینځ وروسته وروسته ټول عناصر د مینځ څخه لوی وي یا مساوي دي.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // ترتیب ورکول د صفر اندازې ډولونو باندې هیڅ معنی لرونکی چلند نه لري.هیڅ مه کوه.
    } else if index == v.len() - 1 {
        // اعظمي عنصر ومومئ او د صف په وروستي موقعیت کې یې ځای په ځای کړئ.
        // موږ دلته د `unwrap()` کارولو لپاره آزاد یو ځکه چې موږ پوهیږو v باید خالي نه وي.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // لږترلږه عنصر ومومئ او د صف په لومړي موقعیت کې یې ځای په ځای کړئ.
        // موږ دلته د `unwrap()` کارولو لپاره آزاد یو ځکه چې موږ پوهیږو v باید خالي نه وي.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}