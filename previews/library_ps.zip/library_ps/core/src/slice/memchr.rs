// اصلي تطبیق د rust-memchr څخه اخیستل شوی.
// د کاپي حق 2015 انډریو ګالانټ ، bluss او نیکولاس کوچ

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// ټرنکشن کارول.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `true` راګرځوي که `x` کومه صفر بایټ لري.
///
/// له *موضوعاتو کمپیوټري*، جي ارندټ څخه:
///
/// "نظر دا دی چې د هر بایټ څخه یو کس کم کړي او بیا د بایټونو په لټه کې وي چیرې چې پور ټولې لارې تر خورا مهم پورې تبلیغ کړی
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// په `text` کې د بایټ `x` سره سم لومړي انډیکس بیرته راولي.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // د وړو ټوټو لپاره ګړندی لار
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // په یو وخت کې د دوه `usize` ټکو لوستلو سره د یو واحد بایټ ارزښت لپاره سکین کړئ.
    //
    // `text` په دریو برخو ویشئ
    // - نامعلومه لومړنۍ برخه ، مخکې له دې چې لومړی ټکی په متن کې منسجم پته
    // - بدن ، په یوځل کې د 2 ټکو په واسطه سکین کړئ
    // - وروستۍ پاتې برخه ، <2 ټکي اندازه

    // په منل شوي حد پورې لټون وکړئ
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // د متن اصلي برخه وپلټئ
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // امنیت: د وخت وړاندوینه د لږترلږه 2 * usize_bytes فاصلو تضمین کوي
        // د آفسیټ او سلایس پای ترمینځ.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // مات کړئ که چیرې یو برابر بیت شتون ولري
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // بایټ د هغه ټکي وروسته ومومئ کله چې د بدن لوپ ودریده.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// په `text` کې د بایټ `x` سره جوخت وروستی شاخص راوباسي.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // په یو وخت کې د دوه `usize` ټکو لوستلو سره د یو واحد بایټ ارزښت لپاره سکین کړئ.
    //
    // `text` په دریو برخو ویشئ:
    // - بې خطبه جوړه ، په وروستي ټکي کې په لیک کې د سم شوي پتې وروسته ،
    // - بدن ، په یوځل کې د 2 ټکو په واسطه سکین شوی ،
    // - لومړۍ پاتې شوې بایټونه ، <2 ټکي اندازه.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // موږ دا د مخه د مختاړی او د فرعي اوږدوالي د ترلاسه کولو لپاره وایو.
        // په مینځ کې موږ تل په یوځل دوه ټوټې پروسس کوو.
        // خوندي: د `[u8]` `[usize]` ته لیږد خوندي دی مګر د اندازې توپیرونو لپاره چې د `align_to` لخوا اداره کیږي.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // د متن اصلي برخه وپلټئ ، ډاډ ترلاسه کړئ چې موږ min_aligned_offset نه تیروو.
    // آفسیټ تل تل سم وي ، نو یوازې د `>` ازمول کافي دي او احتمالي جریان مخنیوی کوي.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // خوندي: آفسیټ په لین ، suffix.len() کې پیلیږي ، تر هغه چې لوی وي
        // min_aligned_offset (prefix.len()) پاتې واټن لږترلږه 2 * ټوک_بیټ دی.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // مات کړئ که چیرې میچل بیت شتون ولري.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // مخکې د ټکي نه مخکې بایټ ومومئ د بدن لوپ ودریده.
    text[..offset].iter().rposition(|elt| *elt == x)
}