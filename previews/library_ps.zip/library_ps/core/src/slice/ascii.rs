//! په ASCII `[u8]` کې عملیات.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// چک کوي که چیرې پدې ټوټې کې ټولې باټې د ASCII حد کې وي.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// چک کوي چې دوه ټوټې د ASCII قضیه غیر حساسه لوبه ده.
    ///
    /// د `to_ascii_lowercase(a) == to_ascii_lowercase(b)` په څیر ، مګر د لنډمهاله تخصیص کولو او کاپي کولو پرته.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// دا سلیز دې د ASCII پورتنۍ قضیې سره په ځای کې بدل کړي.
    ///
    /// د ASCII اکرونه 'a' ته 'z' ته 'A' ته 'Z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// د موجوده لوی ترمیم کولو پرته نوي لوی لوی ارزښت بیرته ورکولو لپاره ، [`to_ascii_uppercase`] وکاروئ.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// دا سلیز دې د ASCII ټیټې قضیې ته په ځای کې بدله کړي.
    ///
    /// د ASCII اکرونه 'A' ته 'Z' ته 'a' ته 'z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// د موجوده ټیټ ترمیم کولو پرته نوي ټیټ شوي ارزښت بیرته ورکولو لپاره ، [`to_ascii_lowercase`] وکاروئ.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `true` راګرځوي که د `v` ټکي کې هیڅ بایټ ناناسکي وي (>=128).
/// د `../str/mod.rs` څخه Snarfed ، کوم چې د utf8 اعتبار لپاره ورته څه کوي.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// د ASCII اصلاح شوی ازموینه چې د بایټ-ان-د وخت عملیات (د امکان په صورت کې) د ځای په ځای د کاروونې پر وخت کاروي.
///
/// هغه الګوریتم چې موږ یې دلته کاروو خورا ساده دی.که `s` خورا لنډ وي ، موږ یوازې هر بایټ معاینه کوو او ورسره ترسره کیږو.نور:
///
/// - لومړۍ کلمه د غیر لاسلیک شوي بار سره ولولئ.
/// - پوائنټر سیده کړئ ، ورپسې ټکي تر هغه وخته پورې ولولئ تر څو په لیکلي ب .و سره پای ته ورسي.
/// - د `s` څخه وروستي `usize` د غیر لاسلیک شوي بار سره ولولئ.
///
/// که د دې بارونو څخه کوم شی تولید کړي د کوم لپاره چې `contains_nonascii` (above) ریښتیني راستنوي ، نو موږ پوهیږو چې ځواب غلط دی.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // که موږ د وخت په وخت تطبیق څخه هیڅ لاسته راوړنه ونه مومو ، نو بیرته د اسکیلر لاپ ته ولوځو.
    //
    // موږ دا د معمارونو لپاره هم کوو چیرې چې `size_of::<usize>()` د `usize` لپاره کافي صف برابر ندی ، ځکه چې دا د عجیب edge قضیه ده.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // موږ تل لومړی کلمه بې خطره لوستلو ، چې معنی یې `align_offset` ده
    // 0 ، موږ به د ورته سمون لپاره د سمون لپاره ولولئ.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // خوندي: موږ پورته `len < USIZE_SIZE` تایید کوو.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // موږ دا پورته پورته وګاټه ، یو څه په ساده ډول.
    // په یاد ولرئ چې `offset_to_aligned` یا هم `align_offset` یا `USIZE_SIZE` دی ، دواړه پورته په ښکاره ډول چیک شوي.
    //
    debug_assert!(offset_to_aligned <= len);

    // خوندي: word_ptr د (په سمه توګه تنظیم شوې) ustr ptr دی چې موږ یې د لوستلو لپاره کاروو
    // د ټوټې منځنۍ برخه.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` د `word_ptr` بایټ شاخص دی چې د پای پای چیکونو لپاره کارول کیږي.
    let mut byte_pos = offset_to_aligned;

    // پیراونیا د ساحاتو په اړه ګوري ، ځکه چې موږ د نه لاسلیک شوي بوټو یوه ټولګه کوو.
    // په عمل کې دا باید ناممکن وي که څه هم په `align_offset` کې د کړۍ خنډ کول.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // ورپسې ټکي د وروستي ترتیب شوي ټکي پورې ولولئ ، وروستی لیکل شوی ټکی پخپله پرته له هغه چې په دم کې چیک کې ترسره شي ، ډاډ ترلاسه کړئ چې دمخه تل یو `usize` وي په اضافي توګه branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // سینټ چیک کوي چې لوستل حد کې دي
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // او دا چې د `byte_pos` په اړه زموږ انګیرنې دي.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // خوندي: موږ پوهیږو چې `word_ptr` په سمه توګه تنظیم شوی دی (له امله
        // `align_offset`) ، او موږ پوهیږو چې موږ د `word_ptr` او پای تر مینځ کافي بایټونه لرو
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // خوندي: موږ پوهیږو چې `byte_pos <= len - USIZE_SIZE` ، کوم چې پدې معنی دی
        // د دې `add` وروسته ، `word_ptr` به په خورا لږ وخت کې به یوه برخه وي
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // د سینټي چک ډاډ ترلاسه کولو لپاره چې دلته واقعیا یوازې یو `usize` پاتې دی.
    // دا باید زموږ د لوپ حالت لخوا تضمین شي.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // خوندي: دا په `len >= USIZE_SIZE` تکیه کوي ، کوم چې موږ یې په پیل کې ګورو.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}