//! د `[T]` لپاره traits پرتله کول.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// د کال پلي کیدل یادداشت چمتو کړی.
    ///
    /// ډاټا د u8 په توګه تشریح کوي.
    ///
    /// 0 د مساوي لپاره ، <0 د لږ لپاره او 0 0 د لوی لپاره.
    ///
    // FIXME(#32610): د راستنولو ډول باید c_int وي
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// د vectors [lexicographically](Ord#lexicographical-comparison) پرتله پرتله کوي.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// د vectors [lexicographically](Ord#lexicographical-comparison) پرتله پرتله کوي.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// منځنۍ trait د سلایس پارټیکلیک تخصص لپاره
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// د ټوټې ټوټې برابري
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// د بل پلوه مساواتو لپاره میمکیم وکاروئ کله چې ډولونه اجازه ورکوي
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // خوندي: `self` او `other` حوالې دي او پدې توګه باوري دي چې د اعتبار وړ دي.
        // دوه ټوټې پورته پورته ورته اندازې لپاره چیک شوي دي.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// منځنۍ trait د سلایس پارټورډ تخصص لپاره
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // په کمپلر کې د پاب چیک چیک کولو توان ورکولو لپاره د لوپ تکرار سلسلې ته سلیز
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// دا هغه انګیرنه ده چې موږ یې غواړو.بدبختانه دا سمه نده.
// `partial_ord_slice.rs` وګورئ.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// منځنۍ trait د سلایس آرډ تخصص لپاره
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // په کمپلر کې د پاب چیک چیک کولو توان ورکولو لپاره د لوپ تکرار سلسلې ته سلیز
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// میمکیمپ د لاسلیک کولو څخه د لاسلیک شوي بایټونو ترتیب پرتله کوي.
// دا د هغه ترتیب سره سمون لري چې موږ یې د [u8] لپاره غواړو ، مګر نور نه (حتی [i8] هم نه).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // خوندي: `left` او `right` حوالې دي او پدې توګه باوري دي چې د اعتبار وړ دي.
            // موږ د دواړو اوږدوالی لږترلږه کاروو چې دا تضمین کوي چې دواړه سیمې په دې وقفه کې د لوستلو لپاره د اعتبار وړ دي.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// هیک د `Eq` تخصص اجازه ورکولو لپاره که څه هم `Eq` یو میتود لري.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait د ډولونو لپاره پلي شوي چې د دوی له خوا وړاندې کولو په کارولو سره د مساواتو لپاره پرتله کیدی شي
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // خوندي: `i8` او `u8` ورته حافظه ترتیب لري ، پدې توګه د `x.as_ptr()` کاسټ کول
        // لکه څنګه چې `*const u8` خوندي دی.
        // `x.as_ptr()` د حوالې څخه راځي او پدې توګه تضمین کیږي چې د سلیس `x.len()` اوږدوالي لپاره د لوستلو لپاره د اعتبار وړ وي ، کوم چې د `isize::MAX` څخه لوی نشي.
        // بیرته راټول شوی ټوټه هیڅکله بدلون نه کوي.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}