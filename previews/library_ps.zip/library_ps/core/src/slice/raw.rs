//! د `&[T]` او `&mut [T]` رامینځته کولو لپاره وړیا دندې.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// د اشارې او اوږدوالي څخه سلایش جوړوي.
///
/// د `len` دلیل د **عناصر** شمیره ده ، نه د بایټونو شمیر.
///
/// # Safety
///
/// چلند له سره ټاکل شوي ندي که کوم یو له لاندې شرایطو څخه سرغړونه وي:
///
/// * `data` د `len * mem::size_of::<T>()` ډیری بایټونو لوستلو لپاره باید [valid] وي ، او دا باید په سم ډول تنظیم شي.دا په ځانګړي ډول معنی لري:
///
///     * د دې ټوټې بشپړ حافظې لړۍ باید د یو واحد تخصیص شوي شي دننه ولري!
///       سلیز هیڅکله نشي کولی د ګ allocated شمیر تخصیص شوي توکو څخه تیر شي.د مثال په توګه [below](#incorrect-usage) وګورئ چې دا په پام کې نه نیسي.
///     * `data` باید حتما غیر خالص وي او حتی د صفر اوږدوالي سلیزو لپاره.
///     د دې لپاره یو دلیل دا دی چې د اینوم ترتیب اصلاح کول ممکن په مآخذونو تکیه وکړي (د هرې اندازې سلیزو په شمول) ترتیب شوي او غیر خالي کول ترڅو د نورو معلوماتو څخه توپیر وکړي.
///     تاسو کولی شئ داسې نښه ترلاسه کړئ چې د [`NonNull::dangling()`] په کارولو سره د صفر اوږدوالي سلیسونو لپاره د `data` په توګه د کارولو وړ وي.
///
/// * `data` د `T` ډول ډول په سمه توګه پیل شوي ارزښتونو ته باید د `len` په نښه کړئ.
///
/// * د بیرته سلیس لخوا حواله شوی حافظه باید د ژوند `'a` دورې لپاره بدله نه شي ، پرته لدې چې د `UnsafeCell` دننه.
///
/// * د ټوټې مجموعی اندازه `len * mem::size_of::<T>()` باید د `isize::MAX` څخه لوی نه وي.
///   د [`pointer::offset`] د خوندیتوب اسناد وګورئ.
///
/// # Caveat
///
/// د بیرته راټول شوي سلیس لپاره ژوند د دې کارول څخه تخفیف شوی.
/// د ناڅاپي ناوړه ګټه اخیستنې مخنیوي لپاره ، وړاندیز شوی چې د ژوند هر اړخ پورې وتړي چې د سرچینې ژوند په شرایطو کې خوندي وي ، لکه د مرستندویه فعالیت چمتو کولو له لارې چې د ټوټې لپاره د کوربه ارزښت ژوند اخلي ، یا د څرګند تشریح کولو له لارې.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // د یو واحد عنصر لپاره سلیس څرګند کړئ
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### غلط استعمال
///
/// لاندې د `join_slices` فعالیت **بې بنسټه** is دی
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // پورتنۍ ادعا ډاډ ورکوي چې `fst` او `snd` متناقض دي ، مګر دوی ممکن لاهم د _different allocated objects_ دننه وي ، پدې حالت کې د دې ټوټې رامینځته کول غیر تعریف شوي چلند دی.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` او `b` مختلف مختص شوي شیان دي ...
///     let a = 42;
///     let b = 27;
///     // ... کوم چې بیا هم کیدی شي په حافظه کې په متنازعه توګه ایښودل شي: |الف |ب |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // خوندي: زنګ وهونکی باید د `from_raw_parts` لپاره د خوندیتوب تړون ملاتړ وکړي.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// د [`from_raw_parts`] په څیر ورته فعالیت ترسره کوي ، پرته لدې چې یو بدلیدونکی ټوټه بیرته راشي.
///
/// # Safety
///
/// چلند له سره ټاکل شوي ندي که کوم یو له لاندې شرایطو څخه سرغړونه وي:
///
/// * `data` د `len * mem::size_of::<T>()` ډیری بیوټونو لپاره دواړه لوستلو او لیکلو لپاره باید [valid] وي ، او دا باید په سم ډول تنظیم شي.دا په ځانګړي ډول معنی لري:
///
///     * د دې ټوټې بشپړ حافظې لړۍ باید د یو واحد تخصیص شوي شي دننه ولري!
///       سلیز هیڅکله نشي کولی د ګ allocated شمیر تخصیص شوي توکو څخه تیر شي.
///     * `data` باید حتما غیر خالص وي او حتی د صفر اوږدوالي سلیزو لپاره.
///     د دې لپاره یو دلیل دا دی چې د اینوم ترتیب اصلاح کول ممکن په مآخذونو تکیه وکړي (د هرې اندازې سلیزو په شمول) ترتیب شوي او غیر خالي کول ترڅو د نورو معلوماتو څخه توپیر وکړي.
///
///     تاسو کولی شئ داسې نښه ترلاسه کړئ چې د [`NonNull::dangling()`] په کارولو سره د صفر اوږدوالي سلیسونو لپاره د `data` په توګه د کارولو وړ وي.
///
/// * `data` د `T` ډول ډول په سمه توګه پیل شوي ارزښتونو ته باید د `len` په نښه کړئ.
///
/// * د بیرته سلیس لخوا اشاره شوي یادداشت باید د ژوند `'a` دورې لپاره د کوم بل نښه کونکي (د بیرته ستنیدو ارزښت څخه نه اخیستل شوي) له لارې لاسرسی ونلري.
///   دواړه د لوستلو او لیکلو لاسرسی منع دی.
///
/// * د ټوټې مجموعی اندازه `len * mem::size_of::<T>()` باید د `isize::MAX` څخه لوی نه وي.
///   د [`pointer::offset`] د خوندیتوب اسناد وګورئ.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // خوندي: زنګ وهونکی باید د `from_raw_parts_mut` لپاره د خوندیتوب تړون ملاتړ وکړي.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T ته مراجعه د لمړی لمړی ټوټې (د کاپي کولو پرته) بدلوي.
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T ته مراجعه د لمړی لمړی ټوټې (د کاپي کولو پرته) بدلوي.
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}