//! میکروس د سلیس تکرارونکو لخوا کارول کیږي.

// لیکنه is_empty او لین د لوی فعالیت توپیر رامینځته کوي
macro_rules! is_empty {
    // په هغه لاره چې موږ د ZST تکرار اوږدوالي ته کوډ ورکوو ، دا د ZST او غیر ZST لپاره کار کوي.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// د ځینې حدود چیکونو څخه د خلاصون لپاره (وګورئ `position`) ، موږ اوږدوالی په یو څه ناڅاپي ډول محاسبه کوو.
// (د `کوډګن/سلیس پوزیشن-حدود چیک` لخوا ازمول شوی.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // موږ ځینې وختونه د غیر خوندي بلاک دننه کارول کیږو

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // دا _cannot_ د `unchecked_sub` کاروي ځکه چې موږ د اوږدې ZST سلایټ تکرار کونکو نمایندګي کولو لپاره په ریپینګ تکیه کوو.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // موږ پوهیږو چې `start <= end` ، نو د `offset_from` په پرتله ښه کار کولی شي ، کوم چې په لاسلیک کې معاملو ته اړتیا لري.
            // دلته د مناسب بیرغونو تنظیم کولو سره موږ کولی شو دا LLVM ته ووایو ، کوم چې دا د حد چیکونو لرې کولو کې مرسته کوي.
            // خوندي: د بریدګر ډول په واسطه ، `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // د LLVM په ویلو سره چې نښې د دقیق اندازې دقیق څو سره جلا کیږي ، دا کولی شي د `(end - start) < size` پرځای `len() == 0` ته `len() == 0` غوره کړي.
            //
            // خوندي: د بریدګر ډول په واسطه ، نښې په ترتیب شوي دي نو
            //         د دوی ترمینځ فاصله باید د نقطې اندازې ډیری وي
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// د `Iter` او `IterMut` تکرارونو مشترکه تعریف
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // لومړی عنصر راستنوي او د تکرار پیل د 1 لخوا مخکې ځي.
        // د زړه راښکونکي فعالیت په پرتله فعالیت په عالي توګه وده کوي.
        // تکرار کونکی باید خالي نه وي.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // وروستی عنصر راستنوي او د تکرار پای د 1 لخوا بیرته حرکت کوي.
        // د زړه راښکونکي فعالیت په پرتله فعالیت په عالي توګه وده کوي.
        // تکرار کونکی باید خالي نه وي.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // تکرار کونکي کموي کله چې T د ZST وي ، د تکرار پای د `n` لخوا شاته حرکت سره.
        // `n` باید د `self.len()` څخه زیات نشي.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // د تکرار کونکي څخه د سلیس جوړولو لپاره مرسته کونکي فعالیت.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // خوندي: تکرار کونکی د اشارې سره د ټوټې څخه جوړ شوی و
                // `self.ptr` او اوږدوالی `len!(self)`.
                // دا تضمین ورکوي چې د `from_raw_parts` لپاره ټول شرایط پوره شوي.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // د `offset` عناصرو لخوا د تیریدونکي حرکتونو د حرکت حرکت لپاره مرستندویه فعالیت ، زاړه پیل بیرته راستنیدل.
            //
            // غیر محفوظ ځکه چې آفسیټ باید د `self.len()` څخه ډیر نه وي.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // خوندي: زنګ وهونکی تضمین کوي چې `offset` له `self.len()` څخه زیات نه وي ،
                    // نو دا نوی پوائنټر د `self` دننه دی او پدې توګه د غیر خالي کیدو تضمین دی.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // د `offset` عناصرو لخوا د تیریدونکي پای ته د حرکت لپاره د مرستندویه فعالیت ، نوې پای ته راستنیدل.
            //
            // غیر محفوظ ځکه چې آفسیټ باید د `self.len()` څخه ډیر نه وي.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // خوندي: زنګ وهونکی تضمین کوي چې `offset` له `self.len()` څخه زیات نه وي ،
                    // کوم چې د `isize` جریان نه تضمین دی.
                    // همچنان ، پایله یې د `slice` په حدود کې ده ، کوم چې د `offset` لپاره نورې اړتیاوې پوره کوي.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // د ټوټو سره تطبیق کیدلی شو، مګر دا د چیک چیکونو څخه مخنیوی کوي

                // خوندي: د سلیس پیل پوائنټر راهیسې د `assume` زنګونه خوندي دي
                // باید غیر خالص وي ، او په غیر ZSTs باندې سلیسونه هم باید د غیر غیر پای پای ټکی وي.
                // `next_unchecked!` ته زنګ خوندي دی ځکه چې موږ ګورو چې ایا تکرار کونکی لومړی خالی دی.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // دا تکرار کونکی اوس خالي دی.
                    if mem::size_of::<T>() == 0 {
                        // موږ دا باید پدې توګه وکړو ځکه چې `ptr` ممکن هیڅکله 0 نه وي ، مګر `end` کیدی شي (د ریپینګ له امله).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // : endFYY: endﺎ 0 can't can't be be. be.. T if T T T T ZST isn't isn't because because because because because because ptr 0 end end end end> end>> end.=.====ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // امنیت: موږ حدود کې یو.`post_inc_start` حتی د ZSTs لپاره سم کار کوي.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // موږ د ډیفالټ تطبیق له سره تنظیم کوو ، کوم چې `try_fold` کاروي ، ځکه چې دا ساده پلي کول لږ LLVM IR رامینځته کوي او تالیف یې ګړندی دی.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // موږ د ډیفالټ تطبیق له سره تنظیم کوو ، کوم چې `try_fold` کاروي ، ځکه چې دا ساده پلي کول لږ LLVM IR رامینځته کوي او تالیف یې ګړندی دی.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // موږ د ډیفالټ تطبیق له سره تنظیم کوو ، کوم چې `try_fold` کاروي ، ځکه چې دا ساده پلي کول لږ LLVM IR رامینځته کوي او تالیف یې ګړندی دی.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // موږ د ډیفالټ تطبیق له سره تنظیم کوو ، کوم چې `try_fold` کاروي ، ځکه چې دا ساده پلي کول لږ LLVM IR رامینځته کوي او تالیف یې ګړندی دی.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // موږ د ډیفالټ تطبیق له سره تنظیم کوو ، کوم چې `try_fold` کاروي ، ځکه چې دا ساده پلي کول لږ LLVM IR رامینځته کوي او تالیف یې ګړندی دی.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // موږ د ډیفالټ تطبیق له سره تنظیم کوو ، کوم چې `try_fold` کاروي ، ځکه چې دا ساده پلي کول لږ LLVM IR رامینځته کوي او تالیف یې ګړندی دی.
            // همچنان ، `assume` د حدود چیک څخه مخنیوی کوي.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // خوندي: موږ تضمین لرو چې د لوپ بریدګر لخوا حدود کې وي:
                        // کله چې `i >= n` ، `self.next()` `None` بیرته راولي او لوپ مات شي.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // موږ د ډیفالټ تطبیق له سره تنظیم کوو ، کوم چې `try_fold` کاروي ، ځکه چې دا ساده پلي کول لږ LLVM IR رامینځته کوي او تالیف یې ګړندی دی.
            // همچنان ، `assume` د حدود چیک څخه مخنیوی کوي.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // خوندي: `i` باید د `n` څخه ټیټ وي ځکه چې دا په `n` کې پیل کیږي
                        // او یوازې کمیږي.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // خوندي: زنګ وهونکی باید تضمین وکړي چې د `i` حدود کې دي
                // لاندینی سلیس ، نو ځکه `i` نشي کولی `isize` پراخه کړي ، او بیرته راګرځول شوي تضمین د سلایس عنصر ته راجع کولو تضمین دی او پدې توګه د باوري کیدو تضمین شتون لري.
                //
                // دا هم په یاد ولرئ چې زنګ وهونکی هم تضمین کوي چې موږ بیا هیڅکله ورته ورته شاخص سره اړیکه نه ده نیولې ، او دا چې نور میتودونه چې دې پیرود ته لاسرسی ونلري ، نو دا د راستنیدونکي حوالې لپاره د اعتبار وړ ده چې په قضیه کې یې تغیر وکړي.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // د ټوټو سره تطبیق کیدلی شو، مګر دا د چیک چیکونو څخه مخنیوی کوي

                // خوندي: د `assume` تلیفونونه خوندي دي ځکه چې د سلایس پیل ټکي باید غیر خالي وي ،
                // او په غیر ZSTs باندې سلیسونه هم باید د غیر غیر پای پای ټکی وي.
                // `next_back_unchecked!` ته زنګ خوندي دی ځکه چې موږ ګورو چې ایا تکرار کونکی لومړی خالی دی.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // دا تکرار کونکی اوس خالي دی.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // امنیت: موږ حدود کې یو.`pre_dec_end` حتی د ZSTs لپاره سم کار کوي.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}