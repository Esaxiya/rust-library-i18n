// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// د `[mid-left, mid+right)` اندازه داسې ګرځوي چې په `mid` کې عنصر لومړی عنصر شي.په مساوي ډول ، د `left` عناصر کی left اړخ ته X یا `right` عناصر ښي خوا ته ګرځوي.
///
/// # Safety
///
/// ټاکل شوې لړۍ باید د لوستلو او لیکلو لپاره د اعتبار وړ وي.
///
/// # Algorithm
///
/// الګوریتم 1 د `left + right` کوچني ارزښتونو لپاره یا د لوی `T` لپاره کارول کیږي.
/// عناصر خپلو وروستي پوستونو ته یوځل په یو وخت کې د `mid - left` څخه پیل کیږي او د `right` مرحلو ترمینځ پرمخ وړل ماډلو `left + right` ، لکه یوازې یو لنډمهاله ته اړتیا لیدل کیږي.
/// په نهایت کې ، موږ بیرته `mid - left` ته راځو.
/// په هرصورت ، که `gcd(left + right, right)` 1 نه وي ، پورتني ګامونه د عناصرو څخه لرې شوي.
/// د مثال په توګه:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// خوشبختانه ، د نهایی شوي عناصرو ترمینځ د پریښودو شمیره تل مساوي وي ، نو موږ کولی شو یوازې زموږ د پیل موقعیت له مینځه یوسو او ډیر پړاوونه ترسره کړو (د ګردونو مجموعی شمیره د `gcd(left + right, right)` value) دی.
///
/// وروستۍ پایله دا ده چې ټول عناصر یو ځل او یوازې یو ځل نهایی کیږي.
///
/// الګوریتم 2 کارول کیږي که چیرې `left + right` لوی وي مګر `min(left, right)` دومره کوچنی دی چې په سټا بفر کې فټ شي.
/// د `min(left, right)` عناصر په بفر کې کاپي شوي ، `memmove` نورو ته پلي کیږي ، او هغه چې په بفر کې دي بیرته د مخالف لوري سوري ته اړول شوي چیرې چې سرچینه اخیستې.
///
/// الګوریتمونه چې وکټور شي کیدی شي یوځل چې `left + right` کافی لوی شي.
/// د الګوریتم 1 کولی شي په یوځل کې ډیری پړاوونه وټکوي او ترسره کړي ، مګر په اوسط ډول خورا ډیرې دورې شتون لري تر دې چې `left + right` خورا لوی نه وي ، او د یوې دورې بدترین قضیه تل هلته وي.
/// پرځای یې ، الګوریتم 3 د `min(left, right)` عناصرو تکرار تبادله کاروي تر هغه چې یو کوچنی گردش ستونزه پاتې شي.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// کله چې د `left < right` بدلول پرځای د کی left اړخ څخه پیښیږی.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. لاندې الګوریتمونه ناکامي کیدی شي که دا قضیې نه وي معاینه شوي
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // د الګوریتم 1 مایکرو بینچمارکونه په ګوته کوي چې د `left + right == 32` پورې شاوخوا د تصادفي شفټونو لپاره اوسط فعالیت خورا ښه دی ، مګر د بد حالت قضیه یې حتی د 16 شاوخوا ماتوي.
            // 24 د مینځنۍ ځمکې په توګه غوره شوی و.
            // که د `T` اندازه د 4 `usize`s څخه لوی وي ، نو دا الګوریتم نور الګوریتمونه هم ښه کوي.
            //
            //
            let x = unsafe { mid.sub(left) };
            // د لومړي پړاو پیل
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` د `gcd(left + right, right)` محاسبه کولو سره د لاس دمخه موندل کیدی شي ، مګر دا یو لپ ترسره کول ګړندي دي کوم چې د ضمني اثر په توګه gcd محاسبه کوي ، بیا پاتې برخه ترسره کوي
            //
            //
            let mut gcd = right;
            // معیارونه څرګندوي چې د لنډمهاله توبونو بدلول ګړندي دي د دې پرځای چې یوځل یوځل لنډمهاله لوستل شي ، وروسته کاپي کول ، او بیا په لنډ وخت کې لنډمهاله لیکل.
            // دا احتمال د دې حقیقت له امله دی چې د عارضي تغیراتو یا ځای په ځای کولو کې د دوه تنظیم کولو ته اړتیا پرځای په لوپ کې یوازې د حافظې پتې کاروي.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // د `i` زیاتوالي پرځای او بیا چیک کول که چیرې دا حدود څخه بهر وي ، موږ ګورو چې ایا `i` به په راتلونکي انکراینټ کې د حد څخه بهر لاړ شي.
                // دا د نښو یا `usize` هرډول مخه نیسي.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // د لومړي پړاو پای
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // دا مشروط باید دلته وي که `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ټوپک نور پړاوونو سره ختم کړئ
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` دا د صفر اندازې ډول ندی ، نو دا سمه ده چې د هغې اندازې سره ویشئ.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // الګوریتم 2 د `[T; 0]` دلته د دې ډاډ ترلاسه کولو لپاره دی چې دا د T لپاره مناسب ترتیب شوی
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // د الګوریتم 3 د بدلولو بدیل لاره شتون لري چې پکې موندل د دې الګوریتم وروستی تغیر چیرې وي ، او د دې الګوریتم په څیر د نږدې برخې بدلولو پرځای د دې وروستي برخې په کارولو سره تبادله کول دي ، مګر دا لاره لاهم ګړندۍ ده.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // الګوریتم 3 ، `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}