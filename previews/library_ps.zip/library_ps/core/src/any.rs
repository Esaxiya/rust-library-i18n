//! دا انډول د `Any` trait تطبیقوي ، کوم چې د رن ټائم انعکاس له لارې د هر ډول `'static` ډول متحرک ټایپینګ وړوي.
//!
//! `Any` پخپله د `TypeId` ترلاسه کولو لپاره کارول کیدی شي ، او ډیرې ب featuresې لري کله چې د trait څیز په توګه وکارول شي.
//! لکه څنګه چې `&dyn Any` (د پور اخیستل شوی trait څیز) ، دا د `is` او `downcast_ref` میتودونه لري ، دا ازموینه کوي چې که موجود ارزښت د ورکړل شوي نوعیت څخه وي ، او د نوعیت په توګه داخلي ارزښت ته مراجعه وکړي.
//! لکه څنګه چې د `&mut dyn Any` ، د `downcast_mut` میتود هم شتون لري ، داخلي ارزښت ته د تغیر وړ حوالې ترلاسه کولو لپاره.
//! `Box<dyn Any>` د `downcast` میتود اضافه کوي ، کوم چې په `Box<T>` بدلولو هڅه کوي.
//! د بشپړ توضیحاتو لپاره د [`Box`] اسناد وګورئ.
//!
//! په یاد ولرئ چې `&dyn Any` په آزموینې پورې محدود دی چې ایا ارزښت د مشخص کانکریټ ډول دی ، او د ازموینې لپاره نشي کارول کیدی چې ایا یو ډول trait تطبیقوي.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # سمارټ پوینټرې او `dyn Any`
//!
//! د چلند یوه برخه چې په ذهن کې وساتئ کله چې `Any` د trait څیز په توګه وکاروئ ، په ځانګړي توګه د `Box<dyn Any>` یا `Arc<dyn Any>` په څیر ډولونو سره ، دا په ساده ډول د ارزښت ویلو په اړه د `.type_id()` تلیفون کول به د *کانټینر*`TypeId` تولید کړي ، نه اصلي trait اعتراض.
//!
//! دا د سمارټ پوائنټر په بدل کې `&dyn Any` ته اړولو څخه مخنیوی کیدی شي ، کوم چې به د اعتراض `TypeId` بیرته راشي.
//! د مثال په توګه:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // تاسو ډیر احتمال دا غواړئ:
//! let actual_id = (&*boxed).type_id();
//! // ... له دې څخه:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! یو داسې وضعیت ته پام وکړئ چیرې چې موږ غواړو یو فنکشن ته ورکړل شوي ارزښت وتښتو.
//! موږ هغه ارزښت پوهیږو چې موږ د پلي کولو ډیبګ باندې کار کوو ، مګر موږ د دې کانکریټ ډول نه پوهیږو.موږ غواړو ځانګړو ډولونو ته ځانګړې درملنه وکړو: پدې حالت کې د سټینګ ارزښتونو اوږدوالي چاپ کول د دوی ارزښت دمخه.
//! موږ د کمپیل وخت کې زموږ د ارزښت کانکریټ ډول نه پوهیږو ، نو موږ د دې پرځای د وخت وخت انعکاس کارولو ته اړتیا لرو.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // د هر ډول لپاره د لاګر فعالیت چې د ډیبګ پلي کوي.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // هڅه وکړئ چې زموږ ارزښت په `String` بدل کړئ.
//!     // که بریالی وي ، موږ غواړو د سټرینګ اوږدوالي او همدارنګه د هغې ارزښت وآزمو.
//!     // که نه ، دا یو بل ډول دی: یوازې دا غیر محصله چاپ کړئ.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // دا فنکشن غواړي د دې سره کار کولو دمخه خپل پیرامیټر بهر کړي.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... یو څه نور کار وکړئ
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// کوم trait
///////////////////////////////////////////////////////////////////////////////

/// د ډینامیک ټایپ کولو تقلید لپاره یو trait.
///
/// ډیری ډولونه `Any` پلي کوي.په هرصورت ، هر ډول کوم چې د غیر ایسټیک حواله لري نه کوي.
/// د نورو جزیاتو لپاره [module-level documentation][mod] وګورئ.
///
/// [mod]: crate::any
// دا trait غیر محفوظ نه دی ، که څه هم موږ په غیر خوندي کوډ کې د مثال په توګه د XP1X فعالیت په ځانګړتیاو تکیه کوو (د بیلګې په توګه ، `downcast`).په نورمال ډول ، دا به ستونزه وي ، مګر ځکه چې د `Any` یوازینی امپلیټ د کمپلې پلي کول دي ، نو نور کوډ نشي کولی `Any` تطبیق کړي.
//
// موږ کولی شو په ظاهره توګه دا trait غیر محفوظ کړو-دا به د ماتېدو لامل نه شي ، ځکه چې موږ ټول پلي کونکي کنټرول کوو-مګر موږ غوره نه کوو چې دا دواړه واقعیا اړین ندي او ممکن د کاروونکو د ناخوندي traits او غیر خوندي میتودونو توپیر په اړه مغشوش کړي (لکه ، `type_id` به د زنګ وهلو لپاره خوندي وي ، مګر موږ احتمال به ورته په نښه کړو لکه په اسنادو کې).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// د `self` `TypeId` ترلاسه کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// د هر trait څیزونو لپاره د غزولو میتودونه.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ډاډ ترلاسه کړئ چې د مثال په توګه ، په مزي کې یوځای کیدل چاپ کیدلی شي او له همدې امله د `unwrap` سره کارول کیږي.
// ممکن په نهایت کې نور اړتیا ونلري که لیږد د توضیحاتو سره کار وکړي.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// `true` راګرځوي که د بکس شوي ډول د `T` ورته وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // د `TypeId` ډول ډول ترلاسه کړئ چې دا فن په انسټینټ شوی دی.
        let t = TypeId::of::<T>();

        // د ډول ډول `TypeId` په trait څیز (`self`) کې ترلاسه کړئ.
        let concrete = self.type_id();

        // په مساواتو کې دواړه `TypeId` پرتله کړئ.
        t == concrete
    }

    /// بکس شوي ارزښت ته ځینې حواله ورکوي که دا د `T` ډول وي ، یا `None` وي که نه وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // خوندي: یوازې چیک شوي چې ایا موږ سم ډول ته ګوته نیسو ، او موږ تکیه کولی شو
            // دا د حافظې خوندیتوب لپاره ګوري ځکه چې موږ د هر ډول لپاره پلي کړی؛نور هیڅ ډول اثر شتون نلري ځکه چې دا زموږ له اغیزو سره په ټکر کې دي.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// بکس شوي ارزښت ته ځینې بدلیدونکي حواله ورکوي که دا د `T` ډول وي ، یا `None` وي که نه.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // خوندي: یوازې چیک شوي چې ایا موږ سم ډول ته ګوته نیسو ، او موږ تکیه کولی شو
            // دا د حافظې خوندیتوب لپاره ګوري ځکه چې موږ د هر ډول لپاره پلي کړی؛نور هیڅ ډول اثر شتون نلري ځکه چې دا زموږ له اغیزو سره په ټکر کې دي.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// د `Any` ډول کې ټاکل شوې میتود ته وړاندې.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// د `Any` ډول کې ټاکل شوې میتود ته وړاندې.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// د `Any` ډول کې ټاکل شوې میتود ته وړاندې.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// د `Any` ډول کې ټاکل شوې میتود ته وړاندې.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// د `Any` ډول کې ټاکل شوې میتود ته وړاندې.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// د `Any` ډول کې ټاکل شوې میتود ته وړاندې.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ټایپ آیډ او د هغې میتودونه
///////////////////////////////////////////////////////////////////////////////

/// A `TypeId` د نوع لپاره په نړیواله کچه ځانګړی پیژندونکی استازیتوب کوي.
///
/// هر `TypeId` یو مبهم شی دی چې دننه دننه د تفتیش اجازه نه ورکوي مګر د لومړني عملیاتو اجازه ورکوي لکه کلون کول ، پرتله کول ، چاپ کول او ښودل.
///
///
/// یو `TypeId` اوس مهال یوازې د هغه ډولونو لپاره شتون لري چې د `'static` سره مل وي ، مګر دا محدودیت ممکن په future کې لرې شي.
///
/// پداسې حال کې چې `TypeId` `Hash` ، `PartialOrd` ، او `Ord` تطبیقوي ، دا د پام وړ ارزښت لري چې د hashes او ترتیب کول به د Rust ریلیزونو تر مینځ توپیر ولري.
/// د خپل کوډ دننه د دوی تکیه کولو څخه خبر اوسئ!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// د `TypeId` ډول ډول راګرځوي چې دا عمومي فعالیت پکې انسټيټ شوی و.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// د ډول نوم نوم د تار سلیس په توګه.
///
/// # Note
///
/// دا د تشخیصي کارونې لپاره دی.
/// د راستنیدونکي تار دقیق مینځپانګه او ب formatه نده مشخص شوي ، بل دا چې د ډول غوره هڅه کولو توضیح کولو څخه علاوه.
/// د مثال په توګه ، د هغه تارونو په مینځ کې چې `type_name::<Option<String>>()` ممکن بیرته راشي `"Option<String>"` او `"std::option::Option<std::string::String>"` دي.
///
///
/// بیرته راغلی تار باید د یو نوع ځانګړی پیژندونکی ونه ګ .ل شي ځکه چې ډیری ډولونه ورته ورته نوم ته نقشه کولی شي.
/// په ورته ډول ، هیڅ تضمین شتون نلري چې د ډول ډول ټولې برخې به په بیرته ستنیدو کې څرګند شي: د بیلګې په توګه ، د اوسني ژوند ځانګړي کونکي پکې شامل ندي.
/// سربیره پردې ، محصول ممکن د کمپیلر نسخو ترمینځ بدل شي.
///
/// اوسني پلي کول ورته جوړښت د کمپیلر تشخیصاتو او ډیبګینفو په توګه کاروي ، مګر دا تضمین ندي.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// د ټکي-ارزښت ارزښت ډول د تار ټوټې په نوم.
/// دا د `type_name::<T>()` په څیر ورته دی ، مګر کارول کیدی شي چیرې چې د تغیر ډول په اسانۍ سره شتون نلري.
///
/// # Note
///
/// دا د تشخیصي کارونې لپاره دی.د تار ریښتیني مینځپانګې او ب formatه مشخص ندي شوي ، بل دا چې د ډول غوره هڅه کولو توضیح کولو څخه پرته.
/// د مثال په توګه ، `type_name_of_val::<Option<String>>(None)` کولی شي `"Option<String>"` یا `"std::option::Option<std::string::String>"` بیرته راولي ، مګر `"foobar"` نه.
///
/// سربیره پردې ، محصول ممکن د کمپیلر نسخو ترمینځ بدل شي.
///
/// دا فنکشن د trait څیزونه نه حل کوي ، پدې معنی چې `type_name_of_val(&7u32 as &dyn Debug)` ممکن `"dyn Debug"` بیرته راشي ، مګر `"u32"` نه.
///
/// د ډول نوم باید د یو ډول ځانګړی پیژندونکی ونه ګ ؛ل شي؛
/// ډیری ډولونه ممکن ورته ورته نوم شریک کړي.
///
/// اوسني پلي کول ورته جوړښت د کمپیلر تشخیصاتو او ډیبګینفو په توګه کاروي ، مګر دا تضمین ندي.
///
/// # Examples
///
/// د ډیفالټ عدد او فلوټ ډولونه چاپوي.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}