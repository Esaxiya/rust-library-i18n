//! د ترتیب او پرتله کولو لپاره فعالیت.
//!
//! دا موډل د ترتیب کولو او ارزښتونو پرتله کولو لپاره بیلابیل وسیلې لري.په لنډیز کې:
//!
//! * [`Eq`] او [`PartialEq`] traits دي چې تاسو ته اجازه درکوي په ترتیب سره د ارزښتونو تر مینځ مجموعي او جزوي مساوات تعریف کړئ.
//! د دوی پلي کول د `==` او `!=` آپریټرونو څخه ډیر کوي.
//! * [`Ord`] او [`PartialOrd`] د traits دي چې تاسو ته اجازه درکوي په ترتیب سره د ارزښتونو تر منځ ټول او جزوي ترتیب تعریف کړئ.
//!
//! د دوی پلي کول د `<` ، `<=` ، `>` ، او `>=` آپریټرونو څخه ډیر کوي.
//! * [`Ordering`] د اینوم دی چې د [`Ord`] او [`PartialOrd`] د اصلي دندو لخوا بیرته راستانه شوی ، او د سپارښتنې توضیح کوي.
//! * [`Reverse`] یو داسې جوړښت دی چې تاسو ته اجازه درکوي په اسانۍ سره غوښتنه ترتیب کړئ.
//! * [`max`] او [`min`] هغه دندې دي چې د [`Ord`] څخه جوړوي او تاسو ته اجازه درکوي چې اعظمي یا لږترلږه دوه ارزښتونه ومومئ.
//!
//! د نورو معلوماتو لپاره ، په لیست کې د هر توکي اړوند اسناد وګورئ.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// د مساواتو پرتله کولو لپاره Trait چې [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) وي.
///
/// دا trait د جزوي مساواتو لپاره اجازه ورکوي ، د هغه ډولونو لپاره چې د بشپړ مساواتو اړیکې نلري.
/// د مثال په توګه ، د فلوټینګ پوائنټونو `NaN != NaN` کې ، نو د فلوینګ پوینټ ډولونه `PartialEq` پلي کوي مګر [`trait@Eq`] نه.
///
/// په رسمي ډول ، مساوات باید وي (د ټولو `a` ، `b` ، `A` ډول `A` ، `B` ، `C` لپاره):
///
/// - **سیمالټ**: که `A: PartialEq<B>` او `B: PartialEq<A>` ، نو بیا **`a==b` ضمیمه کوي`b==a`**؛او
///
/// - **انتقالي**: که `A: PartialEq<B>` او `B: PartialEq<C>` او `A:
///   جزئيات<C>`، بیا **` a==b`او `b == c` ضمیمه کوي`a==c`**.
///
/// په یاد ولرئ چې د `B: PartialEq<A>` (symmetric) او `A: PartialEq<C>` (transitive) تطبیق شتون ته اړتیا نلري ، مګر دا اړتیاوې کله چې شتون ولري پلي کیږي.
///
/// ## Derivable
///
/// دا trait د `#[derive]` سره کارول کیدی شي.کله چې په ډډونو باندې ورګډ شي ، دوه حالتونه یو شان دي که چیرې ټولې ځمکې مساوي وي ، او مساوي نه وي که کومې ځمکې مساوي نه وي.کله چې په انیمونو باندې پوهیدل کیږي ، هر ډول پخپله مساوي دی او د نورو ویناوو سره مساوي ندي.
///
/// ## زه څنګه کولی شم `PartialEq` تطبیق کړم؟
///
/// `PartialEq` یوازې د [`eq`] میتود پلي کولو ته اړتیا لري؛[`ne`] د دې په شرایطو کې د ډیفالټ لخوا تعریف شوی.د [`ne`] * هر ډول لازمي پلي کول باید د دې قانون درناوی وکړي چې [`eq`] د [`ne`] سخت مقابل دی؛دا دی ، `!(a == b)` که او یوازې که `a != b`.
///
/// د `PartialEq` ، [`PartialOrd`] ، او [`Ord`]*پلي کول باید* د یو بل سره موافق وي.دا په اسانۍ سره د ځینې traits د ترلاسه کولو او د نورو په لاسي ډول د نورو پلي کولو په واسطه دوی سره راضي کول اسان ندي.
///
/// د یوې ډومین لپاره د مثال پلي کول په کوم کې چې دوه کتابونه ورته کتاب ګ areل کیږي که چیرې د دوی ISBN لوبه وکړي ، حتی که شکلونه یې توپیر ولري:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## څنګه کولی شم دوه مختلف ډولونه پرتله کړم؟
///
/// هغه ډول چې تاسو ورسره پرتله کولی شئ د `جزوی معیار type ډول پیرامیټر لخوا کنټرولیږي.
/// د مثال په توګه ، راځئ چې زموږ تیر کوډ یو څه ټک کړو:
///
/// ```
/// // د لاسته راوړنې تطبیقونه<BookFormat>==<BookFormat>پرتله کول
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // پلي کول<Book>==<BookFormat>پرتله کول
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // پلي کول<BookFormat>==<Book>پرتله کول
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// د `impl PartialEq for Book` `impl PartialEq<BookFormat> for Book` ته بدلولو سره ، موږ اجازه ورکوو `BookFormat`s د`Book`s سره پرتله کړو.
///
/// د پورتني په څیر پرتله کول ، کوم چې د سټراټ ځینې برخې له پامه غورځوي ، خطرناک کیدی شي.دا کولی شي د جزوي انډول اړیکې لپاره د غوښتنو څخه نامشروع سرغړونې لامل شي.
/// د مثال په توګه ، که موږ د `BookFormat` لپاره د `PartialEq<Book>` پورتني تطبیق وساتو او د `Book` لپاره د `PartialEq<Book>` تطبیق اضافه کړو (یا د `#[derive]` له لارې یا د لومړي مثال څخه د لاسي لارښود له لارې) نو پایله به د لیږد څخه سرغړونه وي:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// دا میتود د `self` او `other` ارزښتونو لپاره مساوي ازموینه کوي ، او د `==` لخوا کارول کیږي.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// دا طریقه د `!=` لپاره ازموي.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// د trait `PartialEq` د تطبیق وړ میکرو تولید.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// د مساواتو پرتله کولو لپاره Trait چې [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) وي.
///
/// پدې معنی چې ، د دې سربیره چې د `a == b` او `a != b` سخت برعکس وي ، مساوات باید باید وي (د ټولو `a` ، `b` او `c` لپاره):
///
/// - reflexive: `a == a`;
/// - سیمالټ: `a == b` د `b == a` معنی لري؛او
/// - انتقالي: `a == b` او `b == c` د `a == c` معنی لري.
///
/// دا ملکیت د تالیف کونکي لخوا نشي کتلی ، او له همدې امله `Eq` د [`PartialEq`] معنی لري ، او اضافي میتودونه نلري.
///
/// ## Derivable
///
/// دا trait د `#[derive]` سره کارول کیدی شي.
/// کله چې اختصاص کیږي ، ځکه چې `Eq` اضافي میتودونه نلري ، دا یوازې تالیف کونکي ته خبر ورکوي چې دا د یو اړخیز انډول اړیکې پرځای د انډولیز اړیکه ده.
///
/// په یاد ولرئ چې د `derive` ستراتیژي ټول ډګرونه ته اړتیا لري `Eq` دي ، کوم چې تل مطلوب ندي.
///
/// ## زه څنګه کولی شم `Eq` تطبیق کړم؟
///
/// که تاسو د `derive` تګلاره نشئ کارولی ، نو مشخص کړئ چې ستاسو ډول `Eq` پلي کوي ، کوم چې هیڅ میتود نلري:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // دا میتود یوازې د#[اخذ کولو] په واسطه کارول کیږي ترڅو دا تثبیت شي چې د نوعې هرې برخې پخپله پلي کوي [[لاسته راوړنې]] ، د اوسنۍ لاسته راوړنې زیربنا پدې معنی ده چې د دې trait میتود کارولو پرته دا ادعا کول نږدې ناممکن دي.
    //
    //
    // دا باید هیڅکله د لاس پواسطه پلي نشي.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// د trait `Eq` د تطبیق وړ میکرو تولید.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: دا جوړښت په بشپړ ډول د#[اخیر] لخوا کارول کیږي
// تاکید وکړئ چې د ډول هر برخې Eq تطبیقوي.
//
// دا جوړښت باید هیڅکله د کارونکي کوډ کې څرګند نشي.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// یو `Ordering` د دوه ارزښتونو تر منځ د پرتلې پایله ده.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// یو امر چېرته چې پرتله شوي ارزښت له بل څخه لږ وي.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// یو امر چېرته چې پرتله شوي ارزښت له بل سره مساوي وي.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// یو ترتیب چېرې چیرې پرتله پرتله شوي ارزښت له بل څخه ډیر وي.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// `true` راستنوي که ترتیب د `Equal` متغیر وي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// `true` راستنوي که ترتیب د `Equal` ډول نه وي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// `true` راستنوي که ترتیب د `Less` متغیر وي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// `true` راستنوي که ترتیب د `Greater` متغیر وي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// `true` راستنوي که ترتیب د `Less` یا `Equal` متغیر وي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// `true` راستنوي که ترتیب د `Greater` یا `Equal` متغیر وي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// د `Ordering` بدلوي.
    ///
    /// * `Less` په `Greater` شي.
    /// * `Greater` په `Less` شي.
    /// * `Equal` په `Equal` شي.
    ///
    /// # Examples
    ///
    /// لومړني چلند:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// دا میتود د پرتله کولو ریورس کولو لپاره کارول کیدی شي:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // له لوی څخه تر کوچني پورې صف بندی کړئ.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// دوه حکمونه ځنځیرونه.
    ///
    /// `self` راستنوي کله چې دا `Equal` نه وي.نور نو `other` بیرته راګرځي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// د ورکړل شوي فنکشن سره ترتیب ترتیب کول.
    ///
    /// `self` راستنوي کله چې دا `Equal` نه وي.
    /// نور نو `f` زنګ ووهي او پایله یې راوباسي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// د بيرته ترتيبولو لپاره مرسته کوونکی جوړښت.
///
/// دا جوړښت یو مرسته کونکی دی چې د [`Vec::sort_by_key`] په څیر دندو سره وکارول شي او د کیلي یوې برخې ریورس کولو لپاره وکارول شي.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// د ډولونو لپاره Trait چې [total order](https://en.wikipedia.org/wiki/Total_order) جوړوي.
///
/// یو آرډر مجموعي حکم دی که دا وي (د ټولو `a` ، `b` او `c` لپاره):
///
/// - ټول او غیر متناسب: د `a < b` ، `a == b` یا `a > b` څخه بالکل یو ریښتیا دی؛او
/// - انتقالي ، `a < b` او `b < c` د `a < c` معنی ورکوي.ورته باید دواړه د `==` او `>` لپاره وساتي.
///
/// ## Derivable
///
/// دا trait د `#[derive]` سره کارول کیدی شي.
/// کله چې په سټریکونو کې اختصاص شي ، نو دا به د جوړښت د غړو غړو له پورتنۍ څخه ښکته اعلامیې امر پراساس د [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) امر تولید کړي.
///
/// کله چې په اینامونو کې اختصاص شي ، ډولونه د دوی له پورته څخه تر ښکته تعصبي امر لخوا ترتیب شوي.
///
/// ## قاموسونه پرتله کول
///
/// لغوګرافیک پرتله کول د لاندې ملکیتونو سره عملیات دي:
///  - دوه تسلسل د عنصر لخوا عنصر سره پرتله کیږي.
///  - لومړی بې مسولیت عنصر دا تشریح کوي چې کوم ترتیب د بل په پرتله په لیکسونو کې لږ یا لوی دی.
///  - که چیرې یو ترتیب د بل مخکینۍ برخه وي ، نو لنډ ترتیب یې د بل په پرتله په لیکسوګرافیک ډول لږ دی.
///  - که دوه ترتیب مساوي عناصر ولري او د ورته اوږدوالي څخه وي ، نو بیا دا سلسلې په لغت کې مساوي دي.
///  - یو خالي ترتیب د کوم غیر خالي ترتیب څخه په لیکسوګرافیک ډول لږ دی.
///  - دوه خالي تسلسل په لغت کې مساوي دي.
///
/// ## زه څنګه کولی شم `Ord` تطبیق کړم؟
///
/// `Ord` اړتیا لري چې دا ډول هم [`PartialOrd`] او [`Eq`] وي (کوم چې [`PartialEq`] ته اړتیا لري).
///
/// بیا تاسو باید د [`cmp`] لپاره پلي کول تعریف کړئ.تاسو ممکن د خپل ډول په کروندو کې د [`cmp`] کارولو ګټور ومومئ.
///
/// د [`PartialEq`] ، [`PartialOrd`] ، او `Ord`*پلي کول باید* د یو بل سره موافق وي.
/// دا دی ، `a.cmp(b) == Ordering::Equal` که او یوازې که `a == b` او `Some(a.cmp(b)) == a.partial_cmp(b)` د ټولو `a` او `b` لپاره.
/// دا په اسانۍ سره د ځینې traits د ترلاسه کولو او د نورو په لاسي ډول د نورو پلي کولو په واسطه دوی سره راضي کول اسانه دي.
///
/// دلته یو مثال دی چیرې چې تاسو غواړئ یوازې د قد په واسطه خلک ترتیب کړئ ، د `id` او `name` په پام کې نیولو سره:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// دا طریقه د `self` او `other` تر منځ [`Ordering`] بیرته راولي.
    ///
    /// د کنوانسیون په واسطه ، `self.cmp(&other)` د آرکسینګ `self <operator> other` سره مل ترتیب وړاندې کوي که ریښتیا وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// اعظمي حد ته دوه ارزښتونه ورکوي.
    ///
    /// دوهم دلیل راستنوي که پرتله کول دوی مساوي وي.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// لږترلږه د دوه ارزښتونو پرتله کول او بیرته ورکول.
    ///
    /// لومړی دلیل راستنوي که پرتله کول دوی مساوي وي.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// یو ټاکل شوې وقفې ته ارزښت محدود کړئ.
    ///
    /// که `self` د `max` څخه لوی وي `max` ، او `min` بیرته راوړي که `self` د `min` څخه کم وي.
    /// نور نو دا `self` راستنوي.
    ///
    /// # Panics
    ///
    /// Panics که `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// د trait `Ord` د تطبیق وړ میکرو تولید.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// د ارزښتونو لپاره Trait چې د ترتیب تنظیم لپاره پرتله کیدی شي.
///
/// پرتله کول باید پوره کړي ، د ټولو `a` ، `b` او `c` لپاره:
///
/// - غیر متناسب: که `a < b` نو بیا `!(a > b)` ، او همدارنګه `a > b` د `!(a < b)` تطبیق کوي؛او
/// - لیږدیزتیا: `a < b` او `b < c` د `a < c` معنی لري.ورته باید دواړه د `==` او `>` لپاره وساتي.
///
/// په یاد ولرئ چې دا غوښتنې پدې معنی دي چې trait پخپله باید په متوازي او انتقالي ډول پلي شي: که `T: PartialOrd<U>` او `U: PartialOrd<V>` بیا `U: PartialOrd<T>` او `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// دا trait د `#[derive]` سره کارول کیدی شي.کله چې په سټریکونو باندې اختصاص شي ، دا به د لغت غړي له پورته څخه ښکته اعلامیې امر پراساس د اکتشافي ترتیب تولید وکړي.
/// کله چې په اینامونو کې اختصاص شي ، ډولونه د دوی له پورته څخه تر ښکته تعصبي امر لخوا ترتیب شوي.
///
/// ## زه څنګه کولی شم `PartialOrd` تطبیق کړم؟
///
/// `PartialOrd` یوازې د [`partial_cmp`] میتود پلي کولو ته اړتیا لري ، د نورو سره د ډیفالټ پلي کیدو څخه رامینځته شوی.
///
/// په هرصورت دا امکان لري چې نور د ډولونو لپاره په جلا توګه پلي کړئ کوم چې بشپړ حکم نلري.
/// د مثال په توګه ، د فلوټینګ پوائنټونو لپاره ، `NaN < 0 == false` او `NaN >= 0 == false` (cf.
/// د IEEE 754-2008 برخه 5.11).
///
/// `PartialOrd` ستاسو ډول د [`PartialEq`] کیدو ته اړتیا لري.
///
/// د [`PartialEq`] ، `PartialOrd` ، او [`Ord`]*پلي کول باید* د یو بل سره موافق وي.
/// دا په اسانۍ سره د ځینې traits د ترلاسه کولو او د نورو په لاسي ډول د نورو پلي کولو په واسطه دوی سره راضي کول اسانه دي.
///
/// که ستاسو ډول [`Ord`] وي ، نو تاسو کولی شئ د [`cmp`] په کارولو سره [`partial_cmp`] پلي کړئ:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// تاسو ممکن د خپل ډول په کروندو کې د [`partial_cmp`] کارول ګټور هم ومومئ.
/// دلته د `Person` ډولونو مثال دی چې د فلوټینګ-`height` ساحه لري چې یوازینی ډګر دی چې د ترتیب کولو لپاره کارول کیږي:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// دا میتود د `self` او `other` ارزښتونو تر مینځ ترتیب بیرته ورکوي که چیرې شتون ولري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// کله چې پرتله کول ناممکن وي:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// دا طریقه د (`self` او `other` لپاره) څخه ټیټ ټیسټ کوي او د `<` آپریټر لخوا کارول کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// دا میتود د (`self` او `other` لپاره) څخه لږ یا مساوي ازموینه کوي او د `<=` آپریټر لخوا کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// دا میتود د (`self` او `other` لپاره) څخه لوی ازمیښت کوي او د `>` آپریټر لخوا کارول کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// دا میتود د `self` او `other` لپاره لوی یا مساوي ازموینه کوي او د `>=` آپریټر لخوا کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// د trait `PartialOrd` د تطبیق وړ میکرو تولید.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// لږترلږه د دوه ارزښتونو پرتله کول او بیرته ورکول.
///
/// لومړی دلیل راستنوي که پرتله کول دوی مساوي وي.
///
/// په داخلي توګه [`Ord::min`] ته یو عرف کاروي.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// لږترلږه دوه ارزښتونه د ټاکل شوي پرتلې فعالیت ته په پام سره بیرته راګرځي.
///
/// لومړی دلیل راستنوي که پرتله کول دوی مساوي وي.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// هغه عنصر راستنوي چې د ټاکل شوي فنکشن څخه لږترلږه ارزښت ورکوي.
///
/// لومړی دلیل راستنوي که پرتله کول دوی مساوي وي.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// اعظمي حد ته دوه ارزښتونه ورکوي.
///
/// دوهم دلیل راستنوي که پرتله کول دوی مساوي وي.
///
/// په داخلي توګه [`Ord::max`] ته یو عرف کاروي.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// د ټاکل شوي پرتلې فعالیت ته په درناوي سره د دوو ارزښتونو اعظمي اعداد
///
/// دوهم دلیل راستنوي که پرتله کول دوی مساوي وي.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// هغه عنصر راستنوي چې د ټاکل شوي فنکشن څخه اعظمي ارزښت ورکوي.
///
/// دوهم دلیل راستنوي که پرتله کول دوی مساوي وي.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// د لومړني ډولونو لپاره د جزوي ايق ، ايق ، پارټيورډ او آرډ پلي کول
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // دلته امر د لازمي اسمبلۍ رامینځته کولو لپاره مهم دی.
                    // د نورو معلوماتو لپاره <https://github.com/rust-lang/rust/issues/63758> وګورئ.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // د آی 8 په اړه کاسټ کول او توپیر په آرډر کولو کې بدلول خورا غوره مجلس رامینځته کوي.
            //
            // د نورو معلوماتو لپاره <https://github.com/rust-lang/rust/issues/66780> وګورئ.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // خوندي: bool لکه څنګه چې i8 0 یا 1 بیرته راګرځوي ، نو توپیر یې هیڅ هم نشي کیدی
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // نښې

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}