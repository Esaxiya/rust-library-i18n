//! د تبادلې وړ وړ کانټینرونه.
//!
//! د Rust حافظه خوندیتوب د دې قواعد پر بنسټ والړ دی: د یو شي `T` ورکړل شوی ، دا یوازې ممکن دی چې لاندې لین څخه یو ولرئ:
//!
//! - X-X ایکس ایکس ته اعتراض ته د ډیری غیر متناسب حوالې درلودل (د **ایلیسینګ** په نامه هم پیژندل کیږي).
//! - څيز ته د بدليدو وړ مآخذ (`&mut T`) ورکول (د **بدلون** په نامه هم ياديږي)
//!
//! دا د Rust تالیف کونکي لخوا پلي شوی.په هرصورت ، داسې شرایط شتون لري چیرې چې دا قواعد په کافي اندازه نرم نه وي.ځینې وختونه اړین دي چې یو توکي ته ډیری مآخذونه ولرئ او لاهم یې بدل کړئ.
//!
//! د تبادلې وړ وړ بدلون وړ کانتینرونه په کنټرول شوي ډول د بدلیدو اجازه ورکولو لپاره شتون لري حتی د ایلیسینګ په شتون کې.دواړه [`Cell<T>`] او [`RefCell<T>`] اجازه ورکوي چې دا په یو اړخیز ډول ترسره کړي.
//! په هرصورت ، نه `Cell<T>` او `RefCell<T>` د مزي خوندي ندي (دوی [`Sync`] نه پلي کوي).
//! که تاسو اړتیا لرئ د ډیری موضوعاتو ترمینځ عليزین او بدلون رامینځته کړئ نو امکان لري د [`Mutex<T>`] ، [`RwLock<T>`] یا [`atomic`] ډولونه وکاروئ.
//!
//! د `Cell<T>` او `RefCell<T>` ډولونو ارزښتونه ممکن د شریک حوالې له لارې بدل شي
//! عام `&T` ډول) ، پداسې حال کې چې ډیری Rust ډولونه یوازې د ځانګړي (`&mut T`) حوالې له لارې بدلیدلی شي.
//! موږ وایو چې `Cell<T>` او `RefCell<T>` 'داخلي بدلون "چمتو کوي ، د Rust ډولونو سره په مقابل کې چې د' میراث بدلیدل 'څرګندوي.
//!
//! د حجرو ډولونه په دوه خوندونو کې راځي: `Cell<T>` او `RefCell<T>`.`Cell<T>` د `Cell<T>` دننه او بهر د ارزښتونو حرکت کولو سره د داخلي بدلون غوښتنه کوي.
//! د ارزښتونو پرځای حوالې کارولو لپاره ، یو څوک باید د `RefCell<T>` ډول وکاروي ، د بدلون کولو دمخه د لیک تالا ترلاسه کول.`Cell<T>` د داخلي اوسني ارزښت ترلاسه کولو او بدلولو لپاره میتودونه وړاندې کوي:
//!
//!  - د ډولونو لپاره چې [`Copy`] پلي کوي ، د [`get`](Cell::get) میتود اوسنی داخلي ارزښت ترلاسه کوي.
//!  - د ډولونو لپاره چې [`Default`] پلي کوي ، د [`take`](Cell::take) میتود د داخلي اوسنی ارزښت د [`Default::default()`] سره ځای په ځای کوي او ځای شوي ارزښت بیرته راولي.
//!  - د ټولو ډولونو لپاره ، د [`replace`](Cell::replace) میتود موجوده داخلي ارزښت ځای نیسي او ځای شوي ارزښت بیرته راولي او د [`into_inner`](Cell::into_inner) میتود `Cell<T>` مصرفوي او داخلي ارزښت بیرته راولي.
//!  سربیره پردې ، د [`set`](Cell::set) میتود د داخلي ارزښت ځای نیسي ، ځای پرځای شوي ارزښت پریږدي.
//!
//! `RefCell<T>` د متحرک پور اخیستنې پلي کولو لپاره د Rust ژوندون وختونه کاروي ، داسې پروسه چې له مخې یو څوک کولی شي داخلي ارزښت ته د لنډمهاله ، ځانګړي ، بدلون غوښتونکي لاسرسي ادعا وکړي.
//! د `RefCell لپاره پورونه<T>Z s د وخت په تیریدو سره تعقیب کیږي ، د Rust اصلي حوالې ډولونو برخلاف چې په بشپړ ډول په جامد ډول تعقیب شوي ، د وخت په وخت کې.
//! ځکه چې د `RefCell<T>` پور متحرک دي دا امکان لري چې د داسې یو پور د اخیستو هڅه وشي چې دمخه یې په متقابل ډول پور اخیستل شوی دی.کله چې دا پیښ شي نو دا د panic سلسله کې پایله لري.
//!
//! # کله چې د داخلي بدلونونو غوره کول
//!
//! ترټولو عام میراثي بدلون ، چیرې چې یو څوک باید د ارزښت بدلولو لپاره ځانګړي لاسرسي ولري ، د ژبې کلیدي عناصرو څخه یو دی چې Rust ته وړتیا ورکوي چې د نښې وتلو په اړه قوي دلیل وړاندې کړي ، د احصایوي حادثاتو مخه ونیسي.
//! د دې له امله ، په میراث کې تغیر ورکول غوره ګ ،ل کیږي ، او د داخلي بدلون بدلون د وروستي حل لاره ده.
//! څنګه چې د حجرو ډولونه بدلون ته وده ورکوي چیرې چې دا به بل ډول منع نه وي ، پداسې وختونو کې شتون لري کله چې د داخلي بدلون بدلون مناسب وي ، یا حتی *باید* وکارول شي ، د بیلګې په توګه.
//!
//! * د نه بدلیدونکي شي د 'inside' بدلولو معرفي کول
//! * د منطقي-غیر منطقي میتودونو پلي کولو توضیحات.
//! * د [`Clone`] پلي کولو پلي کول.
//!
//! ## د نه بدلیدونکي شي د 'inside' بدلولو معرفي کول
//!
//! د [`Rc<T>`] او [`Arc<T>`] په ګډون ډیری شریک شوي سمارټ پوینټرې ډولونه ، کانټینرونه چمتو کوي چې کولی شي د څو اړخونو تر مینځ کلون او شریک شي.
//! ځکه چې موجود ارزښتونه ممکن ضرب الاضع وي ، دوی یوازې د `&` سره پور کیدی شي ، نه د `&mut`.
//! د حجرو پرته دا به ناممکن وي چې په ټولو کې د دې سمارټ پوینټرونو دننه معلومات بدل کړئ.
//!
//! دا خورا معمول دی نو بیا د `RefCell<T>` د شریک شوي نښې ډولونو کې دننه کړئ ترڅو د بدلون بدلون راوړو:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // د متحرک پور محدود کولو لپاره یو نوی بلاک جوړ کړئ
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // په یاد ولرئ که چیرې موږ د کیشې پخوانۍ پور له لاسه ورنکړو نو بیا راتلونکی پور به د متحرک تار panic لامل شي.
//!     //
//!     // دا د `RefCell` کارولو لوی خطر دی.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! په یاد ولرئ چې دا مثال د `Rc<T>` کاروي نه `Arc<T>`.`ریف سیل<T>single s د یو واحد تار شوي سناریوګانو لپاره دي.د [`RwLock<T>`] یا [`Mutex<T>`] کارولو ته پام وکړئ که چیرې تاسو په څو اړخیزه حالت کې ګډ بدلون ته اړتیا لرئ.
//!
//! ## د منطقي-غیر منطقي میتودونو پلي کولو توضیحات
//!
//! ځینې وختونه دا مطلوب وي چې په API کې افشا نه کړئ چې د اتباع پیښې رامینځته کیږي "under the hood".
//! دا ممکن وي ځکه چې په منطقي توګه دا عملیات غیر منطقي دي ، مګر د مثال په توګه ، ساتل پلي کیدو ته د بدلون لپاره اړ ایستل کیږي؛یا ځکه چې تاسو باید د trait میتود پلي کولو لپاره تغیرات ګومارئ چې په اصل کې د `&self` اخیستلو لپاره ټاکل شوی و.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ګران شمیرنه دلته پرمخ ځي
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## د `Clone` پلي کولو پلي کول
//!
//! دا په ساده ډول د تیر ځانګړي قضیه ده: د عملیاتو لپاره د بدلون تحول کول چې داسې نه بریښي چې ښکاري.
//! د [`clone`](Clone::clone) میتود تمه کیږي چې د سرچینې ارزښت بدل نشي ، او اعلان شوی چې `&self` واخلي ، نه `&mut self`.
//! نو ځکه ، هر بدلون چې د `clone` میتود کې پیښیږي باید د حجرو ډولونه وکاروي.
//! د مثال په توګه ، [`Rc<T>`] د `Cell<T>` دننه د دې حوالې شمیرې ساتي.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// د بدلون وړ یادداشت ځای.
///
/// # Examples
///
/// پدې مثال کې ، تاسو لیدلی شئ چې `Cell<T>` د غیر منقول جوړښت دننه بدلون ته وده ورکوي.
/// په نورو ټکو ، دا د "interior mutability" وړ کوي.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // تیروتنه: `my_struct` نه بدلیدونکی دی
/// // my_struct.regular_field =نوی_ ارزونه؛
///
/// // کارونه: که څه هم `my_struct` ناقابل معاف دی ، `special_field` د `Cell` دی ،
/// // کوم چې تل بدلیدلی شي
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// د نورو لپاره [module-level documentation](self) وګورئ.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// د X لپاره د `Default` ارزښت سره ، `Cell<T>` رامینځته کوي.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// ورکړل شوی ارزښت لرونکی نوی `Cell` جوړوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// موجود ارزښت ټاکي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// د دوه حجرو ارزښتونه بدلوي.
    /// د `std::mem::swap` سره توپیر دا دی چې دا فعالیت د `&mut` حوالې ته اړتیا نلري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // خوندي: دا خطرناک کیدی شي که چیرې د جلا موضوعاتو څخه غوښتنه وشي ، مګر `Cell`
        // `!Sync` دی نو دا به پیښ نشي.
        // دا به هیڅ نښې هم باطله نه کړي ځکه چې `Cell` ډاډ ترلاسه کوي چې هیڅ بل هیڅکله به دې `حجرو ته په نښه نکړي.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// موجود ارزښت د `val` سره ځای په ځای کوي ، او زاړه موجود ارزښت بیرته ورکوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // خوندي: دا د ډیټا ریسونو لامل کیدی شي که چیرې د جلا موضوع څخه غوښتنه شوې وي ،
        // مګر `Cell` `!Sync` دی نو دا به پیښ نشي.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// د ارزښت ضایع کول.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// د موجود ارزښت یوه کاپي راولي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // خوندي: دا د ډیټا ریسونو لامل کیدی شي که چیرې د جلا موضوع څخه غوښتنه شوې وي ،
        // مګر `Cell` `!Sync` دی نو دا به پیښ نشي.
        unsafe { *self.value.get() }
    }

    /// د فنکشن په کارولو سره موجود ارزښت تازه کوي او نوي ارزښت بیرته ورکوي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// دې حجره کې اصلي معلوماتو ته خامو اشاره راګرځوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// لاندې معلوماتو ته بدلون مومي حواله.
    ///
    /// دا زنګ `Cell` په متقابل ډول پور اخلي (د تالیف په وخت کې) کوم چې تضمین لري چې موږ یوازینی حواله لرو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// له `&mut T` څخه `&Cell<T>` راستنوي
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // خوندي: `&mut` ځانګړې لاسرسي تضمینوي.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// د حجرو ارزښت اخلي ، په خپل ځای کې `Default::default()` پریږدي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// له `&Cell<[T]>` څخه `&[Cell<T>]` راستنوي
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // خوندي: `Cell<T>` د `T` په ورته حافظه ترتیب لري.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// د تحول وړ یادداشت ځای د متحرک چیک شوي پور قواعد سره
///
/// د نورو لپاره [module-level documentation](self) وګورئ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// یوه تېروتنه د [`RefCell::try_borrow`] لخوا راستون شوه.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// یوه تېروتنه د [`RefCell::try_borrow_mut`] لخوا راستون شوه.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// مثبت ارزښتونه د `Ref` فعال شمیر څرګندوي.منفي ارزښتونه د `RefMut` فعال شمیره وړاندې کوي.
// ګ`شمیر`ریف میټز یوازې هغه وخت فعال کیدی شي که چیرې دوی د `RefCell` جلا ، نانو لیپ کولو اجزاو ته مراجعه وکړي (د بیلګې په توګه ، د ټوټې مختلف سلسلې).
//
// `Ref` او `RefMut` دواړه په ټکو کې دوه ټکي دي ، او له دې امله احتمال به هیڅکله کافی نه وي `ریفیمز یا` ریف میټس په وجود کې د `usize` اندازې نیمایي جریان لپاره.
// په دې توګه ، یو `BorrowFlag` شاید شاید هیڅکله له سره جریان یا جریان ونه کړي.
// په هرصورت ، دا تضمین ندی ، ځکه چې د رنځپوهنې برنامه کولی شي په مکرر ډول رامینځته کړي او بیا یې د mem::forget `Ref`s یا`RefMut`s.
// په دې توګه ، ټول کوډ باید په څرګند ډول د ډیر جریان او د اوبو جریان وګوري ترڅو د بې باورۍ مخه ونیسي ، یا لږترلږه په هغه پیښه کې سم چلند وکړئ چې ډیر جریان یا زیربنا واقع کیږي (د بیلګې په توګه ، BorrowRef::new وګورئ).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// نوی `RefCell` جوړوي چې `value` لري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// د `RefCell` مصرف کوي ، نغښتل شوي ارزښت بیرته راستنوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // له دې چې دا فن د `self` (`RefCell`) د ارزښت له مخې اخلي ، تالیف کونکی په احتمالي توګه تایید کوي چې دا اوس پور نه دی اخیستل شوی.
        //
        self.value.into_inner()
    }

    /// نغاړل شوی ارزښت له نوي سره ځای په ځای کوي ، زاړه ارزښت بیرته راګرځوي ، پرته له دې چې یو یې هم تشخیص کړي.
    ///
    ///
    /// دا فنکشن د [`std::mem::replace`](../mem/fn.replace.html) سره مطابقت لري.
    ///
    /// # Panics
    ///
    /// Panics که چیرې دا مهال پور اخیستل شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// د `f` څخه محاسبه شوي نوي سره د نغښتل شوي ارزښت ځای نیسي ، زاړه ارزښت بیرته راګرځوي ، پرته له دې چې یو یې هم تشخیص کړي.
    ///
    ///
    /// # Panics
    ///
    /// Panics که چیرې دا مهال پور اخیستل شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// د `self` نغاړل شوي ارزښت د `other` تړل شوي ارزښت سره تغیر کوي ، پرته له دې چې یو یې هم ډیناټیز کړئ.
    ///
    ///
    /// دا فنکشن د [`std::mem::swap`](../mem/fn.swap.html) سره مطابقت لري.
    ///
    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// په فوري توګه نغښتل شوی ارزښت پور اخلي.
    ///
    /// پور تر هغه وخته پورې دوام کوي چې بیرته راستنیدونکي `Ref` له ساحې څخه وځي.
    /// ګ imm بې عیاره پورونه په عین وخت کې اخیستل کیدی شي.
    ///
    /// # Panics
    ///
    /// Panics که اوس مهال ارزښت په متناسب پور اخیستل شوی وي.
    /// د بې خطره ویرینټ لپاره ، [`try_borrow`](#method.try_borrow) وکاروئ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// د panic مثال:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// په فوري توګه نغښتل شوي ارزښت پور اخلي ، یوه تېروتنه راستنوي که چیرې اوس مهال ارزښت په متناسب پور اخیستل شوی وي.
    ///
    ///
    /// پور تر هغه وخته پورې دوام کوي چې بیرته راستنیدونکي `Ref` له ساحې څخه وځي.
    /// ګ imm بې عیاره پورونه په عین وخت کې اخیستل کیدی شي.
    ///
    /// دا د [`borrow`](#method.borrow) غیر ویریدونکی تغیر دی.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // امنیت: `BorrowRef` ډاډ ترلاسه کوي چې یوازې بې تکیه لاسرسی شتون لري
            // ارزښت ته.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// په مناسب ډول نغښتل شوی ارزښت پور اخلي.
    ///
    /// پور تر هغه وخته پورې دوام لري چې بیرته راستانه شوي `RefMut` یا ټول `RefMut`s له هغې څخه اخیستل شوي ساحې څخه وځي.
    ///
    /// ارزښت پور نشي اخیستلی پداسې حال کې چې دا پور فعال دی.
    ///
    /// # Panics
    ///
    /// Panics که چیرې دا مهال پور اخیستل شوی وي.
    /// د بې خطره ویرینټ لپاره ، [`try_borrow_mut`](#method.try_borrow_mut) وکاروئ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// د panic مثال:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// په متناسب ډول نغښتل شوي ارزښت پور اخلي ، یوه تېروتنه راستنوي که ارزښت اوس مهال پور شوی وي.
    ///
    ///
    /// پور تر هغه وخته پورې دوام لري چې بیرته راستانه شوي `RefMut` یا ټول `RefMut`s له هغې څخه اخیستل شوي ساحې څخه وځي.
    /// ارزښت پور نشي اخیستلی پداسې حال کې چې دا پور فعال دی.
    ///
    /// دا د [`borrow_mut`](#method.borrow_mut) غیر ویریدونکی تغیر دی.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // خوندي: `BorrowRef` د لاسرسي تضمین تضمین کوي.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// دې حجره کې اصلي معلوماتو ته خامو اشاره راګرځوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// لاندې معلوماتو ته بدلون مومي حواله.
    ///
    /// دا زنګ `RefCell` په متقابل ډول پور اخلي (د مرتب وخت کې) نو د متحرک چیکونو ته اړتیا نشته.
    ///
    /// په هرصورت محتاط اوسئ: دا طریقه تمه کوي `self` د بدلون وړ وي ، کوم چې عموما داسې نه وي کله چې د `RefCell` کارولو کې وي.
    ///
    /// پرځای یې د [`borrow_mut`] میتود ته یوه کتنه وکړئ که `self` د بدلون وړ نه وي.
    ///
    /// همچنان ، مهرباني وکړئ خبر اوسئ چې دا طریقه یوازې د ځانګړي شرایطو لپاره ده او معمولا هغه څه نه وي چې تاسو یې غواړئ.
    /// د شک په صورت کې ، پرځای یې [`borrow_mut`] وکاروئ.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// د `RefCell` پور پور ایالت کې د لیک شوي محافظینو تاثیر رد کړئ.
    ///
    /// دا زنګ [`get_mut`] ته ورته دی مګر ډیر متخصص.
    /// دا `RefCell` په متناسب ډول پور اخلي ترڅو ډاډ ترلاسه کړي چې هیڅ پور شتون نلري او بیا د دولت تعقیب شوي پورونه بیا تنظیموي.
    /// دا اړونده ده که ځینې `Ref` یا `RefMut` پورونه لیک شوي وي.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// په فوري توګه نغښتل شوي ارزښت پور اخلي ، یوه تېروتنه راستنوي که چیرې اوس مهال ارزښت په متناسب پور اخیستل شوی وي.
    ///
    /// # Safety
    ///
    /// د `RefCell::borrow` په خلاف ، دا میتود غیر محفوظ دی ځکه چې دا `Ref` نه راستنوي ، پدې توګه د پور بیرغ پریښودل کیږي.
    /// په متناسب ډول د `RefCell` پور اخیستل پداسې حال کې چې د دې میتود لخوا بیرته راستانه شوي حواله ژوندي ده غیر تعریف شوي چلند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // خوندي: موږ ګورو چې هیڅوک اوس په فعاله توګه نه لیکي ، مګر دا دی
            // د زنګ وهونکي مسؤلیت دی چې ډاډ ترلاسه کړي چې هیڅکله لیکل شوي نه لیکل کیږي ترڅو بیرته راستانه شوي حواله نور کارول کیږي.
            // همچنان ، `self.value.get()` د `self` ملکیت ارزښت ته اشاره کوي او پدې توګه د `self` د ژوند لپاره د اعتبار وړ تضمین لري.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// تاو شوی ارزښت اخلي ، په خپل ځای کې د `Default::default()` پریښودل.
    ///
    /// # Panics
    ///
    /// Panics که چیرې دا مهال پور اخیستل شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics که اوس مهال ارزښت په متناسب پور اخیستل شوی وي.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// د X لپاره د `Default` ارزښت سره ، `RefCell<T>` رامینځته کوي.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics که چیرې په `RefCell` کې اوس مهال پور اخیستل شوی وي.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // د پور ډیرول کولی شي پدې حالتونو کې د نه لوستلو ارزښت پایله (<=0):
            // 1. دا <0 و ، د بیلګې په توګه دلته پور لیکل شتون لري ، نو موږ نشو کولی د Rust د حوالې ایلاییزینګ قواعدو له امله د لوستلو پور اجازه ورنه کړو.
            // 2.
            // دا isize::MAX و (د لوستلو لوړه اندازه) او دا په isize::MIN کې راوتلی (د لیکلو پور اعظمي اندازه) نو موږ نشو کولی د اضافي لوستلو پور اجازه ورکړو ځکه چې ایاز نشي کولی د ډیری لوستلو پور استازیتوب وکړي (دا یوازې کیدی شي که تاسو د کوچني ثابت amount ریفیس څخه ډیر mem::forget کوئ ، کوم چې ښه عمل ندی)
            //
            //
            //
            //
            None
        } else {
            // د پور ډیرول پدې حالتونو کې د لوستلو ارزښت (> 0) پایله کیدی شي:
            // 1. دا=0 و ، د مثال په توګه دا پور نه دی اخیستل شوی ، او موږ د لوستلو لومړی پور اخلو
            // 2. دا> 0 او <isize::MAX و ، یعنی
            // دلته لوستل شوي پورونه و ، او اسیز دومره لوی دی چې د یو بل لوستلو پور نمایندګي وکړي
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // څنګه چې دا ریف شتون لري ، موږ پوهیږو چې د پور بیرغ د لوستلو پور دی.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // د لیکنې پور ته د ورننوتلو څخه د پور کاونټر مخه ونیسئ.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// په `RefCell` بکس کې د ارزښت لپاره پور شوي حوالې ریپ کوي.
/// د `RefCell<T>` څخه د غیر منقول پور شوي ارزښت لپاره د ریپر ډول.
///
/// د نورو لپاره [module-level documentation](self) وګورئ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// د `Ref` کاپي کول.
    ///
    /// د `RefCell` لا دمخه په مستعار ډول پور اخیستل شوی ، نو دا ناکام نشي.
    ///
    /// دا یو وابسته دنده ده چې د `Ref::clone(...)` په توګه وکارول شي.
    /// د `Clone` پلي کول یا یو میتود به د X002 ایکس پراخه کارونې سره مداخله وکړي ترڅو د `RefCell` مینځپانګې کلون کړي.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// د پور شوي ډاټا برخې لپاره نوي `Ref` جوړوي.
    ///
    /// د `RefCell` لا دمخه په مستعار ډول پور اخیستل شوی ، نو دا ناکام نشي.
    ///
    /// دا یو وابسته دنده ده چې د `Ref::map(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// د پور شوي ډاټا اختیاري برخې لپاره نوی `Ref` جوړوي.
    /// اصلي ساتونکی د `Err(..)` په توګه بیرته راستنیدل کیږي که چیرې بندیز `None` بیرته راشي.
    ///
    /// د `RefCell` لا دمخه په مستعار ډول پور اخیستل شوی ، نو دا ناکام نشي.
    ///
    /// دا یو وابسته دنده ده چې د `Ref::filter_map(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// د پور شوي معلوماتو مختلف برخو لپاره `Ref` په څو ډالر `ریفونو کې تقسیم کوي.
    ///
    /// د `RefCell` لا دمخه په مستعار ډول پور اخیستل شوی ، نو دا ناکام نشي.
    ///
    /// دا یو وابسته دنده ده چې د `Ref::map_split(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// لاندې معلوماتو ته مآخذ بدل کړئ.
    ///
    /// اصلي `RefCell` هیڅکله په متناسب ډول له بل څخه پور نشي اخیستل کیدی او تل به مخکې له مخکې نه په مستعار ډول پور اخیستل کیږي.
    ///
    /// دا د دوامداره شمیرو په پرتله ډیر لیک کول ښه نظر ندی.
    /// `RefCell` بیا په مستقل ډول پور اخیستل کیدی شي که چیرې یوازې یو څو کوچنۍ لیک شتون ولري.
    ///
    /// دا یو وابسته دنده ده چې د `Ref::leak(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // د دې ریف په هیرولو سره موږ ډاډ ترلاسه کوو چې په ریف سکیل کې د پور کاونټر نشي کولی بیرته د ژوند په اوږدو کې د `'b` دننه UNUSED ته لاړ شي.
        // د حوالې تعقیب ریاست بیا تنظیم کول به د پور شوي ریف سییل ته ځانګړي مآخذ ته اړتیا ولري.
        // نور د بدلولو وړ حوالې د اصلي حجرې څخه نشي رامینځته کیدلی.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// د اخیستل شوي ډیټا برخې لپاره نوي `RefMut` جوړوي ، د بیلګې په توګه ، د اینوم ډول.
    ///
    /// د `RefCell` لا دمخه په پور اخیستل شوی ، نو دا ناکام نشي.
    ///
    /// دا یو وابسته دنده ده چې د `RefMut::map(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): د پور چک حل کړئ
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// د پور شوي ډاټا اختیاري برخې لپاره نوی `RefMut` جوړوي.
    /// اصلي ساتونکی د `Err(..)` په توګه بیرته راستنیدل کیږي که چیرې بندیز `None` بیرته راشي.
    ///
    /// د `RefCell` لا دمخه په پور اخیستل شوی ، نو دا ناکام نشي.
    ///
    /// دا یو وابسته دنده ده چې د `RefMut::filter_map(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): د پور چک حل کړئ
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // د خوندیتوب: فعالیت د مودې لپاره ځانګړي مرجع لري
        // د `orig` له لارې د دې زنګ ، او نښې یوازې د فن کال دننه de-حواله کیږي هیڅکله اجازه نه ورکوي ځانګړي ریفرنس ته فرار شي.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // خوندي: د پورتني په څیر.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// د پور اخیستل شوي معلوماتو مختلف برخو لپاره `RefMut` په څو ګ multipleو `RefMut`s توزیع کوي.
    ///
    /// اساس لرونکی `RefCell` به په متقابل ډول پور اخیستل کیږي تر هغه چې دواړه بیرته راستانه شوي `ریف میتز له حوزې بهر نشي.
    ///
    /// د `RefCell` لا دمخه په پور اخیستل شوی ، نو دا ناکام نشي.
    ///
    /// دا یو وابسته دنده ده چې د `RefMut::map_split(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// اړوندو ارقامو ته بدلیدونکي حوالې ته واړوئ.
    ///
    /// لاندې `RefCell` د بیا څخه پور نشي اخیستل کیدی او تل به دمخه په پور اخیستل شوي ب .ه ښکاري ، چې بیرته راستنیدونکي به یوازې داخلي ته راجع کیږي.
    ///
    ///
    /// دا یو وابسته دنده ده چې د `RefMut::leak(...)` په توګه وکارول شي.
    /// یو میتود به د ورته نوم میتودونو سره مداخله وکړي د `RefCell` مینځپانګو کې چې د `Deref` له لارې کارول کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // د دې BrainRefMut په هیرولو سره موږ ډاډ ترلاسه کوو چې په ریفसेल کې د پور اخیستونکي نشي کولی بیرته د ژوند په اوږدو کې د `'b` دننه UNUSED ته لاړ شي.
        // د حوالې تعقیب ریاست بیا تنظیم کول به د پور شوي ریف سییل ته ځانګړي مآخذ ته اړتیا ولري.
        // نور اصلي مآخذ په دې ژوندانه کې نشي رامینځته کیدلی ، اوسنی پور د پاتې ژوند لپاره یوازینۍ مآخذ جوړوي.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: د BorrowRefMut::clone په خلاف ، نوی د ابتدایی رامینځته کولو لپاره ویل کیږي
        // تغیر منونکی حواله ، او نو اوس مهال باید موجود مآخذونه شتون ونلري.
        // په دې توګه ، پداسې حال کې چې کلون د بدلون وړ محاسبې ته وده ورکوي ، دلته موږ په ښکاره ډول یواځې د UNUSED څخه UNUSED ته د تلو اجازه ورکوو.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // د `BorrowRefMut` کلونونه.
    //
    // دا یوازې معتبر دی که هر `BorrowRefMut` د اصلي مقصود جلا ، نه اوورلیپینګ لړۍ ته د بدلون اړونده حوالې تعقیبولو لپاره وکارول شي.
    //
    // دا د کلون امپلو کې ندی نو ځکه کوډ دغه په مستقیم ډول نه بولي.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // د پور کاونټر د جریان څخه مخنیوی وکړئ.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// له `RefCell<T>` څخه د متقابل پور اخیستل شوي ارزښت لپاره د ریپر ډول.
///
/// د نورو لپاره [module-level documentation](self) وګورئ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// په Rust کې د داخلي بدلون لپاره اصلي لومړنی.
///
/// که تاسو د `&T` حواله لرئ ، نو په نورمال ډول په Rust کې تالیف کونکي د هغه پوهې پراساس اصلاح کوي چې `&T` غیر منقول ارقام ته اشاره کوي.د دې ډاټا بدله کول ، د مثال په توګه د یو ایل له لارې یا د `&T` په `&mut T` کې د لیږدولو سره ، غیر تعریف شوي چلند ګ .ل کیږي.
/// `UnsafeCell<T>` د `&T` لپاره د بې ثباتۍ تضمین غوره کول: شریک شوی حواله `&UnsafeCell<T>` ممکن هغه ډیټا ته په ګوته کړي چې بدل شوي وي.دې ته "interior mutability" ویل کیږي.
///
/// نور ټول ډولونه چې داخلي بدلون ته اجازه ورکوي ، لکه `Cell<T>` او `RefCell<T>` ، په داخلي توګه د دوی د معلوماتو سمولو لپاره `UnsafeCell` کاروي.
///
/// په یاد ولرئ چې د شریک حوالې لپاره یوازې د بې ثباتۍ تضمین د `UnsafeCell` لخوا اغیزمن شوی.د تغیر وړ مآخذونو لپاره د انفرادیت تضمین متاثر ندی.د ایلیسینګ `&mut` ترلاسه کولو لپاره هیڅ قانوني لاره شتون نلري ، حتی د `UnsafeCell<T>` سره هم نه.
///
/// د `UnsafeCell` API پخپله تخنیکي پلوه خورا ساده دی: [`.get()`] تاسو ته د دې مینځپانګو ته د خامو شیانو `*mut T` درکوي.دا د خلاصې ډیزاینر په توګه _you_ پورې اړه لري ترڅو دا خام نښه په سمه توګه وکاروي.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// دقیق Rust د ایلیسینګ قواعد یو څه په جریان کې دي ، مګر اصلي ټکي متناقض ندي:
///
/// - که تاسو د ژوندانه `'a` (یا د `&T` یا `&mut T` حواله) سره خوندي حواله رامینځته کړئ چې د خوندي کوډ لخوا لاسرسی وي (د مثال په توګه ، ځکه چې تاسو یې بیرته راوړی) ، نو تاسو باید ډیټا ته په هر ډول لاسرسی ونلرئ چې د پاتې کیدو لپاره ورته مراجع سره مخالفت کوي د `'a`.
/// د مثال په توګه ، پدې معنی ده چې که تاسو له `*mut T` څخه د `UnsafeCell<T>` واخلئ او دا یې `&T` ته واچوئ ، نو په `&T` کې ډاټا باید بې باوره پاتې شي (البته چې د `T` په مینځ کې د `UnsafeCell` کوم معلومات شتون ولري ، البته) تر هغه چې د دې ریفرنس ژوندون پای ته ورسیږي.
/// په ورته ډول ، که تاسو د `&mut T` حواله رامینځته کړئ چې خوندي کوډ ته خپره شوې وي ، نو تاسو باید د `UnsafeCell` دننه ډاټا ته لاسرسی ونلرئ تر څو چې دا ریفرنس پای ته ورسیږي.
///
/// - هر وخت ، تاسو باید د ډیټا ریس څخه مخنیوی وکړئ.که چیرې ډیری موضوعات ورته `UnsafeCell` ته لاسرسی ولري ، نو بیا باید هر لیکوال د مناسبې پیښې سره مخ شي-مخکې له دې چې د نورو ټولو لاسرسیاتو سره تړاو ولري (یا اټومکس وکاروئ).
///
/// د مناسب ډیزاین سره مرسته کولو لپاره ، لاندې سناریوګانې په واضح ډول د واحد توری کوډ لپاره قانوني اعلان شوي:
///
/// 1. د `&T` حواله خوندي کوډ ته خوشې کیدی شي او هلته دا د نورو `&T` حوالې سره همکاري کولی شي ، مګر د `&mut T` سره نه
///
/// 2. د `&mut T` حواله ممکن خوندي کوډ ته خوشې شي په بیله بیا چې نور `&mut T` او نه هم د `&T` هم ورسره شتون ولري.یو `&mut T` باید تل ځانګړی وي.
///
/// په یاد ولرئ چې پداسې حال کې چې د `&UnsafeCell<T>` مینځپانګه بدله کړئ (پداسې حال کې چې نور `&UnsafeCell<T>` حوالې عرف سیل دی) ښه دی (په دې شرط چې تاسو پورتني یرغلګر بل ډول پلي کړئ) ، دا لاهم ټاکل شوی چلند دی چې د `&mut UnsafeCell<T>` بل ډول شتون ولري.
/// دا ، `UnsafeCell` یو ریپر دی چې د _shared_ accesses (_i.e._ سره د ځانګړي متقابل عمل لپاره ډیزاین شوی ، د `&UnsafeCell<_>` حوالې له لارې)؛هیڅ جادو شتون نلري کله چې د _exclusive_ accesses (_e.g._ سره معامله وکړئ ، د `&mut UnsafeCell<_>` له لارې): نه حجره او نه هم تاوول شوی ارزښت ممکن د دې `&mut` پور دورې لپاره محبس شي.
///
/// دا د [`.get_mut()`] لاسرسی لخوا ښودل شوی ، کوم چې د _safe_ getter دی چې `&mut T` ترلاسه کوي.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// دلته یو مثال دی چې د `UnsafeCell<_>` مینځپانګې په ښه توګه بدلولو څرنګوالي ښودلو سره سره دلته د سیل ډیجیټل کولو ډیری حوالې شتون لري:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ورته `x` ته ډیری/متقابل/شریک حوالې ترلاسه کړئ.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // خوندي: پدې ځای کې د `x` مینځپانګو ته هیڅ بل مآخذ نسته ،
///     // نو زموږ اغیزمن ډول ځانګړی دی.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- پور-+
///     *p1_exclusive += 27; // |
/// } // <---------- له دې ټکي هاخوا نشي تللی -------------------+
///
/// unsafe {
///     // خوندي: پدې برخه کې هیڅوک تمه نلري چې د x` مینځپانګو ته ځانګړي لاسرسي ولري ،
///     // نو موږ کولی شو په ګډه ډول څو ګډې لاس رسۍ ولرو.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// لاندې مثال د دې حقیقت ښودنه کوي چې د `UnsafeCell<T>` ته ځانګړي لاسرسی د دې `T` ته ځانګړي لاسرسی نافذ کوي:
///
/// ```rust
/// #![forbid(unsafe_code)] // د ځانګړي لاسرسي سره ،
///                         // `UnsafeCell` د رو noو نه اوپي ریپر دی ، نو دلته د `unsafe` لپاره اړتیا نشته.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // د `x` ته د تالیف شوي وخت چیک شوي ځانګړي ریفرنس ترلاسه کړئ.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // د ځانګړي حوالې سره ، موږ کولی شو مینځپانګې وړیا بدل کړو.
/// *p_unique.get_mut() = 0;
/// // یا ، مساوي:
/// x = UnsafeCell::new(0);
///
/// // کله چې موږ د ارزښت مالکیت لرو ، موږ کولی شو مینځپانګې په وړیا توګه وباسو.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// د `UnsafeCell` نوی مثال رامینځته کوي کوم چې به ټاکل شوی ارزښت سمبال کړي.
    ///
    ///
    /// د میتودونو له لارې داخلي ارزښت ته ټول لاسرسي د `unsafe` دی.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// د ارزښت ضایع کول.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// نغښتل شوي ارزښت ته تغیر ورکوونکی پوائنټر ترلاسه کوي.
    ///
    /// دا کولی شي د هر ډول نښې ته راوبلل شي.
    /// ډاډ ترلاسه کړئ چې لاسرسی ځانګړی دی (هیڅ فعال مآخذ ، نه بدلیدونکی یا نه) کله چې `&mut T` ته کاسټ کول ، او ډاډ ترلاسه کړئ کله چې `&T` ته کاسټ کولو کې هیڅ بدلون یا تغیر وړ الیاس شتون نلري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // موږ کولی شو یوازې د `UnsafeCell<T>` څخه `T` ته د #[repr(transparent)] له امله اشاره کاسټ کړو.
        // دا د لیبسټډ ځانګړي دریځ کاروي ، د کارونکي کوډ لپاره هیڅ تضمین شتون نلري چې دا به د کمپیلر future نسخو کې کار وکړي!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// لاندې معلوماتو ته بدلون مومي حواله.
    ///
    /// دا زنګ `UnsafeCell` په متقابل ډول پور اخلي (په مرتب وخت کې) کوم چې تضمین لري چې موږ یوازینی حواله لرو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// نغښتل شوي ارزښت ته تغیر ورکوونکی پوائنټر ترلاسه کوي.
    /// د [`get`] لپاره توپیر دا دی چې دا فن یو خام نخښه مني ، کوم چې د لنډمهاله حوالې جوړولو رامینځته کولو لپاره ګټور دی.
    ///
    /// پایله د هر ډول نښې ته کیښودل کیدی شي.
    /// ډاډ ترلاسه کړئ چې لاسرسی ځانګړی دی (هیڅ فعال مآخذ ، نه بدلیدونکی یا نه) کله چې `&mut T` ته کاسټ کول ، او ډاډ ترلاسه کړئ کله چې `&T` ته کاسټ کولو کې هیڅ بدلون یا بدلون الیسیسونه شتون نلري.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// د `UnsafeCell` ورو ورو ابتکار کول `raw_get` ته اړتیا لري ، ځکه چې د `get` زنګ وهل به بې بنسټه معلوماتو ته مآخذ رامینځته کولو ته اړتیا ولري:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // موږ کولی شو یوازې د `UnsafeCell<T>` څخه `T` ته د #[repr(transparent)] له امله اشاره کاسټ کړو.
        // دا د لیبسټډ ځانګړي دریځ کاروي ، د کارونکي کوډ لپاره هیڅ تضمین شتون نلري چې دا به د کمپیلر future نسخو کې کار وکړي!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// د X لپاره د `Default` ارزښت سره ، `UnsafeCell` رامینځته کوي.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}