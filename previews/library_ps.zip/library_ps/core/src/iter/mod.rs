//! کوچنی بهرنی تکرار.
//!
//! که تاسو ځان د یو ډول ډول ټولګه سره وموندئ ، او د ورته ټولولو عناصرو باندې عملیاتو ترسره کولو ته اړتیا لرئ ، نو تاسو به ژر تر ژره 'iterators' ته ورشئ.
//! ایټریټرونه په ایډیوماتیک Rust کوډ کې خورا ډیر کارول کیږي ، نو دا د دوی سره د پیژندلو ارزښت لري.
//!
//! د نورو توضیح کولو دمخه ، راځئ چې پدې اړه خبرې وکړو چې دا موډل څنګه تنظیم شوی:
//!
//! # Organization
//!
//! دا موډل په پراخه کچه د ډول پواسطه تنظیم شوی دی:
//!
//! * [Traits] اصلي برخه دي: دا traits تعریف کوي چې کوم ډول تکرارونکي شتون لري او تاسو د دوی سره څه کولی شئ.د دې traits میتودونه د مطالعې ځینې اضافي وخت دننه کولو ارزښت لري.
//! * [Functions] د ځینې لومړني تکرارونو رامینځته کولو لپاره ځینې ګټورې لارې چمتو کړئ.
//! * [Structs] ډیری وختونه د دې ماډل traits کې د مختلف میتودونو بیرته ستنیدو ډولونه دي.تاسو به معمولا غواړئ هغه میتود وګورئ چې د `struct` رامینځته کوي ، نه پخپله د `struct` څخه.
//! د دې په اړه د نورو جزییاتو لپاره ، وګورئ [[تطبیق کونکي Iterator](#پلي کول-تکرار کونکی)).
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! همدا و!راځئ چې تکرار کونکو ته کش کړو.
//!
//! # Iterator
//!
//! د دې ماډل زړه او روح د [`Iterator`] trait دی.د [`Iterator`] اصلي برخه داسې ښکاري:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! یو تکرار کونکی میتود لري ، [`next`] ، کوم چې کله ویل کیږي ، [`اختیار`] returns بیرته راولي<Item>`.
//! [`next`] [`Some(Item)`] به بیرته راشي تر هغه چې عناصر شتون ولري ، او یوځل چې دا ټول له مینځه تللي وي ، نو `None` به بیرته راستون شي ترڅو دا په ګوته شي چې تکرار بشپړ شوی.
//! انفرادي تکرار کونکي ممکن د تکرار بیا پیل کول غوره کړي ، او په دې توګه د [`next`] تلیفون کول ممکن ممکن په یو وخت کې د [`Some(Item)`] بیرته راستنیدل پیل کړي (د مثال په توګه ، [`TryIter`] وګورئ).
//!
//!
//! [te Iterator`] بشپړ تعریف کې یو شمیر نور میتودونه هم شامل دي ، مګر دا د ډیفالټ میتودونه دي چې د [`next`] په سر کې جوړ شوي ، او له همدې امله تاسو دا وړیا ترلاسه کوئ.
//!
//! تفتیش کونکي هم د تحلیل وړ دي ، او دا د دوی پیچلي کولو لپاره عام دي چې د پروسس پیچلي ب formsې ترسره کړي.د نورو جزیاتو لپاره لاندې د [Adapters](#adapters) برخې وګورئ.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # د تکرار درې ډولونه
//!
//! دلته درې عام میتودونه شتون لري چې کولی شي له ټولګه څخه تکرار کونکي رامینځته کړي:
//!
//! * `iter()`, کوم چې د `&T` څخه زیات تکرار کیږي.
//! * `iter_mut()`, کوم چې د `&mut T` څخه زیات تکرار کیږي.
//! * `into_iter()`, کوم چې د `T` څخه زیات تکرار کیږي.
//!
//! په معیاري کتابتون کې مختلف شیان ممکن له دریو څخه یو یا ډیر پلي کړي ، چیرې چې مناسب وي.
//!
//! # تطبیق کونکی
//!
//! ستاسو د ځان تکرار کونکي رامینځته کول دوه مرحلې لري: د تکرار حالت ساتلو لپاره د `struct` رامینځته کول ، او بیا د دې `struct` لپاره [`Iterator`] پلي کول.
//! له همدې امله په دې ماډل کې ډیری ډیری جوړښتونه شتون لري: د هر تکرار او تکرار اډاپټر لپاره یو دی.
//!
//! راځئ چې د `Counter` په نوم تکرار کونکی رامینځته کړو چې له `1` څخه تر `5` پورې حساب کیږي:
//!
//! ```
//! // لومړی ، جوړښت:
//!
//! /// یو تکرارونکی چې له یو څخه تر پنځو پورې حسابيږي
//! struct Counter {
//!     count: usize,
//! }
//!
//! // موږ غواړو زموږ شمیره په یو پیل وکړو ، نو راځئ چې د مرستې لپاره د new() میتود اضافه کړو.
//! // دا په کلکه اړین ندي ، مګر مناسب دي.
//! // یادونه وکړئ چې موږ په صفر کې `count` پیل کوو ، موږ به وګورو چې ولې د `next()`'s تطبیق لاندې دی.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // بیا ، موږ زموږ د `Counter` لپاره `Iterator` پلي کوو:
//!
//! impl Iterator for Counter {
//!     // موږ به له usize سره حساب وکړو
//!     type Item = usize;
//!
//!     // next() یوازینۍ اړین میتود دی
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // زموږ د شمیر زیاتوالی.له همدې امله موږ په صفر پیل وکړ.
//!         self.count += 1;
//!
//!         // وګوره چې وګورو چې موږ شمېرنه پای ته رسیدلې که نه.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // او اوس موږ دا کارولی شو!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! په دې ډول د [`next`] زنګ وهل تکرار کیږي.Rust یو جوړښت لري چې کولی شي ستاسو تکرارونکي باندې [`next`] زنګ ووهي ، تر دې چې دا `None` ته ورسیږي.راځئ چې دې بلې ته ورشو.
//!
//! دا هم په یاد ولرئ چې `Iterator` د میتودونو ډیفالټ پلي کول چمتو کوي لکه `nth` او `fold` چې په کور دننه `next` غږوي.
//! په هرصورت ، دا هم امکان لري چې د `nth` او `fold` په څیر د میتودونو دودیز پلي کول ولیکئ که چیرې یو تکرار کونکی د `next` تلیفون کولو پرته دوی په ډیرې موثره توګه محاسبه کړي.
//!
//! # `for` لوپس او `IntoIterator`
//!
//! د Rust د `for` لوپ ترکیب واقعیا د تکرار کونکو لپاره شوګر دی.دلته د `for` لومړنی مثال دی:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! دا به لمبر له یو څخه تر پنځه پورې چاپ کړي ، هر یو یې پخپله خپله لیکه کې.مګر تاسو به دلته یو څه وګورئ: موږ هیڅکله په خپل vector کې هیڅکله تلیفون نه کوو ترڅو تکرار تولید کړي.څه ورکوي؟
//!
//! دلته په معیاري کتابتون کې trait شتون لري چې یو څه تکرارونکي ته بدل کړي: [`IntoIterator`].
//! دا trait یو میتود لري ، [`into_iter`] ، کوم چې د [`IntoIterator`] پلي کونکي شی په تکرار کونکي بدلوي.
//! راځئ چې بیا پدې `for` لوپ باندې یو نظر وګورو ، او کوم چې تالیف کونکی یې په دې کې بدلوي:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust دې قندونه دې ته اړباسي:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! لومړی ، موږ د `into_iter()` په ارزښت تلیفون کوو.بیا ، موږ په تکرار کونکي سره لوبه کوو چې بیرته راځي ، [`next`] ته ډیر ځله تلیفون کوي تر هغه چې موږ یو `None` ونه ګورو.
//! په دې وخت کې ، موږ له لوپ څخه `break` ، او موږ تکرار شو.
//!
//! دلته یو بل فرعي بټ شتون لري: معیاري کتابتون د [`IntoIterator`] په زړه پوري پلي کول لري:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! په بل عبارت ، ټول [te Iterator`] یوازې د ځان بیرته راستنولو سره ، [`IntoIterator`] پلي کوي.دا دوه شیان معنی لري:
//!
//! 1. که تاسو [`Iterator`] لیکئ ، نو تاسو یې د `for` لوپ سره وکاروئ.
//! 2. که تاسو ټولګه رامینځته کوئ ، نو د دې لپاره د [`IntoIterator`] پلي کول به ستاسو ټولګه ته اجازه ورکړي چې د `for` لوپ سره وکارول شي.
//!
//! # د حوالې سره سپړنه
//!
//! له هغه وخته چې [`into_iter()`] د ارزښت له مخې `self` اخلي ، نو د `for` لوپ په کارولو سره په ټولګه کې تکرار کول دا ټولګه مصرفوي.اکثرا ، تاسو ممکن د دې مصرف کولو پرته د ټولګې په اوږدو کې تکرار کړئ.
//! ډیری راټولونه میتودونه وړاندې کوي چې مراجعینو ته تکرار کونکي چمتو کوي ، په عنعنوي ډول په ترتیب سره د `iter()` او `iter_mut()` په نوم یادیږي:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` لاهم د دې فنلیک ملکیت دی.
//! ```
//!
//! که د راټولولو ب Xه `C` `iter()` چمتو کوي ، نو دا معمولا د `&C` لپاره هم د `IntoIterator` پلي کوي ، د پلي کیدو سره چې یوازې `iter()` بولي.
//! په ورته ډول ، د `C` ټولګه چې د `iter_mut()` چمتو کوي په عمومي ډول د `iter_mut()` ته د رابللو سره د `&mut C` لپاره `IntoIterator` پلي کوي.دا اسانه لنډ لنډیز چمتو کوي:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // د `values.iter_mut()` په څیر
//!     *x += 1;
//! }
//! for x in &values { // د `values.iter()` په څیر
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! پداسې حال کې چې ډیری راټولونه `iter()` وړاندیز کوي ، نه ټول وړاندیز `iter_mut()`.
//! د مثال په توګه ، د [`HashSet<T>`] یا [`HashMap<K, V>`] د کیلو ګانو بدلول کولی شي ټولګه په نامناسب حالت کې واچوي که چیرې کلیدي چنګونه بدلې شي ، نو دا ټولګه یوازې `iter()` وړاندیز کوي.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! هغه فعالیتونه چې [`Iterator`] اخلي او بل [`Iterator`] بیرته راوړي اکثرا د تکرار اډاپټرونه بلل کیږي ، ځکه چې دا د 'اډیپټر ب'reه دي
//! pattern'.
//!
//! عام تکرار کونکي اډیپټرې کې [`map`] ، [`take`] ، او [`filter`] شامل دي.
//! د نورو لپاره ، د دوی اسناد وګورئ.
//!
//! که چیرې د تیریدونکي اډیپټر panics ، تکرارونکی به په نامعلوم ډول (مګر حافظه خوندي) حالت کې وي.
//! دا ایالت هم د Rust نسخو کې ورته ورته پاتې کیدو تضمین نلري ، نو تاسو باید د تکرارونکي لخوا بیرته راستنیدونکي دقیقو ارزښتونو تکیه کولو څخه ډډه وکړئ.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! تفتیش کونکي (او تکرارونکي [adapters](#adapters)) * لوازم دي. د دې معنی دا ده چې یوازې د تکرار رامینځته کول په بشپړ ډول _do_ نه کوي. هیڅکله واقعیا واقع کیږي نه تر هغه چې تاسو [`next`] ته زنګ ووهئ.
//! دا ځینې وختونه د ګډوډۍ سرچینه وي کله چې یوازې د دې اړخیزو تاثیراتو لپاره تکرار رامینځته کول.
//! د مثال په توګه ، د [`map`] میتود د هر عنصر بندول بولي چې دا تکراروي:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! دا به هیڅ ارزښت ونه چاپ کړي ، ځکه چې موږ یوازې د تکرار کونکي رامینځته کړی ، نه د دې د کارولو پرځای.تالیف کونکی به موږ ته د دې ډول چلند په اړه خبرداری ورکړي:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! د دې ضمني تاثیراتو لپاره د [`map`] لیکلو ایډیوماتیک لاره د `for` لوپ کارولو یا د [`for_each`] میتود زنګ وهل دي:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! د تکرار ارزونې لپاره بله عامه لاره د نوي ټولګه تولید لپاره د [`collect`] میتود کارول دي.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! تفتیش کونکي باید محدود نه وي.د مثال په توګه ، د خلاص پای رینج یو لامحدود تکرارونکی دی:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! د [`take`] تکرار اډیپټر کارول عام دي چې لامحدود تکرار کونکي په بشپړ ډول بدل کړئ:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! دا به د `4` شمیره د `4` له لارې چاپ کړي ، هر یو یې پخپله خپله لیکه کې.
//!
//! په یاد ولرئ چې لامحدود تکرار کونکي میتودونه ، حتی د کومو لپاره چې پایله یې په ټاکل شوي وخت کې په ریاضی ډول ټاکل کیدی شي ، ممکن پای ته ونه رسيږي.
//! په ځانګړي توګه ، میتودونه لکه [`min`] ، کوم چې په عمومي حالت کې د تکرار کونکي هر عنصر تعقیب کولو ته اړتیا لري ، احتمال لري د هیڅ لامحدود تکرار کونکو لپاره په بریالیتوب سره بیرته راستنیدنه ونه کړي.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // او نه!یو نه ختمیدونکی لوپ!
//! // `ones.min()` د نامحدود لوپ لامل کیږي ، نو موږ به دې مرحلې ته ونه رسیږو!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;