use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// هغه څیزونه چې د *بریالي* او *وړاندویني* عملیاتو مفکوره لري.
///
/// *د بریالیتوب* عملیات د ارزښتونو په لور حرکت کوي چې لوی پرتله کوي.
/// *پیشرو* عملیات د ارزښتونو په لور حرکت کوي چې لږ پرتله کوي.
///
/// # Safety
///
/// دا trait `unsafe` دی ځکه چې د دې تطبیق باید د `unsafe trait TrustedLen` تطبیقاتو د خوندیتوب لپاره سم وي ، او د دې trait کارولو پایلې کولی شي د `unsafe` کوډ لخوا اعتماد شي ترڅو سم وي او لیست شوي مسؤلیتونه پوره کړي.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// د `start` څخه `end` ته د لاسرسي لپاره د *بریالي* مرحلو شمیره راستنوي.
    ///
    /// `None` راګرځوي که چیرې د مرحلو شمیر به `usize` پراخه شي (یا لامحدود دی ، یا که `end` به هیڅکله ونه رسیږي).
    ///
    ///
    /// # Invariants
    ///
    /// د هر `a` ، `b` ، او `n` لپاره:
    ///
    /// * `steps_between(&a, &b) == Some(n)` که او یوازې که `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` که او یوازې که `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` یوازې که `a <= b`
    ///   * غلط: `steps_between(&a, &b) == Some(0)` که او یوازې که `a == b`
    ///   * په یاد ولرئ چې `a <= b` _not_ د `steps_between(&a, &b) != None` تطبیق کوي؛
    ///     دا قضیه ده کله چې دا د `b` ته د لاسرسي لپاره له `usize::MAX` مرحلو څخه ډیر ته اړتیا ولري
    /// * `steps_between(&a, &b) == None` که `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// هغه ارزښت بیرته راولي چې د `self` `count` وختونو *جانشین* په اخیستلو سره ترلاسه شي.
    ///
    /// که دا به د `Self` لخوا ملاتړ شوي ارزښتونو لړۍ پراخه کړي ، نو `None` بیرته راشي.
    ///
    /// # Invariants
    ///
    /// د هر `a` ، `n` ، او `m` لپاره:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// د هر `a` ، `n` ، او `m` لپاره چیرې چې `n + m` ترې نه تیریږي:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// د هر ډول `a` او `n` لپاره:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// هغه ارزښت بیرته راولي چې د `self` `count` وختونو *جانشین* په اخیستلو سره ترلاسه شي.
    ///
    /// که چیرې دا به د `Self` لخوا ملاتړ شوي ارزښتونو لړۍ پراخه کړي ، نو دا فعالیت panic ، لپیچ ، یا مطلق کولو ته اجازه لري.
    ///
    /// وړاندیز شوی چلند panic ته دی کله چې د ډیب ادعاګانې فعالې وي ، او یا بل چالان یا مطمین کول.
    ///
    /// غیر خوندي کوډ باید د ډیر جریان وروسته د چلند په سموالي تکیه ونه کړي.
    ///
    /// # Invariants
    ///
    /// د هر `a` ، `n` ، او `m` لپاره ، چیرې چې ډیر جریان نه پیښیږي:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// د هر `a` او `n` لپاره ، چیرې چې ډیر جریان نه پیښیږي:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// هغه ارزښت بیرته راولي چې د `self` `count` وختونو *جانشین* په اخیستلو سره ترلاسه شي.
    ///
    /// # Safety
    ///
    /// دا د دې عملیاتو لپاره ټاکل شوی چلند ندی چې د `Self` لخوا ملاتړ شوي د ارزښتونو حد څخه ډوب شي.
    /// که تاسو تضمین نشئ کولی چې دا به جریان نشي ، د `forward` یا `forward_checked` پرځای یې وکاروئ.
    ///
    /// # Invariants
    ///
    /// د هر `a` لپاره:
    ///
    /// * که چیرې شتون ولري `b` لکه چې `b > a` وي ، نو د `Step::forward_unchecked(a, 1)` تلیفون کول خوندي دي
    /// * که چیرې شتون ولري `b` ، `n` لکه چې `steps_between(&a, &b) == Some(n)` وي ، نو دا خوندي ده چې د هر `m <= n` لپاره `Step::forward_unchecked(a, m)` تلیفون وکړئ.
    ///
    ///
    /// د هر `a` او `n` لپاره ، چیرې چې ډیر جریان نه پیښیږي:
    ///
    /// * `Step::forward_unchecked(a, n)` د `Step::forward(a, n)` سره مساوي دی
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// هغه ارزښت بیرته راګرځي چې د `self` `count` وختونو *وړاندوینې* په ترلاسه کولو سره ترلاسه شي.
    ///
    /// که دا به د `Self` لخوا ملاتړ شوي ارزښتونو لړۍ پراخه کړي ، نو `None` بیرته راشي.
    ///
    /// # Invariants
    ///
    /// د هر `a` ، `n` ، او `m` لپاره:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// د هر ډول `a` او `n` لپاره:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// هغه ارزښت بیرته راګرځي چې د `self` `count` وختونو *وړاندوینې* په ترلاسه کولو سره ترلاسه شي.
    ///
    /// که چیرې دا به د `Self` لخوا ملاتړ شوي ارزښتونو لړۍ پراخه کړي ، نو دا فعالیت panic ، لپیچ ، یا مطلق کولو ته اجازه لري.
    ///
    /// وړاندیز شوی چلند panic ته دی کله چې د ډیب ادعاګانې فعالې وي ، او یا بل چالان یا مطمین کول.
    ///
    /// غیر خوندي کوډ باید د ډیر جریان وروسته د چلند په سموالي تکیه ونه کړي.
    ///
    /// # Invariants
    ///
    /// د هر `a` ، `n` ، او `m` لپاره ، چیرې چې ډیر جریان نه پیښیږي:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// د هر `a` او `n` لپاره ، چیرې چې ډیر جریان نه پیښیږي:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// هغه ارزښت بیرته راګرځي چې د `self` `count` وختونو *وړاندوینې* په ترلاسه کولو سره ترلاسه شي.
    ///
    /// # Safety
    ///
    /// دا د دې عملیاتو لپاره ټاکل شوی چلند ندی چې د `Self` لخوا ملاتړ شوي د ارزښتونو حد څخه ډوب شي.
    /// که تاسو تضمین نشئ کولی چې دا به جریان نشي ، د `backward` یا `backward_checked` پرځای یې وکاروئ.
    ///
    /// # Invariants
    ///
    /// د هر `a` لپاره:
    ///
    /// * که چیرې شتون ولري `b` لکه چې `b < a` وي ، نو د `Step::backward_unchecked(a, 1)` تلیفون کول خوندي دي
    /// * که چیرې شتون ولري `b` ، `n` لکه چې `steps_between(&b, &a) == Some(n)` وي ، نو دا خوندي ده چې د هر `m <= n` لپاره `Step::backward_unchecked(a, m)` تلیفون وکړئ.
    ///
    ///
    /// د هر `a` او `n` لپاره ، چیرې چې ډیر جریان نه پیښیږي:
    ///
    /// * `Step::backward_unchecked(a, n)` د `Step::backward(a, n)` سره مساوي دی
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// دا لاهم میکرو تولید شوي دي ځکه چې د انټجیر سواد مختلف ډولونه حلوي.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // خوندي: زنګ وهونکی تضمین لري چې `start + n` ډیر نه جریان لري.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // خوندي: زنګ وهونکی تضمین لري چې `start - n` ډیر نه جریان لري.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // په ډیبګ جوړونو کې ، د ضایع کیدو په وخت کې panic ټرر کړئ.
            // دا باید په خوشې کولو جوړونو کې بشپړ بشپړ شي.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // د ریاضی کولو ریپ کولو لپاره ترسره کړئ لکه د مثال په توګه `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // په ډیبګ جوړونو کې ، د ضایع کیدو په وخت کې panic ټرر کړئ.
            // دا باید په خوشې کولو جوړونو کې بشپړ بشپړ شي.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // د ریاضی کولو ریپ کولو لپاره ترسره کړئ لکه د مثال په توګه `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // دا په $u_narrower <=usize پورې اړه لري
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // که چیرې n د حد څخه بهر وي ، نو `unsigned_start + n` هم خورا ډیر دی
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // که چیرې n د حد څخه بهر وي ، نو `unsigned_start - n` هم خورا ډیر دی
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // دا په $i_narrower <=usize پورې اړه لري
                        //
                        // د آی ایس آی کولو لپاره کاسټل پراخه کوي مګر نښه خوندي کوي.
                        // د isize ځای کې ریپینګ_ سوب وکاروئ او د کاروونې لپاره usize ته کاسټ کړئ چې ممکن د isize اندازې کې مناسب نه وي.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ریپینګ د `Step::forward(-120_i8, 200) == Some(80_i8)` په څیر قضیې اداره کوي ، پداسې حال کې چې 200 د i8 لپاره له حد څخه بهر دی.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // اضافه ډیر شوه
                            }
                        }
                        // که چیرې د مثال په توګه بهر نه وي
                        // u8, بیا دا د i8 لپاره د ټول حد څخه لوی دی نو `any_i8 + n` لازمي ډول د i8 اتکا کوي.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ریپینګ د `Step::forward(-120_i8, 200) == Some(80_i8)` په څیر قضیې اداره کوي ، پداسې حال کې چې 200 د i8 لپاره له حد څخه بهر دی.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // تخفیه ډیره شوه
                            }
                        }
                        // که چیرې د مثال په توګه بهر نه وي
                        // u8, بیا دا د i8 لپاره د ټول حد څخه لوی دی نو `any_i8 - n` لازمي ډول د i8 اتکا کوي.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // که توپیر د مثال په توګه خورا لوی وي
                            // i128 ، دا به د لږ بټونو سره د کاروونې لپاره خورا لوی وي.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // : res :Y::res res res a a valid valid valid valid... ic un...... is
            // (د 0x110000 لاندې او په 0xD800..0xE000 کې ندي)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // : res :Y::res res res a a valid valid valid valid... ic un...... is
        // (د 0x110000 لاندې او په 0xD800..0xE000 کې ندي)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // امنیت: زنګ وهونکی باید تضمین وکړي چې دا جریان نلري
        // د چارت لپاره د ارزښتونو لړ.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // امنیت: زنګ وهونکی باید تضمین وکړي چې دا جریان نلري
            // د چارت لپاره د ارزښتونو لړ.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // خوندي: د تیر تړون له امله ، دا تضمین دی
        // د زنګ وهونکي لخوا د اعتبار وړ چار.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // امنیت: زنګ وهونکی باید تضمین وکړي چې دا جریان نلري
        // د چارت لپاره د ارزښتونو لړ.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // امنیت: زنګ وهونکی باید تضمین وکړي چې دا جریان نلري
            // د چارت لپاره د ارزښتونو لړ.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // خوندي: د تیر تړون له امله ، دا تضمین دی
        // د زنګ وهونکي لخوا د اعتبار وړ چار.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // امنیت: یوازې شرطه چیک شوی
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // امنیت: یوازې شرطه چیک شوی
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// دا ماکروز د مختلف سلسلو ډولونو لپاره د `ExactSizeIterator` امپلیټ رامینځته کوي.
//
// * `ExactSizeIterator::len` د تل دقیق `usize` بیرته ورکولو لپاره اړین دی ، نو هیڅ حد د `usize::MAX` څخه اوږد نشي.
//
// * په `Range<_>` کې د بشپړ ډولونو لپاره دا د `usize` څخه خورا پراخه او پراخه ډولونو لپاره قضیه ده.
//   په `RangeInclusive<_>` کې د بشپړ ډولونو لپاره دا د ډولونو لپاره قضیه ده *د `usize` په پرتله دقیقا تنگ*
//   `(0..=u64::MAX).len()` به `u64::MAX + 1` وي.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // دا پورته دلایل له مخې غیر اصلي دي ، مګر د دوی لرې کول به یو ماتونکی بدلون وي ځکه چې دوی په Rust 1.0.0 کې مستحکم شوي.
    // نو لکه
    // `(0..66_000_u32).len()` د مثال په توګه به په 16 بټ پلیټ فارمونو کې پرته له خطا یا خبرتیاو څخه تالیف وکړي ، مګر غلطې پایلې ورکولو ته به دوام ورکړي.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // دا پورته دلایل له مخې غیر اصلي دي ، مګر د دوی لرې کول به یو ماتونکی بدلون وي ځکه چې دوی په Rust 1.26.0 کې مستحکم شوي.
    // نو لکه
    // `(0..=u16::MAX).len()` د مثال په توګه به په 16 بټ پلیټ فارمونو کې پرته له خطا یا خبرتیاو څخه تالیف وکړي ، مګر غلطې پایلې ورکولو ته به دوام ورکړي.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // امنیت: یوازې شرطه چیک شوی
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // امنیت: یوازې شرطه چیک شوی
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // امنیت: یوازې شرطه چیک شوی
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // امنیت: یوازې شرطه چیک شوی
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // امنیت: یوازې شرطه چیک شوی
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // امنیت: یوازې شرطه چیک شوی
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}