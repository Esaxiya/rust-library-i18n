use crate::iter::{FusedIterator, TrustedLen};

/// یو تیریدونکی رامینځته کوي چې په اسانۍ سره برابر شوي یو ځل د برابر شوي بند په غوښتنه کولو سره تولید کوي.
///
/// دا عموما د یو واحد ارزښت جنریټر ته د [`chain()`] نورو ډولونو تکرار لپاره د یو واحد ارزښت تولید کونکي غوره کولو لپاره کارول کیږي.
/// شاید تاسو تکرار لرئ چې نږدې هرڅه پوښي ، مګر تاسو اضافي ځانګړي قضیې ته اړتیا لرئ.
/// شاید تاسو یو فعالیت لرئ چې په تکرار کونکو کار کوي ، مګر تاسو یوازې د یو ارزښت پروسس کولو ته اړتیا لرئ.
///
/// د [`once()`] په خلاف ، دا فنکشن به په سست ډول د غوښتنې ارزښت تولید کړي.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::iter;
///
/// // یوه ترټولو اوږده شمیره ده
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // یوازې یو ، دا ټول موږ ترلاسه کوو
/// assert_eq!(None, one.next());
/// ```
///
/// د بل تکرارونکي سره یوځای ځړول.
/// راځئ چې ووایو چې موږ غواړو د `.foo` لارښود هرې دوتنې تکرار کړو ، مګر د تشکیلاتو فایل هم ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // موږ اړتیا لرو د ډییر انټری-ایس له تکرارونکي څخه د پاتھ بوفز تکرارونکي ته واړوو ، نو موږ نقشه وکاروو
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // اوس ، زموږ تکرار یوازې زموږ د تشکیل فایل لپاره
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // دوه تکرار کونکي په یو لوی تیریدونکي کې یوځای کړئ
/// let files = dirs.chain(config);
///
/// // دا به موږ ټولو ته فایلونه په .foorc او همدارنګه .foorc راکړو
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// یو تکرار کونکی چې د چمتو شوي بند `F: FnOnce() -> A` په پلي کولو سره د `A` ډول واحد عنصر تولیدوي.
///
///
/// دا `struct` د [`once_with()`] فنکشن لخوا رامینځته شوی.
/// د نورو لپاره د دې اسناد وګورئ.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}