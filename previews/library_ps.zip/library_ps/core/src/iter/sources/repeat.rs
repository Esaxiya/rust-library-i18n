use crate::iter::{FusedIterator, TrustedLen};

/// یو نوی تیتر رامینځته کوي چې په دوامداره توګه یو عنصر تکراروي.
///
/// د `repeat()` فعالیت یو ځل بیا تکراروي.
///
/// د `repeat()` په څیر لامحدود تکرار کونکي اکثرا د [`Iterator::take()`] په څیر د اډیپټرو سره کارول کیږي ، ترڅو دوی محدود کړي.
///
/// که د تکرار عنصر ډول چې تاسو ورته اړتیا لرئ `Clone` نه پلي کوي ، یا که تاسو نه غواړئ تکرار شوي عنصر په حافظه کې وساتئ ، نو تاسو یې پرځای د [`repeat_with()`] فنکشن کارولی شئ.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::iter;
///
/// // څلور څلورم نمبر:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // هو ، لاهم څلور
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// د [`Iterator::take()`] سره د لازمي سفر کول:
///
/// ```
/// use std::iter;
///
/// // دا وروستی مثال ډیر څلوریز وو.راځئ چې یوازې څلور څلوریزې ولرو.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... او اوس مو سرته رسولی
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// یو تکرار کونکی چې یو عنصر په نه مکرر ډول تکراروي.
///
/// دا `struct` د [`repeat()`] فنکشن لخوا رامینځته شوی.د نورو لپاره د دې اسناد وګورئ.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}