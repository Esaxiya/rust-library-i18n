use crate::iter::{FusedIterator, TrustedLen};

/// یو تیټور رامینځته کوي چې یو ځل ورته عنصر په سمه توګه ترلاسه کوي.
///
/// دا عموما د یو بل ارزښت د تکرار نورو ډولونو [`chain()`] ته د تطبیق لپاره کارول کیږي.
/// شاید تاسو تکرار لرئ چې نږدې هرڅه پوښي ، مګر تاسو اضافي ځانګړي قضیې ته اړتیا لرئ.
/// شاید تاسو یو فعالیت لرئ چې په تکرار کونکو کار کوي ، مګر تاسو یوازې د یو ارزښت پروسس کولو ته اړتیا لرئ.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::iter;
///
/// // یوه ترټولو اوږده شمیره ده
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // یوازې یو ، دا ټول موږ ترلاسه کوو
/// assert_eq!(None, one.next());
/// ```
///
/// د بل تکرارونکي سره یوځای ځړول.
/// راځئ چې ووایو چې موږ غواړو د `.foo` لارښود هرې دوتنې تکرار کړو ، مګر د تشکیلاتو فایل هم ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // موږ اړتیا لرو د ډییر انټری-ایس له تکرارونکي څخه د پاتھ بوفز تکرارونکي ته واړوو ، نو موږ نقشه وکاروو
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // اوس ، زموږ تکرار یوازې زموږ د تشکیل فایل لپاره
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // دوه تکرار کونکي په یو لوی تیریدونکي کې یوځای کړئ
/// let files = dirs.chain(config);
///
/// // دا به موږ ټولو ته فایلونه په .foorc او همدارنګه .foorc راکړو
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// یو تکرار کونکی چې یوځل یو ځل عنصر ترلاسه کوي.
///
/// دا `struct` د [`once()`] فنکشن لخوا رامینځته شوی.د نورو لپاره د دې اسناد وګورئ.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}