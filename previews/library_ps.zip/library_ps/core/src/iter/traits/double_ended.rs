use crate::ops::{ControlFlow, Try};

/// یو تیریدونکی چې له دواړو پایونو څخه عناصر تولید کولی شي.
///
/// یو څه چې د `DoubleEndedIterator` تطبیق کوي د یو څه باندې یو اضافي وړتیا لري چې د [`Iterator`] پلي کوي: د شا څخه `توکي take توکي اخیستل هم وړتیا ، او هم له مخې.
///
///
/// دا مهمه ده چې په یاد ولرئ چې دواړه او وروسته دواړه په ورته سلسله کار کوي ، او نه تیریږي: تکرار پای ته رسیدلی کله چې دوی په مینځ کې سره ګوري.
///
/// په ورته فیشن کې د [`Iterator`] پروتوکول ته ، یوځل `DoubleEndedIterator` له [`next_back()`] څخه [`None`] بیرته راستنوي ، بیا یې زنګ وهلی یا شاید هیڅکله [`Some`] بیرته نه راستنوي.
/// [`next()`] او [`next_back()`] د دې مقصد لپاره د تبادلې وړ دي.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// د تکرار له پای څخه عنصر لرې کوي او بیرته راولي.
    ///
    /// `None` بیرته راګرځوي کله چې نور عناصر شتون نلري.
    ///
    /// د [trait-level] سندونه نور توضیحات لري.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// هغه عناصر چې د `DoubleEenderIterator` میتودونو لخوا ترلاسه شوي ممکن د هغه څخه توپیر ولري چې د [te Iterator`] میتودونو لخوا ترلاسه شوي:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// د `n` عناصرو لخوا له شا څخه تیتر ته پرمختګ ورکوي.
    ///
    /// `advance_back_by` د [`advance_by`] ریورس نسخه ده.دا میتود به په لیوالتیا سره د `n` عناصر له شا څخه پیل شي [`next_back`] تر `n` وختونو پورې د [`None`] وختونو پورې وغځوي تر دې چې د [`None`] سره مخ شي.
    ///
    /// `advance_back_by(n)` به [`Ok(())`] بیرته راشي که چیرې تکرار کونکی د `n` عناصرو لخوا په بریالیتوب سره پرمختګ وکړي ، یا [`Err(k)`] که [`None`] ورسره مخ شوي ، چیرته چې `k` د عناصرو شمیر دی چې تیریدونکی د عناصرو له چلولو دمخه پرمختللی شوی دی (د بیلګې په توګه.
    /// د تکرار اوږدوالی).
    /// په یاد ولرئ چې `k` تل د `n` څخه کم دی.
    ///
    /// د `advance_back_by(0)` زنګ وهل هیڅ عناصر نه مصرفوي او تل د [`Ok(())`] راستنوي.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // یوازې `&3` پریښودل شو
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// د تکرار له پای څخه element n n عن عنصر راګرځي.
    ///
    /// دا په لازمي ډول د [`Iterator::nth()`] معکوس نسخه ده.
    /// که څه هم د ډیری شاخص عملیاتو په څیر ، شمیره له صفر څخه پیل کیږي ، نو `nth_back(0)` د پای څخه لومړی ارزښت بیرته راوړي ، `nth_back(1)` دوهم ، او داسې نور.
    ///
    ///
    /// په یاد ولرئ چې د پای او بیرته راګرځیدونکي عنصر ترمینځ ټول عناصر به مصرف شي ، په شمول د بیرته راوړل شوي عنصر.
    /// دا د دې معنی هم لري چې په ورته تکرار کې د `nth_back(0)` ډیری وختونه تلیفون کول مختلف عناصر بیرته راولي.
    ///
    /// `nth_back()` به [`None`] بیرته راشي که چیرې `n` د تکرار له اوږدوالي یا مساوي وي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// د `nth_back()` ډیری ځل زنګ وهل تکرارونکي ته مه اړوي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// د `None` بیرته راستنیدل که چیرې د `n + 1` عنصر څخه کم وي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// دا د [`Iterator::try_fold()`] ریورس نسخه ده: دا عناصر اخلي چې د تکرار له شا څخه پیل کیږي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ځکه چې دا لنډ محور شوی ، پاتې عناصر لاهم د تکرار له لارې شتون لري.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// د تکراري میتود چې د تکرار عنصرونه یو واحد ، وروستي ارزښت ته راټیټوي ، له شا څخه پیل کیږي.
    ///
    /// دا د [`Iterator::fold()`] ریورس نسخه ده: دا عناصر اخلي چې د تکرار له شا څخه پیل کیږي.
    ///
    /// `rfold()` دوه دلیلونه اخلي: لومړنی ارزښت ، او د دوه دلیلونو سره بندول: یو 'accumulator' ، او یو عنصر.
    /// بندیز هغه ارزښت بیرته راولي چې جمع کوونکی باید د راتلونکي تکرار لپاره ولري.
    ///
    /// لومړنی ارزښت هغه ارزښت دی چې راټولونکی به یې په لومړي کال کې ولري.
    ///
    /// د تکرار هر عنصر ته د دې بندیز پلي کولو وروسته ، `rfold()` جمع کوونکی بیرته راولي.
    ///
    /// دا عملیات ځینې وختونه د 'reduce' یا 'inject' په نوم یادیږي.
    ///
    /// فولډینګ ګټور دی کله چې تاسو د یو څه ټولګه ولرئ ، او غواړئ له دې څخه یو واحد ارزښت تولید کړئ.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // د. د ټولو عناصرو مجموعه
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// دا مثال یو تار رامینځته کوي ، د ابتدايي ارزښت سره پیل کیږي او د هر عنصر سره د شا څخه تر مخ پورې دوام لري:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// له شا څخه د تکراري عنصر لټون کوي کوم چې وړاندوینه خوښوي.
    ///
    /// `rfind()` یو بند اخلي چې `true` یا `false` راګرځي.
    /// دا د وتلو هر عنصر ته دا بندیز پلي کوي ، په پای کې پیل کیږي ، او که له دوی څخه هیڅ `true` بیرته راشي ، نو `rfind()` بیرته [`Some(element)`] بیرته راستنوي.
    /// که دوی ټول `false` بیرته راشي ، نو دا [`None`] بیرته راستنوي.
    ///
    /// `rfind()` لنډ سرکشیټ دی؛په بل عبارت ، دا به ژر تر ژره پروسس ودروي کله چې بندیز `true` بیرته راشي.
    ///
    /// ځکه چې `rfind()` یو حواله اخلي ، او ډیری تکرار کونکي د حوالې څخه تکرار کوي ، دا د احتمالي اختلال رامینځته کیدو لامل کیږي چیرې چې دلیل دوه ځله حواله ده.
    ///
    /// تاسو کولی شئ دا تاثیر په لاندې مثالونو کې وګورئ ، د `&&x` سره.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// په لومړي `true` کې درول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // موږ لاهم کولی شو `iter` وکاروو ، ځکه چې ډیر عناصر شتون لري.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}