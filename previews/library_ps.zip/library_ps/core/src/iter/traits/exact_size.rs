/// یو تکرار کونکی چې دقیق اوږدوالی پوهیږي.
///
/// ډیری [`Iterator`] s نه پوهیږي چې دوی به څو ځله تکرار کړي ، مګر ځینې یې کوي.
/// که چیرې یو تکرار کونکی پوه شي چې دا څو ځله تکرار کولی شي ، نو معلوماتو ته لاسرسی چمتو کول ګټور ثابتیدای شي.
/// د مثال په توګه ، که تاسو غواړئ بیرته شا ته تکرار کړئ ، یو ښه پیل دا دی چې پوه شي چې پای چېرته دی.
///
/// کله چې د `ExactSizeIterator` پلي کول ، تاسو باید [`Iterator`] هم پلي کړئ.
/// کله چې داسې کول ، د [`Iterator::size_hint`]*پلي کول باید* د تکرار کونکي اندازه بیرته راشي.
///
/// د [`len`] میتود پخوانی تطبیق لري ، نو تاسو معمولا باید دا پلي نه کړئ.
/// په هرصورت ، تاسو ممکن وتوانیږئ چې د ډیفالټ په پرتله ډیر ښه پلي کونکي چمتو کړئ ، نو پدې حالت کې د دې اضافي کولو معنی ورکوي.
///
///
/// په یاد ولرئ چې دا trait یو خوندي trait دی او لکه دا چې *نه* او * * نشي تضمین کولی چې بیرته ورکړل شوی اوږدوالی سم دی.
/// دا پدې مانا ده چې د `unsafe` کوډ **باید** د [`Iterator::size_hint`] په درستتیا تکیه ونه کړي.
/// بې ثباته او غیر خوندي [`TrustedLen`](super::marker::TrustedLen) trait دا اضافي تضمین ورکوي.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// // یو محدود حد په سمه توګه پوهیږي چې دا به څو ځله تکرار شي
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// په [module-level docs] کې ، موږ یو [`Iterator`] تطبیق کړ ، `Counter`.
/// راځئ چې د دې لپاره هم `ExactSizeIterator` پلي کړو:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // موږ کولی شو په اسانۍ سره د تکرار پاتې شمیره محاسبه کړو.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // او اوس موږ دا کارولی شو!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// د تکرار کونکي اوږدوالی راستنوي.
    ///
    /// پلي کول ډاډ ورکوي چې تکرار کونکی به د [`None`] بیرته راستنیدو دمخه `len()` ډیر ځله د [`Some(T)`] ارزښت بیرته راشي.
    ///
    /// دا میتود ډیفالټ پلي کول لري ، نو تاسو باید عموما دا مستقیم پلي نه کړئ.
    /// په هرصورت ، که تاسو خورا اغیزمن پلي کولو چمتو کولی شئ ، نو تاسو یې کولی شئ.
    /// د مثال لپاره د [trait-level] لاسوندونه وګورئ.
    ///
    /// دا فنکشن د [`Iterator::size_hint`] فنکشن په څیر ورته خوندیتوب تضمین لري.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// // یو محدود حد په سمه توګه پوهیږي چې دا به څو ځله تکرار شي
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: دا ادعا خورا دفاعي ده ، مګر دا بریدګر ګوري
        // د trait لخوا تضمین شوی.
        // که دا trait د rust داخلي وی ، موږ کولی شو ډیبګاسټر وکاروو!assert_eq!د ټولو Rust کارونکي پلي کول به هم وګوري.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// `true` راګرځوي که چیرې تکرار خالي وي.
    ///
    /// دا طریقه د [`ExactSizeIterator::len()`] په کارولو سره ډیفالټ پلي کول لري ، نو تاسو اړتیا نلرئ دا پخپله پلي کړئ.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}