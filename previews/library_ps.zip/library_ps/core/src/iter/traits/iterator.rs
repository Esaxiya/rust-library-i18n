// غفلت-ټیډ-فایل لینټ دا فایل تقریبا په ځانګړي ډول د `Iterator` تعریف سره جوړ دی.
// موږ نشو کولی دا په ګ multipleو فایلونو وویشو.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// د تکرار کونکو سره معامله کولو لپاره یو انٹرفیس.
///
/// دا اصلي تکرارونکی trait دی.
/// په عموم کې د تکرار کونکو مفکورې په اړه نورو معلوماتو لپاره ، مهرباني وکړئ [module-level documentation] وګورئ.
/// په ځانګړي توګه ، تاسو ممکن وغواړئ پوه شئ چې د [implement `Iterator`][impl] څرنګوالی.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// د عناصر ډول چې تکرار کیږي.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// تکرار پرمختګ او راتلونکی ارزښت بیرته راګرځوي.
    ///
    /// [`None`] راستنوي کله چې تکرار پای ته ورسي.
    /// د انفرادي تکرار پلي کول ممکن د تکرار بیا پیلولو لپاره غوره کړي ، او له همدې امله د `next()` بیا تلیفون ممکن ممکن په یو وخت کې د [`Some(Item)`] بیرته راستنیدل پیل کړي.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() ته زنګ راغلی بل ارزښت ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... او بیا هیڅ یو کله چې پای ته ورسي.
    /// assert_eq!(None, iter.next());
    ///
    /// // ډیر زنګونه ممکن `None` بیرته راشي یا نه.دلته ، دوی به تل وي.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// د تکرار په پاتې اوږدوالي حدونه راستنوي.
    ///
    /// په ځانګړي توګه ، `size_hint()` یو ګونګه بیرته راګرځوي چیرې چې لومړی عنصر ښکته حد دی ، او دوهم عنصر د پورتنۍ حد دی.
    ///
    /// دوهم نیمه برخه چې بیرته راستانه کیږي هغه د [[اختیار`]`<`[`usize`]`> `دی.
    /// دلته د [`None`] معنی دا ده چې یا ته هیڅ پورتنی حد شتون نلري ، یا پورتنی حد د [`usize`] څخه لوی دی.
    ///
    /// # د تطبیق یادښتونه
    ///
    /// دا ندی پلي شوی چې د تکرار پلي کول د عنصرونو اعلان شوي شمیر ترلاسه کوي.یو ګیګی ایټریټر ممکن د ټیټ حد څخه لږ یا د عناصرو له پورتنۍ حد څخه ډیر عاید ترلاسه کړي.
    ///
    /// `size_hint()` اساسا د اصلاح لپاره کارول کیږي لکه د تکرار عناصرو لپاره ځای خوندي کول ، مګر باید باور ونلري د مثال په توګه ، په غیر خوندي کوډ کې د حدود چیکونه له لاسه ورکول.
    /// د `size_hint()` غلط پلي کول باید د حافظې خوندیتوب سرغړونې لامل نه کړي.
    ///
    /// دې وویل ، پلې کول باید سم اټکل وړاندې کړي ، ځکه چې که نه نو دا به د trait پروتوکول سرغړونه وي.
    ///
    /// د ډیفالټ پلي کول `(0 ،` [`هیڅ نه]]`) returns بیرته راولي کوم چې د کوم تکرار کونکي لپاره سم دي.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// یو ډیر پیچلی مثال:
    ///
    /// ```
    /// // د حتی شمیر له صفر څخه تر لسو پورې.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // موږ ممکن له صفر څخه تر لسو ځله تکرار کړو.
    /// // پوهیدل چې دا واقعیا پنځه دی د filter() اجرا کولو پرته امکان نلري.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // راځئ چې د chain() سره پنځه نور شمیرې اضافه کړو
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // اوس دواړه حدود پنځه ته لوړ شوي
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// د پورتني حد لپاره `None` بیرته راوړل:
    ///
    /// ```
    /// // یو لامحدود تکرار هیڅ پورتنی حد او اعظمي ممکنه ټیټ حد نلري
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// تکرار کونکی مصرفوي ، د تکرارونو شمیره حسابوي او بیرته یې راستون کوي.
    ///
    /// دا میتود به [`next`] په تکرار سره تلیفون وکړي تر څو چې [`None`] ورسره مخ شي ، د هغه وخت بیرته راستنیدل چې دا یې لیدلی [`Some`].
    /// په یاد ولرئ چې [`next`] باید لږترلږه یو ځل زنګ ووهل شي حتی که چیرې تکرار کونکي عنصر ونه لري.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # د ډیر جریان چلند
    ///
    /// میتود د ډیر جریاناتو پروړاندې هیڅ محافظت نه کوي ، نو د [`usize::MAX`] څخه ډیر عناصرو سره د تکراري عناصرو شمیرل غلط غلط پایله یا panics تولید کوي.
    ///
    /// که چیرې د ضبط ادعاګانې فعالې شي ، نو د panic تضمین دی.
    ///
    /// # Panics
    ///
    /// دا فنکشن ممکن panic که چیرې تکرار کونکي د [`usize::MAX`] څخه ډیر عنصر ولري.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// تکرارونکي مصرف کوي ، وروستی عنصر بیرته راستنوي.
    ///
    /// دا میتود به تکرارونکي ارزونه وکړي تر هغه چې دا [`None`] بیرته راشي.
    /// د داسې کولو پرمهال ، دا د اوسني عنصر تعقیب ساتي.
    /// د [`None`] بیرته راستانه کیدو وروسته ، `last()` به بیا وروستی عنصر چې دا ولیدل بیرته راستون کړي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// د `n` عناصرو لخوا تکرار پرمختګ.
    ///
    /// دا میتود به په لیوالتیا سره د X0XX تلیفون کولو سره X0XX وختونو ته د X0XX وختونو ته لاړ شي ترڅو چې د [`None`] سره مخ شي.
    ///
    /// `advance_by(n)` به [`Ok(())`][Ok] بیرته راشي که چیرې تکرار کونکی د `n` عناصرو لخوا په بریالیتوب سره پرمختګ وکړي ، یا [`Err(k)`][Err] که [`None`] ورسره مخ شوي ، چیرې چې د `k` د عناصرو شمیر دی چې تیریدونکی د عناصرو له چلولو دمخه پرمختللی شوی دی (د بیلګې په توګه.
    /// د تکرار اوږدوالی).
    /// په یاد ولرئ چې `k` تل د `n` څخه کم دی.
    ///
    /// د `advance_by(0)` زنګ وهل هیڅ عناصر نه مصرفوي او تل د [`Ok(())`][Ok] راستنوي.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // یوازې `&4` پریښودل شو
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// د تکرارونکي element n نیت عنصر راستنوي.
    ///
    /// د ډیری شاخص عملیاتو په څیر ، شمیره له صفر څخه پیل کیږي ، نو `nth(0)` لومړی ارزښت بیرته راوړي ، `nth(1)` دوهم ، او داسې نور.
    ///
    /// په یاد ولرئ چې ټول مخکیني عنصرونه ، او همدا رنګه عنصر به له تیریدونکي څخه مصرف شي.
    /// د دې معنی دا ده چې مخکیني عنصرونه به له مینځه یوړل شي ، او همدارنګه دا چې په ورته تکرار کې د `nth(0)` ډیری وختونه تلیفون کول به مختلف عناصر بیرته راشي.
    ///
    ///
    /// `nth()` به [`None`] بیرته راشي که چیرې `n` د تکرار له اوږدوالي یا مساوي وي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// د `nth()` ډیری ځل زنګ وهل تکرارونکي ته مه اړوي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// د `None` بیرته راستنیدل که چیرې د `n + 1` عنصر څخه کم وي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// په ورته ټکي د پیل پیل کولو تیریټر رامینځته کوي ، مګر په هر تکرار کې د ورکړل شوي مقدار سره مرحله کول.
    ///
    /// 1 یادونه: د تکرار کونکي لومړي عنصر به تل بیرته راشي ، پرته لدې چې ورکړل شوي ګام څخه.
    ///
    /// 2 یادونه: هغه وخت چې په پام کې نیول شوي عناصر ایستل شوي ندي ټاکل شوی.
    /// `StepBy` د ترتیب `next(), nth(step-1), nth(step-1),…` په څیر چلند کوي ، مګر د ترتیب په څیر چلند لپاره هم وړیا دی
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// کومه لاره کارول کیږي ممکن د فعالیت لاملونو لپاره د ځینې تکرار کونکو لپاره بدل شي.
    /// دوهمه لاره به دمخه تیریټر ته وده ورکړي او ممکن ډیر توکي مصرف کړي.
    ///
    /// `advance_n_and_return_first` مساوي دي د:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// طریقه به panic وي که ورکړل شوی مرحله `0` وي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// دوه تکرارونکي اخلي او په ترتیب سره د دواړو په اوږدو کې یو نوی تکرار رامینځته کوي.
    ///
    /// `chain()` یو نوی تکرار به راشي کوم چې به لومړی د تیریدونکي څخه د ارزښتونو تکرار شي او بیا د دوهم تکرارونکي څخه ارزښتونو باندې تیریږي.
    ///
    /// په نورو ټکو کې ، دا دوه تکرارونکي یو له بل سره اړیکه لري ، په یو لړ کې.🔗
    ///
    /// [`once`] عموما د یو واحد ارزښت د تکرار د نورو ډولونو لړۍ کې تطابق کولو لپاره کارول کیږي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// له هغه وخته چې د `chain()` دلیل د [`IntoIterator`] کاروي ، موږ کولی شو هر هغه شی ته واستوو چې په [`Iterator`] بدل شي ، نه یوازې پخپله [`Iterator`].
    /// د مثال په توګه ، ټوټې (`&[T]`) [`IntoIterator`] تطبیقوي ، او پدې توګه په مستقیم ډول `chain()` ته لیږدول کیدی شي:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// که تاسو د Windows API سره کار کوئ ، تاسو ممکن د [`OsStr`] `Vec<u16>` ته بدلول وغواړئ:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// دوه ځله تکرار کونکو ته د جوړو واحد تکرار ته.
    ///
    /// `zip()` یو نوی تیریدونکی راستون کوي چې د دوو نورو تیروونکو څخه تکرار شي ، د دوه ګونی بیرته راګرځیدو چیرې چې لومړی عنصر د لومړي تکرار څخه راځي ، او دوهم عنصر د دوهم تکرار څخه راځي.
    ///
    ///
    /// په بل عبارت ، دا دوه تکرارونکي یوځای سره زپ کوي ، په یو واحد کې.
    ///
    /// که چیرې یا تکرار کونکي [`None`] بیرته راولي ، نو د زپ شوي تکرارونکي څخه [`next`] به [`None`] بیرته راشي.
    /// که چیرې لومړی تکرار کونکی [`None`] بیرته راشي ، نو `zip` به شارټ سرکټ او `next` به په دوهم تکرار کونکي نه غږ شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// له هغه وخته چې د `zip()` دلیل د [`IntoIterator`] کاروي ، موږ کولی شو هر هغه شی ته واستوو چې په [`Iterator`] بدل شي ، نه یوازې پخپله [`Iterator`].
    /// د مثال په توګه ، ټوټې (`&[T]`) [`IntoIterator`] تطبیقوي ، او پدې توګه په مستقیم ډول `zip()` ته لیږدول کیدی شي:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ډیری وختونه د لامحدود تکرار ته زیپ کولو لپاره کارول کیږي.
    /// دا کار کوي ځکه چې محدود تکرار کونکی به په پای کې [`None`] بیرته راولي ، د زپ پای ته رسیدو سره.د `(0..)` سره زپ کول د [`enumerate`] په څیر ډیر ښکاري:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// یو نوی تیریټر رامینځته کوي چې د اصلي تکرار کونکي نږدې توکو کې د `separator` کاپي ځای په ځای کوي.
    ///
    /// په هغه حالت کې چې `separator` [`Clone`] نه تطبیقوي یا هر ځل محاسبولو ته اړتیا لري ، [`intersperse_with`] وکاروئ.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // د `a` څخه لومړی عنصر.
    /// assert_eq!(a.next(), Some(&100)); // جدا کونکی.
    /// assert_eq!(a.next(), Some(&1));   // راتلونکی عنصر له `a` څخه.
    /// assert_eq!(a.next(), Some(&100)); // جدا کونکی.
    /// assert_eq!(a.next(), Some(&2));   // د `a` څخه وروستی عنصر.
    /// assert_eq!(a.next(), None);       // تکرار کونکی پای ته رسیدلی
    /// ```
    ///
    /// `intersperse` د عمومي عنصر په کارولو سره د تکراري توکو سره یوځای کیدو لپاره خورا ګټور کیدی شي:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// یو نوی تیتر رامینځته کوي کوم چې د اصلي تکرار کونکي توکو سره د `separator` لخوا رامینځته شوی توکي ځای په ځای کوي.
    ///
    /// بند به دقیقا یو ځل وبلل شي هر ځل چې یو توکي د لاندې تیریدونکي څخه د دوه نږدې توکیو ترمینځ کیښودل شي؛
    /// په ځانګړي توګه ، بند نه ویل کیږي که چیرې لاندې تیریدونکی له دوه شیانو څخه لږ عاید ترلاسه کړي او وروسته د وروستي توکی حاصل شي.
    ///
    ///
    /// که چیرې د تکرار کونکي توکي [`Clone`] پلي کړي ، نو ممکن د [`intersperse`] کارول اسانه وي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // د `v` څخه لومړی عنصر.
    /// assert_eq!(it.next(), Some(NotClone(99))); // جدا کونکی.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // راتلونکی عنصر له `v` څخه.
    /// assert_eq!(it.next(), Some(NotClone(99))); // جدا کونکی.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // وروستی عنصر د `v` څخه.
    /// assert_eq!(it.next(), None);               // تکرار کونکی پای ته رسیدلی
    /// ```
    ///
    /// `intersperse_with` کیدی شي په داسې شرایطو کې وکارول شي چیرې چې جدا کونکی ورته کولو ته اړتیا لري:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // تړل په متناسب ډول خپل توضیح د معاملې لپاره رامینځته کوي.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// یو بند نیسي او یو تیریدونکی رامینځته کوي کوم چې په هر عنصر پورې تړلي بولي.
    ///
    /// `map()` یو استاذ په بل دلیل بدلوي ، د هغې دلیل په واسطه:
    /// یو څه چې [`FnMut`] تطبیقوي.دا یو نوی تکرار تولیدوي کوم چې دا د اصلي تکرار کونکي هر عنصر باندې دا بندیز بولي.
    ///
    /// که تاسو په ډولونو کې فکر کولو کې ښه یاست ، تاسو د `map()` په اړه ورته فکر کولی شئ:
    /// که تاسو یو تیتر لرئ چې تاسو ته د `A` ډول ډول عناصر درکوي ، او تاسو د ځینې بل ډول `B` تکرار غواړئ ، نو تاسو کولی شئ `map()` وکاروئ ، د بندیدو څخه تیریدل چې `A` اخلي او `B` بیرته راولي.
    ///
    ///
    /// `map()` د مفهوم له مخې د [`for`] لاپ سره ورته دی.په هرصورت ، لکه څنګه چې `map()` سست دی ، دا غوره کارول کیږي کله چې تاسو دمخه د نورو تکرار کونکو سره کار کوئ.
    /// که تاسو د اړخ اغیزې لپاره ځینې لوپینګ ترسره کوئ ، نو دا د `map()` په پرتله د [`for`] کارول خورا ایډیومیک ګ .ل کیږي.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// که تاسو یو څه اړخیز اغیز ترسره کوئ ، نو [`for`] ته `map()` ته غوره کړئ:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // دا مه کوه:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // دا حتی اعدام به نه کړي ، ځکه چې دا اسان دی.Rust به پدې اړه تاسو خبرداری ورکړي.
    ///
    /// // پرځای یې ، د دې لپاره وکاروئ:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// د تکرار کونکي هر عنصر باندې بندیز غوښتنه کوي.
    ///
    /// دا په تکرار کونکي کې د [`for`] لوپ کارولو سره مساوي دی ، که څه هم `break` او `continue` د بند څخه امکان نلري.
    /// دا د `for` لوپ کارولو لپاره عموما ایډیومیاټیک دی ، مګر `for_each` ممکن ډیر تقلید شي کله چې د اوږد تکرار ځنځیرونو په پای کې د توکو پروسس کول.
    ///
    /// په ځینو قضیو کې `for_each` ممکن د لوپ څخه هم ګړندی وي ، ځکه چې دا به د `Chain` په څیر اډیپټرونو کې داخلي تکرار وکاروي.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// د داسې کوچني مثال لپاره ، د `for` لاپ ممکن پاک وي ، مګر `for_each` ممکن غوره وي چې د اوږد تکرار کونکو سره فعال سټایل وساتئ:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ایټریټر رامینځته کوي چې د تړلو لپاره کاروي ترڅو وټاکي چې عنصر باید ورکړل شي.
    ///
    /// یو عنصر ورکړل شوی چې بند باید `true` یا `false` بیرته راشي.بیرته راګرځیدونکی به یوازې هغه عناصر تولید کړي د کوم لپاره چې تړل ریښتیا راستنوي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ځکه چې تړل `filter()` ته حواله اخلي ، او ډیری تکرار کونکي د حوالې څخه تکرار کوي ، دا د احتمالي اختلال رامینځته کیدو لامل کیږي ، چیرې چې د بند ډول دوه ځله حواله ده:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // دوه * ضرورت دی!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// د دې پرځای چې یو له ځانه لرې کولو لپاره دلیل د تخریب کارولو لپاره عام وي:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // دواړه او *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// یا دواړه:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // دوه &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// د دې پرتونو.
    ///
    /// په یاد ولرئ چې `iter.filter(f).next()` د `iter.find(f)` سره مساوي دی.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// یو ایټریټر رامینځته کوي چې دواړه فلټرې او نقشې.
    ///
    /// راستنیدونکی تکرار کونکی یوازې `ارزښت s ترلاسه کوي د کوم لپاره چې چمتو شوي بندیز `Some(value)` بیرته راستنوي.
    ///
    /// `filter_map` د [`filter`] او [`map`] زنځیرونو ډیر لنډ جوړ کولو لپاره کارول کیدی شي.
    /// لاندې مثال ښیې چې څنګه `map().filter().map()` `filter_map` ته یو غږ ته لنډ کیدی شي.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// دلته ورته مثال شتون لري ، مګر د [`filter`] او [`map`] سره:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// یو تیریدونکی رامینځته کوي کوم چې اوسنی تکرار شمیره او راتلونکي ارزښت ورکوي.
    ///
    /// تکرار کونکي `(i, val)` حاصلات راوړي ، چیرې چې `i` د تکرار اوسنی شاخص دی او `val` هغه ارزښت دی چې د تکرار لخوا بیرته راستنیدونکی دی.
    ///
    ///
    /// `enumerate()` خپله شمیره د [`usize`] په توګه ساتي.
    /// که تاسو غواړئ د مختلف اندازې انټریر حساب وکړئ ، نو د [`zip`] فن ورته فعالیت چمتو کوي.
    ///
    /// # د ډیر جریان چلند
    ///
    /// میتود د اوښتو په مقابل کې هیڅ محافظت نه کوي ، نو د [`usize::MAX`] څخه ډیر عنصرونه شمیرل غلط غلط پایله یا panics تولید کوي.
    /// که چیرې د ضبط ادعاګانې فعالې شي ، نو د panic تضمین دی.
    ///
    /// # Panics
    ///
    /// بیرته راګرځیدونکی ممکن panic که د بیرته راستانه شوي شاخص به د [`usize`] پراخه شي.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// یو تیریټر رامینځته کوي کوم چې د مصرف کولو پرته د تکرار راتلونکي عنصر لیدلو لپاره [`peek`] وکاروي.
    ///
    /// په تیریدونکي کې د [`peek`] میتود اضافه کوي.د نورو معلوماتو لپاره د دې اسناد وګورئ.
    ///
    /// په یاد ولرئ چې اصلي تیریدونکی لاهم پرمختللی دی کله چې [`peek`] د لومړي ځل لپاره غوښتنه کیږي: د بل عنصر د ترلاسه کولو لپاره ، [`next`] په لاندې تیریدونکي باندې غږ کیږي ، له همدې امله کوم اړخیزې اغیزې (د بیلګې په توګه.
    ///
    /// د [`next`] میتود) بل ارزښت ترلاسه کولو پرته بل څه به پیښ شي.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() راځئ چې future ته وګورو
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // موږ څو ځله peek() کولی شو ، تکرار کونکی پرمختګ نه کوي
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // وروسته له دې چې تکرار پای ته ورسید ، نو peek() دی
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// یو تیریټر رامینځته کوي چې د [وړاندوینې پراساس [`skip`] عناصر.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` بندول د دلیل په توګه اخلي.دا به د وتلو په هر عنصر باندې دا بندیز ووایی ، او عناصر له پامه غورځوي تر هغه چې دا `false` بیرته راشي.
    ///
    /// د `false` بیرته راستنیدو وروسته ، د `skip_while()`'s دنده پای ته رسیدلې ، او پاتې عناصر ترلاسه کیږي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ځکه چې تړل `skip_while()` ته حواله اخلي ، او ډیری تکرار کونکي د حوالې په اړه تکرار کوي ، دا د احتمالي اختلال رامینځته کیدو لامل کیږي ، چیرې چې د بند دلیل ډول دوه اړخیزه حواله ده:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // دوه * ضرورت دی!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// د لومړي `false` وروسته ودریدل:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // پداسې حال کې چې دا به غلط و ، ځکه چې موږ دمخه غلط ترلاسه کړی ، نو skip_while() نور نه کارول کیږي
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ایټریټر رامینځته کوي چې د پیشو پراساس عناصر تولید کوي.
    ///
    /// `take_while()` بندول د دلیل په توګه اخلي.دا به د وتلو په هر عنصر باندې دا بندیز ووایی ، او حاصلات عناصر پداسې حال کې چې دا `true` بیرته راولي.
    ///
    /// د `false` بیرته راستنیدو وروسته ، د `take_while()`'s دنده پای ته رسیدلې ، او پاتې عناصر یې له پامه غورځولي دي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ځکه چې تړل `take_while()` ته حواله اخلي ، او ډیری تکرار کونکي د حوالې څخه تکرار کوي ، دا د احتمالي اختلال رامینځته کیدو لامل کیږي ، چیرې چې د بند ډول دوه ځله حواله ده:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // دوه * ضرورت دی!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// د لومړي `false` وروسته ودریدل:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // موږ ډیر عناصر لرو چې له صفر څخه کم دي ، مګر دا چې موږ دمخه غلط ترلاسه کړی نو take_while() نور نه کارول کیږي
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ځکه چې `take_while()` اړتیا لري ترڅو دې ارزښت ته وګوري ترڅو وګوري چې ایا دا باید شامل شي یا نه ، مصرف کونکي تکرار کونکي به وګوري چې دا لرې شوی:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` نور شتون نلري ، ځکه چې دا مصرف شوی و ترڅو وګوري چې ایا تکرار باید ودریږي ، مګر بیرته په تیرایټ کې ندی ایښودل شوی.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// ایټریټر رامینځته کوي چې دواړه د وړاندوینې او نقشو پراساس عناصر ترلاسه کوي.
    ///
    /// `map_while()` بندول د دلیل په توګه اخلي.
    /// دا به د وتلو په هر عنصر باندې دا بندیز ووایی ، او حاصلات عناصر پداسې حال کې چې دا [`Some(_)`][`Some`] بیرته راولي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// دلته ورته مثال شتون لري ، مګر د [`take_while`] او [`map`] سره:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// د لومړي [`None`] وروسته ودریدل:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // موږ ډیر عناصر لرو چې کولی شي په u32 (4 ، 5) کې فټ شي ، مګر `map_while` د `-3` لپاره `None` بیرته راستولی (لکه څنګه چې د `predicate` `None` بیرته راستنیدلی) او `collect` په لومړي `None` کې ورسره مخ شو.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// ځکه چې `map_while()` اړتیا لري ترڅو دې ارزښت ته وګوري ترڅو وګوري چې ایا دا باید شامل شي یا نه ، مصرف کونکي تکرار کونکي به وګوري چې دا لرې شوی:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` نور شتون نلري ، ځکه چې دا مصرف شوی و ترڅو وګوري چې ایا تکرار باید ودریږي ، مګر بیرته په تیرایټ کې ندی ایښودل شوی.
    ///
    /// په یاد ولرئ چې د [`take_while`] برعکس دا تکرار **نه** فیوز دی.
    /// دا هم مشخص شوي ندي چې دا تکرار کونکی د لومړي [`None`] بیرته راستنیدو وروسته بیرته راستنوي.
    /// که تاسو فیوز ایټریټر ته اړتیا لرئ ، نو [`fuse`] وکاروئ.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// یو ایټریټر رامینځته کوي چې د لومړي `n` عنصرونه پریږدي.
    ///
    /// وروسته له دې چې دوی مصرف شي ، پاتې عناصر حاصل ورکوي.
    /// ددې پرځای چې دا میتود په مستقیم ډول پراخه کړي ، پرځای یې د `nth` میتود وځلوي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// یو ایټریټر رامینځته کوي چې خپل لومړي `n` عناصر ترلاسه کوي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ډیری ځله د لامحدود تکرارونکي سره کارول کیږي ، ترڅو دا محدود کړي:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// که چیرې د `n` عنصر څخه لږ شتون ولري ، نو `take` به ځان د لاندې تیټونکي اندازې پورې محدود کړي:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// د [`fold`] په څیر یو تیریدونکی اډیپټر چې داخلي حالت ساتي او نوی تیټر رامینځته کوي.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` دوه دلیلونه اخلي: یو ابتدایی ارزښت چې داخلي حالت تخموي ، او د دوه دلیلونو سره وتړل ، لومړی یې داخلي حالت ته د تغیر وړ حواله او دوهم د تکراري عنصر.
    ///
    /// بند کولی شي داخلي دولت ته دنده وسپاري چې د تکرارونو ترمینځ ریاست شریک کړي.
    ///
    /// په تکرار باندې ، بند به د تکرار هر عنصر باندې پلي شي او د بند څخه بیرته ستنیدونکي ارزښت ، د [`Option`] ، د تکرار لخوا ترلاسه کیږي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // هر تکرار ، موږ به د عنصر په واسطه دولت ضرب کړو
    ///     *state = *state * x;
    ///
    ///     // بیا ، موږ به د دولت غفلت لاسته راوړو
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// یو تیټور رامینځته کوي چې د نقشې په څیر کار کوي ، مګر د بestedه شوي جوړښت فلیټ کوي.
    ///
    /// د [`map`] اډیپټر خورا ګټور دی ، مګر یوازې کله چې د بند دلیل ارزښتونه تولید کړي.
    /// که چیرې دا په ځای تکرار تولید کړي ، نو د لارښوونې اضافي پرت شتون لري.
    /// `flat_map()` دا اضافي پرت به پخپله لرې کړي.
    ///
    /// تاسو کولی شئ د `flat_map(f)` په اړه د [`map`] پینګ سمینټیک مسایل په توګه فکر وکړئ ، او بیا [` فلیټین] د `map(f).flatten()` په څیر.
    ///
    /// د `flat_map()` په اړه د فکر کولو بله لاره: [`map`] تړل د هر عنصر لپاره یو توکی بیرته راولي ، او د `flat_map()`'s بندیدل د هر عنصر لپاره تکرار بیرته راستنوي.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() یو تکرارونکی راستون کوي
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// یو تیټور رامینځته کوي چې د بestedسټ جوړښت فلیټ کوي.
    ///
    /// دا ګټور دی کله چې تاسو د تکرارونو تکرار لرونکی یا د شیانو تکرار لرونکی وي چې په تکرارونو بدلیدلی شي او تاسو غواړئ د لارښوونې یوه سطح لرې کړئ.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// نقشه کول او بیا فلیټینګ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() یو تکرارونکی راستون کوي
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// تاسو دا د [`flat_map()`] په شرایطو کې هم لیکلی شئ ، کوم چې پدې قضیه کې غوره دی ځکه چې دا په روښانه توګه نیت څرګندوي:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() یو تکرارونکی راستون کوي
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// فلیټینګ یوازې په یو وخت کې د ځناور یوه کچه لرې کوي:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// دلته موږ ګورو چې `flatten()` د "deep" فلیټ نه ترسره کوي.
    /// پرځای یې ، یوازې د ځنګلونو کچه لرې شوې.دا دی ، که تاسو `flatten()` یو درې بعدي صفونه ، پایله به دوه اړخیزه وي نه یو اړخیزه.
    /// د یو اړخیزه جوړښت ترلاسه کولو لپاره ، تاسو باید بیا `flatten()` ته لاړ شئ.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// یو تیریټر رامینځته کوي چې د لومړي [`None`] وروسته پای ته رسیږي.
    ///
    /// وروسته له دې چې یو تیریدونکی [`None`] بیرته راوړي ، future تلیفونونه ممکن بیا [`Some(T)`] ترلاسه کړي یا نه.
    /// `fuse()` یو تیریدونکی تطبیق کوي ، ډاډ ترلاسه کوي چې د [`None`] ورکړل کیدو وروسته ، دا به تل د تل لپاره [`None`] بیرته راشي.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// // یو تکرارونکی چې د ځینې او هیڅ نه ترمنځ بدلیږي
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // که دا حتی وي ، Some(i32) ، بل هیڅ نه
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // موږ لیدلی شو چې زموږ تکرار کونکی شا او خوا ځي
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // په هرصورت ، یوځل چې موږ یې فیوز کړو ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // دا به د لومړي ځل وروسته تل `None` بیرته راشي.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// د تکرار کونکي هر عنصر سره یو څه کوي ، ارزښت تیروي.
    ///
    /// کله چې تکرارونکي کاروئ ، تاسو ډیری وختونه یو له بل سره یوځای زنځیر کوئ.
    /// په داسې کوډ کار کولو پرمهال ، تاسو ممکن وغواړئ وګورئ چې په پایپ لاین کې په بیلابیلو برخو کې څه پیښیږي.د دې کولو لپاره ، `inspect()` ته زنګ ووهئ.
    ///
    /// دا د `inspect()` لپاره خورا عام دی چې ستاسو د وروستي کوډ کې شتون څخه د ډیبګ کولو وسیلې په توګه وکارول شي ، مګر غوښتنلیکونه ممکن دا په ځینو شرایطو کې ګټور ومومي کله چې خطا کولو څخه مخکې له مینځه وړل اړین وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // د دې تکرار ترتیب پیچلی دی.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // راځئ چې د inspect() تلیفونونه اضافه کړو ترڅو تحقیق وکړي چې څه پیښیږي
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// دا به چاپ کړي:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// د سپارلو دمخه غلطي کول
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// دا به چاپ کړي:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// یو تکرار پور اخلي ، نه د دې مصرف کولو پرځای.
    ///
    /// دا ګټور دی چې د تکرار اډاپټرونو پلي کولو ته اجازه ورکړئ پداسې حال کې چې لاهم د اصلي تکرار مالکیت ساتل کیږي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // که موږ بیا د ایټر کارولو هڅه وکړو ، نو دا به کار ونکړي.
    /// // لاندې کرښه "تېروتنه" ورکوي: د لیږد شوي ارزښت کارول: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // راځئ چې بیا دا هڅه وکړو
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // پرځای یې ، موږ په .by_ref() کې اضافه کوو
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // اوس دا سمه ده:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// تکرار کونکی په ټولګه بدلوی.
    ///
    /// `collect()` کولی شي هر څه تکرار شي ، او دا اړونده ټولګه کې بدل کړي.
    /// دا په معیاري کتابتون کې یو له خورا پیاوړي میتودونو څخه دی ، چې په بیالبیلو شرایطو کې کارول کیږي.
    ///
    /// ترټولو لومړنۍ ب patternه چې پکې `collect()` کارول کیږي دا دی چې یوه ټولګه بل ته واړوئ.
    /// تاسو ټولګه واخلئ ، په دې باندې [`iter`] زنګ ووهئ ، د بدلونونو یو ټولګه وکړئ ، او بیا په پای کې `collect()`.
    ///
    /// `collect()` هم د ډولونو مثالونه رامینځته کولی شي چې عادي ټولګه نه وي.
    /// د مثال په توګه ، یو [`String`] د [`چار`] s څخه رامینځته کیدی شي ، او د [`Result<T, E>`][`Result`] توکو تعدیل کونکی کولی شي `Result<Collection<T>, E>` کې راټول شي.
    ///
    /// د نورو لپاره لاندې مثالونه وګورئ.
    ///
    /// ځکه چې `collect()` خورا عمومي دی ، نو دا د ډول انفجار سره ستونزې رامینځته کولی شي.
    /// د ورته په څیر ، `collect()` یو څو ځله دی چې تاسو به یې سینټاکس په مینه ډول د 'turbofish' په نوم پیژنئ: `::<>`.
    /// دا د تخمیني الګوریتم سره مرسته کوي په ځانګړي ډول پوه شي چې تاسو کوم ټولګه کې راټولولو هڅه کوئ.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// په یاد ولرئ چې موږ په کی-اړخ کې `: Vec<i32>` ته اړتیا درلوده.دا ځکه چې موږ کولی شو د مثال په توګه [`VecDeque<T>`] راټول کړو:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// د `doubled` تشریح کولو پرځای د 'turbofish' کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ځکه چې `collect()` یوازې د هغه څه په اړه پاملرنه کوي چې تاسو یې راټول کوئ ، تاسو لاهم د ټربوفش سره د جزوي ډول اشاره ، `_` کارولی شئ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// د [`String`] جوړولو لپاره د `collect()` کارول:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// که تاسو د [`پایلې لیست ولرئ<T, E>`][`پایلې`] s ، تاسو کولی شئ د `collect()` وکاروئ ترڅو وګورئ چې ایا کوم یو یې ناکام شوی:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // موږ ته لومړۍ خطا راکوي
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // موږ ته د ځوابونو لیست راکوي
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// تکرار کونکی مصرفوي ، له دې څخه دوه ټولګې رامینځته کوي.
    ///
    /// `partition()` ته لیږد شوی وړاندوینه کولی شي `true` ، یا `false` بیرته راولي.
    /// `partition()` یوه جوړه بیرته راولي ، ټول هغه عناصر چې د دې لپاره یې `true` بیرته راوړي ، او ټول هغه عناصر چې د دې لپاره `false` بیرته راوړي.
    ///
    ///
    /// [`is_partitioned()`] او [`partition_in_place()`] هم وګورئ.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// د دې تکرارونکي عناصر تنظیموي *په ځای کې* د ورکړل شوي وړاندوینې سره سم ، لکه دا ټول هغه کسان چې `true` بیرته راوړي ټول هغه کسان چې `false` بیرته راګرځي.
    ///
    /// د موندل شوي `true` عناصرو شمیر راولي.
    ///
    /// د ویشل شوي توکو اړوند ترتیب ساتل شوی ندی.
    ///
    /// [`is_partitioned()`] او [`partition()`] هم وګورئ.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // د ماښام او توپیرونو تر مینځ ځای په ځای کول
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ایا موږ باید د رایو د شمېرنې له امله اندېښمن شو؟د ډیر څه درلودو یوازینۍ لار
        // `usize::MAX` بدلیدونکي مآخذونه د ZSTs سره دي ، کوم چې د تقسیم لپاره ګټور ندي ...

        // دا بندول "factory" افعال شتون لري ترڅو په `Self` کې د سخاوت مخه ونیسي.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // په مکرر ډول لومړی `false` ومومئ او د وروستي `true` سره یې بدل کړئ.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// چک کوي که چیرې د دې تکرارونکي عناصر د ورکړل شوي پیشنیکټ مطابق تقسیم شوي وي ، لکه دا ټول هغه کسان چې `true` بیرته راوړي ټول هغه مخکې چې `false` بیرته راشي.
    ///
    ///
    /// [`partition()`] او [`partition_in_place()`] هم وګورئ.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // یا ټول توکي د `true` ازموینه کوي ، یا لومړی بند په `false` کې ودریږي او موږ ګورو چې له دې وروسته نور `true` توکي شتون نلري.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// د تکرار میتود چې یو فن په هغه وخت کې پلي کوي تر هغه چې بریالی راشي ، یو واحد ، نهایی ارزښت تولید کوي.
    ///
    /// `try_fold()` دوه دلیلونه اخلي: لومړنی ارزښت ، او د دوه دلیلونو سره بندول: یو 'accumulator' ، او یو عنصر.
    /// بند یا په بریالیتوب سره بیرته راګرځی ، د دې ارزښت سره چې راټولونکی باید د راتلونکي تکرار لپاره ولري ، یا دا ناکامي بیرته راستنوي ، د غلطۍ ارزښت سره چې بیرته زنګ وهونکی ته سمدلاسه (short-circuiting) تبلیغ کیږي.
    ///
    ///
    /// لومړنی ارزښت هغه ارزښت دی چې راټولونکی به یې په لومړي کال کې ولري.که چیرې د بند پلي کول د تکرار کونکي هر عنصر پروړاندې بریالي شوي ، نو `try_fold()` د بریا په توګه نهایی جمع کوونکی بیرته راستنوي.
    ///
    /// فولډینګ ګټور دی کله چې تاسو د یو څه ټولګه ولرئ ، او غواړئ له دې څخه یو واحد ارزښت تولید کړئ.
    ///
    /// # پلي کونکو ته یادونه
    ///
    /// د (forward) نور ډیری میتودونه د دې شرایطو سره سم ډیفالټ پلي کونکي لري ، نو د دې په روښانه ډول پلي کولو هڅه وکړئ که چیرې دا د ډیفالټ `for` لوپ پلي کولو څخه غوره کار وکړي.
    ///
    /// په ځانګړي توګه ، هڅه وکړئ دا زنګ `try_fold()` په داخلي برخو باندې ولرئ له کوم ځای څخه چې دا تکرار کونکی دی.
    /// که چیرې ډیری تلیفونونو ته اړتیا وي ، نو د `?` آپریټر ممکن د جمع کولو ارزښت سره د زنځیر کولو لپاره اسانه وي ، مګر د کوم بل بریدګر څخه خبر اوسئ چې د دې لومړني بیرته راستنیدو دمخه باید ساتل کیږي.
    /// دا د `&mut self` میتود دی ، نو دلته تیروتنه د تیروتنې وروسته دلته د بیا ژوندي کیدو اړتیا لري.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // د صف د ټولو عناصرو کتل شوې جوړه
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // دا مجموعه کله چې 100 عنصر اضافه کړي ډیر راوباسي
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ځکه چې دا لنډ محور شوی ، پاتې عناصر لاهم د تکرار له لارې شتون لري.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// د تکراري میتود چې په تیریدونکي کې هر شي ته د پام وړ فعالیت تطبیق کوي ، په لومړۍ خطا کې ودریږي او دا خطا بیرته راستنوي.
    ///
    ///
    /// دا د [`for_each()`] د راټیټیدونکي ب asې یا د [`try_fold()`] بې ځایه نسخه په توګه هم فکر کیدی شي.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // دا لنډ محور شوی ، نو پاتې توکي لاهم په تیرایټ کې دي:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// د عملیاتو په پلي کولو سره هر عنصر په زیرمو کې پوښي ، وروستۍ پایله بیرته راوړي.
    ///
    /// `fold()` دوه دلیلونه اخلي: لومړنی ارزښت ، او د دوه دلیلونو سره بندول: یو 'accumulator' ، او یو عنصر.
    /// بندیز هغه ارزښت بیرته راولي چې جمع کوونکی باید د راتلونکي تکرار لپاره ولري.
    ///
    /// لومړنی ارزښت هغه ارزښت دی چې راټولونکی به یې په لومړي کال کې ولري.
    ///
    /// د تکرار هر عنصر ته د دې بندیز پلي کولو وروسته ، `fold()` جمع کوونکی بیرته راولي.
    ///
    /// دا عملیات ځینې وختونه د 'reduce' یا 'inject' په نوم یادیږي.
    ///
    /// فولډینګ ګټور دی کله چې تاسو د یو څه ټولګه ولرئ ، او غواړئ له دې څخه یو واحد ارزښت تولید کړئ.
    ///
    /// Note: `fold()` ، او ورته میتودونه چې بشپړ تکرارونکي تیروي ، ممکن د لامحدود تکرار کونکو لپاره پای ته ونه رسوي ، حتی په traits کې د کوم لپاره چې پایله په ټاکل شوي وخت کې د ټاکلو وړ ده.
    ///
    /// Note: [`reduce()`] د لومړي عنصر کارولو لپاره د لومړني ارزښت په توګه کارول کیدی شي ، که چیرې د راټولونکی ډول او توکي ډول ورته وي.
    ///
    /// # پلي کونکو ته یادونه
    ///
    /// د (forward) نور ډیری میتودونه د دې شرایطو سره سم ډیفالټ پلي کونکي لري ، نو د دې په روښانه ډول پلي کولو هڅه وکړئ که چیرې دا د ډیفالټ `for` لوپ پلي کولو څخه غوره کار وکړي.
    ///
    ///
    /// په ځانګړي توګه ، هڅه وکړئ دا زنګ `fold()` په داخلي برخو باندې ولرئ له کوم ځای څخه چې دا تکرار کونکی دی.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // د صف د ټولو عناصرو مجموعه
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// راځئ چې د تکرار هرې مرحلې ته دلته ورشو:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// او نو ، زموږ وروستۍ پایله ، `6`.
    ///
    /// دا د هغه خلکو لپاره عام دی چې تکرار کونکي یې د پایلو رامینځته کولو لپاره د شیانو لیست سره د `for` لوپ کارولو لپاره ډیر کار نه دی کړی.دا کولی شي په `fold()`s بدل شي:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // د لوپ لپاره:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // دوی یو شان دي
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// عناصر یوځل ته راټیټوي ، د بار بار د کمولو عملیاتو پلي کولو سره.
    ///
    /// که چیرې تیریدونکی خالي وي ، نو [`None`] بیرته راشي؛که نه نو د کمولو پایله یې راوباسي.
    ///
    /// د لږترلږه یو عنصر سره د تکرار کونکو لپاره ، دا د ابتدايي ارزښت په توګه د تکرار د لومړي عنصر سره د [`fold()`] په څیر دی ، هر راتلونکی عنصر په هغې کې فولډ کول.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// اعظمي ارزښت ومومئ:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ازموینه کوي که د تکرار هر عنصر د پیشو سره مل وي.
    ///
    /// `all()` یو بند اخلي چې `true` یا `false` راګرځي.دا د وتونکي هر عنصر ته دا بندیز پلي کوي ، او که دوی ټول `true` بیرته راشي ، نو بیا `all()` هم کوي.
    /// که له دوی څخه کوم یې `false` بیرته راوړي ، نو دا `false` بیرته راوړي.
    ///
    /// `all()` لنډ سرکشیټ دی؛په بل عبارت ، دا به ژر تر ژره پروسس ودروي ځکه چې دا د `false` موندلی ، په دې شرط چې نور څه پیښ نشي ، پایله به یې `false` هم وي.
    ///
    ///
    /// یو خالي تکرار کونکی `true` بیرته راولي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// په لومړي `false` کې درول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // موږ لاهم کولی شو `iter` وکاروو ، ځکه چې ډیر عناصر شتون لري.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ازموینه کوي که د تکرار کوم عنصر د پیشوګانو سره مل وي.
    ///
    /// `any()` یو بند اخلي چې `true` یا `false` راګرځي.دا د وتلو هر عنصر ته دا بندیز پلي کوي ، او که له دوی څخه کوم یې `true` بیرته راوړي ، نو بیا `any()` هم کوي.
    /// که دوی ټول `false` بیرته راشي ، نو دا `false` بیرته راستنوي.
    ///
    /// `any()` لنډ سرکشیټ دی؛په بل عبارت ، دا به ژر تر ژره پروسس ودروي ځکه چې دا د `true` موندلی ، په دې شرط چې نور څه پیښ نشي ، پایله به یې `true` هم وي.
    ///
    ///
    /// یو خالي تکرار کونکی `false` بیرته راولي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// په لومړي `true` کې درول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // موږ لاهم کولی شو `iter` وکاروو ، ځکه چې ډیر عناصر شتون لري.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// د تکرار عنصر لټون کوي کوم چې وړاندوینه خوښوي.
    ///
    /// `find()` یو بند اخلي چې `true` یا `false` راګرځي.
    /// دا د ایتراټر هر عنصر ته دا بندیز پلي کوي ، او که د دوی څخه هیڅ `true` بیرته راشي ، نو `find()` [`Some(element)`] بیرته راستنوي.
    /// که دوی ټول `false` بیرته راشي ، نو دا [`None`] بیرته راستنوي.
    ///
    /// `find()` لنډ سرکشیټ دی؛په بل عبارت ، دا به ژر تر ژره پروسس ودروي کله چې بندیز `true` بیرته راشي.
    ///
    /// ځکه چې `find()` یو حواله اخلي ، او ډیری تکرار کونکي د حوالې څخه تکرار کوي ، دا د احتمالي اختلال رامینځته کیدو لامل کیږي چیرې چې دلیل دوه ځله حواله ده.
    ///
    /// تاسو کولی شئ دا تاثیر په لاندې مثالونو کې وګورئ ، د `&&x` سره.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// په لومړي `true` کې درول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // موږ لاهم کولی شو `iter` وکاروو ، ځکه چې ډیر عناصر شتون لري.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// په یاد ولرئ چې `iter.find(f)` د `iter.filter(f).next()` سره مساوي دی.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// د تکرار عناصرو باندې فعالیت پلي کوي او لومړۍ غیر نه پایلې ته رسوي.
    ///
    ///
    /// `iter.find_map(f)` د `iter.filter_map(f).next()` سره مساوي دی.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// د تکرار عناصرو باندې فعالیت پلي کوي او لومړۍ ریښتیني پایله یا لومړۍ تېروتنه راستنوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// په تکرار کې د عنصر لټون کوي ، د دې شاخص بیرته راوړي.
    ///
    /// `position()` یو بند اخلي چې `true` یا `false` راګرځي.
    /// دا د وتلو هر عنصر ته دا بندیز پلي کوي ، او که له دوی څخه یو `true` بیرته راشي ، نو `position()` [`Some(index)`] بیرته راستنوي.
    /// که دا ټول `false` بیرته راشي ، نو دا [`None`] بیرته راستنوي.
    ///
    /// `position()` لنډ سرکشیټ دی؛په بل عبارت ، دا به ژر تر ژره پروسس ودروي ځکه چې دا د `true` موندلی.
    ///
    /// # د ډیر جریان چلند
    ///
    /// میتود د اوښتو په مقابل کې هیڅ محافظت نه کوي ، نو که چیرې د [`usize::MAX`] غیر مطابقت لرونکي عنصر شتون ولري ، نو دا غلط پایله رامینځته کوي یا panics.
    ///
    /// که چیرې د ضبط ادعاګانې فعالې شي ، نو د panic تضمین دی.
    ///
    /// # Panics
    ///
    /// دا فنکشن ممکن ممکن panic که چیرې تکرار کونکي د `usize::MAX` ډیر میچ نه لرونکي عنصر ولري.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// په لومړي `true` کې درول:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // موږ لاهم کولی شو `iter` وکاروو ، ځکه چې ډیر عناصر شتون لري.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // راستنیدونکی شاخص د تکرار کونکي حالت پورې اړه لري
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// له ښي خوا څخه په تیښته کې د عنصر لټون کوي ، د دې شاخص بیرته راوړي.
    ///
    /// `rposition()` یو بند اخلي چې `true` یا `false` راګرځي.
    /// دا د ایتراټر هر عنصر ته دا بندیز پلي کوي ، د پای څخه پیل کیږي ، او که له دوی څخه یو `true` بیرته راشي ، نو `rposition()` بیرته [`Some(index)`] بیرته راولي.
    ///
    /// که دا ټول `false` بیرته راشي ، نو دا [`None`] بیرته راستنوي.
    ///
    /// `rposition()` لنډ سرکشیټ دی؛په بل عبارت ، دا به ژر تر ژره پروسس ودروي ځکه چې دا د `true` موندلی.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// په لومړي `true` کې درول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // موږ لاهم کولی شو `iter` وکاروو ، ځکه چې ډیر عناصر شتون لري.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // دلته د ډیر جریان چیک لپاره اړتیا نشته ، ځکه چې `ExactSizeIterator` پدې معنی ده چې د عناصرو شمیر په `usize` کې فټ کیږي.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// د تکرار اعظمي عنصر راستنوي.
    ///
    /// که چیرې ډیری عنصرونه په مساوي توګه اعظمي وي ، وروستی عنصر بیرته راځي.
    /// که چیرې تکرار کونکی خالي وي ، نو [`None`] بیرته راځي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// د تکرار لږترلږه عنصر راستنوي.
    ///
    /// که چیرې ډیری عنصرونه په مساوي توګه لږترلږه وي ، لومړی عنصر بیرته راستانه کیږي.
    /// که چیرې تکرار کونکی خالي وي ، نو [`None`] بیرته راځي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// هغه عنصر راستنوي چې د ټاکل شوي فنکشن څخه اعظمي ارزښت ورکوي.
    ///
    ///
    /// که چیرې ډیری عنصرونه په مساوي توګه اعظمي وي ، وروستی عنصر بیرته راځي.
    /// که چیرې تکرار کونکی خالي وي ، نو [`None`] بیرته راځي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// هغه عنصر راستنوي چې ټاکل شوي پرتله کولو فعالیت ته په درناوي اعظمي ارزښت ورکوي.
    ///
    ///
    /// که چیرې ډیری عنصرونه په مساوي توګه اعظمي وي ، وروستی عنصر بیرته راځي.
    /// که چیرې تکرار کونکی خالي وي ، نو [`None`] بیرته راځي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// هغه عنصر راستنوي چې د ټاکل شوي فنکشن څخه لږترلږه ارزښت ورکوي.
    ///
    ///
    /// که چیرې ډیری عنصرونه په مساوي توګه لږترلږه وي ، لومړی عنصر بیرته راستانه کیږي.
    /// که چیرې تکرار کونکی خالي وي ، نو [`None`] بیرته راځي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// هغه عنصر راستنوي چې ټاکل شوي پرتله کولو فعالیت ته په درناوي سره لږترلږه ارزښت ورکوي.
    ///
    ///
    /// که چیرې ډیری عنصرونه په مساوي توګه لږترلږه وي ، لومړی عنصر بیرته راستانه کیږي.
    /// که چیرې تکرار کونکی خالي وي ، نو [`None`] بیرته راځي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// د تکرار کونکي لور ته بدلون ورکوي.
    ///
    /// معمولا ، تکرارونکي له کی from څخه ښیې ته تکرار کیږي.
    /// د `rev()` کارولو وروسته ، یو تکرار کونکی به د دې پرځای بیا ښیې څخه کی to ته تکرار کړي.
    ///
    /// دا یوازې امکان لري که چیرې تکرار پای ولري ، نو `rev()` یوازې په [`DoubleEndedIterator`] s کار کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// د جوړه ایټریټر یو جوړه کانتینرونو ته واړوئ.
    ///
    /// `unzip()` د جوړو یو بشپړ تکرار مصرفوي ، دوه ټولګه تولید کوي: یو د جوړې د کی elementsو عنصرو څخه ، او یو د ښي عنصرونو څخه.
    ///
    ///
    /// دا فنکشن ، په یو معنی ، د [`zip`] برعکس دی.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// یو تیریټر رامینځته کوي کوم چې د دې ټول عناصر کاپي کوي.
    ///
    /// دا ګټور دی کله چې تاسو له `&T` څخه تکرار لرئ ، مګر تاسو د `T` څخه ډیر تکرار ته اړتیا لرئ.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // کاپي د .map(|&x| x) په څیر ده
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// یو تیریدونکی رامینځته کوي کوم چې [all clone`] د هغې ټول عنصر دي.
    ///
    /// دا ګټور دی کله چې تاسو له `&T` څخه تکرار لرئ ، مګر تاسو د `T` څخه ډیر تکرار ته اړتیا لرئ.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // کلون د .map(|&x| x) په څیر ورته دی ، د عدد لپاره
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// په تکرار سره تکرار تکرار کړئ.
    ///
    /// د [`None`] پرځای ودرولو پرځای ، تکرار کونکی به د دې پرځای بیا پیل وکړي ، له پیل څخه.د بیا تکرار وروسته ، دا به په پیل کې بیا پیل شي.او بیا.
    /// او بیا.
    /// Forever.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// د بیا تکرار کولو عناصر ترکیب کوي.
    ///
    /// هر عنصر اخلي ، دوی سره یوځای کوي ، او پایله یې راوباسي.
    ///
    /// یو خالي تکرارونکی د ډول صفر ارزښت بیرته راګرځوي.
    ///
    /// # Panics
    ///
    /// کله چې `sum()` زنګ ووهئ او لومړنۍ انفرادي ډول بیرته راستانه شي ، نو دا طریقه به panic وي که چیرې د کمپیوټري جریان او ډیبګ زورونه فعال شي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// د ټول تیریدونکي برخې باندې توکی ، د ټولو عنصرونو ضرب کول
    ///
    /// یو خالي تکرارونکی د ډول یو ارزښت بیرته ورکوي.
    ///
    /// # Panics
    ///
    /// کله چې `product()` ته زنګ ووهئ او لومړنۍ عدد ډول بیرته راشئ ، نو طریقه به panic وي که چیرې د کمپیوټري جریان او ډیبګ زورونه فعال شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) د دې [`Iterator`] عناصر د بل سره پرتله کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) د دې [`Iterator`] عناصر د بل سره ورته پرتله کولو سره د ټاکل شوي پرتله کولو فعالیت سره پرتله کوي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) د دې [`Iterator`] عناصر د بل سره پرتله کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) د دې [`Iterator`] عناصر د بل سره ورته پرتله کولو سره د ټاکل شوي پرتله کولو فعالیت سره پرتله کوي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// ټاکي که چیرې د دې [`Iterator`] عناصر د بل سره ورته وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// مشخص کوي که چیرې د دې [`Iterator`] عناصر د ټاکل شوي مساوات فعالیت ته په درناوي د بل سره مساوي وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// مشخص کوي که چیرې د دې [`Iterator`] عناصر د بل یو سره غیر مساوي وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// مشخص کوي که چیرې د دې [`Iterator`] عناصر د یو بل څخه [lexicographically](Ord#lexicographical-comparison) لږ وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// مشخص کوي که چیرې د دې [`Iterator`] عناصر [lexicographically](Ord#lexicographical-comparison) لږ وي یا د بل ورته سره مساوي وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// مشخص کوي که چیرې د دې [`Iterator`] عناصر د یو بل څخه [lexicographically](Ord#lexicographical-comparison) لوی وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// ټاکي که چیرې د دې [`Iterator`] عناصر د [lexicographically](Ord#lexicographical-comparison) لوی وي یا د بل سره مساوي وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// چیک کوي چې ایا د دې تکرارونکي عناصر ترتیب شوي دي.
    ///
    /// دا ، د هر عنصر `a` او د هغې عنصر `b` لپاره ، `a <= b` باید ونیسي.که چیرې تکرار کونکی صفا یا یو عنصر ترلاسه کړي ، نو `true` بیرته راستنیدلی.
    ///
    /// په یاد ولرئ که چیرې `Self::Item` یوازې `PartialOrd` دی ، مګر `Ord` نه ، پورتنی تعریف پدې معنی دی چې دا فنون `false` بیرته ورکوي که چیرې دوه پرله پسې توکي د پرتلې وړ نه وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// چک کوي که د دې تکرارونکي عناصر د ورکړل شوي پرتله کونکي فنکشن په کارولو سره ترتیب شوي.
    ///
    /// د `PartialOrd::partial_cmp` کارولو پرځای ، دا فعالیت د ورکړل شوي `compare` فعالیت کاروي ترڅو د دوه عناصرو ترتیب وټاکي.
    /// د دې تر څنګ ، دا د [`is_sorted`] سره برابر دی؛د نورو معلوماتو لپاره د دې اسناد وګورئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// چک کوي که د دې تکرارونکي عناصر د ورکړل شوي کیلي استخراج فنکشن په کارولو سره ترتیب شوي.
    ///
    /// د تکرار کونکي عناصرو مستقیم پرتله کولو پرځای ، دا فنکشن د عناصرو کلیدونه پرتله کوي ، لکه څنګه چې د `f` لخوا ټاکل شوی.
    /// د دې تر څنګ ، دا د [`is_sorted`] سره برابر دی؛د نورو معلوماتو لپاره د دې اسناد وګورئ.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] وګورئ
    // غیر معمولي نوم د میتود په حل کې د نوم ټکرونو مخنیوي لپاره دی #76479 وګورئ.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}