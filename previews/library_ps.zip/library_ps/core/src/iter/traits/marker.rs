/// یو تکرار کونکی چې تل د `None` حاصل ورکولو ته دوام ورکوي کله چې ستړی شئ.
///
/// په فیوز شوي تکرار باندې بل غږ کول چې یوځل `None` بیرته راشي د [`None`] بیرته راستنیدو تضمین دی.
/// دا trait باید د ټولو تکرار کونکو لخوا پلي شي چې دا ډول چلند کوي ځکه چې دا د [`Iterator::fuse()`] اصلاح کولو ته اجازه ورکوي.
///
///
/// Note: په عموم کې ، تاسو باید په جینریک حدونو کې `FusedIterator` ونه کاروئ که چیرې تاسو فیوز شوی تکرار ته اړتیا لرئ.
/// پرځای یې ، تاسو باید یوازې تکرار کونکي ته [`Iterator::fuse()`] زنګ ووهئ.
/// که چیرې تکرار کونکی لا دمخه فیوز شوی وي ، نو د [`Fuse`] اضافي ریپر به د فعالیت جریمې سره نه وي.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// یو تکرار کونکی چې د اندازې_چینټ په کارولو سره د دقیق اوږدوالي راپور ورکوي.
///
/// تکرار کونکی د اندازې اشاره راپورته کوي چیرته چې دا سمه وي (ټیټ حد د پورتنۍ حد سره مساوي وي) ، یا پورتنۍ حد د [`None`] دی.
///
/// پورتنی حد باید یوازې [`None`] وي که چیرې د اصلي تکرار اوږدوالی د [`usize::MAX`] څخه لوی وي.
/// پدې حالت کې ، ټیټ حد باید [`usize::MAX`] وي ، په پایله کې د `(usize::MAX, None)` [`Iterator::size_hint()`].
///
/// تکرار کونکی باید دقیقا د عناصرو شمیر تولید کړي چې راپور شوي یا پای ته رسیدو دمخه منحل کیږي.
///
/// # Safety
///
/// دا trait باید یوازې هغه وخت پلي شي کله چې تړون دوام ولري.
/// د دې trait مصرف کونکي باید [`Iterator::size_hint()`]’s د پورتنۍ حد معاینه وکړي.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// یو تکرار کونکی چې کله د توکي محصول راولي نو لږترلږه یو عنصر یې د خپل اصلي [`SourceIter`] څخه اخیستی وي.
///
/// هر ډول میتود ته زنګ وهل چې تکرار ته پرمختګ ورکوي ، د بیلګې په توګه
/// [`next()`] یا [`try_fold()`] ، تضمین ورکوي چې د هر مرحلې لپاره لږترلږه د تکرار لاندې زیرمې سرچینه بهر ته لیږدول شوې وي او د تکرار سلسله پایله په خپل ځای کې دننه کیدلی شي ، د سرچینې ساختماني خنډونه داسې داخليدو ته اجازه ورکوي.
///
/// په نورو ټکو کې دا trait اشاره کوي چې د تکرار پایپ لاین په ځای کې راټول کیدی شي.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}