/// له [`Iterator`] څخه بدلون.
///
/// د یو ډول لپاره د `FromIterator` پلي کولو سره ، تاسو تشریح کوئ چې دا به د تکرار څخه څنګه رامینځته شي.
/// دا د ډولونو لپاره عام دی کوم چې د یو ډول ټولګه بیانوي.
///
/// [`FromIterator::from_iter()`] په ندرت سره په څرګند ډول ویل کیږي ، او د [`Iterator::collect()`] میتود له لارې کارول کیږي.
///
/// د نورو مثالونو لپاره د [`Iterator::collect()`]'s اسناد وګورئ.
///
/// هم وګوره: [`IntoIterator`].
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// د [`Iterator::collect()`] کارول په څرګنده ډول د `FromIterator` کارول:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ستاسو د ډول لپاره د `FromIterator` پلي کول:
///
/// ```
/// use std::iter::FromIterator;
///
/// // د نمونې ټولګه ، دا یوازې په Vec باندې ریپر دی<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // راځئ چې دا یو څه میتودونه راکړو نو موږ کولی شو یو یې رامینځته کړو او په هغې کې شیان اضافه کړو.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // او موږ به له فلتر څخه تطبیق کړو
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // اوس موږ کولی شو یو نوی تکرار کونکی ...
/// let iter = (0..5).into_iter();
///
/// // ... او له دې څخه زما کلکسیون جوړ کړئ
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // کار هم راټول کړئ!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// د تکرارونکي څخه ارزښت رامینځته کوي.
    ///
    /// د نورو لپاره [module-level documentation] وګورئ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// په [`Iterator`] کې اړول.
///
/// د یو ډول لپاره د `IntoIterator` په پلي کولو سره ، تاسو تشریح کوئ چې دا به څنګه تکرار کونکي ته واړول شي.
/// دا د ډولونو لپاره عام دی کوم چې د یو ډول ټولګه بیانوي.
///
/// د `IntoIterator` پلي کولو یوه ګټه دا ده چې ستاسو ډول به [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) وي.
///
///
/// هم وګوره: [`FromIterator`].
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// ستاسو د ډول لپاره د `IntoIterator` پلي کول:
///
/// ```
/// // د نمونې ټولګه ، دا یوازې په Vec باندې ریپر دی<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // راځئ چې دا یو څه میتودونه راکړو نو موږ کولی شو یو یې رامینځته کړو او په هغې کې شیان اضافه کړو.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // او موږ به دننه داخل کړو
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // اوس موږ کولی شو یو نوی ټولګه جوړه کړو ...
/// let mut c = MyCollection::new();
///
/// // ... یو څه پکې اضافه کړئ ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... او بیا یې دې ته اړوونکی ته واړو:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// دا د `IntoIterator` د trait bound په توګه کارول عام دي.دا د ننوت راټولولو ډول بدلولو ته اجازه ورکوي ، نو ځکه چې دا لاهم یو تیریدونکی دی.
/// اضافي حدود د محدودولو سره ټاکل کیدی شي
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// د عناصر ډول چې تکرار کیږي.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// کوم ډول تکرار کونکی موږ دې ته اړوو؟
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// له ارزښت څخه تکرار کونکی جوړوي.
    ///
    /// د نورو لپاره [module-level documentation] وګورئ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// د تکرارونکي مینځپانګو سره ټولګه پراخه کړئ.
///
/// تفتیش کونکي یو لړ ارزښتونه تولیدوي ، او راټولونه هم د ارزښتونو لړۍ په توګه فکر کیدی شي.
/// د `Extend` trait دغه تشه ډیزاین کوي ، تاسو ته اجازه درکوي د دې تکرارونکي مینځپانګې په ګډون کولو ټولولو ته وده ورکړئ.
/// کله چې د موجوده موجود کیلي سره ټولګه غځول ، دا ننوتنه تازه کیږي یا ، د راټولولو په حالت کې چې د مساوي کیلي سره ډیری ننوتلو ته اجازه ورکوي ، دا ننوتنه دننه کیږي.
///
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// // تاسو کولی شئ د ځینې کرونو سره سټینګ وغزوئ:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// د `Extend` پلي کول:
///
/// ```
/// // د نمونې ټولګه ، دا یوازې په Vec باندې ریپر دی<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // راځئ چې دا یو څه میتودونه راکړو نو موږ کولی شو یو یې رامینځته کړو او په هغې کې شیان اضافه کړو.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // له هغه ځایه چې مایک کولیکشن د آی 32s لیست لري ، نو موږ د i32 لپاره غزول پلي کوو
/// impl Extend<i32> for MyCollection {
///
///     // دا د کانکریټ ډوله لاسلیک سره یو څه ساده دی: موږ کولی شو په هر هغه څه وغواړو چې موږټ ته بدل شي کوم چې موږ ته i32s راکوي.
///     // ځکه چې موږ مای کلکسیون کې اچولو لپاره i32s ته اړتیا لرو.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // پلي کول خورا سم دي: د تکرار له لارې لوپ ، او ځان ته add() هر عنصر.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // راځئ چې خپل ټولګه د دریو نورو شمیرو سره وغزوو
/// c.extend(vec![1, 2, 3]);
///
/// // موږ دا عناصر په پای کې اضافه کړل
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// د تکرارونکي مینځپانګو سره ټولګه پراخه کوي.
    ///
    /// لکه څنګه چې دا د دې trait لپاره یوازینۍ اړین میتود دی ، نو د [trait-level] سندونه نور توضیحات لري.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// // تاسو کولی شئ د ځینې کرونو سره سټینګ وغزوئ:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// دقیقا د یو عنصر سره ټولګه پراخه کوي.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// د اضافي عناصرو ورکړل شوي شمیرې لپاره په ټولګه کې ظرفیت خوندي کوي.
    ///
    /// د ډیفالټ پلي کول هیڅ نه کوي.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}