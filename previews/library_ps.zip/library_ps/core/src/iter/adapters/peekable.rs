use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// د `peek()` سره یو تکرارونکی چې راتلونکي عنصر ته اختیاري حواله بیرته راولي.
///
///
/// دا `struct` په [`Iterator`] کې د [`peekable`] میتود لخوا رامینځته شوی.
/// د نورو لپاره د دې اسناد وګورئ.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// یو څرګند شوی ارزښت په یاد وساتئ ، حتی که دا هیڅ هم نه و.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// پام وړ باید په یاد ولري که چیرې یو هم د `.peek()` په میتود کې نه وي لیدل شوی.
// دا باوري کوي چې `.peek()؛.peek();` یا `.peek()؛.next();` یوازې په یوځل کې دننه تکرار کونکي ته پرمختګ ورکوي.
// دا پخپله نه تکرارونکی فیوز کوي.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// د اکرټر پرمختللو پرته د next() ارزښت ته مآخرت ورکوي.
    ///
    /// د [`next`] په څیر ، که چیرې یو ارزښت شتون ولري ، نو دا په `Some(T)` کې نغښتی دی.
    /// مګر که چیرې تکرار پای ته ورسي ، نو `None` بيرته راستون شوی.
    ///
    /// [`next`]: Iterator::next
    ///
    /// ځکه چې `peek()` یو حواله بیرته راګرځوي ، او ډیری تکرار کونکي د حوالې څخه تکرار کوي ، ممکن احتمالي اختلال وضعیت وي چیرې چې د بیرته راستنیدو ارزښت دوه ځله حواله وي.
    /// تاسو کولی شئ دا تاثیر په لاندې مثالونو کې وګورئ.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() راځئ چې future ته وګورو
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // تکرار کونکی پرمختګ نه کوي حتی که موږ څو ځله `peek` هم وکړو
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // وروسته له دې چې تکرار پای ته ورسید ، نو `peek()` دی
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// د next() ارزښت ته تغیر کونکي پرمختګ سره بدلیدونکی حواله بیرته ورکوي.
    ///
    /// د [`next`] په څیر ، که چیرې یو ارزښت شتون ولري ، نو دا په `Some(T)` کې نغښتی دی.
    /// مګر که چیرې تکرار پای ته ورسي ، نو `None` بيرته راستون شوی.
    ///
    /// ځکه چې `peek_mut()` حواله بیرته راګرځوي ، او ډیری تکرار کونکي د حوالې څخه تکرار کوي ، ممکن احتمالي اختلال وضعیت وي چیرې چې د راستنیدنې ارزښت دوه ځله حواله وي.
    /// تاسو کولی شئ دا تاثیر په لاندې مثالونو کې وګورئ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // د `peek()` په څیر ، موږ کولی شو د ایتراټور پرمختګ پرته future کې وګورو.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // تکرار ته لاړشئ او د بدلون وړ مراجع شاته ارزښت تنظیم کړئ.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // هغه ارزښت چې موږ تکراروي لکه څنګه چې تکرار دوام لري.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// مصرف کړئ او د دې تکرار راتلونکي ارزښت بیرته ورکړئ که چیرې یو حالت سم وي.
    /// که `func` د دې تکرار کونکي راتلونکي ارزښت لپاره `true` بیرته راستنوي ، مصرف یې کړئ او بیرته یې ورکړئ.
    /// نور نو ، `None` بیرته راوګرځئ.
    /// # Examples
    /// یوه شمېره مصرف کړئ که دا د 0 سره مساوي وي.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // د تکرار کونکی لومړی توکی 0 دی؛مصرف یې کړئ.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // راتلونکی توکي بیرته 1 دی ، نو `consume` به `false` بیرته راولي.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` د بل توکي ارزښت خوندي کوي که چیرې دا د `expected` سره مساوي نه وي.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// له 10 څخه لږ شمیر مصرف کړئ.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // ټولې شمیرې له 10 څخه لږ واخلئ
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // راتلونکی ارزښت به 10 وي
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // له هغه وخته چې موږ د `self.next()` په نوم نومولی ، نو موږ `self.peeked` مو مصرف کړ.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// راتلونکی توکي مصرف کړئ او بیرته یې ورکړئ که چیرې دا د `expected` سره مساوي وي.
    /// # Example
    /// یوه شمېره مصرف کړئ که دا د 0 سره مساوي وي.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // د تکرار کونکی لومړی توکی 0 دی؛مصرف یې کړئ.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // راتلونکی توکي بیرته 1 دی ، نو `consume` به `false` بیرته راولي.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` د بل توکي ارزښت خوندي کوي که چیرې دا د `expected` سره مساوي نه وي.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // خوندي: د ورته اړتیاو سره غیر محفوظ فعالیت ته د غیر خوندي فعالیت لیږدول
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}