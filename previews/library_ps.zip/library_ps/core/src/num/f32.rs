//! دوامداره د `f32` واحد-دقیق فلوټینګ پوینټ ډول پورې اړه لري.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! په ریاضياتي توګه د پام وړ شمیرې د `consts` فرعي ماډل کې چمتو شوي.
//!
//! د دې ماډل کې مستقیم تعریف شوي ثابت کونکي لپاره (لکه څنګه چې د `consts` فرعي ماډل کې تعریف شوي څخه توپیر لري) ، نوی کوډ باید د دې پرځای اړونده مستعمرې وکاروي په مستقیم ډول د `f32` ډول کې ټاکل شوي.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// رادکس یا د `f32` د داخلي نمایندګۍ اساس.
/// پرځای یې [`f32::RADIX`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // مطلوب لاره
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// په 2 بیس کې د پام وړ ټکو شمیر.
/// پرځای یې [`f32::MANTISSA_DIGITS`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // مطلوب لاره
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// په 10 بیس کې د پام وړ ډیرو اټکل شوی شمیر.
/// پرځای یې [`f32::DIGITS`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // مطلوب لاره
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] د `f32` لپاره ارزښت.
/// پرځای یې [`f32::EPSILON`] وکاروئ.
///
/// دا د `1.0` او بل لوی نماینده شمیرې ترمنځ توپیر دی.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // مطلوب لاره
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// ترټولو کوچنی محدود `f32` ارزښت.
/// پرځای یې [`f32::MIN`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // مطلوب لاره
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// خورا لږ مثبت نورمال `f32` ارزښت.
/// پرځای یې [`f32::MIN_POSITIVE`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // مطلوب لاره
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// ترټولو لوی محدود `f32` ارزښت.
/// پرځای یې [`f32::MAX`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // مطلوب لاره
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// یو د لږترلږه ممکنه عادي بریښنا 2 توکی څخه لوی.
/// پرځای یې [`f32::MIN_EXP`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // مطلوب لاره
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// د 2 توزیع کونکي اعظمي بریښنا.
/// پرځای یې [`f32::MAX_EXP`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // مطلوب لاره
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// د 10 توزیع کونکي لږترلږه ممکن نورمال ځواک.
/// پرځای یې [`f32::MIN_10_EXP`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // مطلوب لاره
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// د 10 توضیحي اعظمي بریښنا.
/// پرځای یې [`f32::MAX_10_EXP`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // مطلوب لاره
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// شمېره (NaN) نه.
/// پرځای یې [`f32::NAN`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // مطلوب لاره
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// انفینیت (∞).
/// پرځای یې [`f32::INFINITY`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // مطلوب لاره
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// منفي انفینټي (−∞).
/// پرځای یې [`f32::NEG_INFINITY`] وکاروئ.
///
/// # Examples
///
/// ```rust
/// // تخفیف شوې لاره
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // مطلوب لاره
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// اساسی ریاضی فشارونه.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: له cmath څخه د ریاضیاتو دوامدارو سره ځای په ځای کړئ.

    /// د آرکیډیمز ثابت (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// د بشپړ حلقې ثابت (τ)
    ///
    /// د 2π سره مساوي.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// د ایلیر شمیره (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// رادکس یا د `f32` د داخلي نمایندګۍ اساس.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// په 2 بیس کې د پام وړ ټکو شمیر.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// په 10 بیس کې د پام وړ ډیرو اټکل شوی شمیر.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] د `f32` لپاره ارزښت.
    ///
    /// دا د `1.0` او بل لوی نماینده شمیرې ترمنځ توپیر دی.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// ترټولو کوچنی محدود `f32` ارزښت.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// خورا لږ مثبت نورمال `f32` ارزښت.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// ترټولو لوی محدود `f32` ارزښت.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// یو د لږترلږه ممکنه عادي بریښنا 2 توکی څخه لوی.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// د 2 توزیع کونکي اعظمي بریښنا.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// د 10 توزیع کونکي لږترلږه ممکن نورمال ځواک.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// د 10 توضیحي اعظمي بریښنا.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// شمېره (NaN) نه.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// انفینیت (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// منفي انفینټي (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// `true` راګرځوي که دا ارزښت `NaN` وي.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` د وړتیا په اړه د اندیښنو له امله په لیبیکور کې په عامه ډول شتون نلري ، نو دا تطبیق په داخلي توګه د شخصي کارونې لپاره دی.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// `true` راستنوي که چیرې دا ارزښت مثبت انفینټي یا منفي انفینټیټ وي ، او `false` په بل ډول.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// `true` راګرځوي که چیرې دا شمیره نه لامحدود وي او نه `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // اړتیا نشته چې په جلا ډول د NaN اداره کړئ: که چیرې پخپله NaN وي ، نو پرتله کول سم ندي ، لکه څنګه چې مطلوب.
        //
        self.abs_private() < Self::INFINITY
    }

    /// `true` راګرځوي که شمیره [subnormal] وي.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // د `0` او `min` ترمنځ ارزښتونه غیر معمولي دي.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// د `true` راګرځوي که چیرې شمیره صفر ، لامحدود ، [subnormal] ، یا `NaN` نه وي.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // د `0` او `min` ترمنځ ارزښتونه غیر معمولي دي.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// د شمشتی فلوټینګ پوسټ کټګورۍ راستنوي.
    /// که چیرې یوازې یو ملکیت ازمول کیږي ، نو عموما ګړندی وي د دې پرځای د مشخص وړاندوینې کارول.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `true` راولي که چیرې `self` مثبت نښه ولري ، پشمول د `+0.0` ، positive NaN`s د مثبت نښه بټ او مثبت انفینیت سره.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// `true` راولي که چیرې `self` منفي نښه ولري ، په شمول د `-0.0` ، negative NaN`s د منفي نښه بټ او منفي انفینیت سره.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 وايي: isSignMinus(x) ریښتینی دی که یوازې او که ایکس منفي نښه ولري.
        // isSignMinus په صفر او NaNs هم پلي کیږي.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// د یو شمیر عادي (inverse) اخلي ، `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// رادیان په درجې بدلوي.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // د غوره دقیقت لپاره یو ثابت کار کړئ.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// درجې ګانو ته واړوئ.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// د دوه اعظمي اعظمي حد ته راګرځي
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// که یو له دلیلونو څخه NaN وي ، نو بل دلیل یې راستون کیږي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// لږترلږه د دوو شمیرو راګرځوي.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// که یو له دلیلونو څخه NaN وي ، نو بل دلیل یې راستون کیږي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// صفر ته ګرځي او هر ډول عدد بشپړ ډول ته بدلوي ، په دې معنی چې ارزښت محدود دی او په دې ډول کې فټ کیږي.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// ارزښت باید:
    ///
    /// * `NaN` نه وي
    /// * لامحدود مه اوسئ
    /// * د بیرته ستن ډول `Int` کې د نمایندګۍ وړ اوسئ ، وروسته له هغې د برخې برخې له ټوټې کولو څخه
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // خوندي: زنګ وهونکی باید د `FloatToInt::to_int_unchecked` لپاره د خوندیتوب تړون ملاتړ وکړي.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` ته د خام لیږد
    ///
    /// دا اوس مهال په ټولو پلیټونو کې `transmute::<f32, u32>(self)` ته ورته دی.
    ///
    /// د دې عملیاتو د ظرفیت ځینې بحث لپاره `from_bits` وګورئ (نږدې مسلې شتون نلري).
    ///
    /// په یاد ولرئ چې دا فنکشن د `as` کاسټینګ څخه توپیر لري ، کوم چې د *شمیره* ارزښت ساتلو هڅه کوي ، او نه د بټیوز ارزښت.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() کاسټ کول نه دي!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // خوندي: `u32` یو پخوانی زوړ ډاټا دی نو موږ کولی شو تل ورته لیږد کړو
        unsafe { mem::transmute(self) }
    }

    /// له `u32` څخه د خام لیږد.
    ///
    /// دا اوس مهال په ټولو پلیټونو کې `transmute::<u32, f32>(v)` ته ورته دی.
    /// داسې معلومیږي چې دا د دوه دلیلونو لپاره ، د نه منلو وړ وړ وړ دی.
    ///
    /// * فلوټس او انټس په ټولو ملاتړ شوي پلیټ فارمونو کې ورته پایښت لري.
    /// * IEEE-754 خورا دقیقا د فلوټونو بټ ترتیب مشخص کوي.
    ///
    /// په هرصورت دلته یو احتیاط شتون لري: د IEEE-754 د 2008 نسخه دمخه ، د NaN سیګنلینګ بټ تشریح کولو څرنګوالی په حقیقت کې مشخص شوی نه و.
    /// ډیری پلیټ فارمونو (په ځانګړي توګه x86 او ARM) هغه تشریح غوره کړی چې په نهایت کې په 2008 کې معیاري شوی ، مګر ځینې یې ندي (په ځانګړي توګه MIP).
    /// د پایلې په توګه ، په MIPS کې ټول سیګنلینګ نان په x86 کې خاموش NaNs دي ، او برعکس.
    ///
    /// د دې پرځای چې د سیګنالګ-Ness کراس پلیټ فارم ساتلو هڅه وکړي ، دا پلي کول دقیق بیټونو ساتنه غوره کوي.
    /// دا پدې مانا ده چې په NaNs کې کوډ شوي هر ډول تادیې به خوندي شي حتی که د دې میتود پایله د x86 ماشین څخه د MIPS یو ته د شبکې له لارې لیږل شوې وي.
    ///
    ///
    /// که چیرې د دې میتود پایلې یوازې د ورته معمار لخوا اداره شي چې دوی رامینځته کړي ، نو بیا د پور وړتیا اندیښنه شتون نلري.
    ///
    /// که چېرې آخذه NaN نه وي ، نو بیا د پوربلټيټي اندېښنه نشته.
    ///
    /// که تاسو د سیګنالي کیدو په اړه پاملرنه نه کوئ (ډیر احتمال) ، نو د پور وړتیا هیڅ اندیښنه شتون نلري.
    ///
    /// په یاد ولرئ چې دا فنکشن د `as` کاسټینګ څخه توپیر لري ، کوم چې د *شمیره* ارزښت ساتلو هڅه کوي ، او نه د بټیوز ارزښت.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // خوندي: `u32` یو پخوانی زوړ ډاټا دی نو موږ کولی شو تل له دې څخه لیږد کړو
        // دا د sNaN سره د خوندیتوب مسلې له پامه غورځیدلې وې!هورۍ!
        unsafe { mem::transmute(v) }
    }

    /// د دې ورو روان ټکي شمیره د حافظې نمایندګي په لوی-اډیان (network) بایټ ترتیب کې د بایټ صف په توګه بیرته راستانه کړئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// د فلوینګ پوینټ شمیره د یاد نمایندګي په بټنیټ بټ ترتیب کې د بایټ صف په توګه راوباسئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// د دې روان ټکي شمیره د یاد نمایش بیس بrayې ترتیب کې د بایټ صف په توګه راوباسئ.
    ///
    /// لکه څنګه چې د موخې پلیټ فارم اصلي پایښت کارول کیږي ، د پورټ وړ کوډ باید [`to_be_bytes`] یا [`to_le_bytes`] وکاروي ، که مناسب وي ، پرځای یې.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// د دې روان ټکي شمیره د یاد نمایش بیس بrayې ترتیب کې د بایټ صف په توګه راوباسئ.
    ///
    ///
    /// [`to_ne_bytes`] هرکله چې امکان ولري باید دې ته لومړیتوب ورکړل شي.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // خوندي: `f32` یو پخوانی زوړ ډاټا دی نو موږ کولی شو تل ورته لیږد کړو
        unsafe { &*(self as *const Self as *const _) }
    }

    /// په لوی اندیان کې د بایټ سرسري په توګه د دې نمایندګي څخه د فلوینګ نقطه ارزښت رامینځته کړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// د هغې نمایندګي څخه د فټینګ پوائنټ ارزښت رامینځته کړئ په کوچنۍ اریانا کې د بایټ سرسري په توګه.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// په اصلي اډیان کې د بایټ سرسري په توګه د هغې له نمایندګۍ څخه د فلوینګ پوائنټ ارزښت رامینځته کړئ.
    ///
    /// لکه څنګه چې د پلیټ فارم اصلي پایښت کارول کیږي ، د پورټ وړ کوډ احتمال غواړي د [`from_be_bytes`] یا [`from_le_bytes`] وکاروي ، مناسب پرځای یې مناسب وي.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// د ځان او نورو ارزښتونو تر مینځ ترتیب راوګرځي.
    /// د فلوټینګ پوائنټ شمیرو تر مینځ د معیاري جزوي پرتله کولو برخلاف ، دا پرتله کول تل د ټیټ آرډر وړاندوینې سره سم ترتیب ترتیب کوي لکه څنګه چې د IEEE 754 (د 2008 بیاکتنه) د فلوټینګ پوائنټ معیار کې تعریف شوی.
    /// ارزښتونه په لاندې ترتیب سره ترتیب شوي:
    /// - منفي خاموش
    /// - منفي سيګنال
    /// - منفي انفلاسیون
    /// - منفي شمیرې
    /// - sub subn malnnor mal numbers numbers.
    /// - منفي صفر
    /// - مثبت صفر
    /// - مثبت غیر معمولي شمیرې
    /// - مثبتې شمېرې
    /// - مثبت انفلاسیون
    /// - مثبت سيګنال
    /// - مثبت خاموش NN
    ///
    /// په یاد ولرئ چې دا فنکشن تل د X001 X او [`PartialEq`] تطبیق سره موافق نه دی.په ځانګړي توګه ، دوی منفي او مثبت صفر ته مساوي ګ regardي ، پداسې حال کې چې `total_cmp` نه کوي.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // د منفي قضیو په حالت کې ، د نښه بشپړ کولو پرته ټولې ټوټې فلپ کړئ ترڅو د ورته دوه بشپړونکي انډیجرونو په څیر ورته ترتیب ترلاسه کړئ
        //
        // ولې دا کار کوي؟د IEEE 754 فلوټونه درې ساحې لري:
        // لاسلیک بټ ، توزیع کونکی او مانټیسټا.د مجموعي په توګه د توضیحي او مینټیسسا ساحو سیټ ملکیت لري چې د دوی د خوا خوا ترتیب د شمیرو عرض سره مساوي دی چیرې چې عرض ټاکل شوی دی.
        // شدت په نورمال ډول د NaN ارزښتونو باندې ندی تعریف شوی ، مګر IEEE 754 TotalOrder د NN ارزښتونه هم تعریف کوي ترڅو د بټوایس ترتیب تعقیب کړي.دا د ډیسک په نظر کې د توضیح شوي حکم لامل کیږي.
        // په هرصورت ، د پراخه استازیتوب د منفي او مثبت شمیر لپاره ورته دی-یوازې د نښه بټ توپیر لري.
        // د لاسلیک شوي انډیجرونو په توګه په اسانۍ سره فلوټونه پرتله کولو لپاره ، موږ اړتیا لرو د منفي شمیرو په حالت کې د توضیح کونکي او مینټیسا بیټونه فلیپ کړو.
        // موږ په مؤثره توګه شمیرې د "two's complement" ب formه ته واړوو.
        //
        // د فلش کولو لپاره ، موږ د دې په مقابل کې ماسک او XOR جوړوو.
        // موږ په منطقي توګه د منفي لاسلیک شوي ارزښتونو څخه د "all-ones except for the sign bit" ماسک محاسبه کوو: د سم شفټ کولو نښه بشپړوي ، نو موږ ماسک د نښه بټونو سره "fill" کوو ، او بیا یې لاسلیک شوی ته بدل کوو ترڅو یو بل صفر بیټ ته فشار ورکړي.
        //
        // په مثبت ارزښتونو باندې ، ماسک ټول صفر دي ، نو دا هیڅ انتخاب نه کوي.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// یو ټاکل شوې وقفې ته ارزښت محدود کړئ مګر دا چې NaN وي.
    ///
    /// که `self` د `max` څخه لوی وي `max` ، او `min` بیرته راوړي که `self` د `min` څخه کم وي.
    /// نور نو دا `self` راستنوي.
    ///
    /// په یاد ولرئ چې دا فعالیت NaN بیرته راګرځوي که ابتدايي ارزښت یې هم NaN و.
    ///
    /// # Panics
    ///
    /// Panics که `min > max` ، `min` NaN دی ، یا `max` NaN دی.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}