//! د 32-بټ نه لاسلیک شوي انډیجر ډول لپاره ثابتونه.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! نوی کوډ باید اړونده ثابتول په مستقیم ډول په لومړني ډول کې وکاروي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }