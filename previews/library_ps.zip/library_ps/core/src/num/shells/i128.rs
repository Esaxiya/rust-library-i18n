//! د 128 بټ لاسلیک شوي انډیجر ډول لپاره ثابتونه.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! نوی کوډ باید اړونده ثابتول په مستقیم ډول په لومړني ډول کې وکاروي.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }