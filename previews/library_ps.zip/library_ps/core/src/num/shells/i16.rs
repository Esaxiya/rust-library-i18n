//! د 16-بټ لاسلیک شوي بشپړ ډول لپاره مستقل.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! نوی کوډ باید اړونده ثابتول په مستقیم ډول په لومړني ډول کې وکاروي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }