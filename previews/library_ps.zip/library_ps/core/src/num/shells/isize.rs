//! د نښې-اندازې لاسلیک شوي بشپړ کونکي ډول لپاره مستقل.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! نوی کوډ باید اړونده ثابتول په مستقیم ډول په لومړني ډول کې وکاروي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }