//! د 8 بټ نه لاسلیک شوي انډي ډول لپاره مستقل.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! نوی کوډ باید اړونده ثابتول په مستقیم ډول په لومړني ډول کې وکاروي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }