//! انفرادي برخو او تیروتنو لړیو کې د تیر شوي ټکي ارزښت ډکوډ کړئ.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// بې کوډ شوی لاسلیک شوی محدود ارزښت ، داسې چې:
///
/// - اصلي ارزښت د `mant * 2^exp` سره مساوي دی.
///
/// - له `(mant - minus)*2^exp` څخه `(mant + plus)* 2^exp` ته هره شمیره به اصلي ارزښت ته ورسیږي.
/// سلسله یوازې پکې شامله ده کله چې `inclusive` `true` وي.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// aled The... mant mant mantississ
    pub mant: u64,
    /// د ټیټ خطا اندازه
    pub minus: u64,
    /// د پورتنۍ تېروتنې سلسله.
    pub plus: u64,
    /// په بیس 2 کې شریک شوی برخه لرونکی.
    pub exp: i16,
    /// ریښتیا کله چې د خطا اندازه پکې شامله وي.
    ///
    /// په IEEE 754 کې ، دا ریښتیا ده کله چې اصلي مینټیسه هم وه.
    pub inclusive: bool,
}

/// بې کوډ شوي ارزښت.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// نیمګړتیاوې ، که مثبت یا منفي.
    Infinite,
    /// صفر ، که مثبت یا منفي.
    Zero,
    /// د نورو ډکوډ شوي ساحو سره محدود شمیرې.
    Finite(Decoded),
}

/// د روانې ټکي ډول چې `بې کوډه کېدی شي.
pub trait DecodableFloat: RawFloat + Copy {
    /// لږترلږه مثبت نورمال شوي ارزښت.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// د ورکړل شوي فلوټینګ شمیره څخه نښه (ریښتیا کله منفي) او `FullDecoded` ارزښت بیرته راشي.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // ګاونډیان: (مانټ ،، ، ختم)-(مانټ ، ختم)-(مانټ + 2 ، ختم)
            // Float::integer_decode تل توزیع کوونکی ساتي ، نو مانټیسسا د فرعي نورمونو لپاره اندازه شوی.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // ګاونډیان: (اعظمي ، Exp ، 1)-(minnormmant ، Exp)-(minnormmant + 1 ، Exp)
                // چیرته چې maxmant=minnormmant * 2 ، 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // ګاونډیان: (مانټ ،، ، ختم)-(مانټ ، ختم)-(مانټ + 1 ، ختم)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}