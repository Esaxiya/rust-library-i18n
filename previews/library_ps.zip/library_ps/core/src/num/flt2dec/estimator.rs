//! د اټکلی اټکل کونکی.

/// `k_0` داسې وموندئ چې `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// دا نږدې `k = ceil(log_10 (mant * 2^exp))` کارول کیږي؛
/// ریښتیني `k` یا `k_0` یا `k_0+1` دی.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbit-1) <مين <<2 bits nbit که مينټ> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) نو له دې امله دا تل تخریب کیږي (یا دقیق دی) ، مګر ډیر نه.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}