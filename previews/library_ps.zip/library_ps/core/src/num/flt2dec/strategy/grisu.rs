//! د Grisu3 الګوریتم Rust موافقت په "ګړندیو سره ګړندي او دقیقه د چاپ کولو" کې توضیح شوی [^ 1].
//! دا د شاوخوا 1KB لخته جدول کاروي ، او په پایله کې ، دا د ډیری معلوماتو لپاره خورا ګړندی دی.
//!
//! [^1]: Florian لوټسچ.2010. د فلوټینګ-پواینټونو ګړندۍ چاپول او
//!   دقیقا دقیقو سره.سیپلن نه.45 ، 6 (جون 2010) ، 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// د بیان لپاره په `format_shortest_opt` کې نظرونه وګورئ.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i؛e=4* i ، 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (ف ، ای ، ک)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// ورکړل شوی `x > 0` ، `(k, 10^k)` داسې بیرته ورکوي لکه `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// د ګریسو لپاره لنډه وضعیت پلي کول.
///
/// دا `None` بیرته راګرځوي کله چې دا به غیرمستقیم نمایندګۍ بیرته راګرځي.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // موږ لږترلږه درې ټوټې اضافي دقیقیت ته اړتیا لرو

    // د شریک شوي ځانګړي کونکي سره نورمال شوي ارزښتونو سره پیل کړئ
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // کوم `cached = 10^minusk` ومومئ لکه `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // ځکه چې `plus` نورمال دی ، نو دا د `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` معنی لري؛
    // زموږ د `ALPHA` او `GAMMA` انتخابونو ته په پام سره ، دا `plus * cached` په `[4, 2^32)` کې اچوي.
    //
    // دا څرګند دی چې د `GAMMA - ALPHA` اعظمي کولو لپاره مطلوب دی ، نو له همدې امله موږ د 10 ډیری ډیرو قدرتونو ته اړتیا نلرو ، مګر ځینې ملاحظات شتون لري:
    //
    //
    // 1. موږ غواړو `floor(plus * cached)` په `u32` کې وساتو ځکه چې دا قیمتي برخې ته اړتیا لري.
    //    (دا واقعیا د مخنیوي وړ ندي ، پاتې د دقت د اندازې لپاره اړین دي.)
    // 2.
    // د `floor(plus * cached)` پاتې برخه په مکرر ډول د 10 لخوا ضرب کیږي ، او دا باید جریان ونه کړي.
    //
    // لومړي `64 + GAMMA <= 32` ورکوي ، پداسې حال کې چې دوهم `10 * 2^-ALPHA <= 2^64` ورکوي؛
    // -60 او -32 د دې محدودیت سره اعظمي حد دی ، او V8 هم دوی کاروي.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // د پیمان fps.دا د 1 ulp اعظمي غلطي وړاندې کوي (د تیوریم 5.1 څخه ثابت شوی).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-د منفي اصل حد
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // د `minus` ، `v` او `plus` پورته *مقدار* اټکل شوي (خطا <1 ulp) دي.
    // لکه څنګه چې موږ نه پوهیږو چې خطا مثبت یا منفي ده ، موږ دوه اټکلونه په مساوي توګه ځای په ځای کوو او د 2 ulps اعظمي غلطي لرو.
    //
    // "unsafe region" یو لیبرال وقفه ده چې موږ یې په پیل کې پیدا کوو.
    // "safe region" محافظه کاره وقفه ده چې موږ یې یوازې منو.
    // موږ په ناامنه سیمه کې د سم ریپر سره پیل کوو ، او هڅه کوو چې `v` ته ترټولو نږدې ریپر ومومئ کوم چې په خوندي سیمه کې هم دی.
    // که موږ نشو کولی موږ یې پریږدو.
    //
    let plus1 = plus.f + 1;
    // پرېږدئ plus0 = plus.f ، 1؛//یوازې د تشریح لپاره پریږدئ minus0 = minus.f + 1؛//یوازې د وضاحت لپاره
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // شریک شوی برخه

    // `plus1` په متقابل او جلا برخو کې وویشئ.
    // لازمې برخې په u32 کې د فټ کولو تضمین دي ، ځکه چې زیرمه شوي ځواک د `plus < 2^32` تضمین کوي او نورمال شوي `plus.f` تل د دقیقت د اړتیا له امله د `2^64 - 2^4` څخه کم دی.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ترټولو لوی `10^max_kappa` محاسبه کړئ له `plus1` (په دې ډول `plus1 < 10^(max_kappa+1)`) نه.
    // دا لاندې د `kappa` لوړ حد دی.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // تیوریم 6.2: که `k` ترټولو لوی لوی عدد دی
    // `0 <= y mod 10^k <= y - x`,              بیا نو `V = floor(y / 10^k) * 10^k` په `[x, y]` کې دی او یو له لنډ نمایندګۍ څخه (د پام وړ ډیرو لږترلږه شمیر سره) پدې حد کې.
    //
    //
    // د `(minus1, plus1)` تر مینځ د تیوریم 6.2 تر مینځ د `kappa` عددي اوږدوالی ومومئ.
    // د تیوریم 6.2 د `y mod 10^k < y - x` جلا کولو لپاره د دې پرځای د `y mod 10^k < y - x` غوښتنه کولو لپاره اختیار کیدلی شي.
    // (د مثال په توګه ، `x` =32000 ، `y` =32777 X `kappa` =2 وروسته له `y Mod 10 ^ 3=777 <y ، x=777`.) الګوریتم د `y` د ایستلو لپاره وروسته تایید مرحلې پورې اړه لري.
    //
    let delta1 = plus1 - minus1;
    // پریږدئ delta1int=(delta1>> e) لکه څنګه چې کارول کیږي؛//یوازې د وضاحت لپاره
    let delta1frac = delta1 & ((1 << e) - 1);

    // اړونده برخې وړاندې کړئ ، پداسې حال کې چې په هر ګام کې د دقت لپاره ګورئ.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ګsې تر اوسه پورې ندي ورکړل شوي
    loop {
        // موږ تل د راکړې ورکړې لپاره لږترلږه یو ډیجیټل لرو ، لکه د `plus1 >= 10^kappa` بریدګرو:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (دا تعقیبوي چې `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // د `remainder` لخوا د `remainder` ویشل.دواړه د `2^-e` لخوا اندازه شوي.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1٪ 10 ^ کاپا) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; موږ سم `kappa` وموند.
            let ten_kappa = (ten_kappa as u64) << e; // 10 ^ کاپا د شریک برخې ته بیرته ستن کړئ
            return round_and_weed(
                // حفاظت: موږ دا یادداشت په پورتنی پیل وکړ.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // لوپ مات کړئ کله چې موږ ټول بشپړ ګsې وړاندې کړې.
        // د شمیرو دقیقه شمیره د `plus1 < 10^(max_kappa+1)` په توګه `max_kappa + 1` ده.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // بلواګر راوګرځول
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // مختلفې برخې وړاندې کړئ ، پداسې حال کې چې په هر مرحله کې د دقت لپاره ګورئ.
    // دا وخت موږ په تکراري ضربونو تکیه کوو ، ځکه چې تقسیم به دقیقا له لاسه ورکړي.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // راتلونکی ګ digitه باید د پام وړ وي ځکه چې موږ ازموینه کړې چې د اشغالګرو ماتولو دمخه ، چیرې چې `m = max_kappa + 1` (په انډول برخه کې د شمیرو شمیره):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ډیر وران به نه شی ، `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // د X001 لخوا `remainder` ویشل.
        // دواړه د `2^e / 10^kappa` لخوا اندازه شوي ، نو وروستی یې دلته ضمیمه دی.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ضمیمه کونکی
            return round_and_weed(
                // حفاظت: موږ دا یادداشت په پورتنی پیل وکړ.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // بلواګر راوګرځول
        kappa -= 1;
        remainder = r;
    }

    // موږ د `plus1` ټول پام وړ ډیجیټونه تولید کړي ، مګر ډاډه نه یو چې دا مطلوب دی.
    // د مثال په توګه ، که `minus1` 3.14153 وي ... او `plus1` 3.14158 وي ... نو د 3.14154 څخه 3.14158 ته 5 مختلف لنډ وړاندیزونه شتون لري مګر موږ یوازې ترټولو لوی یو لرو.
    // موږ باید په بریالیتوب سره وروستي ګ decreaseه راټیټ کړو او وګورو چې ایا دا غوره ریپرټ دی.
    // لږ تر لږه 9 کاندیدان شتون لري (..1 تر ..9) ، نو دا خورا ګړندۍ ده.(د "rounding" مرحله)
    //
    // فنکشن ګوري که چیرې دا "optimal" repr په حقیقت کې د ulp حدود کې وي ، او هم ، دا امکان لري چې د "second-to-optimal" ریپر واقعیا د ګردي خطا له امله مناسب وي.
    // په دواړو مواردو کې دا `None` راستنوي.
    // (د "weeding" مرحله)
    //
    // دلته ټول دلیلونه د عمومي (مګر ضمني) ارزښت `k` لخوا اندازه شوي ، نو له همدې امله:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (او هم ، `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (او همدارنګه ، د مخکیني بریدګرو لخوا `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // په `v` x کې دننه دوه اټکلونه (په حقیقت کې `plus1 - v`) تولید کړئ.
        // پایله لرونکی نمایش باید دواړه ته نږدې استازیتوب وي.
        //
        // دلته `plus1 - v` کارول کیږي ځکه چې محاسبې د `plus1` په درناوي سره ترسره کیږي ترڅو د overflow/underflow څخه مخنیوی وشي (له همدې امله ښکاري ښکاري نومونه).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v، 1 اول)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 اولپ)

        // وروستی ګ digitه کم کړئ او د `v + 1 ulp` ته نږدې نماینده کې ودروئ.
        let mut plus1w = remainder; // plus1w(n) = plus1 ، w(n)
        {
            let last = buf.last_mut().unwrap();

            // موږ د نږدې شمیرې `w(n)` سره کار کوو ، کوم چې په پیل کې د `plus1 - plus1 % 10^kappa` سره مساوي دی.د لوپ باډي `n` ځل چليدو وروسته ، `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // موږ د چک ساده کولو لپاره `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (په دې ډول پاتې= plus1w(0)`)) ټاکلی.
            // په یاد ولرئ چې `plus1w(n)` تل وده کوي.
            //
            // موږ د پای ته رسولو لپاره درې شرایط لرو.د دوی هر یو به لوپ د پرمختګ مخه ونیسي ، مګر بیا موږ لږترلږه یو معتبر نمایندګي ولرو چې په هرصورت `v + 1 ulp` ته نږدې پیژندل شوي.
            // موږ به دوی د TC3 له لارې د بریالي کیدو لپاره د TC1 په توګه معرفي کړو.
            //
            // TC1: `w(n) <= v + 1 ulp` ، د مثال په توګه ، دا وروستی ریپرس دی چې کیدی شي نږدې وي.
            // دا د `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` سره مساوي دی.
            // د TC2 سره یوځای شوی (کوم چې چیک کوي که `w(n+1)` is valid) ، دا د `plus1w(n)` محاسبه کې احتمالي جریان مخه نیسي.
            //
            // TC2: `w(n+1) < minus1` ، د مثال په توګه ، راتلونکی ریپر د `v` سره نه خنډ کیږي.
            // دا د `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` سره مساوي دی.
            // د کی hand لاس اړخ کولی شي جریان وکړي ، مګر موږ پوهیږو `threshold > plus1v` ، نو که TC1 غلط وي ، `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` او موږ کولی شو په خوندي ډول ازموینه وکړو که `threshold - plus1w(n) < 10^kappa` پرځای.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))` ، د مثال په توګه ، بل ریپر دی
            // د اوسني repr په پرتله `v + 1 ulp` ته نږدې ندی.
            // ورکړل شوی `z(n) = plus1v_up - plus1w(n)` ، دا `abs(z(n)) <= abs(z(n+1))` کیږي.بیا په دې ګومان چې TC1 غلط دی ، موږ `z(n) > 0` لرو.موږ دوه قضیې لرو چې غور پرې کوو:
            //
            // - کله چې `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)` شي.
            // لکه څنګه چې `plus1w(n)` وده کوي ، `z(n)` باید کم شي او دا په ښکاره ډول غلط دی.
            // - کله چې `z(n+1) < 0`:
            //   - TC3a: مخکیني شرط د `plus1v_up < plus1w(n) + 10^kappa` دی.د TC2 فرض کول غلط دي ، `threshold >= plus1w(n) + 10^kappa` نو دا به جریان نشي.
            //   - TC3b: TC3 `z(n) <= -z(n+1)` کیږي ، د مثال په توګه ، `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   غفلت شوی TC1 `plus1v_up > plus1w(n)` ورکوي ، نو دا نشي جریان کولی یا جریان شي کله چې د TC3a سره یوځای شي.
            //
            // په پایله کې ، موږ باید ودروو کله چې `TC1 || TC2 || (TC3a && TC3b)`.لاندې د هغې سرسري سره مساوي دی ، `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ترټولو لنډ ریپر د `0` سره ختم نشي
                plus1w += ten_kappa;
            }
        }

        // وګورئ چې ایا دا نمایندګي هم د `v - 1 ulp` ته نږدې نماینده ده.
        //
        // دا په ساده ډول د `v + 1 ulp` لپاره ختمیدونکي شرایطو سره ورته دی ، د `plus1v_down` پرځای ټول `plus1v_up` سره.
        // د ډیر جریان تحلیل په مساوي ډول لري.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // اوس موږ د `plus1` او `minus1` تر مینځ `v` ته نږدې نمایندګي لرو.
        // دا خورا لیبرال دی ، که څه هم ، نو موږ کوم `w(n)` رد کوو د `plus0` او `minus0` تر مینځ ندی ، د مثال په توګه ، `plus1 - plus1w(n) <= minus0` یا `plus1 - plus1w(n) >= plus0`.
        // موږ هغه حقایق کاروو چې `threshold = plus1 - minus1` او `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// د ډریگن فال بیک سره د ګریسو لپاره د لنډ وضعیت پلي کول.
///
/// دا باید د ډیری قضیو لپاره وکارول شي.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // خوندي: د پور چیکر دومره هوښیار ندي چې موږ ته اجازه راکړئ `buf` وکاروو
    // په دوهم branch کې ، نو موږ دلته د ژوند شراکت کوو.
    // مګر موږ یوازې `buf` بیا کاروو که `format_shortest_opt` `None` بیرته راستنوي نو دا سمه ده.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// د ګریسو لپاره دقیق او ثابت حالت پلي کول.
///
/// دا `None` بیرته راګرځوي کله چې دا به غیرمستقیم نمایندګۍ بیرته راګرځي.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // موږ لږترلږه درې ټوټې اضافي دقیقیت ته اړتیا لرو
    assert!(!buf.is_empty());

    // نورمال کول او د `v` اندازه کول.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` په متقابل او جلا برخو کې وویشئ.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // دواړه زاړه `v` او نوي `v` (د `10^-k` لخوا اندازه شوی) د <1 ulp (تیوریم 5.1) تېروتنه لري.
    // لکه څنګه چې موږ نه پوهیږو چې اشتباه مثبت یا منفي ده ، موږ دوه اټکلونه په مساوي ډول سره ځای په ځای کوو او د 2 ulps اعظمي غلطي لرو (د لنډې مودې لپاره ورته).
    //
    //
    // هدف دا دی چې د عددونو دقیق پړاو لړۍ ومومئ چې دواړه د `v - 1 ulp` او `v + 1 ulp` لپاره عام دي ، نو ځکه چې موږ په کلکه باور لرو.
    // که دا ممکن نه وي ، موږ نه پوهیږو کوم یو د `v` لپاره سم محصول دی ، نو موږ یې ورکړو او بیرته سقوط کوو.
    //
    // `err` دلته د `1 ulp * 2^e` په توګه تعریف شوی (په `vfrac` کې ورته ته ورته) ، او موږ به یې اندازه کړو هرکله چې `v` اندازه شي.
    //
    //
    //
    let mut err = 1;

    // ترټولو لوی `10^max_kappa` محاسبه کړئ له `v` (په دې ډول `v < 10^(max_kappa+1)`) نه.
    // دا لاندې د `kappa` لوړ حد دی.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // که موږ د وروستي ګ digitې محدودیت سره کار کوو ، نو موږ اړتیا لرو چې د ریفرډ کولو دمخه بفر لنډ کړو ترڅو د دوه ګوني کیدو مخه ونیسو.
    //
    // په یاد ولرئ چې موږ باید بیا بفر پراخه کړو کله چې ګرځي راټول شي!
    let len = if exp <= limit {
        // اوه ، موږ حتی د *یو* ګ digitی هم نشو تولیدولی.
        // دا امکان لري کله چې ، ووایاست ، موږ د 9.5 په څیر یو څه ترلاسه کړي او دا 10 ته رسیدلی.
        //
        // په اصولو کې موږ سمدلاسه د خالي بفر سره `possibly_round` تلیفون کولی شو ، مګر د 10 لخوا `max_ten_kappa << e` اندازه کول کولی شي د ډیر جریان لامل شي.
        //
        // پدې توګه موږ دلته ضعیف یو او د 10 فاکتور لخوا د خطا اندازه پراخه کوو.
        // دا به غلط منفي کچه لوړه کړي ، مګر یوازې خورا ،*خورا* یو څه؛
        // دا یوازې د پام وړ موضوع کیدی شي کله چې مینټیسسا د 60 ټوټو څخه لوی وي.
        //
        // خوندي: `len=0` ، نو د دې حافظې پیل کولو مکلفیت کوچنی دی.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // اړونده برخې وړاندې کړئ.
    // تېروتنه په بشپړه توګه جلا ده ، نو موږ اړتیا نلرو په دې برخه کې یې وګورو.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ګsې تر اوسه پورې ندي ورکړل شوي
    loop {
        // موږ تل د اشغالګرو کرایه ورکولو لپاره لږترلږه یو ډیجیټل لرو:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (دا تعقیبوي چې `remainder = vint % 10^(kappa+1)`)
        //
        //

        // د `remainder` لخوا د `remainder` ویشل.دواړه د `2^-e` لخوا اندازه شوي.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ایا بفر ډک دی؟راونډینګ پاس د پاتې کیدو سره چل کړئ.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v٪ 10 ^ کاپا) * 2 ^ e
            // خوندي: موږ د `len` ډیری بایټونه پیل کړي.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // لوپ مات کړئ کله چې موږ ټول بشپړ ګsې وړاندې کړې.
        // د شمیرو دقیقه شمیره د `plus1 < 10^(max_kappa+1)` په توګه `max_kappa + 1` ده.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // بلواګر راوګرځول
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // لنډې برخې راکړئ.
    //
    // په اصولو کې موږ کولی شو وروستي موجود ډیجیټ ته دوام ورکړو او د دقت لپاره یې وګورو.
    // بدبختانه موږ د بشپړې اندازې سره کار کوو ، نو موږ د جریان کشف کولو لپاره یو څه معیار ته اړتیا لرو.
    // V8 `remainder > err` کاروي ، کوم چې غلط کیږي کله چې د `v - 1 ulp` او `v` لومړني `i` پام وړ ټکي توپیر ولري.
    // په هرصورت دا خورا ډیر نور غیر معتبر پیوستون ردوي.
    //
    // وروسته له دې چې وروستی مرحله د اتفایې درست توضیحات لري ، نو موږ یې پرځای سخت معیارونه کاروو:
    // موږ دوام ورکوو `err` د `10^kappa / 2` څخه زیات ، نو د `v - 1 ulp` او `v + 1 ulp` تر منځ حد دقیقا دوه یا ډیر ګردي نمایندګۍ لري.
    //
    // دا د `possibly_round` څخه لومړي دوه پرتله کولو ته ورته دی ، د حوالې لپاره.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // بریدګر ، چیرې چې `m = max_kappa + 1` (په انډول برخه کې د شمیرو شمیره):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ډیر وران به نه شی ، `2^e * 10 < 2^64`
        err *= 10; // ډیر وران به نه شی ، `err * 10 < 2^e * 5 < 2^64`

        // د X001 لخوا `remainder` ویشل.
        // دواړه د `2^e / 10^kappa` لخوا اندازه شوي ، نو وروستی یې دلته ضمیمه دی.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ایا بفر ډک دی؟راونډینګ پاس د پاتې کیدو سره چل کړئ.
        if i == len {
            // خوندي: موږ د `len` ډیری بایټونه پیل کړي.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // بلواګر راوګرځول
        remainder = r;
    }

    // نور محاسبه بې ګټې ده (`possibly_round` په یقین سره ناکام کیږي) ، نو موږ یې ورکړو.
    return None;

    // موږ د `v` ټولې غوښتل شوې ګsې تولید کړې دي ، کوم چې باید د `v - 1 ulp` ورته شمېرو ته ورته وي.
    // اوس موږ ګورو چې ایا د `v - 1 ulp` او `v + 1 ulp` لخوا شریک شوی ځانګړی استازیتوب شتون لري؛دا کیدی شي د تولید شوي ډیجیټونو ته ورته وي ، یا د دې ګ ofو راډون اپ نسخې ته.
    //
    // که چیرې رینج د ورته اوږدوالي ډیری نمایشګانې ولري ، موږ نشو ډاډه کولی او پرځای یې `None` بیرته راستون کړو.
    //
    // دلته ټول دلیلونه د عمومي (مګر ضمني) ارزښت `k` لخوا اندازه شوي ، نو له همدې امله:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // خوندي: د `buf` لومړي `len` بایټ باید پیل شي.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (د حوالې لپاره ، نقطه شوې کرښه په ورکړل شوي ګ digitو کې د ممکنه نمایندګیو لپاره دقیق ارزښت په ګوته کوي.)
        //
        //
        // تېروتنه خورا لوی ده چې د `v - 1 ulp` او `v + 1 ulp` تر منځ لږترلږه درې ممکنه نمایشګانې شتون لري.
        // موږ نشو ویلای چې کوم یو سم دی.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // په حقیقت کې ، د 1/2 ulp د دوه احتمالي نمایندګیو معرفي کولو لپاره کافی دی.
        // (په یاد ولرئ چې موږ د دواړو `v - 1 ulp` او `v + 1 اولپ لپاره ځانګړي نمایندګي ته اړتیا لرو.) دا به جریان نشي ، ځکه چې د لومړي چک څخه `ulp < ten_kappa`.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ کاپا---------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // که چیرې `v + 1 ulp` د ګرد ښکته نمایندګۍ ته نږدې وي (کوم چې دمخه په `buf` کې دی) ، نو بیا موږ په خوندي ډول بیرته راستون شو.
        // په یاد ولرئ چې `v - 1 ulp` * د اوسني نمایش څخه کم کیدی شي ، مګر د `1 ulp < 10^kappa / 2` په توګه ، دا حالت کافي دی:
        // د `v - 1 ulp` او اوسني نمایندګۍ ترمینځ فاصله د `10^kappa / 2` نه زیات نشي.
        //
        // حالت د `remainder + ulp < 10^kappa / 2` سره مساوي دی.
        // له دې چې دا کولی شي په اسانۍ سره ډوب شي ، لومړی چیک کړئ که `remainder < 10^kappa / 2`.
        // موږ لا دمخه تایید کړی چې `ulp < 10^kappa / 2` ، نو ترهغې چې `10^kappa` له هرڅه وروسته ډیر نه وی ، دوهم چیک ښه دی.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // خوندي: زموږ زنګ وهونکي هغه حافظه پیل کړه.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------پاتې------> |:
        //   :                          |   :
        //   : <---------10 ^ کاپا--------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // له بلې خوا ، که `v - 1 ulp` د ټولټاکنو نمایندګیو ته نږدې وي ، موږ باید راټول او بیرته راشو.
        // د ورته دلیل لپاره موږ اړتیا نلرو `v + 1 ulp` چیک کړئ.
        //
        // حالت د `remainder - ulp >= 10^kappa / 2` سره مساوي دی.
        // بیا موږ لومړی چیک کوو که `remainder > ulp` (په یاد ولرئ چې دا `remainder >= ulp` ندی ، ځکه چې `10^kappa` هیڅکله هم صفر ندی).
        //
        // دا هم په یاد ولرئ چې `remainder - ulp <= 10^kappa` ، نو دوهم چک ډیر جریان نلري.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // خوندي: زموږ زنګ وهونکی باید دا حافظه پیل کړي وي.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // یوازې یوه اضافي شمیره اضافه کړئ کله چې زموږ څخه د ټاکل شوي دقیقه غوښتنه وشوه.
                // موږ باید دا هم وګورو چې ، که اصلي بفر خالي و ، اضافي ډیجیټ یوازې هغه وخت اضافه کیدی شي کله چې `exp == limit` (edge قضیه).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // خوندي: موږ او زموږ زنګ وهونکي دا حافظه پیل کړه.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // که نه نو موږ برباد شو (د مثال په توګه د `v - 1 ulp` او `v + 1 ulp` تر مینځ ځینې ارزښتونه په کښته کیدو دي او نور یې سر راپورته کوي) او پریږدو.
        //
        None
    }
}

/// د ډریگن فال بیک سره د ګریسو لپاره دقیق او ثابت حالت پلي کول.
///
/// دا باید د ډیری قضیو لپاره وکارول شي.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // خوندي: د پور چیکر دومره هوښیار ندي چې موږ ته اجازه راکړئ `buf` وکاروو
    // په دوهم branch کې ، نو موږ دلته د ژوند شراکت کوو.
    // مګر موږ یوازې `buf` بیا کاروو که `format_exact_opt` `None` بیرته راستنوي نو دا سمه ده.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}