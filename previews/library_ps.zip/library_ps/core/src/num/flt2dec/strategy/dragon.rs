//! نږدې د مستقیم (مګر یو څه اصلاح شوی) Rust د "چاپ کولو فلوینګ-پوینټ شمیرې په چټکه او دقیق ډول چاپ کړئ" [^ 1].
//!
//!
//! [^1]: Burger, آر جی او ډایبویګ ، RK 1996. د فلوټینګ پوینټونو چاپول
//!   ژر او دقیق.سیپلن نه.31 ، 5 (می. 1996) ، 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// د 10 ^ (2 ^ n) لپاره د `ډیجیټسونو اټکل شوی صفونه
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// یوازې د کارولو وړ کله چې `x < 16 * scale`؛`scaleN` باید `scale.mul_small(N)` وي
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// د ډریگن لپاره ترټولو لنډه وضعیت پلي کول.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // د `v` شمیره ب formatه یې پیژندل کیږي:
    // - د `mant * 2^exp` سره مساوي؛
    // - د اصلي ډول کې د `(mant - 2 *minus)* 2^exp` لخوا وړاندې؛او
    // - په اصل کې د `(mant + 2 *plus)* 2^exp` په تعقیب.
    //
    // په ښکاره ډول ، `minus` او `plus` صفر نشي.(د انفلاسیون لپاره ، موږ د پراخه کچې ارزښتونه کاروو.) موږ دا هم ګumeو چې لږترلږه یو ګ digitی تولید شوی دی ، د مثال په توګه ،`minus` هم صفر نشی کیدی.
    //
    // دا د دې معنی هم لري چې د `low = (mant - minus)*2^exp` او `high = (mant + plus)* 2^exp` تر مینځ کوم شمیر به دې دقیق فلوټینګ شمیره ته نقشه ورکړي ، د حدونو سره به شامل وي کله چې اصلي مینټیسه حتی (د مثال په توګه ، `!mant_was_odd`) وه.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` دا `if d.inclusive {a <= b} else {a < b}` دی
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // د X0 `k_0` اټکل د اصلي معلوماتو څخه د اطمینان وړ `10^(k_0-1) < high <= 10^(k_0+1)`.
    // کلک تړلی `k` د رضایت وړ `10^(k-1) < high <= 10^k` وروسته محاسبه کیږي.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` په جلا جلا ب intoه کې بدل کړئ ترڅو چې:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // د `mant` لخوا د `mant` ویشل.اوس `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // د تنظیم کله چې `mant + plus > scale` (یا `>=`).
    // موږ واقعیا د `scale` تغیر نه کوو ، ځکه چې موږ کولی شو پرځای یې لومړني ضرب له لاسه ورکړو.
    // اوس `scale < mant + plus <= scale * 10` او موږ د ګ .و تولید لپاره چمتو یو.
    //
    // په یاد ولرئ چې `d[0]`*کیدی شي* صفر وي ، کله چې `scale - plus < mant < scale`.
    // پدې حالت کې د راټولولو حالت (لاندې `up`) به سمدستي پیل شي.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // د 10 لخوا `scale` اندازه کولو سره مساوي
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // د ډیجیټ نسل لپاره کیچ ایکس00 ایکس.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // بریدګر ، چیرې چې `d[0..n-1]` تردې دمه ګsې تولید شوي:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (پدې توګه `mant / scale < 10`) چیرې چې `d[i..j]` د `d [i] * 10 ^ (جي) لپاره لنډ لنډ دی + ...
        // + d [j-1] * 10 + d[j]`.

        // یوه ګ digitه تولید کړئ: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // دا د ترمیم شوي ډریگن الګوریتم ساده توضیح دی.
        // ډیری منځګړیتوب او بشپړ استدلال د اسانتیا لپاره له لاسه ورکړل شوي.
        //
        // د بدل شوي اشغالګرو سره پیل کړئ ، لکه څنګه چې موږ `n` تازه کړی:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // فرض کړئ چې `d[0..n-1]` د `low` او `high` تر مینځ لنډه نمایندګي ده ، د مثال په توګه ، `d[0..n-1]` دواړه دواړه مطمئن کوي مګر `d[0..n-2]` یې نه کوي:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: تر `v` پورې ګsې)؛او
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (وروستۍ ګ digitه سمه ده).
        //
        // دوهم حالت `2 * mant <= scale` ته ساده کوي.
        // د `mant` ، `low` او `high` په شرایطو کې د اشغالګرو حل کول د لومړي حالت ساده نسخه ترلاسه کوي: `-plus < mant < minus`.
        // د `-plus < 0 <= mant` راهیسې ، موږ سم لنډه لنډه نمایندګي لرو کله چې `mant < minus` او `2 * mant <= scale`.
        // (پخوانی `mant <= minus` کیږي کله چې اصلي مینټیسه هم وي.)
        //
        // کله چې دوهم (`2 * مينټ> سکیل`) ونه لري ، موږ اړتیا لرو چې وروستۍ ګ digitه زیاته کړو.
        // دا د دې حالت بیرته راګرځولو لپاره کافی دی: موږ دمخه پوهیږو چې د ډیجیټ نسل `0 <= v / 10^(k-n) - d[0..n-1] < 1` تضمین کوي.
        // پدې حالت کې ، لومړی حالت `-plus < mant - scale < minus` کیږي.
        // له نسل وروسته د `mant < scale` راهیسې ، موږ `scale < mant + plus` لرو.
        // (بیا ، دا `scale <= mant + plus` کیږي کله چې اصلي مینټیسه حتی وي.)
        //
        // په لنډه کښی:
        // - د `down` ودروئ او ګرد کړئ (ګ digitه په هغه ډول وساتئ) کله چې `mant < minus` (یا `<=`).
        // - د `up` ودروئ او ګرد کړئ (وروستۍ ګ digitه زیاته کړئ) کله چې `scale < mant + plus` (یا `<=`).
        // - په بل ډول تولید ته دوام ورکوئ.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // موږ لږترلږه نمایندګي لرو ، پړاو ته لاړو

        // بریدګر بیرته راوګرځوئ.
        // دا د الګوریتم تل پای ته رسوي: `minus` او `plus` تل وده کوي ، مګر `mant` کلپ شوی موډلو `scale` دی او `scale` ټاکل شوي.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // راډینګنګ پیښیږي کله چې i) یوازې د راډینګ اپ حالت رامینځته شوی و ، یا ii) دواړه شرایط رامینځته شوي او د ماتولو ترجیح د راونډ اپ کولو ترجیح ورکوي.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // که چیرې راډک کول اوږدوالي ته تغیر ورکړي ، توضیحي باید هم بدل شي.
        // داسې بریښي چې دا شرایط پوره کول خورا سخت دي (احتمالي ناشونې) ، مګر موږ دلته خوندي او مستقل یو.
        //
        // حفاظت: موږ دا یادداشت په پورتنی پیل وکړ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // حفاظت: موږ دا یادداشت په پورتنی پیل وکړ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// د ډریگن لپاره دقیق او ثابت حالت پلي کول.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // د X0 `k_0` اټکل د اصلي معلوماتو څخه د اطمینان وړ `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // د `mant` لخوا د `mant` ویشل.اوس `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // د تنظیم کله چې `mant + plus >= scale` ، چیرته `plus / scale = 10^-buf.len() / 2`.
    // د ترتیب شوي اندازې bignum ساتلو لپاره ، موږ واقعیا `mant + floor(plus) >= scale` کاروو.
    // موږ واقعیا د `scale` تغیر نه کوو ، ځکه چې موږ کولی شو پرځای یې لومړني ضرب له لاسه ورکړو.
    // بیا د لنډې الګوریتم سره ، `d[0]` کیدی شي صفر وي مګر په پای کې به راټولو شي.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // د 10 لخوا `scale` اندازه کولو سره مساوي
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // که موږ د وروستي ګ digitې محدودیت سره کار کوو ، نو موږ اړتیا لرو چې د ریفرډ کولو دمخه بفر لنډ کړو ترڅو د دوه ګوني کیدو مخه ونیسو.
    //
    // په یاد ولرئ چې موږ باید بیا بفر پراخه کړو کله چې ګرځي راټول شي!
    let mut len = if k < limit {
        // اوه ، موږ حتی د *یو* ګ digitی هم نشو تولیدولی.
        // دا امکان لري کله چې ، ووایاست ، موږ د 9.5 په څیر یو څه ترلاسه کړي او دا 10 ته رسیدلی.
        // موږ د وروسته نیمګړتیا قضیې په استثنا سره یو خالي بفر بیرته راوړو چې هغه وخت پیښیږي کله چې `k == limit` وي او باید یو عدد تولید شي.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // د ډیجیټ نسل لپاره کیچ ایکس00 ایکس.
        // (دا کیدی شي ګران وي ، نو کله چې بفر خالي وي نو دوی محاسبه مه کوئ.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // لاندې ګ digitي ټول صفر دي ، موږ دلته ودروو *د* کولو هڅه مه کوئ!پرځای یې ، پاتې ټکي ډک کړئ.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // حفاظت: موږ دا یادداشت په پورتنی پیل وکړ.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // راډنګ کول که چیرې موږ د عددونو په مینځ کې ودروو که چیرې لاندې ګ digitې په سمه توګه 5000 وي ... نو مخکینۍ ګ digitه وګ checkئ او هڅه وکړئ حتی یو څه ته هم ورشئ (د بیلګې په توګه ، کله چې پخوانۍ ګ digitه هم مساوي وي) له ګردولو څخه مخنیوی وکړئ.
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // خوندي: `buf[len-1]` پیل شوی.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // که چیرې راډک کول اوږدوالي ته تغیر ورکړي ، توضیحي باید هم بدل شي.
        // مګر زموږ څخه غوښتنه شوې چې د شمیرې د ثابت شمیرو غوښتنه وشي ، نو د بفر مه بدلوئ ...
        // حفاظت: موږ دا یادداشت په پورتنی پیل وکړ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... پرته لدې چې د دې پرځای موږ دقیق دقیقه غوښتنه شوې نه وي.
            // موږ باید دا هم وګورو چې ، که اصلي بفر خالي و ، اضافي ډیجیټ یوازې هغه وخت اضافه کیدی شي کله چې `k == limit` (edge قضیه).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // حفاظت: موږ دا یادداشت په پورتنی پیل وکړ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}