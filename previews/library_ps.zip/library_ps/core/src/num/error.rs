//! انضمام ډولونو ته د بدلون لپاره د خطو ډولونه.

use crate::convert::Infallible;
use crate::fmt;

/// د خطا ډول بیرته راګرځیدلی کله چې د چیک شوي انډول ډول ډول تبادلې ناکام شي.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // د فشار پرځای میچ وکړئ ترڅو ډاډ ترلاسه کړئ چې پورته `From<Infallible> for TryFromIntError` کوډ کار کوي کله چې `Infallible` د `!` لپاره یو عرف شي.
        //
        //
        match never {}
    }
}

/// یوه خطا چې بیرته راستنیدل کیدی شي کله چې د عدد پارس کول.
///
/// دا خطا د `from_str_radix()` افعال لپاره د پخوانۍ انټژیر ډولونو لکه [`i8::from_str_radix`] په توګه د غلط ډول لپاره کارول کیږي.
///
/// # احتمالي لاملونه
///
/// د نورو دلیلونو په منځ کې ، `ParseIntError` کیدی شي د تار یا مخکینۍ سپین ځای له امله وغورځول شي ، لکه کله چې دا د معیاري آخذه څخه ترلاسه کیږي.
///
/// د [`str::trim()`] میتود کارول ډاډ ترلاسه کوي چې د سپینولو دمخه هیڅ سپینه سپینه نه پاتې کیږي.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// د مختلف ډوله غلطیو ذخیره کولو لپاره هینوم چې کولی شي د عدد پارس کولو لامل شي.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// د تجزیې ارزښت خالي دی.
    ///
    /// د نورو دلیلونو په مینځ کې ، دا ډول به رامینځته شي کله چې د خالي تار پارس کول.
    Empty,
    /// په دې حالت کې یو ناباوره ټکی لري.
    ///
    /// د نورو دلیلونو په مینځ کې ، دا ډول به رامینځته شي کله چې د تار تثبیت کول چې پکې غیر ASCII چارټ شامل وي.
    ///
    /// دا ډول هم رامینځته کیږي کله چې `+` یا `-` د تار په مینځ کې ځای په ځای شوی یا پخپله یا د شمیرو په مینځ کې.
    ///
    ///
    InvalidDigit,
    /// انټجیر خورا لوی دی چې د هدف بشپړ ډول کې زیرمه کړي.
    PosOverflow,
    /// انټرجیر خورا کوچنی دی چې په نښه شوي انډیجر ډول کې وساتل شي.
    NegOverflow,
    /// ارزښت صفر و
    ///
    /// دا ډول به خارج شي کله چې د جلا کولو تار د صفر ارزښت لري ، کوم چې د غیر صفر ډولونو لپاره غیرقانوني وي.
    ///
    Zero,
}

impl ParseIntError {
    /// د بشپړ انډول پاتې کیدو تفصیلي لامل راووځي.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}