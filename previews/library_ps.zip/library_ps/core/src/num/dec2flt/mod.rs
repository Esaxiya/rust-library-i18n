//! د لسیز تارونه د آی ای ای 754 بائنری فلوټینګ پوائنټونو ته اړول.
//!
//! # ستونزه بیان
//!
//! موږ ته د لسیزې تار ورکول کیږي لکه `12.34e56`.
//! دا سلسله لازم (`12`) ، متناسب (`34`) ، او توضیحي (`56`) برخې لري.ټولې برخې اختیاري دي او د صفر په توګه تشریح کیږي کله چې ورک شي.
//!
//! موږ د IEEE 754 فلوینګ پوینټ شمیره په لټه کې یو چې د لسیزې سټینګ دقیق ارزښت سره نږدې وي.
//! دا ښه پیژندل شوي چې ډیری لسیزې تارونه په اساس دوه کې د پای نمایندګۍ نلري ، نو موږ په وروستي ځای کې 0.5 واحدونو ته ګرځو (په بل عبارت ، او هم ممکن).
//! ټایمز ، د دوه پرله پسې فلوټونو تر مینځ نیمه لار دقیقا ارزښتونه ، د نیم څخه تر حتی ستراتیژی سره حل کیږي ، چې د بانکدار دورې په نوم هم پیژندل کیږي.
//!
//! اړتیا نشته چې ووایو ، دا د پلي کولو پیچلتیا او د CPU دورانونو په پام کې نیولو سره ، خورا سخت دي.
//!
//! # Implementation
//!
//! لومړی ، موږ نښې له پامه غورځوو.یا بلکه ، موږ دا د تبادلې پروسې په پیل کې لرې کوو او دا په خورا پای کې بیا پلي کوو.
//! دا په ټولو edge قضیو کې سمه ده ځکه چې د IEEE فلوټونه د صفر په شاوخوا کې متوازي دي ، او یو څوک په اسانۍ سره لومړی بټ فلیپ کوي.
//!
//! بیا بیا موږ د ډیجیټل ټکی لرې کړئ د توضیحي تنظیم کولو سره: په متناسب ډول ، `12.34e56` په `1234e54` بدل شو ، کوم چې موږ د مثبت بشپړت `f = 1234` او بشپړ `e = 54` سره تشریح کوو.
//! د `(f, e)` نمایش د جلا کولو مرحلې تیرو شاوخوا ټولو کوډونو لخوا کارول کیږي.
//!
//! بیا بیا موږ د ماشین اندازې انډیژرو او کوچني ، ثابت شوي اندازې تیرې نقطې شمیرې (لومړی `f32`/`f64` ، بیا د 64 بټ اهمیت لرونکی ، `Fp`) په کارولو سره د پرمختګ خورا عمومي او قیمتي ځانګړي قضیې اوږد سلسله هڅه کوو.
//!
//! کله چې دا ټول ناکام شي ، موږ ګولۍ وخورو او یو ساده مګر خورا ورو ورو الګوریتم ته واړوو چې په بشپړ ډول د `f * 10^e` کمپیوټري کولو کې او د غوره نږدې کولو لپاره تکراري لټون ترسره کول شامل دي.
//!
//! په لومړني ډول ، دا انډول او د هغې ماشومان د الګوریتم پلي کوي چې په لاندې ډول بیان شوي:
//! "How to Read Floating Point Numbers Accurately" د ولیم ډي لخوا
//! کلینګر ، آنلاین شتون لري: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! سربیره پردې ، ډیری مرستندویه دندې شتون لري چې په کاغذ کې کارول شوي مګر په Rust کې شتون نلري (یا لږترلږه په کور کې).
//! زموږ نسخه سربیره پردې د جریان او زیربنا اداره کولو اړتیا او د غیر نورمال شمیرې اداره کولو غوښتنې لخوا پیچلې ده.
//! بیلروفون او الګوریتم R د ډیر جریان ، subnormals ، او ځمکې لاندې جریان کې ستونزه لري.
//! موږ په محافظه کاره ډول الګوریتم M ته واړوو (د کاغذ په 8 برخه کې تشریح شوي توضیحاتو سره) مخکې له دې چې معلومات نازک سیمې ته ورشئ.
//!
//! بل اړخ چې پاملرنې ته اړتیا لري هغه ``RawFloat`` trait دی چې له مخې یې نږدې ټول افعال پارامیټرائز کیږي.یو څوک شاید فکر وکړي چې دا د `f64` پارس کولو لپاره کافي دی او پایله یې `f32` ته اچول شوې.
//! بدبختانه دا نړۍ نده چې موږ پکې ژوند کوو ، او دا د اډې دوه یا نیم څخه تر حتی راډینګ کارولو سره هیڅ تړاو نلري.
//!
//! د مثال په توګه دوه ډولونه `d2` او `d4` په پام کې ونیسئ چې د لسیزې نوعیت د دوه لسیزو ډیجیټلونو او څلور لسیزو ډیجیټونو نمایندګي کوي او د "0.01499" ان پټ په توګه اخلي.راځئ چې نیم نیم راډینګ وکاروو.
//! په مستقیم ډول دوه لسیزې ډیجیټل ته `0.01` درکوي ، مګر که موږ لومړی څلور عددي ته ورسیدو ، نو موږ `0.0150` ترلاسه کوو ، چې بیا وروسته `0.02` پورې ګرځي.
//! ورته اصول په نورو عملیاتو کې هم پلي کیږي ، که تاسو د 0.5 ULP درستیت غواړئ نو تاسو اړتیا لرئ *هرڅه* په بشپړ دقیقه او ګرد *کې یو ځل ترسره کړئ ، په پای کې*، په یوځل کې ټول ټټ شوي بټونه په پام کې نیولو سره.
//!
//! FIXME: که څه هم ځینې کوډ ډایپلیکشن اړین دی ، ممکن د کوډ برخې په شاوخوا کې داسې بدلې شي چې لږ کوډ ورته نقل شوی وي.
//! د الګوریتم لویې برخې محصول ته د فلوټ ډول څخه خپلواک دي ، یا یوازې یو څو ثابت ته لاسرسی ته اړتیا لري ، کوم چې د پیرامیټونو په توګه پاس کیدلی شي.
//!
//! # Other
//!
//! تبادله باید *هیڅکله* panic نه.
//! په کوډ کې ادعاوې او څرګند panics شتون لري ، مګر دوی باید هیڅکله محرک نشي او یوازې د داخلي احساساتو چیکونو په توګه خدمت وکړي.هر panics باید یوه مسئله وګ consideredل شي.
//!
//! د واحد ازموینې شتون لري مګر دوی د درستۍ په یقیني کولو کې په کافي اندازه ناکافي دي ، دوی یوازې د ممکنه خطا لږه سلنه پوښي.
//! ډیر پراخه ازموینې په 0Python سکریپټ په توګه په `src/etc/test-float-parse` په ډایرکټر کې موقعیت لري.
//!
//! د انډیج ډیریدو باندې یوه یادونه: د دې فایل ډیری برخې د لسیزې توضیحي `e` سره ریاضي ترسره کوي.
//! په لومړي سر کې ، موږ لسیز ټکي شاوخوا ته واړوو: د لسیزې ډیجیټل دمخه ، د وروستي لسیزې ډیجیټ وروسته ، او داسې نور.دا کیدی شي په بې احتیاطۍ سره ترسره شي.
//! موږ یوازې د کافي کوچني مصرف کونکو لپاره د پارس کولو فرعي موډل تکیه کوو ، چیرې چې "sufficient" د "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" معنی لري.
//! لوی توضیح کونکي منل شوي ، مګر موږ له دوی سره ریاضي نه کوو ، دوی سمدلاسه په {positive,negative} {zero,infinity} بدل شوي.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// دا دواړه خپلې ازمونې لري.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// تار په 10 بیس کې فلوټ ته واړوئ.
            /// اختیاري لسیزې توضیحات مني.
            ///
            /// دا فنکشن لکه د
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', یا مساوي ، '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', یا ، مساوي ، '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// رهبري او تعقیبي سپین ځای یوه تېروتنه ښیې.
            ///
            /// # Grammar
            ///
            /// ټول تارونه چې لاندې [EBNF] ګرامر سره مراعات کیږي د [`Ok`] بیرته راستنیدو پایله به ولري:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # پیژندل شوې کړۍ
            ///
            /// په ځینو حاالتو کې ، ځینې تارونه چې باید یو معتبر فلوټ رامینځته کړي پرځای یې یوه تېروتنه راوباسي.
            /// د توضیحاتو لپاره [issue #31407] وګورئ.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src ، یو تار
            ///
            /// # د راستنیدو ارزښت
            ///
            /// `Err(ParseFloatError)` که چیرې تار باوري شمیره ونه ټاکي.
            /// بلکه ، `Ok(n)` چیرې چې `n` د فلوینګ-پواینټ شمیره ده چې د `src` لخوا استازیتوب کیږي.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// یوه تېروتنه چې د فلوټ پارس کولو پر مهال بیرته راګرځیدلی شي.
///
/// دا خطا د [`f32`] او [`f64`] لپاره د [`FromStr`] پلي کولو لپاره د غلط ډول په توګه کارول کیږي.
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// په نښه او پاتې کې یو لسیز تار وویشئ ، پرته لدې چې د تفتیش یا اعتبار تایید کړئ.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // که تار ناباوره وي ، موږ هیڅکله نښه نه کاروو ، نو موږ اړتیا نلرو دلته اعتبار وکړو.
        _ => (Sign::Positive, s),
    }
}

/// لسیز تار د فلوټ پوینټ شمیر ته واړوئ.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// د لسیزې څخه تر فلوټ د تبادلې لپاره اصلي ورکشاپونه: ټول چمتووالی تنظیم کړئ او معلومه کړئ چې کوم الګوریتم باید اصلي تبادله ترسره کړي.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift لسيز ټکي لرې.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 په 1280 بټونو پورې محدود دی ، کوم چې شاوخوا 385 لسیزې ډیجیټونو ته وژباړي.
    // که موږ له دې څخه تیر شو ، نو موږ به ټکر وکړو ، نو موږ د ډیر نږدې کیدو دمخه غلطي کوو (د 10 ^ 10 دننه).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // اوس مصرف کونکی یقینا په 16 بیټ کې فټ کوي ، کوم چې د اصلي الګوریتمونو په اوږدو کې کارول کیږي.
    let e = e as i16;
    // FIXME دا حدود نه بلکه محافظه کاره دي.
    // د بیلروفون د ناکامۍ حالتونو خورا محتاط تحلیل کولی شي د لوی سرعت لپاره په ډیرو قضیو کې د دې کارولو ته اجازه ورکړي.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// لکه څنګه چې لیکل شوي ، دا په بده توګه اصلاح کوي (#27130 وګورئ ، که څه هم دا د کوډ زوړ نسخه حواله کوي).
// `inline(always)` د دې لپاره یو عملي کار دی.
// په ټوله کې یوازې دوه د تلیفون سایټونه شتون لري او دا د کوډ اندازه بد نه کوي.

/// د امکان تر بریده پټی ځیرو ، حتی کله چې دا د توضیح بدلولو ته اړتیا لري
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // د دې زیروونو پاکول هیڅ شی نه بدلوي مګر ممکن ګړندۍ لاره (<15 ډیجیټل) وړ کړي.
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // د فورمې شمیره ساده کړئ 0.0 ... x او x ... 0.0 ، د مطابق مطابق ب adjustه تنظیم کول.
    // دا ممکن تل ګټونکي نه وي (په احتمالي توګه د ګ numbersې ګو ofې څخه ځینې شمیرې تیروي) ، مګر دا نورې برخې د پام وړ ساده کوي (په ځانګړي توګه د ارزښت شدت نږدې کول).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// د ترټولو لوی ارزښت (log10) اندازه باندې ګړندی-چټل لوړ حد ته راستنوي چې الګوریتم R او الګوریتم M به ورکړل شوې لسیزې کې د کار کولو پرمهال محاسبه کړي.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // موږ د trivial_cases() او پارسر څخه مننه کوو چې دلته د ډیر جریان په اړه ډیر اندیښنه کولو ته اړتیا نلرو ، کوم چې زموږ لپاره خورا خورا ډیر معلومات فلټر کوي.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // په قضیه کې e>=0 ، دواړه الګوریتمونه د `f * 10^e` په اړه حساب کوي.
        // الگوریتم R د دې سره یو څه پیچلي محاسبې ته دوام ورکوي مګر موږ کولی شو دا د پورتنۍ حد لپاره له پامه وغورځوو ځکه چې دا دمخه مخکی برخه کموي ، نو موږ هلته ډیری بفر لرو.
        //
        f_len + (e as u64)
    } else {
        // که e <0 ، الګوریتم R تقریبا ورته کار کوي ، مګر الګوریتم M توپیر لري:
        // دا د مثبت شمیره k موندلو هڅه کوي داسې لکه چې `f << k / 10^e` د حد کې اهمیت لري.
        // دا به د `2^53 *f* 10^e` <`10^17 *f* 10^e` په اړه پایله ولري.
        // یو ان پیوټ چې دا محرکوي 0.33 دی ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// پرته لدې ډیسی شمیرو ته په کتلو سره څرګند جریان او د اوبو جریان کشف کړئ.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // دلته زیرو شتون درلود مګر دوی د simplify() لخوا ویستل شوي
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // دا د ceil(log10(the real value)) یو خام اټکل دی.
    // موږ اړتیا نلرو دلته د ډیر جریان په اړه ډیر اندیښنه ولرو ځکه چې د ننوت اوږدوالی خورا کوچنی دی (لږترلږه د 2 ^ 64 په پرتله) او پارسیر لا دمخه توضیح کونکي اداره کوي چې بشپړ ارزښت یې د 10 ^ 18 څخه ډیر دی (کوم چې لاهم 10 ^ 19 لنډ دی د 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}