//! د فارم د لسیزې سلسله باوري کول او بې زنګول:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! په نورو ټکو کې ، د دوه استثناوو سره معیاري فلوټینګ-ټکي نحو: هیڅ نښه نلري ، او د "inf" او "NaN" نه اداره کول.دا د ډرایور فنکشن (super::dec2flt) لخوا اداره کیږي.
//!
//! که څه هم د معتبر رایو پیژندل نسبتا اسانه دي ، دا ماډل هم باید بې شمیره غیرقانوني تغیرات رد کړي ، هیڅکله panic نه ، او ډیری چیکونه ترسره کوي چې نور موډلونه د panic (یا ډیر جریان) په تکیه کولو تکیه کوي.
//!
//! د دې لپاره چې موضوع خرابه کړي ، دا ټول د وتلو په یوه برخه کې پیښیږي.
//! نو ، په هرڅه کې د ترمیم کولو پر مهال محتاط اوسئ ، او د نورو ماډلونو سره دوه ځله چیک وکړئ.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// د لسیزې مزي په زړه پوري برخې.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// د لسی ډیجیټل تضمین ، د 18 لسیزې څخه لږ لږو تضمین.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// چیک کوي چې آیا د ان پټ تار د اعتبار وړ فلوټینګ پوائنټ شمیره ده او که داسې وي ، نو اړینه برخه ، کسرونکی برخه ، او په کې پکې نفوذ کوونکی ومومئ.
/// نښې نه اداره کوي.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // د 'e' دمخه هیڅ ګ .ه نشته
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // موږ د ټکي دمخه یا وروسته لږترلږه یو عدد ته اړتیا لرو.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // د جزوي برخې وروسته د جنک تعقیب
            }
        }
        _ => Invalid, // د لومړۍ ګ stringې تار وروسته د جنک تعقیب
    }
}

/// لومړي غیر ډیجیټل کرکټر پورې لسیز ډیجیټل کاروي.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// د توکی استخراج او د تېروتنې کتنه.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // د مصرف کونکی وروسته د جنک تعقیب
    }
    if number.is_empty() {
        return Invalid; // خالی توکی
    }
    // پدې مرحله کې ، موږ حتما د ډیرو معتبر تار لرو.دا ممکن ډیر اوږد وي چې په `i64` کېښودل شي ، مګر که دا خورا لوی وي ، ننوت به خامخا صفر وي یا لامحدود.
    // څنګه چې په لسیز ډیجیټونو کې هر صفر یوازې د +/-1 لخوا مصرف کونکی تنظیم کوي ، نو په ایکسپورټ=10 ^ 18 کې ننوت باید حتی د لرې کیدو څخه حتی لرې ته نږدې کیدو لپاره د زیرو ایکس ایکس ایکس ایکس ایکس ایکس وي.
    //
    // دا دقیقا د کارونې قضیه نده چې موږ ورته اړتیا لرو.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}