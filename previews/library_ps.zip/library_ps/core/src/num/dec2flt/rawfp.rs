//! په مثبتو IEEE 754 فلوټونو کې د بټ فیډلینګ.منفي شمیرې ندي او لاس ته نه ورځي.
//! نورمال فلوټینګ پوائنټ شمیره نمایشي نمایش لري لکه (frac، exp) لکه چې ارزښت یې 2 <sup>Exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) دی چیرې چې N د بیټونو شمیر دی.
//!
//! فرعي نورمال یو څه مختلف او عجیب دي ، مګر ورته اصول پلي کیږي.
//!
//! دلته ، په هرصورت ، موږ دوی د f مثبت سره (sig ، k) نمایندګي کوو ، داسې چې ارزښت یې f * دی
//! 2 <sup>ای</sup> .د "hidden bit" توضیحي کولو سربیره ، دا د نامتو مانټیسسا شفټ لخوا توضیح بدلوي.
//!
//! بله لاره یې وساتئ ، په عادي ډول فلوټونه د (1) په نوم لیکل شوي مګر دلته دا د (2) په توګه لیکل شوي:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! موږ (1) ته **څلورمه برخه نمایش** او (1) د **متناسب نمایش** وایو.
//!
//! پدې موډل کې ډیری دندې یوازې نورمال شمیرې اداره کوي.د ډیک فلټ روټینز محافظه کاره د خورا کوچنۍ او خورا لوی شمیر لپاره د نړۍ په کچه درست سمې لارې (الګوریتم M) اخلي.
//! دا الګوریتم یوازې next_float() ته اړتیا لري کوم چې فرعي نورمالونه او صفرونه اداره کوي.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// د مرسته کونکي trait ترڅو د `f32` او `f64` لپاره اساسا د ټولو تبادلې کوډ نقل کولو مخه ونیسي.
///
/// د دې لپاره چې ولې لازمي دي د اصلي انډول ماسټر ډیسک نظر وګورئ.
///
/// ایا **هیڅکله هیڅکله** د نورو ډولونو لپاره پلي کیدلی نشي یا د ډیک فیلټ موډل څخه بهر وکارول شي.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// د `to_bits` او `from_bits` لخوا کارول شوی ډول.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// عدد ته خام لیږد ترسره کوي.
    fn to_bits(self) -> Self::Bits;

    /// د بشپړ انډول څخه خام لیږد ترسره کوي.
    fn from_bits(v: Self::Bits) -> Self;

    /// کتګورۍ ته راستنوي چې دا شمیره پکې راځي.
    fn classify(self) -> FpCategory;

    /// مینټیسسا ، توزیع کونکي او نښه د اشکال په توګه بیرته راګرځي.
    fn integer_decode(self) -> (u64, i16, i8);

    /// فلوټ ډیکوډ کړئ.
    fn unpack(self) -> Unpacked;

    /// د کوچني عدد څخه ذاتونه چې دقیقا نمایش کیدی شي.
    /// Panic که چیرې انټیکټ ونه نمایش شي ، نو پدې ماډل کې نور کوډ ډاډ ترلاسه کوي چې هیڅکله دا پیښ نشي.
    fn from_int(x: u64) -> Self;

    /// د مخکیني حساب شوي جدول څخه 10 <sup>e</sup> ارزښت ترلاسه کوي.
    /// د `e >= CEIL_LOG5_OF_MAX_SIG` لپاره Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// څه نوم وايي.
    /// دا د جاګینګ داخلي توکو په پرتله هارډ کوډ لپاره اسانه دی او امید لري چې LLVM دوامداره ټوټه کړي.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // یو محافظه کار د ډیمال ډیجیټل اعدادونو پورې اړه لري چې نشي کولی جریان یا صفر یا تولید کړي
    /// فرعي نومرې.شاید د اعظمي حد اعشاریه اعظمي حد ته د نورمال ارزښت له همدې امله نوم.
    const MAX_NORMAL_DIGITS: usize;

    /// کله چې خورا مهم لسیز ډیجیټ د دې څخه د ځای ارزښت لري ، نو دا شمیره يقينا لا محدودیت ته رسي.
    ///
    const INF_CUTOFF: i64;

    /// کله چې خورا مهم لسیز ډیجیټ د دې څخه لږ د ځای ارزښت لري ، نو دا شمیره صفر ته رسیږي.
    ///
    const ZERO_CUTOFF: i64;

    /// په تاویدونکي کې د باټونو شمیر.
    const EXP_BITS: u8;

    /// د ارزښتونو کې د ټوټې شمیره ،*پټول شامل دي*.
    const SIG_BITS: u8;

    /// د ارزښتونو کې د ټوټې شمیره ، * پټه بیټ پرته.
    const EXPLICIT_SIG_BITS: u8;

    /// د تقلبي نمایندګۍ کې اعظمي قانوني توکی.
    const MAX_EXP: i16;

    /// د فرعي نورمونو په استثنایی ، د برخې په نمایندګۍ کې لږترلږه قانوني توکی.
    const MIN_EXP: i16;

    /// `MAX_EXP` د انضمام نمایندګۍ لپاره ، د بیلګې په توګه ، د شيفټ پلي کیدو سره.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` کوډ شوی (د بیلګې په توګه ، د قضیې تعصب سره)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` د انضمام نمایندګۍ لپاره ، د بیلګې په توګه ، د شيفټ پلي کیدو سره.
    const MIN_EXP_INT: i16;

    /// د بشپړ نمایندګۍ لپاره اعظمي معمول شوی اهمیت.
    const MAX_SIG: u64;

    /// لږترلږه نورمال اهمیت په انضمام نمایندګۍ کې.
    const MIN_SIG: u64;
}

// تر ډیره بریده د #34344 لپاره کاري تماس.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// مینټیسسا ، توزیع کونکي او نښه د اشکال په توګه بیرته راګرځي.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // توضیحي تعصب + مینټیسټا شفټ
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe نامعلومه ده چې ایا `as` په سمه توګه په ټولو پلیټ فارمونو کې ګرځي.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// مینټیسسا ، توزیع کونکي او نښه د اشکال په توګه بیرته راګرځي.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // توضیحي تعصب + مینټیسټا شفټ
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe نامعلومه ده چې ایا `as` په سمه توګه په ټولو پلیټ فارمونو کې ګرځي.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// د `Fp` نږدې ماشین فلوټ ډول ته بدلوي.
/// غیر معمولي پایلې نه اداره کوي.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 بټ دی ، نو ځکه xe د 63 مینټیسا شفټ لري
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// د 64-بټ اهمیت سره نیم نیم تر حتی سره T::SIG_BITS بټونو ته پړاو ورکړئ.
/// د توسعې جریان نه اداره کوي.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // د مینټیسا شفټ تنظیم کړئ
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// د نورمال شمیر لپاره د `RawFloat::unpack()` معکوس.
/// Panics که اهمیت لرونکی یا توجیه کونکي د نورمال شمیر لپاره معتبر ندي.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // پټ بیټ لرې کړئ
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // د توزیع کونکي تعصب او مینټیسسا شفټ لپاره تنظیم کونکي تنظیم کړئ
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // په 0 ("+") کې د نښه نښه پریږدئ ، زموږ شمیرې ټولې مثبتې دي
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// یو نورمال جوړول.د 0 مینټیسا اجازه لري او صفر جوړوي.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // د کوډ شوي توضیع کونکی 0 دی ، د نښه بټ 0 دی ، نو موږ باید یوازې ټوټې بیا تشریح کړو.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// د Fp سره نږدې بیګم.د نیم00 څخه حتی سره د 0.5 ULP دننه ګردونه.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // موږ د انډیکس `start` دمخه ټول ټوټې ټوټې کړې ، د مثال په توګه ، موږ د `start` مقدار سره په مؤثره توګه ښي شفټ کوو ، نو دا هم هغه توکی دی چې موږ ورته اړتیا لرو.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // د ټټ شوي بټونو پورې اړه لرونکی ګر (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// د دلیل څخه په کلکه کوچنی ترټولو لوی فلوټینګ پوائنټ ومومئ.
/// فرعي نورمالونه ، صفر ، یا توضیحي جریان نه اداره کوي.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// ترټولو کوچنی فلوټ پوینټ شمیره د دلیل څخه په کلکه غټ کړئ
// دا عملیات د تقویت وړ دی ، د مثال په توګه ، next_float(inf) ==inf.
// په دې ماډل کې د ډیری کوډونو برخلاف ، دا فنلک صفر ، فرعي نورمالونه او ناببره اداره کوي.
// په هرصورت ، دلته د نورو ټولو کوډونو په څیر ، دا د NaN او منفي شمیرو سره معامله نه کوي.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // دا ریښتیا هم خورا ښه ښکاري ، مګر دا کار کوي.
        // 0.0 د ټول صفر ټکي په توګه کوډ شوی دیفرعي نمونې د 0x000m دي ... m چیرې چې میتیسټا دی.
        // په ځانګړي توګه ، ترټولو کوچنۍ فرعي درجه 0x0 ... 01 ده او لوی یې 0x000F دی ... F.
        // ترټولو کوچنۍ معمولي شمیره 0x0010 ... 0 ده ، نو د دې کونج قضیه هم کار کوي.
        // که چیرې وده مینټیسا پراخه کړي ، نو د کڅوړې بټ برخه لکه څنګه چې موږ غواړو وده کوي ، او د مینټیسسا ټوټې صفر کیږي.
        // د پټ بټ کنوانسیون له امله ، دا هم په سمه توګه هغه څه دي چې موږ یې غواړو!
        // په نهایت کې ، f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}