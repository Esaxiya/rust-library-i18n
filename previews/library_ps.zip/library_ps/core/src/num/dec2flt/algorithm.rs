//! د کاغذ څخه مختلف الګوریتمونه.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// په ایف پی کې د ارزښت لرونکي بټونو شمیر
const P: u32 = 64;

// موږ په ساده ډول د *ټولو* توضیح کونکو لپاره ترټولو نږدې اټکل کوو ، نو د متغیر "h" او اړوند شرایط له مینځه وړل کیدی شي.
// دا د څو کیلوټایټ فضا لپاره فعالیت سودا کوي.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// په ډیری معمارونو کې ، د فلوټینګ پوینټ عملیات یو څه اندازه اندازه لري ، نو له همدې امله د کمپیوټري توضیحات د هر عملیات په اساس ټاکل کیږي.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// په x86 کې ، x87 FPU د فلوټ عملیاتو لپاره کارول کیږي که چیرې د SSE/SSE2 توسیع شتون نلري.
// د x87 FPU د ډیټابیس لخوا د 80 دقیقې دقیقیت سره کار کوي ، پدې معنی چې عملیات به 80 ټوټې ته ګرځي چې د ډبل پړاو رامینځته کیدو لامل کیږي کله چې ارزښتونه په پای کې نمایش شي
//
// 32/64 بټ فلوټ ارزښتونه.د دې له مینځه وړلو لپاره ، د FPU کنټرول کلمه ترتیب کیدی شي نو چې کمپیوټونه مطلوب دقیقیت کې ترسره شي.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// یو جوړښت چې د FPU کنټرول کلمې اصلي ارزښت ساتلو لپاره کارول کیږي ، نو دا بیا جوړیدل کیدی شي کله چې جوړښت راټیټ شي.
    ///
    ///
    /// د x87 FPU یو 16-باټ راجسټر دی چې ساحې یې په لاندې ډول دي:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// د ټولو برخو لپاره اسناد د IA-32 آرکیټیکچر سافټویر ډویلپر لارښود (جلد 1) کې شتون لري.
    ///
    /// یوازینۍ ساحه چې د لاندې کوډ لپاره اړونده ده PC ده ، دقیقا کنټرول.
    /// دا ساحه د FPU لخوا ترسره شوي عملیاتو دقیقیت ټاکي.
    /// دا تنظیم کیدی شي:
    ///  - 0b00 ، واحد دقیقیت ، 32 32 بټونه
    ///  - 0b10 ، دوه ګونی دقیقیت ، 64-بیټونه
    ///  - 0b11 ، دوه برابره شوی دقیقیت لکه د 80-bits (ډیفالټ حالت) د 0b01 ارزښت ساتل شوی او باید ونه کارول شي.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // خوندي: د `fldcw` لارښود وپلټل شو ترڅو د دې سره سم کار کولو وړ وي
        // هر ډول `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: موږ د LLVM 8 او LLVM 9 ملاتړ لپاره د ATT ترکیب کار کوو.
                options(att_syntax, nostack),
            )
        }
    }

    /// د FPU دقیقه ساحه `T` ته ټاکي او `FPUControlWord` بیرته ورکوي.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // د دقیق کنټرول ساحې لپاره ارزښت محاسبه کړئ چې د `T` لپاره مناسب دی.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 ټوټې
            8 => 0x0200, // 64 ټوټې
            _ => 0x0300, // اصلي ، 80 ټوټې
        };

        // د دې د بیرته نیولو لپاره د کنټرول کلمې اصلي ارزښت ترلاسه کړئ ، کله چې د `FPUControlWord` جوړښت خوندي پریښودل شي: د `fnstcw` لارښود تفتیش شوی ترڅو د کومې `u16` سره سم کار کولو وړ وي
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: موږ د LLVM 8 او LLVM 9 ملاتړ لپاره د ATT ترکیب کار کوو.
                options(att_syntax, nostack),
            )
        }

        // مطلوب دقیقیت ته د کنټرول کلمه تنظیم کړئ.
        // دا د زاړه دقیقیت (د 8 او 9 ، 0x300 بټونو) ماسک کولو او د پورته محاسب شوي دقیق بیرغ سره ځای په ځای کولو سره ترلاسه شوی.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// د بیلاروفون ګړندۍ لار د ماشین اندازې انډیجز او فلوټس په کارولو سره.
///
/// دا په جلا فعالیت کې استخراج کیږي نو دا د بیګم جوړولو دمخه هڅه کیدی شي.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // موږ دقیق ارزښت د پای ته نږدې MAX_SIG سره پرتله کوو ، دا یوازې یو ګړندي ، ارزانه رد دی (او پاتې کوډ هم د زیربنا په اړه اندیښنې څخه آزادوي).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // ګړندۍ لاره په جدي توګه د ریاضیاتو پورې اړه لري چې د بیټونو سمه شمیره ته پرته له کومې منځنۍ دورې سره ګرځي.
    // په x86 کې (د SSE یا SSE2 پرته) د دې اړتیا ده چې د x87 FPU سټیکیکټ تثبیت شي ترڅو بدل شي ترڅو دا په مستقیم ډول د 64/32 بټ ته واوړي.
    // د `set_precision` فعالیت په معمارونو کې د دقیق ترتیب کولو ته پاملرنه کوي کوم چې د نړیوال دولت بدلولو سره د دې ترتیب کولو ته اړتیا لري (لکه د x87 FPU کنټرول کلمه).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // قضیه e <0 نشي کولی بل branch ته وسپارل شي.
    // منفي قوتونه په بائنری کې د تکراري برخې برخې پایله کوي ، کوم چې ګردي شوي دي ، کوم چې په وروستۍ پایله کې واقعیا (او کله ناکله د پام وړ پام وړ غلطي) رامینځته کوي.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// الګوریتم بیلاروفان کوچني کوډ دی چې د غیر مجاز شمیري تحلیل لخوا توجیه شوی.
///
/// دا د 64 بټ اهمیت سره فلوټ ته ګرځي او د `10^e` غوره اټکل کولو سره ضرب کوي (په ورته فلوټینګ نقطه ب formatه کې).دا اکثرا د سمې پایلې ترلاسه کولو لپاره کافي دي.
/// په هرصورت ، کله چې پایله د دوه نږدې (ordinary) فلوټونو تر مینځ نیمایي ته نږدې وي ، نو د دوه نږدې کیدو ضرب کولو څخه د راټولولو تېروتنه پدې معنی ده چې پایله ممکن د څو ټوټو لخوا بنده وي.
/// کله چې دا پیښ شي ، تکرار الګوریتم R شیان اصلاح کوي.
///
/// د لاسي لاری "close to halfway" په کاغذ کې د شمیرو تحلیلونو لخوا دقیق رامینځته شوی.
/// د کلینجر په ټکو کې:
///
/// > ټوټه ، د لږترلږه پام وړ بټ په واحدونو کې ښودل شوې ، د غلطۍ لپاره یو ټولیز حد دی
/// > د f * 10 ^ e ته د نږدې د فلوټینګ محاسبې په جریان کې راټول شوي.(ټوټه ده
/// > د ریښتیني غلطي لپاره پابند ندي ، مګر د نږدې z او
/// > ترټولو ښه احتمالي نږدې والی چې د پیټ بټیټ د اهمیت څخه کار اخلي.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // قضیې abs(e) <log5(2^N) په fast_path() کې دي
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // ایا سلاپ دومره لوی دی چې توپیر وکړي کله چې د n بټونو سره ګرځي؟
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// یو تکراري الګوریتم چې د `f * 10^e` تیرې نقطې نږدې ته وده ورکوي.
///
/// هر تکرار په وروستي ځای کې یو واحد ته نږدې نږدې راځي ، کوم چې البته د یوځای کیدو لپاره خورا اوږد وخت نیسي که `z0` حتی لږ څه بند وي.
/// خوشبختانه ، کله چې د بیلروفون لپاره د فال بیک بیک په توګه وکارول شي ، د پیل اټکل نږدې د یو ULP لخوا بند دی.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // مثبت عددونه `x` ، `y` ومومئ چې `x / y` دقیقا `(f *10^e) / (m* 2^k)` وي.
        // دا نه یوازې د `e` او `k` نښو سره معامله کولو څخه مخنیوی کوي ، موږ د `10^e` او `2^k` دوه عام ځواک هم له مینځه وړو ترڅو شمیرې کوچنۍ کړئ.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // دا یو څه عجیب لیکل شوی ځکه چې زموږ bignums د منفي شمیرو ملاتړ نه کوي ، نو موږ د مطلق ارزښت + نښه معلومات کاروو.
        // د m_d Digits سره ضرب کیدلی نشي.
        // که `x` یا `y` دومره لوی وي چې موږ د ډیر فلو په اړه اندیښنې ته اړتیا لرو ، نو دوی هم دومره لوی دي چې `make_ratio` د 2 ^ 64 یا ډیرو فاکتور لخوا برخه کمه کړې.
        //
        //
        let (d2, d_negative) = if x >= y {
            // ایکس ته اړتیا نلرئ ، یو clone() خوندي کړئ.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // بیا هم y ته اړتیا لرئ ، یوه کاپي جوړه کړئ.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// ورکړل شوی `x = f` او `y = m` چیرې چې `f` د معمول په توګه د انډول اعشاریې نمرې نمایندګي کوي او `m` د تیرې نقطې نږدې کیدو اهمیت دی ، د `x / y` تناسب د `(f *10^e) / (m* 2^k)` سره برابر کړئ ، ممکن د دوه بریښنا سره کم شي چې دواړه سره مشترک دي.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e، y=m* 2 ^ k، په استثنا د دې چې موږ د دوه قوي بریښنا له مخې کسب کم کړو.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k)، y=m دا نشي کولی جریان وکړي ځکه چې دا مثبت `e` او منفي `k` ته اړتیا لري ، کوم چې یوازې 1 ته خورا نږدې ارزښتونو لپاره پیښ کیدی شي ، پدې معنی چې `e` او `k` به نسبتا کوچني وي.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f، y=m *10^abs(e)* 2 ^ k دا هم نشي جریان کولی ، پورته یې وګورئ.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k) ، y=m* 10^abs(e) ، بیا د دوه ګډ ځواک لخوا کمول.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// په موازي ډول ، الګوریتم M تر لسیزې پورې په فلوټ کې بدلولو ترټولو اسانه لار ده.
///
/// موږ یو تناسب جوړ کوو چې د `f * 10^e` سره مساوي وي ، بیا د دوه قدرتونو کې وغورځو تر هغه چې ورته د اعتبار وړ فلوټ اهمیت ورکړ شي.
/// د بائنری توضیح کونکی `k` هغه وخت دی چې موږ دوه یا ډومینټر دوه سره ضرب کړی ، په داسې حال کې چې هر وخت `f *10^e` د `(u / v)* 2^k` مساوي دي.
/// کله چې موږ اهمیت وموند ، موږ یوازې د برخې پاتې برخې معاینه کولو ته اړتیا لرو ، کوم چې لاندې په مرسته کونکو کارونو کې ترسره کیږي.
///
///
/// دا الګوریتم خورا ورو دی ، حتی په `quick_start()` کې بیان شوي مطلوب سره.
/// په هرصورت ، دا د الګوریتمونو ترټولو ساده دی چې د ډیر جریان ، زیربنا ، او غیر نورمال پایلو لپاره تطبیق کړئ.
/// دا تطبیق هغه وخت نیسي کله چې بیلروفون او الګوریتم R له پامه غورځول کیږي.
/// د ځمکې لاندې او جریان کشف کول اسانه دي: تناسب لاهم د خورا محدود حد اهمیت نلري ، مګر بیا هم د minimum/maximum توضیحاتو ته رسیدلی.
/// د ډیر جریان په حالت کې ، موږ په ساده ډول انفینیت بیرته راستون کوو.
///
/// د زیربنا او فرعي نورمونو اداره کول پیچلي دي.
/// یوه لویه ستونزه دا ده چې د لږترلږه مصرف کونکي سره ، تناسب شاید لاهم د یو اهمیت لپاره خورا لوی وي.
/// د توضیحاتو لپاره underflow() وګورئ.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // د FIXME احتمالي مطلوب کول: لوی_تو_ ایف پی عمومي کړئ ترڅو موږ وکولی شو دلته د fp_to_float(big_to_fp(u)) مساوي ترسره کړو ، یوازې د دوه ځله راوتلو پرته.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // موږ باید په لږترلږه توضیح کونکي باندې ودرېږو ، که موږ د `k < T::MIN_EXP_INT` پورې انتظار وباسو ، نو موږ به د دوه فکتور لخوا بند شو.
            // بدبختانه د دې معنی ده چې موږ باید د لږترلږه مصرف کونکي سره عادي شمیره ځانګړې کړو.
            // FIXME یو ډیر ښکلی جوړښت ومومئ ، مګر د `tiny-pow10` ازموینه پرمخ وړئ ترڅو ډاډ ترلاسه کړئ چې دا واقعیا سمه ده!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// د بټ اوږدوالی په کلیک کولو سره د ډیری الګوریتم M تکرارونو څخه ځي.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // د بیټ اوږدوالی د اساس دوه لوګارتم اټکل دی ، او log(u / v) = log(u) ، log(v).
    // اټکل د لږترلږه 1 لخوا بند دی ، مګر تل یو تخمینی تخمینی دی ، نو په log(u) او log(v) کې خطا د ورته نښه ده او لغوه یې کړئ (که دواړه لوی وي).
    // له همدې امله د log(u / v) لپاره خطا یو له بل څخه هم یوه ده.
    // د هدف تناسب یو دی چیرې چې u/v د انډیز رینج اهمیت کې دی.پدې توګه زموږ د ختمیدو حالت log2(u / v) دی چې د اهمیت لرونکي ټوټې دي ، plus/minus یو.
    // FIXME دوهم بټ ته کتنه ممکن اټکل ته وده ورکړي او د نورو برخو څخه مخنیوی وکړي.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // د ځمکې لاندې جریان یا غیر نورمالاصلي فعالیت ته یې پریږدئ.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // ډیر جریاناصلي فعالیت ته یې پریږدئ.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // تناسب د لږترلږه تثبیت کونکي سره غیرمقابل اهمیت نلري ، نو موږ اړتیا لرو اضافي ټوټې ټوټې کړو او په ترتیب سره مصرف کونکي تنظیم کړو.
    // اصلي ارزښت اوس داسې ښکاري:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    Q ټرنک.(د ریم لخوا نمایش شوی)
    //
    // له همدې امله ، کله چې د ګرد څخه ویستل شوي بټونه وي!= 0.5 ULP ، دوی پخپله د دورې پریکړه کوي.
    // کله چې دوی مساوي وي او پاتې یې غیر صفر وي ، نو ارزښت یې لاهم ګرد ته اړتیا لري.
    // یوازې کله چې د ګرځېدلي بټونه 1/2 وي او پاتې یې صفر وي ، موږ له نیم څخه تر حده حالت لرو.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// عادي پړاو څخه حتی ، د برخې پاتې کیدو پراساس د ګرد سره درلودو لخوا ځنډیدلی.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}