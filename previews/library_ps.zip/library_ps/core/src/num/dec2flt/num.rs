//! د bignums لپاره د کارونې فعالیتونه چې په میتودونو کې د بدلولو لپاره خورا ډیر احساس نه کوي.

// FIXME د دې موډل نوم یو څه بدبخت دی ، ځکه چې نور موډل هم `core::num` واردوي.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// ازموینه وکړئ ایا د `ones_place` په پرتله د ټولو بټونو کم پام کول د 0.5 ULP څخه لږ ، مساوي ، یا خورا لوی نسبتي غلطي معرفي کوي.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // که ټول پاتې ټوټې صفر وي ، دا= 0.5 ULP دی ، که نه نو> 0.5 که نور بیټونه نه وي (نیمه بیټ==0) ، لاندې هم په سمه توګه مساوي راولي.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// د ASCII تار بدلوي چې یوازې لسیز ډیجیټل `u64` ته لري.
///
/// د ډیر جریان یا ناباوره کرکټرونو لپاره چیکونه نه ترسره کوي ، نو که چیرې زنګ وهونکی محتاط نه وي ، نو پایله جعلي ده او panic کولی شي (که څه هم دا به `unsafe` نه وي).
/// سربیره پردې ، خالي تارونه د صفر په توګه چلند کیږي.
/// دا دنده شتون لري ځکه چې
///
/// 1. په `&[u8]` د `FromStr` کارول `from_utf8_unchecked` ته اړتیا لري ، کوم چې خراب دي ، او
/// 2. د `integral.parse()` او `fractional.parse()` پایلو ګډه کول د دې ټول فعالیت په پرتله خورا پیچلي دي.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// د ASCII ګ ofو تار په بیګم بدلوي.
///
/// د `from_str_unchecked` په څیر ، دا فنکشن د ډیجیټونو زیان رسوونکو پا pو باندې تکیه کوي.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// بېګم په bit 64 بیټ انټریج کې راوباسي.Panics که شمیر خورا لوی وي.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// یو شمیر بیټونه راوباسي.

/// شاخص 0 لږترلږه د پام وړ بیټ دی او سلسله د معمول په توګه نیمه خلاصه ده.
/// Panics که د راستنیدو ډول کې د فټ څخه ډیرې ټوټې راوبللو غوښتنه وشي.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}