//! د ګمرکي پخپل سري توضیح شمیره د (bignum) پلي کول.
//!
//! دا د دې لپاره ډیزاین شوی چې د سټیک حافظې په لګښت کې د زېرمې تخصیص مخه ونیسي.
//! تر ټولو ډیر کارول شوی بیګینم ډول ، `Big32x40` ، د 32 × 40=1،280 بټونو لخوا محدود دی او د سټیک حافظې به یې تر 160 بیتونو ډیر وخت ونیسي.
//! دا د ټول احتمالي محدود `f64` ارزښتونو د پړاو درې کولو لپاره کافي دی.
//!
//! په اصولو کې دا امکان شتون لري چې د مختلف بیلګو لپاره ډیری بینګم ډولونه ولرئ ، مګر موږ دا نه کوو ترڅو د کوډ بلاټ څخه مخنیوی وشي.
//!
//! هر باینګم لاهم د اصلي کارولو لپاره تعقیب کیږي ، نو دا معمولا مهمه نده.
//!

// دا انډول یوازې د dec2flt او flt2dec لپاره دی ، او یوازې د اصلي شیانو له امله عام دی.
// دا د هیڅکله ثبات کولو اراده نلري.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// د bignums لخوا اړونده ارثیتیک عملیات.
pub trait FullOps: Sized {
    /// `(carry', v')` بیرته راوړي لکه `carry' * 2^W + v' = self + other + carry` ، چیرې چې `W` په `Self` کې د ټوټې شمیره ده.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` بیرته راوړي لکه `carry'*2^W + v' = self* other + carry` ، چیرې چې `W` په `Self` کې د ټوټې شمیره ده.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` بیرته راوړي لکه `carry'*2^W + v' = self* other + other2 + carry` ، چیرې چې `W` په `Self` کې د ټوټې شمیره ده.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` بیرته راوړي لکه `borrow *2^W + self = quo* other + rem` او `0 <= rem < other` ، چیرې چې `W` په `Self` کې د بیټونو شمیر دی.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // دا ډیر نشي کولیمحصول د `0` او `2 * 2^nbits - 1` تر منځ دی.
                    // FIXME: ایا LLVM به دا په ADC یا ورته ورته کې غوره کړي؟
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // دا ډیر نشي کولی
                    // محصول د `0` او `2^nbits * (2^nbits - 1)` تر منځ دی.
                    // FIXME: ایا LLVM به دا په ADC یا ورته ورته کې غوره کړي؟
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // دا ډیر نشي کولی
                    // محصول د `0` او `2^nbits * (2^nbits - 1)` تر منځ دی.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // دا ډیر نشي کولیمحصول د `0` او `other * (2^nbits - 1)` تر منځ دی.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // د دې توان ورکولو لپاره RFC #521 وګورئ.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// د 5 د ځواکونو جدول په ګsو کې د استازیتوب وړ.په ځانګړي توګه ، ترټولو لوی {u8, u16, u32} ارزښت چې د پنځه بریښنا ، جمع اړونده مصرف کونکی دی.
/// په `mul_pow5` کې کارول شوی.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// د سټک تخصیص شوي پخپل سري توقیف (تر یو حد پورې پورې) بشپړونکی.
        ///
        /// دا د ورکړل شوي ډول ("digit") د اندازې اندازه شوي سرې لخوا ملاتړ کیږي.
        /// پداسې حال کې چې سرنی خورا لوی ندی (معمولا ځینې سوه بایټونه) ، د دې په کافي اندازه کاپي کول ممکن د فعالیت پایلې ته ورسوي.
        ///
        /// پدې توګه دا په قصدي ډول `Copy` ندي.
        ///
        /// ټول عمليات د ډیر جریان په حالت کې Bignums panic ته شتون لري.
        /// زنګ وهونکی مسؤل دی چې د کافي غټ بیګم ډولونه وکاروي.
        pub struct $name {
            /// یو جمع په پراخه کچه په کارولو کې "digit" ته آفسیټ.
            /// دا کم نه کیږي ، نو د حساب کولو امر څخه خبر اوسئ.
            /// `base[size..]` باید صفر وي.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` د `a + b *2^W + c* 2^(2W) + ...` استازیتوب کوي چیرې چې `W` د ډیجیټل ډولونو کې د باټونو شمیر دی.
            base: [$ty; $n],
        }

        impl $name {
            /// له یوې ګ fromې څخه بېګم جوړوي.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// د `u64` ارزښت څخه بېګم جوړوي.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// داخلي عددي د سلیس `[a, b, c, ...]` په څیر بیرته راګرځوي داسې چې عددي ارزښت یې `a + b *2^W + c* 2^(2W) + ...` دی چیرې چې `W` د عددي ډول کې د ټوټې شمیره ده.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// `i`-th بیټ ته راستون کوي چیرې چې 0 0 لږترلږه د پام وړ یو دی.
            /// په نورو ټکو ، د وزن `2^i` سره یو څه.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// `true` راستنوي که چیرې بیګینم صفر وي.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// د دې ارزښت استازیتوب کولو لپاره اړین بټونو شمیر راولي.
            /// په یاد ولرئ چې صفر 0 ټوټې ته اړتیا لري.
            pub fn bit_length(&self) -> usize {
                // د پام وړ ډیرو څخه چې صفر دي تیر کړئ.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // دلته غیر صفر ټکي نشته ، د مثال په توګه ، شمیره صفر ده.
                    return 0;
                }
                // دا د leading_zeros() او بټ شفټونو سره غوره کیدی شي ، مګر دا شاید د پریشانۍ ارزښت نلري.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// ځان ته `other` اضافه کوي او خپل بدل کیدونکی حواله بیرته راستنوي.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// له ځانه څخه `other` ضمني کوي او خپل بدلون مبایل ته مراجعه کوي.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// ځان د ډیجیټل اندازې `other` لخوا ضرب کوي او خپل متغیر شوی حواله بیرته ورکوي.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// پخپله د `2^bits` لخوا ضرب کوي او خپل متغیر حواله بیرته ورکوي.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // د `digits * digitbits` بټونو لخوا بدلون
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // د `bits` بټونو لخوا بدلون
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. ګsي] صفر دی ، اړولو ته اړتیا نلري
                }

                self.size = sz;
                self
            }

            /// پخپله د `5^e` لخوا ضرب کوي او خپل متغیر حواله بیرته ورکوي.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // په 2 ^ n کې دقیقا د N تعقیبي زیرو شتون لري ، او یوازې اړوند ډیجیټل سائز دوه د یو پرله پسې ځواک دي ، نو دا د میز لپاره مناسب مناسب شاخص دی.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // تر هغه چې ممکنه وي ترټولو لوی واحد-ډیجیټل ځواک سره ضرب کړئ ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... بیا پاتې پاتې بشپړ کړئ.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// پخپله د `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` لخوا تشریح شوي شمیرې سره ضرب کوي (چیرې چې `W` د ډیجیټ ډول کې د ټوټې شمیره ده) او خپل متغیر حواله یې راستنوي.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // داخلي ورځنۍښه کار کوي کله چې aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// ځان د ډیجیټل اندازې `other` په واسطه ویشئ او خپل متغیر حواله یې *او* پاتې راوړي.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// ځان د بل باینګم په واسطه وویشئ ، د `q` له اقتباس سره او او پاتې `r` سره له سره لیکل.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // احمقانه ورو base-2 اوږده برخه له څخه اخیستل شوې
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME د اوږدې برخې لپاره لوی اکس ($ty) کاروي.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // 1 ته د Q x بټ `i` تنظیم کړئ.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// د `Big32x40` لپاره د ګ typeي ډول.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// دا یوازې د ازموینې لپاره کارول کیږي.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}