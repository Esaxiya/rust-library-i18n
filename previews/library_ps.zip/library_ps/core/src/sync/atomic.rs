//! اټوم ډولونه
//!
//! اټوم ډولونه د تارونو ترمینځ لومړني مشترک حافظه اړیکه چمتو کوي ، او د نورو ورته ډولونو جوړونکي بلاکونه دي.
//!
//! دا انډول د لومړني ډولونو د ټاکلو شمیرو اټومي ب selectې ټاکي ، په شمول د [`AtomicBool`] ، [`AtomicIsize`] ، [`AtomicUsize`] ، [`AtomicI8`] ، [`AtomicU16`] ، او داسې نور.
//! اټوم ډولونه عملیات وړاندې کوي چې ، کله چې په سمه توګه وکارول شي ، نو د تارونو ترمینځ تازه معلومات ترکیب کړئ.
//!
//! هر میتود [`Ordering`] اخلي کوم چې د دې عملیاتو لپاره د حافظې خنډ ځواک څرګندوي.دا حکمونه د [C++20 atomic orderings][1] په څیر دي.د نورو معلوماتو لپاره [nomicon][2] وګورئ.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! اټومي تغیرات د موضوعاتو ترمینځ شریکولو لپاره خوندي دي (دوی د [`Sync`] پلي کوي) مګر دوی پخپله د Rust [threading model](../../../std/thread/index.html#the-threading-model) د شریکولو او تعقیب میکانیزم نه وړاندې کوي.
//!
//! د اټومي تغیراتو شریکولو ترټولو عامه لاره دا ده چې په [`Arc`][arc] کې ځای په ځای شي (د اټومي پلوه-حواله حساب شوي شریک پوائنټر).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! اټوم ډولونه ممکن په جامد تغیراتو کې زیرمه شي ، د [`AtomicBool::new`] په څیر دوامداره ابتکارونو په کارولو سره پیل شوي.اټومي احصایې اکثرا د لوڅې نړیوالې پیل لپاره کارول کیږي.
//!
//! # Portability
//!
//! پدې ماډل کې ټول اټومي ډولونه د [lock-free] تضمین دي که چیرې شتون ولري.د دې معنی دا ده چې دوی په نړیواله کچه نړیوال میتیکس نه ترلاسه کوي.اټوم ډولونه او عملیات د انتظار څخه آزاد کی تضمین ندي.
//! دا پدې مانا ده چې د `fetch_or` په څیر عملیات ممکن د پرتله کولو او سویپ لوپ سره پلي شي.
//!
//! اټومي عملیات ممکن د لارښود پرت کې د لوی اندازې اټومیک سره پلي شي.د مثال په توګه ځینې پلیټ فارمونه د `AtomicI8` پلي کولو لپاره د 4 بایټ اټومي لارښوونو څخه کار اخلي.
//! په یاد ولرئ چې دا تقلید باید د کوډ په سموالي اغیزه ونلري ، دا یوازې یو څه دي چې باید پرې خبر اوسئ.
//!
//! پدې ماډل کې اټومي ډولونه ممکن په ټولو پلیټ فارمونو کې شتون ونلري.په هرصورت ، دلته اټومي ډولونه په پراخه کچه شتون لري ، او په عمومي ډول په موجوده تکیه کولی شي.ځینې د پام وړ استثناوې په لاندې ډول دي:
//!
//! * PowerPC او د 32 بټ پوینټرو سره MIPS پلیټ فارمونه د `AtomicU64` یا `AtomicI64` ډولونه نلري.
//! * ARM د `armv5te` په څیر پلیټ فارمونه چې د Linux لپاره ندي یوازې د `load` او `store` عملیاتو چمتو کوي ، او د پرتله کولو او سویپ (CAS) عملیاتو ملاتړ نه کوي ، لکه `swap` ، `fetch_add` ، او داسې نور.
//! سربیره پر Linux ، دا CAS عملیات د [operating system support] له لارې پلي کیږي ، کوم چې ممکن د فعالیت جریمې سره راشي.
//! * ARM د `thumbv6m` سره اهداف یوازې `load` او `store` عملیات چمتو کوي ، او د پرتله کولو او سویس (CAS) عملیاتو ملاتړ نه کوي ، لکه `swap` ، `fetch_add` ، او داسې نور.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! په یاد ولرئ چې ممکن د future پلیټ فارمونه اضافه شي چې د ځینې اټومي عملیاتو ملاتړ هم نلري.په احتمالي توګه د لیږد وړ کوډ به د دې په اړه محتاط وي چې کوم اټومي ډولونه کارول کیږي.
//! `AtomicUsize` او `AtomicIsize` عموما ترټولو خورا وړ وړ دی ، مګر بیا هم دا هرچیرې شتون نلري.
//! د حوالې لپاره ، د `std` کتابتون د پوائنټر-اندازې اټومکس ته اړتیا لري ، که څه هم `core` نه کوي.
//!
//! اوس مهال تاسو اړتیا لرئ د `#[cfg(target_arch)]` په عمده ډول د اټومکس سره کوډ کې تالیف کولو لپاره وکاروئ.دلته هم بې ثباته `#[cfg(target_has_atomic)]` شتون لري کوم چې ممکن په future کې مستحکم شي.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! یو ساده سپن لاک:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // د لاک خوشې کولو لپاره نورو تار ته انتظار وکړئ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! د ژوندیو تورو نړیوال شمیره وساتئ:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// د بولین ډول چې د مزو ترمینځ په خوندي ډول شریک کیدی شي.
///
/// دا ډول د [`bool`] په څیر په حافظه کې ورته نمونه لري.
///
/// **یادونه**: دا ډول یوازې په پلیټفارمونو کې شتون لري چې د `u8` اټومي بوټو او پلورنځیو ملاتړ کوي.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` ته پیل شوی `AtomicBool` رامینځته کوي.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// لیږل په اتوماتيک ډول د تطبیق وړ دی.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// د خامو اشاره ډول چې د مزي ترمینځ په خوندي ډول شریک کیدی شي.
///
/// دا ډول د `*mut T` په څیر په حافظه کې ورته نمونه لري.
///
/// **یادونه**: دا ډول یوازې په پلیټ فارمونو کې شتون لري چې د اټومي بوټو او د نښو پلورنځیو ملاتړ کوي.
/// د دې اندازه د هدف نښه کونکي اندازې پورې اړه لري.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// نول ایکس00 ایکس رامینځته کوي.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// د اټومي حافظې امرونه
///
/// د یادونې سپارښتنې د اتومات فعالیتونو د حافظې ترکیب کولو لاره مشخص کوي.
/// د دې ترټولو ضعیف [`Ordering::Relaxed`] کې ، یوازې د حافظې مستقیم عملیات چې د عملیاتو لخوا پواسطه ترکیب کیږي.
/// له بلې خوا ، د [`Ordering::SeqCst`] عملیاتو یو پلورنځی لوړه جوړه نور حافظه همغوي کوي پداسې حال کې چې سربیره پردې په ټولو موضوعاتو کې د ورته عملیاتو مجموعه ساتي.
///
///
/// د Rust د حافظې امرونه د [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) دي.
///
/// د نورو معلوماتو لپاره [nomicon] وګورئ.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// نه د نظم محدودیتونه ، یوازې اټومي عملیات.
    ///
    /// په C++ 20 کې د [`memory_order_relaxed`] سره مطابقت لري.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// کله چې د پلورنځي سره مل کیږي ، ټول پخواني عملیات د [`Acquire`] (یا پیاوړي) امر سره د دې ارزښت د هرډول بار دمخه امر شوي.
    ///
    /// په ځانګړي توګه ، ټول پخواني لیکنې ټولو موضوعاتو ته د لیدو وړ ګرځي چې د دې ارزښت [`Acquire`] (یا قوي) لوړه ترسره کوي.
    ///
    /// په یاد ولرئ چې د عملیاتو لپاره د دې ترتیب کارول کارول چې بوجونه او پلورنځی سره یوځای کوي د [`Relaxed`] بوج عملیاتو لامل کیږي!
    ///
    /// دا امر یوازې د عملیاتو لپاره پلي کیږي چې کولی شي پلورنځی ترسره کړي.
    ///
    /// په C++ 20 کې د [`memory_order_release`] سره مطابقت لري.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// کله چې د بار سره مل شوی ، که لوډ شوی ارزښت د [`Release`] (یا قوي) امر سره د پلورنځي عملیاتو لخوا لیکل شوی و ، نو بیا وروسته ټول عملیات د پلورنځي وروسته امر کیږي.
    /// په ځانګړي توګه ، ټول راتلونکي بارونه به د پلورنځي دمخه لیکل شوي ډاټا وګوري.
    ///
    /// په پام کې ونیسئ چې د عملیاتو لپاره د دې ترتیب کارول کارول چې بوجونه او پلورنځي یوځای کوي د [`Relaxed`] پلورنځي عملیاتو لامل کیږي!
    ///
    /// دا ترتیب یوازې د عملیاتو لپاره پلي کیږي چې کولی شي بار ترسره کړي.
    ///
    /// په C++ 20 کې د [`memory_order_acquire`] سره مطابقت لري.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// د [`Acquire`] او [`Release`] دواړه سره تاثیرات لري:
    /// د بارونو لپاره دا د [`Acquire`] امر کاروي.د پلورنځیو لپاره دا د [`Release`] امر کاروي.
    ///
    /// په یاد ولرئ چې د `compare_and_swap` په قضیه کې ، امکان لري چې عملیات د هیڅ پلورنځي نه ترسره کوي او له همدې امله دا یوازې د [`Acquire`] امر لري.
    ///
    /// په هرصورت ، `AcqRel` به هیڅکله د [`Relaxed`] لاسرسی ونه ترسره کړي.
    ///
    /// دا امر یوازې د عملیاتو لپاره د تطبیق وړ دی چې دواړه بارونه او پلورنځي یوځای کوي.
    ///
    /// په C++ 20 کې د [`memory_order_acq_rel`] سره مطابقت لري.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// د [qu Acquire`]/[[`ریلیز`]/[` AcqRel`](په ترتیب سره د بار ، ذخیره کولو او بار سره د پلور سره عملیاتو لپاره) د اضافي تضمین سره چې ټول موضوعات په ترتیب سره ټول ترتیب منظم عملیات په ورته ترتیب کې ګوري .
    ///
    ///
    /// په C++ 20 کې د [`memory_order_seq_cst`] سره مطابقت لري.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// یو [`AtomicBool`] `false` ته پیل شو.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// نوی `AtomicBool` رامینځته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// په مابین [`bool`] کې د بدلون بدلونه حواله کوي.
    ///
    /// دا خوندي دی ځکه چې تغیر ورکول حواله تضمین کوي چې نور هیڅ تارونه په عین وخت کې اتومي معلوماتو ته لاسرسی نلري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // امنیت: د بدلون وړ حواله د ځانګړي ملکیت ضمانت کوي.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` ته اټومي لاسرسی ومومئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // امنیت: د بدلون وړ حواله د ځانګړي ملکیت تضمین کوي ، او
        // د `bool` او `Self` دواړه برابرول 1 دی.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// اټوم مصرفوي او موجود ارزښت بیرته راولي.
    ///
    /// دا خوندي دی ځکه چې د ارزښت له مخې د `self` تیریدل تضمین کوي چې نور کوم تارونه په عین وخت کې اتومي معلوماتو ته لاسرسی نلري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// د bool څخه ارزښت پورته کوي.
    ///
    /// `load` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.
    /// ممکنه ارزښتونه یې [`SeqCst`] ، [`Acquire`] او [`Relaxed`] دي.
    ///
    /// # Panics
    ///
    /// Panics که `order` [`Release`] یا [`AcqRel`] وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // خوندي: د هر ډول معلوماتو ریسان د اټومي داخلي توکو او خامیو لخوا مخنیوی کیږي
        // دننه شوی نښه شوی معتبره ده ځکه چې موږ دا د یوې حوالې څخه ترلاسه کړه.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// په bool کې ارزښت ساتي.
    ///
    /// `store` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.
    /// ممکنه ارزښتونه یې [`SeqCst`] ، [`Release`] او [`Relaxed`] دي.
    ///
    /// # Panics
    ///
    /// Panics که `order` [`Acquire`] یا [`AcqRel`] وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // خوندي: د هر ډول معلوماتو ریسان د اټومي داخلي توکو او خامیو لخوا مخنیوی کیږي
        // دننه شوی نښه شوی معتبره ده ځکه چې موږ دا د یوې حوالې څخه ترلاسه کړه.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool کې ارزښت ساتي ، مخکینی ارزښت بیرته راګرځي.
    ///
    /// `swap` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
    /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
    ///
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// په [`bool`] کې ارزښت ساتي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
    ///
    /// د راستنیدو ارزښت تل پخوانی ارزښت وي.که دا د `current` سره مساوي وي ، نو ارزښت یې تازه شوی و.
    ///
    /// `compare_and_swap` د [`Ordering`] دلیل هم اخلي چې د دې عملیاتو د حافظې ترتیب توضیح کوي.
    /// په یاد ولرئ چې حتی د [`AcqRel`] کارولو پرمهال ، عملیات ممکن ناکام شي او له همدې امله یوازې د `Acquire` بار ترسره کوي ، مګر د `Release` سیمانټیکونه نلري.
    /// د [`Acquire`] کارول د ذخیره کولو دغه برخه [`Relaxed`] رامینځته کوي که دا پیښ شي ، او د [`Release`] کارول د بار برخه [`Relaxed`] رامینځته کوي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # `compare_exchange` او `compare_exchange_weak` ته هجرت کول
    ///
    /// `compare_and_swap` د `compare_exchange` سره مساوي د حافظې ترتیباتو لپاره لاندې میپینګ سره:
    ///
    /// اصلي |بریا |ناکامي
    /// -------- | ------- | -------
    /// راحته |راحته |ارام ترلاسه کول |لاسته راوړنه |د خلاصون لاسته راوړنه |خوشې کول |آرام اکریکیل |AcqRel |د SeqCst لاسته راوړئ |سیکیکسټ |SeqCst
    ///
    /// `compare_exchange_weak` اجازه ورکړل شوې چې په زحمت سره ناکام شي حتی کله چې پرتله کول بریالي وي ، کوم چې تالیف کونکي ته اجازه ورکوي غوره مجلس کوډ رامینځته کړي کله چې پرتله او سویپ په لوپ کې وکارول شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// په [`bool`] کې ارزښت ساتي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
    ///
    /// د راستنیدنې ارزښت یوه پایله ده چې په ګوته کوي چې ایا نوي ارزښت لیکل شوی او پخوانی ارزښت لري.
    /// په بریا کې دا ارزښت د `current` سره مساوي تضمین دی.
    ///
    /// `compare_exchange` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
    /// `success` د لوستلو-تدوین-لیکلو عملیاتو لپاره اړین امر توضیح کوي چې واقع کیږي که د `current` سره پرتله کول بریالي شي.
    /// `failure` د بار عملیاتو لپاره اړین امر بیانوي چې ترسره کیږي کله چې پرتله کول ناکام شي.
    /// د [`Acquire`] کارول د بریا امر په توګه د پلورنځي د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارولو سره بریالی بار [`Relaxed`] رامینځته کیږي.
    ///
    /// د ناکامۍ ترتیب یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریالیتوب امر سره باید مساوي یا ضعیف وي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// په [`bool`] کې ارزښت ساتي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
    ///
    /// د [`AtomicBool::compare_exchange`] برعکس ، دا فعالیت ته اجازه ورکول کیږي چې په شدت سره ناکام شي حتی کله چې پرتله کول بریالي وي ، کوم چې په ځینې پلیټ فارمونو کې د ډیر موثر کوډ پایله کیدی شي.
    ///
    /// د راستنیدنې ارزښت یوه پایله ده چې په ګوته کوي چې ایا نوي ارزښت لیکل شوی او پخوانی ارزښت لري.
    ///
    /// `compare_exchange_weak` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
    /// `success` د لوستلو-تدوین-لیکلو عملیاتو لپاره اړین امر توضیح کوي چې واقع کیږي که د `current` سره پرتله کول بریالي شي.
    /// `failure` د بار عملیاتو لپاره اړین امر بیانوي چې ترسره کیږي کله چې پرتله کول ناکام شي.
    /// د [`Acquire`] کارول د بریا امر په توګه د پلورنځي د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارولو سره بریالی بار [`Relaxed`] رامینځته کیږي.
    /// د ناکامۍ ترتیب یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریالیتوب امر سره باید مساوي یا ضعیف وي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// منطقي "and" د بولین ارزښت سره.
    ///
    /// په اوسني ارزښت او دلیل `val` باندې د منطقي "and" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
    ///
    /// مخکینی ارزښت راستنوي.
    ///
    /// `fetch_and` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
    /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
    ///
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// منطقي "nand" د بولین ارزښت سره.
    ///
    /// په اوسني ارزښت او دلیل `val` باندې د منطقي "nand" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
    ///
    /// مخکینی ارزښت راستنوي.
    ///
    /// `fetch_nand` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
    /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
    ///
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // موږ دلته اټوم_ننډ نه کاروو ځکه چې دا کولی شي د bool پایلې د ناباوره ارزښت سره.
        // دا پیښیږي ځکه چې اټومي عملیات په داخلي توګه د 8 بټ انډیجر سره ترسره کیږي ، کوم چې پورتنۍ 7 ټوټې ټاکي.
        //
        // نو موږ یوازې د دې پرځای fetch_xor یا سویپ کاروو.
        if val {
            // ! (x او ریښتینی)== !x موږ باید bool بدل کړو.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&غلط)==ریښتیني موږ باید bool ریښتیني کړو.
            //
            self.swap(true, order)
        }
    }

    /// منطقي "or" د بولین ارزښت سره.
    ///
    /// په اوسني ارزښت او دلیل `val` باندې د منطقي "or" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
    ///
    /// مخکینی ارزښت راستنوي.
    ///
    /// `fetch_or` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
    /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
    ///
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// منطقي "xor" د بولین ارزښت سره.
    ///
    /// په اوسني ارزښت او دلیل `val` باندې د منطقي "xor" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
    ///
    /// مخکینی ارزښت راستنوي.
    ///
    /// `fetch_xor` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
    /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
    ///
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// د بدل شوي [`bool`] ته بدلون پذیري راګرځوي.
    ///
    /// د غیر اټومي لوستلو او پایلو کې لیکل ترسره کول د ډیټا ریس کیدی شي.
    /// دا میتود اکثرا د FFI لپاره ګټور دی ، چیرې چې د فعالیت لاسلیک ممکن د `&AtomicBool` پرځای `*mut bool` وکاروي.
    ///
    /// دې اتوم ته د شریک حوالې څخه د `*mut` پوائنټر بیرته راستنیدل خوندي دي ځکه چې اټوم ډولونه د داخلي بدلون سره کار کوي.
    /// د اټومیت ټول بدلونونه د ګډ حوالې له لارې ارزښت بدلوي ، او تر هغه چې دا اټومي عملیات وکاروي نو په خوندي ډول یې ترسره کولی شي.
    /// د راستن شوي خام نښې هرډول کارول د `unsafe` بلاک ته اړتیا لري او اوس هم باید ورته محدودیت وساتي: پدې کې عملیات باید اټومي وي.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// ارزښت ترلاسه کوي ، او پدې کې یو فنکشن پلي کوي چې اختیاري نوي ارزښت بیرته راولي.د `Ok(previous_value)` `Result` راستنوي که چیرې فنکشن `Some(_)` بیرته راشي ، نو `Err(previous_value)`.
    ///
    /// Note: دا ممکن فنکشن ته څو ځله زنګ ووهي که چیرې ارزښت په ورته وخت کې له نورو موضوعاتو څخه بدل شوی وي ، ترڅو چې فن `Some(_)` بیرته راشي ، مګر فنکشن به یوازې یو ځل د ذخیره شوي ارزښت سره پلي شي.
    ///
    ///
    /// `fetch_update` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
    /// لومړی د اړین امر لپاره توضیحات وړاندې کوي کله چې عملیات په پای کې بریالي کیږي پداسې حال کې چې دوهم د بارونو لپاره اړین امر بیانوي.
    /// دا په ترتیب سره د [`AtomicBool::compare_exchange`] بریالیتوب او ناکامي امرونو سره مطابقت لري.
    ///
    /// د بریا امر په توګه د [`Acquire`] کارول د ذخیره کولو د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارول د بریالي بار وروستی [`Relaxed`] رامینځته کوي.
    /// د (failed) د بار کولو امر یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریا ترتیب کولو په پرتله مساوي یا ضعیف وي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په `u8` کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// نوی `AtomicPtr` رامینځته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// لاندې ټکي ته د بدلون بدلول حواله ورکوي.
    ///
    /// دا خوندي دی ځکه چې تغیر ورکول حواله تضمین کوي چې نور هیڅ تارونه په عین وخت کې اتومي معلوماتو ته لاسرسی نلري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// اټومي ته لاسرسی ته لاړ شئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - د بدلون بدلول حواله د ځانګړي ملکیت ضمانت کوي.
        //  - د `*mut T` او `Self` سمون په ټولو پلیټونو کې یو دی چې د rust لخوا ملاتړ کیږي ، لکه څنګه چې پورته تایید شوی.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// اټوم مصرفوي او موجود ارزښت بیرته راولي.
    ///
    /// دا خوندي دی ځکه چې د ارزښت له مخې د `self` تیریدل تضمین کوي چې نور کوم تارونه په عین وخت کې اتومي معلوماتو ته لاسرسی نلري.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// د اشارې څخه ارزښت پورته کوي.
    ///
    /// `load` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.
    /// ممکنه ارزښتونه یې [`SeqCst`] ، [`Acquire`] او [`Relaxed`] دي.
    ///
    /// # Panics
    ///
    /// Panics که `order` [`Release`] یا [`AcqRel`] وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// پوائنټور ته ارزښت ساتي.
    ///
    /// `store` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.
    /// ممکنه ارزښتونه یې [`SeqCst`] ، [`Release`] او [`Relaxed`] دي.
    ///
    /// # Panics
    ///
    /// Panics که `order` [`Acquire`] یا [`AcqRel`] وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// پوائنټور ته ارزښت ساتي ، مخکینی ارزښت بیرته راګرځي.
    ///
    /// `swap` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
    /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
    ///
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په اشارو کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// پوائنټر ته ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
    ///
    /// د راستنیدو ارزښت تل پخوانی ارزښت وي.که دا د `current` سره مساوي وي ، نو ارزښت یې تازه شوی و.
    ///
    /// `compare_and_swap` د [`Ordering`] دلیل هم اخلي چې د دې عملیاتو د حافظې ترتیب توضیح کوي.
    /// په یاد ولرئ چې حتی د [`AcqRel`] کارولو پرمهال ، عملیات ممکن ناکام شي او له همدې امله یوازې د `Acquire` بار ترسره کوي ، مګر د `Release` سیمانټیکونه نلري.
    /// د [`Acquire`] کارول د ذخیره کولو دغه برخه [`Relaxed`] رامینځته کوي که دا پیښ شي ، او د [`Release`] کارول د بار برخه [`Relaxed`] رامینځته کوي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په اشارو کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # `compare_exchange` او `compare_exchange_weak` ته هجرت کول
    ///
    /// `compare_and_swap` د `compare_exchange` سره مساوي د حافظې ترتیباتو لپاره لاندې میپینګ سره:
    ///
    /// اصلي |بریا |ناکامي
    /// -------- | ------- | -------
    /// راحته |راحته |ارام ترلاسه کول |لاسته راوړنه |د خلاصون لاسته راوړنه |خوشې کول |آرام اکریکیل |AcqRel |د SeqCst لاسته راوړئ |سیکیکسټ |SeqCst
    ///
    /// `compare_exchange_weak` اجازه ورکړل شوې چې په زحمت سره ناکام شي حتی کله چې پرتله کول بریالي وي ، کوم چې تالیف کونکي ته اجازه ورکوي غوره مجلس کوډ رامینځته کړي کله چې پرتله او سویپ په لوپ کې وکارول شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// پوائنټر ته ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
    ///
    /// د راستنیدنې ارزښت یوه پایله ده چې په ګوته کوي چې ایا نوي ارزښت لیکل شوی او پخوانی ارزښت لري.
    /// په بریا کې دا ارزښت د `current` سره مساوي تضمین دی.
    ///
    /// `compare_exchange` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
    /// `success` د لوستلو-تدوین-لیکلو عملیاتو لپاره اړین امر توضیح کوي چې واقع کیږي که د `current` سره پرتله کول بریالي شي.
    /// `failure` د بار عملیاتو لپاره اړین امر بیانوي چې ترسره کیږي کله چې پرتله کول ناکام شي.
    /// د [`Acquire`] کارول د بریا امر په توګه د پلورنځي د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارولو سره بریالی بار [`Relaxed`] رامینځته کیږي.
    ///
    /// د ناکامۍ ترتیب یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریالیتوب امر سره باید مساوي یا ضعیف وي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په اشارو کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// پوائنټر ته ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
    ///
    /// د [`AtomicPtr::compare_exchange`] برعکس ، دا فعالیت ته اجازه ورکول کیږي چې په شدت سره ناکام شي حتی کله چې پرتله کول بریالي وي ، کوم چې په ځینې پلیټ فارمونو کې د ډیر موثر کوډ پایله کیدی شي.
    ///
    /// د راستنیدنې ارزښت یوه پایله ده چې په ګوته کوي چې ایا نوي ارزښت لیکل شوی او پخوانی ارزښت لري.
    ///
    /// `compare_exchange_weak` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
    /// `success` د لوستلو-تدوین-لیکلو عملیاتو لپاره اړین امر توضیح کوي چې واقع کیږي که د `current` سره پرتله کول بریالي شي.
    /// `failure` د بار عملیاتو لپاره اړین امر بیانوي چې ترسره کیږي کله چې پرتله کول ناکام شي.
    /// د [`Acquire`] کارول د بریا امر په توګه د پلورنځي د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارولو سره بریالی بار [`Relaxed`] رامینځته کیږي.
    /// د ناکامۍ ترتیب یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریالیتوب امر سره باید مساوي یا ضعیف وي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په اشارو کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // خوندي: دا انټرنسیک غیر محفوظ دی ځکه چې دا په خام نقطه کار کوي
        // مګر موږ د ډاډ لپاره پوهیږو چې اشاره باوري ده (موږ دا یوازې د `UnsafeCell` څخه ترلاسه کړی چې موږ یې د حوالې سره لرو) او اټومي عملیات موږ ته اجازه راکوي چې په خوندي ډول د `UnsafeCell` مینځپانګې بدل کړو.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// ارزښت ترلاسه کوي ، او پدې کې یو فنکشن پلي کوي چې اختیاري نوي ارزښت بیرته راولي.د `Ok(previous_value)` `Result` راستنوي که چیرې فنکشن `Some(_)` بیرته راشي ، نو `Err(previous_value)`.
    ///
    /// Note: دا ممکن فنکشن ته څو ځله زنګ ووهي که چیرې ارزښت په ورته وخت کې له نورو موضوعاتو څخه بدل شوی وي ، ترڅو چې فن `Some(_)` بیرته راشي ، مګر فنکشن به یوازې یو ځل د ذخیره شوي ارزښت سره پلي شي.
    ///
    ///
    /// `fetch_update` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
    /// لومړی د اړین امر لپاره توضیحات وړاندې کوي کله چې عملیات په پای کې بریالي کیږي پداسې حال کې چې دوهم د بارونو لپاره اړین امر بیانوي.
    /// دا په ترتیب سره د [`AtomicPtr::compare_exchange`] بریالیتوب او ناکامي امرونو سره مطابقت لري.
    ///
    /// د بریا امر په توګه د [`Acquire`] کارول د ذخیره کولو د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارول د بریالي بار وروستی [`Relaxed`] رامینځته کوي.
    /// د (failed) د بار کولو امر یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریا ترتیب کولو په پرتله مساوي یا ضعیف وي.
    ///
    /// **Note:** دا میتود یوازې په پلیټ فارمونو کې شتون لري چې په اشارو کې د اټومي عملیاتو ملاتړ کوي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` په `AtomicBool` بدلوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // دا میکرو پای ته رسیدلی ترڅو په ځینې معماریو کې بې ګټې پاتې شي.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// د بشپړ ډول ډول چې د مزو ترمینځ په خوندي ډول شریک کیدی شي.
        ///
        /// دا ډول د مینځنۍ عین نوع ډول په توګه د حافظې نمایندګي لري ، [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// د اټومي ډولونو او غیر اټومي ډولونو تر مینځ د توپیرونو په اړه د معلوماتو لپاره او د دې ډول د پورت وړتیا په اړه معلومات لپاره ، مهرباني وکړئ [module-level documentation] وګورئ.
        ///
        ///
        /// **Note:** دا ډول یوازې په پلیټ فارمونو کې شتون لري چې د اټوم بوډونو او [of] پلورنځیو ملاتړ کوي
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// یو اټوم انټرنیټ `0` ته پیل شو.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // لیږل په صریح ډول پلي شوي.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// نوی اټومي عدد جوړوي.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// تر تعقیب لاندې عدد بشپړ بدلون ته راستنوي.
            ///
            /// دا خوندي دی ځکه چې تغیر ورکول حواله تضمین کوي چې نور هیڅ تارونه په عین وخت کې اتومي معلوماتو ته لاسرسی نلري.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =؛؛
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// پرېږدئ ځنې_نټ=33؛؛
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (ځینې_څه ، 100)؛
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - د بدلون بدلول حواله د ځانګړي ملکیت ضمانت کوي.
                //  - د `$int_type` او `Self` سمون یو شان دی ، لکه څنګه چې د $cfg_align لخوا ژمنه شوې او پورته تایید شوې.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// اټوم مصرفوي او موجود ارزښت بیرته راولي.
            ///
            /// دا خوندي دی ځکه چې د ارزښت له مخې د `self` تیریدل تضمین کوي چې نور کوم تارونه په عین وخت کې اتومي معلوماتو ته لاسرسی نلري.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// د اټومي انډیجر څخه یو ارزښت پورته کوي.
            ///
            /// `load` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.
            /// ممکنه ارزښتونه یې [`SeqCst`] ، [`Acquire`] او [`Relaxed`] دي.
            ///
            /// # Panics
            ///
            /// Panics که `order` [`Release`] یا [`AcqRel`] وي.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// اټومي عدد کې ارزښت ساتي.
            ///
            /// `store` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.
            ///  ممکنه ارزښتونه یې [`SeqCst`] ، [`Release`] او [`Relaxed`] دي.
            ///
            /// # Panics
            ///
            /// Panics که `order` [`Acquire`] یا [`AcqRel`] وي.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// اټومي عدد کې ارزښت ساتي ، مخکینی ارزښت بیرته راګرځي.
            ///
            /// `swap` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// اټومي عدد کې یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
            ///
            /// د راستنیدو ارزښت تل پخوانی ارزښت وي.که دا د `current` سره مساوي وي ، نو ارزښت یې تازه شوی و.
            ///
            /// `compare_and_swap` د [`Ordering`] دلیل هم اخلي چې د دې عملیاتو د حافظې ترتیب توضیح کوي.
            /// په یاد ولرئ چې حتی د [`AcqRel`] کارولو پرمهال ، عملیات ممکن ناکام شي او له همدې امله یوازې د `Acquire` بار ترسره کوي ، مګر د `Release` سیمانټیکونه نلري.
            ///
            /// د [`Acquire`] کارول د ذخیره کولو دغه برخه [`Relaxed`] رامینځته کوي که دا پیښ شي ، او د [`Release`] کارول د بار برخه [`Relaxed`] رامینځته کوي.
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` او `compare_exchange_weak` ته هجرت کول
            ///
            /// `compare_and_swap` د `compare_exchange` سره مساوي د حافظې ترتیباتو لپاره لاندې میپینګ سره:
            ///
            /// اصلي |بریا |ناکامي
            /// -------- | ------- | -------
            /// راحته |راحته |ارام ترلاسه کول |لاسته راوړنه |د خلاصون لاسته راوړنه |خوشې کول |آرام اکریکیل |AcqRel |د SeqCst لاسته راوړئ |سیکیکسټ |SeqCst
            ///
            /// `compare_exchange_weak` اجازه ورکړل شوې چې په زحمت سره ناکام شي حتی کله چې پرتله کول بریالي وي ، کوم چې تالیف کونکي ته اجازه ورکوي غوره مجلس کوډ رامینځته کړي کله چې پرتله او سویپ په لوپ کې وکارول شي.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// اټومي عدد کې یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
            ///
            /// د راستنیدنې ارزښت یوه پایله ده چې په ګوته کوي چې ایا نوي ارزښت لیکل شوی او پخوانی ارزښت لري.
            /// په بریا کې دا ارزښت د `current` سره مساوي تضمین دی.
            ///
            /// `compare_exchange` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
            /// `success` د لوستلو-تدوین-لیکلو عملیاتو لپاره اړین امر توضیح کوي چې واقع کیږي که د `current` سره پرتله کول بریالي شي.
            /// `failure` د بار عملیاتو لپاره اړین امر بیانوي چې ترسره کیږي کله چې پرتله کول ناکام شي.
            /// د [`Acquire`] کارول د بریا امر په توګه د پلورنځي د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارولو سره بریالی بار [`Relaxed`] رامینځته کیږي.
            ///
            /// د ناکامۍ ترتیب یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریالیتوب امر سره باید مساوي یا ضعیف وي.
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// اټومي عدد کې یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `current` ارزښت سره ورته وي.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// دا فنکشن ته اجازه ورکول کیږي چې په بې ساري ډول ناکام شي حتی کله چې پرتله کول بریالي وي ، کوم چې په ځینې پلیټ فارمونو کې د ډیر موثر کوډ پایله کیدی شي.
            /// د راستنیدنې ارزښت یوه پایله ده چې په ګوته کوي چې ایا نوي ارزښت لیکل شوی او پخوانی ارزښت لري.
            ///
            /// `compare_exchange_weak` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
            /// `success` د لوستلو-تدوین-لیکلو عملیاتو لپاره اړین امر توضیح کوي چې واقع کیږي که د `current` سره پرتله کول بریالي شي.
            /// `failure` د بار عملیاتو لپاره اړین امر بیانوي چې ترسره کیږي کله چې پرتله کول ناکام شي.
            /// د [`Acquire`] کارول د بریا امر په توګه د پلورنځي د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارولو سره بریالی بار [`Relaxed`] رامینځته کیږي.
            ///
            /// د ناکامۍ ترتیب یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریالیتوب امر سره باید مساوي یا ضعیف وي.
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// پریږدئ زاړه= val.load(Ordering::Relaxed)؛
            /// لوپ {پری نوی=زوړ * 2؛
            ///     لوبه val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// اوسني ارزښت ته اضافه کوي ، پخوانی ارزښت بیرته راګرځوي.
            ///
            /// دا عملیات د ډیر جریان په شاوخوا کې ریپ
            ///
            /// `fetch_add` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// د اوسني ارزښت څخه تخفیه ، د مخکیني ارزښت بیرته راګرځول.
            ///
            /// دا عملیات د ډیر جریان په شاوخوا کې ریپ
            ///
            /// `fetch_sub` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// د اوسني ارزښت سره Bitwise "and".
            ///
            /// په اوسني ارزښت او دلیل `val` باندې یو څه اړخیز "and" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
            ///
            /// مخکینی ارزښت راستنوي.
            ///
            /// `fetch_and` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// د اوسني ارزښت سره Bitwise "nand".
            ///
            /// په اوسني ارزښت او دلیل `val` باندې یو څه اړخیز "nand" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
            ///
            /// مخکینی ارزښت راستنوي.
            ///
            /// `fetch_nand` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31))؛
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// د اوسني ارزښت سره Bitwise "or".
            ///
            /// په اوسني ارزښت او دلیل `val` باندې یو څه اړخیز "or" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
            ///
            /// مخکینی ارزښت راستنوي.
            ///
            /// `fetch_or` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// د اوسني ارزښت سره Bitwise "xor".
            ///
            /// په اوسني ارزښت او دلیل `val` باندې یو څه اړخیز "xor" عملیات ترسره کوي ، او پایلې ته نوي ارزښت ټاکي.
            ///
            /// مخکینی ارزښت راستنوي.
            ///
            /// `fetch_xor` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// ارزښت ترلاسه کوي ، او پدې کې یو فنکشن پلي کوي چې اختیاري نوي ارزښت بیرته راولي.د `Ok(previous_value)` `Result` راستنوي که چیرې فنکشن `Some(_)` بیرته راشي ، نو `Err(previous_value)`.
            ///
            /// Note: دا ممکن فنکشن ته څو ځله زنګ ووهي که چیرې ارزښت په ورته وخت کې له نورو موضوعاتو څخه بدل شوی وي ، ترڅو چې فن `Some(_)` بیرته راشي ، مګر فنکشن به یوازې یو ځل د ذخیره شوي ارزښت سره پلي شي.
            ///
            ///
            /// `fetch_update` د دې عملیاتو د حافظې ترتیب شرح کولو لپاره دوه [`Ordering`] دلیلونه اخلي.
            /// لومړی د اړین امر لپاره توضیحات وړاندې کوي کله چې عملیات په پای کې بریالي کیږي پداسې حال کې چې دوهم د بارونو لپاره اړین امر بیانوي.دا د بریا او ناکامۍ امر سره مطابقت لري
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// د بریا امر په توګه د [`Acquire`] کارول د ذخیره کولو د دې عملیاتو برخه کوي [`Relaxed`] ، او د [`Release`] کارول د بریالي بار وروستی [`Relaxed`] رامینځته کوي.
            /// د (failed) د بار کولو امر یوازې [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] کیدی شي او د بریا ترتیب کولو په پرتله مساوي یا ضعیف وي.
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ترتيب ورکول: SeqCst ، Ordering::SeqCst ، | x | Some(x + 1)) ، Ok(7));
            /// assert_eq! (x.fetch_update (ترتيب ورکول: SeqCst ، Ordering::SeqCst ، | x | Some(x + 1)) ، Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// د اوسني ارزښت سره اعظمي.
            ///
            /// د اوسني ارزښت اعظمي حد او دلیل `val` لټوي ، او پایلې ته نوي ارزښت ټاکي.
            ///
            /// مخکینی ارزښت راستنوي.
            ///
            /// `fetch_max` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// پرېږدئ=42 42؛
            /// راځئ چې max_foo=foo.fetch_max (بار ، Ordering::SeqCst).max(bar);
            /// ادعا وکړئ! (max_foo==42)؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// لږترلږه د اوسني ارزښت سره.
            ///
            /// د اوسني ارزښت لږترلږه او د دلیل `val` لټوي ، او پایلې ته نوي ارزښت ټاکي.
            ///
            /// مخکینی ارزښت راستنوي.
            ///
            /// `fetch_min` د [`Ordering`] دلیل اخلي چې د دې عملیاتو د حافظې ترتیب شرح کوي.د سپارلو ټولې طریقې امکان لري.
            /// په یاد ولرئ چې د [`Acquire`] کارول د دې عملیاتو [`Relaxed`] پلورنځي برخه جوړوي ، او د [`Release`] کارولو سره د بار برخې [`Relaxed`] رامینځته کیږي.
            ///
            ///
            /// **یادونه**: دا میتود یوازې په پلیټ فارمونو کې شتون لري چې د اټومي عملیاتو ملاتړ کوي
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// پرېږدئ=12؛
            /// اجازه راکړئ min_foo=foo.fetch_min (بار ، Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo، 12)؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // خوندي: د ډیټا ریسونه د اټومي داخليدو مخه نیسي.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// ترټولو اصلي عدد ته د بدلون وړ پواینټ راستنوي.
            ///
            /// د غیر اټومي لوستلو او پایلو کې لیکل ترسره کول د ډیټا ریس کیدی شي.
            /// دا میتود اکثرا د FFI لپاره ګټور دی ، چیرې چې د فنکشن لاسلیک ممکن وکاروي
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// دې اتوم ته د شریک حوالې څخه د `*mut` پوائنټر بیرته راستنیدل خوندي دي ځکه چې اټوم ډولونه د داخلي بدلون سره کار کوي.
            /// د اټومیت ټول بدلونونه د ګډ حوالې له لارې ارزښت بدلوي ، او تر هغه چې دا اټومي عملیات وکاروي نو په خوندي ډول یې ترسره کولی شي.
            /// د راستن شوي خام نښې هرډول کارول د `unsafe` بلاک ته اړتیا لري او اوس هم باید ورته محدودیت وساتي: پدې کې عملیات باید اټومي وي.
            ///
            ///
            /// # Examples
            ///
            /// X `X (extern-declaration) سترګې پټې کړئ
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// خارجي "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // خوندي: تر هغه چې خوندي وي `my_atomic_op` اتومات وي.
            /// غیر محفوظ {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // خوندي: زنګ وهونکی باید د `atomic_store` لپاره د خوندیتوب تړون ملاتړ وکړي.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_load` لپاره د خوندیتوب تړون ملاتړ وکړي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_swap` لپاره د خوندیتوب تړون ملاتړ وکړي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// مخکینی ارزښت بیرته راګرځوي (لکه __ sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_add` لپاره د خوندیتوب تړون ملاتړ وکړي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// مخکینی ارزښت بیرته راګرځوي (لکه __ sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_sub` لپاره د خوندیتوب تړون ملاتړ وکړي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // خوندي: زنګ وهونکی باید د `atomic_compare_exchange` لپاره د خوندیتوب تړون ملاتړ وکړي.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // خوندي: زنګ وهونکی باید د `atomic_compare_exchange_weak` لپاره د خوندیتوب تړون ملاتړ وکړي.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_and` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_nand` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_or` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_xor` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// اعظمي ارزښت (لاسلیک شوي پرتله) بیرته راګرځوي
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_max` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// د لږترلږه ارزښت (لاسلیک شوي پرتله) بیرته راګرځوي
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_min` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// اعظمي ارزښت بیرته راګرځوي (لاسلیک شوی پرتله کول)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_umax` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// د لږترلږه ارزښت سره بیرته راګرځي
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // خوندي: زنګ وهونکی باید د `atomic_umin` لپاره د خوندیتوب تړون ملاتړ وکړي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// یو اټومي کټ
///
/// د ټاکل شوي امر پورې اړه لري ، یو کڅوړی د کمپلر او CPU مخه نیسي شاوخوا د حافظې عملیاتو ځینې ډولونه تنظیموي.
/// دا د دې او اتوماتيک عملونو یا نورو تارونو کې باڑونو ترمینځ اړیکې همغږي کوي.
///
/// یو باڑ 'A' چې (لږترلږه) [`Release`] د سیمینټکس آرډر کوي ، د بایر 'B' سره (لږترلږه) [`Acquire`] سیمانټیک سره ترکیب کوي ، که او یوازې که شتون ولري X او Y دواړه دواړه په ځینې اټومي څیز 'M' کې داسې فعالیت کوي چې A مخکې ترتیب شوی وي X ، Y مخکې له دې هم B او Y ترکیب شوی وي او M ته یې بدلون مشاهده کړي.
/// دا د A او B تر مینځ تکیه دمخه چمتو کوي.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// د [`Release`] یا [`Acquire`] سیمانټیکس سره اټومي عملیات هم کولی شي د کټارو سره همغږي شي.
///
/// یو کټ چې د [`SeqCst`] امر لري ، د دواړه د [`Acquire`] او [`Release`] سیمانټیکس سربیره ، د نورو [`SeqCst`] عملیاتو او/یا باڑونو نړیوال برنامې ترتیب کې برخه اخلي.
///
/// د [`Acquire`] ، [`Release`] ، [`AcqRel`] او [`SeqCst`] امرونه مني.
///
/// # Panics
///
/// Panics که `order` [`Relaxed`] وي.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // د سپین لاک پراساس متقابل جلا جلا.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // انتظار وکړئ تر هغه چې زاړه ارزښت `false` وي.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // دا باڑ په `unlock` کې د پلورنځی سره ترکیب کوي.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // خوندي: د اټومي کټ کارول کارول خوندي دي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// د کمپلر یاداشت کټور.
///
/// `compiler_fence` د ماشین کوډ نه خارجوي ، مګر د ډول ډول حافظې محدودوي چې کمپلر ته د کولو اجازه ورکړل شوې.په ځانګړي ډول ، ورکړل شوي [`Ordering`] سیمانټیکس پورې اړه لري ، تالیف کونکی ممکن د زنګ څخه مخکې یا وروسته `compiler_fence` ته د زنګ بل اړخ ته د لوستلو لوستلو یا لیکلو څخه منع شي.په یاد ولرئ چې دا **نه** د *هارډویر* د داسې بیا ترتیب کولو څخه مخنیوی کوي.
///
/// دا په یو اړخیز ، اعدام شرایطو کې ستونزه نده ، مګر کله چې نور موضوعات ممکن په ورته وخت کې حافظه بدله کړي ، قوي همغږي کولو لومړني لکه [`fence`] اړین دي.
///
/// د بیا سپارلو ترتیب د مختلف ترتیب سیمانټیک لخوا مخنیوی شوی په لاندې ډول دي:
///
///  - د [`SeqCst`] سره ، پدې لوستلو کې د لوستلو او لیکلو بیا ترتیب کولو اجازه نشته.
///  - د [`Release`] سره ، مخکینۍ لوستل او لیکل نشي تیر کیدونکي لیکنې حرکت کولی شي.
///  - د [`Acquire`] سره ، ورپسې لوستل او لیکل د مخکینیو لوستلو دمخه حرکت نه شي کولی.
///  - د [`AcqRel`] سره ، دواړه پورتني مقررات پلي کیږي.
///
/// `compiler_fence` عموما یوازې د ځان سره * ریس کولو څخه د تار د مخنیوي لپاره ګټور دی.دا دی ، که چیرې ورکړل شوی موضوع د کوډ یوه برخه اجرا کوي ، او بیا یې مداخله کیږي ، او د بل ځای کې کوډ اجرا کول پیل کوي (پداسې حال کې چې لاهم ورته ورته تار کې دی ، او په ورته ډول په مفهوم کې لاهم).په دودیزو برنامو کې ، دا یوازې هغه وخت پیښ کیدی شي کله چې د سیګنال هډلر ثبت شي.
/// په ډیر ټیټ کچې کوډ کې ، دا ډول شرایط هم رامینځته کیدی شي کله چې د مداخلو اداره کول ، کله چې شنه تیوري د پری تشویش سره پلي کول ، او داسې نور.
/// مبهم لوستونکي هڅول کیږي چې د Linux کریل د [memory barriers] بحث ولوستل شي.
///
/// # Panics
///
/// Panics که `order` [`Relaxed`] وي.
///
/// # Examples
///
/// د `compiler_fence` پرته ، په لاندې کوډ کې `assert_eq!` * د بریالیتوب تضمین نلري ، سره له دې چې هرڅه په یوه تار کې پیښ کیږي.
/// د دې لپاره چې وګورئ ، په یاد ولرئ چې تالیف کونکي `IMPORTANT_VARIABLE` او `IS_READ` ته د پلورنځي بدلولو لپاره وړیا دي ځکه چې دواړه دواړه `Ordering::Relaxed` دي.که دا وکړي ، او د سیګنال دستګاه کونکي د `IS_READY` تازه کیدو وروسته سم غوښتل شوي وي ، نو د سیګنال هینڈلر به `IS_READY=1` وګوري ، مګر `IMPORTANT_VARIABLE=0`.
/// پدې حالت کې د `compiler_fence` درملنې کارول.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // مخکینۍ لیکنې له دې ټکي هاخوا ته مخه مه کوئ
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // خوندي: د اټومي کټ کارول کارول خوندي دي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// پروسیسر ته اشاره کوي چې دا د مصروف انتظار سپن-لوپ ("سپن لاک") دننه دی.
///
/// دا فنکشن د [`hint::spin_loop`] په حق کې تخریب شوی دی.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}