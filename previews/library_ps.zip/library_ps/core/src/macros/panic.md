اوسنی تار Panics.

دا یو برنامه ته اجازه ورکوي چې سمدلاسه پای ته ورسوي او د برنامه زنګ وهونکي ته خپل نظر چمتو کړي.
`panic!` باید وکارول شي کله چې برنامه نا راټول شوي حالت ته ورسیږي.

دا میکرو د مثال په کوډ او ازموینو کې د شرایطو ثابتولو سمه لاره ده.
`panic!` د [`Option`][ounwrap] او [`Result`][runwrap] انیمونو دواړه د `unwrap` میتود سره نږدې تړل شوي.
دواړه پلي کونکي `panic!` زنګ وهي کله چې دوی د [`None`] یا [`Err`] تغیراتو ته ټاکل شوي وي.

کله چې د `panic!()` کاروئ تاسو کولی شئ د سټینګ تادیاتو اندازه مشخص کړئ ، دا د [`format!`] ترکیب په کارولو سره رامینځته شوی.
دا تادیه هغه وخت کارول کیږي کله چې د Rust زنګ وهلو ته د panic انجیکشن وکړئ ، نو دا موضوع په بشپړ ډول panic ته اړوي.

د ډیفالټ `std` hook چلند ، د مثال په توګه
هغه کوډ چې د panic بللو وروسته مستقیم پرمخ ځي ، د `panic!()` زنګ د file/line/column معلوماتو سره `stderr` ته د پیغام تادیه چاپ کول دي.

تاسو کولی شئ د [`std::panic::set_hook()`] په کارولو سره panic hook له سره تنظیم کړئ.
د hook دننه د panic د `&dyn Any + Send` په توګه لاسرسی کیدی شي ، کوم چې د منظم `panic!()` بلنو لپاره `&str` یا `String` لري.
د بل بل ډول ارزښت سره panic ته ، [`panic_any`] کارول کیدی شي.

[`Result`] اینوم اکثرا د `panic!` مایکرو کارولو په پرتله د غلطیو څخه راګرځولو لپاره غوره حل دی.
دا میکرو باید د غلط ارزښتونو کارولو څخه د مخنیوي لپاره وکارول شي ، لکه د بهرنیو سرچینو څخه.
د غلطۍ سمبالولو په اړه تفصيلي معلومات په [book] کې موندل شوي.

د تالیف په جریان کې د غلطیو راپورته کولو لپاره میکرو [`compile_error!`] هم وګورئ.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# اوسنی تطبیق

که اصلي تار panics دا به ستاسو ټولې تارونه ختم او ستاسو برنامه د `101` کوډ سره پای ته ورسوي.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





