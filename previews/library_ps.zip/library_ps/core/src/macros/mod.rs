#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // یا د `$crate::panic::panic_2015` یا `$crate::panic::panic_2021` ته د تلیفون نسخه پورې اړه لري.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ادعا کوي چې دوه څرګندونې یو بل سره مساوي دي (د [`PartialEq`] کارول).
///
/// په panic کې ، دا میکرو به د دوی د ډب نمایندګیو سره د څرګندونو ارزښتونه چاپ کړي.
///
///
/// د [`assert!`] په څیر ، دا میکرو دوهم ب hasه لري ، چیرې چې د ګمرکي panic پیغام چمتو کیدی شي.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // لاندې بوربروز قصدآ دي.
                    // د دوی پرته ، د پور لپاره د سټاټ سلاټ حتی د ارزښتونو پرتله کولو دمخه پیل کیږي ، چې د پام وړ ورو کیدو لامل کیږي.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // لاندې بوربروز قصدآ دي.
                    // د دوی پرته ، د پور لپاره د سټاټ سلاټ حتی د ارزښتونو پرتله کولو دمخه پیل کیږي ، چې د پام وړ ورو کیدو لامل کیږي.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ادعا کوي چې دوه څرګندونې یو بل سره مساوي ندي (د [`PartialEq`] کارول).
///
/// په panic کې ، دا میکرو به د دوی د ډب نمایندګیو سره د څرګندونو ارزښتونه چاپ کړي.
///
///
/// د [`assert!`] په څیر ، دا میکرو دوهم ب hasه لري ، چیرې چې د ګمرکي panic پیغام چمتو کیدی شي.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // لاندې بوربروز قصدآ دي.
                    // د دوی پرته ، د پور لپاره د سټاټ سلاټ حتی د ارزښتونو پرتله کولو دمخه پیل کیږي ، چې د پام وړ ورو کیدو لامل کیږي.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // لاندې بوربروز قصدآ دي.
                    // د دوی پرته ، د پور لپاره د سټاټ سلاټ حتی د ارزښتونو پرتله کولو دمخه پیل کیږي ، چې د پام وړ ورو کیدو لامل کیږي.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ادعا کوي چې د بولین څرګندونه د وخت په وخت کې `true` وي.
///
/// دا به د [`panic!`] میکرو غوښتنه وکړي که چمتو شوي اظهار په `true` کې په وخت کې ونه ارزول شي.
///
/// د [`assert!`] په څیر ، دا میکرو دوهم نسخه هم لري ، چیرې چې د ګمرکي panic پیغام چمتو کیدی شي.
///
/// # Uses
///
/// د [`assert!`] برعکس ، د `debug_assert!` بیانات یوازې د ډیفالټ لخوا په غیر مطلوب جوړښتونو کې فعال شوي دي.
/// یو مطلوب جوړول به د `debug_assert!` بیانات اجرا نه کړي مګر دا چې `-C debug-assertions` تالیف کونکي ته انتقال شي.
/// دا د چکونو لپاره `debug_assert!` ګټور کوي چې خورا ډیر لګښت لري چې په خپاره شوي جوړښت کې شتون ولري مګر ممکن د پرمختګ په جریان کې ګټور وي.
/// د `debug_assert!` پراخولو پایله تل ډول ډول چیک شوې وي.
///
/// یو چک شوی بې ارزښته ادعا په نامناسبه حالت کې برنامه ته اجازه ورکوي چې پرمخ وړي ، کوم چې شاید غیر متوقع پایلې ولري مګر غیر مصرفي ندي معرفي کوي ترڅو چې دا یوازې په خوندي کوډ کې پیښ شي.
///
/// په هرصورت ، د قیمتونو اجرا کولو لګښت په عمومي ډول د اندازه کولو وړ ندي.
/// د [`assert!`] سره د [`assert!`] ځای په ځای کول یوازې د بشپړ پروفایل وروسته هڅول کیږي ، او خورا مهم ، یوازې په خوندي کوډ کې!
///
/// # Examples
///
/// ```
/// // د دې ادعاوو لپاره panic پیغام د ورکړل شوي بیان قوي ارزښت دی.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // یو ډیر ساده فعالیت
/// debug_assert!(some_expensive_computation());
///
/// // د دودیز پیغام سره ټینګار وکړئ
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ادعا کوي چې دوه څرګندونې یو بل سره مساوي دي.
///
/// په panic کې ، دا میکرو به د دوی د ډب نمایندګیو سره د څرګندونو ارزښتونه چاپ کړي.
///
/// د [`assert_eq!`] برعکس ، د `debug_assert_eq!` بیانات یوازې د ډیفالټ لخوا په غیر مطلوب جوړښتونو کې فعال شوي دي.
/// یو مطلوب جوړول به د `debug_assert_eq!` بیانات اجرا نه کړي مګر دا چې `-C debug-assertions` تالیف کونکي ته انتقال شي.
/// دا د چکونو لپاره `debug_assert_eq!` ګټور کوي چې خورا ډیر لګښت لري چې په خپاره شوي جوړښت کې شتون ولري مګر ممکن د پرمختګ په جریان کې ګټور وي.
///
/// د `debug_assert_eq!` پراخولو پایله تل ډول ډول چیک شوې وي.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ادعا کوي چې دوه څرګندونې یو بل سره مساوي ندي.
///
/// په panic کې ، دا میکرو به د دوی د ډب نمایندګیو سره د څرګندونو ارزښتونه چاپ کړي.
///
/// د [`assert_ne!`] برعکس ، د `debug_assert_ne!` بیانات یوازې د ډیفالټ لخوا په غیر مطلوب جوړښتونو کې فعال شوي.
/// یو مطلوب جوړول به د `debug_assert_ne!` بیانات اجرا نه کړي مګر دا چې `-C debug-assertions` تالیف کونکي ته انتقال شي.
/// دا د چکونو لپاره `debug_assert_ne!` ګټور کوي چې خورا ډیر لګښت لري چې په خپاره شوي جوړښت کې شتون ولري مګر ممکن د پرمختګ په جریان کې ګټور وي.
///
/// د `debug_assert_ne!` پراخولو پایله تل ډول ډول چیک شوې وي.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// راګرځي چې ورکړل شوی څرګندونه له ورکړل شوې ب patternsو سره پرتله کوي.
///
/// د `match` څرګندولو په څیر ، نمونه کولی شي په اختیاري ډول د `if` تعقیب شي او د ساتونکي څرګندونې چې د نمونې سره پابند نومونو ته لاسرسی ولري.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// پایله له سره غورځوي یا خپله تېروتنه تبلیغوي.
///
/// د `?` آپریټر د `try!` ځای په ځای کولو لپاره اضافه شوی او د دې پرځای باید وکارول شي.
/// سربیره پردې ، `try` په Rust 2018 کې خوندي کلمه ده ، نو که تاسو باید دا وکاروئ ، نو تاسو به د [raw-identifier syntax][ris] کارولو ته اړتیا ولرئ: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ورکړل شوي [`Result`] سره پرتله کوي.د `Ok` تغیر په صورت کې ، څرګند د تاپ شوي ارزښت ارزښت لري.
///
/// د `Err` تغیر په صورت کې ، دا داخلي خطا ترلاسه کوي.`try!` بیا د `From` په کارولو سره تبادله ترسره کوي.
/// دا د ځانګړي تیروتنو او ډیرو عامو ترمینځ اتومات تبادله چمتو کوي.
/// پایله شوې غلطي بیا سمدلاسه بیرته راستانه کیږي.
///
/// د مخکیني راستنیدو له امله ، `try!` یوازې په افعال کې کارول کیدی شي چې [`Result`] بیرته راشي.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // د چټک بیرته راستنیدو غلطیو غوره طریقه
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // د ګړندي بیرته راستنیدو تېروتنې پخوانی میتود
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // دا سره برابر دی:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// بفر کې ب formatه شوي معلومات لیکي.
///
/// دا میکرو 'writer' ، د ب stringې سلسله ، او د دلیلونو لیست مني.
/// دلیلونه به د ټاکل شوي فارمیټ تار سره سم شکل شي او پایله به یې لیکوال ته واستول شي.
/// لیکوال ممکن د `write_fmt` میتود سره ارزښت ولري؛عموما دا د [`fmt::Write`] یا [`io::Write`] trait د پلي کولو څخه راځي.
/// میکرو هرڅه د `write_fmt` میتود بیرته راولي؛عموما یو [`fmt::Result`] ، یا یو [`io::Result`].
///
/// د فارمټ سټینګ ترکیب په اړه د نورو معلوماتو لپاره [`std::fmt`] وګورئ.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// یو انډول کولی شي دواړه `std::fmt::Write` او `std::io::Write` وارد کړي او د پلي کولو په اړه `write!` زنګ ووهي ، ځکه چې شیان دواړه عموما دواړه پلي نه کوي.
///
/// په هرصورت ، موډل باید د traits وړتیا وارد کړي نو د دوی نومونه سره ټکر نلري:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // د fmt::Write::write_fmt کاروي
///     write!(&mut v, "s = {:?}", s)?; // د io::Write::write_fmt کاروي
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: دا میکرو د `no_std` ترتیباتو کې هم کارول کیدی شي.
/// په `no_std` ترتیب کې تاسو د اجزاو پلي کولو توضیحاتو مسؤل یاست.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// په بفر کې فارمیټ شوي معلومات ولیکئ ، د نوي لین ضمیمه کولو سره.
///
/// په ټولو پلیټ فارمونو کې ، نوی لاین یوازې د لین فیډ کریکټ (`\n`/`U+000A`) دی (هیڅ اضافي کیریج بیرته نه راوړل (`\r`/`U+000D`).
///
/// د نورو معلوماتو لپاره ، [`write!`] وګورئ.د سټینګ سایټکس فارمیټ معلوماتو لپاره ، [`std::fmt`] وګورئ.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// یو انډول کولی شي دواړه `std::fmt::Write` او `std::io::Write` وارد کړي او د پلي کولو په اړه `write!` زنګ ووهي ، ځکه چې شیان دواړه عموما دواړه پلي نه کوي.
/// په هرصورت ، موډل باید د traits وړتیا وارد کړي نو د دوی نومونه سره ټکر نلري:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // د fmt::Write::write_fmt کاروي
///     writeln!(&mut v, "s = {:?}", s)?; // د io::Write::write_fmt کاروي
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// د لاسرسي وړ کوډ په ګوته کوي.
///
/// دا هر وخت ګټور دی چې تالیف کونکي نشي ټاکل کیدی چې ځینې کوډ د لاسرسي وړ دی.د مثال په توګه:
///
/// * د ساتونکو شرایطو سره وسله لاسته راوړئ.
/// * لوپ چې په متحرک ډول ختمیږي.
/// * سپړونکي چې په متحرک ډول پای ته رسیږي.
///
/// که عزم چې کوډ د لاسرسي وړ نه دی غلط ثابتوي ، برنامه سمدلاسه د [`panic!`] سره پای ته رسیدلی.
///
/// د دې میکرو غیر خوندي همکار د [`unreachable_unchecked`] فنکشن دی ، کوم چې به د کوډ نه رسیدو په صورت کې د نامعلومه چلند لامل شي.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// دا به تل [`panic!`].
///
/// # Examples
///
/// د وسلو برابرول:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // د تالیف کولو تېروتنه که په نښه شوې وي
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // د x/3 بې وزله پلي کول یو
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// د "not implemented" پیغام سره د ډار کولو له لارې بې پلي شوي کوډ په ګوته کوي.
///
/// دا ستاسو کوډ ټایپ چیک ته اجازه ورکوي ، کوم چې ګټور دی که تاسو د trait پروټوټایپ یا پلي کوئ نو ډیری میتودونو ته اړتیا لرئ چې تاسو یې د ټولو کارولو پلان نلرئ.
///
/// د `unimplemented!` او [`todo!`] ترمینځ توپیر دا دی چې پداسې حال کې چې `todo!` وروسته د فعالیت پلي کولو نیت څرګندوي او پیغام یې "not yet implemented" دی ، `unimplemented!` داسې هیڅ ادعا نه کوي.
/// د دې پیغام "not implemented" دی.
/// همدارنګه ځینې IDEs به `todo! mark s په نښه کړي.
///
/// # Panics
///
/// دا به تل [`panic!`] وي ځکه چې `unimplemented!` د یو ټاکل شوي ، ځانګړي پیغام سره د `panic!` لپاره یوازې لنډ لنډ دی.
///
/// د `panic!` په څیر ، دا میکرو د دودیز ارزښتونو ښودلو لپاره دوهمه ب hasه لري.
///
/// # Examples
///
/// ووایو چې موږ یو trait `Foo` لرو:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// موږ د 'MyStruct' لپاره د `Foo` پلي کول غواړو ، مګر د ځینې دلیل لپاره دا یوازې د `bar()` فعالیت پلي کولو لپاره معنی لري.
/// `baz()` او `qux()` به لاهم زموږ د `Foo` پلي کولو کې تعریف کولو ته اړتیا ولري ، مګر موږ کولی شو `unimplemented!` د دوی په تعریفونو کې وکاروو ترڅو زموږ کوډ تالیف کولو ته اجازه ورکړي.
///
/// موږ لاهم غواړو چې زموږ برنامه پرمخ لاړ شي که غیر پلي شوي میتودونو ته ورسیږي.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // دا د `baz` د `MyStruct` لپاره هیڅ احساس نه کوي ، نو موږ دلته هیڅ کوم منطق نلرو.
/////
///         // دا به "thread 'main' panicked at 'not implemented'" ښکاره کړي.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // موږ دلته یو څه منطق لرو ، موږ کولی شو غیر پلي شوي ته پیغام اضافه کړو!زموږ د ورکیدو ښودلو لپاره.
///         // دا به څرګند کړي: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// نابشپړ شوی کوډ په ګوته کوي.
///
/// دا ګټور کیدی شي که تاسو پروټوټایپ کول یاست او یوازې د خپل کوډ ټایپیک کولو په لټه کې یاست.
///
/// د [`unimplemented!`] او `todo!` ترمینځ توپیر دا دی چې پداسې حال کې چې `todo!` وروسته د فعالیت پلي کولو نیت څرګندوي او پیغام یې "not yet implemented" دی ، `unimplemented!` داسې هیڅ ادعا نه کوي.
/// د دې پیغام "not implemented" دی.
/// همدارنګه ځینې IDEs به `todo! mark s په نښه کړي.
///
/// # Panics
///
/// دا به تل [`panic!`].
///
/// # Examples
///
/// دلته د پرمختګ په برخه کې ځینې کوډ مثال دی.موږ یو trait `Foo` لرو:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// موږ غواړو چې زموږ یو ډول باندې `Foo` پلي کړو ، مګر موږ دا هم غواړو چې لومړی په `bar()` کار وکړو.زموږ د کوډ تالیف کولو لپاره ، موږ د `baz()` پلي کولو ته اړتیا لرو ، نو موږ کولی شو `todo!` وکاروو:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // تطبیق دلته دی
///     }
///
///     fn baz(&self) {
///         // راځئ چې د اوس لپاره د baz() پلي کولو په اړه اندیښنه ونکړو
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // موږ حتی baz() نه کاروو ، نو دا ښه دی.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// د جوړ شوي میکروس تعریفونه.
///
/// د میکرو ډیری ملکیتونه (ثبات ، لیدلوری ، او نور) دلته د سرچینې کوډ څخه اخیستل شوي ، د توسعې دندو سربیره پرته له دې چې د ماکرو آثارو محصولاتو ته واړوي ، دا دندې د مرتب کونکي لخوا چمتو شوي.
///
///
pub(crate) mod builtin {

    /// د ورکړل شوي تېروتنې پیغام سره د تالیف د ناکامیدو لامل کیږي کله چې ورسره مخ شي.
    ///
    /// دا میکرو باید وکارول شي کله چې crate د غلط تالیف شرایطو لپاره غوره خطا پیغامونه چمتو کولو لپاره د مشروط تالیف ستراتیژي وکاروي.
    ///
    /// دا د [`panic!`] تالیف کونکي ب formه ده ، مګر د *تالیف* پرځای د *رن ټیم* په وخت کې یوه تېروتنه صادروي.
    ///
    /// # Examples
    ///
    /// دوه ورته مثالونه د مایکروس او `#[cfg]` چاپیریالونه دي.
    ///
    /// د کمپیلر غوره غلطي خارج کړئ که میکرو غیرقانوني ارزښتونو ته انتقال شي.
    /// د وروستي branch پرته ، تالیف کونکي به لاهم یوه ستونزه تېروي ، مګر د غلطۍ پیغام به دوه معتبر ارزښتونه ونه یادوي.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// د کمپیلر غلطي پریږدئ که چیرې یو شمیر ب featuresې شتون ونلري.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// د نورو سټینګ فارمیټ کولو مایکرو لپاره پیرامیټرې رامینځته کوي.
    ///
    /// دا میکرو د هر اضافي دلیل لپاره د `{}` لرونکي فارمیټ سټینګ لغوي نیولو سره فعالیت کوي.
    /// `format_args!` اضافي پیرامیټونه چمتو کوي ترڅو ډاډ ترلاسه کړي چې محصول د تار په توګه تشریح کیدی شي او دلیلونه په یو ډول کې کینینیکي کول.
    /// هر ارزښت چې د [`Display`] trait تطبیقوي `format_args!` ته لیږدول کیدی شي ، لکه څنګه چې د [`Debug`] تطبیق د فارمیټ سټینګ کې دننه `{:?}` ته سپارل کیدی شي.
    ///
    ///
    /// دا میکرو د [`fmt::Arguments`] ډول ارزښت تولیدوي.دا ارزښت به د [`std::fmt`] دننه میکرو ته د ګټور ریډیرکشن ترسره کولو لپاره انتقال شي.
    /// نور ټول فارميټګ میکروس ([[`ب !ه!`] ، [`write!`] ، [`println!`] ، او داسې نور)) د دې یو له لارې تمه کیږي.
    /// `format_args!`, د دې ترلاسه شوي ماکروز برعکس ، د زړو تخصیصونو مخه نیسي.
    ///
    /// تاسو کولی شئ د [`fmt::Arguments`] ارزښت وکاروئ چې `format_args!` په `Debug` او `Display` سیاستوالو کې لکه څنګه چې لاندې لیدل کیږي بیرته راشي.
    /// مثال یې ورته ښیې چې `Debug` او `Display` ب formatه ورته شی ته: په `format_args!` کې د انقباض شوي ب formatه تار.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// د نورو معلوماتو لپاره ، په [`std::fmt`] کې سند وګورئ.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// د `format_args` په څیر ورته ، مګر په پای کې یو نوی لاین اضافه کوي.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// د تالیف په وخت کې د چاپیریال بدلون بدلوي.
    ///
    /// دا میکرو به د کمپیل وخت کې د نومول شوي چاپیریال متغیر ارزښت ته پراختیا ورکړي ، د `&'static str` ډول څرګندوي.
    ///
    ///
    /// که چیرې د چاپیریال بدلون تثبیت نه شي ، نو د تالیف غلطي به خارج شي.
    /// د تالیف خطا ایستلو لپاره نه ، د [`option_env!`] میکرو پرځای وکاروئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// تاسو کولی شئ د خط پیغام د دوهم پیرامیټر په توګه تثبیتولو سره تنظیم کړئ:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// که چیرې د `documentation` چاپیریال بدلون نه وي تعریف شوی ، تاسو به لاندې خطا ترلاسه کړئ:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// په اختیاري توګه د تالیف په وخت کې د چاپیریال متغیر معاینه کوي.
    ///
    /// که چیرې نومول شوی چاپیریال متغیر په مرتب وخت کې شتون ولري ، نو دا به د `Option<&'static str>` ډول ته وګرځي چې ارزښت یې د چاپیریال د بدلیدو ارزښت `Some` دی.
    /// که چیرې د چاپیریال متغیر شتون ونلري ، نو دا به `None` ته پراخه شي.
    /// په دې ډول د نورو معلوماتو لپاره [`Option<T>`][Option] وګورئ.
    ///
    /// د تالیف وخت تېروتنه هیڅکله نه جوړیږي کله چې د دې میکرو کارولو په پام کې ونیول شي پرته لدې چې د چاپیریال بدلون بدلون شتون لري یا نه.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// پیژندونکي په یو شناخت کونکي کې مقابله کوي.
    ///
    /// دا میکرو د کوما څخه جدا شوي پیژندونکي ګ of شمیر نیسي ، او دا ټول یې یو په بل کې راټوليږي ، د څرګندتیا لاسته راوړي کوم چې نوی پیژندونکی دی.
    /// په یاد ولرئ چې حفظ الصحه دا داسې رامینځته کوي چې دا میکرو نشي کولی محلي تغیرات ونیسي.
    /// همچنان ، د عمومي قاعدې په توګه ، میکروس یوازې په توکي ، بیان یا څرګندونې موقعیت کې اجازه لري.
    /// د دې معنی دا ده چې پداسې حال کې چې تاسو ممکن دا میکرو د موجوده متغیرونو ، دندو یا ماډلونو او نورو ته د راجع کولو لپاره وکاروئ ، نو تاسو نشئ کولی د دې سره نوی جوړ کړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn کونټاکټیسټیس (نوي ، ساتیري ، نوم) { }//پدې ډول د کارولو وړ ندي!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// سوځیدنه د جامد تار سلیسونو ته.
    ///
    /// دا میکرو هر ډول کوما څخه جدا شوي سوادونه اخلي ، د `&'static str` ډول څرګندوي چې د ټول سوځیدنې ښیې ښیې څخه تر ښیې ښیې.
    ///
    ///
    /// انټیجر او فلوټینګ پواینټونه د سناتیدلو لپاره تنظیم شوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// لاین شمیري ته پراخیږي په کومه چې دا غوښتل شوې وه.
    ///
    /// د [`column!`] او [`file!`] سره ، دا میکروس د سرچینې دننه موقعیت په اړه پراختیا کونکو لپاره د ډیبګ کولو معلومات چمتو کوي.
    ///
    /// پراخه شوی اظهار د `u32` ډول لري او 1-اساس دی ، نو په هر فایل کې لومړۍ کرښه 1 ته ، دوهم ته 2 ته ارزونه کوي.
    /// دا د عام تالیف کونکو یا مشهور مدیرانو لخوا د غلط پیغامونو سره سم دی.
    /// بیرته راوړل شوی لین *لازمي نه دی* د `line!` بل غوښتنه پخپله ، بلکه د لومړي میکرو غوښتنه چې د `line!` میکرو غوښتنه کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// کالم شمیرو ته غزیدلی په کوم کې چې غوښتل شوی و.
    ///
    /// د [`line!`] او [`file!`] سره ، دا میکروس د سرچینې دننه موقعیت په اړه پراختیا کونکو لپاره د ډیبګ کولو معلومات چمتو کوي.
    ///
    /// پراخه شوی اظهار د `u32` ډول لري او 1-اساس دی ، نو په هره کرښه کې لومړی کالم 1 ته ، دوهم ته 2 ته ارزوي.
    /// دا د عام تالیف کونکو یا مشهور مدیرانو لخوا د غلط پیغامونو سره سم دی.
    /// راستنیدونکی کالم *لازمي نه دی* د `column!` بل غوښتنه پخپله ، بلکه د لومړي میکرو غوښتنه چې د `column!` میکرو غوښتنه کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// د فایل نوم ته پراخه کیږي په کوم کې چې دا غوښتل شوی و.
    ///
    /// د [`line!`] او [`column!`] سره ، دا میکروس د سرچینې دننه موقعیت په اړه پراختیا کونکو لپاره د ډیبګ کولو معلومات چمتو کوي.
    ///
    /// پراخه شوی اظهار د `&'static str` ډول لري ، او بیرته راستانه شوی فایل پخپله د `file!` میکرو غوښتنه نه ده ، بلکه د لومړي میکرو غوښتنه چې د `file!` میکرو غوښتنه کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// د دې دلیلونه پیاوړي کوي.
    ///
    /// دا میکرو به د `&'static str` ډول څرګندوي ترلاسه کړي کوم چې د ټولو tokens تاکید دی چې میکرو ته انتقال شوی.
    /// پخپله د میکرو غوښتنې ترکیب باندې هیڅ محدودیت ندی وضع شوی.
    ///
    /// په یاد ولرئ چې د انبار tokens پراخې پایلې ممکن په future کې بدل شي.تاسو باید محتاط اوسئ که تاسو په محصول تکیه وکړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// د تار په توګه د UTF-8 کوډ شوی فایل شامل دی.
    ///
    /// فایل د اوسني فایل سره سم موقعیت لري (ورته ورته چې ماډلونه څنګه موندل کیږي).
    /// ورکړل شوې لاره د تالیف وخت کې په پلیټ فارم ځانګړي ډول تشریح شوې.
    /// نو ، د مثال په توګه ، د Windows لارې سره بلیکشن د بیکسلایشونو `\` درلودونکی به په Unix کې سم تنظیم نه کړي.
    ///
    ///
    /// دا میکرو به د `&'static str` ډول څرګندوي ترلاسه کړي کوم چې د فایل مینځپانګه ده.
    ///
    /// # Examples
    ///
    /// فرض کړئ چې په ورته لارښود کې د لاندې مینځپانګو سره دوه فایلونه شتون لري:
    ///
    /// فایل 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// فایل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// د 'main.rs' تالیف کول او د نتیجې بائنری چلول به "adiós" چاپ کړي.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// د فایل سرې ته د حوالې په توګه د فایل شامل دي.
    ///
    /// فایل د اوسني فایل سره سم موقعیت لري (ورته ورته چې ماډلونه څنګه موندل کیږي).
    /// ورکړل شوې لاره د تالیف وخت کې په پلیټ فارم ځانګړي ډول تشریح شوې.
    /// نو ، د مثال په توګه ، د Windows لارې سره بلیکشن د بیکسلایشونو `\` درلودونکی به په Unix کې سم تنظیم نه کړي.
    ///
    ///
    /// دا میکرو به د `&'static [u8; N]` ډول څرګندوي ترلاسه کړي کوم چې د فایل مینځپانګه ده.
    ///
    /// # Examples
    ///
    /// فرض کړئ چې په ورته لارښود کې د لاندې مینځپانګو سره دوه فایلونه شتون لري:
    ///
    /// فایل 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// فایل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// د 'main.rs' تالیف کول او د نتیجې بائنری چلول به "adiós" چاپ کړي.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// تار ته غزیدل چې د اوسني ماډل لاره استازیتوب کوي.
    ///
    /// د اوسني ماډل لاره د ماډلونو درجه بندي په توګه فکر کیدی شي چې crate root ته راستون شي.
    /// د راستنیدونکي لارې لومړۍ برخه د crate نوم دی چې اوس مهال ترکیب شوی.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// د تالیف وخت کې د ترتیب بیرغونو د بولین ترکیبونو ارزونه.
    ///
    /// د `#[cfg]` خاصیت سربیره ، دا میکرو چمتو شوی ترڅو د ترتیب بیرغونو د بولین بیان ارزونې ته اجازه ورکړي.
    /// دا اکثرا د لږ نقل کوډ لامل کیږي.
    ///
    /// دې میکرو ته ورکړل شوی ترکیب د [`cfg`] خاصیت ورته ترکیب دی.
    ///
    /// `cfg!`, د `#[cfg]` برعکس ، هیڅ کوډ نه لرې کوي او یوازې ریښتیا یا غلط ته یې ارزونه کوي.
    /// د مثال په توګه ، په if/else اظهار کې ټول بلاکونه باید باوري وي کله چې `cfg!` د حالت لپاره کارول کیږي ، پرته لدې چې د `cfg!` ارزونه کوي.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// د مینځپانګې له مخې یو فایل د بیان یا توکي په توګه تجزیه کوي.
    ///
    /// فایل د اوسني فایل سره سم موقعیت لري (ورته ورته چې ماډلونه څنګه موندل کیږي).ورکړل شوې لاره د تالیف وخت کې په پلیټ فارم ځانګړي ډول تشریح شوې.
    /// نو ، د مثال په توګه ، د Windows لارې سره بلیکشن د بیکسلایشونو `\` درلودونکی به په Unix کې سم تنظیم نه کړي.
    ///
    /// د دې میکرو کارول اکثرا یو بد نظر دی ، ځکه چې که فایل د بیان په توګه تجزیه شوي وي ، نو دا به په غیر صحي توګه شاوخوا کوډ کې ځای په ځای شي.
    /// دا د متغیرو یا افعال پایله کولی شي د فایل له تمې سره توپیر ولري که چیرې تغیرات یا افعال شتون ولري چې په اوسني فایل کې ورته نوم لري.
    ///
    ///
    /// # Examples
    ///
    /// فرض کړئ چې په ورته لارښود کې د لاندې مینځپانګو سره دوه فایلونه شتون لري:
    ///
    /// فایل 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// فایل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// د 'main.rs' تالیف کول او د نتیجې بائنری چلول به "🙈🙊🙉🙈🙊🙉" چاپ کړي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ادعا کوي چې د بولین څرګندونه د وخت په وخت کې `true` وي.
    ///
    /// دا به د [`panic!`] میکرو غوښتنه وکړي که چمتو شوي اظهار په `true` کې په وخت کې ونه ارزول شي.
    ///
    /// # Uses
    ///
    /// ادعاوې تل په دواړه ډبګ او خوشې کولو ودانیو کې چیک کیږي ، او نشي منل کیدلی.
    /// د ادعاوو لپاره [`debug_assert!`] وګورئ چې د ډیفالټ په واسطه په ریلیز جوړښتونو کې ندي فعال شوي.
    ///
    /// غیر خوندي کوډ ممکن د وخت وخت بریدګرو پلي کولو لپاره په `assert!` تکیه وکړي چې ، که سرغړونه کیدی شي د بې کفایتۍ لامل شي.
    ///
    /// د `assert!` نورې کارونې قضیې په خوندي کوډ کې د وخت وخت اشغالګرو ازموینه او پلي کول شامل دي (د هغه سرغړونه نشي کولی بې پایلې پایله ولري).
    ///
    ///
    /// # دودیز پیغامونه
    ///
    /// دا میکرو دوهم ب hasه لري ، چیرې چې د رسمی panic پیغام د فارمیټ لپاره پرته د دلیلونو سره چمتو کیدی شي.
    /// د دې فارم لپاره نحو لپاره [`std::fmt`] وګورئ.
    /// د فارمیټ دلیلونو په توګه کارول شوي څرګندونې به یوازې هغه وخت و ارزول شي چې که ټینګار ناکام شي.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // د دې ادعاوو لپاره panic پیغام د ورکړل شوي بیان قوي ارزښت دی.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // یو ډیر ساده فعالیت
    ///
    /// assert!(some_computation());
    ///
    /// // د دودیز پیغام سره ټینګار وکړئ
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// په انلاین مجلس.
    ///
    /// د کارولو لپاره [unstable book] ولولئ.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// د LLVM-ډول انلاین شورا.
    ///
    /// د کارولو لپاره [unstable book] ولولئ.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// د انډول مجلس ماډل کچه.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// پرنټونو tokens په معیاري محصول کې تېر شو.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// د نورو مایکرو ډیبګ کولو لپاره کارول شوي د ټریګینګ فعالیت وړ یا غیر فعال کوي.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// د مشتق میکرو کارول د مشتق مایکرو پلي کولو لپاره کارول کیږي.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// خاصیت میکرو په فنکشن کې پلي شوی ترڅو دا د واحد ازموینې ته واړوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// خاصیت میکرو په فنکشن کې پلي شوی ترڅو دا د بینچمارک ازموینې ته واړوي.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// د `#[test]` او `#[bench]` میکروس د پلي کولو توضیحات.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// خاصیت میکرو په جامد باندې پلي کړی ترڅو دا د نړیوال تخصیص کونکي په توګه راجستر کړي.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) هم وګورئ.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// هغه توکي ساتي چې ورته پلي کیږي که چیرې تیره شوې لاره د لاسرسي وړ وي ، او بل ډول یې لرې کوي.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// د کوډ ټوټې ټولې `#[cfg]` او `#[cfg_attr]` صفات پراخوي چې ورته پلي کیږي.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// د `rustc` تالیف کونکي غیر پلي کولو توضیحات ، کارول مه کوئ.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// د `rustc` تالیف کونکي غیر پلي کولو توضیحات ، کارول مه کوئ.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}