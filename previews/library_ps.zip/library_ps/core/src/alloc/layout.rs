use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// پداسې حال کې چې دا فنکشن په یو ځای کې کارول شوی او د هغې تطبیق کول دننه کیدلی شي ، د داسې کولو مخکیني هڅې rustc ورو کړی:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// د حافظې د بلاک جوړښت.
///
/// د `Layout` یوه بیلګه د حافظې ځانګړی ترتیب بیانوي.
/// تاسو د `Layout` جوړول د ان پیوټ په توګه تخصیص ورکوونکي ته ورکوئ.
///
/// ټولې ب anې یو اړونده اندازه او د دوه څخه بریښنا برابرونه لري.
///
/// (په یاد ولرئ چې ترتیبونه *د* غیر صفر اندازې ته اړتیا نلري ، پداسې حال کې چې `GlobalAlloc` اړتیا لري چې د حافظې ټولې غوښتنې په اندازه کې صفر نه وي.
/// زنګ وهونکی باید یا دا تضمین کړي چې شرایط ورته پوره کیږي ، د ځانګړو تخصیص کونکو څخه د نرم غوښتنو سره کار واخلئ ، یا ډیر نرم `Allocator` انٹرفیس وکاروئ.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // د حافظې غوښتل شوي بلاک اندازه ، په بایټونو کې اندازه شوی.
    size_: usize,

    // د حافظې غوښتل شوي بلاک سیده ، په بایټونو کې اندازه شوی.
    // موږ ډاډ ترلاسه کوو چې دا تل د دوه څخه بریښنا وي ، ځکه چې د API په څیر `posix_memalign` ورته اړتیا لري او دا د مناسب ترتیب دی چې په ترتیب جوړونکو باندې تحمیل شي.
    //
    //
    // (په هرصورت ، موږ په ورته ډول `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) ته اړتیا نلرو
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// د ورکړل شوي `size` او `align` څخه `Layout` جوړوي ، یا `LayoutError` بیرته ورکوي که لاندې شرایطو څخه هیڅ نه وي پوره شوي:
    ///
    /// * `align` باید صفر نه وي ،
    ///
    /// * `align` باید د دوه قدرت وي
    ///
    /// * `size`, کله چې د `align` ترټولو نږدې ته رسي ، باید جریان نلري (د بیلګې په توګه ، دا ګرد ارزښت باید د `usize::MAX` سره مساوي یا مساوي وي).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (د دوه څخه بریښنا د صف برابرول!=0)

        // د اندازې اندازه یې دا ده:
        //   اندازه_مخه_او==(اندازه + سیده ،))&! (صف ، 1)؛
        //
        // موږ له پورته څخه پوهیږو چې سیده!=0.
        // که اضافه کول (سید ، 1) ډیر نه جریان کیږي ، نو بیا به راټولول به ښه وي.
        //
        // سربیره پردې ، او له سره جوړول! (په سمون ، 1) به یوازې د ټیټ آرډر بیټونه وغواړوي.
        // په دې توګه که چیرې لوی جریان د پیسو سره واقع شي ، او-ماسک نشي کولی دومره جریان کم کړي ترڅو د هغه جریان بیرته پاک کړي.
        //
        //
        // پورته پورتنۍ معنی دا ده چې د لنډیز جریان لپاره معاینه کول دواړه اړین او کافي دي.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // خوندي: د `from_size_align_unchecked` لپاره شرایط وې
        // پورته چیک شوی
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// د ټولو چیکونو سربیره ، یو ترتیب چمتو کوي.
    ///
    /// # Safety
    ///
    /// دا فعالیت غیر محفوظ دی ځکه چې دا له [`Layout::from_size_align`] څخه مخکیني شرطونه نه تاییدوي.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // خوندي: زنګ وهونکی باید ډاډ ترلاسه کړي چې `align` د صفر څخه لوی دی.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// د دې ترتیب د حافظه بلاک لپاره په بایټونو کې لږترلږه اندازه.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// د دې ترتیب د حافظې بلاک لپاره لږترلږه بایټ سیده.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// د `T` ډول ارزښت ساتلو لپاره مناسب `Layout` جوړوي.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // خوندي: سیده د Rust لخوا تضمین کیږي ترڅو د دوه او
        // اندازه + د القاح کامبو زموږ د پتې په ځای کې د فټ کولو تضمین دی.
        // د پایلې په توګه غیر چیک شوی جوړونکی دلته وکاروئ د کوډ داخلولو څخه مخنیوی وکړئ چې panics که چیرې دا په کافي اندازه مطلوب نه وي.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// د ریکارډ تشریح کولو ترتیب چمتو کوي چې د `T` لپاره د ملاتړ جوړښت تخصیص کولو لپاره کارول کیدی شي (کوم چې ZZtrait0Z یا د بل سایټ په څیر نور نه منل شوی ډول کیدی شي).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // خوندي: په `new` کې دلایل وګورئ چې د دې غیر خوندي ب theه کاروي
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// د ریکارډ تشریح کولو ترتیب چمتو کوي چې د `T` لپاره د ملاتړ جوړښت تخصیص کولو لپاره کارول کیدی شي (کوم چې ZZtrait0Z یا د بل سایټ په څیر نور نه منل شوی ډول کیدی شي).
    ///
    /// # Safety
    ///
    /// دا فنکشن یوازې د تلیفون کولو لپاره خوندي دی که لاندې شرایط ولري:
    ///
    /// - که `T` `Sized` وي ، نو دا فنکشن تل د زنګ وهلو لپاره خوندي دی.
    /// - که چیرې د `T` غیر منقوله جوړه وي:
    ///     - یو `isize`، بیا د سلیزې دم اوږدوالی باید یو اړونده انټرژیر وي ، او د *بشپړ ارزښت* اندازه (د متحرک دم اوږدوالی + د احصایوي اندازې سابقه) باید په `isize` کې فټ شي.
    ///     - یو [trait object] ، بیا د نښې وتلی برخه باید د `T` ډول لپاره د نه راحته کولو لخوا اخیستل شوي درست vtable ته ګوته کړي ، او د *ټول ارزښت* اندازه (د متحرک دم اوږدوالي + جامد اندازې سابقه) باید په `isize` کې فټ شي.
    ///
    ///     - یو (unstable) [extern type] ، بیا دا فنکشن تل د زنګ وهلو لپاره خوندي دی ، مګر ممکن panic یا بل ډول غلط ارزښت بیرته راشي ، ځکه چې د بهرني ډول ترتیب نه پیژندل کیږي.
    ///     دا د [`Layout::for_value`] په څیر ورته چلند دی چې د بیروني ډول دم په حواله.
    ///     - بل پلو ، دا په محافظه توګه اجازه نلري چې دا فنکشن ته زنګ ووهي.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // : SAFYY: these we these.. functions functions... .ites........ theler..... .ږ.
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // خوندي: په `new` کې دلایل وګورئ چې د دې غیر خوندي ب theه کاروي
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// یو `NonNull` رامینځته کوي چې دروند وي ، مګر د دې ترتیب لپاره ښه تنظیم شوی.
    ///
    /// په یاد ولرئ چې د نښې ارزښت ممکن په احتمالي توګه یو درست ټکي ښودونکی وي ، پدې معنی چې دا باید د "not yet initialized" لیږل شوي ارزښت په توګه ونه کارول شي.
    /// ډولونه چې په اسانۍ سره تخصیص کیږي باید د ځینې نورو وسیلو په مرسته ابتکار تعقیب کړي.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // خوندي: سید صفر د نه صفر کیدو تضمین دی
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// د ریکارډ تشریح کولو یوه ب .ه رامینځته کوي چې د ورته ترتیب اندازه د `self` په توګه ساتلی شي ، مګر دا هم د `align` (بایټونو کې اندازه شوي) سره د همغږۍ سره سمون لري.
    ///
    ///
    /// که `self` دمخه وړاندیز شوی صف پوره کوي ، نو بیا `self` بیرته راوړي.
    ///
    /// په یاد ولرئ چې دا میتود په مجموعي اندازې کې هیڅ توکی نه اضافه کوي ، پرته لدې پرته چې بیرته راستنیدونکی توپیر لري.
    /// په بل عبارت ، که `K` اندازه 16 وي ، نو `K.align_to(32)` به *لاهم* اندازه 16 ولري.
    ///
    /// یوه تېروتنه راستنوي که چیرې د `self.size()` او ورکړل شوي `align` ترکیب په [`Layout::from_size_align`] کې درج شوي شرایطو څخه سرغړونه وکړي.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// د پیډینګ مقدار بیرته راوړي چې موږ یې باید د `self` وروسته دننه کړو ترڅو ډاډ ترلاسه شي چې لاندې پته به `align` پوره کړي (په بایټونو کې اندازه کیږي).
    ///
    /// د مثال په توګه ، که `self.size()` 9 وي ، نو بیا `self.padding_needed_for(4)` 3 بیرته راګرځوي ، ځکه چې دا د 4 قطع شوي پته ترلاسه کولو لپاره اړین د پیډینګ لږترلږه بایټس شمیره ده (فرض کړئ چې دا اړونده حافظه بلاک د 4-تنظیم شوي پته څخه پیل کیږي).
    ///
    ///
    /// د دې فنکشن بیرته ستنیدو ارزښت هیڅ معنی نلري که `align` د دوه څخه بریښنا نه وي.
    ///
    /// په یاد ولرئ چې د بیرته راستنیدونکي ارزښت کارول د `align` څخه غواړي چې د حافظې ټول مختص شوي بلاک لپاره د پیل پته د سمونې سره لږ یا مساوي وي.د دې خنډونو پوره کولو یوه لاره د `align <= self.align()` ډاډ ترلاسه کول دي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // د ارزښت ارزښت:
        //   len_rounded_up=(len + align، 1)&! (align، 1)؛
        // او بیا موږ د پیډینګ توپیر بیرته راوړو: `len_rounded_up - len`.
        //
        // موږ په اوږدو کې ماډلر ریاضي کاروو:
        //
        // 1. سمون د 0 0 تضمین دی ، نو قطار ، 1 تل معتبر دی.
        //
        // 2.
        // `len + align - 1` کیدی شي د حد اکثر `align - 1` لخوا تیریږي ، نو د `!(align - 1)` سره&ماسک به ډاډ ترلاسه کړي چې د ډیر جریان په حالت کې ، `len_rounded_up` پخپله 0 وي.
        //
        //    پدې توګه بیرته راوړل شوې ګنډنه ، کله چې په `len` کې اضافه شي ، 0 لاسته راوړي ، کوم چې په متناسب ډول د ساحې `align` خوښوي.
        //
        // (البته ، د حافظې د بلاکونو تخصیص کولو هڅې چې په پورتني طریقه کې د اندازې او ګړندي جریان باید د تخصیص لامل شي چې بیا هم غلطي رامینځته کړي.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// د دې ترتیب اندازې څو کچې د ترتیب تنظیم کولو ته تنظیم ورکولو ترتیب چمتو کوي.
    ///
    ///
    /// دا د ترتیب اوسني اندازې ته د `padding_needed_for` پایله اضافه کولو سره مساوي ده.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // دا ډیر نشي.د برید کوونکی برید کونکي حواله کول:
        // > `size`, کله چې د `align` ترټولو نږدې ته رسي
        // > باید زیات نه وی (د مثال په توګه ، ارزښت لرونکی ارزښت باید له دې څخه ټیټ وي
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// د `self` مثالونو لپاره د `n` مثالونو لپاره ریکارډ تشریح کولو یوه ب layoutه رامینځته کوي ، د هر یو تر مینځ مناسب پیډینګ سره ترڅو ډاډ ترلاسه شي چې هر مثال ورته غوښتل شوی اندازه او صف برابر شوی.
    /// په بریا سره ، `(k, offs)` بیرته راوړي چیرې چې `k` د صفونو ترتیب دی او `offs` په صف کې د هر عنصر د پیل ترمینځ فاصله ده.
    ///
    /// د ریاضیاتو په جریان کی ، `LayoutError` بیرته راځی.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // دا ډیر نشي.د برید کوونکی برید کونکي حواله کول:
        // > `size`, کله چې د `align` ترټولو نږدې ته رسي
        // > باید زیات نه وی (د مثال په توګه ، ارزښت لرونکی ارزښت باید له دې څخه ټیټ وي
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // خوندي: self.align دمخه د اعتبار وړ پیژندل شوی او تخصیص_جوړول شوی
        // لا دمخه
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// د `self` لپاره د ریکارډ تشریح کولو یوه ب layoutه رامینځته کوي ، په تعقیب د `next` ، د اړین اړین ګنډو پشمول پدې کې چې ډاډ ترلاسه کړي چې `next` به په سمه توګه سمون ولري ، مګر *هیڅ تیریدونکی نالی*.
    ///
    /// د C نمایندګي ترتیب `repr(C)` سره مل کولو لپاره ، تاسو باید د ټولو برخو سره د ترتیب غزولو وروسته `pad_to_align` زنګ ووهئ.
    /// (د Rust نمایندګي ترتیب `repr(Rust)`, as it is unspecified.) سره مل کولو لپاره هیڅ لاره شتون نلري
    ///
    /// په یاد ولرئ چې د نتیجې ترتیب به د `self` او `next` د اعظمي حد څخه وي ، ترڅو د دواړو برخو سمون ډاډمن شي.
    ///
    /// `Ok((k, offset))` راګرځوي ، چیرې چې `k` د کانټینټ شوي ریکارډ ترتیب دی او `offset` د `next` د پیل مرحله د کانټینټ شوي ریکارډ دننه سایټ ده (فرض کړئ چې ریکارډ پخپله د آفسیټ 0 څخه پیل کیږي).
    ///
    ///
    /// د ریاضیاتو په جریان کی ، `LayoutError` بیرته راځی.
    ///
    /// # Examples
    ///
    /// د `#[repr(C)]` جوړښت ترتیب او د دې ساحو له ترتیب څخه د ساحو آفسیټ محاسبه کولو لپاره:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // د `pad_to_align` سره نهایی کول یاد وساتئ!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // ازموینه وکړئ چې دا کار کوي
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// د `self` مثالونو لپاره د `n` مثالونو لپاره ریکارډ تشریح کولو یوه ب Creه رامینځته کوي ، د هرې بیلګې په مینځ کې هیڅ ګیډۍ پرته.
    ///
    /// په یاد ولرئ ، د `repeat` برعکس ، `repeat_packed` تضمین نه کوي چې د `self` تکرار مثالونه به په سمه توګه سمون ولري ، حتی که د `self` بیلګه په سمه توګه هملته وي.
    /// په بل عبارت ، که چیرې د `repeat_packed` لخوا بیرته راوتلی ترتیب د صف د تخصیص لپاره وکارول شي ، نو تضمین نلري چې په صف کې ټول عناصر به په سم ډول تنظیم شي.
    ///
    /// د ریاضیاتو په جریان کی ، `LayoutError` بیرته راځی.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// د `self` لپاره د ریکارډ تشریح کولو یوه ب layoutه رامینځته کوي له دې وروسته د `next` تعقیب د دواړو تر مینځ اضافي اضافه کولو پرته.
    /// لدې چې هیڅ پیډینګ ندی داخل شوی ، نو د `next` الینینګ غیر معقول دی ، او *په ټول* کې * په ترتیب ترتیب کې نه دی شامل شوی.
    ///
    ///
    /// د ریاضیاتو په جریان کی ، `LayoutError` بیرته راځی.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// د `[T; n]` لپاره ریکارډ تشریح کولو یوه ب .ه رامینځته کوي.
    ///
    /// د ریاضیاتو په جریان کی ، `LayoutError` بیرته راځی.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// د `Layout::from_size_align` یا کوم بل `Layout` جوړونکي ته ورکړل شوي پیرامیټرې د دې مستند شوي محدودیتونه نه پوره کوي.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (موږ دې د trait غلطي د غورځېدلو هڅونې لپاره اړتیا لرو)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}