//! د حافظې تخصیص API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// د `AllocError` غلطي د تخصیص ناکامي په ګوته کوي چې ممکن د سرچینې ستړیا له امله وي یا یو څه غلط وي کله چې د دې تخصیص کونکي سره ورکړل شوي آخذې دلیلونو ترکیب کول وي.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (موږ دې د trait غلطي د غورځېدلو هڅونې لپاره اړتیا لرو)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// د `Allocator` پلي کول کولی شي د [`Layout`][] له لارې توضیح شوي ارقام بلاکونه اختصاص ، وده ، کمیدل او له مینځه ویسي.
///
/// `Allocator` په ZSTs ، حوالې ، یا سمارټ پوینټرونو کې پلي کولو لپاره ډیزاین شوی ځکه چې د `MyAlloc([u8; N])` په څیر تخصیص درلودل نشي حرکت کولی ، پرته له دې چې تخصیص شوي حافظې ته د نښو تازه کولو څخه.
///
/// د [`GlobalAlloc`][] برعکس ، په `Allocator` کې د صفر اندازې تخصیصونو ته اجازه ورکول کیږي.
/// که چیرې اساس تخصیص کونکي د دې ملاتړ ونه کړي (جیمالاک په څیر) یا نال پوائنټر بیرته راوړي (لکه `libc::malloc`) ، دا باید د تطبیق لخوا ونیول شي.
///
/// ### اوس مهال تخصیص شوی حافظه
///
/// ځینې میتودونه اړتیا لري چې د حافظې بلاک * دا مهال د تخصیص کونکي له لارې وټاکل شي.دا پدې مانا ده چې:
///
/// * د دې حافظې بلاک لپاره د پیل پته مخکې د [`allocate`] ، [`grow`] ، یا [`shrink`] ، او لخوا بیرته راستانه شوي
///
/// * د حافظې بلاک بیا وروسته له پامه غورځول شوی نه دی ، چیرې چې بلاکونه یا د [`deallocate`] ته په مستقیم ډول لیږدول شوي یا د [`grow`] یا [`shrink`] ته په تیریدو سره بدل شوي چې `Ok` بیرته راولي.
///
/// که چیرې `grow` یا `shrink` `Err` بیرته راستانه کړي ، نو تیره شوې اشاره باوري پاتې کیږي.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### د حافظې فټینګ
///
/// ځینې میتودونه اړتیا لري چې ترتیب د حافظې بلاک *مناسب* کړي.
/// څه چې دا د "fit" د ترتیب کولو لپاره د حافظې بلاک معنی لري (یا مساوي د "fit" ته د حافظې بلاک لپاره یوه ترتیب) دا دی چې لاندې شرایط باید ولري:
///
/// * بلاک باید د ورته قطار سره د [`layout.align()`] په توګه تخصیص شي ، او
///
/// * ورکړل شوي [`layout.size()`] باید د `min ..= max` لړ کې راښکته شي ، چیرې چې:
///   - `min` د هغه شکل کچه ده چې په دې وروستیو کې د بلاک د تخصیص لپاره کارول شوې ، او
///   - `max` د [`allocate`] ، [`grow`] ، یا [`shrink`] څخه راستن شوی وروستی اصلی اندازه ده.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * د تخصیص کونکي څخه یاد شوي بلاکونه باید باوري حافظې ته اشاره وکړي او د اعتبار موده یې وساتي تر هغه چې مثال او د هغې ټول کلونونه له مینځه وی ،
///
/// * د تخصیص کونکي کول یا حرکت کول باید د دې اختصاص څخه بیرته راګرځیدلي حافظې بلاکونه باطله نکړي.یو کلون شوی اختصاص کونکی باید د ورته تخصیص کونکي په څیر چلند وکړي ، او
///
/// * د حافظې بلاک ته کوم نښه چې [*currently allocated*] وي ممکن د تخصیین کومې بلې میتود ته واستول شي.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// د حافظې د بلاک مختص کولو هڅې.
    ///
    /// په بریا سره ، د `layout` اندازه او د تضمین تضمینونو سره ناسته کوي [`NonNull<[u8]>`][NonNull] راستنوي.
    ///
    /// راستنیدونکی بلاک ممکن د `layout.size()` لخوا مشخص شوي اندازې څخه لوی اندازه ولري ، او ممکن ممکن د هغې مینځپانګه پیل نه وي.
    ///
    /// # Errors
    ///
    /// د `Err` بیرته راستنیدل په ګوته کوي چې یا خو حافظه ختمه شوې ده یا `layout` د تخصیص اندازه یا د سمون خنډونه نه پوره کوي.
    ///
    /// تطبیق هڅول کیږي د `Err` بیرته راستنیدو په حافظه د ستړیا پرځای د ویرې کولو یا تیښتي پرځای ، مګر دا سخت اړتیا نلري.
    /// (په ځانګړي توګه: دا د قانوني ډول دی چې د دې trait پلي کول د اصلي تخصیص کتابتون څخه پورته چې د حافظې ستړیا بندوي.)
    ///
    /// هغه مراجعین چې د تخصیص خطا په ځواب کې د کمپیوټري ضایع کیدو غوښتونکي دي د [`handle_alloc_error`] فنکشن ته هڅول کیږي ، د دې پرځای چې په مستقیم ډول د `panic!` یا ورته غوښتنه وکړي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// د `allocate` په څیر چلند کوي ، مګر دا هم تضمینوي چې بیرته راستانه شوي حافظه صفر پیل شوې.
    ///
    /// # Errors
    ///
    /// د `Err` بیرته راستنیدل په ګوته کوي چې یا خو حافظه ختمه شوې ده یا `layout` د تخصیص اندازه یا د سمون خنډونه نه پوره کوي.
    ///
    /// تطبیق هڅول کیږي د `Err` بیرته راستنیدو په حافظه د ستړیا پرځای د ویرې کولو یا تیښتي پرځای ، مګر دا سخت اړتیا نلري.
    /// (په ځانګړي توګه: دا د قانوني ډول دی چې د دې trait پلي کول د اصلي تخصیص کتابتون څخه پورته چې د حافظې ستړیا بندوي.)
    ///
    /// هغه مراجعین چې د تخصیص خطا په ځواب کې د کمپیوټري ضایع کیدو غوښتونکي دي د [`handle_alloc_error`] فنکشن ته هڅول کیږي ، د دې پرځای چې په مستقیم ډول د `panic!` یا ورته غوښتنه وکړي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // خوندي: `alloc` د باوري حافظې بلاک بیرته راولي
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// د `ptr` لخوا حواله شوی حافظه ضایع کوي.
    ///
    /// # Safety
    ///
    /// * `ptr` د دې مختص کونکي له لارې باید د [*currently allocated*] حافظې بلاک په نښه کړي
    /// * `layout` د [*fit*] باید د حافظې مخه ونیسي.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// د حافظې بلاک پراخولو لپاره هڅې.
    ///
    /// یو نوی [`NonNull<[u8]>`][NonNull] راستنوي چې پکې یو پوائنټور او د ورکړل شوي حافظې اصلي اندازې لري.پوائنټر د `new_layout` لخوا بیان شوي معلوماتو ساتلو لپاره مناسب دی.
    /// د دې د ترسره کولو لپاره ، تخصیص کونکي ممکن د نوي ترتیب فټ کولو لپاره د `ptr` لخوا راجع شوي تخصیص وغزوي.
    ///
    /// که دا `Ok` بیرته راشي ، نو د `ptr` لخوا راجع شوي د یاد بلاک ملکیت دې اختصاص کونکي ته سپارل شوی.
    /// حافظه ممکن یا خوشې شوې وي ، او باید د کارونې وړ ونه ګ unlessل شي پرته لدې چې د دې میتود بیرته راستنیدو ارزښت له لارې بیرته زنګ وهونکي ته لیږدول شوي وي.
    ///
    /// که دا طریقه `Err` بیرته راشي ، نو بیا د حافظې بلاک ملکیت دې تخصیص کونکي ته نه دی لیږدول شوی ، او د حافظه بلاک مینځپانګې غیر منظم دي.
    ///
    /// # Safety
    ///
    /// * `ptr` د دې اختصاق له لارې باید د [*currently allocated*] حافظې بلاک په نښه شي.
    /// * `old_layout` باید [*fit*] چې د حافظې مخه ونیسي (د `new_layout` دلیل اړتیا نلري.).
    /// * `new_layout.size()` باید د `old_layout.size()` څخه لوی یا مساوي وي.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` راګرځوي که نوې ترتیب د تخصیص اندازه او د تخصیص تنظیم کولو خنډونه پوره نه کړي ، یا که وده نوره هم ناکامه شي.
    ///
    /// تطبیق هڅول کیږي د `Err` بیرته راستنیدو په حافظه د ستړیا پرځای د ویرې کولو یا تیښتي پرځای ، مګر دا سخت اړتیا نلري.
    /// (په ځانګړي توګه: دا د قانوني ډول دی چې د دې trait پلي کول د اصلي تخصیص کتابتون څخه پورته چې د حافظې ستړیا بندوي.)
    ///
    /// هغه مراجعین چې د تخصیص خطا په ځواب کې د کمپیوټري ضایع کیدو غوښتونکي دي د [`handle_alloc_error`] فنکشن ته هڅول کیږي ، د دې پرځای چې په مستقیم ډول د `panic!` یا ورته غوښتنه وکړي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // خوندي: ځکه چې `new_layout.size()` باید د دې څخه لوی وي یا مساوي وي
        // `old_layout.size()`, د زاړه او نوي حافظې تخصیص دواړه د `old_layout.size()` بیتونو لپاره د لوستلو او لیکلو لپاره معتبر دي.
        // همچنان ، ځکه چې زاړه تخصیص لاهم ضایع شوی نه و ، نو دا نشي کولی `new_ptr` پراخه کړي.
        // پدې توګه ، `copy_nonoverlapping` ته زنګ خوندي دی.
        // د `dealloc` لپاره د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// د `grow` په څیر چلند کوي ، مګر دا هم تضمینوي چې نوي مینځپانګې بیرته راستنیدو دمخه صفر ته تنظیم شوي وي.
    ///
    /// د حافظې بلاک به د بریالي زنګ څخه وروسته لاندې مینځپانګې ولري
    /// `grow_zeroed`:
    ///   * بایټس `0..old_layout.size()` د اصلي تخصیص څخه خوندي دي.
    ///   * بایټس `old_layout.size()..old_size` به یا د محافظت یا صفر شي ، د تخصیص پلي کولو پورې اړه لري.
    ///   `old_size` د `grow_zeroed` تلیفون دمخه د حافظې بلاک اندازې ته اشاره کوي ، کوم چې ممکن د اندازې څخه لوی وي چې په اصل کې غوښتنه شوې وه کله چې تخصیص ورکړل شوی و.
    ///   * بایټ `old_size..new_size` صفر شوي.`new_size` د `grow_zeroed` زنګ لخوا بیرته راستانه شوي حافظې بلاک اندازې ته اشاره کوي.
    ///
    /// # Safety
    ///
    /// * `ptr` د دې اختصاق له لارې باید د [*currently allocated*] حافظې بلاک په نښه شي.
    /// * `old_layout` باید [*fit*] چې د حافظې مخه ونیسي (د `new_layout` دلیل اړتیا نلري.).
    /// * `new_layout.size()` باید د `old_layout.size()` څخه لوی یا مساوي وي.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` راګرځوي که نوې ترتیب د تخصیص اندازه او د تخصیص تنظیم کولو خنډونه پوره نه کړي ، یا که وده نوره هم ناکامه شي.
    ///
    /// تطبیق هڅول کیږي د `Err` بیرته راستنیدو په حافظه د ستړیا پرځای د ویرې کولو یا تیښتي پرځای ، مګر دا سخت اړتیا نلري.
    /// (په ځانګړي توګه: دا د قانوني ډول دی چې د دې trait پلي کول د اصلي تخصیص کتابتون څخه پورته چې د حافظې ستړیا بندوي.)
    ///
    /// هغه مراجعین چې د تخصیص خطا په ځواب کې د کمپیوټري ضایع کیدو غوښتونکي دي د [`handle_alloc_error`] فنکشن ته هڅول کیږي ، د دې پرځای چې په مستقیم ډول د `panic!` یا ورته غوښتنه وکړي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // خوندي: ځکه چې `new_layout.size()` باید د دې څخه لوی وي یا مساوي وي
        // `old_layout.size()`, د زاړه او نوي حافظې تخصیص دواړه د `old_layout.size()` بیتونو لپاره د لوستلو او لیکلو لپاره معتبر دي.
        // همچنان ، ځکه چې زاړه تخصیص لاهم ضایع شوی نه و ، نو دا نشي کولی `new_ptr` پراخه کړي.
        // پدې توګه ، `copy_nonoverlapping` ته زنګ خوندي دی.
        // د `dealloc` لپاره د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// د حافظې بلاک د راکمولو هڅې.
    ///
    /// یو نوی [`NonNull<[u8]>`][NonNull] راستنوي چې پکې یو پوائنټور او د ورکړل شوي حافظې اصلي اندازې لري.پوائنټر د `new_layout` لخوا بیان شوي معلوماتو ساتلو لپاره مناسب دی.
    /// د دې بشپړولو لپاره ، تخصیص کونکي ممکن د `ptr` لخوا راجع شوې تخصیص لنډ کړي ترڅو د نوي ترتیب مناسب شي.
    ///
    /// که دا `Ok` بیرته راشي ، نو د `ptr` لخوا راجع شوي د یاد بلاک ملکیت دې اختصاص کونکي ته سپارل شوی.
    /// حافظه ممکن یا خوشې شوې وي ، او باید د کارونې وړ ونه ګ unlessل شي پرته لدې چې د دې میتود بیرته راستنیدو ارزښت له لارې بیرته زنګ وهونکي ته لیږدول شوي وي.
    ///
    /// که دا طریقه `Err` بیرته راشي ، نو بیا د حافظې بلاک ملکیت دې تخصیص کونکي ته نه دی لیږدول شوی ، او د حافظه بلاک مینځپانګې غیر منظم دي.
    ///
    /// # Safety
    ///
    /// * `ptr` د دې اختصاق له لارې باید د [*currently allocated*] حافظې بلاک په نښه شي.
    /// * `old_layout` باید [*fit*] چې د حافظې مخه ونیسي (د `new_layout` دلیل اړتیا نلري.).
    /// * `new_layout.size()` د `old_layout.size()` څخه کوچنی یا مساوي باید وي.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` راګرځوي که نوې ترتیب د تخصیص اندازه او د تخصیص تنظیم کولو خنډونه پوره نه کړي ، یا که راښکته شي نو ناکام کیږي.
    ///
    /// تطبیق هڅول کیږي د `Err` بیرته راستنیدو په حافظه د ستړیا پرځای د ویرې کولو یا تیښتي پرځای ، مګر دا سخت اړتیا نلري.
    /// (په ځانګړي توګه: دا د قانوني ډول دی چې د دې trait پلي کول د اصلي تخصیص کتابتون څخه پورته چې د حافظې ستړیا بندوي.)
    ///
    /// هغه مراجعین چې د تخصیص خطا په ځواب کې د کمپیوټري ضایع کیدو غوښتونکي دي د [`handle_alloc_error`] فنکشن ته هڅول کیږي ، د دې پرځای چې په مستقیم ډول د `panic!` یا ورته غوښتنه وکړي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // خوندي: ځکه چې `new_layout.size()` باید د دې څخه ټیټ یا مساوي وي
        // `old_layout.size()`, د زاړه او نوي حافظې تخصیص دواړه د `new_layout.size()` بیتونو لپاره د لوستلو او لیکلو لپاره معتبر دي.
        // همچنان ، ځکه چې زاړه تخصیص لاهم ضایع شوی نه و ، نو دا نشي کولی `new_ptr` پراخه کړي.
        // پدې توګه ، `copy_nonoverlapping` ته زنګ خوندي دی.
        // د `dealloc` لپاره د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// د `Allocator` دې مثال لپاره د "by reference" اډاپټر رامینځته کوي.
    ///
    /// بیرته ورکړل شوی اډیپټر هم `Allocator` تطبیقوي او په ساده ډول به دا پور واخلي.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // خوندي: د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // خوندي: د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // خوندي: د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // خوندي: د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}