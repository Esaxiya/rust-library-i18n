//! تالیف کونکي توکي.
//!
//! اړوند تعریفونه په `compiler/rustc_codegen_llvm/src/intrinsic.rs` کې دي.
//! اړونده قرارد پلي کول په `compiler/rustc_mir/src/interpret/intrinsics.rs` کې دي
//!
//! # رغښت داخلي
//!
//! Note: د ژبني ټکو سره هر ډول بدلون باید د ژبې له ټیم سره تر بحث لاندې ونیول شي.
//! پدې کې د ثبات ثبات کې بدلونونه شامل دي.
//!
//! د تالیف وخت کې د داخلي کارولو وړ کولو لپاره ، یو څوک اړتیا لري چې پلي کول یې د <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> څخه `compiler/rustc_mir/src/interpret/intrinsics.rs` ته کاپي کړي او په X کې دننه "foo" اضافه کړي.
//!
//!
//! که چیرې یو انټرنیسیک د `const fn` څخه د `rustc_const_stable` خاصیت سره وکارول شي ، نو د انټرنیټک خاصیت باید هم `rustc_const_stable` وي.
//! دا ډول بدلون باید د T-lang مشورې پرته ترسره نشي ، ځکه چې دا ژبه ته ب intoه کوي چې د تالیف کونکي ملاتړ پرته د کارونکي کوډ کې تکرار نشي.
//!
//! # Volatiles
//!
//! خوځنده داخلي فعالیتونه د I/O حافظې باندې عمل کولو لپاره چمتو کوي ، کوم چې تضمین کیږي چې د نورو تاکتیک انترنیتونو کې د تالیف کونکي لخوا تنظیم نشي.په [[volatile]] کې د LLVM اسناد وګورئ.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! اټومي انترنیکونه د ماشین په ټکو کې عام اټومي عملیات چمتو کوي ، د ډیری ممکنه حافظې ترتیب سره.دوی د ورته ژبپوهنې اطاعت کوي لکه C++ 11.په [[atomics]] کې د LLVM اسناد وګورئ.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! د حافظې په ترتیب کولو یو نوی تازه شوی:
//!
//! * ترلاسه کړئ ، د لاک ترلاسه کولو لپاره یو خنډ.ورپسې لوستل او لیکل د خنډ وروسته ترسره کیږي.
//! * خوشې کول ، د لاک خوشې کولو لپاره یو خنډ.مخکې لوستل او لیکل د خنډ څخه دمخه ترسره کیږي.
//! * په ترتیب سره مستقل ، په ترتیب ډول متقابل عملیات په ترتیب سره پیښ شوي تضمین دي.دا د اټوم ډولونو سره کار کولو لپاره معیاري حالت دی او د Java د `volatile` سره مساوي دی.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// دا واردات د انټرا-ډاک لینکونو ساده کولو لپاره کارول کیږي
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // خوندي: `ptr::drop_in_place` وګورئ
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB ، دا انتنونه خام نښې اخلي ځکه چې دا د ایلیس شوي حافظې سره بدلون کوي ، کوم چې د `&` یا `&mut` لپاره معتبر ندي.
    //

    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange` میتود له لارې د [`Ordering::SeqCst`] په واسطه د `success` او `failure` پیرامیټونو دواړو په توګه د [`atomic`] ډولونو کې شتون لري.
    ///
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange` میتود له لارې د [`Ordering::Acquire`] په واسطه د `success` او `failure` پیرامیټونو دواړو په توګه د [`atomic`] ډولونو کې شتون لري.
    ///
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange` میتود له لارې د X0XX ډولونو له لارې د [`Ordering::Release`] او `failure` په توګه د `failure` پیرامیټونو په واسطه د [`atomic`] X ډولونو له لارې په [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange` میتود له لارې د X0XX ډولونو له لارې د [`Ordering::AcqRel`] او `failure` په توګه د `failure` پیرامیټونو په واسطه د [`atomic`] X ډولونو له لارې په [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange` میتود له لارې د [`Ordering::Relaxed`] په واسطه د `success` او `failure` پیرامیټونو دواړو په توګه د [`atomic`] ډولونو کې شتون لري.
    ///
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange` میتود له لارې د X0XX ډولونو له لارې د [`Ordering::SeqCst`] او `failure` په توګه د `failure` پیرامیټونو په واسطه د [`atomic`] X ډولونو له لارې په [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د `compare_exchange` میتود له لارې د [`Ordering::SeqCst`] په توګه د `success` او [`Ordering::Acquire`] په توګه د `failure` پیرامیټونو په واسطه د X0XX میتود له لارې د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د `compare_exchange` میتود له لارې د X0XX ډولونو لخوا د `success` او [`Ordering::Relaxed`] په توګه د `failure` پیرامیټونو په واسطه د X0XX میتودونو له لارې د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د `compare_exchange` میتود له لارې د X0XX ډولونو لخوا د `success` او [`Ordering::Relaxed`] په توګه د `failure` پیرامیټونو په واسطه د X0XX میتودونو له لارې د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د [`Ordering::SeqCst`] په واسطه د `success` او `failure` پیرامیټونو دواړو په توګه د [`atomic`] ډولونو کې شتون لري.
    ///
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د [`Ordering::Acquire`] په واسطه د `success` او `failure` پیرامیټونو دواړو په توګه د [`atomic`] ډولونو کې شتون لري.
    ///
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د X0XX ډولونو له لارې د [`Ordering::Release`] او `failure` په توګه د `failure` پیرامیټونو په واسطه د [`atomic`] X ډولونو له لارې په [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د `compare_exchange_weak` میتود له لارې د [`Ordering::AcqRel`] په توګه د `success` او [`Ordering::Acquire`] په توګه د `failure` پیرامیټونو په واسطه د X0XX میتود له لارې د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د [`Ordering::Relaxed`] په واسطه د `success` او `failure` پیرامیټونو دواړو په توګه د [`atomic`] ډولونو کې شتون لري.
    ///
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د [`Ordering::SeqCst`] په توګه د `success` او `failure` په توګه د `failure` پیرامیټونو په واسطه د X0 [`Ordering::Relaxed`] میتود له لارې د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د X0XX ډولونو له لارې د [`Ordering::SeqCst`] او `failure` په توګه د `failure` پیرامیټونو په واسطه د [`atomic`] X ډولونو له لارې په [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د X0XX ډولونو له لارې د [`Ordering::Acquire`] او `failure` په توګه د `failure` پیرامیټونو په واسطه د [`atomic`] X ډولونو له لارې په [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// یو ارزښت ذخیره کوي که چیرې اوسنی ارزښت د `old` ارزښت سره ورته وي.
    ///
    /// د دې داخلي ثبات نسخه د `compare_exchange_weak` میتود له لارې د X0XX ډولونو له لارې د [`Ordering::AcqRel`] او `failure` په توګه د `failure` پیرامیټونو په واسطه د [`atomic`] X ډولونو له لارې په [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// د نغدي اوسنی ارزښت پورته کوي.
    ///
    /// د دې داخلي ثبات نسخه د `load` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// د نغدي اوسنی ارزښت پورته کوي.
    ///
    /// د دې داخلي ثبات نسخه د `load` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// د نغدي اوسنی ارزښت پورته کوي.
    ///
    /// د دې داخلي ثبات نسخه د `load` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// ارزښت په ټاکل شوي حافظه ځای کې ساتي.
    ///
    /// د دې داخلي ثبات نسخه د `store` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// ارزښت په ټاکل شوي حافظه ځای کې ساتي.
    ///
    /// د دې داخلي ثبات نسخه د `store` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// ارزښت په ټاکل شوي حافظه ځای کې ساتي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] ډولونو په واسطه د `store` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// ارزښت په ټاکل شوي حافظه ځای کې زیرمه کوي ، زاړه ارزښت بیرته راستانه کوي.
    ///
    /// د دې داخلي ثبات نسخه د `swap` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// ارزښت په ټاکل شوي حافظه ځای کې زیرمه کوي ، زاړه ارزښت بیرته راستانه کوي.
    ///
    /// د دې داخلي ثبات نسخه د `swap` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ارزښت په ټاکل شوي حافظه ځای کې زیرمه کوي ، زاړه ارزښت بیرته راستانه کوي.
    ///
    /// د دې داخلي ثبات نسخه د `swap` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ارزښت په ټاکل شوي حافظه ځای کې زیرمه کوي ، زاړه ارزښت بیرته راستانه کوي.
    ///
    /// د دې داخلي ثبات نسخه د `swap` میتود له لارې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ارزښت په ټاکل شوي حافظه ځای کې زیرمه کوي ، زاړه ارزښت بیرته راستانه کوي.
    ///
    /// د دې داخلي ثبات نسخه د `swap` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// اوسني ارزښت ته اضافه کوي ، پخوانی ارزښت بیرته راګرځوي.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_add` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// اوسني ارزښت ته اضافه کوي ، پخوانی ارزښت بیرته راګرځوي.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_add` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// اوسني ارزښت ته اضافه کوي ، پخوانی ارزښت بیرته راګرځوي.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_add` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// اوسني ارزښت ته اضافه کوي ، پخوانی ارزښت بیرته راګرځوي.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_add` میتود له لارې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// اوسني ارزښت ته اضافه کوي ، پخوانی ارزښت بیرته راګرځوي.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_add` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// د اوسني ارزښت څخه منفي کول ، د مخکیني ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_sub` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت څخه منفي کول ، د مخکیني ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_sub` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت څخه منفي کول ، د مخکیني ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_sub` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت څخه منفي کول ، د مخکیني ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] ډولونو په واسطه د `fetch_sub` میتود له لارې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت څخه منفي کول ، د مخکیني ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_sub` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// په ورته ډول او د اوسني ارزښت سره ، پخوانی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_and` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// په ورته ډول او د اوسني ارزښت سره ، پخوانی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_and` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// په ورته ډول او د اوسني ارزښت سره ، پخوانی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] ډولونو په واسطه د `fetch_and` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// په ورته ډول او د اوسني ارزښت سره ، پخوانی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_and` میتود له لارې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// په ورته ډول او د اوسني ارزښت سره ، پخوانی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_and` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// مخکنی ارزښت بیرته راګرځولو سره ، د اوسني ارزښت سره Bitwise ناند.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_nand` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`AtomicBool`] ډول کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخکنی ارزښت بیرته راګرځولو سره ، د اوسني ارزښت سره Bitwise ناند.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_nand` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`AtomicBool`] ډول کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخکنی ارزښت بیرته راګرځولو سره ، د اوسني ارزښت سره Bitwise ناند.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_nand` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره د [`AtomicBool`] ډول کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخکنی ارزښت بیرته راګرځولو سره ، د اوسني ارزښت سره Bitwise ناند.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_nand` میتود له لارې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره د [`AtomicBool`] ډول کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخکنی ارزښت بیرته راګرځولو سره ، د اوسني ارزښت سره Bitwise ناند.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_nand` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`AtomicBool`] ډول کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// په حقیقت کې یا د اوسني ارزښت سره ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_or` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// په حقیقت کې یا د اوسني ارزښت سره ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_or` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// په حقیقت کې یا د اوسني ارزښت سره ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_or` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// په حقیقت کې یا د اوسني ارزښت سره ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_or` میتود له لارې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// په حقیقت کې یا د اوسني ارزښت سره ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_or` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// د اوسني ارزښت سره Bitwise xor ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_xor` میتود له لارې د `order` په توګه د [`Ordering::SeqCst`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت سره Bitwise xor ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_xor` میتود له لارې د `order` په توګه د [`Ordering::Acquire`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت سره Bitwise xor ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_xor` میتود له لارې د `order` په توګه د [`Ordering::Release`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت سره Bitwise xor ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_xor` میتود له لارې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت سره Bitwise xor ، مخکینی ارزښت بیرته راګرځول.
    ///
    /// د دې داخلي ثبات نسخه د `fetch_xor` میتود له لارې د `order` په توګه د [`Ordering::Relaxed`] تیریدو سره د [`atomic`] ډولونو کې شتون لري.
    /// د مثال په توګه، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::SeqCst`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::Acquire`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::Release`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::AcqRel`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د اوسني ارزښت سره اعظمي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::Relaxed`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// لږترلږه د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::SeqCst`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// لږترلږه د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::Acquire`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// لږترلږه د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::Release`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// لږترلږه د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::AcqRel`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// لږترلږه د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic`] لاسلیک شوي بشپړ ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::Relaxed`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره لږترلږه.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::SeqCst`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره لږترلږه.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::Acquire`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره لږترلږه.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::Release`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره لږترلږه.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::AcqRel`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره لږترلږه.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_min` میتود له لارې د [`Ordering::Relaxed`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::SeqCst`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::Acquire`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::Release`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::AcqRel`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// د لاسلیک شوي پرتله کولو په کارولو سره د اوسني ارزښت سره اعظمي.
    ///
    /// د دې انټرنیټیک ثبات شوی نسخه د [`atomic`] لاسلیک شوي انډیجر ډولونو کې د `fetch_max` میتود له لارې د [`Ordering::Relaxed`] د `order` په توګه تیریدو سره شتون لري.
    /// د مثال په توګه، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// د `prefetch` انټرنیسیک د کوډ جنریټر ته اشاره ده ترڅو د مخکینۍ لارښود دننه کړي که ملاتړ یې وشي؛که نه نو ، دا هیڅ انتخاب نه وي.
    /// مخکینۍ پیښې د برنامه چلند باندې هیڅ اغیزه نلري مګر کولی شي د دې فعالیت ځانګړتیاوې بدل کړي.
    ///
    /// د `locality` دلیل باید دوامداره عدد وي او د لنډمهاله محل توضیح کونکی دی چې د (0) پورې وي ، هیڅ ځای نه ، (3) پورې ، په محلول کې خورا محلي ساتل کیږي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// د `prefetch` انټرنیسیک د کوډ جنریټر ته اشاره ده ترڅو د مخکینۍ لارښود دننه کړي که ملاتړ یې وشي؛که نه نو ، دا هیڅ انتخاب نه وي.
    /// مخکینۍ پیښې د برنامه چلند باندې هیڅ اغیزه نلري مګر کولی شي د دې فعالیت ځانګړتیاوې بدل کړي.
    ///
    /// د `locality` دلیل باید دوامداره عدد وي او د لنډمهاله محل توضیح کونکی دی چې د (0) پورې وي ، هیڅ ځای نه ، (3) پورې ، په محلول کې خورا محلي ساتل کیږي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// د `prefetch` انټرنیسیک د کوډ جنریټر ته اشاره ده ترڅو د مخکینۍ لارښود دننه کړي که ملاتړ یې وشي؛که نه نو ، دا هیڅ انتخاب نه وي.
    /// مخکینۍ پیښې د برنامه چلند باندې هیڅ اغیزه نلري مګر کولی شي د دې فعالیت ځانګړتیاوې بدل کړي.
    ///
    /// د `locality` دلیل باید دوامداره عدد وي او د لنډمهاله محل توضیح کونکی دی چې د (0) پورې وي ، هیڅ ځای نه ، (3) پورې ، په محلول کې خورا محلي ساتل کیږي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// د `prefetch` انټرنیسیک د کوډ جنریټر ته اشاره ده ترڅو د مخکینۍ لارښود دننه کړي که ملاتړ یې وشي؛که نه نو ، دا هیڅ انتخاب نه وي.
    /// مخکینۍ پیښې د برنامه چلند باندې هیڅ اغیزه نلري مګر کولی شي د دې فعالیت ځانګړتیاوې بدل کړي.
    ///
    /// د `locality` دلیل باید دوامداره عدد وي او د لنډمهاله محل توضیح کونکی دی چې د (0) پورې وي ، هیڅ ځای نه ، (3) پورې ، په محلول کې خورا محلي ساتل کیږي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// یو اټومي کټ
    ///
    /// د دې داخلي ثبات نسخه د [`atomic::fence`] په توګه د `order` په توګه تیریدو سره په [`atomic::fence`] کې شتون لري.
    ///
    ///
    pub fn atomic_fence();
    /// یو اټومي کټ
    ///
    /// د دې داخلي ثبات نسخه د [`atomic::fence`] په توګه د `order` په توګه تیریدو سره په [`atomic::fence`] کې شتون لري.
    ///
    ///
    pub fn atomic_fence_acq();
    /// یو اټومي کټ
    ///
    /// د دې داخلي ثبات نسخه د [`atomic::fence`] په توګه د `order` په توګه تیریدو سره په [`atomic::fence`] کې شتون لري.
    ///
    ///
    pub fn atomic_fence_rel();
    /// یو اټومي کټ
    ///
    /// د دې داخلي ثبات نسخه د [`atomic::fence`] په توګه د `order` په توګه تیریدو سره په [`atomic::fence`] کې شتون لري.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// یواځې د یادونې یو خنډ.
    ///
    /// د یادونې لاسرسی به هیڅکله د کمپیلر لخوا د دې خنډ په اوږدو کې تنظیم نشي ، مګر د دې لپاره هیڅ لارښود به نه خارج کیږي.
    /// دا په ورته تار کې د عملیاتو لپاره مناسب دی چې ممکن مخه نیول شوې وي ، لکه کله چې د سیګنال کاروونکو سره متقابل عمل وي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic::compiler_fence`] په توګه د `order` په توګه تیریدو سره په [`atomic::compiler_fence`] کې شتون لري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// یواځې د یادونې یو خنډ.
    ///
    /// د یادونې لاسرسی به هیڅکله د کمپیلر لخوا د دې خنډ په اوږدو کې تنظیم نشي ، مګر د دې لپاره هیڅ لارښود به نه خارج کیږي.
    /// دا په ورته تار کې د عملیاتو لپاره مناسب دی چې ممکن مخه نیول شوې وي ، لکه کله چې د سیګنال کاروونکو سره متقابل عمل وي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic::compiler_fence`] په توګه د `order` په توګه تیریدو سره په [`atomic::compiler_fence`] کې شتون لري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// یواځې د یادونې یو خنډ.
    ///
    /// د یادونې لاسرسی به هیڅکله د کمپیلر لخوا د دې خنډ په اوږدو کې تنظیم نشي ، مګر د دې لپاره هیڅ لارښود به نه خارج کیږي.
    /// دا په ورته تار کې د عملیاتو لپاره مناسب دی چې ممکن مخه نیول شوې وي ، لکه کله چې د سیګنال کاروونکو سره متقابل عمل وي.
    ///
    /// د دې داخلي ثبات نسخه د [`atomic::compiler_fence`] په توګه د `order` په توګه تیریدو سره په [`atomic::compiler_fence`] کې شتون لري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// یواځې د یادونې یو خنډ.
    ///
    /// د یادونې لاسرسی به هیڅکله د کمپیلر لخوا د دې خنډ په اوږدو کې تنظیم نشي ، مګر د دې لپاره هیڅ لارښود به نه خارج کیږي.
    /// دا په ورته تار کې د عملیاتو لپاره مناسب دی چې ممکن مخه نیول شوې وي ، لکه کله چې د سیګنال کاروونکو سره متقابل عمل وي.
    ///
    /// د دې داخلي ثبات نسخه په [`atomic::compiler_fence`] کې د `order` په توګه د [`Ordering::AcqRel`] تیریدو سره شتون لري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// جادو انټرنیژیک چې د دې معنی له فنکشن سره تړلې صفاتو څخه ترلاسه کوي.
    ///
    /// د مثال په توګه ، ډاټا فولو دا د جامد تورونو انجیک کولو لپاره کاروي نو ځکه چې `rustc_peek(potentially_uninitialized)` به واقعیا دوه ځله وګوري چې ډاټا فلو واقعیا محاسبه کړې چې دا د کنټرول جریان کې پدې مرحله کې بې بنسټه دی.
    ///
    ///
    /// دا انترنیک باید د تالیف کونکي بهر ونه کارول شي.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// د پروسې پلي کول منع کوي.
    ///
    /// د دې عملیاتو ډیر کاروونکي دوستانه او مستحکم نسخه [`std::process::abort`](../../std/process/fn.abort.html) ده.
    ///
    pub fn abort() -> !;

    /// اصلاح کونکي ته خبر ورکوي چې په کوډ کې دا ټکی د لاسرسي وړ نه دی ، او نور اصلاحات وړوي.
    ///
    /// NB ، دا د `unreachable!()` میکرو څخه خورا توپیر لري: د میکرو په خلاف ، کوم چې panics کله چې اجرا کیږي ، نو دا د دې غیر معقول چلند * دی چې دې فنکشن سره نښه شوي کوډ ته رسي.
    ///
    ///
    /// د دې داخلي ثبات نسخه [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) ده.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// اصلاح کونکي ته خبر ورکوي چې یو حالت تل ریښتینی وي.
    /// که حالت غلط وي ، چلند یې نه دی ټاکل شوی.
    ///
    /// د دې داخلي لپاره هیڅ کوډ ندی رامینځته شوی ، مګر اصلاح کونکی به د پاسه (او د دې حالت) د پاسونو ترمینځ هڅه وکړي ، کوم چې ممکن د شاوخوا کوډ اصلاح کولو کې مداخله وکړي او فعالیت کم کړي.
    /// دا باید ونه کارول شي که چیرې بریدګر په خپله پخپله د اصلاح کونکي لخوا کشف شي ، یا که چیرې دا د پام وړ مطلوب فعالیت نه کوي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// کمپیلر ته اشاره کوي چې د branch حالت احتمال یې ریښتینی وي.
    /// دې ته سپارل شوی ارزښت بیرته راګرځي.
    ///
    /// د `if` بیاناتو پرته نور کوم کارول به شاید اغیز ونلري.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// کمپیلر ته اشاره کوي چې د branch حالت احتمال غلط دی.
    /// دې ته سپارل شوی ارزښت بیرته راګرځي.
    ///
    /// د `if` بیاناتو پرته نور کوم کارول به شاید اغیز ونلري.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// د ډیبګر لخوا د تفتیش لپاره ، د وقایې نقطې جال پلي کول.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn breakpoint();

    /// په بیوټونو کې د یو ډول کچه.
    ///
    /// په ځانګړي ډول ، دا د ورته ډول ډول پرله پسې توکو ترمنځ په بایټس کې آفسیټ دی ، پشمول د صف بندي کولو کښت.
    ///
    ///
    /// د دې داخلي ثبات نسخه [`core::mem::size_of`](crate::mem::size_of) ده.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// د نوعیت لږترلږه صف بندی.
    ///
    /// د دې داخلي ثبات نسخه [`core::mem::align_of`](crate::mem::align_of) ده.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// د يو ډول غوره سمون.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// په بایټونو کې د حوالې شوي ارزښت اندازه.
    ///
    /// د دې داخلي ثبات نسخه [`mem::size_of_val`] ده.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// د مراجع شوي ارزښت لازمي اړونده.
    ///
    /// د دې داخلي ثبات نسخه [`core::mem::align_of_val`](crate::mem::align_of_val) ده.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// د جامد تار سلسله ترلاسه کوي چې د ډول نوم پکې دی.
    ///
    /// د دې داخلي ثبات نسخه [`core::any::type_name`](crate::any::type_name) ده.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// یو پیژندونکی ترلاسه کوي کوم چې په نړیواله کچه مشخص شوي ډول ته ځانګړی دی.
    /// دا فنکشن به د یو ډول لپاره ورته ارزښت بیرته راستنوي پرته لدې چې هر یو crate په کې غوښتنه شوې.
    ///
    ///
    /// د دې داخلي ثبات نسخه [`core::any::TypeId::of`](crate::any::TypeId::of) ده.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// د غیر خوندي کارونو ساتونکی چې هیڅکله نشي اجرا کیدی که `T` بې ځایه وي:
    /// دا به په ساده ډول یا panic ، یا هیڅ ونه کړي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// د غیر خوندي کارونو لپاره محافظ چې هیڅکله نشي اجرا کیدی که `T` د صفر-پیل کولو اجازه نه ورکوي: دا به په احصایوي ډول panic ، یا هیڅ ونه کړي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn assert_zero_valid<T>();

    /// د غیر خوندي کارونو لپاره محافظ چې هیڅکله نشي اجرا کیدی که چیرې `T` غیرقانوني بټ نمونه لري: دا به په احصایوي ډول panic ، یا هیڅ ونه کړي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn assert_uninit_valid<T>();

    /// د جامد `Location` حواله ترلاسه کوي چې په ګوته کوي چیرې چې ورته ویل شوي و.
    ///
    /// پرځای یې د [`core::panic::Location::caller`](crate::panic::Location::caller) کارولو ته پام وکړئ.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// پرته له غورځېدونکي ګلو پرته د ارزښت کچه له موقعیت څخه بهر کوي.
    ///
    /// دا یوازې د [`mem::forget_unsized`] لپاره شتون لري؛نورمال `forget` د دې پرځای `ManuallyDrop` کاروي.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// د یو ډول ډول ارزښتونو ټوټې بیا بل ډول په توګه معرفي کوي.
    ///
    /// دواړه ډولونه باید یو شان اندازه ولري.
    /// نه اصلي ، نه پایله ، کیدی شي [invalid value](../../nomicon/what-unsafe-does.html) وي.
    ///
    /// `transmute` په سینماټیک ډول د یو ډول بل اړخ ته د یو بل سره حرکت کولو سره مساوي دی.دا د سرچینې ارزښت څخه ټوټې د منزل ارزښت ته نقل کوي ، بیا اصلي هیروي.
    /// دا د هود لاندې د C `memcpy` سره مساوي دی ، لکه د `transmute_copy` په څیر.
    ///
    /// ځکه چې `transmute` د ارزښت له پلوه عملیات دي ، د *لیږد شوي ارزښتونو سمون پخپله* د اندیښنې وړ ندی.
    /// لکه څنګه چې د کوم بل فعالیت سره ، تالیف کونکی دمخه ډاډ ورکوي چې دواړه `T` او `U` په سمه توګه تنظیم شوي.
    /// په هرصورت ، کله چې د ارزښتونو لیږد چې *بل چیرې* وي (لکه اشارې ، حوالې ، بکسونه ...) ، زنګ وهونکی باید د ټکي-ارزښتونو سم سمون ډاډمن کړي.
    ///
    /// `transmute` **ناقابل یقین** غیر محفوظ دی.د دې دندې سره د [undefined behavior][ub] د رامینځته کولو ډیری لارې شتون لري.`transmute` باید مطلق وروستی ریسارټ وي.
    ///
    /// [nomicon](../../nomicon/transmutes.html) اضافي اسناد لري.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// یو څو شیان شتون لري چې `transmute` واقعیا د دې لپاره ګټور دی.
    ///
    /// د فعالیت نښې ته د نښې اړول.دا * ماشینونو ته د پور وړ وړ نه دی چیرې چې د فعالیت نښې او د ډیټا پوائنټرې مختلف اندازې لري.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// د ژوند اوږدول ، یا د ناڅاپي ژوند لنډول.دا پرمختللی دی ، خورا خوندي نه دی Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// مایوسه مه کوئ: د `transmute` ډیری کارونې د نورو وسیلو له لارې ترلاسه کیدی شي.
    /// لاندې د `transmute` عام غوښتنلیکونه دي کوم چې د خوندي جوړښتونو سره ځای په ځای کیدی شي.
    ///
    /// `u32` ، `f64` ، او داسې نورو ته د خام bytes(`&[u8]`) بدلول.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // پرځای یې `u32::from_ne_bytes` وکاروئ
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // یا د پای پای مشخص کولو لپاره `u32::from_le_bytes` یا `u32::from_be_bytes` وکاروئ
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// په `usize` کې د نښې بدلول:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // پرځای یې د `as` کاسټ وکاروئ
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// د `*mut T` په `&mut T` بدلول:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // پرځای یې بوربرو وکاروئ
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// د `&mut T` په `&mut U` بدلول:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // اوس ، د `as` او بارولو سره یوځای کړئ ، د `as` `as` سلسله په یاد ولرئ چې انتقالي ندي
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// د `&str` په `&[u8]` بدلول:
    ///
    /// ```
    /// // دا د دې کولو لپاره ښه لاره نده.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // تاسو کولی شئ `str::as_bytes` وکاروئ
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // یا ، یوازې د بایټ تار وکاروئ ، که تاسو د سټینټ لفظي کنټرول ولرئ
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// د `Vec<&T>` په `Vec<Option<&T>>` بدلول.
    ///
    /// د کانټینر مینځپانګو داخلي ډول لیږدولو لپاره ، تاسو باید ډاډ ترلاسه کړئ چې د کانټینر بل هیڅکله سرغړونه نه کوئ.
    /// د `Vec` لپاره ، دا پدې مانا ده چې د داخلي ډولونو اندازه *او سمون* دواړه باید میچ ولري.
    /// نور کانتینرونه ممکن د نوع ، اندازې یا حتی `TypeId` اندازه باندې تکیه وکړي ، په دې حالت کې د کانټینر بریدګرو سرغړونې پرته لیږد ممکن نه وي.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector کلون کړئ ځکه چې موږ به یې وروسته بیا وکاروو
    /// let v_clone = v_orig.clone();
    ///
    /// // د ټرانسمیټ کارول: دا د `Vec` غیرمعلومه معلوماتو ترتیب باندې تکیه کوي ، کوم چې بد نظر دی او کیدی شي د نامعلومه چلند لامل شي.
    /////
    /// // په هرصورت ، دا هیڅ کاپي نده.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // دا وړاندیز شوی ، خوندي لاره ده.
    /// // دا بشپړ vector کاپي کوي ، که څه هم ، په نوي صف کې.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // دا د معلوماتو هیڅ کاپي ، د "transmuting" د `Vec` غیر محفوظه لاره ده ، پرته د ډاټا ترتیب باندې تکیه کولو څخه.
    /// // د `transmute` په لفظي ډول زنګ وهلو پرځای ، موږ د پوائنټر کاسټ ترسره کوو ، مګر د اصلي داخلي ډول (`&i32`) ته نوي یو (`Option<&i32>`) ته اړولو په شرایطو کې ، دا ټول ورته غدارونه لري.
    /////
    /// // پورته ورکړل شوي معلوماتو سربیره ، د [`from_raw_parts`] اسنادو سره هم مشوره وکړئ.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME دا تازه کړئ کله چې vec_into_raw_parts مستحکم وي.
    ///     // ډاډ ترلاسه کړئ چې اصلي vector نه ویستل شوی.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// د `split_at_mut` پلي کول:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // د دې کولو لپاره ډیری لارې شتون لري ، او د لاندې (transmute) لارې سره ډیری ستونزې شتون لري.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // لومړی: لیږد خوندي نه دی.ټول دا چیک کوي چې T او
    ///         // U د ورته اندازې دي.
    ///         // دوهم ، دلته ، تاسو دوه متقابل حواله لرئ چې ورته حافظې ته په ګوته کوي.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // دا د خوندیتوب ډول ډول ستونزو څخه خلاصیږي؛`&mut *` به* یوازې *تاسو ته د `&mut T` یا `* mut T` څخه `&mut T` درکړي.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // په هرصورت ، تاسو لاهم دوه متقابل حواله لرئ چې ورته حافظې ته اشاره کوي.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // دا هغه څه دي چې معیاري کتابتون یې کوي.
    /// // دا غوره میتود دی ، که تاسو اړتیا ورته ولرئ
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // دا اوس په ورته حافظه کې د اشارې په توګه درې بدلون مآخذونه لري.`slice` ، ارزښت ret.0 ، او ارزښت ret.1.
    ///         // `slice` هیڅکله د `let ptr = ...` وروسته نه کارول کیږي ، او له دې امله یو څوک کولی شي دا د "dead" په توګه چلند وکړي ، او له همدې امله ، تاسو یوازې دوه اصلي بدلون غوښتونکي سلیسونه لرئ.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: پداسې حال کې چې دا داخلي فشار مستحکم کوي ، موږ په کانال fn کې ځینې دودیز کوډ لرو
    // چیک کوي چې د `const fn` دننه د دې کار مخه نیسي.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `true` راګرځوي که اصلي ډول د `T` په توګه ورکړل شوی د غورځونکي گلو ته اړتیا ولري؛`false` راستنوي که چیرې د `T` لپاره چمتو شوي ډول د `Copy` پلي کوي.
    ///
    ///
    /// که چیرې اصلي ډول نه د قطع کولو گلو ته اړتیا ولري او نه هم `Copy` تطبیق کړي ، نو د دې فعالیت بیرته ستنیدونکي ارزښت مشخص ندي.
    ///
    /// د دې داخلي ثبات نسخه [`mem::needs_drop`](crate::mem::needs_drop) ده.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// د نښې څخه د آفسیټ محاسبه کوي.
    ///
    /// دا د انټرنیټیک په توګه پلي کیږي ترڅو د بشپړ او بل ته د اړولو څخه مخنیوی وکړي ، ځکه چې بدلون به د ایلیسینګ معلوماتو لرې کړي.
    ///
    /// # Safety
    ///
    /// دواړه پیل او پایله ایښودونکی باید یا هم په حدود کې وي یا د یو ټاکل شوي اعتراض په پای کې یو بایټ وي.
    /// که چیرې یا نښې له حدودو بهر وي یا ریاضياتي جریان پیښ شي نو د بیرته راستنیدونکي ارزښت نور کارول به د نه ټاکل شوي چلند پایله ولري.
    ///
    ///
    /// د دې داخلي ثبات نسخه [`pointer::offset`] ده.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// د نښې څخه د افسیټ محاسبه کوي ، په بالقوه توګه ریپینګ.
    ///
    /// دا د انټرنیټیک په توګه پلي کیږي ترڅو د بشپړ او بل څخه بدلیدو څخه مخنیوی وکړي ، ځکه چې تبادله ځینې اصلاحات منع کوي.
    ///
    /// # Safety
    ///
    /// د `offset` انترنسټ برعکس ، دا انټرنیټک نتیجه ورکوونکي ته د تخصیص شوي توکي پای ته په اشارې یا یو بایټ محدود نه کوي ، او دا د دوه بشپړونکي ریاضي سره پوښل کیږي.
    /// پایله شوي ارزښت لازمي نه دی چې واقعیا حافظې ته لاسرسي لپاره وکارول شي.
    ///
    /// د دې داخلي ثبات نسخه [`pointer::wrapping_offset`] ده.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// د مناسب `llvm.memcpy.p0i8.0i8.*` انترنیت سره مساوي ، د `count`*`size_of::<T>()` اندازه او د سمون سره
    ///
    /// `min_align_of::<T>()`
    ///
    /// خوځنده پیرامیټر `true` ته تنظیم شوی ، نو دا به مطلوب نه وي ترڅو چې اندازه د صفر سره مساوي نه وي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// د مناسب `llvm.memmove.p0i8.0i8.*` انتشار سره مساوي ، د `count* size_of::<T>()` اندازه او د سمون سره
    ///
    /// `min_align_of::<T>()`
    ///
    /// خوځنده پیرامیټر `true` ته تنظیم شوی ، نو دا به مطلوب نه وي ترڅو چې اندازه د صفر سره مساوي نه وي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// د `count *size_of::<T>()` اندازې او د `min_align_of::<T>()` سمون سره د مناسب `llvm.memset.p0i8.*` انټرنیټیک سره مساوي.
    ///
    ///
    /// خوځنده پیرامیټر `true` ته تنظیم شوی ، نو دا به مطلوب نه وي ترڅو چې اندازه د صفر سره مساوي نه وي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// د `src` پوائنټر څخه بې ثباته بار ترسره کوي.
    ///
    /// د دې داخلي ثبات نسخه [`core::ptr::read_volatile`](crate::ptr::read_volatile) ده.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// د `dst` پوائنټر ته ناڅاپي پلورنځی ترسره کوي.
    ///
    /// د دې داخلي ثبات نسخه [`core::ptr::write_volatile`](crate::ptr::write_volatile) ده.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// د `src` پوائنټر څخه بې ثباته لوړه ترسره کوي نوځکه اړین ندي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// د `dst` پوائنټر ته ناڅاپي پلورنځی ترسره کوي.
    /// ناباوره اړینه نده چې اړین وي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// د `f32` مربع ریښه راستنوي
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// د `f64` مربع ریښه راستنوي
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// انټيجر ځواک ته `f32` لوړوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// انټيجر ځواک ته `f64` لوړوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// د `f32` سینه راګرځوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// د `f64` سینه راګرځوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// د `f32` کاسین راګرځوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// د `f64` کاسین راګرځوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// یو `f32` یو `f32` ځواک ته لوړوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// یو `f64` یو `f64` ځواک ته لوړوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// د `f32` تفاوت بیرته راولي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// د `f64` تفاوت بیرته راولي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// د `f32` ځواک ته لوړ شوی 2 راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// د `f64` ځواک ته لوړ شوی 2 راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// د `f32` طبیعي لوګارتم بیرته راوړي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// د `f64` طبیعي لوګارتم بیرته راوړي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// د `f32` اساس 10 لوګارتم بیرته راولي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// د `f64` اساس 10 لوګارتم بیرته راولي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// د `f32` اساس 2 لوګارتم بیرته راولي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// د `f64` اساس 2 لوګارتم بیرته راولي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// د `f32` ارزښتونو لپاره `a * b + c` راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// د `f64` ارزښتونو لپاره `a * b + c` راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// د `f32` مطلق ارزښت راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// د `f64` مطلق ارزښت راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// لږترلږه د دوه `f32` ارزښتونو ته راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// لږترلږه د دوه `f64` ارزښتونو ته راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// اعظمي حد ته د دوه `f32` ارزښتونه.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// اعظمي حد ته د دوه `f64` ارزښتونه.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// د `f32` ارزښتونو لپاره نښه له `y` څخه `x` ته کاپي کوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// د `f64` ارزښتونو لپاره نښه له `y` څخه `x` ته کاپي کوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// ترټولو لوی بشپړونکی د `f32` څخه لږ یا مساوي سره راټولیږي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// ترټولو لوی بشپړونکی د `f64` څخه لږ یا مساوي سره راټولیږي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// ترټولو کوچنۍ انټرنیټ له `f32` لوی یا مساوي سره راټولیږي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// ترټولو کوچنۍ انټرنیټ له `f64` لوی یا مساوي سره راټولیږي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// د `f32` بشپړه برخه راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// د `f64` بشپړه برخه راستنوي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// `f32` ته ترټولو نږدې بشپړونکی راستنوي.
    /// کیدی شي یو بې ارزښته فلوینګ-نقطه استثنا راپورته کړي که چیرې دلیل بشپړ نه وي.
    pub fn rintf32(x: f32) -> f32;
    /// `f64` ته ترټولو نږدې بشپړونکی راستنوي.
    /// کیدی شي یو بې ارزښته فلوینګ-نقطه استثنا راپورته کړي که چیرې دلیل بشپړ نه وي.
    pub fn rintf64(x: f64) -> f64;

    /// `f32` ته ترټولو نږدې بشپړونکی راستنوي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn nearbyintf32(x: f32) -> f32;
    /// `f64` ته ترټولو نږدې بشپړونکی راستنوي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn nearbyintf64(x: f64) -> f64;

    /// `f32` ته ترټولو نږدې بشپړونکی راستنوي.د صفر څخه نیمایي لاری قضیې راوباسي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// `f64` ته ترټولو نږدې بشپړونکی راستنوي.د صفر څخه نیمایي لاری قضیې راوباسي.
    ///
    /// د دې داخلي مستحکم نسخه ده
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// د فلوټ اضافه چې د الجبریک مقرراتو پراساس اصلاح ته اجازه ورکوي.
    /// کیدی شي فرض کړي محدودیتونه دي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// د فلوټ تخفیف چې د الجبریک قواعد پراساس اصلاح ته اجازه ورکوي.
    /// کیدی شي فرض کړي محدودیتونه دي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// د فلو ضرب الاجل چې د الجبرایک مقرراتو پراساس اصلاح ته اجازه ورکوي.
    /// کیدی شي فرض کړي محدودیتونه دي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// د فلوټ څانګه چې د الجبریک مقرراتو پراساس اصلاح ته اجازه ورکوي.
    /// کیدی شي فرض کړي محدودیتونه دي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// د فلوټ پاتې کیدل چې د الجبریک قواعدو پراساس اصلاح ته اجازه ورکوي.
    /// کیدی شي فرض کړي محدودیتونه دي.
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// د LLVM د fptoui/fptosi سره تبادله کړئ ، کوم چې ممکن د حد څخه بهر ارزښتونو لپاره نامعلومه راستنیدنه وکړي
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// د [`f32::to_int_unchecked`] او [`f64::to_int_unchecked`] په څیر مستحکم.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// په بشپړ ډول `T` کې د بټونو شمیره راستنوي
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `count_ones` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// په انټیجر ډول `T` کې د مخکښو نا تنظیم شوي بټونو (zeroes) شمیره راستنوي.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `leading_zeros` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// د `0` ارزښت سره یو `x` به د `T` بټ سور پراخه کړي.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// د `ctlz` په څیر ، مګر اضافي غیر خوندي ځکه چې دا د `undef` بیرته راوړي کله چې د `0` ارزښت سره `x` ورکړل شي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// په انټرک ډول `T` کې د غیر نصب شوي بټونو (zeroes) شمیره راستنوي.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `trailing_zeros` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// یو `x` د `0` ارزښت سره به د `T` بټ سور پراخه کړي:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// د `cttz` په څیر ، مګر اضافي غیر خوندي ځکه چې دا د `undef` بیرته راوړي کله چې د `0` ارزښت سره `x` ورکړل شي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// بایټس په بشپړ ډول `T` کې بدلوي.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `swap_bytes` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// ټوټې په بشپړ ډول `T` کې بدلوي.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `reverse_bits` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// د کتل شوي عدد اضافې ترسره کوي.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `overflowing_add` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// کتل شوي عدد تفکیک ترسره کوي
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `overflowing_sub` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// د کتل شوي عدد ضرب ضربه اجرا کوي
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `overflowing_mul` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// دقیق وېش ترسره کوي ، د نه منل شوي چلند په پایله کې چیرې چې `x % y != 0` یا `y == 0` یا `x == T::MIN && y == -1`
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// بې چک شوي برخې ترسره کوي ، د نه منل شوي چلند په پایله کې چیرې چې `y == 0` یا `x == T::MIN && y == -1`
    ///
    ///
    /// د دې انټرنیټیک لپاره خوندي ریپرونه د `checked_div` میتود له لارې په انټرنیټ پریمیمټونو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// د نه چیک شوي برخې پاتې برخه بیرته راګرځوي ، د نه تعریف شوي چلند په پایله کې کله چې `y == 0` یا `x == T::MIN && y == -1`
    ///
    ///
    /// د دې انټرنیټیک لپاره خوندي ریپرونه د `checked_rem` میتود له لارې په انټرنیټ پریمیمټونو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// بې چک شوي کی left شفټ ترسره کوي ، په نه پایله کې د غیر تعریف شوي چلند په پایله کې کله چې `y < 0` یا `y >= N` وي ، چیرې چې N په Bits کې د T پلنوالی دی.
    ///
    ///
    /// د دې انټرنیټیک لپاره خوندي ریپرونه د `checked_shl` میتود له لارې په انټرنیټ پریمیمټونو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// یو نه چک شوي درست شفټ ترسره کوي ، په پایله کې د غیر تعریف شوي چلند په پایله کې کله چې `y < 0` یا `y >= N` وي ، چیرې چې N په Bits کې د T پلنوالی دی.
    ///
    ///
    /// د دې انټرنیټیک لپاره خوندي ریپرونه د `checked_shr` میتود له لارې په انټرنیټ پریمیمټونو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// د نه چیک شوي اضافې پایلې راوړي ، د نه تعریف شوي چلند په پایله کې کله چې `x + y > T::MAX` یا `x + y < T::MIN` وي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// د نه چیک شوي ضمني پایلې راوړي ، د نه تعریف شوي چلند په پایله کې کله چې `x - y > T::MAX` یا `x - y < T::MIN` وي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// د نه چیک شوي ضرب پایلې راوړي ، د نه تعریف شوي چلند په پایله کې کله چې `x *y > T::MAX` یا `x* y < T::MIN` وي.
    ///
    ///
    /// دا انټرنسيک مستحکم همکار نه لري.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// کی left اړخ ته تاوول
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `rotate_left` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// ښي اړوي.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `rotate_right` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (a + b) Mod 2 <sup>N</sup> بیرته راګرځی ، چیرې چې N په ټوټو کې د T پلنوالی دی.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `wrapping_add` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (a ، b) Mod 2 <sup>N</sup> بیرته راګرځی ، چیرې چې N په ټوټو کې د T پلنوالی دی.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `wrapping_sub` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (a * b) Mod 2 <sup>N</sup> بیرته راګرځی ، چیرې چې N په بټونو کې د T پراخه دی.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `wrapping_mul` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// کمپیوټري `a + b` ، د شمېرنې په حدود کې سنترید کول.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `saturating_add` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// کمپیوټري `a - b` ، د شمیري حدود سره مطمئن.
    ///
    /// د دې انټرنیټیک ثبات شوي نسخې د `saturating_sub` میتود له لارې په انټرنیټ لومړیو کې شتون لري.
    /// د مثال په توګه،
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// په 'v' کې د تغیر لپاره د امتیاز لرونکي ارزښت راستنوي؛
    /// که `T` هیڅ امتیاز نلري ، `0` بیرته ورکوي.
    ///
    /// د دې داخلي ثبات نسخه [`core::mem::discriminant`](crate::mem::discriminant) ده.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// د `T` ډول ډول ډولونو ب Xو ته `usize` ته راګرځي؛
    /// که `T` هیڅ ډولونه نلري ، نو `0` بیرته راوړي.بې ځایه ډولونه به حساب شي.
    ///
    /// د دې انټرنسيک څخه با ثباته نسخه [`mem::variant_count`] ده.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// د Rust د "try catch" جوړونه کوم چې د ډاټا پوائنټر `data` سره د فنکشن پوائنټر `try_fn` غوښتنه کوي.
    ///
    /// دریم دلیل یو فنکشن دی چې ویل کیږي که panic پیښیږي.
    /// دا فنکشن د ډیټا پوائنټر او پوائنټر په نښه کوي ځانګړي ځانګړي استثنايي توکي ته چې نیول شوی و.
    ///
    /// د نورو معلوماتو لپاره د کمپلر سرچینه او همدارنګه د std د کیچ پلي کول وګورئ.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// د LLVM مطابق د `!nontemporal` پلورنځی وویشئ (د دوی سندونه وګورئ).
    /// شاید هیڅکله مستحکم نشي.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// د توضیحاتو لپاره د `<*const T>::offset_from` سند وګورئ.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// د توضیحاتو لپاره د `<*const T>::guaranteed_eq` سند وګورئ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// د توضیحاتو لپاره د `<*const T>::guaranteed_ne` سند وګورئ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// د تالیف وخت کې تخصیص ورکول.په منډه وخت کې باید ونه ویل شي.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// ځینې دندې دلته تعریف شوي ځکه چې دوی په ناڅاپي ډول په دې ماډل کې په مستحکم باندې چمتو شوي.
// <https://github.com/rust-lang/rust/issues/15702> وګورئ.
// (`transmute` هم پدې کټګورۍ کې راځي ، مګر دا د چک له امله نشي تاوولی چې د `T` او `U` ورته اندازه لري.)
//

/// چیک کوي چې ایا `ptr` د `align_of::<T>()` په درناوي سره سم سم دی.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// د `count *size_of::<T>()` بایټس له `src` څخه `dst` ته کاپي کړئ.سرچینه او منزل باید باید* پوښښ نه کړي.
///
/// د حافظې ساحو لپاره چې کیدی شي پراخه شي ، پرځای یې [`copy`] وکاروئ.
///
/// `copy_nonoverlapping` په سیمینټیک ډول د C's [`memcpy`] سره مساوي دی ، مګر د دلیل امر سره بدل شو.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// چلند له سره ټاکل شوي ندي که کوم یو له لاندې شرایطو څخه سرغړونه وي:
///
/// * `src` د `count * size_of::<T>()` بایټونو لوستلو لپاره باید [valid] وي.
///
/// * `dst` د `count * size_of::<T>()` بایټونو لیکلو لپاره باید [valid] وي.
///
/// * دواړه `src` او `dst` باید په سم ډول تنظیم شي.
///
/// * د حافظې سیمه په `src` د `شمیر اندازې سره پیل کیږي *
///   اندازه_او: :<T>() tes بایټس باید * د ورته اندازې سره په `dst` کې د حافظې له ساحې سره پوښښ نه وي.
///
/// د [`read`] په څیر ، `copy_nonoverlapping` د `T` یو څه اړخ کاپي رامینځته کوي ، پرته لدې چې د `T` [`Copy`] دی.
/// که `T` [`Copy`] نه وي ، نو د دواړه *کارولو په کارولو سره په سیمه کې د `* src` څخه پیل کیږي او په `*dst` کې د سیمې پیل [violate memory safety][read-ownership] کولی شي.
///
///
/// په یاد ولرئ چې حتی که په مؤثره توګه کاپي شوی اندازه (`شمېر * اندازه_او: :<T>()`) د `0` دی ، نښې باید غیر NULL وي او په سمه توګه سمون ولري.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// په لاسي ډول د [`Vec::append`] پلي کول:
///
/// ```
/// use std::ptr;
///
/// /// د `src` ټول عناصر په `dst` کې حرکت کوي ، د `src` خالي پریښودل.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // ډاډ ترلاسه کړئ چې `dst` د ټول `src` ساتلو لپاره کافي ظرفیت لري.
///     dst.reserve(src_len);
///
///     unsafe {
///         // آفسیټ ته زنګ تل خوندي وي ځکه چې `Vec` به هیڅکله له `isize::MAX` بایټونو څخه زیات تخصیص ونه کړي.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // پرته له دې چې مینځپانګه راوباسي `src` تعقیب کړئ.
///         // موږ دا لومړی کوو ، ترڅو د panics لاندې نور څه په حالت کې د ستونزو مخه ونیسو.
///         src.set_len(0);
///
///         // دواړه سیمې نشي اوریدلی ځکه چې بدلون مآخذونه عرف نه کوي ، او دوه مختلف vectors ورته حافظه نشي ترلاسه کولی.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` ته خبر ورکړئ چې دا اوس د `src` مینځپانګې لري.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: دا چکونه یوازې د وخت په وخت کې ترسره کړئ
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // د کوډګین اغیز کوچنی ساتلو لپاره نه ډار.
        abort();
    }*/

    // خوندي: د `copy_nonoverlapping` لپاره د خوندیتوب قرارداد باید وي
    // د زنګ وهونکي لخوا ساتل شوی.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// د `count * size_of::<T>()` بایټس له `src` څخه `dst` ته کاپي کړئ.سرچینه او منزل مقصود کیدی شي.
///
/// که چیرې سرچینه او منزل به هیڅکله هم * جبران نه کړي ، [`copy_nonoverlapping`] د دې پرځای کارول کیدی شي.
///
/// `copy` په سیمینټیک ډول د C's [`memmove`] سره مساوي دی ، مګر د دلیل امر سره بدل شو.
/// کاپي کول داسې واقع کیږي لکه څنګه چې بایټونه د `src` څخه لنډمهاله سرلیک کې کاپي شوي او بیا یې له سرې څخه `dst` ته کاپي شوي.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// چلند له سره ټاکل شوي ندي که کوم یو له لاندې شرایطو څخه سرغړونه وي:
///
/// * `src` د `count * size_of::<T>()` بایټونو لوستلو لپاره باید [valid] وي.
///
/// * `dst` د `count * size_of::<T>()` بایټونو لیکلو لپاره باید [valid] وي.
///
/// * دواړه `src` او `dst` باید په سم ډول تنظیم شي.
///
/// د [`read`] په څیر ، `copy` د `T` یو څه اړخ کاپي رامینځته کوي ، پرته لدې چې د `T` [`Copy`] دی.
/// که `T` [`Copy`] نه وي ، نو په دواړه سیمه کې د دواړو ارزښتونو په کارولو سره په `*src` کې پیل کیږي او په سیمه کې د `* dst` په پیل کې [violate memory safety][read-ownership] کولی شي.
///
///
/// په یاد ولرئ چې حتی که په مؤثره توګه کاپي شوی اندازه (`شمېر * اندازه_او: :<T>()`) د `0` دی ، نښې باید غیر NULL وي او په سمه توګه سمون ولري.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// په خوندي توګه د غیر محفوظ بفر څخه Rust vector جوړ کړئ:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` باید د دې ډول او غیر صفر لپاره سم تنظیم شي.
/// /// * `ptr` د `T` ډوله عناصرو لوستلو لپاره باید باوري وي د `T` ډول.
/// /// * دا عناصر باید د دې فنکشن له ویلو وروسته ونه کارول شي غیر لدې چې `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // امنیت: زموږ مخکینی حالت ډاډ ورکوي چې سرچینه یوځای او اعتبار لري ،
///     // او `Vec::with_capacity` ډاډ ترلاسه کوي چې موږ د دوی لیکلو لپاره د کارولو وړ ځای لرو.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // امنیت: موږ دا دمخه د دې ډیر ظرفیت سره رامینځته کړی ،
///     // او مخکیني `copy` دا عناصر پیل کړي.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: دا چکونه یوازې د وخت په وخت کې ترسره کړئ
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // د کوډګین اغیز کوچنی ساتلو لپاره نه ډار.
        abort();
    }*/

    // خوندي: د `copy` لپاره د خوندیتوب قرارداد باید د تلیفون کونکي لخوا وساتل شي.
    unsafe { copy(src, dst, count) }
}

/// د `count * size_of::<T>()` بایټس د حافظې ټاکي `dst` څخه `val` ته.
///
/// `write_bytes` د C [`memset`] سره ورته دی ، مګر `count * size_of::<T>()` بایټونه `val` ټاکي.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// چلند له سره ټاکل شوي ندي که کوم یو له لاندې شرایطو څخه سرغړونه وي:
///
/// * `dst` د `count * size_of::<T>()` بایټونو لیکلو لپاره باید [valid] وي.
///
/// * `dst` باید سم تنظیم شي.
///
/// سربیره پردې ، زنګ وهونکی باید ډاډ ترلاسه کړي چې د `count * size_of::<T>()` بایټس د حافظې ورکړل شوې سیمې ته د `T` معتبر ارزښت کې لیکل لیکي.
/// د `T` په څیر د حافظې ساحې کارول چې د `T` یو ناباوره ارزښت لري غیر تعریف شوي چلند دی.
///
/// په یاد ولرئ چې حتی که په مؤثره توګه کاپي شوی اندازه (`شمېر * اندازه_او: :<T>()`) د `0` دی ، نښې باید غیر NULL وي او په سمه توګه سمون ولري.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// د ناباوره ارزښت رامینځته کول:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // د `Box<T>` د نل لیکې سره په نوي کولو سره مخکینی نیول شوی ارزښت لیک.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // پدې وخت کې ، د `v` کارول یا غورځول د نه ټاکل شوي چلند په پایله کې.
/// // drop(v); // ERROR
///
/// // حتی دا د `v` "uses" لیک کول ، او له همدې امله غیر تعریف شوی چلند دی.
/// // mem::forget(v); // ERROR
///
/// // په حقیقت کې ، `v` د لومړني ډول ترتیب ترتیب اشخاصو له مخې باوري دی ، نو *کوم* کوم عملیات چې دې سره لمس کیږي غیر تعریف شوی چلند دی.
/////
/// // پرېږدئ v2 =v؛//تیروتنه
///
/// unsafe {
///     // راځئ چې پرځای یې یو معتبر ارزښت ولګو
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // اوس بکس ښه دی
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // خوندي: د `write_bytes` لپاره د خوندیتوب قرارداد باید د تلیفون کونکي لخوا وساتل شي.
    unsafe { write_bytes(dst, val, count) }
}