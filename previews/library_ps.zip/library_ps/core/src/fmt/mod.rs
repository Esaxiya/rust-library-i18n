//! د تارونو د بtingې او چاپ کولو لپاره اسانتیاوې.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// احتمالي صف بندي د `Formatter::align` لخوا بيرته راستون شو
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشاره کوي چې مینځپانګې باید چپ خوا ته کیښودل شي.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشاره چې مینځپانګې باید سمې وي.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشاره چې مینځپانګه باید په مرکز کې جوړه شي.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ډول د فارمیټرې میتودونو سره راستن شو.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// د خطا ډول چې د یو پیغام په ب intoه کولو سره جریان کې ب .ه شوی.
///
/// دا ډول د غلطۍ پیښیدو پرته د غلطۍ لیږد ملاتړ نه کوي.
/// هر اضافي معلومات باید تنظیم شي ترڅو د ځینې نورو وسیلو له لارې لیږدول شي.
///
/// د یادولو لپاره یو مهم شی دا دی چې د `fmt::Error` ډول باید د [`std::io::Error`] یا [`std::error::Error`] سره مغشوش نه وي ، کوم چې تاسو ممکن په دائره کې هم ولرئ.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// د یونیکوډ منلو بفرونو یا جریانونو کې د لیکلو یا فارمیټ کولو لپاره trait.
///
/// دا trait یوازې د UTF-8 - کوډ شوي ډاټا مني او [flushable] ندی.
/// که تاسو یوازې یونیکوډ منل غواړئ او فلش کولو ته اړتیا نلرئ ، نو تاسو باید دا trait پلي کړئ؛
/// که نه نو تاسو باید [`std::io::Write`] تطبیق کړئ.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// دې لیکوال ته د تار سلسله لیکي ، بیرته راګرځي چې لیکنه بریالۍ وه که نه.
    ///
    /// دا میتود یوازې هغه وخت بریالی کیدی شي کله چې د سټینګ ټولې ټوټې په بریالیتوب سره لیکل شوي وي ، او دا میتود به بیرته نه راشي تر هغه چې ټول معلومات لیکل شوي یا غلطي واقع نشي.
    ///
    ///
    /// # Errors
    ///
    /// دا فنکشن به په غلطۍ د [`Error`] مثال راوړي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// دې لیکوال ته [`char`] لیکي ، بیرته راګرځي چې لیکنه بریالۍ وه که نه.
    ///
    /// یو X [`char`] ممکن د یو څخه ډیر بایټ په توګه کوډ شوی وي.
    /// دا میتود یوازې هغه وخت بریالی کیدی شي کله چې د بایټ بشپړ تسلسل په بریالیتوب سره لیکل شوی وي ، او دا میتود به بیرته نه راشي تر هغه چې ټول معلومات لیکل شوي یا غلطي واقع نشي.
    ///
    ///
    /// # Errors
    ///
    /// دا فنکشن به په غلطۍ د [`Error`] مثال راوړي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// د دې trait پلي کونکو سره د [`write!`] میکرو کارولو لپاره گلو.
    ///
    /// دا میتود باید عموما په لاسي ډول ونه بلل شي ، بلکه پخپله د [`write!`] میکرو له لارې.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// د شکل ورکولو لپاره تشکیلات.
///
/// A `Formatter` د فارمیټ پورې اړوند مختلف انتخابونه وړاندې کوي.
/// کارونکي مستقیم mat فارمیټرونه نه جوړوي؛یو ته د بدلون اړونده حواله د `fmt` میتود ته د [`Debug`] او [`Display`] په څیر د ټولو فارمیټ traits X ته ورکړل شوې.
///
///
/// د `Formatter` سره متقابل عمل کولو لپاره ، تاسو به د فارمیټ پورې اړوند مختلف اختیارونه بدلولو لپاره مختلف میتودونه زنګ ووهئ.
/// د مثالونو لپاره ، مهرباني وکړئ په لاندې `Formatter` کې تعریف شوي میتودونو سند وګورئ.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// دلیل په لازمي ډول یو مطلوب جزوي تطبیق شوي بtingه ورکول فعالیت دی ، د `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` سره مساوي.

extern "C" {
    type Opaque;
}

/// دا جوړښت عمومي "argument" استازیتوب کوي کوم چې د دندو د Xprintf کورنۍ لخوا اخیستل کیږي.دا د ورکړل شوي ارزښت ب formatه کولو لپاره فعالیت لري.
/// د تالیف په وخت کې دا تضمین کیږي چې فنکشن او ارزښت یې سم ډولونه لري ، او بیا دا جوړښت یو ډول ته د دلیلونو کینونیکي کولو لپاره کارول کیږي.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// دا د فارمیټ زیربنا کې د indices/counts سره تړل شوي فنکشن پوائنټر لپاره یو واحد مستحکم ارزښت تضمین کوي.
//
// په یاد ولرئ چې یو فعالیت به ورته سم نه وي ځکه چې افعال تل نامعلوم_ډر سره د اوسني ټیټ LLVM IR سره ټګیږي ، نو د دوی پته LLVM ته مهم نه ګ andل کیږي او لکه د کاس کاسټ غلط کیمپلی کیدی شي.
//
// په عمل کې ، موږ هیڅکله as_usize په غیر usise لرونکي ډیټا باندې (د فارمیټینګ دلیلونو جامد نسل په توګه) نه غږو ، نو دا یوازې یو اضافي چیک دی.
//
// موږ په اساسي ډول غواړو ډاډ ترلاسه کړو چې په `USIZE_MARKER` کې د فنکشن پوائنټر د افعالاتو سره *یوازې* اړوند پته لري چې دا هم د لومړي دلیل په توګه `&usize` اخلي.
// دلته د مطالعې وړ والي تضمین کوي چې موږ کولی شو په خوندي ډول وکاروو چې له منظور شوي مآخذ څخه یوز بیس چمتو کړو او دا پته د نه کارولو په توګه کارولو ته په ګوته نه کوي.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // خوندي: ptr یو مراجعه ده
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // خوندي: `mem::transmute(x)` خوندي دی ځکه چې
        //     1. `&'b T` هغه ژوندی ساتي چې دا د `'b` سره رامینځته شوی (نو ځکه چې بې ثباته ژوند نلري)
        //     2.
        //     `&'b T` او `&'b Opaque` ورته حافظه ترتیب لري (کله چې `T` `Sized` وي ، لکه څنګه چې دا دلته دی) `mem::transmute(f)` خوندي دی ځکه چې `fn(&T, &mut Formatter<'_>) -> Result` او `fn(&Opaque, &mut Formatter<'_>) -> Result` ورته ABI لري (تر هغه چې `T` `Sized` وي)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // خوندي: د `formatter` ډګر یوازې USIZE_MARKER ته تنظیم شوی که
            // ارزښت یو کاروونکی دی ، نو دا خوندي دی
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ب formatه د v1 ب formatه د format_args بgsه کې شتون لري
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// کله چې د format_args! () میکرو کارول ، دا فنکشن د دلیلونو جوړښت رامینځته کولو لپاره کارول کیږي.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// دا فنکشن د غیر معیاري فارمیټ پیرامیټونو مشخص کولو لپاره کارول کیږي.
    /// د معتبر دلیلونو جوړښت رامینځته کولو لپاره د `pieces` سرنی باید لږ تر لږه تر `fmt` اوږد وي.
    /// همچنان ، په `fmt` کې کوم `Count` چې `CountIsParam` یا `CountIsNextParam` وي باید د `argumentusize` سره رامینځته شوي دلیل ته ګوته ونیسي.
    ///
    /// په هرصورت ، پدې کې پاتې راتلل د بې باورۍ لامل نه کیږي ، مګر دا به غیرقانوني وګ ignoreي.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// د فارمیټ شوي متن اوږدوالی اټکل کوي.
    ///
    /// دا د لومړني `String` ظرفیت تنظیم کولو لپاره کارول کیږي کله چې `format!` کاروئ.
    /// Note: دا نه ښکته او نه لوړ حد دی.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // که د فارمیټ تار د دلیل سره پیل شي ، نو هیڅ شی مه پریږدئ ، پرته لدې چې د ټوټې اوږدوالی مهم وي.
            //
            //
            0
        } else {
            // دلته ځینې دلیلونه شتون لري ، نو کوم اضافي فشار به دا تار له سره تنظیم کړي.
            //
            // د دې څخه مخنیوي لپاره ، موږ دلته ظرفیت "pre-doubling" یو.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// دا جوړښت د ب stringې تار او د هغې دلیلونو په خوندي ډول چمتو شوي نسخه وړاندې کوي.
/// دا د منډې په وخت کې رامینځته کیدی نشي ځکه چې دا په خوندي ډول نشي ترسره کیدی ، نو هیڅ جوړونکی نه دی ورکړل شوی او ساحې یې د ترمیم مخنیوي لپاره خصوصي دي.
///
///
/// د [`format_args!`] میکرو به په خوندي ډول د دې جوړښت مثال رامینځته کړي.
/// مایکرو د تالیف وخت کې ب stringه تاییدوي نو د [`write()`] او [`format()`] افعال کارول په خوندي ډول ترسره کیدی شي.
///
/// تاسو کولی شئ هغه `Arguments<'a>` وکاروئ چې [`format_args!`] په `Debug` او `Display` سیاستوالو کې لکه څنګه چې لاندې لیدل کیږي بیرته راستانه کیږي.
/// مثال یې ورته ښیې چې `Debug` او `Display` ب formatه ورته شی ته: په `format_args!` کې د انقباض شوي ب formatه تار.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // د چاپ کولو لپاره تار تار ټوټې کړئ.
    pieces: &'a [&'static str],

    // د ځای لرونکي چشمه ، یا `None` که چیرې ټولې طرحې ډیفالټ وي (لکه څنګه چې په "{}{}" کې).
    fmt: Option<&'a [rt::v1::Argument]>,

    // د انډول کولو لپاره متحرک دلیلونه ، د تار ټوټې سره به وصل شي.
    // (هر استدلال د تار ټوټې څخه مخکې دی.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// د فارمیټ شوي تار ترلاسه کړئ ، که دا د شکل ورکولو لپاره هیڅ دلیل ونه لري.
    ///
    /// دا په خورا کوچني حالت کې د تخصیصونو مخنیوي لپاره کارول کیدی شي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` ننوتنه باید د پروګرامر سره مخ ، د ډبګینګ شرایطو کې ب formatه ورکړي.
///
/// په عموم کې خبرې کول ، تاسو باید یوازې `derive` د `Debug` تطبیق وکړئ.
///
/// کله چې د متبادل فارمیټ توضیح کونکي `#?` سره وکارول شي ، محصول خورا ښکلی دی.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// دا trait د `#[derive]` سره کارول کیدی شي که چیرې ټولې برخې `Debug` پلي کړي.
/// کله چې د سټریکونو لپاره ډرایډ شوی ، نو دا به د `struct` نوم وکاروي ، بیا به `{` ، بیا د هر ډګر نوم او `Debug` ارزښت کې کوما څخه جلا لیست ، بیا `}`.
/// د `enum`s لپاره ، دا به د تغیر نوم وکاروي او ، که چیرې د تطبیق وړ وي ، `(` ، بیا د `Debug` ارزښتونو د ساحو ، بیا `)`.
///
/// # Stability
///
/// د ترلاسه شوي `Debug` فارمیټونه مستحکم ندي ، او له دې امله ممکن د future Rust نسخو سره بدل شي.
/// سربیره پردې ، د معیاري کتابتون لخوا چمتو شوي ډولونو `Debug` پلي کول (X libstd` ، `libcore` ، `liballoc` ، او نور) ثبات نلري ، او ممکن د future Rust نسخو سره هم بدل شي.
///
///
/// # Examples
///
/// د پلي کولو په لاره اچول:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// په لاسي ډول پلي کیدل:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// د [`Formatter`] جوړښت کې یو شمیر مرستې کونکي میتودونه شتون لري ترڅو تاسو سره د لارښود پلي کولو کې مرسته وکړي ، لکه [`debug_struct`].
///
/// `Debug` په `derive` کې د `derive` یا ډیبګ جوړونکي API کارولو پلي کول د متبادل بیرغ په کارولو سره د ښکلي چاپ کولو ملاتړ کوي: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// د `#?` سره عالي چاپول:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// د trait `Debug` پرته د مایکرو `Debug` له preolve څخه د ایکسپورټ لپاره ماډل جلا کړئ.
pub(crate) mod macros {
    /// د trait `Debug` د تطبیق وړ میکرو تولید.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// د خالي ب formatه لپاره trait فارمیټ کړئ ، `{}`.
///
/// `Display` د [`Debug`] سره ورته دی ، مګر `Display` د کارونکي مخ رسنۍ محصول لپاره دی ، او له همدې امله نشي ترلاسه کیدی.
///
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// په یو ډول د `Display` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// د `Octal` trait باید خپل محصول په base-8 کې د شمیر په توګه ب formatه کړي.
///
/// د اصلي لاسلیک شوي انډیجرونو لپاره (`i8` څخه `i128` ، او `isize`) ، منفي ارزښتونه د دوه بشپړ مالتړ نمایش په ب formatه ب areه کیږي.
///
///
/// د بدیل بیرغ ، `#` ، د محصول په مخ کې `0o` اضافه کوي.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// د `i32` سره اساسي کارول:
///
/// ```
/// let x = 42; // 42 په اکتوبر کې '52' دی
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// په یو ډول د `Octal` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // د i32 تطبیق ته استازي
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// د `Binary` trait باید خپل محصول په بائنری کې د شمیرو په توګه ب formatه کړي.
///
/// د اصلي لاسلیک شوي انډیجرونو لپاره ([`i8`] څخه [`i128`] ، او [`isize`]) ، منفي ارزښتونه د دوه بشپړ مالتړ نمایش په ب formatه ب areه کیږي.
///
///
/// د بدیل بیرغ ، `#` ، د محصول په مخ کې `0b` اضافه کوي.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// د [`i32`] سره اساسي کارول:
///
/// ```
/// let x = 42; // 42 په بائنری کې '101010' دی
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// په یو ډول د `Binary` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // د i32 تطبیق ته استازي
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// د `LowerHex` trait باید خپل محصول په هیکسادسیمال کې د شمې په توګه ب formatه کړي ، د `a` سره د `f` له لارې په ټیټ حالت کې.
///
/// د اصلي لاسلیک شوي انډیجرونو لپاره (`i8` څخه `i128` ، او `isize`) ، منفي ارزښتونه د دوه بشپړ مالتړ نمایش په ب formatه ب areه کیږي.
///
///
/// د بدیل بیرغ ، `#` ، د محصول په مخ کې `0x` اضافه کوي.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// د `i32` سره اساسي کارول:
///
/// ```
/// let x = 42; // 42 په هیکس کې '2a' دی
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// په یو ډول د `LowerHex` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // د i32 تطبیق ته استازي
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// د `UpperHex` trait باید خپل محصول په هیکسادسیمال کې د شمې په توګه ب formatه کړي ، د `A` سره د `F` له لارې په پورتنۍ حالت کې.
///
/// د اصلي لاسلیک شوي انډیجرونو لپاره (`i8` څخه `i128` ، او `isize`) ، منفي ارزښتونه د دوه بشپړ مالتړ نمایش په ب formatه ب areه کیږي.
///
///
/// د بدیل بیرغ ، `#` ، د محصول په مخ کې `0x` اضافه کوي.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// د `i32` سره اساسي کارول:
///
/// ```
/// let x = 42; // 42 په هیکس کې '2A' دی
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// په یو ډول د `UpperHex` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // د i32 تطبیق ته استازي
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// د `Pointer` trait باید خپل محصول د حافظې ځای په توګه ب formatه کړي.
/// دا عموما د هیکساډیسمل په توګه وړاندې کیږي.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// د `&i32` سره اساسي کارول:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // دا د '0x7f06092ac6d0' په څیر یو څه تولید کوي
/// ```
///
/// په یو ډول د `Pointer` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` د `* const T` ته بدلولو لپاره وکاروئ ، کوم چې پوینټر پلي کوي ، کوم چې موږ یې کاروو
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// د `LowerExp` trait باید خپل تولید په ټیټ قضیې `e` سره په ساینسي علامت کې ب formatه کړي.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// د `f64` سره اساسي کارول:
///
/// ```
/// let x = 42.0; // 42.0 په ساینسي لیکنه کې '4.2e1' دی
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// په یو ډول د `LowerExp` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // د f64 پلي کولو ته استازي
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// د `UpperExp` trait باید خپل محصول په ساینسي علامت کې د لوی قضیې `E` سره ب formatه کړي.
///
/// په فارمیټرونو کې د نورو معلوماتو لپاره ، [the module-level documentation][module] وګورئ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// د `f64` سره اساسي کارول:
///
/// ```
/// let x = 42.0; // 42.0 په ساینسي لیکنه کې '4.2E1' دی
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// په یو ډول د `UpperExp` پلي کول:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // د f64 پلي کولو ته استازي
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// د ورکړل شوي فارمیټر په کارولو سره ارزښت بmatsه کوي.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// د `write` فنکشن د محصول جریان اخلي ، او د `Arguments` جوړښت چې د `format_args!` میکرو سره precompiled کیدی شي.
///
///
/// دلیلونه به د ورکړل شوي فارمیټ سیسټم کې د ټاکل شوي ب formatې سلسلې له مخې ب formatه شي.
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// مهرباني وکړئ په یاد ولرئ چې د [`write!`] کارول ممکن غوره وي.مثال:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // موږ کولی شو د ټولو دلیلونو لپاره د ډیفالټ فارمیټ پیرامیټرې وکاروو.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // هر سپیک یو ورته دلیل لري چې د سټینګ ټوټې لخوا تعقیب شوی.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // خوندي: ارګ او args.args د ورته دلیلونو څخه راځي ،
                // کوم چې تضمین تضمین کوي تل د حدود دننه وي.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // دلته یوازې یوه تیاره تار پاتې کیدلی شي.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // خوندي: دلیل او ارګانونه له ورته دلیلونو څخه راځي ،
    // کوم چې تضمین تضمین کوي تل د حدود دننه وي.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // سم دلیل راوباسئ
    debug_assert!(arg.position < args.len());
    // خوندي: دلیل او ارګانونه له ورته دلیلونو څخه راځي ،
    // کوم چې د دې شاخص تضمین کوي تل د حدود دننه وي.
    let value = unsafe { args.get_unchecked(arg.position) };

    // بیا په حقیقت کې یو څه چاپول ترسره کړئ
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // : cFYgs: ntntntټ ﺍ and gsgsgs gs same Ar samegu mentsgugu from from from from come come
            // کوم چې تضمین کوي دا شاخص تل د حدود په اوږدو کې وي.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// د یو څه پای وروسته ګنډل.د `Formatter::padding` لخوا راستون شوی.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// د دې پوسټ ګیرۍ ولیکئ.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // موږ غواړو دا بدل کړو
            buf: wrap(self.buf),

            // او دا وساتئ
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // د دلیلونو د ډکولو او پروسس کولو لپاره کارول شوي مرستندویه لارې چې ټول traits فارمیټ کولی شي وکاروي.
    //

    /// د بشپړ انډیټ لپاره مناسب پیډینګ ترسره کوي کوم چې دمخه په str کې خپور شوی.
    /// str *باید* د عدد لپاره نښه ونه لري ، چې د دې میتود لخوا به اضافه شي.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative ، ایا اصلي عدد بشپړ او که مثبت وو یا صفر.
    /// * مختاړی ، که د '#' کرکټر (Alternate) چمتو شوی وي ، دا د عدد مخې ته ایښودلو ته چمتو دی.
    ///
    /// * buf ، د بایټ صف چې شمیره یې ب formatه شوې
    ///
    /// دا فنکشن به په سمه توګه چمتو شوي بيرغونو لپاره حساب ورکړي او لږترلږه عرض.
    /// دا به دقیقت په پام کې ونه نیسي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // موږ اړتیا لرو د نمبر محصول څخه "-" لرې کړئ.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // نښه لیکي که شتون ولري ، او بیا مخکښ که دا غوښتنه شوې وه
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // د `width` ډګر په دې موقع د `min-width` پیرامیټر ډیر دی.
        match self.width {
            // که چیرې د لږترلږه اوږدوالي اړتیاوې شتون ونلري نو بیا موږ یوازې بایټ لیکلی شو.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // وګورئ که چیرې موږ لږترلږه عرض څخه پورته شو ، که داسې وي نو بیا موږ یوازې بیتونه هم لیکلی شو.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // نښه او پریفکس د ګنډو دمخه پرمخ ځي که د ډکولو صفر صفر وي
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // نور نو ، نښه او پریفکس د ګنډو وروسته ځي
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// دا فنکشن د تار ټوټه اخلي او د ټاکل شوي اړوند فارمیټ ب .و پلي کولو وروسته دا داخلي بفر ته جذبوي.
    /// هغه بیرغونه چې د عمومي تارونو لپاره پیژندل شوي دي په لاندې ډول دي:
    ///
    /// * لږترلږه سور. د لږتر لږه عرض
    /// * fill/align - څه باید اخراج شي او چیرته چې دا اخراج کړي که چیرې ورکړل شوي تار تار کولو ته اړتیا ولري
    /// * دقیقه ، د ایستلو لپاره اعظمي اوږدوالی ، تار قطع شوی که دا اوږدوالي څخه یې اوږد وي
    ///
    /// د یادونې وړ ده چې دا فعالیت د `flag` پیرامیټونو څخه سترګې پټوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ډاډ ترلاسه کړئ چې مخکې د سرعت سرعت شتون لري
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // د `precision` ساحه کیدلی شي د تار کولو لپاره د `max-width` په توګه تشریح شي.
        //
        let s = if let Some(max) = self.precision {
            // که چیرې زموږ تار اوږد وي دقیقا ، نو موږ باید ټرنیکشن ولرو.
            // په هرصورت نور بیرغونه لکه `fill` ، `width` او `align` باید د تل په څیر عمل وکړي.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // دلته LLVM دا نشي ثابتولی چې `..i` panic `&s[..i]` نه کوي ، مګر موږ پوهیږو چې دا panic نشي کولی.
                // د `unsafe` د مخنیوي لپاره `get` + `unwrap_or` وکاروئ او نه بلکه دلته د panic اړوند کوډ مه خپروئ.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // د `width` ډګر په دې موقع د `min-width` پیرامیټر ډیر دی.
        match self.width {
            // که موږ د اعظمي حد لاندې وي ، او د لږترلږه اوږدوالي اړتیاوې شتون ونلري ، نو بیا موږ کولی شو سټینګ خارج کړو
            //
            None => self.buf.write_str(s),
            // که موږ د اعظمي حد لاندې یاست ، که چیرې موږ له لږترلږه عرض څخه پورته یو ، که چیرې دا دومره اسانه ده لکه د تار سیسټم.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // که موږ د اعظمي حد او کم نه کم عرض دواړو څخه لاندې یو نو بیا د ټاکل شوي تار + ځینې سمون سره لږترلږه عرض ډک کړئ.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// دمخه پیډینګ ولیکئ او لیکلي غیر لیکلې پوسټینګ بیرته ورکړئ.
    /// زنګ وهونکي د ډاډ ترلاسه کولو مسؤلیت لري چې د پوډ پیډینګ له هغه شي وروسته لیکل کیږي چې ویل کیږي.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ب formatه شوې برخې اخلي او ګړندي تطبیقوي.
    /// فرض کړئ چې زنګ وهونکی لا دمخه د اړینې دقیقیت سره برخې وړاندې کړې دي ، نو ځکه چې `self.precision` له پامه غورځول کیدی شي.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // د نښه پوهه صفر پیادو لپاره ، موږ لومړی نښه وړاندې کوو او داسې چلند کوو لکه څنګه چې موږ له پیل څخه هیڅ نښه نلرو.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // نښه تل لومړۍ وي
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // نښه د فارمیټ شوي برخو څخه لرې کړئ
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // پاتې برخې د عادي تختې پروسې له لارې ځي.
            let len = formatted.len();
            let ret = if width <= len {
                // نه بسته
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // دا عادي قضیه ده او موږ یو شارټ کټ واخلو
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // خوندي: دا د `flt2dec::Part::Num` او `flt2dec::Part::Copy` لپاره کارول کیږي.
            // دا د `flt2dec::Part::Num` لپاره کارول خوندي دي ځکه چې هر چیر `c` د `b'0'` او `b'9'` ترمنځ دی ، پدې معنی چې `s` د UTF-8 معتبر دی.
            // دا په عملي ډول د `flt2dec::Part::Copy(buf)` کارولو لپاره خوندي دي ځکه چې `buf` باید ساده ASCII وي ، مګر دا امکان لري چې څوک د `buf` لپاره په خراب ارزښت کې په `flt2dec::to_shortest_str` کې تیریږي ځکه چې دا عامه دنده ده.
            //
            // FIXME: معلومول چې ایا دا د UB پایله کیدی شي.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // z 64 صفرونه
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// پدې بterه کې دننه زیرمه شوي بفر ته ځینې معلومات لیکي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // دا سره برابر دی:
    ///         // ولیکئ (فارمیټ ، "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// دې مثال ته ځینې فارمیټ شوي معلومات لیکي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// د شکل ورکولو لپاره بیرغونه
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// کرکټر د 'fill' په توګه کارول کیږي هرکله چې سمون شتون ولري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // موږ د ">" سره ښي خوا ته سیده جوړه کړه.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// بيرغ په ګوته کوي چې د سمون کومه ب requestedه غوښتل شوې وه.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// په اختیاري توګه مشخص شوي انډییز عرض. محصول چې باید وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // که موږ عرض ترلاسه کړو ، موږ دا کاروو
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // نور نو موږ هیڅ ځانګړي نه کوو
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// د شمیرو ډولونو لپاره اختیاري مشخص شوي دقیقه.
    /// په بدیل توګه ، د تار ډولونو لپاره اعظمي حد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // که موږ دقیقیت ترلاسه کړو ، موږ دا کار کوو.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // نور نو موږ 2 ته ډیفالټ کوو.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// معلوموي چې که د `+` بيرغ مشخص شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// معلوموي چې که د `-` بيرغ مشخص شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // تاسو د منفي نښه غواړئ؟یو یې لری!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// معلوموي چې که د `#` بيرغ مشخص شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// معلوموي چې که د `0` بيرغ مشخص شوی وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // موږ د فارمیټر اختیارونه له پامه غورځوو.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: پریکړه وکړئ چې موږ د دې دوه بیرغونو لپاره کوم عامه API غواړو.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// د [`DebugStruct`] جوړونکی جوړوي چې د سټرکونو لپاره د [`fmt::Debug`] پلي کولو رامینځته کولو کې مرستې لپاره ډیزاین شوی.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// د `DebugTuple` جوړونکی رامینځته کوي چې د ټوپک سټریکونو لپاره د `fmt::Debug` پلي کولو رامینځته کولو کې مرستې لپاره ډیزاین شوی.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// د `DebugList` جوړونکی رامینځته کوي چې د لیست په څیر جوړښتونو لپاره د `fmt::Debug` پلي کولو رامینځته کولو کې مرستې لپاره ډیزاین شوی.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// د `DebugSet` جوړونکی رامینځته کوي چې د سیټ ورته جوړښتونو لپاره د `fmt::Debug` پلي کولو رامینځته کولو کې مرستې لپاره ډیزاین شوی.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// پدې ډیر پیچلي مثال کې ، موږ د میچ وسلو د لیست جوړولو لپاره [`format_args!`] او `.debug_set()` کاروو:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// د `DebugMap` جوړونکی جوړوي چې د نقشې په څیر جوړښتونو لپاره د `fmt::Debug` پلي کولو رامینځته کولو کې مرستې لپاره ډیزاین شوی.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// د اصلي فارمیټ traits تطبیق

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // که چیرې چیرې فرار ته اړتیا ولري ، نو لاهم بیکلوګ فلش کړئ او ولیکئ ، نور یې پریږدئ
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // د بدیل بيرغ لا دمخه د لوئر هیکس لخوا چلند شوی د ځانګړتیا په توګه-دا په ګوته کوي چې ایا د 0x سره مختاړی کول غواړي.
        // موږ دا د کار کولو لپاره کاروو که نه د صفر غزول ، او بیا په غیر مشروط ډول د مخکینۍ ترلاسه کولو لپاره تنظیم کړئ.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// د مختلف اصلي ډولونو لپاره د Display/Debug پلي کول

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // د ریف سییل یو له بل څخه پور اخیستل شوی دی نو موږ یې دلته ارزښت نشو لیدلی.
                // پرځای یو پلی کونکی وښایاست.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// که تاسو تمه لرئ چې ازموینې یې دلته وي ، نو د core/tests/fmt.rs فایل ته یې وګورئ ، دا د ټولو rt::Piece جوړښتونو رامینځته کولو څخه خورا اسانه ده.
//
// په مختص شوي crate کې ازموینې هم شتون لري ، د هغو لپاره چې تخصیص ته اړتیا لري.