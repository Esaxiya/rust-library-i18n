//! دا یو داخلي موډل دی چې د ifmt لخوا کارول کیږي!ځغاستهدا جوړښت جامد تیرونو ته د وخت دمخه دمخه فارمیټ تارونو ته غزیدلی.
//!
//! دا تعریفونه د دوی د `ct` مساوي سره ورته دي ، مګر پدې کې توپیر لري چې دا په ثابت ډول تخصیص شي او د رنټیم لپاره یو څه مطلوب وي
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// احتمالي قطارونه چې د فارمیټ کولو لارښود برخې په توګه غوښتنه کیدی شي.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// اشاره کوي چې مینځپانګې باید چپ خوا ته کیښودل شي.
    Left,
    /// اشاره چې مینځپانګې باید سمې وي.
    Right,
    /// اشاره چې مینځپانګه باید په مرکز کې جوړه شي.
    Center,
    /// د سموالي غوښتنه نه وه شوې.
    Unknown,
}

/// د [width](https://doc.rust-lang.org/std/fmt/#width) او [precision](https://doc.rust-lang.org/std/fmt/#precision) توضیح کونکو لخوا کارول کیږي.
#[derive(Copy, Clone)]
pub enum Count {
    /// د لفظي شمیرې سره ټاکل شوی ، ارزښت ساتي
    Is(usize),
    /// د `$` او `*` ترکیبونو په کارولو سره مشخص شوی ، شاخص په `args` کې ساتي
    Param(usize),
    /// معلوم نه ده
    Implied,
}