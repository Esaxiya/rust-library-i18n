//! د کرکټر بدلون.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ته `char` ته واړوئ.
///
/// په یاد ولرئ چې ټول [`چار`] د اعتبار وړ دي [`u32`] s ، او سره د یو چا ته کیدی شي
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// په هرصورت ، مقابل ریښتیني ندي: ټول معتبر ندي [`u32`] s د اعتبار وړ ندي [`چار`] s.
/// `from_u32()` به `None` بیرته راشي که ان پټ د [`char`] لپاره معتبر ارزښت نه وي.
///
/// د دې فن د غیر خوندي نسخې لپاره چې دا چکونه په نظر کې نیسي ، [`from_u32_unchecked`] وګورئ.
///
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// د `None` بیرته راستنیدل کله چې ان پټ معتبر [`char`] ندی:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// د اعتبار له پامه غورځولو ، د `u32` `char` ته بدلوي.
///
/// په یاد ولرئ چې ټول [`چار`] د اعتبار وړ دي [`u32`] s ، او سره د یو چا ته کیدی شي
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// په هرصورت ، مقابل ریښتیني ندي: ټول معتبر ندي [`u32`] s د اعتبار وړ ندي [`چار`] s.
/// `from_u32_unchecked()` به دې سترګې پټې کړي ، او په ړوند ډول به [`char`] ته کاسټ شي ، احتمالي ناباوره به رامینځته کړي.
///
///
/// # Safety
///
/// دا فنکشن غیر محفوظ دی ، ځکه چې دا ممکن د `char` ارزښتونه رامینځته کړي.
///
/// د دې فنکشن خوندي نسخې لپاره ، د [`from_u32`] فنکشن وګورئ.
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // خوندي: زنګ وهونکی باید تضمین وکړي چې `i` یو معتبر چار ارزښت دی.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] په [`u32`] بدلوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] په [`u64`] بدلوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // چار د کوډ نقطې ارزښت ته کاسټ شوی ، بیا صفر ته 64 بیټ ته غزیدلی.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] وګورئ
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] په [`u128`] بدلوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // چار د کوډ نقطې ارزښت ته کاسټ شوی ، بیا صفر ته 128 بیټ ته غزول شوی.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] وګورئ
        c as u128
    }
}

/// په 0x00 کې بایټ نقشه ..=0xFF ته `char` ته چې د کوډ نقطه ورته ارزښت لري په U + 0000 کې ..=U + 00FF.
///
/// یونیکوډ داسې ډیزاین شوی چې دا د کریکټ کوډ کولو سره بایټس په مؤثره توګه ډیکوډ کوي چې IANA یې ISO-8859-1 بولي.
/// دا کوډ ورکول د ASCII سره مناسب دي.
///
/// په یاد ولرئ چې دا د ISO/IEC 8859-1 ارف څخه توپیر لري
/// ISO 8859-1 (د یو لږ هیفن سره) ، کوم چې یو څه "blanks" ، بایټ ارزښتونه پریږدي چې کوم کرکټر ته نه وي ټاکل شوي.
/// ISO-8859-1 (IANA یو) دوی د C0 او C1 کنټرول کوډونو ته ګوماري.
///
/// په یاد ولرئ چې دا *هم* د وینډوز-1252 ارف څخه توپیر لري
/// د کوډ پا 125ه 1252 ، کوم چې یو سپریټټ ISO/IEC 8859-1 دی چې د ګوتو او مختلف لاتین کرکټرونو لپاره ځینې (ټول نه!) خالي ځایونه ځانګړي کوي.
///
/// د شیانو نور تحلیل کولو لپاره ، [on the Web](https://encoding.spec.whatwg.org/) `ascii` ، `iso-8859-1` ، او `windows-1252` د وینډوز-1222 د سټریسټ لپاره عرفونه دي چې پاتې تشې د ورته C0 او C1 کنټرول کوډونو سره ډکوي.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] په [`char`] بدلوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// یوه خطا چې بیرته راګرځیدلی شي کله چې د جزو جلا کولو.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // خوندي: وګوره چې دا یو قانوني کوډ کوډ ارزښت دی
            Ok(unsafe { transmute(i) })
        }
    }
}

/// د خطا ډول بيرته راستون شو کله چې له u32 څخه چار ته اړول ونيول شي.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// په ورکړل شوي ریډیکس کې یوه ګ aه له `char` سره بدله کوي.
///
/// دلته یو 'radix' ځینې وختونه د 'base' په نوم هم یادیږي.
/// د دوه رادیکس دوه لمریز شمیره ، د لسو ، لسیزو ، او شپاړس ریډیکس ، هیکسادسیمال ته اشاره کوي ترڅو ځینې عام ارزښتونه وړاندې کړي.
///
/// په خپلسري ډول راډیزونه ملاتړ کیږي.
///
/// `from_digit()` به `None` بیرته راشي که چیرې داخل شوي ورکړل شوي رینکس کې نکښته نه وي.
///
/// # Panics
///
/// Panics که چیرې د 36 څخه لوی ریډیکس ورکړل شي.
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // ډیمسال 11 په 16 بیس کې واحد ډیجیټل دی
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// د `None` بیرته راستنیدل کله چې ان پټ ډیجیټل ندی:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// د لوی راډیکس تیریدل ، د panic لامل کیږي:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}