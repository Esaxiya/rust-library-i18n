//! تطبیق چار {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// ترټولو لوی باوري کوډ ټکی چې `char` لري.
    ///
    /// A `char` یو [Unicode Scalar Value] دی ، پدې معنی چې دا د [Code Point] دی ، مګر یوازې په یو ټاکلي حد کې.
    /// `MAX` د اعتبار وړ کوډ نقطه ده چې د اعتبار وړ [Unicode Scalar Value] دی.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () په یونی کوډ کې د کوډ کولو تېروتنې نمایش لپاره کارول کیږي.
    ///
    /// دا واقع کیدی شي ، د مثال په توګه ، کله چې [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ته بد رامینځته شوي UTF-8 بایټونه ورکول.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// د [Unicode](http://www.unicode.org/) نسخه چې د `char` او `str` میتودونو یونیکوډ برخې پر اساس دي.
    ///
    /// د یونیکوډ نوې نسخې په منظمه توګه خپرېږي او ورپسې په یونیکوډ پورې اړوند په معیاري کتابتون کې ټولې میتودونه نوي کیږي.
    /// له همدې امله د ځینې `char` او `str` میتودونو چلند او د وخت په تیریدو سره د دې ثابت بدلون ارزښت.
    /// دا *مات* نه دی.
    ///
    /// د نسخه نمبر ورکولو سکیم په [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) کې توضیح شوی.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// په `iter` کې د UTF-16 کوډ شوي کوډ پوائنټونو باندې تکرار رامینځته کوي ، د p ایرس په توګه غیر جوړه سروجات بیرته راستنوي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// یو زیانمن کوډ کوونکی د `Err` پایلو د ځای په ځای کولو سره ترلاسه کیدی شي:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ته `char` ته واړوئ.
    ///
    /// په یاد ولرئ چې ټول ټول چارتونه د اعتبار وړ دي [`u32`] s ، او سره کولی شي یوه ته کاسټ شي
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// په هرصورت ، معکوب ریښتیني ندي: ټول باوري [`u32`] s معتبر` چارسیټونه ندي.
    /// `from_u32()` به `None` بیرته راشي که ان پټ د `char` لپاره معتبر ارزښت نه وي.
    ///
    /// د دې فن د غیر خوندي نسخې لپاره چې دا چکونه په نظر کې نیسي ، [`from_u32_unchecked`] وګورئ.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// د `None` بیرته راستنیدل کله چې ان پټ معتبر `char` ندی:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// د اعتبار له پامه غورځولو ، د `u32` `char` ته بدلوي.
    ///
    /// په یاد ولرئ چې ټول ټول چارتونه د اعتبار وړ دي [`u32`] s ، او سره کولی شي یوه ته کاسټ شي
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// په هرصورت ، معکوب ریښتیني ندي: ټول باوري [`u32`] s معتبر` چارسیټونه ندي.
    /// `from_u32_unchecked()` به دې سترګې پټې کړي ، او په ړوند ډول به `char` ته کاسټ شي ، احتمالي ناباوره به رامینځته کړي.
    ///
    ///
    /// # Safety
    ///
    /// دا فنکشن غیر محفوظ دی ، ځکه چې دا ممکن د `char` ارزښتونه رامینځته کړي.
    ///
    /// د دې فنکشن خوندي نسخې لپاره ، د [`from_u32`] فنکشن وګورئ.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // خوندي: د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// په ورکړل شوي ریډیکس کې یوه ګ aه له `char` سره بدله کوي.
    ///
    /// دلته یو 'radix' ځینې وختونه د 'base' په نوم هم یادیږي.
    /// د دوه رادیکس دوه لمریز شمیره ، د لسو ، لسیزو ، او شپاړس ریډیکس ، هیکسادسیمال ته اشاره کوي ترڅو ځینې عام ارزښتونه وړاندې کړي.
    ///
    /// په خپلسري ډول راډیزونه ملاتړ کیږي.
    ///
    /// `from_digit()` به `None` بیرته راشي که چیرې داخل شوي ورکړل شوي رینکس کې نکښته نه وي.
    ///
    /// # Panics
    ///
    /// Panics که چیرې د 36 څخه لوی ریډیکس ورکړل شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // ډیمسال 11 په 16 بیس کې واحد ډیجیټل دی
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// د `None` بیرته راستنیدل کله چې ان پټ ډیجیټل ندی:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// د لوی راډیکس تیریدل ، د panic لامل کیږي:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// چیک کوي چې آیا په ورکړل شوي رینډکس کې `char` ګ digitه ده.
    ///
    /// دلته یو 'radix' ځینې وختونه د 'base' په نوم هم یادیږي.
    /// د دوه رادیکس دوه لمریز شمیره ، د لسو ، لسیزو ، او شپاړس ریډیکس ، هیکسادسیمال ته اشاره کوي ترڅو ځینې عام ارزښتونه وړاندې کړي.
    ///
    /// په خپلسري ډول راډیزونه ملاتړ کیږي.
    ///
    /// د [`is_numeric()`] په پرتله ، دا فعالیت یوازې د `0-9` ، `a-z` او `A-Z` حروف پیژني.
    ///
    /// 'Digit' یوازې لاندې کرکټرونو ته تعریف شوی دی:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// د 'digit' د نورو هراړخیز پوهاوي لپاره ، [`is_numeric()`] وګورئ.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics که چیرې د 36 څخه لوی ریډیکس ورکړل شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// د لوی راډیکس تیریدل ، د panic لامل کیږي:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// په ورکړل شوي راډیکس کې `char` یوې برخې ته بدلوي.
    ///
    /// دلته یو 'radix' ځینې وختونه د 'base' په نوم هم یادیږي.
    /// د دوه رادیکس دوه لمریز شمیره ، د لسو ، لسیزو ، او شپاړس ریډیکس ، هیکسادسیمال ته اشاره کوي ترڅو ځینې عام ارزښتونه وړاندې کړي.
    ///
    /// په خپلسري ډول راډیزونه ملاتړ کیږي.
    ///
    /// 'Digit' یوازې لاندې کرکټرونو ته تعریف شوی دی:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `None` راستنوي که چیرې `char` په ورکړل شوي ریډیکس کې یوې ګ toې ته اشاره ونه کړي.
    ///
    /// # Panics
    ///
    /// Panics که چیرې د 36 څخه لوی ریډیکس ورکړل شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// د غیر عدد پایلې پاس کول په ناکامي کې:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// د لوی راډیکس تیریدل ، د panic لامل کیږي:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // کوډ دلته جلا شوی د قضیو لپاره د اعدام سرعت ښه کولو لپاره چیرې چې `radix` مستقل او 10 یا کوچنی وي
        //
        let val = if likely(radix <= 10) {
            // که ګ aه نه وي ، نو د راډیکس څخه لویه شمیره به رامینځته شي.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// یو تیریدونکی راستنوي چې د کریکټ هیکسادسیمال یونیکوډ فرار د `چارټونو په توګه ترلاسه کوي.
    ///
    /// دا به د `\u{NNNNNN}` ب ofه Rust ترکیب سره د حروفونو فرار وکړي چیرې چې `NNNNNN` د هیکسادسیم نمایندګي ده.
    ///
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // یا-انګ 1 ډاډه کوي چې د c==0 لپاره کوډ حسابوي چې یوه ګ digitه باید چاپ شي او (کوم چې ورته وي) د ځمکې لاندې جریان مخنیوی کوي (31 ، 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // د خورا مهم هکس ډیجیټل شاخص
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// د `escape_debug` پراخه نسخه چې په اختیاري توګه د غځول شوي ګرافیم کوډ پوسټونو وتلو ته اجازه ورکوي.
    /// دا موږ ته اجازه راکوي د کرکټر نیکسپیک کولو په څیر غوره شکلونه ب formatه کړو کله چې دوی د تار په پیل کې وي.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// یو تیریدونکی راستنوي چې د کرکټر لفظي فرار کوډ د `چارټونو په څیر لاسته راوړي.
    ///
    /// دا به د `str` یا `char` د `Debug` پلي کولو ته ورته حروفونو څخه فرار وکړي.
    ///
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// یو تیریدونکی راستنوي چې د کرکټر لفظي فرار کوډ د `چارټونو په څیر لاسته راوړي.
    ///
    /// ډیفالټ د لفظي تولیداتو په لور د تعصب سره غوره شوی چې په مختلف ژبو کې قانوني دي ، پشمول د C++ 11 او ورته C کورنۍ ژبې.
    /// دقیق قواعد په لاندې ډول دي:
    ///
    /// * ټب د `\t` په څیر تښتیدلی دی.
    /// * د موټر بیرته راستنیدنه د `\r` په څیر وتښتیدله.
    /// * د لاین فیډ د `\n` په څیر تښتیدلی.
    /// * واحد نرخ د `\'` په څیر تښتیدلی.
    /// * ډبل نرخ د `\"` په څیر تښتیدلی.
    /// * بیکسلاش د `\\` په توګه تښتیدلی دی.
    /// * د 'د چاپونې وړ ASCII' سلسله کې کوم کرکټر `0x20` .. `0x7e` پکې شامل نه دی تښتیدلی.
    /// * نورو ټولو کرکټرونو ته هیکساډیسمل یونیکوډ فرار شوی؛[`escape_unicode`] وګوره.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// د بایټس شمیر راولي چې دا `char` به ورته اړتیا وي که په UTF-8 کې کوډ شوی وي.
    ///
    /// د بایټس شمیره تل د 1 او 4 ترمینځ وي ، شمولیت.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// د `&str` ډول تضمین کوي چې مینځپانګه یې د UTF-8 دي ، او له دې امله موږ کولی شو هغه اوږدوالي پرتله کړو چې دا یې په هر ګوټ کې د `char` په پرتله پخپله د `&str` په توګه وړاندې شوی وي:
    ///
    ///
    /// ```
    /// // د چارس په حیث
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // دواړه د دریو بایټونو په توګه نمایش کیدی شي
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // د &str په څیر ، دا دواړه په UTF-8 کې کوډ شوي دي
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // موږ لیدلی شو چې دوی ټول شپږ بایټونه اخلي ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... لکه د &str په څیر
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// د 16-بټ کوډ واحدونو شمیر راولي چې دا `char` ته به اړتیا وي که په UTF-16 کې کوډ شوی وي.
    ///
    ///
    /// د دې مفهوم نور توضیحاتو لپاره د [`len_utf8()`] لپاره اسناد وګورئ.
    /// دا فن کار دی ، مګر د UTF-8 پرځای د UTF-16 لپاره.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// دا کرکټر د UTF-8 په توګه چمتو شوي بایټ بفر ته داخلیږي ، او بیا د بفر سبسایټ بیرته راولي چې کوډ شوي کرکټر لري.
    ///
    ///
    /// # Panics
    ///
    /// Panics که بفر کافی نه وي.
    /// د څلورم اوږدوالي بفر دومره لوی دی چې د کوم `char` کوډ ورکولو لپاره.
    ///
    /// # Examples
    ///
    /// په دې دواړو مثالونو کې ، 'ß' د کوډ کولو لپاره دوه بایټونه اخلي.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// یو بفر چې خورا کوچنی دی:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // خوندي: `char` یو سروګیټ ندي ، نو دا د اعتبار وړ UTF-8 دی.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// دا کرکټر د UTF-16 په ب asه چمتو شوي `u16` بفر ته داخلیږي ، او بیا د بفر سبسایټ بیرته راولي چې کوډ شوی کرکټر لري.
    ///
    ///
    /// # Panics
    ///
    /// Panics که بفر کافی نه وي.
    /// د اوږدوالي 2 بفر دومره لوی دی چې د کوم `char` کوډ کولو لپاره.
    ///
    /// # Examples
    ///
    /// په دې دواړو مثالونو کې ، '𝕊' د کوډ کولو لپاره دوه `u16`s اخلي.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// یو بفر چې خورا کوچنی دی:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// `true` راستنوي که چیرې دا `char` د `Alphabetic` ملکیت ولري.
    ///
    /// `Alphabetic` د [Unicode Standard] په څلورم څپرکي (د ځانګړتیاو ملکیتونه) کې تشریح شوی او په [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] کې مشخص شوی.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // مینه ډیری شیان دي ، مګر دا الفبا نه دی
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// `true` راستنوي که چیرې دا `char` د `Lowercase` ملکیت ولري.
    ///
    /// `Lowercase` د [Unicode Standard] په څلورم څپرکي (د ځانګړتیاو ملکیتونه) کې تشریح شوی او په [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] کې مشخص شوی.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // د چینایی مختلف سکریپټونه او ځنډونه قضیه نلري ، او داسې نور:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// `true` راستنوي که چیرې دا `char` د `Uppercase` ملکیت ولري.
    ///
    /// `Uppercase` د [Unicode Standard] په څلورم څپرکي (د ځانګړتیاو ملکیتونه) کې تشریح شوی او په [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] کې مشخص شوی.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // د چینایی مختلف سکریپټونه او ځنډونه قضیه نلري ، او داسې نور:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// `true` راستنوي که چیرې دا `char` د `White_Space` ملکیت ولري.
    ///
    /// `White_Space` په [Unicode Character Database][ucd] [`PropList.txt`] کې مشخص شوی.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // نه ماتیدونکی ځای
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// `true` راګرځوي که چیرې دا `char` [`is_alphabetic()`] یا [`is_numeric()`] مطمین کړي.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// `true` راستنوي که چیرې دا `char` د کنټرول کوډونو عمومي کټګوري ولري.
    ///
    /// د کنټرول کوډونه (د `Cc` عمومي کټګورۍ سره د کوډ ټکي) د [Unicode Standard] په څلورم څپرکي کې بیان شوي (د ځانګړتیاو ملکیتونه) او په [Unicode Character Database][ucd] [`UnicodeData.txt`] کې مشخص شوي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// // U + 009C ، د STRING ټرمینټر
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// `true` راستنوي که چیرې دا `char` د `Grapheme_Extend` ملکیت ولري.
    ///
    /// `Grapheme_Extend` په [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] کې تشریح شوی او په [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] کې مشخص شوی.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// `true` راستنوي که چیرې دا `char` د شمېرو لپاره عمومي کټګورۍ ولري.
    ///
    /// د شمیرو لپاره عمومي کټګورۍ (د لسیزې شمیرو لپاره `Nd` ، د شمیرو شمیرو لپاره `Nl` ، او د نورو شمیرو لپاره `No`) په [Unicode Character Database][ucd] [`UnicodeData.txt`] کې مشخص شوي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// یو تیریدونکی راستنوي چې د دې `char` لوی یا د ډیر څه په توګه نقشه ترلاسه کوي
    /// `char`s.
    ///
    /// که دا `char` د ټیټ کیسیس نقشه ونه لري ، تکرار ورته `char` حاصل ورکوي.
    ///
    /// که چیرې دا `char` د [Unicode Character Database][ucd] [`UnicodeData.txt`] لخوا ورکړل شوی له یو څخه بل ته د کوچني کیچینګ نقشه ولري ، تکرار کونکی یې `char` ترلاسه کوي.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// که دا `char` ځانګړي ملاحظاتو ته اړتیا ولري (د بیلګې په توګه ډیری `چارز) تکرارونکی د [`SpecialCasing.txt`] لخوا ورکړل شوي` چارټ (ګیټونه) ترلاسه کوي.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// دا عملیات پرته له خیاطي غیر مشروطې نقشه ترسره کوي.دا ، د تبادلې اساس او ژبه خپلواکه ده.
    ///
    /// په [Unicode Standard] کې ، څلورم څپرکی (د ځانګړتیاو ملکیتونه) په عمومي ډول د قضیې نقشه کولو په اړه بحث کوي او 3 فصل (Conformance) د قضیې د تبادلې لپاره د ډیفالټ الګوریتم په اړه بحث کوي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // ځینې وختونه پایله د یو شخصیت څخه ډیر وي:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // هغه کرکټرونه چې دواړه لوی او لوی کیسیس نلري په ځان کې بدلیږي.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// یو تیریدونکی راستنوي چې د دې `char` لوی لوی نقشه د یو یا ډیرو په څیر ترلاسه کوي
    /// `char`s.
    ///
    /// که دا `char` د لوی کیپ کولو نقشه ونه لري ، تکرار کونکی ورته `char` حاصل ورکوي.
    ///
    /// که چیرې دا `char` د [Unicode Character Database][ucd] [`UnicodeData.txt`] لخوا ورکړل شوی له یو څخه تر یو لوی اپرېپینګ ولري ، تکرار کونکی یې `char` ترلاسه کوي.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// که دا `char` ځانګړي ملاحظاتو ته اړتیا ولري (د بیلګې په توګه ډیری `چارز) تکرارونکی د [`SpecialCasing.txt`] لخوا ورکړل شوي` چارټ (ګیټونه) ترلاسه کوي.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// دا عملیات پرته له خیاطي غیر مشروطې نقشه ترسره کوي.دا ، د تبادلې اساس او ژبه خپلواکه ده.
    ///
    /// په [Unicode Standard] کې ، څلورم څپرکی (د ځانګړتیاو ملکیتونه) په عمومي ډول د قضیې نقشه کولو په اړه بحث کوي او 3 فصل (Conformance) د قضیې د تبادلې لپاره د ډیفالټ الګوریتم په اړه بحث کوي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // ځینې وختونه پایله د یو شخصیت څخه ډیر وي:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // هغه کرکټرونه چې دواړه لوی او لوی کیسیس نلري په ځان کې بدلیږي.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # په ځای کې یادونه
    ///
    /// په ترکیه کې ، په لاتین کې د 'i' مساوي د دوه پرځای پنځه ب hasې لري:
    ///
    /// * 'Dotless': زه/ı ، ځینې وختونه لیکل شوي ï
    /// * 'Dotted': İ/i
    ///
    /// په یاد ولرئ چې د لوټ کیسټ ډټ شوی 'i' د لاتین په څیر دی.له همدې امله:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// دلته د `upper_i` ارزښت د متن ژبه باندې تکیه کوي: که موږ په `en-US` کې یو نو دا باید `"I"` وي ، مګر که موږ په `tr_TR` کې یو نو دا باید `"İ"` وي.
    /// `to_uppercase()` دا په پام کې نه نیسي ، او داسې نور:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// د ژبو په اوږدو کې لري.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// چک کوي که ارزښت د ASCII حد کې وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// د دې ASCII پورتنۍ قضیې مساوي کې د ارزښت یوه کاپي رامینځته کوي.
    ///
    /// د ASCII اکرونه 'a' ته 'z' ته 'A' ته 'Z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// په ځای کې د ارزښت لوی کیدو لپاره ، [`make_ascii_uppercase()`] وکاروئ.
    ///
    /// د غیر ASCII تورو سربیره د ASCII کرکټرونو لوی کولو لپاره ، [`to_uppercase()`] وکاروئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// د دې ASCII ټیټ قضیې مساوي کې د ارزښت یوه کاپي رامینځته کوي.
    ///
    /// د ASCII اکرونه 'A' ته 'Z' ته 'a' ته 'z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// په ځای کې د ارزښت کمولو لپاره ، [`make_ascii_lowercase()`] وکاروئ.
    ///
    /// د غیر ASCII تورو سربیره د ASCII تورو کمولو لپاره ، [`to_lowercase()`] وکاروئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// چیک کوي چې دوه ارزښتونه د ASCII قضیه غیر حساس میچ دي.
    ///
    /// د `to_ascii_lowercase(a) == to_ascii_lowercase(b)` سره مساوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// دا ډول خپل ځایي ASCII پورتنۍ قضیې ته اړوي.
    ///
    /// د ASCII اکرونه 'a' ته 'z' ته 'A' ته 'Z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// د موجوده لوی ترمیم کولو پرته نوي لوی لوی ارزښت بیرته ورکولو لپاره ، [`to_ascii_uppercase()`] وکاروئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// دا ډول دې د ASCII ټیټې قضیې ته په ځای کې بدله کړي.
    ///
    /// د ASCII اکرونه 'A' ته 'Z' ته 'a' ته 'z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// د موجوده ټیټ ترمیم کولو پرته نوي ټیټ شوي ارزښت بیرته ورکولو لپاره ، [`to_ascii_lowercase()`] وکاروئ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// چک کوي که ارزښت د ASCII الفبا ځانګړونکی وي:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ، یا
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// چک کوي که ارزښت د ASCII لوی کیکټر وي:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// چک کوي که ارزښت د ASCII لوټ کیس کیټر وي:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// چیک کوي چې آیا ارزښت د ASCII الفبا شمیره ده
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ، یا
    /// - U + 0061 'a' ..=U + 007A 'z' ، یا
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// چیک کوي چې آیا ارزښت د ASCII لسیز ډیجیټ دی:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// چک کوي که ارزښت د ASCII هیکسادسیمال ډیجیټ وي:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' ، یا
    /// - U + 0041 'A' ..=U + 0046 'F' ، یا
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// چک کوي که ارزښت د ASCII ټکي مشخصات وي:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` ، یا
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` ، یا
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` ، یا
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// چیک کوي چې ایا ارزښت د ASCII ګرافیک کرکټر دی:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// چیک کوي چې ایا ارزښت د ASCII د سپینې ساحې کردار دی:
    /// U + 0020 ځای ، U + 0009 سیمه ییز ټب ، د U + 000A لاین فیډ ، د U + 000C فورډ فیډ ، یا U + 000D کریج بیرته راستنیدنه.
    ///
    /// Rust د WHWG انفرا سټنډرډ [definition of ASCII whitespace][infra-aw] کاروي.په پراخه کچه کارولو کې ډیری نور تعریفونه شتون لري.
    /// د مثال په توګه ، [the POSIX locale][pct] کې U + 000B VERTICAL TAB او همدارنګه ټولې پورتنۍ کرکټرونه شامل دي ، مګر very د ورته ورته ځانګړتیا څخه-[په بورن shell کې د "field splitting" لپاره ډیفالټ قاعده][bfs]*یوازې* سپین ، هوریزونټل ټب ، او د سپین ځای په توګه د لائن ډوډۍ.
    ///
    ///
    /// که تاسو داسې برنامه ولیکئ چې د موجوده فایل ب processه به پروسس کړي ، نو چیک کړئ چې د دې ب usingې کارولو دمخه د سپینې ماaceۍ تعریف هغه څه دی.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// چک کوي که ارزښت د ASCII کنټرول ځانګړتیا وي:
    /// U +0000 NUL ..=U + 001F UNIT SEPARATOR ، یا U + 007F Delete.
    /// په یاد ولرئ چې د ASCII ډیری سپین ځایونه د کنټرول حروف دي ، مګر SPACE ندی.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// د UTF-8 په توګه د چمتو شوي بایټ بفر ته د X u32 X ارزښت کوډ ورکړئ ، او بیا د بفر سبسایټ بیرته راولي چې کوډ شوی کرکټر لري.
///
///
/// د `char::encode_utf8` په خلاف ، دا طریقه د سروګوټ حد کې کوډ پوسټونه هم اداره کوي.
/// (په سروګیټ سلسله کې د `char` رامینځته کول UB دي.) پایله د [generalized UTF-8] معتبره ده مګر د UTF-8 اعتبار نلري.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics که بفر کافی نه وي.
/// د څلورم اوږدوالي بفر دومره لوی دی چې د کوم `char` کوډ ورکولو لپاره.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// چمتو شوي `u16` بفر ته د UTF-16 په توګه د X u32 خام ایکس کوډ ورکوی ، او بیا د بفر سبسایټ بیرته راولي چې کوډ شوی کرکټر لري.
///
///
/// د `char::encode_utf16` په خلاف ، دا طریقه د سروګوټ حد کې کوډ پوسټونه هم اداره کوي.
/// (د سروګوټ حد کې د `char` رامینځته کول UB دي.)
///
/// # Panics
///
/// Panics که بفر کافی نه وي.
/// د اوږدوالي 2 بفر دومره لوی دی چې د کوم `char` کوډ کولو لپاره.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // خوندي: هر بازو ارزوي چې ایا دلته د لیکلو لپاره کافي اندازه بټونه شتون لري
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP له لارې تیریږي
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // تکمیلي الوتکې په سروګوټونو ویشل کیږي.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}