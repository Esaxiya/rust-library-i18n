//! د سټینګ مینځپانګه.
//!
//! د نورو جزیاتو لپاره ، د [`std::str`] موډل وګورئ.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. د حدود نه بهر
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. پیل <=پای
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. لوښه لوښه
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // لوښه ومومئ
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` باید د لین او چار څخه لږ وي
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// د `self` اوږدوالی راولی.
    ///
    /// دا اوږدوالی په بایټونو کې دی ، نه [`چار`] یا ګرافیمونه.
    /// په نورو ټکو کې ، دا ممکن هغه څه نه وي چې انسان د تار اوږدوالي ته پام کوي.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // خیالی f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// که `self` د صفر بایټونو اوږدوالی ولري `true` بیرته راولي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// چیک کوي چې `index`-th بایټ د UTF-8 کوډ نقطې ترتیب یا سټینج پای کې لومړی بایټ دی.
    ///
    ///
    /// د تار پیل او پای (کله چې `index== self.len()`) حدود ګ toل کیږي.
    ///
    /// که `index` د `self.len()` څخه لوی وي `false` بیرته راولي.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // د `老` پیل
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // د `ö` دوهم بایټ
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // د `老` دریم بایټ
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 او لین تل تل سم وي.
        // د 0 لپاره په واضح ډول ازموینه وکړئ نو دا کولی شي چک په اسانۍ سره غوره کړي او د دې قضیې لپاره د سټینګ لوستلو لوستلو ته لاړ نشي.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // دا د بټ جادو سره برابر دی: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// د مزي ټوټې ټوټې ټوټې ته اړوي.
    /// د بایټ سلایس بیرته سټینګ سلائس کې بدلولو لپاره ، د [`from_utf8`] فنکشن وکاروئ.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // خوندي: د غږ غږ ځکه چې موږ دوه ډوله ورته ورته ترتیب سره لیږو
        unsafe { mem::transmute(self) }
    }

    /// د بدلون وړ میت سلیز بدل کړئ د بدلون وړ بایټ سلایس ته.
    ///
    /// # Safety
    ///
    /// زنګ وهونکی باید ډاډ ترلاسه کړي چې د سلیس مینځپانګه د پور پای ته رسیدو دمخه UTF-8 معتبر ده او لاندې `str` کارول کیږي.
    ///
    ///
    /// د `str` کارول چې د مینځپانګې د اعتبار وړ ندي UTF-8 غیر تعریف شوی چلند دی.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // خوندي: د `&str` څخه `&[u8]` ته کاسټ د `str` راهیسې خوندي دی
        // د `&[u8]` په څیر ورته ترتیب لري (یوازې لیبرسټ کولی شي دا تضمین وکړي).
        // د اشارې امتیاز خوندي دی ځکه چې دا د بدلون وړ حوالې څخه راځي کوم چې د لیکلو لپاره د اعتبار وړ تضمین دی.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// د سلسلو ټوټه خام پوائنټر ته اړوي.
    ///
    /// لکه څنګه چې تار سلیزونه د بایټونو سلایډ دي ، نو خام نښې [`u8`] ته په ګوته کوي.
    /// دا نښې به د تار سلیس لومړي بایټ ته په ګوته شي.
    ///
    /// زنګ وهونکی باید ډاډ ترلاسه کړي چې بیرته راستانه شوی اشاره هیڅکله نه لیکل کیږي.
    /// که تاسو اړتیا لرئ د سټینګ سلیز مینځپانګې بدل کړئ ، نو [`as_mut_ptr`] وکاروئ.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// د بدلون وړ میت سلیس خام پوائنټر ته اړوي.
    ///
    /// لکه څنګه چې تار سلیزونه د بایټونو سلایډ دي ، نو خام نښې [`u8`] ته په ګوته کوي.
    /// دا نښې به د تار سلیس لومړي بایټ ته په ګوته شي.
    ///
    /// دا ستاسو مسؤلیت دی چې ډاډ ترلاسه کړئ چې د تار سلیس یوازې په داسې طریقه بدلیږي چې دا د اعتبار وړ UTF-8 پاتې وي.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// د `str` ضمیمه راستنوي.
    ///
    /// دا د `str` انډیکس کولو لپاره د نه ویریدونکي بدیل دی.
    /// [`None`] راګرځوي هرکله چې د مساوي شاخص عملیاتو panic وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // شاخصونه د UTF-8 تسلسل په حدود کې ندي
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // د حدود نه بهر
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// د `str` یو تغیر وړ ضمیمه راګرځي.
    ///
    /// دا د `str` انډیکس کولو لپاره د نه ویریدونکي بدیل دی.
    /// [`None`] راګرځوي هرکله چې د مساوي شاخص عملیاتو panic وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // سمه اوږدوالي
    /// assert!(v.get_mut(0..5).is_some());
    /// // د حدود نه بهر
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// د `str` یوه بې ارزښته ضمیمه راوګرځي.
    ///
    /// دا د `str` شاخص کولو لپاره غیر چیک شوی بدیل دی.
    ///
    /// # Safety
    ///
    /// د دې فنکشن زنګ وهونکي مسؤل دي چې دا مخکیني شرطونه مطمین وي:
    ///
    /// * د پیل کولو شاخص باید د پای شاخص څخه ډیر نه وي؛
    /// * شاخصونه باید د اصلي ټوټې حدود کې وي؛
    /// * شاخصونه باید د UTF-8 تسلسل حدود باندې واقع شي.
    ///
    /// په دې کې پاتې راتلل ، بیرته راغلی تار سلیز ممکن ناباوره حافظه حواله کړي یا د `str` ډوله لخوا لیږل شوي برید کونکي سرغړونه وکړي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // خوندي: زنګ وهونکی باید د `get_unchecked` لپاره د خوندیتوب تړون ملاتړ وکړي؛
        // سلیس د پام وړ دی ځکه چې `self` یو خوندي حواله ده.
        // راستنیدونکی نښې خوندي دي ځکه چې د `SliceIndex` تطبیقات باید تضمین ولري چې وي.
        unsafe { &*i.get_unchecked(self) }
    }

    /// د `str` تغیر کونکی ، نه کنټرول شوې ضمیمه راګرځي.
    ///
    /// دا د `str` شاخص کولو لپاره غیر چیک شوی بدیل دی.
    ///
    /// # Safety
    ///
    /// د دې فنکشن زنګ وهونکي مسؤل دي چې دا مخکیني شرطونه مطمین وي:
    ///
    /// * د پیل کولو شاخص باید د پای شاخص څخه ډیر نه وي؛
    /// * شاخصونه باید د اصلي ټوټې حدود کې وي؛
    /// * شاخصونه باید د UTF-8 تسلسل حدود باندې واقع شي.
    ///
    /// په دې کې پاتې راتلل ، بیرته راغلی تار سلیز ممکن ناباوره حافظه حواله کړي یا د `str` ډوله لخوا لیږل شوي برید کونکي سرغړونه وکړي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // خوندي: زنګ وهونکی باید د `get_unchecked_mut` لپاره د خوندیتوب تړون ملاتړ وکړي؛
        // سلیس د پام وړ دی ځکه چې `self` یو خوندي حواله ده.
        // راستنیدونکی نښې خوندي دي ځکه چې د `SliceIndex` تطبیقات باید تضمین ولري چې وي.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// د خوندیتوب چیکونو ته په تلو سره ، له بلې سټینګ ټوټې څخه سوري سلایس جوړوي.
    ///
    /// دا عموما سپارښتنه نه کیږي ، د احتیاط سره کار واخلئ!د خوندي بدیل لپاره [`str`] او [`Index`] وګورئ.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// دا نوې سلیس د `begin` څخه `end` ته ځي ، پشمول د `begin` مګر د `end` څخه علاوه.
    ///
    /// د دې پرځای د بدلون وړ سوري سلیز ترلاسه کولو لپاره ، د [`slice_mut_unchecked`] میتود وګورئ.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// د دې فنکشن زنګ وهونکي مسؤل دي چې درې مخکیني شرطونه پوره دي:
    ///
    /// * `begin` باید د `end` څخه زیات نشي.
    /// * `begin` او `end` باید د سټینګ سلائس کې بایټ پوزیشنونه وي.
    /// * `begin` او `end` باید د UTF-8 ترتیب حدود کې دروغ وي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // خوندي: زنګ وهونکی باید د `get_unchecked` لپاره د خوندیتوب تړون ملاتړ وکړي؛
        // سلیس د پام وړ دی ځکه چې `self` یو خوندي حواله ده.
        // راستنیدونکی نښې خوندي دي ځکه چې د `SliceIndex` تطبیقات باید تضمین ولري چې وي.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// د خوندیتوب چیکونو ته په تلو سره ، له بلې سټینګ ټوټې څخه سوري سلایس جوړوي.
    /// دا عموما سپارښتنه نه کیږي ، د احتیاط سره کار واخلئ!د خوندي بدیل لپاره [`str`] او [`IndexMut`] وګورئ.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// دا نوې سلیس د `begin` څخه `end` ته ځي ، پشمول د `begin` مګر د `end` څخه علاوه.
    ///
    /// د دې پرځای د نه بدلیدونکي تار سلیز ترلاسه کولو لپاره ، د [`slice_unchecked`] میتود وګورئ.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// د دې فنکشن زنګ وهونکي مسؤل دي چې درې مخکیني شرطونه پوره دي:
    ///
    /// * `begin` باید د `end` څخه زیات نشي.
    /// * `begin` او `end` باید د سټینګ سلائس کې بایټ پوزیشنونه وي.
    /// * `begin` او `end` باید د UTF-8 ترتیب حدود کې دروغ وي.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // خوندي: زنګ وهونکی باید د `get_unchecked_mut` لپاره د خوندیتوب تړون ملاتړ وکړي؛
        // سلیس د پام وړ دی ځکه چې `self` یو خوندي حواله ده.
        // راستنیدونکی نښې خوندي دي ځکه چې د `SliceIndex` تطبیقات باید تضمین ولري چې وي.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// په یوه شاخص کې دوه تار ټوټې وویشئ.
    ///
    /// دلیل ، `mid` ، باید د سټینګ له پیل څخه بایټ سیټ وي.
    /// دا باید د UTF-8 کوډ نقطې په حدود کې هم وي.
    ///
    /// دوه سلیسونه بیرته راستانه شوي د سټینګ له پیل څخه `mid` ته ځي ، او د `mid` څخه د تار سلیس پای ته.
    ///
    /// پرځای یې د بدلون وړ سوري سلیزو ترلاسه کولو لپاره ، د [`split_at_mut`] میتود وګورئ.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics که `mid` د UTF-8 کوډ نقطې حدود کې نه وي ، یا که دا د تار سلیس د وروستي کوډ نقطې پای څخه تېر وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_bundary چیک کوي چې شاخص یې [0 ، .len()]
        if self.is_char_boundary(mid) {
            // خوندي: یوازې چیک شوي چې `mid` په چار چیرنه کې دی.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// د بدلون وړ دوه سلیزونه په شاخص کې دوه برخو کې وویشئ.
    ///
    /// دلیل ، `mid` ، باید د سټینګ له پیل څخه بایټ سیټ وي.
    /// دا باید د UTF-8 کوډ نقطې په حدود کې هم وي.
    ///
    /// دوه سلیسونه بیرته راستانه شوي د سټینګ له پیل څخه `mid` ته ځي ، او د `mid` څخه د تار سلیس پای ته.
    ///
    /// د دې پرځای غیر منقول سوري سلیز ترلاسه کولو لپاره ، د [`split_at`] میتود وګورئ.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics که `mid` د UTF-8 کوډ نقطې حدود کې نه وي ، یا که دا د تار سلیس د وروستي کوډ نقطې پای څخه تېر وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_bundary چیک کوي چې شاخص یې [0 ، .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // خوندي: یوازې چیک شوي چې `mid` په چار چیرنه کې دی.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// د سټرلیټ سیس [[`چار`] s باندې تکرارونکی راګرځي.
    ///
    /// لکه څنګه چې د تار سلیس د باوري UTF-8 مشتمل دی ، موږ کولی شو د [`char`] لخوا د تار سلیس له لارې تکرار کړو.
    /// دا میتود دا ډول تکرار بیرته راوړي.
    ///
    /// دا مهمه ده چې په یاد ولرئ چې [`char`] د یونیکوډ سکیلر ارزښت استازیتوب کوي ، او ممکن ستاسو د نظر سره پرتله نکړي چې 'character' څه شی دی.
    ///
    /// د ګرافیم کلسترونو په مینځ کې بدلون ممکن هغه څه وي چې تاسو واقعیا غواړئ.
    /// دا فعالیت د Rust معیاري کتابتون لخوا نه چمتو کیږي ، پرځای یې crates.io چیک کړئ.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// په یاد ولرئ ، [`چار`] s ممکن د تورو په اړه ستاسو له پوهاوي سره سمون ونه خوري:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // نه 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// د سټریس سلائز [`چار`] s او ځایونو څخه تیریدونکی راستنوي.
    ///
    /// لکه څنګه چې د تار سلیس د باوري UTF-8 مشتمل دی ، موږ کولی شو د [`char`] لخوا د تار سلیس له لارې تکرار کړو.
    /// دا میتود د دې دواړو [`چار`] sونو تکرارونکی راستنوي ، په بیله بیا د دوی بایټ موقعیتونه.
    ///
    /// تکرار کونکی ګیډی ترلاسه کوی.دریځ لومړی دی ، [`char`] دوهم دی.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// په یاد ولرئ ، [`چار`] s ممکن د تورو په اړه ستاسو له پوهاوي سره سمون ونه خوري:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // نه (0 ، 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // دلته 3 یادونه وکړئ ، وروستی کرکټر دوه بایټونه پورته کړل
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// د سټریس ټوټې د بیتونو څخه تکرارونکی.
    ///
    /// لکه څنګه چې د تار سلیس د بایټونو ترتیب لري ، موږ د بایټ په واسطه د تار سلیس له لارې تکرار کولی شو.
    /// دا میتود دا ډول تکرار بیرته راوړي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// د سپین ځای په واسطه د تار تار ټوټه ټوټه کړئ.
    ///
    /// بیرته راګرځیدونکی به د تار سلیسونه بیرته راشي چې د اصلي تار سلیزې فرعي سلیزې دي ، د سپین ځای مقدار څخه جلا شوي.
    ///
    ///
    /// 'Whitespace' د یونیکوډ اخستل شوي کور ملکیت `White_Space` شرایطو سره سم تعریف شوی.
    /// که تاسو غواړئ یوازې د ASCII په سپین ځای کې تقسیم کړئ ، نو [`split_ascii_whitespace`] وکاروئ.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// هر ډول سپینې ساحې ته پام کیږي:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// د ASCII وایس سپیس لخوا د تار ټوټه ټوټه کوي.
    ///
    /// بیرته راګرځیدونکی به د تار سلیسونه بیرته راشي چې د اصلي تار سلیزې فرعي سلیزې دي ، د ASCII سپین ځای هر مقدار سره جلا شوي.
    ///
    ///
    /// پرځای یې د یونیکوډ `Whitespace` لخوا تقسیم کولو لپاره ، [`split_whitespace`] وکاروئ.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// د ASCII هر ډول سپین ځای په پام کې نیول شوی:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// د تورو د کرښو په اوږدو کې تکرار ، لکه د سټر سلائز.
    ///
    /// لاینونه د نوي لاین (`\n`) یا د ګاډو بیرته راستنیدو سره د لائن فیډ (`\r\n`) سره پای ته رسیدلي.
    ///
    /// وروستۍ لیکه پای اختیاري ده.
    /// يو تار چې د وروستۍ ليکې پای سره پای ته رسيږي به ورته لينونه د يو بل ورته ورته تار په توګه وروزي پرته د وروستۍ ليکې پای ته رسي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// د وروستۍ لیکې پای پای ته اړتیا نلري:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// د مزي پر مزو تکرارونکی.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// د UTF-16 په توګه کوډ شوی تار باندې د `u16` یو تکرارونکی راستنوي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// `true` راګرځوي که ورکړل شوی نمونه د دې تار ټوټې فرعي ټوټې سره مل کړي.
    ///
    /// `false` راستنوي که دا نه وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// `true` راګرځوي که ورکړل شوی نمونه د دې تار ټوټې مخکینۍ سره لوبه وکړي.
    ///
    /// `false` راستنوي که دا نه وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// `true` راګرځوي که ورکړل شوی نمونه د دې تار ټوټې سره ضمیمه وي.
    ///
    /// `false` راستنوي که دا نه وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// د دې تار سلیس د لومړي کرکټر بایټ انډیکس بیرته راولي چې له ب matchesو سره مل وي.
    ///
    /// [`None`] راستنوي که چیرې نمونه یې مسله نه وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// ډیر ټیټ پیچلې ب patternsې چې د ټکي-خالي انداز او بندونو په کارولو سره:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// نمونه نه موندل:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// په دې تار سلائس کې د نمونې ترټولو ښې میچ د لومړي کرکټر لپاره بایټ شاخص بیرته راګرځي.
    ///
    /// [`None`] راستنوي که چیرې نمونه یې مسله نه وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// ډیر پیچلي نمونې د بندیدو سره:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// نمونه نه موندل:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// د دې مزي ټوټې سبسټریجونو باندې تکرار کونکی ، د ب charactersو پواسطه جدا شوي د نمونې سره مل شوي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی به د [`DoubleEndedIterator`] وي که چیرې نمونه بیرته سرته لاسرسي ته اجازه ورکړي او د forward/reverse لټون ورته عناصر ترلاسه کړي.
    /// دا د مثال په توګه ، [`char`] لپاره ریښتیا دی ، مګر د `&str` لپاره نه.
    ///
    /// که نمونه ریورس لټون ته اجازه ورکوي مګر د هغې پایلې ممکن د مخکنۍ لټون سره توپیر ولري ، د [`rsplit`] میتود کارول کیدی شي.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// که چیرې نمونه د کرس ټوټه وي ، د هرې کرکټر هرې پیښې تقسیم کړئ:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// یو پیچلي ب patternه ، د بند په کارولو سره:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// که چیرې تار ډیری متناقص جدا کونکي ولري ، تاسو به په پای کې د خالي تارونو سره پای ته ورسیږئ:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// متناقص جدا کونکي د خالي تار سره جلا شوي.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// د تار په پیل یا پای کې جدا کونکي د خالي تارونو سره ګاونډی کیږي.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// کله چې تشې تار د جلا کونکي په توګه وکارول شي ، نو دا د سټینګ هر پیل او د تار د پیل او پای سره جلا کوي.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// متناقص جدا کونکي ممکن د حیرانتیا وړ چلند لامل شي کله چې سپین ځای د جلا کونکي په توګه وکارول شي.دا کوډ سم دی:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// دا _not_ تاسو ته درکوي:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// د دې چلند لپاره [`split_whitespace`] وکاروئ.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// د دې مزي ټوټې سبسټریجونو باندې تکرار کونکی ، د ب charactersو پواسطه جدا شوي د نمونې سره مل شوي.
    /// د `split` لخوا تولید شوي تکرار څخه توپیر لري چې په `split_inclusive` کې د سټرینګ ټرمینټر په توګه میچ شوي برخه پریږدي.
    ///
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// که چیرې د تار وروستی عنصر میچ شي ، نو هغه عنصر به د مخکینۍ فرعی سایټ ترمیم کونکی وګ beل شي.
    /// دا سټرینګ به وروستی توکی وي چې د تکرار لخوا بیرته راستنیدونکی دی.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// د ورکړل شوي تار سلیسونو سبسټریجونو باندې یو تیریدونکی ، د کرکټرونو پواسطه جلا شوی چې د نمونې سره مل شوی او په عادي ترتیب کې ترلاسه شوی.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی اړتیا لري چې نمونه د ریورس لټون ملاتړ وکړي ، او دا به [`DoubleEndedIterator`] وي که چیرې د forward/reverse لټون ورته عناصر ترلاسه کړي.
    ///
    ///
    /// د مخ څخه د تکرار لپاره ، د [`split`] میتود کارول کیدی شي.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// یو پیچلي ب patternه ، د بند په کارولو سره:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// د ورکړل شوي تار سلائس سبسټریجونو باندې تکرارونکی ، د ب charactersو پواسطه مختل شوي د نمونو سره.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// د [`split`] سره مساوي ، په استثنا د دې پرته چې د تعقیبي سبسټینګ خالي وي که خالي وي.
    ///
    /// [`split`]: str::split
    ///
    /// دا میتود د سټینګ ډیټا لپاره کارول کیدی شي _terminated_ وي ، نه د نمونې لخوا _separated_.
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی به د [`DoubleEndedIterator`] وي که چیرې نمونه بیرته سرته لاسرسي ته اجازه ورکړي او د forward/reverse لټون ورته عناصر ترلاسه کړي.
    /// دا د مثال په توګه ، [`char`] لپاره ریښتیا دی ، مګر د `&str` لپاره نه.
    ///
    /// که نمونه ریورس لټون ته اجازه ورکوي مګر د هغې پایلې ممکن د مخکنۍ لټون سره توپیر ولري ، د [`rsplit_terminator`] میتود کارول کیدی شي.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// د `self` سب سټرینګ باندې تکرار کونکی ، د کرکټر پواسطه جدا شوي د نمونې سره مل شوي او په ترتیب ترتیب کې ترلاسه شوي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// د [`split`] سره مساوي ، په استثنا د دې پرته چې د تعقیبي سبسټینګ خالي وي که خالي وي.
    ///
    /// [`split`]: str::split
    ///
    /// دا میتود د سټینګ ډیټا لپاره کارول کیدی شي _terminated_ وي ، نه د نمونې لخوا _separated_.
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی اړتیا لري چې نمونه یو برعکس لټون ملاتړ وکړي ، او دا به دوه چنده شي که چیرې د forward/reverse لټون ورته عنصرونه ترلاسه کړي.
    ///
    ///
    /// د مخ څخه د تکرار لپاره ، د [`split_terminator`] میتود کارول کیدی شي.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// د ورکړل شوي تار سلیسونو سبسټریجونو باندې تیریدونکی ، د بیلګې په واسطه جدا شوی ، په ډیرو `n` توکو بیرته راستنیدو پورې محدودیت لري.
    ///
    /// که چیرې د `n` فرعي سیسټرینګ بیرته راستانه شي ، وروستی سټرنګ (د `n`th سټرینګ) به د تار پاتې برخه ولري.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی به دوه چنده پای نه وي ، ځکه چې دا د ملاتړ کولو لپاره اغیزمن ندي.
    ///
    /// که چیرې نمونه ریورس لټون ته اجازه ورکړي ، د [`rsplitn`] میتود کارول کیدی شي.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// یو پیچلي ب patternه ، د بند په کارولو سره:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// د دې تار سلیس سبسټریجونو باندې یو تیریدونکی ، د بیلګې په واسطه جدا شوی ، د تار پای څخه پیل کیږي ، په ډیرو `n` توکو بیرته راستنیدو پورې محدود شوی.
    ///
    ///
    /// که چیرې د `n` فرعي سیسټرینګ بیرته راستانه شي ، وروستی سټرنګ (د `n`th سټرینګ) به د تار پاتې برخه ولري.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی به دوه چنده پای نه وي ، ځکه چې دا د ملاتړ کولو لپاره اغیزمن ندي.
    ///
    /// د مخ څخه تقسیم کولو لپاره ، د [`splitn`] میتود کارول کیدی شي.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// یو پیچلي ب patternه ، د بند په کارولو سره:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// تار د ټاکل شوي ډیلیمر په لومړۍ موقعه تقسیم کوي او د ډیلیمټر څخه دمخه مختاړی او د ډیلیمټر وروسته لاحقه بیرته راګرځي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// د ټاکل شوي ډلیمیټر په وروستي موقعیت کې تار تقسیم کوي او د ډیلیمیټ څخه دمخه مختاړی او د ډیلیمټر وروسته لاحقه بیرته راګرځي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// د ورکړل شوي تار سلیسونو دننه د ب ofې ناخوښ شوي میچونو څخه تکرارونکی.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی به د [`DoubleEndedIterator`] وي که چیرې نمونه بیرته سرته لاسرسي ته اجازه ورکړي او د forward/reverse لټون ورته عناصر ترلاسه کړي.
    /// دا د مثال په توګه ، [`char`] لپاره ریښتیا دی ، مګر د `&str` لپاره نه.
    ///
    /// که نمونه ریورس لټون ته اجازه ورکوي مګر د هغې پایلې ممکن د مخکنۍ لټون سره توپیر ولري ، د [`rmatches`] میتود کارول کیدی شي.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// د دې مزي ټوټې دننه د نمونې ناجوړ شوي میچونو څخه تکرار کونکی ، په بربنډ ترتیب کې ورکړل شوي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی اړتیا لري چې نمونه د ریورس لټون ملاتړ وکړي ، او دا به [`DoubleEndedIterator`] وي که چیرې د forward/reverse لټون ورته عناصر ترلاسه کړي.
    ///
    ///
    /// د مخ څخه د تکرار لپاره ، د [`matches`] میتود کارول کیدی شي.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// د دې سلسلو سلیز کې دننه د ب patternې نښو میچونو باندې یو تیریدونکی په بیله بیا هغه شاخص چې لوبه پیل کیږي.
    ///
    /// د `pat` دننه د `pat` میچونو لپاره چې پراخه کیږي ، یوازې د لومړۍ میچ سره ورته شاخصونه بیرته راځي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی به د [`DoubleEndedIterator`] وي که چیرې نمونه بیرته سرته لاسرسي ته اجازه ورکړي او د forward/reverse لټون ورته عناصر ترلاسه کړي.
    /// دا د مثال په توګه ، [`char`] لپاره ریښتیا دی ، مګر د `&str` لپاره نه.
    ///
    /// که نمونه ریورس لټون ته اجازه ورکوي مګر د هغې پایلې ممکن د مخکنۍ لټون سره توپیر ولري ، د [`rmatch_indices`] میتود کارول کیدی شي.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // یوازې لومړی `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// په `self` کې دننه د نمونې ناجوړ شوي میچونو باندې تکرار کونکی ، د میچ شاخص سره په مقابل ترتیب کې ورکړل شوی.
    ///
    /// د `pat` دننه د `pat` میچونو لپاره چې ډیریږي ، یوازې د وروستي میچ سره ورته شاخصونه بیرته راځي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د سپک چلند
    ///
    /// بیرته راګرځیدونکی اړتیا لري چې نمونه د ریورس لټون ملاتړ وکړي ، او دا به [`DoubleEndedIterator`] وي که چیرې د forward/reverse لټون ورته عناصر ترلاسه کړي.
    ///
    ///
    /// د مخ څخه د تکرار لپاره ، د [`match_indices`] میتود کارول کیدی شي.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // یوازې وروستی `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// د مخکښ او تعقیب سپین ځای له لرې کولو سره د تار سلیز راستنوي.
    ///
    /// 'Whitespace' د یونیکوډ اخستل شوي کور ملکیت `White_Space` شرایطو سره سم تعریف شوی.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// د مخکیني سپین ځای له لرې کولو سره د تار سلیز راستنوي.
    ///
    /// 'Whitespace' د یونیکوډ اخستل شوي کور ملکیت `White_Space` شرایطو سره سم تعریف شوی.
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// `start` په دې برخه کې د دې بایټ تار لومړي پوړ معنی ده؛د کی-څخه ښی ژبې لپاره لکه انګلیسي یا روسی ، دا به کی left اړخ ته ، او د ښي-کی-څخه به د عربي یا عبراني ژبو لپاره ، دا به ښي اړخ وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// د سپیس سپیل لرې شوي سره تار سلیز راستنوي.
    ///
    /// 'Whitespace' د یونیکوډ اخستل شوي کور ملکیت `White_Space` شرایطو سره سم تعریف شوی.
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// `end` پدې برخه کې د دې بایټ تار وروستی دریځ معنی لري؛د کی-څخه ښي ژبې لپاره انګلیسي یا روسی لپاره ، دا به ښي اړخ ته وي ، او د ښیې ښیې څخه کی left ژبو لکه عربي یا عبراني لپاره به دا کی left اړخ وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// د مخکیني سپین ځای له لرې کولو سره د تار سلیز راستنوي.
    ///
    /// 'Whitespace' د یونیکوډ اخستل شوي کور ملکیت `White_Space` شرایطو سره سم تعریف شوی.
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// 'Left' په دې برخه کې د دې بایټ تار لومړي پوړ معنی ده؛د ژبې لپاره لکه عربي یا عبراني چې د ښي نه کی 'سره نه د' کی left څخه ښي 'لپاره ، دا به د _right_ اړخ وي ، نه کی left اړخ.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// د سپیس سپیل لرې شوي سره تار سلیز راستنوي.
    ///
    /// 'Whitespace' د یونیکوډ اخستل شوي کور ملکیت `White_Space` شرایطو سره سم تعریف شوی.
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// 'Right' پدې برخه کې د دې بایټ تار وروستی دریځ معنی لري؛د ژبې لپاره لکه عربي یا عبراني چې د ښي نه کی left سره نه د 'کی to څخه ښي' لپاره ، دا به د _left_ اړخ وي ، نه ښي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// د ټولو پخوانیو او پیچونو سره د تار سلیس راستنوي چې د بار بار لرې شوي ب repeatedlyه سره مل وي.
    ///
    /// د [pattern] کیدی شي [`char`] وي ، د [`چار`] s ټوټه ، یا فنکشن یا بند چې ټاکل کیږي که چیرې یو کرکټر میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// یو پیچلي ب patternه ، د بند په کارولو سره:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // ترټولو مشهوره لوبه یاد وساتئ ، لاندې یې سم کړئ که
            // وروستۍ لوبه بله ده
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // خوندي: `Searcher` د باوري شاخصونو راستنولو لپاره پیژندل شوی.
        unsafe { self.get_unchecked(i..j) }
    }

    /// د ټولو پخوانیو سره سټینګ سلیز راستنوي چې د بار بار لرې شوي ب patternه سره مل وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// `start` په دې برخه کې د دې بایټ تار لومړي پوړ معنی ده؛د کی-څخه ښی ژبې لپاره لکه انګلیسي یا روسی ، دا به کی left اړخ ته ، او د ښي-کی-څخه به د عربي یا عبراني ژبو لپاره ، دا به ښي اړخ وي.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // خوندي: `Searcher` د باوري شاخصونو راستنولو لپاره پیژندل شوی.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// د مخکینۍ لرې شوي سره تار سلیز راستنوي.
    ///
    /// که تار د `prefix` په ب withه سره پیل شي ، د مخه سره وروسته فرسټینګ بیرته راستانه کیږي ، په `Some` کې لپیټل.
    /// د `trim_start_matches` په خلاف ، دا میتود یوځل یوځل مخکې سره لرې کوي.
    ///
    /// که تار د `prefix` سره نه پیل کیږي ، `None` بیرته راولي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// د اغوستلو سره د تار سلیز راستنوي.
    ///
    /// که تار د `suffix` په ب patternه پای ته ورسیږي ، ضمیمه دمخه سټینګ بیرته ورکوي ، په `Some` کې لپیټل.
    /// د `trim_end_matches` په خلاف ، دا میتود یوځل یوځل ضمیمه لرې کوي.
    ///
    /// که تار د `suffix` سره نه ختمیږي ، `None` بیرته راولي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// د ټولو پیچونو سره د تار سلیس راستنوي چې د بار بار لرې شوي ب patternه سره مل وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// `end` پدې برخه کې د دې بایټ تار وروستی دریځ معنی لري؛د کی-څخه ښي ژبې لپاره انګلیسي یا روسی لپاره ، دا به ښي اړخ ته وي ، او د ښیې ښیې څخه کی left ژبو لکه عربي یا عبراني لپاره به دا کی left اړخ وي.
    ///
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// یو پیچلي ب patternه ، د بند په کارولو سره:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // خوندي: `Searcher` د باوري شاخصونو راستنولو لپاره پیژندل شوی.
        unsafe { self.get_unchecked(0..j) }
    }

    /// د ټولو پخوانیو سره سټینګ سلیز راستنوي چې د بار بار لرې شوي ب patternه سره مل وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// 'Left' په دې برخه کې د دې بایټ تار لومړي پوړ معنی ده؛د ژبې لپاره لکه عربي یا عبراني چې د ښي نه کی 'سره نه د' کی left څخه ښي 'لپاره ، دا به د _right_ اړخ وي ، نه کی left اړخ.
    ///
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// د ټولو پیچونو سره د تار سلیس راستنوي چې د بار بار لرې شوي ب patternه سره مل وي.
    ///
    /// د [pattern] کیدی شي `&str` ، [`char`] ، د [`چار`] s ټوټه ، یا فنکشن یا بند وي چې مشخص کوي که چیرې یو سایټ میچ ولري.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # د متن لارښود
    ///
    /// تار د بایټونو ترتیب دی.
    /// 'Right' پدې برخه کې د دې بایټ تار وروستی دریځ معنی لري؛د ژبې لپاره لکه عربي یا عبراني چې د ښي نه کی left سره نه د 'کی to څخه ښي' لپاره ، دا به د _left_ اړخ وي ، نه ښي.
    ///
    ///
    /// # Examples
    ///
    /// ساده نمونه:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// یو پیچلي ب patternه ، د بند په کارولو سره:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// دا تار ټوټې په بل ډول بarsه کوي.
    ///
    /// ځکه چې `parse` خورا عمومي دی ، نو دا د ډول انفجار سره ستونزې رامینځته کولی شي.
    /// د ورته په څیر ، `parse` یو څو ځله دی چې تاسو به یې سینټاکس په مینه ډول د 'turbofish' په نوم پیژنئ: `::<>`.
    ///
    /// دا د لارښود الګوریتم سره مرسته کوي په ځانګړي ډول درک کړي چې کوم ډول چې تاسو د تجزیه کولو هڅه کوئ.
    ///
    /// `parse` کولی شي هر ډول ته توزیع کړي چې د [`FromStr`] trait پلي کوي.
    ///

    /// # Errors
    ///
    /// [`Err`] به بیرته راشي که چیرې دا ممکنه نه وي چې دا سلسله ټوټه په مطلوب ډول وویشئ.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// بنسټیز کارول
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// د `four` تشریح کولو پرځای د 'turbofish' کارول:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// تجزیه کولو کې پاتې راتلل:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// چک کوي که چیرې په دې تار کې ټول حروف د ASCII حد کې وي.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // موږ دلته هر بایټ د کرکټر په توګه چلند کولی شو: ټول ملټي بایټ کرکټرونه د یو بایټ سره پیل کیږي چې د ASIII حد کې ندي ، نو موږ به یې مخکې له دې ودروو.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// چیک کوي چې دوه تارونه د ASCII قضیه غیر حساسه لوبه ده.
    ///
    /// د `to_ascii_lowercase(a) == to_ascii_lowercase(b)` په څیر ، مګر د لنډمهاله تخصیص کولو او کاپي کولو پرته.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// دا تار د هغې ASCII پورتنۍ قضیې ته په ځای کې بدلوي.
    ///
    /// د ASCII اکرونه 'a' ته 'z' ته 'A' ته 'Z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// د موجوده لوی ترمیم کولو پرته نوي لوی لوی ارزښت بیرته ورکولو لپاره ، [`to_ascii_uppercase()`] وکاروئ.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // خوندي: خوندي ځکه چې موږ د ورته ترتیب سره دوه ډوله لیږدوو.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// دا تار د هغې ASCII ټیټ قضیې ته په ځای کې بدله کوي.
    ///
    /// د ASCII اکرونه 'A' ته 'Z' ته 'a' ته 'z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// د موجوده ټیټ ترمیم کولو پرته نوي ټیټ شوي ارزښت بیرته ورکولو لپاره ، [`to_ascii_lowercase()`] وکاروئ.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // خوندي: خوندي ځکه چې موږ د ورته ترتیب سره دوه ډوله لیږدوو.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// یو تکرار بیرته راستانه کړئ چې هر X له X001 سره د [`char::escape_debug`] سره وتښتوي.
    ///
    ///
    /// Note: یوازې د پراخ شوي ګرافیم کوډ پوسټونه چې سلسله پیل کوي به وتښتي.
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// یو تکرار بیرته راستانه کړئ چې هر X له X001 سره د [`char::escape_default`] سره وتښتوي.
    ///
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// یو تکرار بیرته راستانه کړئ چې هر X له X001 سره د [`char::escape_unicode`] سره وتښتوي.
    ///
    ///
    /// # Examples
    ///
    /// د تکراريونکي په توګه:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// د `println!` مستقیم کارول:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// دواړه برابر دي:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// د `to_string` کارول:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// یو خالي تار رامینځته کوي
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// یو خالي بدل کیدونکی تار رامینځته کوي
    #[inline]
    fn default() -> Self {
        // خوندي: خالي مزي د UTF-8 معتبره ده.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// یو نوم وړ ، کلونایی fn ډول
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // خوندي: خوندي ندی
        unsafe { from_utf8_unchecked(bytes) }
    };
}