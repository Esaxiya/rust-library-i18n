//! د `str` لپاره Trait پلي کول.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// د تارونو ترتیب ورکول تطبیقوي.
///
/// سټینګونه د دوی د بایټ ارزښتونو لخوا [lexicographically](Ord#lexicographical-comparison) ته امر شوي.
/// دا د کوډ چارټونو کې د دوی موقعیتونو په اساس د یونیکوډ کوډ ټکي امر کوي.
/// دا اړینه نده چې د "alphabetical" امر سره ورته وي ، کوم چې د ژبې او ځای سره توپیر لري.
/// د کلتوري پلوه منل شوي معیارونو مطابق د تارونو تنظیم کول د ځایی معلوماتو ځانګړی ډیټا ته اړتیا لري چې د `str` ډول څخه بهر وي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// په تارونو باندې د پرتله کولو عملیات پلي کوي.
///
/// سټینګونه د دوی بایټ ارزښتونو لخوا [lexicographically](Ord#lexicographical-comparison) سره پرتله کیږي.
/// دا د کوډ چارټونو کې د دوی موقعیتونو په اساس د یونیکوډ کوډ ټکي پرتله کوي.
/// دا اړینه نده چې د "alphabetical" امر سره ورته وي ، کوم چې د ژبې او ځای سره توپیر لري.
/// د کلتوري پلوه منل شوي معیارونو مطابق د تارونو پرتله کول د ځایی معلوماتو ځانګړی ډیټا ته اړتیا لري چې د `str` ډول پراخه وي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// د سنتیکس `&self[..]` یا `&mut self[..]` سره سلیسینګ سټرینګ تطبیقوي.
///
/// د ټول تار یوه ټوټه بیرته راولي ، د مثال په توګه ، `&self` یا `&mut self` بیرته راګرځي.`&ځان ته مساوي [0 ..
/// لین] `یا`&ځان بدل کړئ [0 ..
/// len]`.
/// د نورو شاخص کولو عملیاتو برخلاف ، دا هیڅکله panic نشي کولی.
///
/// دا عملیات *O*(1) دي.
///
/// د 1.20.0 دمخه ، د دې شاخصونو عملیات لاهم د `Index` او `IndexMut` د مستقیم پلي کولو لخوا ملاتړ شوي و.
///
/// د `&self[0 .. len]` یا `&mut self[0 .. len]` سره مساوي.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// د سنتیکس `&self[begin .. end]` یا `&mut self[begin .. end]` سره سلیسینګ سټرینګ تطبیقوي.
///
/// د ورکړل شوي مزي یوه ټوټه د بایټ سلسلې [`پیل` ، `end`) څخه راستنوي.
///
/// دا عملیات *O*(1) دي.
///
/// د 1.20.0 دمخه ، د دې شاخصونو عملیات لاهم د `Index` او `IndexMut` د مستقیم پلي کولو لخوا ملاتړ شوي و.
///
/// # Panics
///
/// Panics که `begin` یا `end` د یو کرکټ پیل کولو بایټ سیټ ته اشاره نه کوي (لکه څنګه چې د `is_char_boundary` لخوا تعریف شوي) ، که `begin > end` ، یا که `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // دا به panic:
/// // بایټ 2 په `ö` کې دی:
/// // &s [2 ..3]؛
///
/// // بایټ په `老`&s کې دننه دی [1 ..
/// // 8];
///
/// // بایټ 100 د سټینګ او س [outside .. څخه بهر دی.
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // خوندي: یوازې چیک شوي چې `start` او `end` په چار چت کې دي ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            // موږ د چار حدود هم چیک کړل ، نو دا د UTF-8 معتبر دی.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // خوندي: یوازې چیک شوي چې `start` او `end` په چار چت کې دي.
            // موږ پوهیږو چې اشاره ځانګړتیا لري ځکه چې موږ دا د `slice` څخه ترلاسه کړی.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // خوندي: زنګ وهونکی تضمین کوي چې `self` د `slice` حدود کې دی
        // چې د `add` لپاره ټول شرایط خوښوي.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // خوندي: د `get_unchecked` لپاره نظرونه وګورئ.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_bundary چیک کوي چې شاخص [0 کې دی ، .len()] نشي کولی `get` د پورته په څیر وکاروي ، ځکه چې د NLL ستونزې له امله
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // خوندي: یوازې چیک شوي چې `start` او `end` په چار چت کې دي ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// د سنتیکس `&self[.. end]` یا `&mut self[.. end]` سره سلیسینګ سټرینګ تطبیقوي.
///
/// د ورکړل شوي مزي یوه ټوټه د بایټ سلسلې [`0` ، `end`) څخه راګرځوي.
/// د `&self[0 .. end]` یا `&mut self[0 .. end]` سره مساوي.
///
/// دا عملیات *O*(1) دي.
///
/// د 1.20.0 دمخه ، د دې شاخصونو عملیات لاهم د `Index` او `IndexMut` د مستقیم پلي کولو لخوا ملاتړ شوي و.
///
/// # Panics
///
/// Panics که `end` د کرکټر پیل بایټ سیټ ته اشاره نه کوي (لکه څنګه چې د `is_char_boundary` لخوا تعریف شوی) ، یا که `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // خوندي: یوازې چیک شوي چې `end` په چار چت کې دی ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // خوندي: یوازې چیک شوي چې `end` په چار چت کې دی ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // خوندي: یوازې چیک شوي چې `end` په چار چت کې دی ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// د سنتیکس `&self[begin ..]` یا `&mut self[begin ..]` سره سلیسینګ سټرینګ تطبیقوي.
///
/// د ورکړل شوي مزي یوه ټوټه د بایټ سلسلې [`پیل` ، `len`) څخه راستنوي.`&ځان ته مساوي [پیل ..
/// لین] `یا`&ځان بدل کړئ [پیل ..
/// len]`.
///
/// دا عملیات *O*(1) دي.
///
/// د 1.20.0 دمخه ، د دې شاخصونو عملیات لاهم د `Index` او `IndexMut` د مستقیم پلي کولو لخوا ملاتړ شوي و.
///
/// # Panics
///
/// Panics که `begin` د کرکټر پیل بایټ سیټ ته اشاره نه کوي (لکه څنګه چې د `is_char_boundary` لخوا تعریف شوی) ، یا که `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // خوندي: یوازې چیک شوي چې `start` په چار چت کې دی ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // خوندي: یوازې چیک شوي چې `start` په چار چت کې دی ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // خوندي: زنګ وهونکی تضمین کوي چې `self` د `slice` حدود کې دی
        // چې د `add` لپاره ټول شرایط خوښوي.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // خوندي: د `get_unchecked` سره ورته.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // خوندي: یوازې چیک شوي چې `start` په چار چت کې دی ،
            // او موږ په خوندي حواله روان یو ، نو د بیرته ستنیدو ارزښت به هم یو وي.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// د سنتیکس `&self[begin ..= end]` یا `&mut self[begin ..= end]` سره سلیسینګ سټرینګ تطبیقوي.
///
/// د بایټ رینج [`begin`, `end`] څخه ورکړل شوي مزي یوه ټوټه بیرته راولي.د `&self [begin .. end + 1]` یا `&mut self[begin .. end + 1]` سره مساوي ، پرته لدې که `end` د `usize` لپاره اعظمي ارزښت لري.
///
/// دا عملیات *O*(1) دي.
///
/// # Panics
///
/// Panics که `begin` د یو کرکټ ابتدایی بایټ سیټ ته اشاره نه کوي (لکه څنګه چې د `is_char_boundary` لخوا تعریف شوی) ، که `end` د کریکټ پای بایټ سیټ ته اشاره نه کوي (`end + 1` یا د پیل بایټ آفسیټ دی یا د `len` سره مساوي) ، که `begin > end` ، یا که `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // خوندي: زنګ وهونکی باید د `get_unchecked` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // خوندي: زنګ وهونکی باید د `get_unchecked_mut` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// د سنتیکس `&self[..= end]` یا `&mut self[..= end]` سره سلیسینګ سټرینګ تطبیقوي.
///
/// د بایټ رینج [0, `end`] څخه د ورکړل شوي مزي ټوټه بیرته راولي.
/// د `&self [0 .. end + 1]` سره مساوي ، په استثنا د `end` د `usize` لپاره اعظمي ارزښت لري.
///
/// دا عملیات *O*(1) دي.
///
/// # Panics
///
/// Panics که `end` د کرکټر پای بایټ سیټ ته اشاره نه کوي (`end + 1` یا د پیل بایټ سیټ دی چې د `is_char_boundary` لخوا تعریف شوی ، یا د `len` سره مساوي دی) ، یا که `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // خوندي: زنګ وهونکی باید د `get_unchecked` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // خوندي: زنګ وهونکی باید د `get_unchecked_mut` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// د تار څخه ارزښت وټاکئ
///
/// د SStr`د [`from_str`] میتود ډیری ځله په څرګند ډول کارول کیږي ، د [`str`] د [`parse`] میتود له لارې.
/// د مثالونو لپاره د [ars پارسي] اسناد وګورئ.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` د ژوند پیرامیټر نلري ، او نو تاسو یوازې هغه ډولونه نشئ کولی شئ چې پخپله یې د ژوند دورې پیرامیټر نلري.
///
/// په نورو ټکو ، تاسو کولی شئ د `FromStr` سره د `i32` پارس کړئ ، مګر د `&i32` نه.
/// تاسو کولی شئ داسې جوړښت تجزیه کړئ چې `i32` لري ، مګر یو داسې نه چې `&i32` ولري.
///
/// # Examples
///
/// د مثال په ډول `Point` ډول د `FromStr` لومړني پلي کول:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// اړونده تېروتنه چې د جلا کولو څخه بیرته راګرځیدلی شي.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// د دې ډول ارزښت بیرته ورکولو لپاره د تار `s` تجزیه کوي.
    ///
    /// که چیرې بریدل بریالي شي ، نو د [`Ok`] دننه ارزښت بیرته راګرځئ ، که نه نو کله چې تار تار ب illه شوې وي دننه [`Err`] ته ځانګړې شوې خطا بیرته راشئ.
    /// د خطا ډول د trait پلي کولو ته ځانګړی دی.
    ///
    /// # Examples
    ///
    /// د [`i32`] سره اساسي کارول ، یو ډول چې د `FromStr` پلي کوي:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// د تار څخه د `bool` پارس کړئ.
    ///
    /// د `Result<bool, ParseBoolError>` حاصل ورکوي ، ځکه چې `s` ممکن په حقیقت کې د تجزیې وړ وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// یادونه ، په ډیری قضیو کې ، په `str` کې د `.parse()` میتود ډیر مناسب دی.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}