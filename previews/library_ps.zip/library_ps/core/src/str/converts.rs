//! د بایټ سلیس څخه د `str` رامینځته کولو لارې.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// د بایټونو ټوټه په مزی لړ ته اړوي.
///
/// د تار سلیس ([`&str`]) د بایټس ([`u8`]) څخه جوړ شوی ، او د بایټ سلیس ([`&[u8]`][byteslice]) د بایټونو څخه جوړ شوی دی ، نو دا فنکشن د دوه ترمینځ بدلیږي.
/// ټول بایټ سلیزونه د اعتبار وړ سوري سوريز ندي ، په هرصورت: [`&str`] اړتیا لري چې دا د اعتبار وړ UTF-8 وي.
/// `from_utf8()` چک کوي ترڅو ډاډ ترلاسه کړي چې بایټ د UTF-8 معتبر دي ، او بیا د تبادلې ترسره کوي.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// که تاسو ډاډه یاست چې د بایټ سلایس د UTF-8 معتبر دی ، او تاسو نه غواړئ د اعتبار چیک چیک کړئ ، د دې فنون یوه ناخوندي نسخه ده ، [`from_utf8_unchecked`] ، چې ورته چلند لري مګر چیک پریږدي.
///
///
/// که تاسو د `&str` پرځای `String` ته اړتیا لرئ ، نو [`String::from_utf8`][string] په پام کې ونیسئ.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// ځکه چې تاسو کولی شئ د `[u8; N]` اسٹیک-اختصاص وکړئ ، او تاسو کولی شئ د دې څخه [`&[u8]`][byteslice] واخلئ ، دا فنکشن د سټیک مختص شوي تار لپاره یوه لاره ده.لاندې مثالونو برخې کې د دې مثال شتون لري.
///
/// [byteslice]: slice
///
/// # Errors
///
/// `Err` راګرځوي که چیرې سلیس د توضیح سره UTF-8 نه وي نو دا چې ولې چمتو شوي ټوټه UTF-8 نه وي.
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::str;
///
/// // ځینې بایټس ، په vector کې
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // موږ پوهیږو چې دا بایټونه معتبر دي ، نو یوازې د `unwrap()` کارول.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// ناسم بایټس:
///
/// ```
/// use std::str;
///
/// // ځینې ناباوره بایټس ، په vector کې
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// د غلطیو ډولونو په اړه نورو معلوماتو لپاره بیرته راستنیدلو لپاره د [`Utf8Error`] لپاره اسناد وګورئ.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ځینې بایټونه ، په یوه ټولبار شوي تخصیص شوي صف کې
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // موږ پوهیږو چې دا بایټونه معتبر دي ، نو یوازې د `unwrap()` کارول.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // امنیت: یوازې منل شوی اعتبار.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// د بایټونو بدلولو سلیز د بدلون وړ سلیز ته بدلوي.
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" د بدلون وړ vector په توګه
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // لکه څنګه چې موږ پوهیږو چې دا بایټونه معتبر دي ، موږ کولی شو `unwrap()` وکاروو
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// ناسم بایټس:
///
/// ```
/// use std::str;
///
/// // ځینې بدلونونه په بدل وړ vector کې
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// د غلطیو ډولونو په اړه نورو معلوماتو لپاره بیرته راستنیدلو لپاره د [`Utf8Error`] لپاره اسناد وګورئ.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // امنیت: یوازې منل شوی اعتبار.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// د بایټس سلیز دې سوري سلیس ته بدلوي پرته لدې چې وګوري چې تار کې د اعتبار وړ UTF-8 شتون لري.
///
/// د نورو معلوماتو لپاره خوندي نسخه ، [`from_utf8`] وګورئ.
///
/// # Safety
///
/// دا فنکشن غیر محفوظ دی ځکه چې دا نه ګوري چې دا بایټس ته ورکړل شوي د اعتبار وړ UTF-8 دي.
/// که چیرې دا محدودیت سرغړونه شوی وي ، د چلند غیر تعریف شوي پایلې ، ځکه چې د Rust پاتې برخه فرض کوي چې [`&str`] د اعتبار وړ UTF-8 دي.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::str;
///
/// // ځینې بایټس ، په vector کې
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // خوندي: زنګ وهونکی باید تضمین وکړي چې بایټس `v` باوري UTF-8 دي.
    // هماغه ډول ترتیب لري په `&str` او `&[u8]` تکیه کوي.
    unsafe { mem::transmute(v) }
}

/// د بایټس سلیز دې سوري سلیس ته بدلوي پرته لدې چې وګوري چې تار کې د UTF-8 معتبر دی؛د بدلون وړ نسخه.
///
///
/// د لا نورو معلوماتو لپاره بې ثباته نسخه ، [`from_utf8_unchecked()`] وګورئ.
///
/// # Examples
///
/// بنسټیز کارول:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // خوندي: زنګ وهونکی باید تضمین وکړي چې بایټس `v`
    // د UTF-8 معتبر دي ، نو پدې توګه `*mut str` ته کاسټ خوندي دی.
    // همچنان ، د اشارې استدلال خوندي دی ځکه چې دا نښه د یوې مآخذ څخه راځي چې د لیکلو لپاره د اعتبار وړ تضمین لري.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}