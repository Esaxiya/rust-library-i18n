#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! د بهرني فعالیت انٹرفیس (FFI) تړلو پورې اړوند افادیتونه.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// د C `void` ډول سره مساوي کله چې د [pointer] په توګه وکارول شي.
///
/// په جوهر کې ، `*const c_void` د C د `const void*` سره مساوي دی او `*mut c_void` د C د `void*` سره مساوي دي.
/// ورته وویل ، دا * د سی د `void` راستنیدو ډول ته ورته نه دی ، کوم چې د Rust `()` ډول دی.
///
/// په ایف ایف آی کې د غیرمعمولي ډولونو ته اشاره کولو ماډل کولو لپاره ، تر هغه چې `extern type` مستحکم نه وي ، نو سپارښتنه کیږي چې د خالي بایټ صفونو شاوخوا newtype ریپر وکاروئ.
///
/// د توضیحاتو لپاره [Nomicon] وګورئ.
///
/// یو څوک کولی شي `std::os::raw::c_void` وکاروي که دوی وغواړي 1.1.0 ته د زاړه Rust تالیف کونکي ملاتړ وکړي.
/// د Rust 1.30.0 وروسته ، دا د دې تعریف لخوا بیا صادر شوی.
/// د نورو معلوماتو لپاره ، مهرباني وکړئ [RFC 2521] ولولئ.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB ، د LLVM لپاره د بایډر پوائنټر ډول پیژني او د malloc() په څیر د تمدید افعال لخوا ، موږ اړتیا لرو چې دا په LLVM بټکوډ کې د i8 * په توګه وټاکل شي.
// دلته کاریدونکي اینوم دا تضمینوي او د "raw" ډوله ناوړه ګټه اخیستنې مخه نیسي یوازې د خصوصي بianو درلودو سره.
// موږ دوه ډولونو ته اړتیا لرو ، ځکه چې تالیف کونکی د repr خاصیت په اړه شکایت کوي او موږ لږترلږه یو ډول ته اړتیا لرو ځکه چې نه نو اینم به بې ځایه وي او لږترلږه د دې ډول نښو لرې کول به UB وي.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// د `va_list` اساسي تطبیق.
// نوم یې WIP دی ، د اوس لپاره د `VaListImpl` کارول.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // د `'f` څخه ډیر متغیر دی ، نو هر `VaListImpl<'f>` څیز د هغه فعالیت ساحې پورې تړل شوی چې ورته تعریف شوي
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI د `va_list` تطبیق.
/// د نورو جزیاتو لپاره [AArch64 Procedure Call Standard] وګورئ.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI د `va_list` تطبیق.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI د `va_list` تطبیق.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// د `va_list` لپاره ریپر
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` په `VaList` کې بدل کړئ چې د C د `va_list` سره بائنری مطابقت لري.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` په `VaList` کې بدل کړئ چې د C د `va_list` سره بائنری مطابقت لري.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// د VaArgSafe trait باید په عامه خبرو اترو کې وکارول شي ، په هرصورت ، پخپله trait باید اجازه ورنکړل شي چې له دې ماډل بهر وکارول شي.
// د کاروونکو ته اجازه ورکول چې د نوي ډول لپاره trait پلي کړي (پدې توګه د va_arg انټرنیټک ته اجازه ورکول په نوي ډول وکارول شي) احتمال لري د غیر تعریف شوي چلند لامل شي.
//
// FIXME(dlrobertson): د دې لپاره چې په عامه انټرنیټ کې د VaArgSafe trait کارولو لپاره مګر دا هم ډاډه کړئ چې دا په بل ځای کې نشي کارول کیدی ، trait اړتیا لري چې په شخصي انډول کې عامه شي.
// یوځل چې د RFC 2145 پلي شوی نو د دې پرمختګ ته به وګوره.
//
//
//
//
mod sealed_trait {
    /// Trait کوم چې د [super::VaListImpl::arg] سره د کارولو اجازه ورکړل شوي ډولونه ته اجازه ورکوي.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// راتلونکي ارګ ته ورشئ.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // خوندي: زنګ وهونکی باید د `va_arg` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe { va_arg(self) }
    }

    /// په اوسني موقعیت کې د `va_list` کاپي کول.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // خوندي: زنګ وهونکی باید د `va_end` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // خوندي: موږ `MaybeUninit` ته لیکو ، پدې توګه دا پیل شوی او `assume_init` قانوني دی
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: دا باید `va_end` زنګ ووهي ، مګر د دې لپاره هیڅ پاکه لار نشته
        // تضمین ورکړئ چې `drop` تل د هغه زنګ وهونکي ته ننوځي ، نو د `va_end` به مستقیم د ورته `va_copy` ورته فنکشن څخه زنګ ووهي.
        // `man va_end` څرګندوي چې C دې ته اړتیا لري ، او LLVM اساسا د C سیمینټیک تعقیبوي ، نو موږ باید ډاډ ترلاسه کړو چې `va_end` تل د ورته فعالیت څخه د `va_copy` په نوم غوښتل کیږي.
        //
        // د نورو جزیاتو لپاره ، see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // دا د اوس لپاره کار کوي ، ځکه چې `va_end` په ټولو اوسني LLVM اهدافو کې انتخاب نه دی.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// د `va_start` یا `va_copy` سره د ابتدایی وروسته ارګسټل `ap` له مینځه وړو.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// د ارګ لیست `src` اوسنی موقعیت ارګالیست `dst` ته کاپي کوي.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// د `T` X `ap` څخه د `T` ډول دلیل پورته کوي او د دلیل `ap` ته اشاره کوي.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}