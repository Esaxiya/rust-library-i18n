#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` د دندې اجرا کونکي پلي کونکي ته اجازه ورکوي چې [`Waker`] رامینځته کړي کوم چې د بیدار شوي کسب چلند دود چمتو کوي.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// دا د ډیټا پوائنټر او [virtual function pointer table (vtable)][vtable] مشتمل دی چې د `RawWaker` چلند دودوي.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// د ډیټا اشاره ، کوم چې د پخپل سري معلوماتو له مخې ذخیره کولو لپاره کارول کیدی شي لکه څنګه چې اجرایوي ورته اړتیا لري.
    /// دا مثال کیدی شي
    /// ایکس ایکس ایکس ایکس ته یو ډول پاک شوی نښه شوی چې له دندې سره تړاو لري.
    /// د دې ساحې ارزښت ټولو افعال ته لیږدول کیږي چې د لومړي پیرامیټر په توګه د ویټبل برخه وي.
    ///
    data: *const (),
    /// د مجازی فعالیت نښې میز چې د دې واکر چلند تنظیموي.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// د چمتو شوي `data` پوائنټر او `vtable` څخه نوی `RawWaker` رامینځته کوي.
    ///
    /// د `data` نښې کولی شي د ارقامو ډیټا ذخیره کولو لپاره وکارول شي لکه څنګه چې اجرایوي لخوا ورته اړتیا وي.دا مثال کیدی شي
    /// ایکس ایکس ایکس ایکس ته یو ډول پاک شوی نښه شوی چې له دندې سره تړاو لري.
    /// د دې نښې ارزښت به ټولو افعال ته انتقال شي چې د لومړي پیرامیټر په توګه د `vtable` برخه وي.
    ///
    /// `vtable` د `Waker` چلند دودوي چې د `RawWaker` څخه رامینځته کیږي.
    /// په `Waker` کې د هر عملیاتو لپاره ، د `RawWaker` اصلي زیرمو `vtable` کې اړوند فعالیت به وبلل شي.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// یو مجازی فنکشن پوائنټر میز (vtable) چې د [`RawWaker`] چلند مشخص کوي.
///
/// هغه وینډوز چې د vtable دننه ټولو وظیفو ته لیږدول شوی د X0 `data` نښه له تړلو [`RawWaker`] څیز څخه دی.
///
/// د دې جوړښت دننه فعالیتونه یوازې د [`RawWaker`] پلي کولو دننه دننه د مناسب جوړ شوي [`RawWaker`] څیز `data` پوائنټر ته زنګ وهل دي.
/// د نورو `data` پوائنټر کارولو سره یو له موجود افعالونو څخه زنګ وهل به د نامعلوم چلند لامل شي.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// دا فنکشن به زنګ ووهي کله چې [`RawWaker`] کلون شي ، د مثال په توګه کله چې [`Waker`] په کوم کې چې د [`RawWaker`] ذخیره کیږي کلون شي.
    ///
    /// د دې فنکشن پلي کول باید ټولې سرچینې وساتي چې د دې اضافي مثال لپاره د [`RawWaker`] او اړوند کار لپاره اړین دي.
    /// په پایله شوې [`RawWaker`] باندې د `wake` زنګ وهل باید د ورته کار پایله کې راشي چې د اصلي [`RawWaker`] لخوا راویښ شوي وي.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// دا فنکشن به زنګ ووهي کله چې `wake` په [`Waker`] زنګ ووهي.
    /// دا باید د دې [`RawWaker`] پورې تړلې دنده راوباسي.
    ///
    /// د دې فنکشن پلي کول باید ډاډ ترلاسه کړي چې هرهغه سرچینې خوشې کړي چې د دې مثال سره د [`RawWaker`] او اړوند کار پورې تړاو لري.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// دا فنکشن به زنګ ووهي کله چې `wake_by_ref` په [`Waker`] زنګ ووهي.
    /// دا باید د دې [`RawWaker`] پورې تړلې دنده راوباسي.
    ///
    /// دا فنکشن د `wake` سره ورته دی ، مګر باید چمتو شوي ډاټا پوائنټر ونه مصرف کړي.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// دا فنکشن بلل کیږي کله چې [`RawWaker`] راټیټ شي.
    ///
    /// د دې فنکشن پلي کول باید ډاډ ترلاسه کړي چې هرهغه سرچینې خوشې کړي چې د دې مثال سره د [`RawWaker`] او اړوند کار پورې تړاو لري.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// د چمتو شوي `clone` ، `wake` ، `wake_by_ref` ، او `drop` افعالاتو څخه نوی `RawWakerVTable` رامینځته کوي.
    ///
    /// # `clone`
    ///
    /// دا فنکشن به زنګ ووهي کله چې [`RawWaker`] کلون شي ، د مثال په توګه کله چې [`Waker`] په کوم کې چې د [`RawWaker`] ذخیره کیږي کلون شي.
    ///
    /// د دې فنکشن پلي کول باید ټولې سرچینې وساتي چې د دې اضافي مثال لپاره د [`RawWaker`] او اړوند کار لپاره اړین دي.
    /// په پایله شوې [`RawWaker`] باندې د `wake` زنګ وهل باید د ورته کار پایله کې راشي چې د اصلي [`RawWaker`] لخوا راویښ شوي وي.
    ///
    /// # `wake`
    ///
    /// دا فنکشن به زنګ ووهي کله چې `wake` په [`Waker`] زنګ ووهي.
    /// دا باید د دې [`RawWaker`] پورې تړلې دنده راوباسي.
    ///
    /// د دې فنکشن پلي کول باید ډاډ ترلاسه کړي چې هرهغه سرچینې خوشې کړي چې د دې مثال سره د [`RawWaker`] او اړوند کار پورې تړاو لري.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// دا فنکشن به زنګ ووهي کله چې `wake_by_ref` په [`Waker`] زنګ ووهي.
    /// دا باید د دې [`RawWaker`] پورې تړلې دنده راوباسي.
    ///
    /// دا فنکشن د `wake` سره ورته دی ، مګر باید چمتو شوي ډاټا پوائنټر ونه مصرف کړي.
    ///
    /// # `drop`
    ///
    /// دا فنکشن بلل کیږي کله چې [`RawWaker`] راټیټ شي.
    ///
    /// د دې فنکشن پلي کول باید ډاډ ترلاسه کړي چې هرهغه سرچینې خوشې کړي چې د دې مثال سره د [`RawWaker`] او اړوند کار پورې تړاو لري.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// د غیر عضله کار `Context`.
///
/// اوس مهال ، `Context` یوازې `&Waker` ته لاسرسي چمتو کوي چې د اوسنۍ دندې راویښولو لپاره وکارول شي.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ډاډ ترلاسه کړئ چې موږ د توپیر بدلونونو پروړاندې future-پروف د ژوند په اوږدو کې اجباري ایښودلو سره مجبور کوو (د استدلال-موقعیت ژوندون تضاد لري پداسې حال کې چې د راستنیدونکي وضعیت وختونه د کورینټ دي).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// له `&Waker` څخه نوی `Context` جوړ کړئ.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// د اوسني کار لپاره `Waker` ته مراجعه کوي.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` د دې د اجرا کونکي په خبرولو سره د دندې د جایدولو لپاره یو هینڈل دی چې دا چلولو ته چمتو دی.
///
/// دا هینډل د [`RawWaker`] مثال رامینځته کوي ، کوم چې د اجرا کونکي-ځانګړي ویښته چلند تعریف کوي.
///
///
/// [`Clone`] ، [`Send`] ، او [`Sync`] تطبیقوي.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// د دې `Waker` سره وابسته دنده وخورئ.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // ریښتنی ویښ غږ د تطبیق لپاره د مجازی فن کال له لارې استول شوی چې د اجرا کونکي لخوا تعریف شوی.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` تلیفون مه کوئ-بیکر به د `wake` لخوا مصرف شي.
        crate::mem::forget(self);

        // خوندي: دا خوندي دی ځکه چې `Waker::from_raw` یوازینۍ لار ده
        // د `wake` او `data` پیل کولو لپاره کارونکي اړتیا ته اړتیا لري ترڅو ومني چې د `RawWaker` تړون لاسلیک شوی.
        //
        unsafe { (wake)(data) };
    }

    /// د `Waker` مصرفولو پرته د دې `Waker` سره وابسته دنده وخورئ.
    ///
    /// دا د `wake` سره ورته دی ، مګر ممکن په هغه حالت کې یو څه لږ اغیزمن وي چیرې چې ملکیت لرونکی `Waker` شتون ولري.
    /// دا طریقه باید د `waker.clone().wake()` زنګ وهلو ته ترجیح ورکړل شي.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // ریښتنی ویښ غږ د تطبیق لپاره د مجازی فن کال له لارې استول شوی چې د اجرا کونکي لخوا تعریف شوی.
        //

        // خوندي: `wake` وګورئ
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// `true` راستنوي که چیرې دا `Waker` او بل `Waker` ورته کار له سره راپورته کړي.
    ///
    /// دا فنکشن د غوره هڅو پر اساس کار کوي ، او ممکن غلط راپورته شي حتی کله چې واکران هم ورته دنده بیدار کړي.
    /// په هرصورت ، که چیرې دا فنون `true` بیرته راشي ، نو دا تضمین دی چې `واکرز به ورته دنده بیدار کړي.
    ///
    /// دا فنکشن په عمده توګه د مطلوب اهدافو لپاره کارول کیږي.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// د [`RawWaker`] څخه نوی `Waker` رامینځته کوي.
    ///
    /// د بیرته راوړل شوي `Waker` چلند ندی ټاکل شوی که چیرې د [`RawWaker`] او [[RawWakerVTable`]] اسنادو کې ټاکل شوی تړون سم نه وي.
    ///
    /// له همدې امله دا میتود خوندي نه دی.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // خوندي: دا خوندي دی ځکه چې `Waker::from_raw` یوازینۍ لار ده
            // د `clone` او `data` پیل کولو لپاره کارونکي اړتیا ته اړتیا لري ترڅو ومني چې د [`RawWaker`] تړون لاسلیک شوی.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // خوندي: دا خوندي دی ځکه چې `Waker::from_raw` یوازینۍ لار ده
        // د `drop` او `data` پیل کولو لپاره کارونکي اړتیا ته اړتیا لري ترڅو ومني چې د `RawWaker` تړون لاسلیک شوی.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}