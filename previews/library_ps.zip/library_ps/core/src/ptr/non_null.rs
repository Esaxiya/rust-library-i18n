use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` مګر غیر صفر او ځیرک.
///
/// دا ډیری وختونه د کارولو لپاره درست شی دی کله چې د خام نقطو په کارولو سره د ډیټا جوړښتونو رامینځته کول ، مګر په نهایت کې د هغې د اضافي ملکیتونو له امله کارول خطرناک دي.که تاسو ډاډه نه یاست که تاسو باید `NonNull<T>` وکاروئ ، یوازې `*mut T` وکاروئ!
///
/// د `*mut T` برعکس ، اشاره باید تل غیر خالص وي ، حتی که چیرې پوائنټر هیڅکله هم درز نه وي.دا داسې دی چې اینامز ممکن دا منع شوي ارزښت د امتیاز په توګه وکاروي-`Option<NonNull<T>>` د `* mut T` ورته اندازه لري.
/// په هرصورت ، اشاره ممکن لاهم پیچل کړي که چیرې دا درناوی ونلري.
///
/// د `*mut T` برعکس ، `NonNull<T>` د `T` په پرتله د حوصله مندۍ لپاره غوره شوی و.دا ممکنه کوي چې د `NonNull<T>` کارولو کله چې د covariant ډولونه جوړ کړئ کار واخلئ ، مګر د بې غږۍ خطر معرفي کوي که چیرې په داسې ډول وکارول شي چې باید واقعیا همجنس نه وي.
/// (برعکس انتخاب د `*mut T` لپاره شوی و پداسې حال کې چې تخنیکي پلوه بې باوري یوازې د غیر خوندي کارونو غږولو له امله رامینځته کیدلی شي.)
///
/// کوارینس د ډیری خوندي خلاصونونو لپاره درست دی ، لکه `Box` ، `Rc` ، `Arc` ، `Vec` ، او `LinkedList`.دا قضیه ده ځکه چې دوی عامه API چمتو کوي چې د Rust نورمال مشترکه XOR بدلیدونکي قواعد تعقیبوي.
///
/// که ستاسو ډول خوندي نشي خوښې کیدی ، نو تاسو باید ډاډ ترلاسه کړئ چې دا د حملې چمتو کولو لپاره یو څه اضافي ساحه لري.اکثرا دا ساحه به د [`PhantomData`] ډول وي لکه `PhantomData<Cell<T>>` یا `PhantomData<&'a mut T>`.
///
/// په یاد ولرئ چې `NonNull<T>` د `&T` لپاره `From` مثال لري.په هرصورت ، دا حقیقت نه بدلوي چې د شریک حوالې له لارې تغیر ورکول د ټاکل شوي چلند غیر تعریف شوي چلند دی پرته لدې چې بدلون د [`UnsafeCell<T>`] دننه واقع شي.ورته د ګډ ریفرنس څخه د تغیر وړ حوالې رامینځته کولو لپاره ځي.
///
/// کله چې دا د `From` مثال وکاروئ د `UnsafeCell<T>` پرته ، دا ستاسو مسؤلیت دی چې ډاډ ترلاسه کړئ چې `as_mut` هیڅکله نه ویل کیږي ، او `as_ptr` هیڅکله د بدلون لپاره نه کارول کیږي.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` نښې `Send` ندي ځکه چې هغه معلومات چې دوی حواله کوي کیدای شي محافظت شي.
// NB ، دا تطبیق غیر ضروري دی ، مګر باید د غوره خطا پیغامونه چمتو کړي.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` نښې `Sync` ندي ځکه چې هغه معلومات چې دوی حواله کوي کیدای شي محافظت شي.
// NB ، دا تطبیق غیر ضروري دی ، مګر باید د غوره خطا پیغامونه چمتو کړي.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// یو نوی `NonNull` رامینځته کوي چې ځوړند وي ، مګر ښه سمون شوی.
    ///
    /// دا د ډولونو ابتکار لپاره ګټور دی کوم چې په کافي اندازه تخصیص کوي ، لکه `Vec::new` کوي.
    ///
    /// په یاد ولرئ چې د نښې ارزښت ممکن په احتمالي توګه د `T` لپاره معتبر نښې وښیې ، پدې معنی چې دا باید د "not yet initialized" لیږل شوي ارزښت په توګه ونه کارول شي.
    /// ډولونه چې په اسانۍ سره تخصیص کیږي باید د ځینې نورو وسیلو په مرسته ابتکار تعقیب کړي.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // خوندي: mem::align_of() یو نه صفر کارول بیرته راوړي کوم چې بیا کاسټ شوی
        // یو * مت T ته.
        // نو ځکه ، `ptr` باطل ندي او د new_unchecked() زنګ وهلو شرایط درناوی کیږي.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ارزښت ته شریک حوالې ورکوي.د [`as_ref`] برعکس ، دا اړتیا نلري چې ارزښت یې پیل شي.
    ///
    /// د تغیر وړ همکار لپاره [`as_uninit_mut`] وګورئ.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// کله چې دې میتود ته زنګ ووهئ ، نو تاسو باید ډاډه اوسئ چې لاندې ټول رښتیا دي:
    ///
    /// * نښې باید په سم ډول تنظیم شي.
    ///
    /// * دا باید په [the module documentation] کې تعریف شوي معنی کې "dereferencable" وي.
    ///
    /// * تاسو باید د Rust د ایلیسینګ قواعد پلي کړئ ، ځکه چې بیرته راستانه شوي `'a` په خپل سري توګه غوره شوی او اړتیا نلري د ارقامو ریښتیني ژوند منعکس کړي.
    ///
    ///   په ځانګړي توګه ، د دې ژوند دورې لپاره ، یادداشت کونکي اشاره کوي باید بدل نشي (په `UnsafeCell` کې دننه).
    ///
    /// دا تطبیق کیږي حتی که د دې میتود پایله بې ګټې وي!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` ټول سره پوره کوي
        // د مراجعې لپاره اړتیاوې.
        unsafe { &*self.cast().as_ptr() }
    }

    /// ارزښت ته ځانګړی حواله ورکوي.د [`as_mut`] برعکس ، دا اړتیا نلري چې ارزښت یې پیل شي.
    ///
    /// د شریک همکارۍ لپاره وګورئ [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// کله چې دې میتود ته زنګ ووهئ ، نو تاسو باید ډاډه اوسئ چې لاندې ټول رښتیا دي:
    ///
    /// * نښې باید په سم ډول تنظیم شي.
    ///
    /// * دا باید په [the module documentation] کې تعریف شوي معنی کې "dereferencable" وي.
    ///
    /// * تاسو باید د Rust د ایلیسینګ قواعد پلي کړئ ، ځکه چې بیرته راستانه شوي `'a` په خپل سري توګه غوره شوی او اړتیا نلري د ارقامو ریښتیني ژوند منعکس کړي.
    ///
    ///   په ځانګړي توګه ، د دې ژوند دورې لپاره ، هغه حافظه چې اشاره کوي یې باید د بلې نښې له لارې لاسرسی ونلري (لوستل یا لیکل شوي وي).
    ///
    /// دا تطبیق کیږي حتی که د دې میتود پایله بې ګټې وي!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` ټول سره پوره کوي
        // د مراجعې لپاره اړتیاوې.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// نوی `NonNull` رامینځته کوي.
    ///
    /// # Safety
    ///
    /// `ptr` باید غیر خالص وي.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `ptr` غیر خالي وي.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// نوی `NonNull` رامینځته کوي که `ptr` غیر خالي وي.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // خوندي: نښې لا دمخه چیک شوي او خالي ندي
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// د [`std::ptr::from_raw_parts`] په څیر ورته فعالیت ترسره کوي ، پرته لدې چې د `NonNull` پوائنټر بیرته راوړل کیږي ، لکه څنګه چې د خام `*const` پوائنټر سره مخالفت لري.
    ///
    ///
    /// د نورو جزیاتو لپاره د [`std::ptr::from_raw_parts`] سند وګورئ.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // خوندي: د `ptr::from::raw_parts_mut` پایله غیر منفي ده ځکه چې `data_address` ده.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// د (ممکنه پراخه) نښې غورځول پته او د میټاټاټا اجزاوې دي.
    ///
    /// پوائنټور وروسته د [`NonNull::from_raw_parts`] سره جوړ کیدی شي.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// د `*mut` اصلي نښه ترلاسه کوي.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ارزښت ته ګډه حواله ورکوي.که ارزښت ممکن غیر منبع شي ، نو [`as_uninit_ref`] باید د دې پرځای وکارول شي.
    ///
    /// د تغیر وړ همکار لپاره [`as_mut`] وګورئ.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// کله چې دې میتود ته زنګ ووهئ ، نو تاسو باید ډاډه اوسئ چې لاندې ټول رښتیا دي:
    ///
    /// * نښې باید په سم ډول تنظیم شي.
    ///
    /// * دا باید په [the module documentation] کې تعریف شوي معنی کې "dereferencable" وي.
    ///
    /// * نښې باید د `T` لومړني مثال ته په ګوته کړي.
    ///
    /// * تاسو باید د Rust د ایلیسینګ قواعد پلي کړئ ، ځکه چې بیرته راستانه شوي `'a` په خپل سري توګه غوره شوی او اړتیا نلري د ارقامو ریښتیني ژوند منعکس کړي.
    ///
    ///   په ځانګړي توګه ، د دې ژوند دورې لپاره ، یادداشت کونکي اشاره کوي باید بدل نشي (په `UnsafeCell` کې دننه).
    ///
    /// دا تطبیق کیږي حتی که د دې میتود پایله بې ګټې وي!
    /// (د پیل په اړه برخه لاهم په بشپړ ډول پریکړه نده شوې ، مګر تر هغه چې دا وي ، یوازینۍ خوندي لاره دا ده چې ډاډ ترلاسه شي چې دوی واقعیا پیل شوي.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` ټول سره پوره کوي
        // د مراجعې لپاره اړتیاوې.
        unsafe { &*self.as_ptr() }
    }

    /// ارزښت ته ځانګړی حواله ورکوي.که ارزښت ممکن غیر منبع شي ، نو [`as_uninit_mut`] باید د دې پرځای وکارول شي.
    ///
    /// د شریک همکارۍ لپاره وګورئ [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// کله چې دې میتود ته زنګ ووهئ ، نو تاسو باید ډاډه اوسئ چې لاندې ټول رښتیا دي:
    ///
    /// * نښې باید په سم ډول تنظیم شي.
    ///
    /// * دا باید په [the module documentation] کې تعریف شوي معنی کې "dereferencable" وي.
    ///
    /// * نښې باید د `T` لومړني مثال ته په ګوته کړي.
    ///
    /// * تاسو باید د Rust د ایلیسینګ قواعد پلي کړئ ، ځکه چې بیرته راستانه شوي `'a` په خپل سري توګه غوره شوی او اړتیا نلري د ارقامو ریښتیني ژوند منعکس کړي.
    ///
    ///   په ځانګړي توګه ، د دې ژوند دورې لپاره ، هغه حافظه چې اشاره کوي یې باید د بلې نښې له لارې لاسرسی ونلري (لوستل یا لیکل شوي وي).
    ///
    /// دا تطبیق کیږي حتی که د دې میتود پایله بې ګټې وي!
    /// (د پیل په اړه برخه لاهم په بشپړ ډول پریکړه نده شوې ، مګر تر هغه چې دا وي ، یوازینۍ خوندي لاره دا ده چې ډاډ ترلاسه شي چې دوی واقعیا پیل شوي.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` ټول سره پوره کوي
        // د بدلون وړ مآخذ ته اړتیا
        unsafe { &mut *self.as_ptr() }
    }

    /// د بل ډول نښو ته نښه.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // خوندي: `self` د `NonNull` نښې دي چې لازمه نه ده
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// د پتلي پوائنټر او اوږدوالي څخه یو غیر خالي خام سلیس رامینځته کوي.
    ///
    /// د `len` دلیل د **عناصر** شمیره ده ، نه د بایټونو شمیر.
    ///
    /// دا فنکشن خوندي دی ، مګر د بیرته راستنیدو ارزښت نه منل غیر محفوظ دی.
    /// د ټوټې خوندیتوب اړتیاو لپاره د [`slice::from_raw_parts`] سند وګورئ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // سلیس پوائنټر جوړ کړئ کله چې لومړي عنصر ته د پوائنټور سره پیل وکړئ
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (په یاد ولرئ چې دا مثال په مصنوعي ډول د دې میتود کارول ښیې ، مګر `پرېږدئ= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // خوندي: `data` د `NonNull` نښې دي چې لازمه نه ده
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// د نه خالي خام ټوټې اوږدوالی راولي.
    ///
    /// بیرته ورکړل شوی ارزښت د **عناصرو** شمیره ده ، نه د بایټونو شمیر.
    ///
    /// دا فنکشن خوندي دی ، حتی کله چې د غیر نل خام ټوټې ټوټې ته درناوی ونلري ځکه چې اشاره سمه پته نلري.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// د سلیس بفر ته غیر نول پوائنټر راستنوي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // خوندي: موږ پوهیږو چې `self` غیر شرعي دی.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// د سلایس بفر ته خام پواینټ راستنوي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// د احتمالي بې ځایه کیدونکو ارزښتونو یوې ټوټې ته ګډه حواله ورکوي.د [`as_ref`] برعکس ، دا اړتیا نلري چې ارزښت یې پیل شي.
    ///
    /// د تغیر وړ همکار لپاره [`as_uninit_slice_mut`] وګورئ.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// کله چې دې میتود ته زنګ ووهئ ، نو تاسو باید ډاډه اوسئ چې لاندې ټول رښتیا دي:
    ///
    /// * پوائنټر باید د `ptr.len() * mem::size_of::<T>()` ډیری بایټونو لوستلو لپاره [valid] وي ، او دا باید په سم ډول تنظیم شي.دا په ځانګړي ډول معنی لري:
    ///
    ///     * د دې ټوټې بشپړ حافظې لړۍ باید د یو واحد تخصیص شوي شي دننه ولري!
    ///       سلیز هیڅکله نشي کولی د ګ allocated شمیر تخصیص شوي توکو څخه تیر شي.
    ///
    ///     * نښې باید حتی د صفر-اوږدوالي سلیسونو لپاره مسدود شي.
    ///     د دې لپاره یو دلیل دا دی چې د اینوم ترتیب اصلاح کول ممکن په مآخذونو تکیه وکړي (د هرې اندازې سلیزو په شمول) ترتیب شوي او غیر خالي کول ترڅو د نورو معلوماتو څخه توپیر وکړي.
    ///
    ///     تاسو کولی شئ داسې نښه ترلاسه کړئ چې د [`NonNull::dangling()`] په کارولو سره د صفر اوږدوالي سلیسونو لپاره د `data` په توګه د کارولو وړ وي.
    ///
    /// * د ټوټې مجموعی اندازه `ptr.len() * mem::size_of::<T>()` باید د `isize::MAX` څخه لوی نه وي.
    ///   د [`pointer::offset`] د خوندیتوب اسناد وګورئ.
    ///
    /// * تاسو باید د Rust د ایلیسینګ قواعد پلي کړئ ، ځکه چې بیرته راستانه شوي `'a` په خپل سري توګه غوره شوی او اړتیا نلري د ارقامو ریښتیني ژوند منعکس کړي.
    ///   په ځانګړي توګه ، د دې ژوند دورې لپاره ، یادداشت کونکي اشاره کوي باید بدل نشي (په `UnsafeCell` کې دننه).
    ///
    /// دا تطبیق کیږي حتی که د دې میتود پایله بې ګټې وي!
    ///
    /// [`slice::from_raw_parts`] هم وګورئ.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // خوندي: زنګ وهونکی باید د `as_uninit_slice` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// د احتمالي بې بنسټه ارزښتونو سلیس ته ځانګړي حواله ورکوي.د [`as_mut`] برعکس ، دا اړتیا نلري چې ارزښت یې پیل شي.
    ///
    /// د شریک همکارۍ لپاره وګورئ [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// کله چې دې میتود ته زنګ ووهئ ، نو تاسو باید ډاډه اوسئ چې لاندې ټول رښتیا دي:
    ///
    /// * نښې باید د `ptr.len() * mem::size_of::<T>()` ډیری بایټونو لپاره د لوستلو او لیکلو لپاره [valid] وي ، او دا باید په سم ډول تنظیم شي.دا په ځانګړي ډول معنی لري:
    ///
    ///     * د دې ټوټې بشپړ حافظې لړۍ باید د یو واحد تخصیص شوي شي دننه ولري!
    ///       سلیز هیڅکله نشي کولی د ګ allocated شمیر تخصیص شوي توکو څخه تیر شي.
    ///
    ///     * نښې باید حتی د صفر-اوږدوالي سلیسونو لپاره مسدود شي.
    ///     د دې لپاره یو دلیل دا دی چې د اینوم ترتیب اصلاح کول ممکن په مآخذونو تکیه وکړي (د هرې اندازې سلیزو په شمول) ترتیب شوي او غیر خالي کول ترڅو د نورو معلوماتو څخه توپیر وکړي.
    ///
    ///     تاسو کولی شئ داسې نښه ترلاسه کړئ چې د [`NonNull::dangling()`] په کارولو سره د صفر اوږدوالي سلیسونو لپاره د `data` په توګه د کارولو وړ وي.
    ///
    /// * د ټوټې مجموعی اندازه `ptr.len() * mem::size_of::<T>()` باید د `isize::MAX` څخه لوی نه وي.
    ///   د [`pointer::offset`] د خوندیتوب اسناد وګورئ.
    ///
    /// * تاسو باید د Rust د ایلیسینګ قواعد پلي کړئ ، ځکه چې بیرته راستانه شوي `'a` په خپل سري توګه غوره شوی او اړتیا نلري د ارقامو ریښتیني ژوند منعکس کړي.
    ///   په ځانګړي توګه ، د دې ژوند دورې لپاره ، هغه حافظه چې اشاره کوي یې باید د بلې نښې له لارې لاسرسی ونلري (لوستل یا لیکل شوي وي).
    ///
    /// دا تطبیق کیږي حتی که د دې میتود پایله بې ګټې وي!
    ///
    /// [`slice::from_raw_parts_mut`] هم وګورئ.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // دا خوندي دی ځکه چې `memory` د لوستلو لپاره د اعتبار وړ دی او د `memory.len()` ډیری بایټونو لپاره لیکي.
    /// // په یاد ولرئ چې دلته د `memory.as_mut()` زنګ وهلو ته اجازه نه ورکول کیږي ځکه چې مینځپانګه کیدی شي بې بنسټه وي.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // خوندي: زنګ وهونکی باید د `as_uninit_slice_mut` لپاره د خوندیتوب تړون ملاتړ وکړي.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// د عنعې یا ضمني برخې ته ، بې له دې چې د حدود چیک کولو ترسره کولو لپاره خامو اشاره بیرته راشي.
    ///
    /// د دې میتود زنګ وهل له حدودو شاخصونو سره یا کله چې `self` د توجیه وړ نه وي * *[نه ټاکل شوی چلند] * حتی که چیرې پایلې لرونکي نښه ونه کارول شي.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // خوندي: زنګ وهونکی تضمینوي چې `self` د درز وړ او د `index` دننه دی.
        // د پایلې په توګه ، نتیجه اخیستونکی نیل نشي کیدی.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // خوندي: یو ځانګړی نښه کونکی نشي کیدی ، نو د دې لپاره شرایط
        // new_unchecked() درناوی کیږي
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // : SAableY::able A mutable. reference reference reference reference.. cannot n be be. be. be.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // : A .YY: reference A reference reference. n n. be. be........ so so.. conditions. conditions... for......
        // new_unchecked() درناوی کیږي
        unsafe { NonNull { pointer: reference as *const T } }
    }
}