#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// د هرې نښه شوي-ډول ډول نښې میټاټاټا ډول چمتو کوي.
///
/// # د نښې میټاډاټا
///
/// د Rust کې د خام نښې ډولونه او د حوالې ډولونه د دوه برخو څخه جوړ شوي په اړه فکر کیدی شي:
/// یو د ډیټا لیږونکی چې د ارزښت یادداشت پته لري ، او یو څه میډاټا.
///
/// د احصایې ډول ډولونو لپاره (چې د `Sized` traits پلي کوي) او د `extern` ډولونو لپاره ، نښې "پتلي" ویل کیږي: میټاډاټا د صفر اندازې ده او ډول یې `()` دی.
///
///
/// [dynamically-sized types][dst] ته اشارو ته ویل کیږي چې "پراخه" یا "غوړ" دي ، دوی د صفر نه اندازې میټاډاټا لري:
///
/// * د سټرکونو لپاره چې وروستی ډګر یې د DST دی ، میډیډاټا د وروستي ډګر لپاره میټاډاټا دی
/// * د `str` ډول لپاره ، میټاډاټا د `usize` په توګه په بایټونو کې اوږدوالی دی
/// * د `[T]` په څیر د سلیس ډولونو لپاره ، میټاډیټا د `usize` په څیر توکي کې اوږدوالی دی
/// * د trait څیزونو لکه `dyn SomeTrait` لپاره ، میټاډاټا [`DynMetadata<Self>`][DynMetadata] ده (د مثال په توګه `DynMetadata<dyn SomeTrait>`)
///
/// په future کې ، د Rust ژبه ممکن نوي ډولونه ترلاسه کړي چې مختلف پوائنټر میټاټا لري.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # د `Pointee` trait
///
/// د دې trait نقطه د دې `Metadata` پورې مربوط ډول دی ، کوم چې پورته بیان شوي `()` یا `usize` یا `DynMetadata<_>` دی.
/// دا په اتوماتيک ډول د هر ډول لپاره پلي کیږي.
/// دا فرض کیدلی شي چې په عمومي حالت کې پلي شي ، حتی له اړونده حد پرته.
///
/// # Usage
///
/// خام نښې د دوی د [`to_raw_parts`] میتود سره د ډاټا پته او میټاټاټا برخو کې شنډ کیدی شي.
///
/// په بدیل سره ، یوازې میټاډاټا د [`metadata`] فعالیت سره استخراج کیدی شي.
/// یو حواله کیدی شي [`metadata`] ته واستول شي او په کلکه یې فشار راوړل شي.
///
/// د (possibly-wide) پوائنټور د [`from_raw_parts`] یا [`from_raw_parts_mut`] سره د دې پتې او میټاټاټا څخه یوځل بیا کیښودل کیدی شي.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// په `Self` کې په اشارو او مآخذونو کې د میټاټاټا ډول.
    #[lang = "metadata_type"]
    // NOTE: په `static_assert_expected_bounds_for_metadata` کې trait bound وساتئ
    //
    // په `library/core/src/ptr/metadata.rs` کې د هغوی سره همغږۍ کې:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// د دې trait عرف تطبیق کولو ډولونو ته نښې "پتلې" دي.
///
/// پدې کې د احصایوي ډوله ډولونه او `extern` ډولونه شامل دي.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: د trait ایلیاس په ژبه کې مستحکم کیدو دمخه دا ثبات نه کړئ؟
pub trait Thin = Pointee<Metadata = ()>;

/// د پوائنټر میډیډاټا جز راوباسئ.
///
/// د `*mut T` ، `&T` ، یا `&mut T` ډول ډول ارزښتونه دې فعالیت ته مستقیم تیریدلی شي ځکه چې دوی په څرګنده ډول `* const T` ته اړ ایستل.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // خوندي: د `PtrRepr` اتحادیې څخه د ارزښت لاسرسی خوندي دی ځکه چې * د کان ټی
    // او د PtrC اجزاو<T>ورته د حافظې ب haveه ولرئ.
    // یوازې std کولی شي دا تضمین وکړي.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// د ډیټا پتې او میټاټاټا څخه د (possibly-wide) خام پوائنټر جوړوي.
///
/// دا فنکشن خوندي دی مګر بیرته راستانه شوی نښې لازمي نه دي د درناوي لپاره خوندي وي.
/// د ټوټو لپاره ، د خوندیتوب اړتیاو لپاره د [`slice::from_raw_parts`] سند وګورئ.
/// د trait څیزونو لپاره ، میټاډاټا باید د پوائنټور څخه ورته ورته زیرمه شوي ډول ته راشي.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // خوندي: د `PtrRepr` اتحادیې څخه د ارزښت لاسرسی خوندي دی ځکه چې * د کان ټی
    // او د PtrC اجزاو<T>ورته د حافظې ب haveه ولرئ.
    // یوازې std کولی شي دا تضمین وکړي.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// د [`from_raw_parts`] په څیر ورته فعالیت ترسره کوي ، پرته لدې چې د خامو `*mut` پوائنټر بیرته راوړل کیږي ، لکه څنګه چې د خام `* const` پوائنټر سره مخالفت لري.
///
///
/// د نورو جزیاتو لپاره د [`from_raw_parts`] سند وګورئ.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // خوندي: د `PtrRepr` اتحادیې څخه د ارزښت لاسرسی خوندي دی ځکه چې * د کان ټی
    // او د PtrC اجزاو<T>ورته د حافظې ب haveه ولرئ.
    // یوازې std کولی شي دا تضمین وکړي.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// لاسي تطبیق د `T: Copy` حدود مخنیوي لپاره اړین دی.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// لاسي تطبیق د `T: Clone` حدود مخنیوي لپاره اړین دی.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// د `Dyn = dyn SomeTrait` trait څیز ډول لپاره میټاټاټا.
///
/// دا د ویټبل (مجازی کال میز) ته اشاره کوي چې د trait څیز کې دننه زیرمه شوي کانکریټ ډوله اداره کولو لپاره ټول اړین معلومات وړاندې کوي.
/// دا vtable د پام وړ ټکي لري:
///
/// * د ډول کچه
/// * ډول برابرول
/// * د ډول ایکس ایکس ایکس امپلو ته نښه کول (ممکن د ساده زوړ ډیټا لپاره انتخاب نه وي)
/// * د trait د ډول پلي کولو لپاره ټولو میتودونو ته ګوته نیسي
///
/// په یاد ولرئ چې لومړۍ درې یې ځانګړي دي ځکه چې دا اړینه ده چې د trait څیز مختص ، غورځولو او له مینځه وړو لپاره.
///
/// دا ممکنه ده چې دا جوړښت د ډول پیرامیټر سره وټاکئ چې د `dyn` trait څیز نه وي (د مثال په توګه `DynMetadata<u64>`) مګر د دې جوړښت معنی ارزښت ترلاسه کولو لپاره ندي.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// د ټولو ویټبلونو معمول مختاړی.دا د trait میتودونو لپاره د فعالیت نښو لخوا تعقیب کیږي.
///
/// د `DynMetadata::size_of` وغيره شخصي پلي کولو توضیحات.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// د دې vtable سره د تړاو ډول اندازه بیرته راګرځوي.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// د دې vtable سره د اړونده ډول سمون راستون کوي.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// اندازه او صف بندي د `Layout` په توګه راټولیږي
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // خوندي: کمپیلر د دې کانټریټ Rust ډول لپاره دا ویټبل خارج کړ
        // د اعتبار وړ ب layoutه لري.ورته دلیل لکه په `Layout::for_value` کې.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// لاسي نقلونه د `Dyn: $Trait` حدود څخه مخنیوی لپاره اړین دي.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}