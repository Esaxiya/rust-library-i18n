use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// د خام غیر نهل `*mut T` په شاوخوا کې یو ریپر چې دا په ګوته کوي چې د دې ریپر مالک مالک د ریسرټ مالکیت لري.
/// د خلاصونې جوړولو لپاره لکه `Box<T>` ، `Vec<T>` ، `String` ، او `HashMap<K, V>` ګټور.
///
/// د `*mut T` په خلاف ، `Unique<T>` د "as if" چلند کوي دا د `T` مثال دی.
/// دا `Send`/`Sync` تطبیق کوي که `T` `Send`/`Sync` وي.
/// دا د قوي ایلیسینګ تضمین هم پلي کوي د `T` مثال تمه کولی شي:
/// د اشارې فرق باید د دې ځانګړي ملکیت ته یوه ځانګړې لاره پرته ترمیم نشي.
///
/// که تاسو ډاډه نه یاست چې ایا دا ستاسو د اهدافو لپاره د `Unique` کارول سم دي ، د `NonNull` کارولو ته پام وکړئ ، کوم چې ضعیف سیمانټیک لري.
///
///
/// د `*mut T` په خلاف ، اشاره کونکی باید تل غیر خالي وي ، حتی که چیرې پوائنټر هیڅکله هم درز نه وي.
/// دا داسې دی چې اینامز ممکن دا منع شوي ارزښت د امتیاز په توګه وکاروي-`Option<Unique<T>>` د `Unique<T>` ورته اندازه لري.
/// په هرصورت ، اشاره ممکن لاهم پیچل کړي که چیرې دا درناوی ونلري.
///
/// د `*mut T` په خلاف ، `Unique<T>` د `T` څخه ډیر همجنس دی.
/// دا باید تل د هر هغه ډول لپاره سم وي چې د ځانګړي بیلابیل غوښتنو ملاتړ کوي.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: دا نښه کونکي د توپیر لپاره کومه پایله نلري ، مګر لازمي دي
    // د قطع کولو لپاره چې پوه شو چې موږ په منطقي ډول د `T` مالکیت لرو.
    //
    // د نورو معلوماتو لپاره ، وګورئ:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` نښې `Send` دي که `T` `Send` وي ځکه چې هغه معلومات چې دوی حواله کوي بې اساسه دي.
/// په یاد ولرئ چې دغه بهرنی بریدګر د ډول سیسټم لخوا ندی پیاوړی شوی؛د `Unique` کارولو خلاصون باید دا پلي کړي.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` نښې `Sync` دي که `T` `Sync` وي ځکه چې هغه معلومات چې دوی حواله کوي بې اساسه دي.
/// په یاد ولرئ چې دغه بهرنی بریدګر د ډول سیسټم لخوا ندی پیاوړی شوی؛د `Unique` کارولو خلاصون باید دا پلي کړي.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// یو نوی `Unique` رامینځته کوي چې ځوړند وي ، مګر ښه سمون شوی.
    ///
    /// دا د ډولونو ابتکار لپاره ګټور دی کوم چې په کافي اندازه تخصیص کوي ، لکه `Vec::new` کوي.
    ///
    /// په یاد ولرئ چې د نښې ارزښت ممکن په احتمالي توګه د `T` لپاره معتبر نښې وښیې ، پدې معنی چې دا باید د "not yet initialized" لیږل شوي ارزښت په توګه ونه کارول شي.
    /// ډولونه چې په اسانۍ سره تخصیص کیږي باید د ځینې نورو وسیلو په مرسته ابتکار تعقیب کړي.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // خوندي: mem::align_of() یو با اعتباره ، نه منسوخونکی ته راستنوي.د
        // د new_unchecked() زنګ وهلو شرایط پدې ډول درناوی کیږي.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// نوی `Unique` رامینځته کوي.
    ///
    /// # Safety
    ///
    /// `ptr` باید غیر خالص وي.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `ptr` غیر خالي وي.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// نوی `Unique` رامینځته کوي که `ptr` غیر خالي وي.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // خوندي: نښې لا دمخه چیک شوي او خالي ندي.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// د `*mut` اصلي نښه ترلاسه کوي.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// د مینځپانګې درناوی.
    ///
    /// د پایلې په توګه ژوند پخپله پابند دی نو دا د "as if" چلند کوي دا په حقیقت کې د T مثال و چې پور اخیستل کیږي.
    /// که اوږد (unbound) ژوندون ته اړتیا وي ، نو `&*my_ptr.as_ptr()` وکاروئ.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` ټول سره پوره کوي
        // د مراجعې لپاره اړتیاوې.
        unsafe { &*self.as_ptr() }
    }

    /// په متناسب ډول د مینځپانګې درناوی.
    ///
    /// د پایلې په توګه ژوند پخپله پابند دی نو دا د "as if" چلند کوي دا په حقیقت کې د T مثال و چې پور اخیستل کیږي.
    /// که اوږد (unbound) ژوندون ته اړتیا وي ، نو `&mut *my_ptr.as_ptr()` وکاروئ.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // خوندي: زنګ وهونکی باید تضمین وکړي چې `self` ټول سره پوره کوي
        // د بدلون وړ مآخذ ته اړتیا
        unsafe { &mut *self.as_ptr() }
    }

    /// د بل ډول نښو ته نښه.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // خوندي: Unique::new_unchecked() یو نوی ځانګړي او اړتیاوې رامینځته کوي
        // ورکړل شوی نښې باید خالي نه وي.
        // څنګه چې موږ خپل ځان د یوه نښې په توګه تیروو ، نو دا نشي خالي کیدی.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // : SAableY::able A mutable. reference reference reference reference.. cannot n be be. be. be
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}