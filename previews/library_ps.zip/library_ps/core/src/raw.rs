#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! د جوړ شوي جوړ شوي ډولونو ترتیب لپاره جوړښت تعریفونه لري.
//!
//! دوی کولی شي په مستقیم ډول د خام نمایندګیو د لاسوهنې لپاره په غیر خوندي کوډ کې د ټرانزیټونو اهدافو په توګه وکارول شي.
//!
//!
//! د دوی تعریف باید تل د `rustc_middle::ty::layout` کې ټاکل شوي ABI سره پرتله شي.
//!

/// د trait څیز نمونه لکه `&dyn SomeTrait`.
///
/// دا جوړښت ورته ب layoutه لري لکه `&dyn SomeTrait` او `Box<dyn AnotherTrait>`.
///
/// `TraitObject` د ترتیب سره میچ کولو تضمین شتون لري ، مګر دا د trait څیزونو ډول نه دی (د بیلګې په توګه ، ساحې په `&dyn SomeTrait` کې مستقیم لاسرسی نلري) او نه دا کنټرول کنټرولوي (د تعریف بدلول به د `&dyn SomeTrait` ترتیب بدل نه کړي).
///
/// دا یوازې د غیر خوندي کوډ کارولو لپاره ډیزاین شوی چې د ټیټ کچې توضیحاتو ته اړتیا لري.
///
/// هیڅ ډول لار نشته چې په ټولیز ډول ټولو trait څیزونو ته مراجعه وکړئ ، نو د دې ډول ارزښتونو رامینځته کولو یوازینۍ لار د [`std::mem::transmute`][transmute] په څیر افعال سره دي.
/// په ورته ډول ، د `TraitObject` ارزښت څخه د ریښتیني trait څیز رامینځته کولو یوازینۍ لار د `transmute` سره ده.
///
/// [transmute]: crate::intrinsics::transmute
///
/// د trait څیز ترکیب کول د بیلابیل ډولونو سره-یو یو چیرې چې ویټبل د ارزښت ډول سره تړاو نلري چیرې چې د ډیټا پوائنټر اشاره کوي highly خورا احتمال لري د نامعلومه چلند المل شي.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // د trait یو مثال
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // پریږده چې trait څیز جوړ کړي
/// let object: &dyn Foo = &value;
///
/// // خام استازیتوب ته ګوره
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // د ډاټا اشاره د `value` پته ده
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // د نوي اعتراض رامینځته کړئ ، مختلف `i32` ته په ګوته کول ، د `object` څخه د `i32` ویټبل کارولو ته احتیاط کول
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // دا باید داسې کار وکړي لکه څنګه چې موږ له `other_value` څخه مستقیم trait څیز جوړ کړی
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}