//! د ډولونو لپاره د `Default` trait کوم چې ممکن معنی لرونکې ډیفالټ ارزښتونه ولري.

#![stable(feature = "rust1", since = "1.0.0")]

/// د یو ډول ګټور ډیفالټ ارزښت ورکولو لپاره یو trait.
///
/// ځینې وختونه ، تاسو غواړئ یو څه ډیفالټ ارزښت ته بیرته ستن شئ ، او په ځانګړي ډول پاملرنه مه کوئ چې دا څه شی دی.
/// دا اکثرا د `جوړښتونو سره راځي چې د اختیارونو سیټ تعریفوي:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// څنګه موږ کولی شو ځینې اصلي ارزښتونه تعریف کړو؟تاسو کولی شئ `Default` وکاروئ:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// اوس ، تاسو ټول ډیفالټ ارزښتونه ترلاسه کوئ.Rust د مختلف لومړنیو ډولونو لپاره `Default` پلي کوي.
///
/// که تاسو غواړئ یو ځانګړی اختیار په پام کې ونیسئ ، مګر بیا هم نور اصلي تاکیدونه وساتئ:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// دا trait د `#[derive]` سره کارول کیدی شي که چیرې د ټول ډول ساحې `Default` پلي کړي.
/// کله چې ترلاسه کیږي ، دا به د هرې برخې د ډول لپاره ډیفالټ ارزښت وکاروي.
///
/// ## زه څنګه کولی شم `Default` تطبیق کړم؟
///
/// د `default()` میتود لپاره پلي کول چمتو کړئ چې ستاسو د ډول ارزښت بیرته راولي چې باید ډیفالټ وي:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// د یو ډول لپاره "default value" راستنوي.
    ///
    /// د ډیفالټ ارزښتونه اکثرا یو څه ابتدایی ارزښت ، د پیژندنې ارزښت ، یا کوم بل څه دي چې ممکن د ډیفالټ په توګه معنی ولري.
    ///
    ///
    /// # Examples
    ///
    /// د جوړ شوي ډیفالټ ارزښتونو کارول:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// خپل ځان جوړول:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// د `Default` trait سره مطابق د ډول ډول ډیفالټ ارزښت بیرته ورکړئ.
///
/// د راستنیدو ډول له شرایطو څخه معلوم شوی دی.دا د `Default::default()` سره برابر دی مګر د ټایپ کولو له پلوه لنډ دی.
///
/// د مثال په توګه:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// د trait `Default` د تطبیق وړ میکرو تولید.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }