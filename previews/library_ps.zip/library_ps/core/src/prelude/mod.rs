//! د libcore prelude
//!
//! دا موډل د لیبکور کاروونکو لپاره دی چې لابسټډ سره هم نه تړاو لري.
//! دا انډول د ډیفالټ لخوا وارد شوی کله چې `#![no_std]` په ورته ډول د معیاري کتابتون preolve په توګه کارول کیږي.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// د اصلي نسخه preolve د 2015 نسخه.
///
/// د نورو لپاره [module-level documentation](self) وګورئ.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// د 2018 اصلي نسخه prelude.
///
/// د نورو لپاره [module-level documentation](self) وګورئ.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// د 2021 اصلي prelude نسخه.
///
/// د نورو لپاره [module-level documentation](self) وګورئ.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: نور شیان اضافه کړئ.
}