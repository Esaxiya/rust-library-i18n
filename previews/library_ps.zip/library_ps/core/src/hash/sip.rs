//! د سیپ هاش پلي کول.

#![allow(deprecated)] // په دې ماډل کې ډولونه تخریب شوي دي

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// د SipHash 1-3 پلي کول.
///
/// دا اوس مهال د معیاري کتابتون لخوا کارول کیږي د ډیفالټ هشینګ فعالیت دی (د مثال په توګه ، `collections::HashMap` دا په تلواله کاروي)
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// د SipHash 2-4 پلي کول.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// د SipHash 2-4 پلي کول.
///
/// See: <https://131002.net/siphash/>
///
/// سیپ هاش د عمومي هدف لرونکي هشنګ فعالیت دی: دا په ښه سرعت سره پرمخ ځي (د سپکوکي او ښار سره سیالي کوي) او د قوي _keyed_ هینګ کولو اجازه ورکوي.
///
/// دا تاسو ته اجازه درکوي د قوي RNG څخه ستاسو د هش میزونه کلیدي کړئ ، لکه [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// که څه هم د سیپ هاش الګوریتم عموما قوي ګ consideredل کیږي ، دا د کریپټوګرافیک اهدافو لپاره ندی.
/// د ورته په څیر ، د دې پلي کولو ټولې کریپټوګرافیک کارونې _strongly discouraged_ دي.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // موږ څومره بایټونه پروسس کړي دي
    state: State,  // د hash ایالت
    tail: u64,     // پروسس شوې بایټس لی
    ntail: usize,  // په دم کې څو بایټونه معتبر دي
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 او v1 ، v3 په الګوریتم کې جوړو کې ښیې ، او د SipHash سیمال پلي کول به د v02 او v13 vectors وکاروي.
    //
    // په سټیکر کې د دوی په ترتیب سره دا ځای په ځای کولو سره ، تالیف کونکي کولی شي پخپله یوازې یو څو سیمال اصلاح باندې غوره کړي.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// د مطلوب ډول بشپړ عدد د بایټ سټریټ څخه ، په ترتیب سره درولوي.
/// د `copy_nonoverlapping` کاروي ترڅو کمپلر ته اجازه ورکړي چې تر ممکنه غیر لست شوي پتې څخه د پورته کولو ترټولو مؤثر لاره رامینځته کړي.
///
///
/// غیر محفوظ ځکه چې: په i..i+size_of(int_ty) کې بې ارزول شوي شاخصونه
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// د بایټ سلایډونو تر 7 بیو پورې کارولو سره u64 پورته کوي.
/// دا اناړ ښکاري مګر د `copy_nonoverlapping` زنګونه چې پیښیږي (د `load_int_le!` له لارې) ټول ثابت شوي اندازې لري او د `memcpy` تلیفون کولو څخه مخنیوی کوي ، کوم چې د سرعت لپاره ښه دی.
///
///
/// ناامنه ځکه چې: په پیل کې بې چک شوي شاخصونه پیل کړئ .. سټارټ + لین
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // په ایکسکس ایکس ایکس کې د اوسني بایټ شاخص (د LSB څخه)
    let mut out = 0;
    if i + 3 < len {
        // خوندي: `i` د `len` څخه لوی نشي کیدی ، او زنګ وهونکی باید تضمین وکړي
        // چې د شاخص پیل .. سټ + لین حدود کې دی.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // خوندي: د پورتني په څیر.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // خوندي: د پورتني په څیر.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// دوه لومړني کیلي 0 ته ټاکل شوي نوي `SipHasher` رامینځته کوي.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// یو `SipHasher` رامینځته کوي چې چمتو شوي کیلي ګانې بندې دي.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// دوه لومړني کیلي 0 ته ټاکل شوي نوي `SipHasher13` رامینځته کوي.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// یو `SipHasher13` رامینځته کوي چې چمتو شوي کیلي ګانې بندې دي.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: د بشپړ اشغال هیڅ ډول طریقې (methods Writ_u *`، `write_i*`) ندي ټاکل شوي
    // د دې ډول لپاره.
    // موږ دا اضافه کولی شو ، په librustc_data_structures/sip128.rs کې د `short_write` پلي کول کاپي کړئ ، او `write_u *`/`write_i*` میتودونه په `SipHasher` ، `SipHasher13` ، او `DefaultHasher` کې اضافه کړئ.
    //
    // دا به په پراخه کچه د دې حاشارو لخوا د انټرنیټ هیسینګ ګړندی کړي ، په ځینې معیارونو د تالیف سرعت لږ ورو کولو په قیمت کې.
    // د توضیحاتو لپاره #69152 وګورئ.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // امنیت: د `cmp::min(length, needed)` تضمین دی چې د `length` څخه ډیر نه وي
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // بفر شوی دم اوس فلش شوی ، نوی ان پټ پروسس.
        let len = length - needed;
        let left = len & 0x7; // لین٪ 8

        let mut i = needed;
        while i < len - left {
            // خوندي: ځکه چې `len - left` د 8 لاندې لاندې ترټولو لوی ضرب دی
            // `len`, او ځکه چې `i` په `needed` کې پیلیږي چیرې چې `len` د `length - needed` دی ، نو `i + 8` د `length` څخه کم یا مساوي تضمین لري.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // خوندي: `i` اوس `needed + len.div_euclid(8) * 8` دی ،
        // نو `i + left` = `needed + len` = `length` ، کوم چې د `msg.len()` سره مساوي تعریف سره دی.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// د 2 لومړني کیلي 0 ته ټاکل شوي سره `Hasher<S>` رامینځته کوي.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}