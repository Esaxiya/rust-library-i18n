#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// זען קס 00 קס.
pub const _PREFETCH_READ: i32 = 0;

/// זען קס 00 קס.
pub const _PREFETCH_WRITE: i32 = 1;

/// זען קס 00 קס.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// זען קס 00 קס.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// זען קס 00 קס.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// זען קס 00 קס.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// ברענגען די קאַש שורה וואָס כּולל אַדרעס קס 01 קס ניצן די געגעבן קס 02 קס און קס 00 קס.
///
/// די `rw` מוזן זיין איינער פון:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): די פּרעפעטש איז פּריפּערינג פֿאַר אַ לייענען.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): די פּרעפעטש איז פּריפּערינג פֿאַר אַ שרייבן.
///
/// די `locality` מוזן זיין איינער פון:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): סטרימינג אָדער ניט-צייַטיק פּרעפעטש, פֿאַר דאַטן וואָס זענען געניצט בלויז אַמאָל.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): ברענגען אין מדרגה 3 קאַש.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): ברענגען אין מדרגה 2 קאַש.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): ברענגען אין מדרגה 1 קאַש.
///
/// די פּרעפעטטש זיקאָרן ינסטראַקשאַנז סיגנאַל צו די זיקאָרן סיסטעם אַז זיקאָרן אַקסעס פֿון אַ ספּעציפיצירט אַדרעס וועט מיסטאָמע פּאַסירן אין דער נאָענט ז 0 פוטורע 0 ז.
/// דער זכּרון סיסטעם קענען ריספּאַנד דורך אַקשאַנז וואָס זענען דערוואַרט צו פאַרגיכערן די זיקאָרן אַקסעס ווען זיי פאַלן, אַזאַ ווי פּרעלאָאַדינג די ספּעסאַפייד אַדרעס אין איין אָדער מער קאַטשעס.
///
/// ווייַל די סיגנאַלז זענען בלויז הינץ, עס איז גילטיק פֿאַר אַ באַזונדער קפּו צו מייַכל קיין אָדער אַלע פּרעפעטש ינסטראַקשאַנז ווי אַ NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // מיר נוצן די `llvm.prefetch` ינסטראַנסיק מיט `cache type` =1 (דאַטן קאַש).
    // `rw` און קס 00 קס זענען באזירט אויף די פונקציע פּאַראַמעטערס.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}