use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // געוויינט צו זאָגן אונדזער קס 00 קס אַנאַטיישאַנז אַז אַלע סימד ינטרינסיקס זענען בארעכטיגט צו פּרובירן זייער קאָדעגען, ווייַל עטלעכע זענען גייטיד הינטער אַן עקסטרע קס 01 קס וואָס טוט נישט האָבן קיין עקוויוואַלענט אין קס 02 קס רעכט איצט.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}