`core::arch` - די האַרץ ביבליאָטעק אַרקאַטעקטשעראַל ספּעציפיש ינטרינסיקס פון Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

די קס 00 קס מאָדולע ימפּלאַמאַנץ ינטרינסיקס פון אַרקאַטעקטשער (למשל סימד).

# Usage 

`core::arch` איז בנימצא ווי טייל פון קס 01 קס און עס איז שייַעך-יקספּאָרטאַד דורך קס 00 קס.בעסער נוצן עס דורך קס 02 קס אָדער קס 03 קס ווי דורך דעם crate.
אַנסטייבאַל פֿעיִקייטן זענען אָפט בנימצא אין ז 0 רוסט 0 ז נייטלי דורך די קס 00 קס.

ניצן `core::arch` דורך דעם crate ריקווייערז Rust נאַכט, און עס קען (און קען) אָפט ברעכן.די בלויז קאַסעס אין וואָס איר זאָל באַטראַכטן די נוצן פון דעם crate זענען:

* אויב איר דאַרפֿן צו שייַעך-צונויפנעמען קס 01 קס זיך, למשל, מיט באַזונדער ציל-פֿעיִקייטן ענייבאַלד וואָס זענען נישט ענייבאַלד פֿאַר קס 00 קס.
Note: אויב איר דאַרפֿן צו שייַעך-צונויפנעמען עס פֿאַר אַ ניט-נאָרמאַל ציל, ביטע בעסער נוצן `xargo` און ווידער-קאַמפּיילינג `libcore`/`libstd` ווי צונעמען אַנשטאָט פון ניצן דעם crate.
  
* ניצן עטלעכע פֿעיִקייטן וואָס קען נישט זיין בארעכטיגט אפילו הינטער אַנסטייבאַל ז 0 רוסט 0 ז פֿעיִקייטן.מיר פּרובירן צו האַלטן דאָס צו אַ מינימום.
אויב איר דאַרפֿן צו נוצן עטלעכע פון די פֿעיִקייטן, ביטע עפֿענען אַן אַרויסגעבן אַזוי אַז מיר קענען ויסשטעלן זיי אין די נאַכט Rust און איר קענען נוצן זיי פֿון דאָרט.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` איז בפֿרט פונאנדערגעטיילט אונטער די טערמינען פון ביידע די MIT דערלויבעניש און די Apache License (ווערסיע 2.0), מיט פּאָרשאַנז קאַווערד דורך פאַרשידן BSD-ווי לייסאַנסיז.

זען LICENSE-APACHE און LICENSE-MIT פֿאַר פּרטים.

# Contribution

סיידן איר דערקלערט אַנדערש, קיין קאַנטראַביושאַנז בעקיוון צו זיין אַרייַנגערעכנט אין `core_arch` דורך איר, ווי דיפיינד אין די Apache-2.0 דערלויבעניש, וועט זיין צווייענדיק לייסאַנסט ווי אויבן, אָן קיין נאָך טערמינען אָדער באדינגונגען.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












