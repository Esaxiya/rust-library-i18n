#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// די אינהאַלט פון די נייַ זכּרון איז אַנינישאַנאַלייזד.
    Uninitialized,
    /// דער נייַ זכּרון איז געראַנטיד צו זיין זעראָוד.
    Zeroed,
}

/// א נידעריק-מדרגה נוצן פֿאַר מער ערגאַנאַמיקלי אַלאַקייטינג, ריאַלאַקייטינג, און דיקלאָוקייטינג אַ באַפער פון זכּרון אויף דעם קופּע אָן זאָרג וועגן אַלע די ינוואַלווד ווינקל קאַסעס.
///
/// דער טיפּ איז ויסגעצייכנט צו בויען דיין אייגענע דאַטן סטראַקטשערז ווי וועק און וועקדעעקווע.
/// אין באַזונדער:
///
/// * טראגט קס 00 קס אויף נול-סייזד טייפּס.
/// * פּראָדוצירן קס 00 קס אויף נול-לענג אַלאַקיישאַנז.
/// * ויסמיידן פריי `Unique::dangling()`.
/// * קאַטשאַז אַלע אָוווערפלאָוז אין קאַפּאַציטעט קאַמפּיאַטיישאַנז (פּראַמאָוץ זיי צו "capacity overflow" panics).
/// * גאַרדז קעגן 32-ביסל סיסטעמען אַלאַקייטינג מער ווי X00 קס ביטעס.
/// * גאַרדז קעגן אָוווערפלאָוינג דיין לענג.
/// * רופט `handle_alloc_error` פֿאַר פאַלאַבאַל אַלאַקיישאַנז.
/// * כּולל אַ `ptr::Unique` און דערמיט די באַניצער מיט אַלע פֿאַרבונדענע בענעפיץ.
/// * ניצט די וידעפדיק אומגעקערט פֿון די אַלאַקייטער צו נוצן די גרעסטע פאַראַנען קאַפּאַציטעט.
///
/// דער טיפּ קען נישט דורכקוקן די זכּרון אַז עס מאַנידזשיז.ווען עס דראַפּט עס * וועט זיין זיקאָרן פריי, אָבער עס וועט נישט פּרובירן צו פאַלן די אינהאַלט.
/// עס איז אַרויף צו דער באַניצער פון קס 01 קס צו האַנדלען מיט די פאַקטיש טינגז *סטאָרד* ין אַ קס 00 קס.
///
/// באַמערקונג אַז די וידעפדיק פון נול-סייזד טייפּס איז שטענדיק ינפאַנאַט, אַזוי X1X שטענדיק קערט `usize::MAX`.
/// דעם מיטל אַז איר דאַרפֿן צו זיין אָפּגעהיט ווען איר אַרומפאָרן דעם טיפּ מיט אַ `Box<[T]>`, ווייַל `capacity()` וועט נישט טראָגן די לענג.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): דעם יגזיסץ ווייַל `#[unstable]` `const fn`s דאַרפֿן נישט קאָנפאָרם צו `min_const_fn` און אַזוי זיי קענען ניט זיין גערופן אין`min_const_fn`s.
    ///
    /// אויב איר טוישן `RawVec<T>::new` אָדער דיפּענדאַנסיז, ביטע נעמען קעיר פון נישט באַקענען עפּעס וואָס וואָלט טאַקע אָנרירן `min_const_fn`.
    ///
    /// NOTE: מיר קען ויסמיידן דעם כאַק און קאָנטראָלירן די קאָנפאָרמאַנסע מיט עטלעכע `#[rustc_force_min_const_fn]` אַטריביוט וואָס ריקווייערז די קאָנפאָרמאַנסע פון `min_const_fn`, אָבער עס קען נישט דאַווקע זיין גערופן `stable(...) const fn`/באַניצער קאָד וואָס קען נישט געבן `foo` ווען `#[rustc_const_unstable(feature = "foo", issue = "01234")]` איז פאָרשטעלן.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// קרעאַטעס די ביגאַסט מעגלעך קס 00 קס (אויף די סיסטעם קופּע) אָן אַלאַקייטינג.
    /// אויב קס 01 קס האט positive גרייס, דאָס מאכט אַ קס 02 קס מיט קאַפּאַציטעט קס 00 קס.
    /// אויב קס 01 קס איז נול-סייזד, עס מאכט אַ קס 02 קס מיט קאַפּאַציטעט קס 00 קס.
    /// נוציק פֿאַר ימפּלאַמענינג דילייד אַלאַקיישאַן.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// קרעאַטעס אַ קס 01 קס (אויף די סיסטעם קופּע) מיט פּונקט די קאַפּאַציטעט און אַליינמאַנט באדערפענישן פֿאַר אַ קס 00 קס.
    /// דאָס איז עקוויוואַלענט צו רופן קס 00 קס ווען קס 01 קס איז קס 02 קס אָדער קס 03 קס איז נול-סייזד.
    /// באַמערקונג אַז אויב `T` איז נול-סייזד, דאָס מיטל אַז איר * וועט נישט באַקומען אַ `RawVec` מיט די געבעטן קאַפּאַציטעט.
    ///
    /// # Panics
    ///
    /// Panics אויב די געבעטן קאַפּאַציטעט יקסיד X00 קס ביטעס.
    ///
    /// # Aborts
    ///
    /// אַבאָרץ אויף OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// ווי קס 00 קס, אָבער געראַנטיז די באַפער איז זעראָוד.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// רעקאָנסטיטוטעס אַ קס 00 קס פֿון אַ טייַטל און קאַפּאַציטעט.
    ///
    /// # Safety
    ///
    /// די `ptr` מוזן זיין אַלאַקייטיד (אויף די סיסטעם קופּע) און מיט די געגעבן `capacity`.
    /// די קס 00 קס קען נישט יקסיד קס 01 קס פֿאַר סייזד טייפּס.(בלויז אַ דייַגע אויף 32-ביסל סיסטעמען).
    /// זסט ז 0 וועקטאָרס 0 ז קען האָבן אַ קאַפּאַציטעט אַרויף צו קס 00 קס.
    /// אויב די `ptr` און `capacity` קומען פֿון `RawVec`, דאָס איז געראַנטיד.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // קליינטשיק וועקס זענען שטום.Skip to:
    // - 8 אויב דער עלעמענט גרייס איז 1, ווייַל קיין קופּע אַלאַקייטערז זענען מסתּמא צו קייַלעכיק אַרויף אַ בקשה פון ווייניקער ווי 8 ביטעס צו לפּחות 8 ביטעס.
    //
    // - 4 אויב עלעמענטן זענען מעסיק-סייזד (<=1 KiB).
    // - אַנדערש, צו ויסמיידן ווי פיל פּלאַץ פֿאַר זייער קורץ וועקס.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// ווי קס 01 קס, אָבער פּאַראַמעטעריזעד איבער די ברירה פון אַלאַקייטער פֿאַר די אומגעקערט קס 00 קס.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` מיטל "unallocated".נול-סייזד טייפּס זענען איגנאָרירט.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// ווי קס 01 קס, אָבער פּאַראַמעטעריזעד איבער די ברירה פון אַלאַקייטער פֿאַר די אומגעקערט קס 00 קס.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// ווי קס 01 קס, אָבער פּאַראַמעטעריזעד איבער די ברירה פון אַלאַקייטער פֿאַר די אומגעקערט קס 00 קס.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// קאָנווערט אַ `Box<[T]>` אין אַ `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// קאָנווערט די גאנצע באַפער אין `Box<[MaybeUninit<T>]>` מיט די ספּעסאַפייד `len`.
    ///
    /// באַמערקונג אַז דאָס וועט ריכטיק רעקאָנסטיטוט די `cap` ענדערונגען וואָס האָבן שוין דורכגעקאָכט.(זען די באַשרייַבונג פון טיפּ פֿאַר אינפֿאָרמאַציע.)
    ///
    /// # Safety
    ///
    /// * `len` מוזן זיין גרעסער ווי אָדער גלייַך צו די לעצטנס געבעטן קאַפּאַציטעט, און
    /// * `len` מוזן זיין ווייניקער ווי אָדער גלייַך צו קס 00 קס.
    ///
    /// באַמערקונג אַז די געבעטן קאַפּאַציטעט און `self.capacity()` קען אַנדערש, ווייַל אַ אַלאַקייטער קען קוילעלדיק און צוריקקומען אַ גרעסערע זיקאָרן בלאָק ווי געבעטן.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // סאַניטי טשעק איינער האַלב פון די זיכערקייַט פאָדערונג (מיר קענען נישט קאָנטראָלירן די אנדערע האַלב).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // מיר ויסמיידן `unwrap_or_else` דאָ ווייַל עס בלאָוץ די סומע פון LLVM IR דזשענערייטאַד.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// רעקאָנסטיטוטעס אַ קס 00 קס פֿון אַ טייַטל, קאַפּאַציטעט און אַלאַקייטער.
    ///
    /// # Safety
    ///
    /// די `ptr` מוזן זיין אַלאַקייטיד (דורך די געגעבן אַלאַקייטער `alloc`) און מיט די געגעבן `capacity`.
    /// די קס 00 קס קען נישט יקסיד קס 01 קס פֿאַר סייזד טייפּס.
    /// (בלויז אַ דייַגע אויף 32-ביסל סיסטעמען).
    /// זסט ז 0 וועקטאָרס 0 ז קען האָבן אַ קאַפּאַציטעט אַרויף צו קס 00 קס.
    /// אויב די `ptr` און `capacity` קומען פֿון אַ `RawVec` באשאפן דורך `alloc`, דאָס איז געראַנטיד.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// געץ אַ רוי טייַטל צו די אָנהייב פון די אַלאַקיישאַן.
    /// באַמערקונג אַז דאָס איז קס 00 קס אויב קס 01 קס אָדער קס 02 קס איז נול-סייזד.
    /// אין ערשטן פאַל, איר מוזן זיין אָפּגעהיט.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// באַקומען די קאַפּאַציטעט פון די אַלאַקיישאַן.
    ///
    /// דאָס וועט שטענדיק זיין `usize::MAX` אויב `T` איז נול-סייזד.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// קערט אַ שערד רעפֿערענץ צו די אַלאַקייטער וואָס שטיצט דעם `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // מיר האָבן אַ אַלאַקייטיד פּעקל פון זכּרון, אַזוי מיר קענען בייפּאַס רונטימע טשעקס צו באַקומען אונדזער קראַנט אויסלייג.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// ינשורז אַז די באַפער כּולל לפּחות גענוג פּלאַץ צו האַלטן `len + additional` עלעמענטן.
    /// אויב עס קען נישט האָבן גענוג קאַפּאַציטעט, עס וועט ריאַלאַקייט גענוג פּלאַץ פּלוס באַקוועם לויז אָרט צו באַקומען אַמאָרטיזעד *O*(1) נאַטור.
    ///
    /// וועט באַגרענעצן דעם נאַטור אויב עס וואָלט יבעריק צו ז 0 פּאַניק 0 ז.
    ///
    /// אויב קס 01 קס יקסיד קס 00 קס, דאָס קען דורכפירן די געבעטן פּלאַץ פאקטיש.
    /// דאָס איז ניט טאַקע אַנסייף, אָבער די אַנסייף קאָד *איר* שרייַבן אַז רילייז אויף די נאַטור פון דעם פֿונקציע קען ברעכן.
    ///
    /// דאָס איז ידעאַל פֿאַר ימפּלאַמענינג אַ פאַרנעם-שטופּן אָפּעראַציע ווי קס 00 קס.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט יקסיד X00 קס ביטעס.
    ///
    /// # Aborts
    ///
    /// אַבאָרץ אויף OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // רעזערוו וואָלט האָבן אַבאָרטיד אָדער פּאַניק אויב די לענן יקסידיד קס 00 קס אַזוי עס איז זיכער צו טאָן ונקעקקעד איצט.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// די זעלבע ווי `reserve`, אָבער קערט אויף ערראָרס אַנשטאָט פון פּאַניק אָדער אַבאָרטינג.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// ינשורז אַז די באַפער כּולל לפּחות גענוג פּלאַץ צו האַלטן `len + additional` עלעמענטן.
    /// אויב עס איז נישט נאָך, עס וועט ריאַלאָוקייט די מינימום מעגלעך סומע פון זכּרון.
    /// אין אַלגעמיין, דאָס וועט זיין פּונקט די נומער פון זכּרון וואָס איז נייטיק, אָבער אין פּרינציפּ די אַלאַקייטער איז פריי צו געבן מער ווי מיר געבעטן פֿאַר.
    ///
    ///
    /// אויב קס 01 קס יקסיד קס 00 קס, דאָס קען דורכפירן די געבעטן פּלאַץ פאקטיש.
    /// דאָס איז ניט טאַקע אַנסייף, אָבער די אַנסייף קאָד *איר* שרייַבן אַז רילייז אויף די נאַטור פון דעם פֿונקציע קען ברעכן.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט יקסיד X00 קס ביטעס.
    ///
    /// # Aborts
    ///
    /// אַבאָרץ אויף OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// די זעלבע ווי `reserve_exact`, אָבער קערט אויף ערראָרס אַנשטאָט פון פּאַניק אָדער אַבאָרטינג.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// שרינקס די אַלאַקיישאַן אַראָפּ צו די ספּעסאַפייד סומע.
    /// אויב די סומע איז 0, אַקשלי גאָר דילאַקייץ.
    ///
    /// # Panics
    ///
    /// Panics אויב די געגעבן סומע איז *גרעסערע* ווי די קראַנט קאַפּאַציטעט.
    ///
    /// # Aborts
    ///
    /// אַבאָרץ אויף OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// קערט אויב די באַפער דאַרף צו וואַקסן צו מקיים דעם דארף עקסטרע קאַפּאַציטעט.
    /// דער הויפּט געניצט צו מאַכן ינליינינג רעזערוו רופט אָן ינליינינג קס 00 קס.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // דעם אופֿן איז יוזשאַוואַלי ינסטאַנטיד פילע מאָל.אַזוי מיר וועלן עס זאָל זיין ווי קליין ווי מעגלעך און פֿאַרבעסערן די צונויפנעמען צייט.
    // מיר וועלן אויך ווי פיל ווי פיל פון די אינהאַלט קענען זיין סטאַטיקלי קאַמפּיאַטאַבאַל צו מאַכן די דזשענערייטאַד קאָד לויפן פאַסטער.
    // דעריבער, דעם אופֿן איז קערפאַלי געשריבן אַזוי אַז אַלע די קאָד וואָס דעפּענדס אויף קס 01 קס איז ין עס, בשעת ווי פיל פון די קאָד וואָס קען נישט אָפענגען אויף קס 02 קס איז אין פאַנגקשאַנז וואָס זענען ניט-דזשאַנעריק איבער קס 00 קס.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // דאָס איז ינשורד דורך די פאַך קאַנטעקסץ.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // זינט מיר צוריקקומען אַ קאַפּאַציטעט פון קס 00 קס ווען קס 01 קס איז
            // 0, צו קומען דאָ, דאַווקע מיטל אַז די `RawVec` איז אָוווערפולל.
            return Err(CapacityOverflow);
        }

        // גאָרנישט מיר קענען טאַקע טאָן וועגן די טשעקס, סאַדלי.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // דאָס געראַנטיז עקספּאָונענשאַל וווּקס.
        // די דאַבלינג קען נישט לויפן איבער ווייַל `cap <= isize::MAX` און די טיפּ `cap` איז `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` איז ניט-דזשאַנעריק איבער `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // די קאַנסטריינץ פֿאַר דעם אופֿן זענען פיל די זעלבע ווי די אויף X00 קס, אָבער דעם אופֿן איז יוזשאַוואַלי ינסטאַנטיאַטעד ווייניקער אָפט, אַזוי עס איז ווייניקער קריטיש.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // זינט מיר צוריקקומען אַ קאַפּאַציטעט פון קס 00 קס ווען די טיפּ גרייס איז
            // 0, צו קומען דאָ, דאַווקע מיטל אַז די `RawVec` איז אָוווערפולל.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` איז ניט-דזשאַנעריק איבער `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// די פֿונקציע איז אַרויס `RawVec` צו מינאַמייז די קאַמפּייל צייט.זען די באַמערקונג אויבן קס 01 קס פֿאַר פּרטים.
// (די פּאַראַמעטער `A` איז נישט באַטייטיק ווייַל די נומער פון פאַרשידענע `A` טייפּס וואָס זענען געזען אין פיר איז פיל קלענערער ווי די נומער פון `T` טייפּס.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // טשעק פֿאַר די טעות דאָ צו מינאַמייז די גרייס פון `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // דער אַלאַקייטער קאָנטראָלירט פֿאַר גלייכקייט פון אַליינמאַנט
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// פריי די זכּרון אָונד דורך די קס 00 קס *אָן* טריינג צו פאַלן די אינהאַלט.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// הויפט פונקציע פֿאַר רעזערוו טעות האַנדלינג.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// מיר דאַרפֿן צו גאַראַנטירן די פאלגענדע:
// * מיר טאָן ניט אַלאַקייט `> isize::MAX` בייט-גרייס אַבדזשעקץ.
// * מיר טאָן ניט לויפן איבער `usize::MAX` און אַקשלי אַלאַקייט צו קליין.
//
// אויף 64-ביסל מיר נאָר דאַרפֿן צו קאָנטראָלירן פֿאַר לויפן, ווייַל טריינג צו אַלאַקייט `> isize::MAX` ביטעס וועט שורלי פאַרלאָזן.
// אויף 32-ביסל און 16-ביסל מיר דאַרפֿן צו לייגן אַן עקסטרע היטן פֿאַר דעם אין פאַל מיר לויפן אויף אַ פּלאַטפאָרמע וואָס קענען נוצן אַלע 4 גיגאבייט אין באַניצער-פּלאַץ, למשל, PAE אָדער x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// איין הויפט פֿונקציע פאַראַנטוואָרטלעך פֿאַר ריפּאָרטינג קאַפּאַציטעט אָוווערפלאָוז.
// דאָס וועט ענשור אַז די קאָד דור שייכות צו די panics איז מינימאַל ווייַל עס איז בלויז איין אָרט panics ווי אַ בינטל איבער די מאָדולע.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}