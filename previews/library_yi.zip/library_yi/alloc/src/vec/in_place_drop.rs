use core::ptr::{self};
use core::slice::{self};

// אַ העלפער סטרוקטור פֿאַר יטעראַטיאָן אין פּלאַץ וואָס דראַפּס די דעסטיניישאַן סלייס פון יטעראַטיאָן, הייסט די קאָפּ.
// די מקור רעפטל (די עק) איז דראַפּט דורך IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}