use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// ספּעשאַלאַזיישאַן ז 0 טראַיט 0 ז געניצט פֿאַר קס 00 קס
///
/// ## די דעלאַגיישאַן גראַפיק:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // א פּראָסט פאַל איז דורכגעגאנגען אַ vector אין אַ פונקציע וואָס גלייך קאַלעקץ ווידער אין אַ vector.
        // מיר קענען קורץ קרייַז אויב די ינטאָיטער איז נישט אַוואַנסירטע.
        // ווען עס איז אַוואַנסירטע, מיר קענען אויך רייוז די זכּרון און אַריבערפירן די דאַטן צו די פראָנט.
        // אָבער מיר טאָן דאָס בלויז ווען די ריזאַלטינג וועק וואָלט נישט האָבן מער אַניוזד קאַפּאַציטעט ווי צו מאַכן עס דורך די דזשאַנעריק פראָמיטאַטאָר ימפּלאַמענטיישאַן.
        //
        // די באַגרענעצונג איז נישט שטרענג נויטיק ווייַל וועק ס אַלאַקיישאַן נאַטור איז בעקיוון ונספּעסיפיעד.
        // אָבער עס איז אַ קאָנסערוואַטיווע ברירה.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // מוזן דעלאַגייט צו קס 00 קס זינט קס 01 קס זיך דעלאַגייץ צו ספּעק_פראָם פֿאַר ליידיק וועקס
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// דעם ניצט `iterator.as_slice().to_vec()` זינט ספּעק_עקסטענד מוזן נעמען מער טריט צו סיבה וועגן די לעצט קאַפּאַציטעט + לענג און אַזוי טאָן מער אַרבעט.
// `to_vec()` גלייך אַלאַקייץ די ריכטיק סומע און פילז עס פּונקט.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): מיט קס 00 קס די טאָכיק קס 01 קס אופֿן, וואָס איז פארלאנגט פֿאַר דעם אופֿן דעפֿיניציע, איז ניט בנימצא.
    // אַנשטאָט נוצן די `slice::to_vec` פונקציע וואָס איז בלויז בנימצא מיט cfg(test) NB. זען slice::hack מאָדולע אין slice.rs פֿאַר מער אינפֿאָרמאַציע
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}