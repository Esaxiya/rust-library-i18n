use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// אַ יטעראַטאָר וואָס ניצט אַ קלאָוזשער צו באַשליסן אויב אַן עלעמענט זאָל זיין אַוועקגענומען.
///
/// די סטרוקטור איז באשאפן דורך [`Vec::drain_filter`].
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// דער אינדעקס פון די נומער וואָס וועט זיין ינספּעקטיד דורך די ווייַטערדיק רופן צו `next`.
    pub(super) idx: usize,
    /// די נומער פון ביז אַהער האָבן שוין ויסגעשעפּט (removed).
    pub(super) del: usize,
    /// דער אָריגינעל לענג פון `vec` איידער דריינינג.
    pub(super) old_len: usize,
    /// די פּרעדיקאַט פון די פילטער פּרובירן.
    pub(super) pred: F,
    /// א פאָן וואָס ינדיקייץ אַ ז 0 פּאַניק 0 ז איז פארגעקומען אין די פּרעדיקאַט פון די פילטער פּרובירן.
    /// דעם איז געוויינט ווי אַ אָנצוהערעניש אין דער פאַל ימפּלאַמענטיישאַן צו פאַרמייַדן די רעשט פון די `DrainFilter`.
    /// ניט פּראַסעסט ייטאַמז וועט זיין באַקקשיפטעד אין די `vec`, אָבער קיין ווייַטער ייטאַמז וועט זיין דראַפּט אָדער טעסטעד דורך די פילטער פּרעדיקאַט.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// קערט אַ רעפֿערענץ צו די אַנדערלייינג אַלאַקייטער.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // דערהייַנטיקן די אינדעקס * נאָך דעם פּרידיקאַט איז גערופֿן.
                // אויב דער אינדעקס איז דערהייַנטיקט פריערדיק און די פּרידיקאַט ז 0 פּאַניקס 0 ז, די עלעמענט אין דעם אינדעקס וואָלט זיין ליקט.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // דאָס איז אַ שיין מעסט אַרויף שטאַט, און עס איז ניט טאַקע אַ דאָך רעכט זאַך צו טאָן.
                        // מיר טאָן ניט וועלן צו האַלטן טריינג צו ויספירן קס 00 קס, אַזוי מיר נאָר באַקקשיפט אַלע די אַנפּראָסעסט עלעמענטן און זאָגן די וועק אַז זיי נאָך עקסיסטירן.
                        //
                        // די באַקסשיפט איז פארלאנגט צו פאַרמייַדן אַ טאָפּל-קאַפּ פון די לעצט הצלחה ויסגעשעפּט נומער איידער אַ panic אין די פּרידיקאַט.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // פּרוּווט צו פאַרנוצן קיין רוען עלעמענטן אויב די פילטער פּרעדיקאַט איז נאָך נישט פּאַניק.
        // מיר וועלן באַקן שיפט קיין רוען עלעמענטן, צי מיר האָבן שוין פּאַניק אָדער אויב די קאַנסאַמשאַן דאָ panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}