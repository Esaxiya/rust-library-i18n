// באַשטעטיק די לענג פון די וועק ווען די `SetLenOnDrop` ווערט גייט אויס פון פאַרנעם.
//
// דער געדאַנק איז: די לענג פעלד אין סעטלענאָנדראָפּ איז אַ היגע בייַטעוודיק וואָס דער אָפּטימיזער וועט זען איז נישט אַליאַס מיט קיין סטאָרז דורך די וועק ס דאַטן טייַטל.
// דאָס איז אַ וואָרקאַראָונד פֿאַר אַליאַס אַנאַליסיס #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}