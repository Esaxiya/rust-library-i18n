use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ספּעשאַלאַזיישאַן מאַרקער פֿאַר קאַלעקטינג אַ יטעראַטאָר רערנ-ליניע אין אַ וועק בשעת רייוזינג די מקור אַלאַקיישאַן, י.ע.
/// עקסאַקיוטינג די רערנ-ליניע אין פּלאַץ.
///
/// דער SourceIter פאָטער trait איז נויטיק פֿאַר דער ספּעשאַלייזינג פונקציע צו אַקסעס די אַלאַקיישאַן וואָס איז צו זיין ריוזד.
/// אָבער עס איז נישט גענוג אַז די ספּעשאַלאַזיישאַן איז גילטיק.
/// זען נאָך גווול אויף די ימפּ.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// די std-ינערלעך SourceIter/InPlaceIterable traits זענען בלויז ימפּלאַמענאַד דורך אַדאַפּט קייטן <Adapter<Adapter<IntoIter>>> (אַלע אָונד דורך קס 01 קס).
// נאָך גווול אויף אַדאַפּטער ימפּלאַמענטיישאַן (ווייַטער פון קס 00 קס) איז בלויז אָפענגיק אויף אנדערע traits וואָס זענען שוין אנגעצייכנט ווי traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. דער מאַרקער איז ניט אָפענגיק אויף די לעבן פון טיפּ פון באַניצער סאַפּלייד.מאָדולאָ די קאָפּיע לאָך, וואָס עטלעכע אנדערע ספּעשאַלאַזיישאַנז זענען אָפענגען אויף.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // נאָך באדערפענישן וואָס קענען ניט זיין אויסגעדריקט דורך trait bounds.מיר פאַרלאָזנ זיך אויף קאָנסט עוואַל אַנשטאָט:
        // a) קיין זסטס ווייַל עס וואָלט זיין קיין אַלאַקיישאַן צו רייוס און טייַטל אַריטמעטיק וואָלט ז 0 פּאַניק 0 ז ב) גרייס גלייַכן ווי פארלאנגט דורך אַללאָק קאָנטראַקט c) אַליינמאַנץ גלייַכן ווי פארלאנגט דורך אַללאָק קאָנטראַקט
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // פאַלבאַק צו מער דזשאַנעריק ימפּלאַמענטיישאַנז
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // נוצן פּרובירן-פאַרלייגן זינט
        // - עס וועקטאָריזעס בעסער פֿאַר עטלעכע יטעראַטאָר אַדאַפּטערז
        // - ניט ענלעך רובֿ ינערלעך יטעראַטיאָן מעטהאָדס, עס בלויז נעמט אַ קס 00 קס זיך
        // - עס לאָזן אונדז פֿאָדעם די שרייַבן טייַטל דורך די ינערז און באַקומען עס צוריק אין די סוף
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // יטעראַטיאָן סאַקסידאַד, טאָן ניט פאַלן די קאָפּ
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // טשעק אויב SourceIter אָפּמאַך איז געווען אַפּכעלד קייוויאַט: אויב נישט, מיר קען נישט אפילו דערגרייכן דעם פונט
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // טשעק InPlaceIterable קאָנטראַקט.דאָס איז נאָר מעגלעך אויב די יטעראַטאָר אַוואַנסירטע די מקור טייַטל.
        // אויב עס ניצט ונקעקקעד אַקסעס דורך TrustedRandomAccess, דער מקור טייַטל סטייז אין זיין ערשט שטעלע און מיר קענען נישט נוצן עס ווי דערמאָנען.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // פאַלן קיין רוען וואַלועס אין די עק פון די מקור אָבער פאַרהיטן פאַלן פון די אַלאַקיישאַן זיך אַמאָל IntoIter גייט אויס פון פאַרנעם אויב די פאַלן panics, מיר אויך רינען קיין עלעמענטן געזאמלט אין דסט_בוף
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // די InPlaceIterable קאָנטראַקט קענען ניט זיין וועריפיעד דווקא דאָ ווייַל try_fold האט אַ ויסשליסיק דערמאָנען צו די מקור טייַטל אַלע מיר קענען טאָן איז צו קאָנטראָלירן אויב עס איז נאָך אין קייט
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}