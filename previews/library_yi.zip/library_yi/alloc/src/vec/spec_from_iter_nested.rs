use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// אן אנדער ספּעשאַלאַזיישאַן trait פֿאַר Vec::from_iter איז נויטיק צו מאַניואַלי פּרייאָראַטייז אָוווערלאַפּינג ספּעשאַלאַזיישאַנז, זען [`SpecFromIter`](super::SpecFromIter) פֿאַר דעטאַילס.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // ראָולינג די ערשטע יטעראַטיאָן, ווייַל די vector וועט זיין יקספּאַנדיד אויף דעם יטעראַטיאָן אין יעדער פאַל ווען די יטיראַבלע איז נישט ליידיק, אָבער די שלייף אין extend_desugared() וועט נישט זען די vector זייַנען פול אין די ביסל סאַבסאַקוואַנט שלייף יטעראַטיאָנס.
        //
        // אַזוי מיר באַקומען אַ בעסער פּראָגנאָז פון branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // מוזן דעלאַגייט צו קס 00 קס זינט קס 01 קס זיך דעלאַגייץ צו ספּעק_פראָם פֿאַר ליידיק וועקס
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // מוזן דעלאַגייט צו קס 00 קס זינט קס 01 קס זיך דעלאַגייץ צו ספּעק_פראָם פֿאַר ליידיק וועקס
        //
        vector.spec_extend(iterator);
        vector
    }
}