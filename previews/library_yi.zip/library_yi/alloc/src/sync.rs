#![stable(feature = "rust1", since = "1.0.0")]

//! פֿאָדעם-זיכער רעפֿערענץ-קאַונטינג פּוינטערז.
//!
//! זען די [`Arc<T>`][Arc] דאַקיומענטיישאַן פֿאַר מער דעטאַילס.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// א ווייך שיעור אויף די סומע פון באַווייַזן צו אַ `Arc`.
///
/// אויב איר העכער ווי דעם שיעור, איר קען אַבאָרטיד דיין פּראָגראַם (כאָטש ניט דאַווקע) ביי _exactly_ קס 01 קס באַווייַזן.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// טהרעאַדסאַניטיזער שטיצט ניט זכּרון פענסעס.
// צו ויסמיידן פאַלש positive ריפּאָרץ אין אַרק/וויק ימפּלאַמענטיישאַן, נוצן אַטאָמישע לאָודז פֿאַר סינגקראַנאַזיישאַן אַנשטאָט.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// א פאָדעם-זיכער רעפֿערענץ-קאַונטינג טייַטל.'Arc' שטייט פֿאַר 'Atomically Reference Counted'.
///
/// דער טיפּ קס 02 קס גיט שערד אָונערשיפּ פון אַ ווערט פון טיפּ קס 00 קס, אַלאַקייטיד אין די קופּע.ינוואָוקינג קס 03 קס אויף קס 04 קס טראגט אַ נייַ קס 05 קס, וואָס ווייזט צו דער זעלביקער אַלאַקיישאַן אויף די קופּע ווי די מקור קס 01 קס, בשעת ינקריסינג אַ רעפֿערענץ ציילן.
/// ווען די לעצטע `Arc` טייַטל צו אַ געגעבן אַלאַקיישאַן איז חרובֿ, די ווערט סטאָרד אין די אַלאַקיישאַן (אָפט ריפערד צו ווי "inner value") איז אויך דראַפּט.
///
/// שערד באַווייַזן אין Rust אָפּזאָגן מיוטיישאַן דורך פעליקייַט, און `Arc` איז ניט ויסנעם: איר קענט בכלל נישט באַקומען אַ מיוטאַבאַל באַווייַזן צו עפּעס אין אַן `Arc`.אויב איר דאַרפֿן צו מוטירן `Arc`, נוצן [`Mutex`][mutex], [`RwLock`][rwlock] אָדער איינער פון די [`Atomic`][atomic] טייפּס.
///
/// ## פֿאָדעם סאַפעטי
///
/// ניט ענלעך קס 00 קס, קס 01 קס ניצט אַטאָמישע אַפּעריישאַנז פֿאַר זייַן רעפֿערענץ קאַונטינג.דעם מיטל אַז עס איז פאָדעם-זיכער.די כיסאָרן איז אַז אַטאָמישע אַפּעריישאַנז זענען מער טייַער ווי געוויינטלעך זכּרון אַקסעס.אויב איר זענט נישט ייַנטיילונג רעפערענץ-קאַונטעד אַלאַקיישאַנז צווישן פֿעדעם, באַטראַכטן ניצן [`Rc<T>`] פֿאַר נידעריקער אָוווערכעד.
/// [`Rc<T>`] איז אַ זיכער פעליקייַט, ווייַל די קאַמפּיילער וועט כאַפּן קיין פּרווון צו שיקן אַן [`Rc<T>`] צווישן פֿעדעם.
/// אָבער, אַ ביבליאָטעק קען קלייַבן `Arc<T>` צו געבן ביבליאָטעק קאָנסומערס מער בייגיקייט.
///
/// `Arc<T>` וועט ינסטרומענט קס 01 קס און קס 02 קס ווי לאַנג ווי די קס 03 קס ימפּלאַמאַנץ קס 04 קס און קס 00 קס.
/// פארוואס קענט איר נישט שטעלן אַ ניט-פאָדעם-זיכער טיפּ קס 01 קס אין אַ קס 02 קס צו מאַכן עס פאָדעם-זיכער?דאָס קען זיין אַ ביסל טאָמבאַנק-ינטואַטיוו אין ערשטער: נאָך אַלע, איז נישט די פונט פון קס 03 קס פאָדעם זיכערקייַט?דער שליסל איז דאָס: `Arc<T>` מאכט עס זיכער פאָדעם צו האָבן קייפל אָונערשיפּ פון די זעלבע דאַטן, אָבער עס גיט נישט קיין פֿאָדעם זיכערקייַט צו זיין דאַטן.
///
/// באַטראַכטן `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] איז נישט [`Sync`], און אויב `Arc<T>` איז שטענדיק געווען [`Send`], `Arc <` [`RefCell<T>`]`>`וואָלט זיין ווי געזונט.
/// אָבער מיר וואָלט האָבן אַ פּראָבלעם:
/// [`RefCell<T>`] איז נישט פאָדעם זיכער;עס האלט שפּור פון די באַראָוינג ציילן מיט ניט-אַטאָמישע אַפּעריישאַנז.
///
/// אין די סוף, דעם מיטל אַז איר קען דאַרפֿן צו פאַרבינדן `Arc<T>` מיט אַ סאָרט פון [`std::sync`] טיפּ, יוזשאַוואַלי [`Mutex<T>`][mutex].
///
/// ## ברייקינג סייקאַלז מיט `Weak`
///
/// די [`downgrade`][downgrade] אופֿן קענען ווערן גענוצט צו שאַפֿן אַ ניט-אָונינג [`Weak`] טייַטל.א קס 03 קס טייַטל קענען זיין [`אַפּגרייד`][אַפּגרייד] ד צו אַ קס 00 קס, אָבער דאָס וועט צוריקקומען קס 04 קס אויב די ווערט סטאָרד אין די אַלאַקיישאַן איז שוין דראַפּט.
/// אין אנדערע ווערטער, קסקסנומקס קס פּוינטערז טאָן ניט האַלטן די ווערט ין די אַלאַקיישאַן לעבעדיק;אָבער, זיי *טאָן* האַלטן די אַלאַקיישאַן (די באַקינג קראָם פֿאַר די ווערט) לעבעדיק.
///
/// א ציקל צווישן קס 00 קס פּוינטערז וועט קיינמאָל זיין דילאַלאַקייטיד.
/// פֿאַר דעם סיבה, [`Weak`] איז געניצט צו ברעכן סייקאַלז.למשל, אַ בוים קען האָבן שטאַרק קס 01 קס פּוינטערז פון פאָטער נאָודז צו קינדער, און קס 02 קס פּוינטערז פון קינדער צוריק צו זייער עלטערן.
///
/// # קלאָונינג באַווייַזן
///
/// שאַפֿן אַ נייַע רעפֿערענץ פֿון אַן יגזיסטינג דערמאָנען טייַטל איז געשען מיט די `Clone` trait ימפּלאַמענאַד פֿאַר [`Arc<T>`][Arc] און [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // די צוויי סינטאַקסיז ונטער זענען עקוויוואַלענט.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b און foo זענען אַלע אַרקס וואָס ווייַזן צו דער זעלביקער זכּרון אָרט
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` אויטאָמאַטיש דערפערענסעס צו קס 02 קס (דורך די קס 03 קס ז 0 טראַאַט 0 ז), אַזוי איר קענען רופן די מעטהאָדס פון 'ט' אויף די ווערט פון טיפּ קס 01 קס.צו ויסמיידן די קלאַשיז פון מעטהאָדס מיט די מעטהאָדס, די מעטהאָדס פון קס 04 קס זיך זענען פארבונדן פאַנגקשאַנז, גערופֿן ניצן קס 00 קס:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// 'אַרק<T>די ימפּלאַמענטיישאַנז פון traits ווי `Clone` קען אויך זיין גערופֿן מיט גאָר קוואַלאַפייד סינטאַקס.
/// עטלעכע מענטשן בעסער וועלן צו נוצן גאָר קוואַלאַפייד סינטאַקס, אנדערע נוצן מעטהאָדס-רופן סינטאַקס.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // אופֿן-רופן סינטאַקס
/// let arc2 = arc.clone();
/// // גאָר קוואַלאַפייד סינטאַקס
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] קען נישט אַוטאָ-דערפעראַנס צו `T` ווייַל די ינער ווערט קען זיין שוין דראַפּט.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// ייַנטיילונג עטלעכע ימיוטאַבאַל דאַטן צווישן פֿעדעם:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// באַמערקונג אַז מיר **טאָן ניט** פירן די טעסץ דאָ.
// די windows בילדערז ווערן סופּער ומגליקלעך אויב אַ פאָדעם אַוטלייווז די הויפּט פאָדעם און דער זעלביקער צייט (עפּעס דעאַדלאָקקס) וועט זיין ויסמיידן, אַזוי מיר נאָר ויסמיידן דאָס דורך נישט לויפן די טעסץ.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// ייַנטיילונג אַ מיוטאַבאַל [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// זען די [`rc` documentation][rc_examples] פֿאַר מער ביישפילן פון קאַונטינג פון דערמאָנען בכלל.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` איז אַ ווערסיע פון [`Arc`] וואָס האט אַ ניט-אָונינג דערמאָנען צו די געראטן אַלאַקיישאַן.
/// די אַלאַקיישאַן איז אַקסעסט דורך רופן [`upgrade`] אויף די `Weak` טייַטל, וואָס קערט אַן [`אָפּציע`] <`[`אַרק`]`<T>> `.
///
/// זינט אַ `Weak` רעפֿערענץ טוט נישט ציילן פֿאַר אָונערשיפּ, דאָס וועט נישט פאַרמייַדן די ווערט סטאָרד אין די אַלאַקיישאַן פון פאַלן, און `Weak` זיך גיט קיין געראַנטיז וועגן די ווערט וואָס איז נאָך פאָרשטעלן.
///
/// אזוי עס קען צוריקקומען [`None`] ווען [`אַפּגרייד`] ד.
/// באַמערקונג אָבער אַז אַ `Weak` דערמאָנען *קען* פאַרמייַדן די אַלאַקיישאַן אַלאַוז (די באַקינג קראָם) דילאַקייטיד.
///
/// א קס 00 קס טייַטל איז נוציק פֿאַר בעכעסקעם אַ צייַטווייַליק דערמאָנען צו די אַלאַקיישאַן געראטן דורך קס 01 קס אָן פּרעווענטינג די ינער ווערט פון דראַפּינג.
/// עס איז אויך געניצט צו פאַרמייַדן קייַלעכיק באַווייַזן צווישן קס 00 קס פּוינטערז, ווייַל קעגנצייַטיק אָונינג באַווייַזן וואָלט קיינמאָל לאָזן [`Arc`] צו פאַלן.
/// למשל, אַ בוים קען האָבן שטאַרק קס 00 קס פּוינטערז פֿון פאָטער נאָודז צו קינדער, און קס 01 קס פּוינטערז פֿון קינדער צוריק צו זייער עלטערן.
///
/// די טיפּיש וועג צו קריגן אַ קס 01 קס טייַטל איז רופן קס 00 קס.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // דאָס איז אַ `NonNull` צו לאָזן אָפּטימיזינג די גרייס פון דעם טיפּ אין ענומס, אָבער עס איז נישט דאַווקע אַ גילטיק טייַטל.
    //
    // `Weak::new` שטעלט דעם צו קסקסנומקסקס אַזוי אַז עס דאַרף נישט אַלאַקייט פּלאַץ אויף די קופּע.
    // דאָס איז נישט אַ ווערט אַ פאַקטיש טייַטל וועט האָבן טאָמיד ווייַל רקבאָקס האט אַליינמאַנט לפּחות 2.
    // דאָס איז נאָר מעגלעך ווען `T: Sized`;ונסייזד קס 01 קס קיינמאָל באָמבלען.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// דאָס איז repr(C) צו future-proof קעגן מעגלעך פעלד-ריאָרדערינג, וואָס וואָלט אַרייַנמישנ זיך מיט אַנדערש [into|from]_raw() פון טראַנסמוטאַבלע ינער טייפּס.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // די ווערט קס 01 קס אַקץ ווי אַ סענטינעל פֿאַר טעמפּערעראַלי קס 02 קס די פיייקייט צו אַפּגרייד שוואַך פּוינטערז אָדער אַראָפּרעכענען שטאַרק אָנעס;דעם איז געניצט צו ויסמייַדן ראַסעס אין קס 03 קס און קס 00 קס.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// קאַנסטראַקץ אַ נייַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // אָנהייב די שוואַך טייַטל ציילן ווי 1, וואָס איז די שוואַך טייַטל וואָס איז געהאלטן דורך אַלע די שטאַרק פּוינטערז קס 00 קס, זען קס 01 קס פֿאַר מער אינפֿאָרמאַציע
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// בויען אַ נייַע קס 00 קס ניצן אַ שוואַך דערמאָנען צו זיך.
    /// פּרווון צו אַפּגרייד די שוואַך רעפֿערענץ איידער די פֿונקציע קערט וועט רעזולטאַט אין אַ `None` ווערט.
    /// די שוואַך רעפֿערענץ קען זיין קלאָונד פרילי און סטאָרד פֿאַר נוצן אין אַ שפּעטער צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // בויען די ינער אין די "uninitialized" שטאַט מיט אַ שוואַך דערמאָנען.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // עס איז וויכטיק מיר טאָן ניט געבן אַרויף אָונערשיפּ פון די שוואַך טייַטל, אַנדערש די זכּרון קען זיין באפרייט ווען `data_fn` קערט.
        // אויב מיר טאַקע געוואלט צו פאָרן אָונערשיפּ, מיר קענען מאַכן אַן נאָך שוואַך טייַטל פֿאַר זיך, אָבער דאָס וואָלט רעזולטאַט אין נאָך דערהייַנטיקונגען צו די שוואַך רעפֿערענץ ציילן וואָס אַנדערש קען נישט זיין נויטיק.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // איצט מיר קענען ערשט יניטיאַליזירן די ינער ווערט און ווענדן אונדזער שוואַך רעפֿערענץ אין אַ שטאַרק רעפֿערענץ.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // די אויבן שרייַבן צו די דאַטן פעלד מוזן זיין קענטיק צו קיין פֿעדעם וואָס האָבן אַ ניט-נול שטאַרק ציילן.
            // דעריבער מיר דאַרפֿן לפּחות "Release" אָרדערינג צו סינגקראַנייז מיט `compare_exchange_weak` אין `Weak::upgrade`.
            //
            // "Acquire" אָרדערינג איז ניט פארלאנגט.
            // ווען איר באַטראַכטן די מעגלעך ביכייוויערז פון קס 01 קס, מיר נאָר דאַרפֿן צו קוקן אין וואָס עס קען טאָן מיט אַ רעפֿערענץ צו אַ ניט-ופּגראַדעאַבלע קס 00 קס:
            //
            // - עס קענען *קלאָון* די קס 00 קס, ינקריסינג די שוואַך רעפֿערענץ ציילן.
            // - עס קענען פאַלן די קלאָונז, און דיקריסט די שוואַך רעפֿערענץ ציילן (אָבער קיינמאָל צו נול).
            //
            // די זייַט יפעקס טאָן ניט ווירקן אונדז אין קיין וועג, און קיין אנדערע זייַט יפעקס זענען מעגלעך בלויז מיט זיכער קאָד.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // שטאַרק רעפערענצן זאָל קאַלעקטיוולי האָבן אַ שערד שוואַך רעפֿערענץ, אַזוי טאָן ניט פירן דעם דעסטרוקטאָר פֿאַר אונדזער אַלט שוואַך רעפֿערענץ.
        //
        mem::forget(weak);
        strong
    }

    /// בויען אַ נייַע קס 00 קס מיט אַנינישיייטיד אינהאַלט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// קאָנסטרוקץ אַ נייַ קס 00 קס מיט אַנינישיייטיד אינהאַלט, מיט די זיקאָרן אָנגעפילט מיט קס 01 קס ביטעס.
    ///
    ///
    /// זען קס 00 קס פֿאַר ביישפילן פון ריכטיק און פאַלש באַניץ פון דעם אופֿן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// קאַנסטראַקץ אַ נייַ קס 00 קס.
    /// אויב קס 01 קס טוט נישט ינסטרומענט קס 00 קס, קס 02 קס וועט זיין פּיננעד אין זכּרון און קען ניט זיין אריבערגעפארן.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// קאַנסטראַקץ אַ נייַע קס 00 קס, און אומגעקערט אַ טעות אויב אַלאַקיישאַן פיילז.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // אָנהייב די שוואַך טייַטל ציילן ווי 1, וואָס איז די שוואַך טייַטל וואָס איז געהאלטן דורך אַלע די שטאַרק פּוינטערז קס 00 קס, זען קס 01 קס פֿאַר מער אינפֿאָרמאַציע
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// בויען אַ נייַע קס 00 קס מיט אַניניטיאַליזעד אינהאַלט, און אומגעקערט אַ טעות אויב די אַלאַקיישאַן איז פיילד.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// קאָנסטרוקץ אַ נייַ קס 00 קס מיט אַנינישיייטיד אינהאַלט, מיט די זיקאָרן אָנגעפילט מיט קס 01 קס ביטעס, קערט אַ טעות אויב די אַלאַקיישאַן פיילז.
    ///
    ///
    /// זען קס 00 קס פֿאַר ביישפילן פון ריכטיק און פאַלש באַניץ פון דעם אופֿן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// קערט די ינער ווערט אויב די `Arc` האט פּונקט איין שטאַרק דערמאָנען.
    ///
    /// אַנדערש, אַ [`Err`] איז אומגעקערט מיט די זעלבע `Arc` וואָס איז דורכגעגאנגען.
    ///
    ///
    /// דאָס וועט זיין געראָטן אפילו אויב עס זענען בוילעט שוואַך באַווייַזן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // מאַכן אַ שוואַך טייַטל צו רייניקן די ימפּליסאַט שטאַרק-שוואַך רעפֿערענץ
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// קאַנסטראַקץ אַ נייַ אַטאָמישע רעפֿערענץ-קאַונטעד רעפטל מיט אַנינישיייטיד אינהאַלט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// קאַנסטראַקץ אַ נייַ אַטאָמישע רעפֿערענץ-קאַונטעד רעפטל מיט אַנינישיייטיד אינהאַלט, מיט די זכּרון אָנגעפילט מיט קס 00 קס ביטעס.
    ///
    ///
    /// זען קס 00 קס פֿאַר ביישפילן פון ריכטיק און פאַלש באַניץ פון דעם אופֿן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// קאָנווערץ צו קס 00 קס.
    ///
    /// # Safety
    ///
    /// ווי מיט [`MaybeUninit::assume_init`], עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די ינער ווערט טאַקע איז אין אַן ינישאַלייזד שטאַט.
    ///
    /// רופן דעם ווען די אינהאַלט איז נישט נאָך ינישיייטיד ז גלייך אַנדיפיינד נאַטור.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// קאָנווערץ צו קס 00 קס.
    ///
    /// # Safety
    ///
    /// ווי מיט [`MaybeUninit::assume_init`], עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די ינער ווערט טאַקע איז אין אַן ינישאַלייזד שטאַט.
    ///
    /// רופן דעם ווען די אינהאַלט איז נישט נאָך ינישיייטיד ז גלייך אַנדיפיינד נאַטור.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// קאַנסומז די `Arc` און אומגעקערט די אלנגעוויקלט טייַטל.
    ///
    /// צו ויסמיידן אַ זיקאָרן רינען, די טייַטל מוזן זיין קאָנווערטעד צוריק צו אַ `Arc` ניצן [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// גיט אַ רוי טייַטל צו די דאַטן.
    ///
    /// די קאַונץ זענען נישט אַפעקטאַד אין קיין וועג און די `Arc` איז נישט קאַנסומד.
    /// די טייַטל איז גילטיק ווי לאַנג ווי עס זענען שטאַרק קאַונץ אין די `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // זיכערקייט: דאָס קען נישט דורכגיין Deref::deref אָדער RcBoxPtr::inner ווייַל
        // דאָס איז פארלאנגט צו האַלטן raw/mut פּראָווענאַנסע אַזאַ ווי למשל
        // `get_mut` קענען שרייַבן דורך די טייַטל נאָך די Rc איז ריקאַווערד דורך `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// בויען אַ `Arc<T>` פֿון אַ רוי טייַטל.
    ///
    /// די רוי טייַטל מוזן האָבן שוין ביז אַהער אומגעקערט דורך אַ רוף צו קס 01 קס, ווו קס 02 קס מוזן האָבן די זעלבע גרייס און אַליינמאַנט ווי קס 00 קס.
    /// דאָס איז נישטיק אויב `U` איז `T`.
    /// באַמערקונג אַז אויב `U` איז נישט `T` אָבער די זעלבע גרייס און אַליינמאַנט, דאָס איז בייסיקלי ווי טראַנסמוטטינג באַווייַזן פון פאַרשידענע טייפּס.
    /// זען [`mem::transmute`][transmute] פֿאַר מער אינפֿאָרמאַציע וועגן וואָס ריסטריקשאַנז זענען גילטיק אין דעם פאַל.
    ///
    /// דער באַניצער פון `from_raw` מוזן מאַכן זיכער אַז אַ ספּעציפֿיש ווערט פון `T` איז נאָר דראַפּט אַמאָל.
    ///
    /// די פֿונקציע איז אַנסייף ווייַל די ימפּראַפּער נוצן קען פירן צו אַנסייפע פון זכּרון, אפילו אויב די `Arc<T>` איז קיינמאָל אַקסעסט.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // גער צוריק צו אַן `Arc` צו פאַרמייַדן רינען.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ווייַטער רופט צו קס 00 קס וואָלט זיין זכּרון-אַנסייף.
    /// }
    ///
    /// // דער זכּרון איז באפרייט ווען קס 00 קס איז אויס פון די אויבן אויבן, אַזוי קס 01 קס איז איצט דאַנגגלינג!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // פאַרקערט די פאָטאָ צו געפֿינען די אָריגינעל ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// קרעאַטעס אַ נייַע קס 00 קס טייַטל צו דעם אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // די רילאַקסט איז גוט ווייַל מיר קאָנטראָלירן די ווערט אין די CAS אונטן.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // טשעק אויב די שוואַך טאָמבאַנק איז דערווייַל קס 00 קס;אויב אַזוי, ומדריי.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: דער קאָד יגנאָרז דערווייַל די מעגלעכקייט פון לויפן
            // אין usize::MAX;אין אַלגעמיין, ביידע RC און Arc דאַרפֿן צו זיין אַדזשאַסטיד צו האַנדלען מיט לויפן.
            //

            // ניט ענלעך Clone(), מיר דאַרפֿן דאָס צו זיין אַ לייענען לייענען צו סינגקראַנייז מיט די שרייבן פֿון `is_unique`, אַזוי אַז די געשעענישן איידער די שרייבן פּאַסירן איידער דעם לייענען.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // מאַכט זיכער אַז מיר טאָן ניט מאַכן אַ דאַנגגלינג וויק
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// די נומער פון [`Weak`] פּוינטערז צו די אַלאַקיישאַן.
    ///
    /// # Safety
    ///
    /// דעם אופֿן איז זיכער זיכער, אָבער צו נוצן עס ריכטיק ריקווייערז עקסטרע זאָרג.
    /// אן אנדער פאָדעם קענען טוישן די שוואַך ציילן צו קיין צייט, אַרייַנגערעכנט פּאָטענציעל צווישן רופן דעם אופֿן און אַקטינג אויף דער רעזולטאַט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // די באַשטעטיקן איז דיטערמאַניסטיק ווייַל מיר האָבן נישט שערד די `Arc` אָדער `Weak` צווישן פֿעדעם.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // אויב די שוואַך ציילן איז דערווייַל פארשפארט, די ווערט פון די ציילן איז געווען 0 פּונקט איידער איר נעמען די שלאָס.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// די נומער פון שטאַרק אַקסנומקס קס פּוינטערז צו דעם אַלאַקיישאַן.
    ///
    /// # Safety
    ///
    /// דעם אופֿן איז זיכער זיכער, אָבער צו נוצן עס ריכטיק ריקווייערז עקסטרע זאָרג.
    /// אן אנדער פאָדעם קענען טוישן די שטאַרק ציילן צו קיין צייט, אַרייַנגערעכנט פּאָטענציעל צווישן רופן דעם אופֿן און אַקטינג אויף דער רעזולטאַט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // די באַשטעטיקן איז דיטערמאַניסטיק ווייַל מיר האָבן נישט שערד די `Arc` צווישן פֿעדעם.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// ינקרימענץ די שטאַרק רעפֿערענץ ציילן אויף די `Arc<T>` פֿאַרבונדן מיט די צוגעשטעלט טייַטל דורך איינער.
    ///
    /// # Safety
    ///
    /// דער טייַטל מוזן האָבן שוין באקומען דורך `Arc::into_raw`, און די פֿאַרבונדן `Arc` בייַשפּיל מוזן זיין גילטיק (י.ע.
    /// די שטאַרק ציילן מוזן זיין לפּחות 1) פֿאַר די געדויער פון דעם אופֿן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // די באַשטעטיקן איז דיטערמאַניסטיק ווייַל מיר האָבן נישט שערד די `Arc` צווישן פֿעדעם.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // ריטיין אַרק, אָבער טאָן ניט אָנרירן די רעפאָונט דורך ראַפּינג אין מאַנואַללי דראָפּ
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // איצט ינקרעאַסע ריפאָונט, אָבער טאָן ניט פאַלן אַ נייַ רעפאָונט
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// דיקריסט די שטאַרק רעפֿערענץ ציילן אויף די `Arc<T>` פֿאַרבונדן מיט די צוגעשטעלט טייַטל דורך איינער.
    ///
    /// # Safety
    ///
    /// דער טייַטל מוזן האָבן שוין באקומען דורך `Arc::into_raw`, און די פֿאַרבונדן `Arc` בייַשפּיל מוזן זיין גילטיק (י.ע.
    /// די שטאַרק ציילן דאַרף זיין לפּחות 1) ווען איר רופן דעם אופֿן.
    /// דעם אופֿן קענען ווערן גענוצט צו באַפרייַען די לעצט `Arc` און באַקינג סטאָרידזש, אָבער **זאָל** נישט זיין גערופֿן נאָך די לעצט `Arc` איז באפרייט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // די טענות זענען דיטערמאַניסטיק ווייַל מיר האָבן נישט שערד די `Arc` צווישן פֿעדעם.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // די אַנסאַפעטי איז גוט ווייַל בשעת דעם קרייַזבויגן איז לעבעדיק מיר געראַנטיד אַז די ינער טייַטל איז גילטיק.
        // אין אַדישאַן, מיר וויסן אַז די `ArcInner` סטרוקטור זיך איז `Sync` ווייַל די ינער דאַטן זענען `Sync`, אַזוי מיר קענען אַנטלייַען אַ ימיושאַנאַל טייַטל צו די אינהאַלט.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // ניט-ינליינד טייל פון קס 00 קס.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // צעשטערן די דאַטן אין דעם צייַט, כאָטש מיר קען נישט באַפרייַען די קעסטל אַלאַקיישאַן זיך (עס קען נאָך זיין שוואַך פּוינטערז ליגנעריש).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // פאַלן די שוואַך רעף קאַלעקטיוולי ביי אַלע שטאַרק באַווייַזן
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// קערט `true` אויב די צוויי `Arc`s ווייַזן צו דער זעלביקער אַלאַקיישאַן (אין אַ אָדער ענלעך [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// אַללאָקאַטעס אַ `ArcInner<T>` מיט גענוג פּלאַץ פֿאַר אַ ינערייזד ינערלעך ווערט, וואָס די ווערט האט צוגעשטעלט.
    ///
    /// די פונקציע קס 01 קס איז גערופֿן מיט די דאַטן טייַטל און מוזן צוריקקומען אַ (פּאַטענטשאַלי פעט)-ווײַזער פֿאַר די קס 00 קס.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // רעכענען אויסלייג ניצן די געגעבן ווערט אויסלייג.
        // ביז אַהער, די אויסלייג איז געווען קאַלקיאַלייטיד אויף דעם אויסדרוק קס 00 קס, אָבער דאָס באשאפן אַ מיסאַליינד דערמאָנען (זען קס 01 קס).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// אַללאָקאַטעס אַ `ArcInner<T>` מיט גענוג פּלאַץ פֿאַר אַ עפשער-אַנסייזד ינער ווערט, וואָס די ווערט האט דער אויסלייג צוגעשטעלט, און אומגעקערט אַ טעות אויב די אַלאַקיישאַן איז אַנדערש.
    ///
    ///
    /// די פונקציע קס 01 קס איז גערופֿן מיט די דאַטן טייַטל און מוזן צוריקקומען אַ (פּאַטענטשאַלי פעט)-ווײַזער פֿאַר די קס 00 קס.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // רעכענען אויסלייג ניצן די געגעבן ווערט אויסלייג.
        // ביז אַהער, די אויסלייג איז געווען קאַלקיאַלייטיד אויף דעם אויסדרוק קס 00 קס, אָבער דאָס באשאפן אַ מיסאַליינד דערמאָנען (זען קס 01 קס).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // יניטיאַליזירן די ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// אַללאָקאַטעס אַ `ArcInner<T>` מיט גענוג פּלאַץ פֿאַר אַן אַנסייזד ינער ווערט.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // אַלאַקייט די `ArcInner<T>` מיט די געגעבן ווערט.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // קאָפּיע ווערט ווי ביטעס
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // באַפרייַען די אַלאַקיישאַן אָן דראַפּינג די אינהאַלט
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// אַלאַקייץ אַן `ArcInner<[T]>` מיט די געגעבן לענג.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// קאָפּיע עלעמענטן פון רעפטל אין די נייַ אַלאַקייטיד אַרק <\[ה\]>
    ///
    /// אַנסייף ווייַל די קאַללער מוזן נעמען אָונערשיפּ אָדער בינדן `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// בויען אַ `Arc<[T]>` פֿון אַ יטעראַטאָר, וואָס איז באַוווסט צו זיין אַ זיכער גרייס.
    ///
    /// די נאַטור איז אַנדיפיינד אויב די גרייס איז פאַלש.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic היטן בשעת קלאָונינג ה עלעמענטן.
        // אין פאַל פון panic, די עלעמענטן וואָס זענען געשריבן אין די נייַ ArcInner וועט זיין דראַפּט, און דער זכּרון איז באפרייט.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // טייַטל צו ערשטער עלעמענט
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // כל קלאָר.פאַרגעסן די וועכטער אַזוי אַז דער נייַ אַרקיננער וועט נישט באַפרייַען.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ספּעשאַלאַזיישאַן ז 0 טראַיט 0 ז געניצט פֿאַר קס 00 קס.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// מאכט אַ קלאָון פון די קס 00 קס טייַטל.
    ///
    /// דעם קריייץ אן אנדער טייַטל צו דער זעלביקער אַלאַקיישאַן, ינקריסינג די שטאַרק רעפֿערענץ ציילן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // ניצן אַ רילאַקסט אָרדערינג איז אָוקיי דאָ, ווייַל וויסן פון דער אָריגינעל דערמאָנען פּריווענץ אנדערע פֿעדעם פון עראָוניאַסלי ויסמעקן די כייפעץ.
        //
        // ווי דערקלערט אין די קס 00 קס, ינקרעאַסינג די רעפערענץ טאָמבאַנק קענען שטענדיק זיין געטאן מיט memory_order_relaxed: נייַע באַווייַזן צו אַ כייפעץ קענען בלויז זיין געשאפן פֿון אַן יגזיסטינג רעפֿערענץ, און די יגזיסטינג דערמאָנען פון איין פאָדעם צו אנדערן מוזן שוין צושטעלן קיין פארלאנגט סינגקראַנאַזיישאַן.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // אָבער, מיר דאַרפֿן צו היטן קעגן מאַסיוו רעפאָונץ אין פאַל עמעצער איז `מעמ: : פאָרגעט`ינג אַרקס.
        // אויב מיר טאָן ניט טאָן דאָס, די ציילן קענען לויפן, און וסערס נוצן נאָך פריי.
        // מיר זאַט זיך צו קס 00 קס אויף די האַשאָרע אַז עס זענען נישט קס 01 קס ביליאָן פֿעדעם ינקריסינג די רעפֿערענץ ציילן אין אַמאָל.
        //
        // די branch וועט קיינמאָל זיין גענומען אין קיין רעאַליסטיש פּראָגראַם.
        //
        // מיר אַבאָרט ווייַל אַזאַ אַ פּראָגראַם איז ינקרעדאַבלי דידזשענערייטיד, און מיר טאָן ניט זאָרגן צו שטיצן עס.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// מאכט אַ מיוטאַבאַל דערמאָנען אין די געגעבן קס 00 קס.
    ///
    /// אויב עס זענען אנדערע קס 00 קס אָדער קס 01 קס פּוינטערז צו דער זעלביקער אַלאַקיישאַן, קס 02 קס וועט שאַפֿן אַ נייַע אַלאַקיישאַן און ינוואָוק קס 03 קס אויף די ינער ווערט צו ענשור יינציק אָונערשיפּ.
    /// דאָס איז אויך ריפערד צו ווי קלאָון-אויף-שרייַבן.
    ///
    /// באַמערקונג אַז דאָס איז אַנדערש פון די נאַטור פון [`Rc::make_mut`] וואָס דיסאַסאָוסיייץ קיין רוען `Weak` פּוינטערז.
    ///
    /// זען אויך [`get_mut`][get_mut], וואָס וועט ניט אַנדערש ווי קלאָונינג.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // וועט נישט קלאָון עפּעס
    /// let mut other_data = Arc::clone(&data); // וועט ניט קלאָון ינער דאַטן
    /// *Arc::make_mut(&mut data) += 1;         // קלאָונז ינער דאַטן
    /// *Arc::make_mut(&mut data) += 1;         // וועט נישט קלאָון עפּעס
    /// *Arc::make_mut(&mut other_data) *= 2;   // וועט נישט קלאָון עפּעס
    ///
    /// // איצט `data` און `other_data` פונט צו פאַרשידענע אַלאַקיישאַנז.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // באַמערקונג אַז מיר האַלטן ביידע אַ שטאַרק דערמאָנען און אַ שוואַך דערמאָנען.
        // דערמיט בלויז ריליסינג אונדזער שטאַרק רעפֿערענץ קען נישט דער זכּרון ווערן דיקלאָוקייטיד דורך זיך.
        //
        // ניצן אַקווירע צו ענשור אַז מיר זען שרייבן צו קס 01 קס וואָס פּאַסירן איידער מעלדונג שרייבט (י.ע., דיקרישאַנז) צו קס 00 קס.
        // זינט מיר האָבן אַ שוואַך ציילן, עס איז קיין שאַנס אַז די ArcInner זיך קען זיין דילאַקייטיד.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // אן אנדער שטאַרק טייַטל יגזיסץ, אַזוי מיר מוזן קלאָון.
            // פאַר-אַלאַקייט זיקאָרן צו לאָזן שרייבן די קלאָונד ווערט גלייַך.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // רילאַקסט גענוג אין די אויבן ווייַל דאָס איז פאַנדאַמענטאַלי אַן אַפּטאַמאַזיישאַן: מיר זענען שטענדיק ראַסינג מיט שוואַך פּוינטערז וואָס זענען דראַפּט.
            // ערגסט פאַל, מיר ענדאַד אַלאַקייטיד אַ נייַ אַרק אַננעסאַסעראַלי.
            //

            // מיר האָבן אַוועקגענומען די לעצטע שטאַרק רעף, אָבער עס זענען נאָך שוואַך רעפ.
            // מיר וועלן אַריבערפירן די אינהאַלט צו אַ נייַע קרייַזבויגן און פאַרקריפּלט די אנדערע שוואַך רעפ.
            //

            // באַמערקונג אַז די `weak` לייענען איז ניט מעגלעך צו טראָגן usize::MAX (ד"ה לאַקט), ווייַל די שוואַך ציילן קענען נאָר זיין פארשפארט דורך אַ פאָדעם מיט אַ שטאַרק רעפֿערענץ.
            //
            //

            // מאַטיריאַלייז אונדזער אייגענע ימפּליסאַט שוואַך טייַטל, אַזוי אַז עס קענען רייניקן די ArcInner ווי איר דאַרפֿן.
            //
            let _weak = Weak { ptr: this.ptr };

            // קענען נאָר גאַנווענען די דאַטן, אַלע וואָס איז לינקס איז וויקס
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // מיר זענען די איינציקע רעפערענץ פון ביידע סאָרטן;זעץ צוריק די שטאַרק רעף ציילן.
            //
            this.inner().strong.store(1, Release);
        }

        // ווי מיט `get_mut()`, די ונסאַפעטי איז גוט ווייַל אונדזער רעפֿערענץ איז געווען יינציק צו אָנהייבן, אָדער איז געווען איינער ווען קלאָונינג די אינהאַלט.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// קערט אַ מיוטאַבאַל רעפֿערענץ אין די געגעבן קס 00 קס, אויב עס זענען קיין אנדערע קס 01 קס אָדער קס 02 קס פּוינטערז צו דער זעלביקער אַלאַקיישאַן.
    ///
    ///
    /// קערט [`None`] אַנדערש ווייַל עס איז ניט זיכער צו מיוטייט אַ שערד ווערט.
    ///
    /// זען אויך [`make_mut`][make_mut], וואָס [`clone`][clone] די ינער ווערט ווען עס זענען אנדערע פּוינטערז.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // די אַנסאַפעטי איז גוט ווייַל מיר זענען געראַנטיד אַז דער טייַטל וואָס איז אומגעקערט איז די *בלויז* טייַטל וואָס וועט טאָמיד זיין אומגעקערט צו טי.
            // אונדזער רעפֿערענץ ציילן איז געראַנטיד צו זיין 1 אין דעם פונט, און מיר האָבן פארלאנגט אַז די אַרק זיך זאָל זיין קס 00 קס, אַזוי מיר צוריקקומען די בלויז מעגלעך דערמאָנען צו די ינער דאַטן.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// קערט אַ מיוטאַבאַל באַווייַזן אין די געגעבן קס 00 קס, אָן קיין טשעק.
    ///
    /// זען אויך [`get_mut`], וואָס איז זיכער און צונעמען טשעקס.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// קיין אנדערע קס 00 קס אָדער קס 01 קס פּוינטערז צו דער זעלביקער אַלאַקיישאַן מוזן ניט זיין דערפערענסט פֿאַר די געדויער פון די אומגעקערט באַראָוד.
    ///
    /// דאָס איז טריוויאַללי דער פאַל אויב עס זענען נישט אַזאַ פּוינטערז, פֿאַר בייַשפּיל גלייך נאָך `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // מיר זענען אָפּגעהיט צו *נישט* שאַפֿן אַ רעפֿערענץ וואָס קאַווערד די "count" פעלדער, ווייַל דאָס אַליאַס מיט קאַנקעראַנט אַקסעס צו די רעפֿערענץ קאַונץ (למשל
        // דורך `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// באַשליסן צי דאָס איז די יינציק רעפֿערענץ (אַרייַנגערעכנט שוואַך רעפס) צו די אַנדערלייינג דאַטן.
    ///
    ///
    /// באַמערקונג אַז דאָס ריקווייערז לאַקינג די שוואַך רעף ציילן.
    fn is_unique(&mut self) -> bool {
        // פאַרשליסן די שוואַך טייַטל, אויב מיר ויסקומען צו זיין דער בלויז שוואַך טייַטל האָלדער.
        //
        // די קריגן פירמע דאָ ינשורז אַ כאַפּאַנז איידער שייכות מיט קס 01 קס (ספּעציעל אין קס 03 קס) איידער דיקרישאַנז פון די קס 02 קס ציילן (דורך קס 00 קס, וואָס ניצט מעלדונג).
        // אויב די אַפּגריידיד שוואַך רעף איז קיינמאָל דראַפּט, די CAS דאָ וועט פאַרלאָזן, אַזוי מיר טאָן ניט זאָרגן צו סינגקראַנייז.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // דאָס דאַרף זיין אַן `Acquire` צו סינגקראַנייז מיט די דעקרעד פון די `strong` טאָמבאַנק אין `drop`-דער בלויז אַקסעס וואָס כאַפּאַנז ווען די לעצטע באַווייַזן איז דראַפּט.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // די ריליס שרייַבן דאָ סינגקראַנייזיז מיט `downgrade` לייענען, יפעקטיוולי פּרעווענטינג די `strong` לייענען אויבן נאָך די שרייבן.
            //
            //
            self.inner().weak.store(1, Release); // באַפרייַען די שלאָס
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// טראפנס די קס 00 קס.
    ///
    /// דאָס וועט פאַרקלענערן די שטאַרק רעפֿערענץ ציילן.
    /// אויב די שטאַרק רעפֿערענץ ציילן ריטשאַז נול, די בלויז אנדערע באַווייַזן (אויב קיין) זענען [`Weak`], אַזוי מיר זענען `drop` די ינער ווערט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // טוט נישט דרוקן עפּעס
    /// drop(foo2);   // פּרינץ קס 00 קס
    /// ```
    #[inline]
    fn drop(&mut self) {
        // ווייַל `fetch_sub` איז שוין אַטאָמישע, מיר טאָן ניט דאַרפֿן צו סינגקראַנייז מיט אנדערע פֿעדעם סייַדן מיר וועלן צו ויסמעקן די כייפעץ.
        // דער זעלביקער לאָגיק אַפּלייז צו די `fetch_sub` ונטער X1X ציילן.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // דער פּלויט איז נידיד צו פאַרמייַדן די אָרדערערינג פון די נוצן פון די דאַטן און דילישאַן פון די דאַטן.
        // ווייַל עס איז אנגעצייכנט קס 00 קס, די רידוסינג פון דער רעפֿערענץ ציילן סינגקראַנייזיז מיט דעם קס 01 קס פּלויט.
        // דעם מיטל אַז די נוצן פון דאַטן כאַפּאַנז איידער דיקריסט די רעפֿערענץ ציילן, וואָס כאַפּאַנז איידער דעם פּלויט, וואָס כאַפּאַנז איידער די דילישאַן פון די דאַטן.
        //
        // ווי דערקלערט אין די [Boost documentation][1],
        //
        // > עס איז וויכטיק צו דורכפירן קיין מעגלעך אַקסעס צו די כייפעץ אין איין
        // > פאָדעם (דורך אַ יגזיסטינג דערמאָנען) צו *פּאַסירן איידער* דיליטינג
        // > די כייפעץ אין אַ אַנדערש פאָדעם.דעם איז אַטשיווד דורך אַ "release"
        // > אָפּעראַציע נאָך דראַפּינג אַ רעפֿערענץ (קיין אַקסעס צו די כייפעץ
        // > דורך דעם דערמאָנען מוזן דאָך געשען פריער), און אַן
        // > "acquire" אָפּעראַציע איידער דיליטינג די כייפעץ.
        //
        // אין באַזונדער, כאָטש די אינהאַלט פון אַן אַרק איז יוזשאַוואַלי ימיוטאַבאַל, עס איז מעגלעך אַז די ינלענדיש שרייבט צו עפּעס ווי אַ מוטעקס<T>.
        // זינט אַ מוטעקס איז ניט קונה ווען עס איז אויסגעמעקט, מיר קענען נישט פאַרלאָזנ אויף די סינגקראַנאַזיישאַן לאָגיק צו מאַכן שרייבן אין פאָדעם א קענטיק צו אַ דעסטרוקטאָר וואָס לויפן אין פֿאָדעם ב.
        //
        //
        // אויך טאָן אַז די אַקווייער פּלויט דאָ קען מיסטאָמע זיין ריפּלייסט מיט אַ קריגן מאַסע, וואָס קען פֿאַרבעסערן די פאָרשטעלונג אין העכסט קאַנטענדיד סיטואַטיאָנס.זען קס 00 קס.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// פּרווון צו אַראָפּרעכענען די `Arc<dyn Any + Send + Sync>` צו אַ באַטאָנען טיפּ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// בויען אַ נייַ קס 00 קס אָן אַלאַקייטינג קיין זכּרון.
    /// רופן קס 01 קס אויף די צוריקקומען ווערט שטענדיק גיט קס 00 קס.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// העלפער טיפּ צו לאָזן אַקסעס צו דער רעפֿערענץ קאַונץ אָן קיין באַשטעטיקן וועגן די דאַטן פעלד.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// רעטורנס אַ רוי טייַטל צו די כייפעץ קס 01 קס ווייזט דורך דעם קס 00 קס.
    ///
    /// דער טייַטל איז גילטיק בלויז אויב עס זענען עטלעכע שטאַרק באַווייַזן.
    /// דער טייַטל קען זיין דאַנגגלינג, אַנאַליינד אָדער אפילו [`null`] אַנדערש.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ביידע פונט צו דער זעלביקער כייפעץ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // די שטאַרק דאָ האלט עס לעבעדיק, אַזוי מיר קענען נאָך אַקסעס די כייפעץ.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // אָבער נישט מער.
    /// // מיר קענען טאָן weak.as_ptr(), אָבער אַקסעס צו די טייַטל וואָלט פירן צו ונדעפינייטיד נאַטור.
    /// // אַססערט_עק! ("העלא", אַנסייף {קס 00 קס;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // אויב דער טייַטל איז דאַנגגלינג, מיר ווייַזן די סענטינעל גלייַך.
            // דאָס קען נישט זיין אַ גילטיק פּיילאָוד אַדרעס, ווייַל די פּיילאָוד איז לפּחות ווי אַליינד ווי ArcInner (usize).
            ptr as *const T
        } else {
            // זיכערקייט: אויב יס_דאַנגלינג קערט פאַלש, דער טייַטל איז דערפערענאַבאַל.
            // די פּיילאָוד קען זיין דראַפּט אין דעם פונט, און מיר האָבן צו טייַנען פּראָווענאַנסע, אַזוי נוצן רוי טייַטל מאַניפּיאַליישאַן.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// קאַנסומז די `Weak<T>` און טורנס עס אין אַ רוי טייַטל.
    ///
    /// דעם קאַנווערץ די שוואַך טייַטל אין אַ רוי טייַטל, בשעת נאָך פּרעזערוויישאַן די אָונערשיפּ פון איין שוואַך רעפֿערענץ (די שוואַך ציילן איז נישט מאַדאַפייד דורך די אָפּעראַציע).
    /// עס קענען זיין פארקערט צוריק אין די `Weak<T>` מיט [`from_raw`].
    ///
    /// די זעלבע ריסטריקשאַנז פון אַקסעס צו די ציל פון די טייַטל ווי מיט [`as_ptr`] אַפּלייז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// קאָנווערט אַ רוי טייַטל פריער באשאפן דורך קס 01 קס צוריק אין קס 00 קס.
    ///
    /// דעם קענען ווערן גענוצט צו באַקומען אַ שטאַרק רעפֿערענץ (דורך רופן [`upgrade`] שפּעטער) אָדער צו האַנדלען מיט די שוואַך ציילן דורך דראַפּינג די `Weak<T>`.
    ///
    /// עס נעמט אָונערשיפּ פון איין שוואַך רעפֿערענץ (מיט די ויסנעם פון פּוינטערז באשאפן דורך קס 00 קס, ווייַל די טאָן ניט פאַרמאָגן עפּעס; דער אופֿן נאָך אַרבעט אויף זיי).
    ///
    /// # Safety
    ///
    /// דער טייַטל מוזן האָבן ערידזשאַנייטאַד פֿון די [`into_raw`] און נאָך זיין פּאָטענציעל שוואַך דערמאָנען.
    ///
    /// דער שטאַרק ציילן איז דערלויבט צו זיין 0 אין דער צייט פון רופן דעם.
    /// פונדעסטוועגן, דאָס נעמט אָונערשיפּ פון איין שוואַך רעפֿערענץ דערווייַל רעפּריזענטיד ווי אַ רוי טייַטל (די שוואַך ציילן איז נישט מאַדאַפייד דורך די אָפּעראַציע) און דעריבער עס מוזן זיין פּערד מיט אַ פריערדיקן רוף צו [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // דעקרעמענט די לעצטע שוואַך ציילן.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // זען קס 00 קס פֿאַר קאָנטעקסט וועגן ווי דער ינפּוט טייַטל איז דערייווד.

        let ptr = if is_dangling(ptr as *mut T) {
            // דאָס איז אַ דאַנגגלינג וויק.
            ptr as *mut ArcInner<T>
        } else {
            // אַנדערש, מיר 'רע געראַנטיד די טייַטל געקומען פֿון אַ נאַנדאַנגלינג שוואַך.
            // זיכערקייט: דאַטאַ_אָפסעט איז זיכער צו רופן, ווייַל פּטר באַווייַזן אַ פאַקטיש (פּאַטענטשאַלי דראַפּט) טי.
            let offset = unsafe { data_offset(ptr) };
            // אַזוי, מיר פאַרקערט די פאָטאָ צו באַקומען די גאַנץ רקבאָקס.
            // זיכערקייט: דער טייַטל ערידזשאַנייטאַד פון אַ וויק, אַזוי דעם פאָטאָ איז זיכער.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // זיכערקייט: מיר האָבן איצט ריקאַווערד דער אָריגינעל וויק טייַטל, אַזוי קענען מאַכן די וויק.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// פרווון צו אַפּגרייד די קס 01 קס טייַטל צו אַ קס 00 קס, פאַרהאַלטן דראַפּינג די ינער ווערט אויב געראָטן.
    ///
    ///
    /// קערט [`None`] אויב די ינער ווערט האט שוין דראַפּט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // צעשטערן אַלע שטאַרק פּוינטערז.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // מיר נוצן אַ CAS שלייף צו ינקרעמענט די שטאַרק ציילן אַנשטאָט פון אַ פעטטש_אַדד ווייַל די פֿונקציע זאָל קיינמאָל נעמען די רעפֿערענץ ציילן פון נול צו איינער.
        //
        //
        let inner = self.inner()?;

        // רילאַקסט מאַסע ווייַל קיין 0 אַז מיר קענען אָבסערווירן, לאָזן די פעלד אין אַ פּערמאַנאַנטלי נול שטאַט (אַזוי אַ "stale" לייענען פון 0 איז פייַן), און קיין אנדערע ווערט איז באשטעטיקט דורך די CAS אונטן.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // זען באַמערקונגען אין קס 00 קס פֿאַר וואָס מיר טאָן דאָס (פֿאַר קס 01 קס).
            if n > MAX_REFCOUNT {
                abort();
            }

            // רילאַקסעד איז פייַן פֿאַר די דורכפאַל פאַל ווייַל מיר טאָן ניט האָבן קיין עקספּעקטיישאַנז וועגן די נייַ שטאַט.
            // קריגן איז נויטיק פֿאַר די הצלחה פאַל צו סינגקראַנייז מיט `Arc::new_cyclic`, ווען די ינער ווערט קענען זיין ינישיייטיד נאָך `Weak` באַווייַזן זענען שוין באשאפן.
            // אין דעם פאַל, מיר דערוואַרטן די פול יניטיאַליזעד ווערט.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // נול אָפּגעשטעלט אויבן
                Err(old) => n = old,
            }
        }
    }

    /// געץ די נומער פון שטאַרק (`Arc`) פּוינטערז וואָס ווייַזן די אַלאַקיישאַן.
    ///
    /// אויב קס 01 קס איז באשאפן מיט קס 00 קס, דאָס וועט צוריקקומען 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// געץ אַן אַפּראַקסאַמיישאַן פון די נומער פון קסקסנומקס קס פּוינטערז צו די אַלאַקיישאַן.
    ///
    /// אויב קס 01 קס איז באשאפן מיט קס 00 קס, אָדער אויב עס זענען קיין רוען שטאַרק פּוינטערז, דאָס וועט צוריקקומען 0.
    ///
    /// # Accuracy
    ///
    /// רעכט צו ימפּלאַמענטיישאַן דעטאַילס, די אומגעקערט ווערט קענען זיין אַוועק מיט 1 אין יעדער ריכטונג ווען אנדערע פֿעדעם מאַניפּיאַלייץ קיין אַרק אָדער וויק צו דער זעלביקער אַלאַקיישאַן.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // זינט מיר באמערקט אַז עס איז געווען לפּחות איין שטאַרק טייַטל נאָך לייענען די שוואַך ציילן, מיר וויסן אַז די ימפּליסאַט שוואַך רעפֿערענץ (פאָרשטעלן ווען קיין שטאַרק באַווייַזן זענען לעבעדיק) איז געווען נאָך אַרום ווען מיר באמערקט די שוואַך ציילן, און קענען דעריבער בעשאָלעם אַראָפּרעכענען עס.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// קערט `None` ווען דער טייַטל איז דאַנגגלינג און עס איז קיין אַלאַקייטיד `ArcInner`, (ד"ה ווען `Weak` איז באשאפן דורך `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // מיר זענען אָפּגעהיט צו *נישט* מאַכן אַ רעפֿערענץ וואָס קאַווערד די "data" פעלד, ווייַל די פעלד קען זיין מיוטייטיד קאַנקעראַנטלי (פֿאַר בייַשפּיל, אויב די לעצטע `Arc` איז דראַפּט, די דאַטן פעלד וועט זיין דראַפּט אין פּלאַץ).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// קערט `true` אויב די צוויי `שוואַך` ווייַזן צו דער זעלביקער אַלאַקיישאַן (ענלעך צו [`ptr::eq`]), אָדער אויב ביידע טאָן ניט ווייַזן קיין אַלאַקיישאַן (ווייַל זיי זענען באשאפן מיט `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// זינט דעם קאַמפּערד פּוינטערז, עס מיטל אַז `Weak::new()` וועט זיין גלייַך יעדער אנדערע, כאָטש זיי טאָן ניט אָנווייַזן קיין אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// קאַמפּערינג קס 00 קס.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// מאכט אַ קלאָון פון די קס 00 קס טייַטל וואָס ווייזט צו דער זעלביקער אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // זען באַמערקונגען אין Arc::clone() פֿאַר וואָס דאָס איז רילאַקסט.
        // דעם קענען נוצן אַ פעטטש_אַדד (יגנאָרינג די שלאָס) ווייַל די שוואַך ציילן איז בלויז פארשפארט ווו עס זענען *קיין אנדערע* שוואַך פּוינטערז.
        //
        // (אַזוי מיר קענען נישט לויפן דעם קאָד אין דעם פאַל).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // זען באַמערקונגען אין קס 00 קס פֿאַר וואָס מיר טאָן דאָס (פֿאַר קס 01 קס).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// בויען אַ נייַ קס 00 קס אָן אַלאַקייטינג זכּרון.
    /// רופן קס 01 קס אויף די צוריקקומען ווערט שטענדיק גיט קס 00 קס.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// דראָפּס די קס 00 קס טייַטל.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // טוט נישט דרוקן עפּעס
    /// drop(foo);        // פּרינץ קס 00 קס
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // אויב מיר געפֿינען זיך אַז מיר זענען די לעצטע שוואַך טייַטל, עס איז צייט צו האַנדלען די דאַטן לעגאַמרע.זען די דיסקוסיע אין Arc::drop() וועגן די זכּרון אָרדערס
        //
        // עס איז ניט נייטיק צו קאָנטראָלירן פֿאַר די פארשפארט שטאַט דאָ, ווייַל די שוואַך ציילן קען נאָר זיין פארשפארט אויב עס איז געווען פּונקט איין שוואַך רעף, וואָס טייַטש אַז פאַלן קען נאָר דערנאָך לויפן אויף די רוען שוואַך רעף, וואָס קען נאָר פּאַסירן נאָך די שלאָס איז באפרייט.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// מיר טאָן דעם ספּעשאַלאַזיישאַן דאָ, און נישט ווי אַ מער אַלגעמיין אַפּטאַמאַזיישאַן אויף קסקסנומקסקס, ווייַל עס וואָלט אַנדערש לייגן אַ קאָסטן פֿאַר אַלע גלייך טשעקס אויף רעפס.
/// מיר יבערנעמען אַז `Arc`s זענען געניצט צו קראָם גרויס וואַלועס, וואָס זענען פּאַמעלעך צו קלאָון, אָבער אויך שווער צו קאָנטראָלירן פֿאַר יקוואַלאַטי, וואָס קען קאָסטן זיך גרינגער צו באַצאָלן.
///
/// עס איז אויך מער מסתּמא צו האָבן צוויי `Arc` קלאָונז, וואָס פונט צו די זעלבע ווערט, ווי צוויי `&T`s.
///
/// מיר קענען בלויז טאָן דאָס ווען `T: Eq` ווי אַ `PartialEq` קען זיין דיליבראַטלי יררעפלעקסיווע.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// יקוואַלאַטי פֿאַר צוויי `אַרק`ס.
    ///
    /// צוויי `Arc`s זענען גלייַך אויב זייער ינער וואַלועס זענען גלייַך, אפילו אויב זיי זענען סטאָרד אין פאַרשידענע אַלאַקיישאַן.
    ///
    /// אויב קס 00 קס אויך ימפּלאַמאַנץ קס 01 קס (ימפּלייינג ריפלעקסיוויטי פון יקוואַלאַטי), צוויי `אַרק`ס וואָס ווייַזן צו דער זעלביקער אַלאַקיישאַן זענען שטענדיק גלייַך.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// יניקוואַלאַטי פֿאַר צוויי `אַרק`ס.
    ///
    /// צוויי `Arc`s זענען אַניקוואַל אויב זייער ינער וואַלועס זענען אַניקוואַל.
    ///
    /// אויב `T` אויך ימפּלאַמענט `Eq` (ימפּלייינג ריפלעקסיוויטי פון יקוואַלאַטי), צוויי `Arc`s וואָס ווייַזן צו דער זעלביקער ווערט זענען קיינמאָל אַניקוואַל.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// פּאַרטיייש פאַרגלייַך פֿאַר צוויי `Arc`s.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `partial_cmp()` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ווייניקער ווי פאַרגלייַך פֿאַר צוויי `Arc`s.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `<` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// ווייניקער ווי אָדער גלייַך צו פאַרגלייַך פֿאַר צוויי Arc's.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `<=` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// גרעסער-ווי פאַרגלייַך פֿאַר צוויי `Arc`s.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `>` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'גרעסער ווי אָדער גלייַך צו' פאַרגלייַך פֿאַר צוויי 'Arc's.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `>=` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// פאַרגלייַך פֿאַר צוויי `Arc`s.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `cmp()` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// קרעאַטעס אַ נייַ קס 01 קס, מיט די קס 02 קס ווערט פֿאַר קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// אַלאַקייט אַ רעפטל-גערעכנט רעפטל און פּלאָמבירן עס דורך קלאָונינג 'V' ס ייטאַמז.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// אַלאַקייט אַ `str` רעפֿערענץ-קאַונטעד און קאָפּיע `v` אין עס.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// אַלאַקייט אַ `str` רעפֿערענץ-קאַונטעד און קאָפּיע `v` אין עס.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// מאַך אַ באַקסיד כייפעץ צו אַ נייַע רעפערענץ-קאַונטעד אַלאַקיישאַן.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// אַלאַקייט אַ רעפטל-גערעכנט רעפטל און מאַך עס 'V` ס ייטאַמז.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // לאָזן די Vec באַפרייַען זיין זכּרון, אָבער נישט צעשטערן די אינהאַלט
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// נעמט יעדער עלעמענט אין די קס 01 קס און קאַלעקץ עס אין אַ קס 00 קס.
    ///
    /// # פאָרשטעלונג קעראַקטעריסטיקס
    ///
    /// ## דער גענעראַל פאַל
    ///
    /// אין אַלגעמיין, קאַלעקטינג אין קס 01 קס איז דורכגעקאָכט דורך ערשטער קאַלעקטינג אין אַ קס 00 קס.דאָס איז, ווען שרייבן די פאלגענדע:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// דאָס ביכייווז ווי אויב מיר געשריבן:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // דער ערשטער שטעלן פון אַלאַקיישאַנז כאַפּאַנז דאָ.
    ///     .into(); // דאָ כאַפּאַנז אַ רגע אַלאַקיישאַן פֿאַר `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// דער קונה וועט זיין מאַנידזשיז ווי פילע מאָל ווי איר דאַרפֿן צו בויען די `Vec<T>`, און דערנאָך עס וועט זיין אַלאַקייטיד אַמאָל פֿאַר די `Vec<T>` אין די `Arc<[T]>`.
    ///
    ///
    /// ## יטאַטאָרס פון באַוווסט לענג
    ///
    /// ווען דיין `Iterator` ימפּלאַמאַנץ `TrustedLen` און איז פון אַ פּינטלעך גרייס, עס וועט זיין אַ איין אַלאַקיישאַן פֿאַר די `Arc<[T]>`.צום ביישפיל:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // נאָר אַ איין אַלאַקיישאַן כאַפּאַנז דאָ.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// ספּעשאַלאַזיישאַן trait געניצט פֿאַר קאַלעקטינג אין `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // דאָס איז דער פאַל פֿאַר אַ `TrustedLen` יטעראַטאָר.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // זיכערקייט: מיר דאַרפֿן צו ענשור אַז די יטעראַטאָר האט אַן פּינטלעך לענג און מיר האָבן.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // פאַלן צוריק צו נאָרמאַל ימפּלאַמענטיישאַן.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// באַקומען די פאָטאָ אין אַן `ArcInner` פֿאַר די פּיילאָוד הינטער אַ טייַטל.
///
/// # Safety
///
/// דער טייַטל דאַרף אָנווייַזן (און האָבן גילטיק מעטאַדאַטאַ פֿאַר) אַ פריער גילטיק בייַשפּיל פון T, אָבער די T איז ערלויבט צו פאַלן.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // אַליינ די אַנסייזד ווערט צו די סוף פון די ArcInner.
    // ווייַל RBBox איז repr(C), עס וועט שטענדיק זיין די לעצטע פעלד אין זכּרון.
    // זיכערקייט: זינט די בלויז ונסיזעד טייפּס זענען סלייסאַז, trait אַבדזשעקץ,
    // און עקסטערן טייפּס, די ינפּוט זיכערקייַט פאָדערונג איז איצט גענוג צו באַפרידיקן די רעקווירעמענץ פון align_of_val_raw;דאָס איז אַן ימפּלאַמענטיישאַן דעטאַל פון די שפּראַך וואָס קען ניט זיין רילייד אויף אַרויס פון std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}