//! די אַלאַקייט Prelude
//!
//! דער ציל פון דעם מאָדולע איז צו באַפרייַען די ימפּאָרץ פון קאַמאַנלי געוויינט ייטאַמז פון די `alloc` crate דורך אַ גלאבאלע ימפּאָרט צו די שפּיץ פון מאַדזשולז:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;