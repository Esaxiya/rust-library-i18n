//! איין-טרעדיד רעפֿערענץ-קאַונטינג פּוינטערז.קס 00 קס שטייט פֿאַר 'רעפערענץ
//! Counted'.
//!
//! דער טיפּ קס 01 קס גיט שערד אָונערשיפּ פון אַ ווערט פון טיפּ קס 00 קס, אַלאַקייטיד אין די קופּע.
//! ינוואָוקינג קס 00 קס אויף קס 01 קס טראגט אַ נייַ טייַטל צו דער זעלביקער אַלאַקיישאַן אין די קופּע.
//! ווען די לעצטע [`Rc`] טייַטל צו אַ געגעבן אַלאַקיישאַן איז חרובֿ, די ווערט סטאָרד אין די אַלאַקיישאַן (אָפט ריפערד צו ווי "inner value") איז אויך דראַפּט.
//!
//! שערד באַווייַזן אין Rust אָפּזאָגן מיוטיישאַן דורך פעליקייַט, און [`Rc`] איז ניט ויסנעם: איר קענט בכלל נישט באַקומען אַ מיוטאַבאַל באַווייַזן צו עפּעס אין אַן [`Rc`].
//! אויב איר דאַרפֿן מיוטאַביליטי, שטעלן אַ קס 02 קס אָדער קס 03 קס ין די קס 01 קס;זען קס 00 קס.
//!
//! [`Rc`] ניצט ניט-אַטאָמישע רעפֿערענץ קאַונטינג.
//! דעם מיטל אַז אָוווערכעד איז זייער נידעריק, אָבער אַ [`Rc`] קענען ניט זיין געשיקט צווישן פֿעדעם, און דעריבער [`Rc`] קען נישט ינסטרומענט [`Send`][send].
//! דער רעזולטאַט, די Rust קאַמפּיילער וועט קאָנטראָלירן *אין זאַמלען צייט* אַז איר טאָן ניט שיקן [`רק`] s צווישן פֿעדעם.
//! אויב איר דאַרפֿן קאַונטינג מיט עטלעכע טרעדיד אַטאָמישע באַווייַזן, נוצן [`sync::Arc`][arc].
//!
//! די [`downgrade`][downgrade] אופֿן קענען ווערן גענוצט צו שאַפֿן אַ ניט-אָונינג [`Weak`] טייַטל.
//! א קס 01 קס טייַטל קענען זיין [`אַפּגרייד`][אַפּגרייד] ד צו אַ קס 00 קס, אָבער דאָס וועט צוריקקומען קס 02 קס אויב די ווערט סטאָרד אין די אַלאַקיישאַן איז שוין דראַפּט.
//! אין אנדערע ווערטער, קסקסנומקס קס פּוינטערז טאָן ניט האַלטן די ווערט ין די אַלאַקיישאַן לעבעדיק;אָבער, זיי *טאָן* האַלטן די אַלאַקיישאַן (די באַקינג קראָם פֿאַר די ינער ווערט) לעבעדיק.
//!
//! א ציקל צווישן קסקסנומקס קס פּוינטערז וועט קיינמאָל זיין דילאַלאַקייטיד.
//! פֿאַר דעם סיבה, [`Weak`] איז געניצט צו ברעכן סייקאַלז.
//! למשל, אַ בוים קען האָבן שטאַרק קס 00 קס פּוינטערז פֿון פאָטער נאָודז צו קינדער, און קס 01 קס פּוינטערז פֿון קינדער צוריק צו זייער עלטערן.
//!
//! `Rc<T>` אויטאָמאַטיש דערפערענסעס צו קס 01 קס (דורך די קס 02 קס ז 0 טראַט 0 ז), אַזוי איר קענען רופן די מעטהאָדס פון 'ט' אויף אַ ווערט פון טיפּ קס 00 קס.
//! צו ויסמיידן די קלאַשיז פון די מעטהאָדס מיט די מעטהאָדס, די מעטהאָדס פון קס 01 קס זיך זענען פארבונדן פאַנגקשאַנז, גערופֿן ניצן קס 00 קס:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! Rc<T>די ימפּלאַמענטיישאַנז פון traits ווי `Clone` קען אויך זיין גערופֿן מיט גאָר קוואַלאַפייד סינטאַקס.
//! עטלעכע מענטשן בעסער וועלן צו נוצן גאָר קוואַלאַפייד סינטאַקס, אנדערע נוצן מעטהאָדס-רופן סינטאַקס.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // אופֿן-רופן סינטאַקס
//! let rc2 = rc.clone();
//! // גאָר קוואַלאַפייד סינטאַקס
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] קען נישט אַוטאָ-דערפעראַנס צו `T` ווייַל די ינער ווערט קען זיין שוין דראַפּט.
//!
//! # קלאָונינג באַווייַזן
//!
//! קרעאַטינג אַ נייַע דערמאָנען צו דער זעלביקער אַלאַקיישאַן ווי אַ יגזיסטינג רעפֿערענץ גערעכנט טייַטל איז געשען מיט די `Clone` trait ימפּלאַמענאַד פֿאַר [`Rc<T>`][`Rc`] און [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // די צוויי סינטאַקסיז ונטער זענען עקוויוואַלענט.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a און b ביידע ווייַזן צו דער זעלביקער זכּרון אָרט ווי פאָאָ.
//! ```
//!
//! די קס 00 קס סינטאַקס איז די מערסט ידיאָמאַטיק ווייַל עס קאַנווייז מער בפירוש די טייַטש פון די קאָד.
//! אין דעם בייַשפּיל אויבן, דעם סינטאַקס מאכט עס גרינגער צו זען אַז דעם קאָד איז קריייטינג אַ נייַע רעפֿערענץ אלא ווי קאַפּיינג די גאנצע אינהאַלט פון פאָאָ.
//!
//! # Examples
//!
//! באַטראַכטן אַ סצענאַר וווּ אַ גאַנג פון 'האַמצאָע' ס אָונד דורך אַ געגעבן `Owner`.
//! מיר וועלן האָבן אונדזער 'האַמצאָע' ס פונט צו זייער קס 01 קס.מיר קענען ניט טאָן דאָס מיט יינציק אָונערשיפּ, ווייַל מער ווי איין האַמצאָע קען געהערן צו דער זעלביקער קס 00 קס.
//! [`Rc`] אַלאַוז אונדז צו טיילן אַן `Owner` צווישן קייפל `האַמצאָע`ס, און די `Owner` בלייַבן אַלאַקייטיד ווי לאַנג ווי קיין `Gadget` ווייזט אויף אים.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... אנדערע פעלדער
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... אנדערע פעלדער
//! }
//!
//! fn main() {
//!     // שאַפֿן אַ `Owner` רעפערענץ.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // שאַפֿן 'האַמצאָע' ס בילאָנגינג צו קס 00 קס.
//!     // קלאָונינג די `Rc<Owner>` גיט אונדז אַ נייַע טייַטל צו דער זעלביקער `Owner` אַלאַקיישאַן, ינקרימענדינג די רעפֿערענץ ציילן אין דעם פּראָצעס.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // באַזייַטיקן אונדזער היגע בייַטעוודיק קס 00 קס.
//!     drop(gadget_owner);
//!
//!     // טראָץ דראַפּינג `gadget_owner`, מיר נאָך קענען צו דרוקן די נאָמען `Owner` פון די `Gadget`s.
//!     // דאָס איז ווייַל מיר נאָר דראַפּט אַ איין `Rc<Owner>`, נישט די `Owner` עס ווייזט צו.
//!     // ווי לאַנג ווי עס זענען אנדערע `Rc<Owner>` ווייזונג אויף דער זעלביקער `Owner` אַלאַקיישאַן, עס וועט בלייבן לעבן.
//!     // די פעלד פּרויעקציע קס 01 קס אַרבעט ווייַל קס 02 קס אויטאָמאַטיש דערפערענסעס צו קס 00 קס.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // אין די סוף פון די פונקציע, `gadget1` און `gadget2` זענען חרובֿ, און מיט זיי די לעצטע גערעכנט באַווייַזן צו אונדזער `Owner`.
//!     // האַמצאָע מענטש איצט אויך צעשטערט.
//!     //
//! }
//! ```
//!
//! אויב אונדזער באדערפענישן טוישן און מיר דאַרפֿן צו קענען צו פאָרן פון קס 01 קס צו קס 00 קס, מיר וועלן באַקומען פּראָבלעמס.
//! אַ קס 00 קס טייַטל פון קס 01 קס צו קס 02 קס ינטראַדוסיז אַ ציקל.
//! דעם מיטל אַז זייער רעפֿערענץ קאַונץ קענען קיינמאָל דערגרייכן 0, און די אַלאַקיישאַן וועט קיינמאָל זיין חרובֿ:
//! אַ זכּרון רינען.צו דערגרייכן דעם, מיר קענען נוצן [`Weak`] פּוינטערז.
//!
//! ז 0 רוסט 0 ז אַקשלי מאכט עס עפּעס שווער צו פּראָדוצירן דעם שלייף אין דער ערשטער אָרט.צו ענדיקן צוויי וואַלועס וואָס ווייַזן יעדער אנדערע, איינער פון זיי דאַרף זיין מיוטאַבאַל.
//! דאָס איז שווער ווייַל [`Rc`] ענפאָרסאַז זכּרון זיכערקייַט דורך בלויז געבן שערד באַווייַזן צו די ווערט עס ראַפּס, און די טאָן ניט לאָזן דירעקט מיוטיישאַן.
//! מיר דאַרפֿן צו ייַנוויקלען דעם טייל פון די ווערט וואָס מיר וועלן צו מיוטייט אין אַ [`RefCell`], וואָס גיט *ינלענדיש מיוטאַביליטי*: אַ מעטאָד צו דערגרייכן מיוטאַביליטי דורך אַ שערד רעפֿערענץ.
//! [`RefCell`] ענפאָרסאַז די באַראָוינג כּללים פון Rust אין רונטימע.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... אנדערע פעלדער
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... אנדערע פעלדער
//! }
//!
//! fn main() {
//!     // שאַפֿן אַ `Owner` רעפערענץ.
//!     // באַמערקונג אַז מיר האָבן שטעלן די vector פון די 'באַזיצער' פון 'האַמצאָע' אין אַ קס 00 קס אַזוי אַז מיר קענען מיוטייט עס דורך אַ שערד רעפֿערענץ.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // שאַפֿן ווי פריערדיק 'האַמצאָע' פון `gadget_owner`.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // לייג די `האַמצאָע`ס צו זייער `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` דינאַמיש באָרגן ענדס דאָ.
//!     }
//!
//!     // יטעראַטע איבער אונדזער `האַמצאָע`ס און דרוקן זייער דעטאַילס.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` איז אַ קס 00 קס.
//!         // זינט `Weak` פּוינטערז קענען נישט גאַראַנטירן די אַלאַקיישאַן נאָך יגזיסץ, מיר דאַרפֿן צו רופן `upgrade`, וואָס קערט אַן `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // אין דעם פאַל, מיר וויסן די אַלאַקיישאַן נאָך יגזיסץ, אַזוי מיר נאָר קס 01 קס די קס 00 קס.
//!         // אין אַ מער קאָמפּליצירט פּראָגראַם, איר דאַרפֿן אַ גראַציעז טעות האַנדלינג פֿאַר אַ `None` רעזולטאַט.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // אין די סוף פון די פונקציע, `gadget_owner`, `gadget1` און `gadget2` זענען חרובֿ.
//!     // עס זענען איצט קיין שטאַרק אַקסנומקס קס פּוינטערז צו די גאַדזשאַץ, אַזוי זיי זענען חרובֿ.
//!     // דאָס זעראָעס דער רעפֿערענץ ציילן אויף האַמצאָע מענטש, אַזוי ער געץ חרובֿ ווי געזונט.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// דאָס איז repr(C) צו future-proof קעגן מעגלעך פעלד-ריאָרדערינג, וואָס וואָלט אַרייַנמישנ זיך מיט אַנדערש [into|from]_raw() פון טראַנסמוטאַבלע ינער טייפּס.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// א איין-טרעדיד דערמאָנען-קאַונטינג טייַטל.קס 00 קס שטייט פֿאַר 'רעפערענץ
/// Counted'.
///
/// זען די [module-level documentation](./index.html) פֿאַר מער דעטאַילס.
///
/// די טאָכיק מעטהאָדס פון קס 02 קס זענען אַלע פֿאַרבונדן פאַנגקשאַנז, וואָס מיטל אַז איר האָבן צו רופן זיי ווי למשל, קס 01 קס אַנשטאָט פון קס 00 קס.
/// דעם אַוווידז קאָנפליקט מיט מעטהאָדס פון די ינער טיפּ קסקסנומקס.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // די אַנסאַפעטי איז גוט ווייַל די RC איז לעבעדיק, מיר געראַנטיד אַז די ינער טייַטל איז גילטיק.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// קאַנסטראַקץ אַ נייַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // עס איז אַ ימפּליסאַט שוואַך טייַטל אָונד דורך אַלע די שטאַרק פּוינטערז, וואָס ינשורז אַז די שוואַך דעסטרוקטאָר קיינמאָל פריי די אַלאַקיישאַן בשעת די שטאַרק דעסטרוקטאָר איז פליסנדיק, אפילו אויב די שוואַך טייַטל איז סטאָרד אין די שטאַרק.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// בויען אַ נייַע קס 00 קס ניצן אַ שוואַך דערמאָנען צו זיך.
    /// פּרווון צו אַפּגרייד די שוואַך רעפֿערענץ איידער די פֿונקציע קערט וועט רעזולטאַט אין אַ `None` ווערט.
    ///
    /// די שוואַך רעפֿערענץ קען זיין קלאָונד פרילי און סטאָרד פֿאַר נוצן אין אַ שפּעטער צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... מער פעלדער
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // בויען די ינער אין די "uninitialized" שטאַט מיט אַ שוואַך דערמאָנען.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // עס איז וויכטיק מיר טאָן ניט געבן אַרויף אָונערשיפּ פון די שוואַך טייַטל, אַנדערש די זכּרון קען זיין באפרייט ווען `data_fn` קערט.
        // אויב מיר טאַקע געוואלט צו פאָרן אָונערשיפּ, מיר קענען מאַכן אַן נאָך שוואַך טייַטל פֿאַר זיך, אָבער דאָס וואָלט רעזולטאַט אין נאָך דערהייַנטיקונגען צו די שוואַך רעפֿערענץ ציילן וואָס אַנדערש קען נישט זיין נויטיק.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // שטאַרק רעפערענצן זאָל קאַלעקטיוולי האָבן אַ שערד שוואַך רעפֿערענץ, אַזוי טאָן ניט פירן דעם דעסטרוקטאָר פֿאַר אונדזער אַלט שוואַך רעפֿערענץ.
        //
        mem::forget(weak);
        strong
    }

    /// בויען אַ נייַע קס 00 קס מיט אַנינישיייטיד אינהאַלט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// קאָנסטרוקץ אַ נייַ קס 00 קס מיט אַנינישיייטיד אינהאַלט, מיט די זיקאָרן אָנגעפילט מיט קס 01 קס ביטעס.
    ///
    ///
    /// זען קס 00 קס פֿאַר ביישפילן פון ריכטיק און פאַלש באַניץ פון דעם אופֿן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// קאַנסטראַקץ אַ נייַע קס 00 קס, און אומגעקערט אַ טעות אויב די אַלאַקיישאַן פיילז
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // עס איז אַ ימפּליסאַט שוואַך טייַטל אָונד דורך אַלע די שטאַרק פּוינטערז, וואָס ינשורז אַז די שוואַך דעסטרוקטאָר קיינמאָל פריי די אַלאַקיישאַן בשעת די שטאַרק דעסטרוקטאָר איז פליסנדיק, אפילו אויב די שוואַך טייַטל איז סטאָרד אין די שטאַרק.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// בויען אַ נייַע קס 00 קס מיט אַניניטיאַליזעד אינהאַלט, און אומגעקערט אַ טעות אויב די אַלאַקיישאַן פיילז
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// קאַנסטראַקץ אַ נייַע קס 00 קס מיט אַנינישיייטיד אינהאַלט, מיט די זיקאָרן אָנגעפילט מיט קס 01 קס ביטעס, קערט אַ טעות אויב די אַלאַקיישאַן פיילז
    ///
    ///
    /// זען קס 00 קס פֿאַר ביישפילן פון ריכטיק און פאַלש באַניץ פון דעם אופֿן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// קאַנסטראַקץ אַ נייַ קס 00 קס.
    /// אויב קס 01 קס טוט נישט ינסטרומענט קס 00 קס, קס 02 קס וועט זיין פּיננעד אין זכּרון און קען ניט זיין אריבערגעפארן.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// קערט די ינער ווערט אויב די `Rc` האט פּונקט איין שטאַרק דערמאָנען.
    ///
    /// אַנדערש, אַ [`Err`] איז אומגעקערט מיט די זעלבע `Rc` וואָס איז דורכגעגאנגען.
    ///
    ///
    /// דאָס וועט זיין געראָטן אפילו אויב עס זענען בוילעט שוואַך באַווייַזן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // נאָכמאַכן די קאַנטיינד כייפעץ

                // אָנווייַזן צו וויקס אַז זיי קענען ניט זיין פּראָמאָטעד דורך דיקרימאַנינג די שטאַרק ציילן, און דאַן באַזייַטיקן די ימפּליסאַט קקסנומקס קס טייַטל בשעת האַנדלינג פאַלן קאַפּ לאָגיק דורך פּונקט קראַפטינג אַ שווינדל וויק.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// קאַנסטראַקץ אַ נייַ רעפֿערענץ-קאַונטעד רעפטל מיט אַנינישאַנאַלייזד אינהאַלט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// קאַנסטראַקץ אַ נייַ רעפֿערענץ-קאַונטעד רעפטל מיט אַנינישיייטיד אינהאַלט, מיט די זכּרון אָנגעפילט מיט קס 00 קס ביטעס.
    ///
    ///
    /// זען קס 00 קס פֿאַר ביישפילן פון ריכטיק און פאַלש באַניץ פון דעם אופֿן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// קאָנווערץ צו קס 00 קס.
    ///
    /// # Safety
    ///
    /// ווי מיט [`MaybeUninit::assume_init`], עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די ינער ווערט טאַקע איז אין אַן ינישאַלייזד שטאַט.
    ///
    /// רופן דעם ווען די אינהאַלט איז נישט נאָך ינישיייטיד ז גלייך אַנדיפיינד נאַטור.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// קאָנווערץ צו קס 00 קס.
    ///
    /// # Safety
    ///
    /// ווי מיט [`MaybeUninit::assume_init`], עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די ינער ווערט טאַקע איז אין אַן ינישאַלייזד שטאַט.
    ///
    /// רופן דעם ווען די אינהאַלט איז נישט נאָך ינישיייטיד ז גלייך אַנדיפיינד נאַטור.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // דיפערד יניטיאַליזאַטיאָן:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// קאַנסומז די `Rc` און אומגעקערט די אלנגעוויקלט טייַטל.
    ///
    /// צו ויסמיידן אַ זיקאָרן רינען, די טייַטל מוזן זיין קאָנווערטעד צוריק צו אַ `Rc` ניצן [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// גיט אַ רוי טייַטל צו די דאַטן.
    ///
    /// די קאַונץ זענען נישט אַפעקטאַד אין קיין וועג און די `Rc` איז נישט קאַנסומד.
    /// דער טייַטל איז גילטיק אַזוי לאַנג ווי עס זענען שטאַרק קאַונץ אין די `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // זיכערקייט: דאָס קען נישט דורכגיין Deref::deref אָדער Rc::inner ווייַל
        // דאָס איז פארלאנגט צו האַלטן raw/mut פּראָווענאַנסע אַזאַ ווי למשל
        // `get_mut` קענען שרייַבן דורך די טייַטל נאָך די Rc איז ריקאַווערד דורך `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// בויען אַ `Rc<T>` פֿון אַ רוי טייַטל.
    ///
    /// די רוי טייַטל מוזן האָבן שוין ביז אַהער אומגעקערט דורך אַ רוף צו קס 01 קס, ווו קס 02 קס מוזן האָבן די זעלבע גרייס און אַליינמאַנט ווי קס 00 קס.
    /// דאָס איז נישטיק אויב `U` איז `T`.
    /// באַמערקונג אַז אויב `U` איז נישט `T` אָבער די זעלבע גרייס און אַליינמאַנט, דאָס איז בייסיקלי ווי טראַנסמוטטינג באַווייַזן פון פאַרשידענע טייפּס.
    /// זען [`mem::transmute`][transmute] פֿאַר מער אינפֿאָרמאַציע וועגן וואָס ריסטריקשאַנז זענען גילטיק אין דעם פאַל.
    ///
    /// דער באַניצער פון `from_raw` מוזן מאַכן זיכער אַז אַ ספּעציפֿיש ווערט פון `T` איז נאָר דראַפּט אַמאָל.
    ///
    /// די פֿונקציע איז אַנסייף ווייַל די ימפּראַפּער נוצן קען פירן צו אַנסייפע פון זכּרון, אפילו אויב די `Rc<T>` איז קיינמאָל אַקסעסט.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // גער צוריק צו אַן `Rc` צו פאַרמייַדן רינען.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ווייַטער רופט צו קס 00 קס וואָלט זיין זכּרון-אַנסייף.
    /// }
    ///
    /// // דער זכּרון איז באפרייט ווען קס 00 קס איז אויס פון די אויבן אויבן, אַזוי קס 01 קס איז איצט דאַנגגלינג!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // פאַרקערט די אָפסעט צו געפֿינען די אָריגינעל רקבאָקס.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// קרעאַטעס אַ נייַע קס 00 קס טייַטל צו דעם אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // מאַכט זיכער אַז מיר טאָן ניט מאַכן אַ דאַנגגלינג וויק
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// די נומער פון [`Weak`] פּוינטערז צו די אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// די נומער פון שטאַרק אַקסנומקס קס פּוינטערז צו דעם אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// קערט קס 00 קס אויב עס זענען קיין אנדערע קס 01 קס אָדער קס 02 קס פּוינטערז צו דעם אַלאַקיישאַן.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// קערט אַ מיוטאַבאַל רעפֿערענץ אין די געגעבן קס 00 קס, אויב עס זענען קיין אנדערע קס 01 קס אָדער קס 02 קס פּוינטערז צו דער זעלביקער אַלאַקיישאַן.
    ///
    ///
    /// קערט [`None`] אַנדערש ווייַל עס איז ניט זיכער צו מיוטייט אַ שערד ווערט.
    ///
    /// זען אויך [`make_mut`][make_mut], וואָס [`clone`][clone] די ינער ווערט ווען עס זענען אנדערע פּוינטערז.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// קערט אַ מיוטאַבאַל באַווייַזן אין די געגעבן קס 00 קס, אָן קיין טשעק.
    ///
    /// זען אויך [`get_mut`], וואָס איז זיכער און צונעמען טשעקס.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// קיין אנדערע קס 00 קס אָדער קס 01 קס פּוינטערז צו דער זעלביקער אַלאַקיישאַן מוזן ניט זיין דערפערענסט פֿאַר די געדויער פון די אומגעקערט באַראָוד.
    ///
    /// דאָס איז טריוויאַללי דער פאַל אויב עס זענען נישט אַזאַ פּוינטערז, פֿאַר בייַשפּיל גלייך נאָך `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // מיר זענען אָפּגעהיט צו *נישט* מאַכן אַ רעפֿערענץ וואָס קאַווערד די "count" פעלדער, ווייַל דאָס איז קאָנפליקט מיט אַקסעס צו די רעפֿערענץ קאַונץ (למשל
        // דורך `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// קערט `true` אויב די צוויי `Rc`s ווייַזן צו דער זעלביקער אַלאַקיישאַן (אין אַ אָדער ענלעך [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// מאכט אַ מיוטאַבאַל דערמאָנען אין די געגעבן קס 00 קס.
    ///
    /// אויב עס זענען אנדערע `Rc` פּוינטערז צו דער זעלביקער אַלאַקיישאַן, `make_mut` וועט [`clone`] די ינער ווערט צו אַ נייַע אַלאַקיישאַן צו ענשור יינציק אָונערשיפּ.
    /// דאָס איז אויך ריפערד צו ווי קלאָון-אויף-שרייַבן.
    ///
    /// אויב עס זענען קיין אנדערע קס 00 קס פּוינטערז צו דעם אַלאַקיישאַן, די קס 01 קס פּוינטערז צו דעם אַלאַקיישאַן וועט זיין דיסאַסאָוסיייטאַד.
    ///
    /// זען אויך [`get_mut`], וואָס וועט ניט אַנדערש ווי קלאָונינג.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // וועט נישט קלאָון עפּעס
    /// let mut other_data = Rc::clone(&data);    // וועט ניט קלאָון ינער דאַטן
    /// *Rc::make_mut(&mut data) += 1;        // קלאָונז ינער דאַטן
    /// *Rc::make_mut(&mut data) += 1;        // וועט נישט קלאָון עפּעס
    /// *Rc::make_mut(&mut other_data) *= 2;  // וועט נישט קלאָון עפּעס
    ///
    /// // איצט `data` און `other_data` פונט צו פאַרשידענע אַלאַקיישאַנז.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] פּוינטערז וועט זיין דיסאַסאָוסיייטאַד:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // מוזן קלאָון די דאַטן, עס זענען אנדערע RCS.
            // פאַר-אַלאַקייט זיקאָרן צו לאָזן שרייבן די קלאָונד ווערט גלייַך.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // קענען נאָר גאַנווענען די דאַטן, אַלע וואָס איז לינקס איז וויקס
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // אַראָפּנעמען ימפּליסאַט שטאַרק-שוואַך רעף (ניט דאַרפֿן צו מאַכן אַ שווינדל וויק דאָ-מיר וויסן אנדערע וויקס קענען ריין אַרויף פֿאַר אונדז)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // די אַנסאַפעטי איז גוט ווייַל מיר זענען געראַנטיד אַז דער טייַטל וואָס איז אומגעקערט איז די *בלויז* טייַטל וואָס וועט טאָמיד זיין אומגעקערט צו טי.
        // אונדזער רעפֿערענץ ציילן איז געראַנטיד צו זיין 1 אין דעם פונט, און מיר פארלאנגט די `Rc<T>` זיך צו זיין קס 00 קס, אַזוי מיר 'רע אומגעקערט די בלויז מעגלעך דערמאָנען צו די אַלאַקיישאַן.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// פּרווון צו אַראָפּרעכענען די `Rc<dyn Any>` צו אַ באַטאָנען טיפּ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// אַללאָקאַטעס אַ `RcBox<T>` מיט גענוג פּלאַץ פֿאַר אַ ינערייזד ינערלעך ווערט, וואָס די ווערט האט צוגעשטעלט.
    ///
    /// די פונקציע קס 01 קס איז גערופֿן מיט די דאַטן טייַטל און מוזן צוריקקומען אַ (פּאַטענטשאַלי פעט)-ווײַזער פֿאַר די קס 00 קס.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // רעכענען אויסלייג ניצן די געגעבן ווערט אויסלייג.
        // ביז אַהער, די אויסלייג איז געווען קאַלקיאַלייטיד אויף דעם אויסדרוק קס 00 קס, אָבער דאָס באשאפן אַ מיסאַליינד דערמאָנען (זען קס 01 קס).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// אַללאָקאַטעס אַ `RcBox<T>` מיט גענוג פּלאַץ פֿאַר אַ עפשער-אַנסייזד ינער ווערט, וואָס די ווערט האט דער אויסלייג צוגעשטעלט, און אומגעקערט אַ טעות אויב די אַלאַקיישאַן איז אַנדערש.
    ///
    ///
    /// די פונקציע קס 01 קס איז גערופֿן מיט די דאַטן טייַטל און מוזן צוריקקומען אַ (פּאַטענטשאַלי פעט)-ווײַזער פֿאַר די קס 00 קס.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // רעכענען אויסלייג ניצן די געגעבן ווערט אויסלייג.
        // ביז אַהער, די אויסלייג איז געווען קאַלקיאַלייטיד אויף דעם אויסדרוק קס 00 קס, אָבער דאָס באשאפן אַ מיסאַליינד דערמאָנען (זען קס 01 קס).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // אַלאַקייט פֿאַר די אויסלייג.
        let ptr = allocate(layout)?;

        // יניטיאַליזירן די רקבאָקס
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// אַללאָקאַטעס אַ `RcBox<T>` מיט גענוג פּלאַץ פֿאַר אַן אַנסייזד ינער ווערט
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // אַלאַקייט פֿאַר די `RcBox<T>` ניצן די געגעבן ווערט.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // קאָפּיע ווערט ווי ביטעס
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // באַפרייַען די אַלאַקיישאַן אָן דראַפּינג די אינהאַלט
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// אַלאַקייץ אַן `RcBox<[T]>` מיט די געגעבן לענג.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// קאָפּיע עלעמענטן פון רעפטל אין נייַ אַלאַקייטיד רק <\[ה\]>
    ///
    /// אַנסייף ווייַל די קאַללער מוזן נעמען אָונערשיפּ אָדער בינדן `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// בויען אַ `Rc<[T]>` פֿון אַ יטעראַטאָר, וואָס איז באַוווסט צו זיין אַ זיכער גרייס.
    ///
    /// די נאַטור איז אַנדיפיינד אויב די גרייס איז פאַלש.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic היטן בשעת קלאָונינג ה עלעמענטן.
        // אין פאַל פון panic, עלעמענטן וואָס זענען געשריבן אין די נייַ RcBox וועט זיין דראַפּט, און דער זכּרון איז באפרייט.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // טייַטל צו ערשטער עלעמענט
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // כל קלאָר.פאַרגעסן די היטן אַזוי אַז דער נייַע RBBox וועט נישט באַפרייַען.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ספּעשאַלאַזיישאַן ז 0 טראַיט 0 ז געניצט פֿאַר קס 00 קס.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// טראפנס די קס 00 קס.
    ///
    /// דאָס וועט פאַרקלענערן די שטאַרק רעפֿערענץ ציילן.
    /// אויב די שטאַרק רעפֿערענץ ציילן ריטשאַז נול, די בלויז אנדערע באַווייַזן (אויב קיין) זענען [`Weak`], אַזוי מיר זענען `drop` די ינער ווערט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // טוט נישט דרוקן עפּעס
    /// drop(foo2);   // פּרינץ קס 00 קס
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // צעשטערן די קאַנטיינד כייפעץ
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // אַראָפּנעמען די ימפּליסאַט קס 00 קס טייַטל איצט אַז מיר האָבן צעשטערט די אינהאַלט.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// מאכט אַ קלאָון פון די קס 00 קס טייַטל.
    ///
    /// דעם קריייץ אן אנדער טייַטל צו דער זעלביקער אַלאַקיישאַן, ינקריסינג די שטאַרק רעפֿערענץ ציילן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// קרעאַטעס אַ נייַ קס 01 קס, מיט די קס 02 קס ווערט פֿאַר קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// כאַק צו לאָזן ספּעשאַלייזינג אויף קס 00 קס, כאָטש קס 01 קס האט אַ מעטאָד.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// מיר טאָן דעם ספּעשאַלאַזיישאַן דאָ, און נישט ווי אַ מער אַלגעמיין אַפּטאַמאַזיישאַן אויף קסקסנומקסקס, ווייַל עס וואָלט אַנדערש לייגן אַ קאָסטן פֿאַר אַלע גלייך טשעקס אויף רעפס.
/// מיר יבערנעמען אַז `Rc`s זענען געניצט צו קראָם גרויס וואַלועס, וואָס זענען פּאַמעלעך צו קלאָון, אָבער אויך שווער צו קאָנטראָלירן פֿאַר יקוואַלאַטי, קאָזינג דעם קאָסטן צו צאָלן אַוועק גרינגער.
///
/// עס איז אויך מער מסתּמא צו האָבן צוויי `Rc` קלאָונז, וואָס פונט צו די זעלבע ווערט, ווי צוויי `&T`s.
///
/// מיר קענען בלויז טאָן דאָס ווען `T: Eq` ווי אַ `PartialEq` קען זיין דיליבראַטלי יררעפלעקסיווע.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// יקוואַלאַטי פֿאַר צוויי `רק`ס.
    ///
    /// צוויי `רק`ס זענען גלייַך אויב זייער ינער וואַלועס זענען גלייַך, אפילו אויב זיי זענען סטאָרד אין פאַרשידענע אַלאַקיישאַן.
    ///
    /// אויב קס 00 קס אויך ימפּלאַמאַנץ קס 01 קס (ימפּלייז ריפלעקסיוויטי פון יקוואַלאַטי), צוויי `רק`ס וואָס ווייַזן צו דער זעלביקער אַלאַקיישאַן זענען שטענדיק גלייַך.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// יניקוואַלאַטי פֿאַר צוויי `רק`ס.
    ///
    /// צוויי `רק`ס זענען אַניקוואַל אויב זייער ינער וואַלועס זענען אַניקוואַל.
    ///
    /// אויב קס 00 קס אויך ימפּלאַמאַנץ קס 01 קס (ימפּלייינג ריפלעקסיוויטי פון יקוואַלאַטי), צוויי `רק`ס וואָס ווייַזן צו דער זעלביקער אַלאַקיישאַן זענען קיינמאָל אַניקוואַל.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// פּאַרטיייש פאַרגלייַך פֿאַר צוויי `רק`ס.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `partial_cmp()` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ווייניקער-ווי פאַרגלייַך פֿאַר צוויי `רק`ס.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `<` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// ווייניקער ווי אָדער גלייַך צו פאַרגלייַך פֿאַר צוויי RC.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `<=` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// גרעסער-ווי פאַרגלייַך פֿאַר צוויי `רק`ס.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `>` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'גרעסער ווי אָדער גלייַך צו' פאַרגלייַך פֿאַר צוויי 'רק'.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `>=` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// פאַרגלייַך פֿאַר צוויי `רק`ס.
    ///
    /// די צוויי זענען קאַמפּערד דורך רופן `cmp()` אויף זייער ינער וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// אַלאַקייט אַ רעפטל-גערעכנט רעפטל און פּלאָמבירן עס דורך קלאָונינג 'V' ס ייטאַמז.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// אַלאַקייט אַ רעפערענץ-קאַונטעד שטריקל רעפטל און צייכענען `v` אין עס.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// אַלאַקייט אַ רעפערענץ-קאַונטעד שטריקל רעפטל און צייכענען `v` אין עס.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// מאַך אַ באַקסעד כייפעץ צו אַ נייַע, אַלאַקיישאַן.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// אַלאַקייט אַ רעפטל-גערעכנט רעפטל און מאַך עס 'V` ס ייטאַמז.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // לאָזן די Vec באַפרייַען זיין זכּרון, אָבער נישט צעשטערן די אינהאַלט
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// נעמט יעדער עלעמענט אין די קס 01 קס און קאַלעקץ עס אין אַ קס 00 קס.
    ///
    /// # פאָרשטעלונג קעראַקטעריסטיקס
    ///
    /// ## דער גענעראַל פאַל
    ///
    /// אין אַלגעמיין, קאַלעקטינג אין קס 01 קס איז דורכגעקאָכט דורך ערשטער קאַלעקטינג אין אַ קס 00 קס.דאָס איז, ווען שרייבן די פאלגענדע:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// דאָס ביכייווז ווי אויב מיר געשריבן:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // דער ערשטער שטעלן פון אַלאַקיישאַנז כאַפּאַנז דאָ.
    ///     .into(); // דאָ כאַפּאַנז אַ רגע אַלאַקיישאַן פֿאַר `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// דער קונה וועט זיין מאַנידזשיז ווי פילע מאָל ווי איר דאַרפֿן צו בויען די `Vec<T>`, און דערנאָך עס וועט זיין אַלאַקייטיד אַמאָל פֿאַר די `Vec<T>` אין די `Rc<[T]>`.
    ///
    ///
    /// ## יטאַטאָרס פון באַוווסט לענג
    ///
    /// ווען דיין `Iterator` ימפּלאַמאַנץ `TrustedLen` און איז פון אַ פּינטלעך גרייס, עס וועט זיין אַ איין אַלאַקיישאַן פֿאַר די `Rc<[T]>`.צום ביישפיל:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // נאָר אַ איין אַלאַקיישאַן כאַפּאַנז דאָ.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// ספּעשאַלאַזיישאַן trait געניצט פֿאַר קאַלעקטינג אין `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // דאָס איז דער פאַל פֿאַר אַ `TrustedLen` יטעראַטאָר.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // זיכערקייט: מיר דאַרפֿן צו ענשור אַז די יטעראַטאָר האט אַן פּינטלעך לענג און מיר האָבן.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // פאַלן צוריק צו נאָרמאַל ימפּלאַמענטיישאַן.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` איז אַ ווערסיע פון [`Rc`] וואָס האט אַ ניט-אָונינג דערמאָנען צו די געראטן אַלאַקיישאַן.די אַלאַקיישאַן איז אַקסעסט דורך רופן [`upgrade`] אויף די `Weak` טייַטל, וואָס קערט אַ [`אָפּציע`]`<`[`Rc`] `<T>>`.
///
/// זינט אַ `Weak` רעפֿערענץ טוט נישט ציילן פֿאַר אָונערשיפּ, דאָס וועט נישט פאַרמייַדן די ווערט סטאָרד אין די אַלאַקיישאַן פון פאַלן, און `Weak` זיך גיט קיין געראַנטיז וועגן די ווערט וואָס איז נאָך פאָרשטעלן.
/// אזוי עס קען צוריקקומען [`None`] ווען [`אַפּגרייד`] ד.
/// באַמערקונג אָבער אַז אַ `Weak` דערמאָנען *קען* פאַרמייַדן די אַלאַקיישאַן אַלאַוז (די באַקינג קראָם) דילאַקייטיד.
///
/// א קס 00 קס טייַטל איז נוציק פֿאַר בעכעסקעם אַ צייַטווייַליק דערמאָנען צו די אַלאַקיישאַן געראטן דורך קס 01 קס אָן פּרעווענטינג די ינער ווערט פון דראַפּינג.
/// עס איז אויך געניצט צו פאַרמייַדן קייַלעכיק באַווייַזן צווישן קס 00 קס פּוינטערז, ווייַל קעגנצייַטיק אָונינג באַווייַזן וואָלט קיינמאָל לאָזן [`Rc`] צו פאַלן.
/// למשל, אַ בוים קען האָבן שטאַרק קס 00 קס פּוינטערז פֿון פאָטער נאָודז צו קינדער, און קס 01 קס פּוינטערז פֿון קינדער צוריק צו זייער עלטערן.
///
/// די טיפּיש וועג צו קריגן אַ קס 01 קס טייַטל איז רופן קס 00 קס.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // דאָס איז אַ `NonNull` צו לאָזן אָפּטימיזינג די גרייס פון דעם טיפּ אין ענומס, אָבער עס איז נישט דאַווקע אַ גילטיק טייַטל.
    //
    // `Weak::new` שטעלט דעם צו קסקסנומקסקס אַזוי אַז עס דאַרף נישט אַלאַקייט פּלאַץ אויף די קופּע.
    // דאָס איז נישט אַ ווערט אַ פאַקטיש טייַטל וועט האָבן טאָמיד ווייַל רקבאָקס האט אַליינמאַנט לפּחות 2.
    // דאָס איז נאָר מעגלעך ווען `T: Sized`;ונסייזד קס 01 קס קיינמאָל באָמבלען.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// בויען אַ נייַ קס 00 קס אָן אַלאַקייטינג קיין זכּרון.
    /// רופן קס 01 קס אויף די צוריקקומען ווערט שטענדיק גיט קס 00 קס.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// העלפער טיפּ צו לאָזן אַקסעס צו דער רעפֿערענץ קאַונץ אָן קיין באַשטעטיקן וועגן די דאַטן פעלד.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// רעטורנס אַ רוי טייַטל צו די כייפעץ קס 01 קס ווייזט דורך דעם קס 00 קס.
    ///
    /// דער טייַטל איז גילטיק בלויז אויב עס זענען עטלעכע שטאַרק באַווייַזן.
    /// דער טייַטל קען זיין דאַנגגלינג, אַנאַליינד אָדער אפילו [`null`] אַנדערש.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // ביידע פונט צו דער זעלביקער כייפעץ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // די שטאַרק דאָ האלט עס לעבעדיק, אַזוי מיר קענען נאָך אַקסעס די כייפעץ.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // אָבער נישט מער.
    /// // מיר קענען טאָן weak.as_ptr(), אָבער אַקסעס צו די טייַטל וואָלט פירן צו ונדעפינייטיד נאַטור.
    /// // אַססערט_עק! ("העלא", אַנסייף {קס 00 קס;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // אויב דער טייַטל איז דאַנגגלינג, מיר ווייַזן די סענטינעל גלייַך.
            // דאָס קען נישט זיין אַ גילטיק פּיילאָוד אַדרעס, ווייַל די פּיילאָוד איז לפּחות ווי אַליינד ווי RcBox (usize).
            ptr as *const T
        } else {
            // זיכערקייט: אויב יס_דאַנגלינג קערט פאַלש, דער טייַטל איז דערפערענאַבאַל.
            // די פּיילאָוד קען זיין דראַפּט אין דעם פונט, און מיר האָבן צו טייַנען פּראָווענאַנסע, אַזוי נוצן רוי טייַטל מאַניפּיאַליישאַן.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// קאַנסומז די `Weak<T>` און טורנס עס אין אַ רוי טייַטל.
    ///
    /// דעם קאַנווערץ די שוואַך טייַטל אין אַ רוי טייַטל, בשעת נאָך פּרעזערוויישאַן די אָונערשיפּ פון איין שוואַך רעפֿערענץ (די שוואַך ציילן איז נישט מאַדאַפייד דורך די אָפּעראַציע).
    /// עס קענען זיין פארקערט צוריק אין די `Weak<T>` מיט [`from_raw`].
    ///
    /// די זעלבע ריסטריקשאַנז פון אַקסעס צו די ציל פון די טייַטל ווי מיט [`as_ptr`] אַפּלייז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// קאָנווערט אַ רוי טייַטל פריער באשאפן דורך קס 01 קס צוריק אין קס 00 קס.
    ///
    /// דעם קענען ווערן גענוצט צו באַקומען אַ שטאַרק רעפֿערענץ (דורך רופן [`upgrade`] שפּעטער) אָדער צו האַנדלען מיט די שוואַך ציילן דורך דראַפּינג די `Weak<T>`.
    ///
    /// עס נעמט אָונערשיפּ פון איין שוואַך רעפֿערענץ (מיט די ויסנעם פון פּוינטערז באשאפן דורך קס 00 קס, ווייַל די טאָן ניט פאַרמאָגן עפּעס; דער אופֿן נאָך אַרבעט אויף זיי).
    ///
    /// # Safety
    ///
    /// דער טייַטל מוזן האָבן ערידזשאַנייטאַד פֿון די [`into_raw`] און נאָך זיין פּאָטענציעל שוואַך דערמאָנען.
    ///
    /// דער שטאַרק ציילן איז דערלויבט צו זיין 0 אין דער צייט פון רופן דעם.
    /// פונדעסטוועגן, דאָס נעמט אָונערשיפּ פון איין שוואַך רעפֿערענץ דערווייַל רעפּריזענטיד ווי אַ רוי טייַטל (די שוואַך ציילן איז נישט מאַדאַפייד דורך די אָפּעראַציע) און דעריבער עס מוזן זיין פּערד מיט אַ פריערדיקן רוף צו [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // דעקרעמענט די לעצטע שוואַך ציילן.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // זען קס 00 קס פֿאַר קאָנטעקסט וועגן ווי דער ינפּוט טייַטל איז דערייווד.

        let ptr = if is_dangling(ptr as *mut T) {
            // דאָס איז אַ דאַנגגלינג וויק.
            ptr as *mut RcBox<T>
        } else {
            // אַנדערש, מיר 'רע געראַנטיד די טייַטל געקומען פֿון אַ נאַנדאַנגלינג שוואַך.
            // זיכערקייט: דאַטאַ_אָפסעט איז זיכער צו רופן, ווייַל פּטר באַווייַזן אַ פאַקטיש (פּאַטענטשאַלי דראַפּט) טי.
            let offset = unsafe { data_offset(ptr) };
            // אַזוי, מיר פאַרקערט די פאָטאָ צו באַקומען די גאַנץ רקבאָקס.
            // זיכערקייט: דער טייַטל ערידזשאַנייטאַד פון אַ וויק, אַזוי דעם פאָטאָ איז זיכער.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // זיכערקייט: מיר האָבן איצט ריקאַווערד דער אָריגינעל וויק טייַטל, אַזוי קענען מאַכן די וויק.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// פרווון צו אַפּגרייד די קס 01 קס טייַטל צו אַ קס 00 קס, פאַרהאַלטן דראַפּינג די ינער ווערט אויב געראָטן.
    ///
    ///
    /// קערט [`None`] אויב די ינער ווערט האט שוין דראַפּט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // צעשטערן אַלע שטאַרק פּוינטערז.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// געץ די נומער פון שטאַרק (`Rc`) פּוינטערז וואָס ווייַזן די אַלאַקיישאַן.
    ///
    /// אויב קס 01 קס איז באשאפן מיט קס 00 קס, דאָס וועט צוריקקומען 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// געץ די נומער פון `Weak` פּוינטערז וואָס ווייַזן די אַלאַקיישאַן.
    ///
    /// אויב קיין שטאַרק פּוינטערז בלייַבן, דאָס וועט צוריקקומען נול.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // אַראָפּרעכענען די ימפּליסאַט שוואַך פּטר
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// קערט `None` ווען דער טייַטל איז דאַנגגלינג און עס איז קיין אַלאַקייטיד `RcBox`, (ד"ה ווען `Weak` איז באשאפן דורך `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // מיר זענען אָפּגעהיט צו *נישט* מאַכן אַ רעפֿערענץ וואָס קאַווערד די "data" פעלד, ווייַל די פעלד קען זיין מיוטייטיד קאַנקעראַנטלי (פֿאַר בייַשפּיל, אויב די לעצטע `Rc` איז דראַפּט, די דאַטן פעלד וועט זיין דראַפּט אין פּלאַץ).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// קערט `true` אויב די צוויי `שוואַך` ווייַזן צו דער זעלביקער אַלאַקיישאַן (ענלעך צו [`ptr::eq`]), אָדער אויב ביידע טאָן ניט ווייַזן קיין אַלאַקיישאַן (ווייַל זיי זענען באשאפן מיט `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// זינט דעם קאַמפּערד פּוינטערז, עס מיטל אַז `Weak::new()` וועט זיין גלייַך יעדער אנדערע, כאָטש זיי טאָן ניט אָנווייַזן קיין אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// קאַמפּערינג קס 00 קס.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// דראָפּס די קס 00 קס טייַטל.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // טוט נישט דרוקן עפּעס
    /// drop(foo);        // פּרינץ קס 00 קס
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // די שוואַך ציילן סטאַרץ ביי 1 און וועט נאָר גיין צו נול אויב אַלע די שטאַרק פּוינטערז האָבן פאַרשווונדן.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// מאכט אַ קלאָון פון די קס 00 קס טייַטל וואָס ווייזט צו דער זעלביקער אַלאַקיישאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// בויען אַ נייַ קס 00 קס, אַלאַקייטינג זכּרון פֿאַר קס 01 קס אָן יניטיאַליזינג עס.
    /// רופן קס 01 קס אויף די צוריקקומען ווערט שטענדיק גיט קס 00 קס.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: מיר אָפּגעשטעלט_אַדד דאָ צו בעשאָלעם האַנדלען מיט mem::forget.אין באַזונדער
// אויב איר קס 00 קס רק (אָדער וויקס), דער רעף-ציילן קענען לויפן, און איר קענען באַפרייַען די אַלאַקיישאַן בשעת בוילעט רק (אָדער וויקס) עקסיסטירן.
//
// מיר אַבאָרט ווייַל דאָס איז אַזאַ אַ דידזשענערייטיד סצענאַר אַז מיר טאָן ניט זאָרגן וועגן וואָס כאַפּאַנז-קיין פאַקטיש פּראָגראַם זאָל קיינמאָל דערפאַרונג דעם.
//
// דעם זאָל האָבן נעגלאַדזשאַבאַל אָוווערכעד ווייַל איר טאָן ניט טאַקע דאַרפֿן צו קלאָון די פיל אין ז 0 רוסט 0 ז דאַנק צו אָונערשיפּ און מאַך-סעמאַנטיקס.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // מיר וועלן אַבאָרט אויף לויפן לויפן אַנשטאָט פון דראַפּינג די ווערט.
        // דער רעפֿערענץ ציילן וועט קיינמאָל זיין נול ווען דאָס איז גערופֿן;
        // פונדעסטוועגן, מיר שטעלן אַן אַבאָרט דאָ צו אָנצוהערעניש LLVM צו אַן אַנדערש מיסט אָפּטימיזאַטיאָן.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // מיר וועלן אַבאָרט אויף לויפן לויפן אַנשטאָט פון דראַפּינג די ווערט.
        // דער רעפֿערענץ ציילן וועט קיינמאָל זיין נול ווען דאָס איז גערופֿן;
        // פונדעסטוועגן, מיר שטעלן אַן אַבאָרט דאָ צו אָנצוהערעניש LLVM צו אַן אַנדערש מיסט אָפּטימיזאַטיאָן.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// באַקומען די אָפסעט אין אַן `RcBox` פֿאַר די פּיילאָוד הינטער אַ טייַטל.
///
/// # Safety
///
/// דער טייַטל דאַרף אָנווייַזן (און האָבן גילטיק מעטאַדאַטאַ פֿאַר) אַ פריער גילטיק בייַשפּיל פון T, אָבער די T איז ערלויבט צו פאַלן.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // אַליינ די אַנסייזד ווערט צו די סוף פון די רקבאָקס.
    // ווייַל RBBox איז repr(C), עס וועט שטענדיק זיין די לעצטע פעלד אין זכּרון.
    // זיכערקייט: זינט די בלויז ונסיזעד טייפּס זענען סלייסאַז, trait אַבדזשעקץ,
    // און עקסטערן טייפּס, די ינפּוט זיכערקייַט פאָדערונג איז איצט גענוג צו באַפרידיקן די רעקווירעמענץ פון align_of_val_raw;דאָס איז אַן ימפּלאַמענטיישאַן דעטאַל פון די שפּראַך וואָס קען ניט זיין רילייד אויף אַרויס פון std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}