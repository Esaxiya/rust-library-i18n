use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // שרייבן אַ טעסט פון ינאַגריישאַן צווישן אַלאַטערז פון דריט טיילווייַז און קס 00 קס איז אַ ביסל טריקי ווייַל די קס 01 קס אַפּי קען נישט ויסשטעלן פאַלאַבאַל אַלאַקיישאַן מעטהאָדס, אַזוי מיר קענען נישט קאָנטראָלירן וואָס כאַפּאַנז ווען אַלאַקייטער איז ויסגעמאַטערט (ווייַטער פון דיטעקטינג אַ ז 0 פּאַניק 0 ז).
    //
    //
    // אַנשטאָט, דאָס נאָר טשעקס אַז די `RawVec` מעטהאָדס טאָן לפּחות דורך די אַללאָקאַטאָר אַפּי ווען עס ריזערווז סטאָרידזש.
    //
    //
    //
    //
    //

    // א שטום אַלאַקייטער וואָס קאַנסומז אַ פאַרפעסטיקט סומע פון ברענוואַרג איידער אַלאַקיישאַן פרווון אָנהייבן צו דורכפאַל.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ז אַ רעאַללאָק, אַזוי ניצן 50 + 150=200 וניץ פון ברענוואַרג)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ערשטער, `reserve` אַלאַקייץ ווי `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 איז מער ווי טאָפּל פון 7, אַזוי `reserve` זאָל אַרבעטן ווי `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 איז ווייניקער ווי האַלב פון 12, אַזוי `reserve` מוזן וואַקסן עקספּאָונענשאַלי.
        // אין דער צייט פון שרייבן, די פּרובירן גראָוט פאַקטאָר איז 2, אַזוי די נייַ קאַפּאַציטעט איז 24, אָבער די גראָוינג פאַקטאָר פון 1.5 איז אויך גוט.
        //
        // דערפאר קס 00 קס באַשטעטיקן.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}