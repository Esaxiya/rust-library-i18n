//! מעמאָרי אַלאַקיישאַן אַפּיס

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // דאָס איז די מאַגיש סימבאָלס צו רופן די גלאבאלע אַלאַקייטער.rustc דזשענערייץ זיי צו רופן `__rg_alloc` עטק.
    // אויב עס איז אַ קס 00 קס אַטריביוט (די קאָד יקספּאַנדינג אַז אַטריביוט מאַקראָו דזשענערייץ די פאַנגקשאַנז), אָדער צו רופן די פעליקייַט ימפּלעמענטאַטיאָנס אין ליבסטד (קס 01 קס עטק.)
    //
    // אין `library/std/src/alloc.rs`) אַנדערש.
    // די rustc fork פון LLVM אויך ספּעציפיצירן די פונקציע נעמען צו זיין אָפּטימיזעד ווי `malloc`, `realloc` און `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// די גלאבאלע זכּרון אַלאַקייטער.
///
/// דעם טיפּ ימפּלאַמאַנץ די [`Allocator`] trait דורך פאָרווערדינג רופט צו די אַלאַקייטער רעגיסטרירט מיט די `#[global_allocator]` אַטריביוט אויב עס איז איינער, אָדער די `std` crate ס פעליקייַט.
///
///
/// Note: בשעת דעם טיפּ איז אַנסטייבאַל, די פאַנגקשאַנאַליטי עס אָפפערס קענען זיין אַקסעסט דורך די [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// אַלאַקייט זיקאָרן מיט די גלאבאלע אַלאַקייטער.
///
/// די פֿונקציע פאָרווערדז די [`GlobalAlloc::alloc`] אופֿן פון די אַלאַקייטער רעגיסטרירט מיט די `#[global_allocator]` אַטריביוט אויב עס איז איינער, אָדער די `std` crate ס פעליקייַט.
///
///
/// די פֿונקציע איז געריכט צו זיין אָפּגעלאָזן צו די `alloc` אופֿן פון די [`Global`] טיפּ ווען עס און די [`Allocator`] ז 0 טראַיט 0 ז ווערן סטאַביל.
///
/// # Safety
///
/// זען קס 00 קס.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// דעאַללאָקאַטע זכּרון מיט די גלאבאלע אַלאַקייטער.
///
/// די פֿונקציע פאָרווערדז די [`GlobalAlloc::dealloc`] אופֿן פון די אַלאַקייטער רעגיסטרירט מיט די `#[global_allocator]` אַטריביוט אויב עס איז איינער, אָדער די `std` crate ס פעליקייַט.
///
///
/// די פֿונקציע איז געריכט צו זיין אָפּגעלאָזן צו די `dealloc` אופֿן פון די [`Global`] טיפּ ווען עס און די [`Allocator`] ז 0 טראַיט 0 ז ווערן סטאַביל.
///
/// # Safety
///
/// זען קס 00 קס.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// ריאַלאַקייט זכּרון מיט די גלאבאלע אַלאַקייטער.
///
/// די פֿונקציע פאָרווערדז די [`GlobalAlloc::realloc`] אופֿן פון די אַלאַקייטער רעגיסטרירט מיט די `#[global_allocator]` אַטריביוט אויב עס איז איינער, אָדער די `std` crate ס פעליקייַט.
///
///
/// די פֿונקציע איז געריכט צו זיין אָפּגעלאָזן צו די `realloc` אופֿן פון די [`Global`] טיפּ ווען עס און די [`Allocator`] ז 0 טראט 0 ז ווערן סטאַביל.
///
/// # Safety
///
/// זען קס 00 קס.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// אַלאַקייט נול-ינישאַלייזד זכּרון מיט די גלאבאלע אַלאַקייטער.
///
/// די פֿונקציע פאָרווערדז די [`GlobalAlloc::alloc_zeroed`] אופֿן פון די אַלאַקייטער רעגיסטרירט מיט די `#[global_allocator]` אַטריביוט אויב עס איז איינער, אָדער די `std` crate ס פעליקייַט.
///
///
/// די פֿונקציע איז געריכט צו זיין אָפּגעלאָזן צו די `alloc_zeroed` אופֿן פון די [`Global`] טיפּ ווען עס און די [`Allocator`] ז 0 טראַיט 0 ז ווערן סטאַביל.
///
/// # Safety
///
/// זען קס 00 קס.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // זיכערקייט: `layout` איז ניט-נול אין גרייס,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // זיכערקייט: זעלביקער ווי קס 00 קס
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // זיכערקייט: קס 01 קס איז ניט-נול ווי קס 02 קס איז גרעסער ווי אָדער גלייַך צו קס 00 קס
            // ווי פארלאנגט דורך זיכערקייַט באדינגונגען.אנדערע טנאָים מוזן זיין אַפּכעלד דורך די קאָלער
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` מיסטאָמע טשעקס פֿאַר קס 00 קס אָדער עפּעס ענלעך.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // זיכערקייט: ווייַל `new_layout.size()` מוזן זיין גרעסער ווי אָדער גלייַך צו `old_size`,
            // די אַלט און נייַ זכּרון אַלאַקיישאַן זענען גילטיק פֿאַר רידינג און שרייבט פֿאַר קס 00 קס ביטעס.
            // ווייַל די אַלטע אַלאַקיישאַן איז נאָך נישט דילאַקייטיד, עס קען נישט אָוווערלאַפּ `new_ptr`.
            // אַזוי, די רופן צו קס 00 קס איז זיכער.
            // דער זיכערקייט קאָנטראַקט פֿאַר קס 00 קס מוזן זיין אַפּכעלד דורך די קאָלער.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // זיכערקייט: `layout` איז ניט-נול אין גרייס,
            // אנדערע באדינגונגען מוזן זיין אַפּכעלד דורך די קאָלער
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // זיכערהייט: די באדערפענישן מוזן זיין אַפּכעלד
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // זיכערהייט: די באדערפענישן מוזן זיין אַפּכעלד
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // זיכערהייט: די קלינגער מוזן באַשטעטיקן די באדינגונגען
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // זיכערקייט: קס 00 קס איז ניט-נול.אנדערע טנאָים מוזן זיין אַפּכעלד דורך די קאָלער
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` מיסטאָמע טשעקס פֿאַר קס 00 קס אָדער עפּעס ענלעך.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // זיכערקייט: ווייַל `new_size` מוזן זיין קלענערער ווי אָדער גלייַך צו `old_layout.size()`,
            // די אַלט און נייַ זכּרון אַלאַקיישאַן זענען גילטיק פֿאַר רידינג און שרייבט פֿאַר קס 00 קס ביטעס.
            // ווייַל די אַלטע אַלאַקיישאַן איז נאָך נישט דילאַקייטיד, עס קען נישט אָוווערלאַפּ `new_ptr`.
            // אַזוי, די רופן צו קס 00 קס איז זיכער.
            // דער זיכערקייט קאָנטראַקט פֿאַר קס 00 קס מוזן זיין אַפּכעלד דורך די קאָלער.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// די אַלאַקייטער פֿאַר יינציק פּוינטערז.
// די פֿונקציע דאַרף נישט אַנוויינד.אויב דאָס, MIR קאָדעגען וועט פאַרלאָזן.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// די סיגנאַטורע דאַרף זיין די זעלבע ווי `Box`, אַנדערש אַ ICE וועט פּאַסירן.
// ווען אַ נאָך פּאַראַמעטער צו `Box` איז מוסיף (ווי `A: Allocator`), דאָס דאַרף אויך זיין מוסיף דאָ.
// פֿאַר בייַשפּיל, אויב `Box` איז געביטן צו `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, די פֿונקציע זאָל זיין געביטן צו `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # אַללאָקאַטיאָן טעות האַנדלער

extern "Rust" {
    // דאָס איז די מאַגיש סימבאָל צו רופן די גלאבאלע אַלאַקייט טעות האַנדלער.
    // rustc דזשענערייץ עס צו רופן `__rg_oom` אויב עס איז אַ `#[alloc_error_handler]`, אָדער צו רופן די פעליקייַט ימפּלאַמענטיישאַנז ונטער (`__rdl_oom`) אַנדערש.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// אַבאָרט אויף זיקאָרן אַלאַקיישאַן טעות אָדער דורכפאַל.
///
/// קאַללערס פון אַפּי פֿאַר זכּרון אַלאַקיישאַן וואָס ווילן צו אָפּגעבן קאַמפּיאַטיישאַן אין ענטפער צו אַ אַלאַקיישאַן טעות זענען ינקעראַדזשד צו רופן דעם פֿונקציע, אלא ווי גלייך ינוואָוקינג `panic!` אָדער ענלעך.
///
///
/// די ניט ויסצאָלן אָפּפירונג פון דעם פֿונקציע איז צו דרוקן אַ אָנזאָג צו נאָרמאַל טעות און אַבאָרט דעם פּראָצעס.
/// עס קענען זיין ריפּלייסט מיט קס 01 קס און קס 00 קס.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// פֿאַר אַלאַקייטיד טעסטינג `std::alloc::handle_alloc_error` קענען ווערן געניצט גלייַך.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // גערופֿן דורך דזשענערייטאַד קס 00 קס

    // אויב עס איז קיין קס 00 קס
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // אויב עס איז אַ `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// ספּעשאַלייז קלאָונז אין פאַר-אַלאַקייטיד, אַנינישיייטיד זכּרון.
/// געוויינט דורך קס 01 קס און קס 00 קס.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // אויב איר האָבן אַלאַקייטיד *ערשטער*, דער אָפּטימיזער קען לאָזן די קלאָונד ווערט אין-אָרט, סקיפּינג די היגע און מאַך.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // מיר קענען שטענדיק נאָכמאַכן אין-אָרט, אָן אַ היגע ווערט.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}