//! א UTF-8-קאָדעד, גראָודאַבאַל שטריקל.
//!
//! די מאָדולע כּולל די קס 00 קס טיפּ, די X 01 קס ז 0 טראַריט 0 ז פֿאַר קאַנווערטינג צו סטרינגס, און עטלעכע טעות טייפּס אַז קען רעזולטאַט פון ארבעטן מיט [`סטרינג`] s.
//!
//!
//! # Examples
//!
//! עס זענען קייפל וועגן צו שאַפֿן אַ נייַע [`String`] פֿון אַ שטריקל ליטעראַל:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! איר קענען שאַפֿן אַ נייַע [`String`] פֿון אַן יגזיסטינג דורך קאַנקאַטאַנייטינג מיט
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! אויב איר האָט אַ vector פון גילטיק UTF-8 ביטעס, איר קענען מאַכן אַ [`String`] פון אים.איר קענען אויך טאָן די פאַרקערט.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // מיר וויסן אַז די ביטעס זענען גילטיק, אַזוי מיר וועלן נוצן `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// א UTF-8-קאָדעד, גראָודאַבאַל שטריקל.
///
/// די קס 01 קס טיפּ איז די מערסט פּראָסט שטריקל טיפּ וואָס האט אָונערשיפּ איבער די אינהאַלט פון די שטריקל.עס האט אַ נאָענט שייכות מיט די באַראָוד אַנטקעגענער, די פּרימיטיוו קס 00 קס.
///
/// # Examples
///
/// איר קענען שאַפֿן אַ `String` פֿון [a literal string][`str`] מיט [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// איר קענען צולייגן אַ [`char`] צו אַ `String` מיט די [`push`] אופֿן, און צוגעבן אַ [`char`] מיט די [`push_str`] אופֿן:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// אויב איר האָבן אַ vector פון UTF-8 ביטעס, איר קענען שאַפֿן אַ `String` פֿון אים מיט די [`from_utf8`] אופֿן:
///
/// ```
/// // עטלעכע ביטעס, אין אַ ז 0 וועקטאָר 0 ז
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // מיר וויסן אַז די ביטעס זענען גילטיק, אַזוי מיר וועלן נוצן `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// סטרינגס זענען שטענדיק גילטיק קס 01 קס.דער ערשטער ימפּלאַקיישאַנז זענען די ערשטע פון וואָס אויב איר דאַרפֿן אַ שטריקל וואָס איז ניט UTF-8, איר זאָל באַטראַכטן [`OsString`].עס איז ענלעך, אָבער אָן די קס 03 קס קאַנסטריינט.די רגע ימפּלאַקיישאַן איז אַז איר קענען נישט אינדעקס אין אַ `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// ינדעקסינג איז בדעה צו זיין אַ קעסיידערדיק-צייט אָפּעראַציע, אָבער קס 00 קס קאָדירונג קען נישט לאָזן אונדז צו טאָן דאָס.דערצו, עס איז נישט קלאָר וואָס סאָרט פון זאַך דער אינדעקס זאָל צוריקקומען: אַ בייט, אַ קאָדעפּאָינט אָדער אַ גראַפעמע קנויל.
/// די [`bytes`] און [`chars`] מעטהאָדס ווייַזן יטעראַטאָרס איבער די ערשטע צוויי.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// String`s implement [`Deref`]`<Target=str>`, און אַזוי ירשענען אַלע מעטהאָדס פון [` סטר`].אין אַדישאַן, דעם מיטל אַז איר קענען פאָרן אַ `String` צו אַ [`&str`] פונקציע מיט אַ אַמערסאַנד קס 00 קס:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// דעם וועט מאַכן אַ קס 00 קס פון די קס 01 קס און פאָרן עס ין דעם קאַנווערזשאַן איז זייער ביליק, און אַזוי בכלל, פאַנגקשאַנז וועט אָננעמען [`&סטר`] s ווי אַרגומענטן סייַדן זיי דאַרפֿן אַ קס 02 קס פֿאַר עטלעכע ספּעציפיש סיבה.
///
/// אין זיכער קאַסעס, Rust האט נישט גענוג אינפֿאָרמאַציע צו מאַכן דעם קאַנווערזשאַן, באַוווסט ווי [`Deref`] צוואַנג.אין די פאלגענדע בייַשפּיל, אַ שטריקל רעפטל קס 02 קס ימפּלאַמאַנץ די ז 0 טראַט 0 ז קס 00 קס, און די פונקציע קס 03 קס נעמט עפּעס וואָס ימפּלאַמאַנץ די ז 0 טראַט 0 ז.
/// אין דעם פאַל, Rust וואָלט דאַרפֿן צו מאַכן צוויי ימפּליסאַט קאַנווערזשאַנז, וואָס Rust קען נישט טאָן.
/// דעריבער, די פאלגענדע בייַשפּיל וועט נישט צונויפנעמען.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// עס זענען צוויי אָפּציעס וואָס וואָלט אַרבעט אַנשטאָט.דער ערשטער וואָלט זיין צו טוישן די שורה קס 01 קס צו קס 00 קס, ניצן די אופֿן קס 02 קס צו יקספּליסאַטלי עקסטראַקט די שטריקל רעפטל מיט די שטריקל.
/// די רגע וועג טשאַנגינג קס 01 קס צו קס 00 קס.
/// אין דעם פאַל, מיר דערפערענסינג אַ קס 02 קס צו אַ קס 01 קס און דערנאָך ריפערינג צו די קס 03 קס צוריק צו קס 00 קס.
/// די רגע וועג איז מער ידיאָמאַטיק, אָבער ביידע אַרבעט צו מאַכן די קאַנווערזשאַן בפירוש ווי צו פאַרלאָזנ אויף די ימפּליסאַט קאַנווערזשאַן.
///
/// # Representation
///
/// א קס 00 קס איז קאַמפּרייזד פון דריי קאַמפּאָונאַנץ: אַ טייַטל צו עטלעכע ביטעס, אַ לענג און אַ קאַפּאַציטעט.דער טייַטל ווייזט צו אַ ינערלעך באַפער קס 01 קס ניצט צו קראָם די דאַטן.די לענג איז די נומער פון ביטעס איצט סטאָרד אין די באַפער, און די קאַפּאַציטעט איז די גרייס פון די באַפער אין ביטעס.
///
/// דעריבער, די לענג וועט שטענדיק זיין ווייניקער ווי אָדער גלייַך צו די קאַפּאַציטעט.
///
/// דער באַפער איז שטענדיק סטאָרד אויף די קופּע.
///
/// איר קענט זען די מיט די [`as_ptr`], [`len`] און [`capacity`] מעטהאָדס:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME דערהייַנטיקן דעם ווען vec_into_raw_parts איז סטייבאַלייזד.
/// // פאַרמייַדן אויטאָמאַטיש דראַפּינג די דאַטן פון די סטרינג
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // געשיכטע האט נייַנצן ביטעס
/// assert_eq!(19, len);
///
/// // מיר קענען שייַעך-בויען אַ שטריקל אויס פון פּטר, לענ, און קאַפּאַציטעט.
/// // דאָס איז אַלץ אַנסייף ווייַל מיר זענען פאַראַנטוואָרטלעך פֿאַר זיכער אַז די קאַמפּאָונאַנץ זענען גילטיק:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// אויב אַ `String` האט גענוג קאַפּאַציטעט, אַדינג עלעמענטן צו עס וועט נישט שייַעך-אַלאַקייט.פֿאַר בייַשפּיל, באַטראַכטן דעם פּראָגראַם:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// דער רעזולטאַט וועט זיין די פאלגענדע:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// אין ערשטער, מיר האָבן קיין זכּרון אַלאַקייטיד, אָבער ווען מיר צולייגן צו די שטריקל, עס ינקריסיז די קאַפּאַציטעט צונעמען.אויב מיר אַנשטאָט ניצן די [`with_capacity`] אופֿן צו אַלאַקייט די ריכטיק קאַפּאַציטעט טכילעס:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// מיר ענדיקן אַ אַנדערש רעזולטאַט:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// דאָ, עס ס ניט דאַרפֿן צו אַלאַקייט מער זיקאָרן ין די שלייף.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// א מעגלעך טעות ווערט ווען קאַנווערטינג אַ קס 00 קס פֿון אַ קס 01 קס ביטע ז 0 וועקטאָר 0 ז.
///
/// דער טיפּ איז דער טעות טיפּ פֿאַר די [`from_utf8`] אופֿן אויף [`String`].
/// עס איז דיזיינד אויף אַזאַ אַ וועג צו קערפאַלי ויסמיידן ריאַלאַקיישאַנז: די [`into_bytes`] אופֿן וועט געבן צוריק די vector בייט וואָס איז געניצט אין דעם קאַנווערזשאַן פּרווון.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// די [`Utf8Error`] טיפּ צוגעשטעלט דורך [`std::str`] רעפּראַזענץ אַ טעות וואָס קען פּאַסירן ווען קאַנווערטינג אַ רעפטל פון [`u8`] s צו אַ [`&str`].
/// אין דעם זינען, עס איז אַן אַנאַלאָג צו קס 00 קס, און איר קענען באַקומען איין פון אַ קס 01 קס דורך די קס 02 קס אופֿן.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// // עטלעכע פאַרקריפּלט ביטעס אין אַ ז 0 וועקטאָר 0 ז
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// א מעגלעך טעות ווערט ווען קאַנווערטינג אַ `String` פֿון אַ UTF-16 בייט רעפטל.
///
/// דעם טיפּ איז די טעות טיפּ פֿאַר די [`from_utf16`] אופֿן אויף [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// קרעאַטעס אַ נייַ ליידיק קס 00 קס.
    ///
    /// אויב די `String` איז ליידיק, דאָס קען נישט צוטיילן קיין ערשט באַפער.כאָטש דאָס מיטל אַז די ערשט אָפּעראַציע איז זייער ביליק, אָבער עס קען פאַרשאַפן יבעריק אַלאַקיישאַן שפּעטער ווען איר לייגן דאַטן.
    ///
    /// אויב איר האָט אַ געדאַנק פון ווי פיל דאַטן די `String` וועט האַלטן, באַטראַכטן די [`with_capacity`] אופֿן צו פאַרמייַדן יבעריק שייַעך-אַלאַקיישאַן.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// קרעאַטעס אַ נייַ ליידיק קס 00 קס מיט אַ באַזונדער קאַפּאַציטעט.
    ///
    /// סטרינגס האָבן אַן ינערלעך באַפער צו האַלטן זייער דאַטן.
    /// די קאַפּאַציטעט איז די לענג פון דעם באַפער און קענען זיין קוועריד מיט די [`capacity`] אופֿן.
    /// דעם אופֿן קריייץ אַן ליידיק קס 00 קס, אָבער איינער מיט אַן ערשט באַפער וואָס קענען האַלטן קס 01 קס ביטעס.
    /// דאָס איז נוציק ווען איר קען צולייגן אַ פּלאַץ פון דאַטן צו די `String` און רידוסינג די נומער פון ריאַלאַקיישאַנז.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// אויב די געגעבן קאַפּאַציטעט איז קס 00 קס, קיין אַלאַקיישאַן וועט פּאַסירן, און דעם אופֿן איז יידעניקאַל צו די קס 01 קס אופֿן.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // די סטרינג כּולל קיין טשאַרס, כאָטש עס קען האָבן מער קאַפּאַציטעט
    /// assert_eq!(s.len(), 0);
    ///
    /// // די אַלע זענען געטאן אָן ריאַלאַקייטינג ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... אָבער דאָס קען מאַכן די שטריקל ריאַלאַקייט
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): מיט קס 00 קס די טאָכיק קס 01 קס אופֿן, וואָס איז פארלאנגט פֿאַר דעם אופֿן דעפֿיניציע, איז ניט בנימצא.
    // זינט מיר טאָן ניט דאַרפן דעם אופֿן פֿאַר טעסטינג צוועקן, איך וועט נאָר שטופּן עס. זען די slice::hack מאָדולע אין slice.rs פֿאַר מער אינפֿאָרמאַציע
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// קאָנווערט אַ ז 0 וועקטאָר 0 ז פון ביטעס צו אַ קס 00 קס.
    ///
    /// א שטריקל קס 01 קס איז געמאכט פון ביטעס קס 00 קס, און אַ ז 0 וועקטאָר 0 ז פון ביטעס קס 02 קס איז געמאכט פון ביטעס, אַזוי דעם פֿונקציע קאַנווערץ צווישן די צוויי.
    /// ניט אַלע בייט סלייסיז זענען גילטיק `סטרינג`ס, אָבער: קס 01 קס ריקווייערז אַז עס איז גילטיק קס 00 קס.
    /// `from_utf8()` טשעקס צו ענשור אַז די ביטעס זענען גילטיק קס 00 קס, און דערנאָך די קאַנווערזשאַן.
    ///
    /// אויב איר זענט זיכער אַז די בייט רעפטל איז גילטיק UTF-8, און איר טאָן נישט וועלן צו נעמען די אָוווערכעד פון די גילטיקייַט טשעק, עס איז אַ אַנסייף ווערסיע פון דעם פֿונקציע, [`from_utf8_unchecked`], וואָס האט די זעלבע נאַטור אָבער סקיפּס די טשעק.
    ///
    ///
    /// דער אופֿן וועט נעמען זאָרג צו נישט צייכענען די vector, צוליב עפעקטיווקייט.
    ///
    /// אויב איר דאַרפֿן אַ קס 02 קס אַנשטאָט פון אַ קס 01 קס, באַטראַכטן קס 00 קס.
    ///
    /// די פאַרקערט פון דעם אופֿן איז [`into_bytes`].
    ///
    /// # Errors
    ///
    /// קערט קס 01 קס אויב די רעפטל איז ניט קס 02 קס מיט אַ באַשרייַבונג וואָס די ביטעס זענען נישט קס 00 קס.די vector וואָס איר האָט אריבערגעפארן איז אויך אַרייַנגערעכנט.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // עטלעכע ביטעס, אין אַ ז 0 וועקטאָר 0 ז
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // מיר וויסן אַז די ביטעס זענען גילטיק, אַזוי מיר וועלן נוצן `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// פאַלש ביטעס:
    ///
    /// ```
    /// // עטלעכע פאַרקריפּלט ביטעס אין אַ ז 0 וועקטאָר 0 ז
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// זען די דאָקס פֿאַר קס 00 קס פֿאַר מער דעטאַילס וועגן וואָס איר קענען טאָן מיט דעם טעות.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// קאָנווערץ אַ רעפטל פון ביטעס צו אַ שטריקל, אַרייַנגערעכנט פאַרקריפּלט אותיות.
    ///
    /// סטרינגס זענען געמאכט פון ביטעס קס 01 קס, און אַ שטיקל פון ביטעס קס 02 קס איז געמאכט פון ביטעס, אַזוי דעם פֿונקציע קאַנווערץ צווישן די צוויי.ניט אַלע בייט סלייסאַז זענען גילטיק סטרינגס, אָבער: סטרינגס זענען פארלאנגט צו זיין גילטיק קס 00 קס.
    /// בעשאַס דעם קאַנווערזשאַן, `from_utf8_lossy()` וועט פאַרבייַטן קיין פאַרקריפּלט UTF-8 סיקוואַנסיז מיט [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], וואָס קוקט ווי דאָס:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// אויב איר זענט זיכער אַז די בייט רעפטל איז גילטיק קס 00 קס, און איר טאָן נישט וועלן צו נעמען די אָוווערכעד פון די קאַנווערזשאַן, עס איז אַן אַנסייף ווערסיע פון דעם פונקציע, קס 01 קס, וואָס האט די זעלבע נאַטור אָבער סקיפּס די טשעקס.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// די פֿונקציע קערט אַ [`Cow<'a, str>`].אויב אונדזער בייט רעפטל איז פאַרקריפּלט קס 02 קס, מיר דאַרפֿן צו אַרייַן די פאַרבייַט אותיות, וואָס וועט טוישן די גרייס פון דעם שטריקל, און דעריבער דאַרפן אַ קס 00 קס.
    /// אָבער אויב עס איז שוין גילטיק UTF-8, מיר טאָן ניט דאַרפֿן אַ נייַע אַלאַקיישאַן.
    /// דער צוריקקער טיפּ אַלאַוז אונדז צו האַנדלען מיט ביידע קאַסעס.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // עטלעכע ביטעס, אין אַ ז 0 וועקטאָר 0 ז
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// פאַלש ביטעס:
    ///
    /// ```
    /// // עטלעכע פאַרקריפּלט ביטעס
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// דעקאָדע אַ UTF-16-ענקאָודיד ז 0 וועקטאָר 0 ז קס 01 קס אין אַ קס 00 קס, אומגעקערט קס 02 קס אויב קס 03 קס כּולל קיין פאַרקריפּלט דאַטן.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // דאָס איז נישט געשען דורך זאַמלען: : <Result<_, _>> () פֿאַר פאָרשטעלונג סיבות.
        // FIXME: די פונקציע קענען זיין סימפּלאַפייד ווידער ווען #48994 איז פֿאַרמאַכט.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// דעקאָדע אַ UTF-16-ענקאָודיד רעפטל `v` אין אַ `String`, ריפּלייסינג פאַרקריפּלט דאַטן מיט [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// ניט ענלעך קס 02 קס וואָס קערט אַ קס 00 קס, קס 01 קס קערט אַ קס 03 קס זינט די X04 קס צו קס 05 קס קאַנווערזשאַן ריקווייערז אַ זיקאָרן אַלאַקיישאַן.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// דיקאַמפּאָוזיז אַ `String` אין זיין רוי קאַמפּאָונאַנץ.
    ///
    /// קערט די רוי טייַטל צו די אַנדערלייינג דאַטן, די לענג פון די שטריקל (אין ביטעס) און די אַלאַקייטיד קאַפּאַציטעט פון די דאַטן (אין ביטעס).
    /// דאָס זענען די זעלבע טענות אין די זעלבע סדר ווי די טענות צו [`from_raw_parts`].
    ///
    /// נאָך רופן דעם פֿונקציע, די קאַללער איז פאַראַנטוואָרטלעך פֿאַר דער זכּרון וואָס איז געווען פריער געראטן דורך די `String`.
    /// דער בלויז וועג צו טאָן דאָס איז צו בייַטן די רוי טייַטל, די לענג און די קאַפּאַציטעט צוריק אין אַ `String` מיט די [`from_raw_parts`] פונקציאָנירן, אַלאַוינג די דעסטרוקטאָר צו ויסמעקן.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// קרעאַטעס אַ נייַע קס 00 קס פֿון אַ לענג, קאַפּאַציטעט און טייַטל.
    ///
    /// # Safety
    ///
    /// דאָס איז זייער אַנסייף ווייַל פון די נומער פון ינוואַריאַנץ וואָס זענען נישט אָפּגעשטעלט:
    ///
    /// * דער זכּרון ביי `buf` דאַרף זיין אַלאַקייטיד דורך דער זעלביקער אַלאַקייטער וואָס די נאָרמאַל ביבליאָטעק ניצט, מיט אַ פארלאנגט אַליינמאַנט פון פּונקט 1.
    /// * `length` דאַרף זיין ווייניקער ווי אָדער גלייַך צו קס 00 קס.
    /// * `capacity` דאַרף זיין די ריכטיק ווערט.
    /// * דער ערשטער `length` ביטעס ביי `buf` דאַרפֿן צו זיין גילטיק UTF-8.
    ///
    /// ווייאַלייטינג די קען אָנמאַכן פּראָבלעמס ווי פאַרדאָרבן די ינערלעך דאַטן סטראַקטשערז פון די אַלאַקייטער.
    ///
    /// די אָונערשיפּ פון קס 00 קס איז יפעקטיוולי טראַנספערד צו די קס 01 קס, וואָס קען דאַן דילאַקייט, ריאַלאַקייט אָדער ענדערן די אינהאַלט פון זכּרון וואָס דער טייַטל ווייזט צו זיין.
    /// פאַרזיכערן אַז גאָרנישט אַנדערש ניצט די טייַטל נאָך רופן דעם פֿונקציע.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME דערהייַנטיקן דעם ווען vec_into_raw_parts איז סטייבאַלייזד.
    ///     // פאַרמייַדן אויטאָמאַטיש דראַפּינג די דאַטן פון די סטרינג
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// קאָנווערט אַ ז 0 וועקטאָר 0 ז ביטעס צו אַ קס 01 קס אָן קאָנטראָלירונג אַז די שטריקל כּולל גילטיק קס 00 קס.
    ///
    /// זען די זיכער ווערסיע [`from_utf8`] פֿאַר מער דעטאַילס.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// די פֿונקציע איז אַנסייף ווייַל עס קען נישט קאָנטראָלירן אַז די ביטעס צו עס זענען גילטיק UTF-8.
    /// אויב דעם קאַנסטריינט איז ווייאַלייטיד, עס קען פאַרשאַפן זיקאָרן ונסאַפעטי ישוז מיט future ניצערס פון די `String`, ווייַל די מנוחה פון דער נאָרמאַל ביבליאָטעק אַסומז אַז `String`s זענען גילטיק UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // עטלעכע ביטעס, אין אַ ז 0 וועקטאָר 0 ז
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// קאָנווערט אַ `String` אין אַ בייטן vector.
    ///
    /// דעם קאַנסומז די `String`, אַזוי מיר טאָן ניט דאַרפֿן צו צייכענען די אינהאַלט.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// יקסטראַקץ אַ שטריקל רעפטל מיט די גאנצע `String`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// קאָנווערט אַ `String` אין אַ מיוטאַבאַל שטריקל רעפטל.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// אַפּפּענדס אַ געגעבן שטריקל רעפטל אויף דעם סוף פון דעם קס 00 קס.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// רעטורנס דעם קאַפּאַציטעט פון דעם `סטרינג`, אין ביטעס.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ינשורז אַז די קאַפּאַציטעט פון דעם 'סטרינג' איז ביי מינדסטער X00 קס ביטעס גרעסער ווי די לענג.
    ///
    /// די קאַפּאַציטעט קען זיין געוואקסן מיט מער ווי `additional` ביטעס אויב עס טשוזיז צו פאַרמייַדן אָפט ריאַלאַקיישאַנז.
    ///
    ///
    /// אויב איר טאָן ניט וועלן דעם "at least" נאַטור, זען די [`reserve_exact`] אופֿן.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט אָוווערפלאָוז [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// דאָס קען נישט אַקשלי פאַרגרעסערן די קאַפּאַציטעט:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s איצט האט אַ לענג פון 2 און אַ קאַפּאַציטעט פון 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // זינט מיר האָבן שוין אַן עקסטרע 8 קאַפּאַציטעט, רופן דעם ...
    /// s.reserve(8);
    ///
    /// // ... טוט נישט אַקשלי פאַרגרעסערן.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ינשורז אַז די קאַפּאַציטעט פון דעם 'סטרינג' איז X00 קס ביטעס גרעסער ווי די לענג.
    ///
    /// באַטראַכטן ניצן די [`reserve`] אופֿן סייַדן איר וויסן בעסער ווי די אַלאַקייטער.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט אָוווערפלאָוז `usize`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// דאָס קען נישט אַקשלי פאַרגרעסערן די קאַפּאַציטעט:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s איצט האט אַ לענג פון 2 און אַ קאַפּאַציטעט פון 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // זינט מיר האָבן שוין אַן עקסטרע 8 קאַפּאַציטעט, רופן דעם ...
    /// s.reserve_exact(8);
    ///
    /// // ... טוט נישט אַקשלי פאַרגרעסערן.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// פּרווון צו רעזערווירן די קאַפּאַציטעט פֿאַר בייַ מינדסטער `additional` מער עלעמענטן צו זיין ינסערטאַד אין די `String` געגעבן.
    /// די זאַמלונג קען רעזערווירן מער פּלאַץ צו ויסמיידן אָפט ריאַלאַקיישאַנז.
    /// נאָך רופן קס 01 קס, די קאַפּאַציטעט וועט זיין גרעסער ווי אָדער גלייַך צו קס 00 קס.
    /// טוט גאָרנישט אויב די קאַפּאַציטעט איז שוין גענוג.
    ///
    /// # Errors
    ///
    /// אויב די קאַפּאַציטעט אָוווערפלאָוז, אָדער די אַלאַקייטער ריפּאָרץ אַ דורכפאַל, אַ טעות איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // פאַר-רעזערווירן די זיקאָרן, אַרויסגאַנג אויב מיר קענען נישט
    ///     output.try_reserve(data.len())?;
    ///
    ///     // איצט מיר וויסן אַז דאָס קען נישט זיין OOM אין אונדזער קאָמפּלעקס אַרבעט
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// פרובירט צו רעזערווירן די מינימום קאַפּאַציטעט פֿאַר פּונקט `additional` מער עלעמענטן צו זיין ינסערטאַד אין די געגעבן `String`.
    ///
    /// נאָך רופן קס 01 קס, די קאַפּאַציטעט וועט זיין גרעסער ווי אָדער גלייַך צו קס 00 קס.
    /// טוט גאָרנישט אויב די קאַפּאַציטעט איז שוין גענוג.
    ///
    /// באַמערקונג אַז די אַלאַקייטער קען געבן די זאַמלונג מער פּלאַץ ווי עס ריקווייערז.
    /// דעריבער, די קאַפּאַציטעט קען נישט זיין רילייד צו זיין פּונקט מינימאַל.
    /// בעסער `reserve` אויב future ינסערשאַנז זענען געריכט.
    ///
    /// # Errors
    ///
    /// אויב די קאַפּאַציטעט אָוווערפלאָוז, אָדער די אַלאַקייטער ריפּאָרץ אַ דורכפאַל, אַ טעות איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // פאַר-רעזערווירן די זיקאָרן, אַרויסגאַנג אויב מיר קענען נישט
    ///     output.try_reserve(data.len())?;
    ///
    ///     // איצט מיר וויסן אַז דאָס קען נישט זיין OOM אין אונדזער קאָמפּלעקס אַרבעט
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// רעדוצירן די קאַפּאַציטעט פון דעם `String` צו זיין גלייך צו זיין לענג.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// שרינגקס די קאַפּאַציטעט פון דעם `String` מיט אַ נידעריקער גרענעץ.
    ///
    /// די קאַפּאַציטעט וועט זיין לפּחות ווי גרויס ווי די לענג און די סאַפּלייד ווערט.
    ///
    ///
    /// אויב די קראַנט קאַפּאַציטעט איז ווייניקער ווי דער נידעריקער שיעור, דאָס איז אַ ניט-אַפּ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// לייגט די געגעבן [`char`] צו די סוף פון די `String`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// קערט אַ בייט רעפטל פון דעם אינהאַלט פון דעם `סטרינג`.
    ///
    /// די פאַרקערט פון דעם אופֿן איז [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// קורץ דעם `String` צו די ספּעסאַפייד לענג.
    ///
    /// אויב קס 00 קס איז גרעסער ווי די שטריקל ס קראַנט לענג, דאָס האט קיין ווירקונג.
    ///
    ///
    /// באַמערקונג אַז דער אופֿן האט קיין ווירקונג אויף די אַלאַקייטיד קאַפּאַציטעט פון דער שטריקל
    ///
    /// # Panics
    ///
    /// Panics אויב `new_len` איז נישט אויף אַ [`char`] גרענעץ.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// רימוווז די לעצטע כאַראַקטער פון די שטריקל באַפער און קערט עס צוריק.
    ///
    /// קערט [`None`] אויב דעם `String` איז ליידיק.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// רימוווז אַ [`char`] פֿון דעם `String` ביי בייט שטעלע און קערט עס צוריק.
    ///
    /// דאָס איז אַן *O*(*n*) אָפּעראַציע, ווייַל עס דאַרף קאַפּיינג יעדער עלעמענט אין די באַפער.
    ///
    /// # Panics
    ///
    /// Panics אויב `idx` איז גרעסער ווי אָדער גלייַך צו די 'שטריקל' לענג, אָדער אויב עס איז נישט אויף אַ [`char`] גרענעץ.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// אַראָפּנעמען אַלע שוועבעלעך פון מוסטער קס 01 קס אין די קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// שוועבעלעך וועט זיין דיטעקטאַד און יטראַטיוולי אַוועקגענומען, אַזוי אין קאַסעס ווען פּאַטערנז אָוווערלאַפּ, בלויז דער ערשטער מוסטער וועט ווערן אַוועקגענומען:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // זיכערהייט: אָנהייב און סוף וועט זיין אויף די utf8 בייט באַונדריז פּער
        // די סעאַרטשער דאָקס
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// ריטיינז בלויז די אותיות וואָס זענען באַשטימט דורך דעם פּרעדיקאַט.
    ///
    /// אין אנדערע ווערטער, אַראָפּנעמען אַלע אותיות קס 01 קס אַזוי אַז קס 02 קס קערט קס 00 קס.
    /// דער אופֿן אַפּערייץ אין פּלאַץ, באזוכט יעדער כאַראַקטער פּונקט אַמאָל אין דער אָריגינעל סדר און פּרעזערווייז די סדר פון די ריטיינד אותיות.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// די פּינטלעך סדר קען זיין נוציק פֿאַר טראַקינג פונדרויסנדיק שטאַט, ווי אַן אינדעקס.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // פונט ידקס צו דער ווייַטער טשאַר
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// ינסערט אַ כאַראַקטער אין דעם `String` ביי בייט שטעלע.
    ///
    /// דאָס איז אַן *O*(*n*) אָפּעראַציע ווי עס ריקווייערז קאַפּיינג יעדער עלעמענט אין די באַפער.
    ///
    /// # Panics
    ///
    /// Panics אויב `idx` איז גרעסער ווי די 'שטריקל' ס לענג, אָדער אויב עס איז נישט אויף אַ [`char`] גרענעץ.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// ינסערט אַ שטריקל רעפטל אין דעם `String` ביי בייט שטעלע.
    ///
    /// דאָס איז אַן *O*(*n*) אָפּעראַציע ווי עס ריקווייערז קאַפּיינג יעדער עלעמענט אין די באַפער.
    ///
    /// # Panics
    ///
    /// Panics אויב `idx` איז גרעסער ווי די 'שטריקל' ס לענג, אָדער אויב עס איז נישט אויף אַ [`char`] גרענעץ.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// קערט אַ מיוטאַבאַל רעפֿערענץ צו די אינהאַלט פון דעם `String`.
    ///
    /// # Safety
    ///
    /// די פֿונקציע איז אַנסייף ווייַל עס קען נישט קאָנטראָלירן אַז די ביטעס צו עס זענען גילטיק UTF-8.
    /// אויב דעם קאַנסטריינט איז ווייאַלייטיד, עס קען פאַרשאַפן זיקאָרן ונסאַפעטי ישוז מיט future ניצערס פון די `String`, ווייַל די מנוחה פון דער נאָרמאַל ביבליאָטעק אַסומז אַז `String`s זענען גילטיק UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// קערט די לענג פון דעם `String`, אין ביטעס, נישט [`char`] אָדער גראַפעמעס.
    /// אין אנדערע ווערטער, עס קען נישט זיין וואָס אַ מענטש האלט די לענג פון די שטריקל.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// קערט `true` אויב די `String` האט אַ לענג פון נול, און `false` אַנדערש.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ספּליץ די שטריקל אין צוויי ביי די געגעבן בייט אינדעקס.
    ///
    /// רעטורנס אַ ניי אַלאַקייטיד קס 00 קס.
    /// `self` כּולל ביטעס קס 01 קס, און די אומגעקערט קס 02 קס כּולל ביטעס קס 00 קס.
    /// `at` מוזן זיין אויף די גרענעץ פון אַ UTF-8 קאָד פונט.
    ///
    /// באַמערקונג אַז די X00 קס קאַפּאַציטעט טוט נישט טוישן.
    ///
    /// # Panics
    ///
    /// Panics אויב `at` איז נישט אויף אַ `UTF-8` קאָד פונט גרענעץ, אָדער אויב עס איז ווייַטער פון די לעצטע קאָד פונט פון די שטריקל.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// טרונקאַטעס דעם קס 00 קס, רימוווינג אַלע אינהאַלט.
    ///
    /// בשעת דעם מיטל `String` וועט האָבן אַ לענג פון נול, אָבער ער קען נישט אָנרירן די קאַפּאַציטעט.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// קרעאַטעס אַ דריינינג יטעראַטאָר אַז רימוווז די ספּעסאַפייד קייט אין די קס 01 קס און ייעלדס די אַוועקגענומען קס 00 קס.
    ///
    ///
    /// Note: די עלעמענט קייט איז אַוועקגענומען אפילו אויב די יטעראַטאָר איז נישט קאַנסומד ביז דעם סוף.
    ///
    /// # Panics
    ///
    /// Panics אויב די סטאַרטינג פונט אָדער סוף פונט טאָן ניט ליגן אויף אַ [`char`] גרענעץ, אָדער אויב זיי זענען אויס פון גווול.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // אַראָפּנעמען די קייט ביז די β פֿון די שטריקל
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // א גאַנץ קייט קלירז די שטריקל
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // זכּרון זיכערקייַט
        //
        // די סטרינג ווערסיע פון Drain האט נישט די זכּרון זיכערקייַט ישוז פון די vector ווערסיע.
        // די דאַטן זענען נאָר קלאָר ביטעס.
        // ווייַל די קייט באַזייַטיקונג כאַפּאַנז אין דראָפּ, אויב די Drain יטעראַטאָר איז ליקט, די באַזייַטיקונג וועט נישט פּאַסירן.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // נעמען צוויי סיימאַלטייניאַס באַראָוז.
        // די &mut סטרינג וועט ניט זיין אַקסעסט ביז יטעראַטיאָן איז איבער, אין דראָפּ.
        let self_ptr = self as *mut _;
        // זיכערקייט: קס 00 קס און קס 01 קס טאָן די צונעמען גווול טשעקס.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// רימוווז די ספּעסאַפייד קייט אין די שטריקל און ריפּלייסיז עס מיט די געגעבן שטריקל.
    /// די געגעבן שטריקל דאַרף נישט זיין די זעלבע לענג ווי די קייט.
    ///
    /// # Panics
    ///
    /// Panics אויב די סטאַרטינג פונט אָדער סוף פונט טאָן ניט ליגן אויף אַ [`char`] גרענעץ, אָדער אויב זיי זענען אויס פון גווול.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // פאַרבייַטן די קייט ביז די β פֿון די שטריקל
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // זכּרון זיכערקייַט
        //
        // Replace_range האט נישט די זיכערהייט ישוז פון זכּרון פון אַ vector Splice.
        // פון די vector ווערסיע.די דאַטן זענען נאָר קלאָר ביטעס.

        // ווארענונג: ינליינינג די בייַטעוודיק וואָלט זיין ניט געזונט (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ווארענונג: ינליינינג די בייַטעוודיק וואָלט זיין ניט געזונט (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // ניצן `range` ווידער וואָלט זיין ומבאַקוועם (#81138) מיר יבערנעמען אַז די `range` געמאלדן גווול בלייבן די זעלבע, אָבער אַ קעגנעריש ימפּלאַמענטיישאַן קען טוישן צווישן רופט
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// קאָנווערט דעם `String` אין אַ [`Box`]`<`[`str`] `>`.
    ///
    /// דאָס וועט פאַלן קיין וידעפדיק קאַפּאַציטעט.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// רעטורנס אַ רעפטל פון [`u8`] s ביטעס וואָס זענען געפרוווט צו בייַטן צו אַ `String`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // עטלעכע פאַרקריפּלט ביטעס אין אַ ז 0 וועקטאָר 0 ז
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// רעטורנס די ביטעס וואָס זענען געפרוווט צו בייַטן צו אַ `String`.
    ///
    /// דעם אופֿן איז קערפאַלי קאַנסטראַקטאַד צו ויסמיידן אַלאַקיישאַן.
    /// עס וועט פאַרנוצן דעם טעות און מאָווינג די ביטעס אַזוי אַז אַ קאָפּיע פון די ביטעס טאָן ניט דאַרפֿן צו מאַכן.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // עטלעכע פאַרקריפּלט ביטעס אין אַ ז 0 וועקטאָר 0 ז
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// ברענגען אַ `Utf8Error` צו באַקומען מער דעטאַילס וועגן די קאַנווערזשאַן דורכפאַל.
    ///
    /// די [`Utf8Error`] טיפּ צוגעשטעלט דורך [`std::str`] רעפּראַזענץ אַ טעות וואָס קען פּאַסירן ווען קאַנווערטינג אַ רעפטל פון [`u8`] s צו אַ [`&str`].
    /// אין דעם זינען, עס איז אַן אַנאַלאָג צו `FromUtf8Error`.
    /// פֿאַר מער דעטאַילס וועגן די נוצן פון דעם, זען די דאָקומענטאַטיאָן.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // עטלעכע פאַרקריפּלט ביטעס אין אַ ז 0 וועקטאָר 0 ז
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // דער ערשטער ביטע איז פאַרקריפּלט דאָ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ווייַל מיר יטערירן איבער `סטרינג`ס, מיר קענען ויסמיידן לפּחות איין אַלאַקיישאַן דורך באַקומען די ערשטער שטריקל פון די יטעראַטאָר און צוגעבן עס אַלע די סאַבסאַקוואַנט סטרינגס.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ווייַל מיר יבערקוקן קאָווס, מיר קענען קקסנומקסקס ויסמיידן לפּחות איין אַלאַקיישאַן דורך באַקומען די ערשטער נומער און צוגעבן אַלע די סאַבסאַקוואַנט זאכן.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// א קאַנוויניאַנס ימפּ וואָס דעלאַגייץ צו די `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// קרעאַטעס אַ ליידיק קס 00 קס.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// ימפּלאַמאַנץ די `+` אָפּעראַטאָר פֿאַר קאַנקאַטאַנייטינג צוויי סטרינגס.
///
/// דעם קאַנסומז די `String` אויף די לינקס זייַט און ניצט זיין באַפער (גראָוינג עס אויב נייטיק).
/// דאָס איז דורכגעקאָכט צו ויסמיידן אַ נייַע קס 00 קס און קאַפּיינג די גאנצע אינהאַלט אויף יעדער אָפּעראַציע, וואָס קען פירן צו די *אָ*(*n*^ 2) צייט ווען איר בויען אַ *n*-בייט שטריקל דורך ריפּיטיד קאַנקאַטאַניישאַן.
///
///
/// די שטריקל אויף די רעכט זייַט איז בלויז באַראָוד;די אינהאַלט איז קאַפּיד אין די X00 קס אומגעקערט.
///
/// # Examples
///
/// קאַנקאַטאַנייטינג צוויי `סטרינגס 'נעמט די ערשטער דורך ווערט און באַראָוז די רגע:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` איז אריבערגעפארן און קענען ניט מער זיין געניצט דאָ.
/// ```
///
/// אויב איר ווילן צו האַלטן די ערשטער `String`, איר קענען קלאָון עס און צולייגן צו די קלאָון אַנשטאָט:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` איז נאָך גילטיק דאָ.
/// ```
///
/// קאַנקאַטאַנייטינג קס 01 קס סלייסאַז קענען זיין דורכגעקאָכט דורך קאַנווערטינג די ערשטער צו אַ קס 00 קס:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// ימפּלאַמאַנץ די קס 01 קס אָפּעראַטאָר צו אַפּפּענדינג צו אַ קס 00 קס.
///
/// דאָס איז דער זעלביקער נאַטור ווי די [`push_str`][String::push_str] אופֿן.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// א טיפּ אַליאַס פֿאַר קס 00 קס.
///
/// דער אַליאַס יגזיסץ פֿאַר קאַפּויער קאַמפּאַטאַבילאַטי און קען יווענטשאַוואַלי דיפּרישיייטיד.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// א ז 0 טראַט 0 ז פֿאַר קאַנווערטינג אַ ווערט צו אַ קס 00 קס.
///
/// די trait איז אויטאָמאַטיש ימפּלאַמענאַד פֿאַר קיין טיפּ וואָס ימפּלאַמאַנץ די [`Display`] trait.
/// ווי אַזאַ, `ToString` זאָל נישט זיין ימפּלאַמענאַד גלייַך:
/// [`Display`] זאָל זיין ימפּלאַמענאַד אַנשטאָט, און איר באַקומען די `ToString` ימפּלאַמענטיישאַן פֿאַר פריי.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// קאָנווערט די געגעבן ווערט צו אַ `String`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// אין דעם ימפּלאַמענטיישאַן, די `to_string` אופֿן panics אויב די `Display` ימפּלאַמענטיישאַן קערט אַ טעות.
/// דעם ינדיקייץ אַ פאַלש קס 00 קס ימפּלאַמענטיישאַן זינט קס 01 קס קיינמאָל קערט אַ טעות זיך.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // א פּראָסט גיידליין איז צו נישט ינלענדיש דזשאַנעריק פאַנגקשאַנז.
    // אָבער, רימוווינג `#[inline]` פֿון דעם אופֿן ז ניט נעגלאַדזשאַבאַל ראַגרעשאַנז.
    // זען קס 00 קס, די לעצטע פּרווון צו פּרובירן צו באַזייַטיקן עס.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// קאָנווערט אַ `&mut str` אין אַ `String`.
    ///
    /// דער רעזולטאַט איז אַלאַקייטיד אויף די קופּע.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: פּרובירן פּולז ליבסטד, וואָס ז ערראָרס דאָ
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// קאָנווערץ די געגעבן קעסטל קס 01 קס רעפטל צו אַ קס 00 קס.
    /// עס איז נאָוטאַבאַל אַז די `str` רעפטל איז אָונד.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// קאַנווערץ די געגעבן `String` צו אַ קעסטל `str` רעפטל וואָס איז אָונד.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// קאַנווערץ אַ שטריקל רעפטל אין אַ באָרראָוועד וואַריאַנט.
    /// קיין קופּע אַלאַקיישאַן איז דורכגעקאָכט און די שטריקל איז נישט קאַפּיד.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// קאַנווערץ אַ שטריקל אין אַן אָוניידיד וואַריאַנט.
    /// קיין קופּע אַלאַקיישאַן איז דורכגעקאָכט און די שטריקל איז נישט קאַפּיד.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// קאַנווערץ אַ שטריקל באַווייַזן אין אַ באַראָוד וואַריאַנט.
    /// קיין קופּע אַלאַקיישאַן איז דורכגעקאָכט און די שטריקל איז נישט קאַפּיד.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// קאַנווערץ די געגעבן קס 01 קס צו אַ ז 0 וועקטאָר 0 ז קס 02 קס וואָס כּולל וואַלועס פון טיפּ קס 00 קס.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// א דריינינג יטעראַטאָר פֿאַר קס 00 קס.
///
/// די סטרוקטור איז באשאפן דורך די [`drain`] אופֿן אויף [`String`].
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// וועט ווערן גענוצט ווי&'אַ מוט סטרינג אין די דעסטרוקטאָר
    string: *mut String,
    /// אָנהייב פון טייל צו באַזייַטיקן
    start: usize,
    /// סוף פון די טייל צו באַזייַטיקן
    end: usize,
    /// קראַנט רוען קייט צו באַזייַטיקן
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // ניצן Vec::drain.
            // "Reaffirm" די גרענעץ טשעקס צו ויסמיידן אַז די panic קאָד איז ינסערטאַד ווידער.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// קערט די רוען (סאַב) שטריקל פון דעם יטעראַטאָר ווי אַ רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: ונקאָממענט AsRef ימפּלייז ונטער ווען סטייבאַלייזינג.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// ונקאָממענט ווען סטייבאַלייזינג `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// ימפּ <'אַ> אַסרעף<str>פֿאַר Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// ימפּ <'אַ> AsRef <[u8]> פֿאַר Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}