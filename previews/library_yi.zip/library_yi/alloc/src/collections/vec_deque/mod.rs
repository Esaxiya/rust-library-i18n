//! א ריי מיט טאָפּל-ענדאַד ימפּלאַמענאַד מיט אַ גראָוינג רינג באַפער.
//!
//! די ריי האט *אָ*(1) אַמערייזד ינסערץ און רימווואַלז פֿון ביידע ענדס פון דעם קאַנטיינער.
//! עס אויך האט *O*(1) ינדעקסינג ווי אַ vector.
//! די קאַנטיינד עלעמענטן זענען נישט פארלאנגט צו זיין קאַפּייאַבאַל, און די ריי וועט זיין סענדאַבאַל אויב די קאַנטיינד טיפּ איז סענדאַבאַל.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // גרעסטע מעגלעך מאַכט פון צוויי

/// א ריי מיט טאָפּל-ענדאַד ימפּלאַמענאַד מיט אַ גראָוינג רינג באַפער.
///
/// די "default" באַניץ פון דעם טיפּ ווי אַ ריי איז צו נוצן [`push_back`] צו לייגן צו די ריי, און [`pop_front`] צו באַזייַטיקן די ריי.
///
/// [`extend`] און קס 00 קס שטופּן אויף דעם צוריק אין דעם שטייגער, און יטערייטינג איבער קס 01 קס גייט פראָנט צו צוריק.
///
/// זינט `VecDeque` איז אַ רינג באַפער, די עלעמענטן זענען נישט דאַווקע קאַנטיגיואַס אין זכּרון.
/// אויב איר ווילן צו אַקסעס די עלעמענטן ווי אַ איין רעפטל, אַזאַ ווי פֿאַר עפעקטיוו סאָרטינג, איר קענען נוצן [`make_contiguous`].
/// עס ראָוטייץ די קס 00 קס אַזוי אַז די עלעמענטן טאָן ניט ייַנוויקלען, און קערט אַ מיוטאַבאַל רעפטל צו די איצט קאַנטיגיואַס עלעמענט סיקוואַנס.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // עק און קאָפּ זענען פּוינטערז אין די באַפער.
    // עק שטענדיק ווייזט צו דער ערשטער עלעמענט וואָס קען זיין לייענען, קאָפּ שטענדיק ווייזט וואו דאַטן זאָל זיין געשריבן.
    //
    // אויב עק==קאָפּ די באַפער איז ליידיק.די לענג פון די רינגבופפער איז דיפיינד ווי די ווייַטקייט צווישן די צוויי.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// לויפט די דעסטרוקטאָר פֿאַר אַלע זאכן אין די רעפטל ווען עס דראַפּט (נאָרמאַלי אָדער בעשאַס אַנוויינדינג).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // נוצן קאַפּ פֿאַר קס 00 קס
            ptr::drop_in_place(front);
        }
        // RawVec כאַנדאַלז דילאַליישאַן
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// קרעאַטעס אַ ליידיק קס 00 קס.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// מאַרדזשאַנאַלי מער באַקוועם
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// מאַרדזשאַנאַלי מער באַקוועם
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // פֿאַר נול סייזד טייפּס, מיר זענען שטענדיק ביי מאַקסימום קאַפּאַציטעט
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// דרייען פּטר אין אַ רעפטל
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// דרייען פּטר אין אַ מוט רעפטל
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// באוועגט אַן עלעמענט אויס פון די באַפער
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// שרייבט אַן עלעמענט אין די באַפער און מאָווינג עס.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// קערט `true` אויב די באַפער איז פול קאַפּאַציטעט.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// קערט דער אינדעקס אין די אַנדערלייינג באַפער פֿאַר אַ געגעבן לאַדזשיקאַל עלעמענט אינדעקס.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// קערט דער אינדעקס אין די אַנדערלייינג באַפער פֿאַר אַ געגעבן לאַדזשיקאַל עלעמענט אינדעקס + אַדדענד.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// קערט דער אינדעקס אין די אַנדערלייינג באַפער פֿאַר אַ געגעבן לאַדזשיקאַל עלעמענט אינדעקס, סובטראַהענד.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// קאפיעס אַ קאַנטיגיואַס זיקאָרן בלאָק לאַנג פֿון sc צו DST
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// קאפיעס אַ קאַנטיגיואַס זיקאָרן בלאָק לאַנג פֿון sc צו DST
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// קאַפּיז אַ פּאַטענטשאַלי ראַפּינג זיקאָרן בלאָק לאַנג פֿון ז 0 סרק 0 ז צו דעסט.
    /// (abs(dst - src) + len) מוזן נישט זיין גרעסער ווי cap() (עס מוזן זיין מאַקסימום איין קעסיידערדיק אָוווערלאַפּינג געגנט צווישן src און דעסט).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // ז 0 סרק 0 ז טוט נישט ייַנוויקלען, דסט טוט נישט ייַנוויקלען
                //
                //        ס...
                // 1 קס 00 קס
                // 2 קס 00 קס ד.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // דסט איידער ז 0 סרק 0 ז, ז 0 סרק 0 ז טוט נישט ייַנוויקלען, דסט ראַפּס
                //
                //
                //    ס...
                // 1 קס 00 קס
                // 2 קס 00 קס
                // 3 קס 00 קס .. ד.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // ז 0 סרק 0 ז איידער דסט, ז 0 סרק 0 ז נישט ייַנוויקלען, דסט ראַפּס
                //
                //
                //              ס...
                // 1 קס 00 קס
                // 2 קס 00 קס
                // 3 קס 00 קס .. ד.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // דסט איידער ז 0 סרק 0 ז, ז 0 סרק 0 ז ראַפּס, דסט טוט נישט ייַנוויקלען
                //
                //
                //    .. S.
                // 1 קס 00 קס
                // 2 קס 00 קס
                // 3 קס 00 קס די...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // ז 0 סרק 0 ז איידער דסט, ז 0 סרק 0 ז ראַפּס, דסט טוט נישט ייַנוויקלען
                //
                //
                //    .. S.
                // 1 קס 00 קס
                // 2 קס 00 קס
                // 3 קס 00 קס די...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // דסט איידער ז 0 סרק 0 ז, ז 0 סרק 0 ז ראַפּס, דסט ראַפּס
                //
                //
                //    ... S.
                // 1 קס 00 קס
                // 2 קס 00 קס
                // 3 קס 00 קס
                // 4 קס 00 קס .. ד..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // ז 0 סרק 0 ז איידער דסט, ז 0 סרק 0 ז ראַפּס, דסט ראַפּס
                //
                //
                //    .. S..
                // 1 קס 00 קס
                // 2 קס 00 קס
                // 3 קס 00 קס
                // 4 קס 00 קס... ד.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// פראָבס די קאָפּ און עק סעקשאַנז אַרום צו האַנדלען מיט די פאַקט אַז מיר נאָר ריאַלאַקייטיד.
    /// אַנסייף ווייַל עס טראַסץ old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // מאַך די שאָרטיסט קאַנטיגיואַס אָפּטיילונג פון די רינג באַפער טה
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] הט
        //   [o o . o o o o o ]
        //          THB [...אָאָאָאָאָאָאָ......
        //          ] הט
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // א נאָפּ
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// קרעאַטעס אַ ליידיק קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// קרעאַטעס אַ ליידיק קס 00 קס מיט פּלאַץ פֿאַר לפּחות קס 01 קס עלעמענטן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // + 1 זינט די רינגבופפער שטענדיק לאָזן איין אָרט ליידיק
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// גיט אַ דערמאָנען צו די עלעמענט אין דער געגעבן אינדעקס.
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// פּראָווידעס אַ מיוטאַבאַל דערמאָנען צו דעם עלעמענט אין דער געגעבן אינדעקס.
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// סוואַפּס עלעמענטן ביי ינדאַסיז קס 01 קס און קס 00 קס.
    ///
    /// `i` און `j` קען זיין גלייַך.
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Panics
    ///
    /// Panics אויב יעדער אינדעקס איז אויס פון גווול.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// קערט די נומער פון עלעמענטן וואָס `VecDeque` קענען האַלטן אָן ריאַלאַקייטינג.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// רעסערוועס די מינימום קאַפּאַציטעט פֿאַר פּונקט `additional` מער עלעמענטן צו זיין ינסערטאַד אין די געגעבן `VecDeque`.
    /// טוט גאָרנישט אויב די קאַפּאַציטעט איז שוין גענוג.
    ///
    /// באַמערקונג אַז די אַלאַקייטער קען געבן די זאַמלונג מער פּלאַץ ווי עס ריקווייערז.
    /// דעריבער, די קאַפּאַציטעט קען נישט זיין רילייד צו זיין פּונקט מינימאַל.
    /// בעסער [`reserve`] אויב future ינסערשאַנז זענען געריכט.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט אָוווערפלאָוז `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// רעסערוועס קאַפּאַציטעט פֿאַר לפּחות קס 01 קס מער עלעמענטן צו זיין ינסערטאַד אין די געגעבן קס 00 קס.
    /// די זאַמלונג קען רעזערווירן מער פּלאַץ צו ויסמיידן אָפט ריאַלאַקיישאַנז.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט אָוווערפלאָוז `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// פרובירט צו רעזערווירן די מינימום קאַפּאַציטעט פֿאַר פּונקט `additional` מער עלעמענטן צו זיין ינסערטאַד אין די געגעבן `VecDeque<T>`.
    ///
    /// נאָך רופן קס 01 קס, די קאַפּאַציטעט וועט זיין גרעסער ווי אָדער גלייַך צו קס 00 קס.
    /// טוט גאָרנישט אויב די קאַפּאַציטעט איז שוין גענוג.
    ///
    /// באַמערקונג אַז די אַלאַקייטער קען געבן די זאַמלונג מער פּלאַץ ווי עס ריקווייערז.
    /// דעריבער, די קאַפּאַציטעט קען נישט זיין רילייד צו זיין פּונקט מינימאַל.
    /// בעסער `reserve` אויב future ינסערשאַנז זענען געריכט.
    ///
    /// # Errors
    ///
    /// אויב די קאַפּאַציטעט אָוווערפלאָוז `usize`, אָדער די אַלאַקייטער ריפּאָרץ אַ דורכפאַל, אַ טעות איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // פאַר-רעזערווירן די זיקאָרן, אַרויסגאַנג אויב מיר קענען נישט
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // איצט מיר וויסן אַז דאָס קען נישט קסקסנומקסקס אין אונדזער קאָמפּלעקס אַרבעט
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // זייער קאָמפּליצירט
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// פּרווון צו רעזערווירן די קאַפּאַציטעט פֿאַר בייַ מינדסטער `additional` מער עלעמענטן צו זיין ינסערטאַד אין די `VecDeque<T>` געגעבן.
    /// די זאַמלונג קען רעזערווירן מער פּלאַץ צו ויסמיידן אָפט ריאַלאַקיישאַנז.
    /// נאָך רופן קס 01 קס, די קאַפּאַציטעט וועט זיין גרעסער ווי אָדער גלייַך צו קס 00 קס.
    /// טוט גאָרנישט אויב די קאַפּאַציטעט איז שוין גענוג.
    ///
    /// # Errors
    ///
    /// אויב די קאַפּאַציטעט אָוווערפלאָוז `usize`, אָדער די אַלאַקייטער ריפּאָרץ אַ דורכפאַל, אַ טעות איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // פאַר-רעזערווירן די זיקאָרן, אַרויסגאַנג אויב מיר קענען נישט
    ///     output.try_reserve(data.len())?;
    ///
    ///     // איצט מיר וויסן אַז דאָס קען נישט זיין OOM אין אונדזער קאָמפּלעקס אַרבעט
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // זייער קאָמפּליצירט
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// שרינגקס די קאַפּאַציטעט פון די `VecDeque` ווי פיל ווי מעגלעך.
    ///
    /// עס וועט פאַלן אַראָפּ ווי נאָענט ווי מעגלעך צו די לענג, אָבער די אַלאַקייטער קען נאָך אָנזאָגן די `VecDeque` אַז עס איז פּלאַץ פֿאַר אַ ביסל מער עלעמענטן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// רעדוצירן די קאַפּאַציטעט פון די `VecDeque` מיט אַ נידעריקער גרענעץ.
    ///
    /// די קאַפּאַציטעט וועט זיין לפּחות ווי גרויס ווי די לענג און די סאַפּלייד ווערט.
    ///
    ///
    /// אויב די קראַנט קאַפּאַציטעט איז ווייניקער ווי דער נידעריקער שיעור, דאָס איז אַ ניט-אַפּ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // מיר טאָן ניט האָבן צו זאָרג וועגן אַ לויפן, ווי `self.len()` אדער `self.capacity()` קענען קיינמאָל זיין `usize::MAX`.
        // + 1 ווי די רינגבופפער שטענדיק לאָזן איין אָרט ליידיק.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // עס זענען דריי קאַסעס פון אינטערעס:
            //   אַלע עלעמענטן זענען אויס פון געוואלט גווול. עלעמענטן זענען קאַנטיגיואַס, און קאָפּ איז אויס פון געוואלט גווול. עלעמענטן זענען דיסקאָנטיגואָוס, און עק איז אויס פון געוואלט גווול.
            //
            //
            // אין אַלע אנדערע צייט, עלעמענט שטעלעס זענען אַנאַפעקטיד.
            //
            // ינדיקייץ אַז עלעמענטן אין דער קאָפּ זאָל זיין אריבערגעפארן.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // מאַך עלעמענטן פֿון אויס פון געוואלט גווול (שטעלעס נאָך טאַרגעט_קאַפּ)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // הט
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// פאַרקירצט די קס 00 קס, בעכעסקעם די ערשטער קס 01 קס עלעמענטן און דראַפּינג די מנוחה.
    ///
    ///
    /// אויב קקסנומקסקס איז גרעסער ווי די קראַנט לענג פון 'וועקדקעק', דאָס איז קיין ווירקונג.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// לויפט די דעסטרוקטאָר פֿאַר אַלע זאכן אין די רעפטל ווען עס דראַפּט (נאָרמאַלי אָדער בעשאַס אַנוויינדינג).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // זיכער ווייַל:
        //
        // * קיין רעפטל וואָס איז דורכגעגאנגען צו קס 00 קס איז גילטיק;די רגע פאַל האט `len <= front.len()` און צוריקקומען אויף `len > self.len()` ינשורז `begin <= back.len()` אין דער ערשטער פאַל
        //
        // * די קאָפּ פון די VecDeque איז אריבערגעפארן איידער רופן `drop_in_place`, אַזוי קיין ווערט איז דראַפּט צוויי מאָל אויב `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // מאַכט זיכער אַז די רגע האַלב איז דראַפּט אפילו ווען אַ דעסטרוקטאָר אין דער ערשטער panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// קערט אַ פראָנט צו צוריק יטעראַטאָר.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// קערט אַ פראָנט-צו-צוריק יטעראַטאָר וואָס קערט מיוטאַבאַל באַווייַזן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // זיכערקייט: די ינערלעך `IterMut` זיכערקייַט ינוועריאַנט איז געגרינדעט ווייַל די
        // `ring` מיר מאַכן איז אַ דערעפערענקאַבלע רעפטל פֿאַר לעבן '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// קערט אַ פּאָר פון סלייסאַז וואָס כּולל, אין סדר, די אינהאַלט פון די `VecDeque`.
    ///
    /// אויב [`make_contiguous`] איז געווען פריער גערופֿן, אַלע `VecDeque` יסודות וועט זיין אין דער ערשטער רעפטל און די רגע רעפטל וועט זיין ליידיק.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// קערט אַ פּאָר פון סלייסאַז וואָס כּולל, אין סדר, די אינהאַלט פון די `VecDeque`.
    ///
    /// אויב [`make_contiguous`] איז געווען פריער גערופֿן, אַלע `VecDeque` יסודות וועט זיין אין דער ערשטער רעפטל און די רגע רעפטל וועט זיין ליידיק.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// קערט די נומער פון עלעמענטן אין די `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// קערט `true` אויב די `VecDeque` איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// קרעאַטעס אַ יטעראַטאָר וואָס קאָווערס די ספּעסאַפייד קייט אין די `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics אויב די סטאַרטינג פונט איז גרעסער ווי דער סוף פונט אָדער אויב דער סוף פונט איז גרעסער ווי די לענג פון vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // א פול קייט קאָווערס אַלע אינהאַלט
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // די שערד רעפֿערענץ וואָס מיר האָבן אין &self איז מיינטיינד אין די '_ פון יטער.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// קרעאַטעס אַ יטעראַטאָר וואָס קאָווערס די ספּעסיפיעד מיוטאַבאַל קייט אין די `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics אויב די סטאַרטינג פונט איז גרעסער ווי דער סוף פונט אָדער אויב דער סוף פונט איז גרעסער ווי די לענג פון vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // א פול קייט קאָווערס אַלע אינהאַלט
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // זיכערקייט: די ינערלעך `IterMut` זיכערקייַט ינוועריאַנט איז געגרינדעט ווייַל די
        // `ring` מיר מאַכן איז אַ דערעפערענקאַבלע רעפטל פֿאַר לעבן '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// קרעאַטעס אַ דריינינג יטעראַטאָר אַז רימוווז די ספּעסאַפייד קייט אין די `VecDeque` און ייעלדס די אַוועקגענומען ייטאַמז.
    ///
    /// באַמערקונג 1: די עלעמענט קייט איז אַוועקגענומען אפילו אויב די יטעראַטאָר איז נישט קאַנסומד ביז דעם סוף.
    ///
    /// באַמערקונג 2: עס איז ונספּעסיפיעד ווי פילע עלעמענטן זענען אַוועקגענומען פון די דעק, אויב די `Drain` ווערט איז נישט דראַפּט, אָבער די באָרגן עס האלט יקספּייערז (למשל רעכט צו `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב די סטאַרטינג פונט איז גרעסער ווי דער סוף פונט אָדער אויב דער סוף פונט איז גרעסער ווי די לענג פון vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // א גאַנץ קייט קלירז אַלע אינהאַלט
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // זכּרון זיכערקייַט
        //
        // ווען די Drain איז ערשטער באשאפן, די מקור דעק איז פאַרקירצט צו מאַכן זיכער אַז קיין וניניטיאַליזעד אָדער אריבערגעפארן פון עלעמענטן זענען בארעכטיגט אויב די דעסטראַקטאָר פון די Drain קיינמאָל געץ.
        //
        //
        // Drain וועט ויסמעקן די וואַלועס צו באַזייַטיקן.
        // ווען פאַרטיק, די רוען דאַטן וועט זיין קאַפּיד צוריק צו דעקן די לאָך, און די head/tail וואַלועס וועט זיין ריכטיק ריסטאָרד.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // די עלעמענטן פון די דעק זענען צעטיילט אין דריי סעגמאַנץ:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // ה=קס 00 קס;ה=קס 01 קס;ה=ז 0 דרינ_טאַיל 0 ז;ה=ז 0 דרינ_העאַד 0 ז
        //
        // מיר קראָם drain_tail ווי self.head און drain_head און self.head ווי אַפטער_טאַיל און אַפטער_העאַד אויף די Drain.
        // דאָס אויך סטרונקאַטעס די עפעקטיוו מענגע אַזוי אַז אויב די Drain איז ליקט, מיר האָבן פארגעסן די פּאָטענציעל אריבערגעפארן וואַלועס נאָך די drain.
        //
        //
        //        ט טה ה
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" וועגן די וואַלועס נאָך די אָנהייב פון די drain ביז די drain איז גאַנץ און די Drain דעסטרוקטאָר איז לויפן.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // קריטיש, מיר בלויז שאַפֿן שערד באַווייַזן פון `self` דאָ און לייענען פֿון אים.
                // מיר טאָן ניט שרייַבן צו `self` און ניט רעבאָר צו אַ מיוטאַבאַל רעפֿערענץ.
                // דעריבער די רוי טייַטל מיר באשאפן אויבן, פֿאַר קס 00 קס, בלייבט גילטיק.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// קלירז די `VecDeque`, רימוווינג אַלע וואַלועס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// קערט `true` אויב די `VecDeque` כּולל אַן עלעמענט גלייַך צו די געגעבן ווערט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// גיט אַ דערמאָנען צו די פראָנט עלעמענט, אָדער `None` אויב די `VecDeque` איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// גיט אַ מיוטאַבאַל דערמאָנען צו די פראָנט עלעמענט, אָדער `None` אויב די `VecDeque` איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// גיט אַ דערמאָנען צו די צוריק עלעמענט, אָדער `None` אויב די `VecDeque` איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// גיט אַ מיוטאַבאַל דערמאָנען צו די צוריק עלעמענט, אָדער `None` אויב די `VecDeque` איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// רימוווז דער ערשטער עלעמענט און קערט עס צוריק, אָדער `None` אויב די `VecDeque` איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// רימוווז די לעצטע עלעמענט פֿון די `VecDeque` און קערט עס צוריק, אָדער `None` אויב עס איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// פּרעפּענדס אַן עלעמענט צו די `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// אַפּפּענדס אַן עלעמענט אויף די צוריק פון די `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: זאָל מיר באַטראַכטן `head == 0` צו מיינען
        // אַז קקסנומקסקס איז קאַנטיגיואַס?
        self.tail <= self.head
    }

    /// רימוווז אַן עלעמענט פֿון ערגעץ אין די `VecDeque` און קערט עס, ריפּלייסט עס מיט דער ערשטער עלעמענט.
    ///
    ///
    /// דאָס קען נישט האַלטן אָרדערינג, אָבער *O*(1).
    ///
    /// קערט `None` אויב `index` איז אויס פון גווול.
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// רימוווז אַן עלעמענט פֿון ערגעץ אין די `VecDeque` און קערט עס, ריפּלייסט עס מיט די לעצטע עלעמענט.
    ///
    ///
    /// דאָס קען נישט האַלטן אָרדערינג, אָבער *O*(1).
    ///
    /// קערט `None` אויב `index` איז אויס פון גווול.
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// ינסערט אַן `index` עלעמענט אין די `VecDeque`, און שיפט אַלע עלעמענטן מיט ינדעקסיז גרעסער ווי אָדער גלייַך צו `index` צו די צוריק.
    ///
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Panics
    ///
    /// Panics אויב `index` איז גרעסער ווי די 'VecDeque' ס לענג
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // מאַך די מינדסטער נומער פון עלעמענטן אין די רינג באַפער און אַרייַן די געגעבן כייפעץ
        //
        // מערסטנס len/2, 1 יסודות וועט זיין אריבערגעפארן. O(min(n, n-i))
        //
        // עס זענען דריי הויפּט קאַסעס:
        //  עלעמענטן זענען קאַנטיגיואַס
        //      - ספּעציעל פאַל ווען עק איז 0 עלעמענטן זענען דיסקאָנטיגואָוס און די ינסערט איז אין די עק אָפּטיילונג עלעמענטן זענען דיסקאָנטיגואָוס און די ינסערט איז אין די קאָפּ אָפּטיילונג
        //
        //
        // פֿאַר יעדער פון זיי, עס זענען צוויי קאַסעס:
        //  ינסערט איז נעענטער צו עק ינסערט איז נעענטער צו די קאָפּ
        //
        // שליסל: ה, קס 00 קס
        //      T, self.tail o, גילטיק עלעמענט I, ינסערשאַן עלעמענט A, די עלעמענט זאָל זיין נאָך די ינסערשאַן פונט M, ינדיקייץ עלעמענט איז אריבערגעפארן
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [א אָאָאָאָאָאָ.......
                //      .
                //      .]
                //
                //                       הט
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // קאַנטיגיואַס, טאָן נעענטער צו עק:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // קאַנטיגיואַס, טאָן נאָענט צו עק און עק איז 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       הט
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // די עק איז שוין אריבערגעפארן, אַזוי מיר בלויז קאָפּיע `index - 1` עלעמענטן.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // קאַנטיגיואַס, טאָן נעענטער צו די קאָפּ:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // דיסקאָנטיגואָוס, ינסערט נעענטער צו עק, עק אָפּטיילונג:
                    //
                    //                   הטי
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   הט
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // דיסקאָנטיגואָוס, טאָן נעענטער צו די קאָפּ, עק אָפּטיילונג:
                    //
                    //           הטי
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             הט
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // קאָפּיע עלעמענטן אַרויף צו נייַ קאָפּ
                    self.copy(1, 0, self.head);

                    // קאָפּיע לעצט עלעמענט אין ליידיק אָרט אין דנאָ פון באַפער
                    self.copy(0, self.cap() - 1, 1);

                    // מאַך עלעמענטן פֿון ידקס צו סוף פאָרויס ניט אַרייַנגערעכנט ^ עלעמענט
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // דיסקאָנטיגואָוס, ינסערט איז נעענטער צו די עק, די קאָפּ אָפּטיילונג, און איז ביי אינדעקס נול אין די ינערלעך באַפער:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           הט
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // קאָפּיע עלעמענטן אַרויף צו נייַ עק
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // קאָפּיע לעצט עלעמענט אין ליידיק אָרט אין דנאָ פון באַפער
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // דיסקאָנטיגואָוס, שטעלן נעענטער צו עק, קאָפּ אָפּטיילונג:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           הט
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // קאָפּיע עלעמענטן אַרויף צו נייַ עק
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // קאָפּיע לעצט עלעמענט אין ליידיק אָרט אין דנאָ פון באַפער
                    self.copy(self.cap() - 1, 0, 1);

                    // מאַך עלעמענטן פֿון קס 00 קס צו ענדיקן פאָרויס ניט אַרייַנגערעכנט ^ עלעמענט
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // דיסקאָנטיגואָוס, טאָן נעענטער צו די קאָפּ, קאָפּ אָפּטיילונג:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     הט
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // די עק קען האָבן שוין טשיינדזשד אַזוי מיר דאַרפֿן צו רעאַלקיאַלייט
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// רימוווז און קערט די עלעמענט X1X פון די `VecDeque`.
    /// וועלכער סוף איז נעענטער צו די באַזייַטיקונג פונט וועט זיין אריבערגעפארן צו מאַכן פּלאַץ, און אַלע די אַפעקטיד עלעמענטן וועט זיין אריבערגעפארן צו נייַע שטעלעס.
    ///
    /// קערט `None` אויב `index` איז אויס פון גווול.
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // עס זענען דריי הויפּט קאַסעס:
        //  עלעמענטן זענען קאַנטיגיואַס עלעמענטן זענען דיסקאָנטיגואָוס און די באַזייַטיקונג איז אין די עק אָפּטיילונג. עלעמענטן זענען דיסקאָנטיגואָוס און די באַזייַטיקונג איז אין די קאָפּ אָפּטיילונג.
        //
        //      - ספּעציעל פאַל ווען עלעמענטן זענען טעקניקלי קאַנטיגיואַס, אָבער self.head =0
        //
        // פֿאַר יעדער פון זיי, עס זענען צוויי קאַסעס:
        //  ינסערט איז נעענטער צו עק ינסערט איז נעענטער צו די קאָפּ
        //
        // שליסל: ה, קס 00 קס
        //      T, self.tail o, גילטיק עלעמענט x, עלעמענט אָפּגעמערקט פֿאַר באַזייַטיקונג R, ינדיקייץ עלעמענט וואָס איז אַוועקגענומען M, ינדיקייץ עלעמענט איז אריבערגעפארן
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // קאַנטיגיואַס, אַראָפּנעמען נעענטער צו עק:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // קאַנטיגיואַס, אַראָפּנעמען נעענטער צו די קאָפּ:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // דיסקאָנטיגואָוס, אַראָפּנעמען נעענטער צו עק, עק אָפּטיילונג:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   הט
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // דיסקאָנטיגואָוס, אַראָפּנעמען נעענטער צו קאָפּ, קאָפּ אָפּטיילונג:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   הט
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // דיסקאָנטיגואָוס, אַראָפּנעמען נעענטער צו די קאָפּ, עק אָפּטיילונג:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           הט
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // אָדער פּונקט-דיסקאָנטיגואָוס, אַראָפּנעמען ווייַטער צו די קאָפּ, עק אָפּטיילונג:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // ציען אין די עק אָפּטיילונג עלעמענטן
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // פּריווענץ אַנדערפלאָו.
                    if self.head != 0 {
                        // קאָפּיע ערשטער עלעמענט אין ליידיק אָרט
                        self.copy(self.cap() - 1, 0, 1);

                        // מאַך עלעמענטן אין די קאָפּ אָפּטיילונג קאַפּויער
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // דיסקאָנטיגואָוס, אַראָפּנעמען נעענטער צו עק, קאָפּ אָפּטיילונג:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           הט
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // ציען אין עלעמענטן אַרויף צו ידקס
                    self.copy(1, 0, idx);

                    // קאָפּיע לעצטע עלעמענט אין ליידיק אָרט
                    self.copy(0, self.cap() - 1, 1);

                    // מאַך עלעמענטן פֿון עק צו סוף פאָרויס, עקסקלודינג די לעצטע
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// ספּליץ די `VecDeque` אין צוויי אויף די געגעבן אינדעקס.
    ///
    /// רעטורנס אַ ניי אַלאַקייטיד קס 00 קס.
    /// `self` כּולל עלעמענטן קס 01 קס, און די אומגעקערט קס 02 קס כּולל עלעמענטן קס 00 קס.
    ///
    /// באַמערקונג אַז די X00 קס קאַפּאַציטעט טוט נישט טוישן.
    ///
    /// עלעמענט ביי אינדעקס 0 איז די פראָנט פון די ריי.
    ///
    /// # Panics
    ///
    /// ז 0 פּאַניקס 0 ז אויב קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` ליגט אין דער ערשטער העלפט.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // נאָר נעמען אַלע די רגע האַלב.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` ליגט אין די רגע האַלב, דאַרפֿן צו פאַקטאָר די עלעמענטן מיר סקיפּט אין דער ערשטער העלפט.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // רייניקונג ווו די ענדס פון די באַפערז זענען
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// מאַך אַלע די עלעמענטן פון קס 01 קס אין קס 00 קס, ליווינג קס 02 קס ליידיק.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ נומער פון עלעמענטן אין זיך אָוווערפלאָוז אַ `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // נאַיוו ימפּ
        self.extend(other.drain(..));
    }

    /// ריטיינז בלויז די עלעמענטן וואָס זענען באַשטימט דורך דעם פּרעדיקאַט.
    ///
    /// אין אנדערע ווערטער, אַראָפּנעמען אַלע עלעמענטן קס 00 קס אַזוי אַז קס 01 קס קערט פאַלש.
    /// דער אופֿן אַפּערייץ אין פּלאַץ, באזוכט יעדער עלעמענט פּונקט אַמאָל אין דער אָריגינעל סדר און קאַנסערווז די סדר פון די ריטיינד עלעמענטן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// די פּינטלעך סדר קען זיין נוציק פֿאַר טראַקינג פונדרויסנדיק שטאַט, ווי אַן אינדעקס.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // דאָס קען panic אָדער אַבאָרט
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // טאָפּל די באַפער גרייס.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// מאַדאַפייז די `VecDeque` אין-אָרט אַזוי אַז `len()` איז גלייַך צו קס 00 קס, אָדער דורך רימוווינג וידעפדיק עלעמענטן פון די צוריק אָדער דורך אַפּענדינג עלעמענטן דזשענערייטאַד דורך רופן `generator` צו די צוריק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// ריעריינדזשז די ינערלעך סטאָרידזש פון דעם דעק, אַזוי עס איז איין קאַנטיגיואַס רעפטל וואָס איז דערנאָך אומגעקערט.
    ///
    /// דער אופֿן איז נישט אַלאַקייטיד און טוט נישט טוישן די סדר פון די ינסערטאַד עלעמענטן.ווי עס קערט אַ מיוטאַבאַל רעפטל, דאָס קענען ווערן גענוצט צו סאָרט אַ דעק.
    ///
    /// אַמאָל די ינערלעך סטאָרידזש איז קאַנטיגיואַס, די [`as_slices`] און [`as_mut_slices`] מעטהאָדס וועט צוריקקומען די גאנצע אינהאַלט פון די `VecDeque` אין אַ איין רעפטל.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// סאָרטינג די אינהאַלט פון אַ דעק.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // סאָרטינג די דעק
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // סאָרטינג עס אין פאַרקערט סדר
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// באַקומען ימיוטאַבאַל אַקסעס צו די קאַנטיגיואַס רעפטל.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // מיר קענען איצט זיין זיכער אַז קס 01 קס כּולל אַלע עלעמענטן פון דער דעקע, און נאָך האָבן ימיוטאַבאַל אַקסעס צו קס 00 קס.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // עס איז גענוג פריי פּלאַץ צו נאָכמאַכן די עק אין איין גאַנג, דאָס מיינט אַז מיר ערשטער יבעררוק די קאָפּ קאַפּויער און דאַן נאָכמאַכן די עק צו די ריכטיק שטעלע.
            //
            //
            // פֿון: DEFGH .... אַבק
            // צו: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: מיר דערווייַל טאָן ניט באַטראַכטן .... אַבקדעפגה
            // צו זיין קאַנטיגיואַס ווייַל `head` וואָלט זיין `0` אין דעם פאַל.
            // כאָטש מיר מיסטאָמע וועלן צו טוישן דעם, עס איז נישט נישטיק, ווייַל אַ ביסל ערטער דערוואַרטן קס 01 קס צו מיינען אַז מיר קענען נאָר רעפטל ניצן קס 00 קס.
            //
            //

            // עס איז גענוג פריי פּלאַץ צו קאָפּירן די קאָפּ אין איין גאַנג, דאָס מיינט אַז מיר ערשטער יבעררוק די עק פֿאָרווערטס און דאַן נאָכמאַכן די קאָפּ צו די ריכטיק שטעלע.
            //
            //
            // פֿון: FGH .... ABCDE
            // צו: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // פּאָטער איז קלענערער ווי ביידע קאָפּ און עק, דאָס מיינט אַז מיר מוזן סלאָולי די עק און די קאָפּ.
            //
            //
            // פֿון: EFGHI ... ABCD אָדער HIJK.ABCDEFG
            // צו: ABCDEFGHI ... אָדער ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // די אַלגעמיינע פּראָבלעם קוקט ווי דעם GHIJKLM ... ABCDEF, איידער קיין סוואַפּס ABCDEFM ... GHIJKL, נאָך 1 פאָרן פון סוואַפּס ABCDEFGHIJM ... KL, ויסבייַטן ביז די לינקס edge ריטשאַז די טעמפּ קראָם
                //                  - דעמאָלט ריסטאַרט די אַלגערידאַם מיט אַ נייַ (smaller) קראָם מאל די טעמפּ קראָם איז ריטשט ווען די רעכט edge איז אין די סוף פון די באַפער, דאָס מיינט אַז מיר האָבן שלאָגן די רעכט סדר מיט ווייניקערע סוואַפּס!
                //
                // E.g
                // EF..ABCD ABCDEF .., נאָך פיר בלויז סוואַפּס מיר האָבן פאַרטיק
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// ראָוטייץ די צוויי-ענדיקט ריי `mid` ערטער צו די לינקס.
    ///
    /// Equivalently,
    /// - דרייען די נומער X00 קס אין דער ערשטער שטעלע.
    /// - פּאַפּס די ערשטער `mid` ייטאַמז און פּושיז זיי צו די סוף.
    /// - ראָטאַטעס `len() - mid` ערטער צו די רעכט.
    ///
    /// # Panics
    ///
    /// אויב קס 01 קס איז גרעסער ווי קס 00 קס.
    /// באַמערקונג אַז קס 00 קס טוט קס 01 קס ז 0 פּאַניק 0 ז און איז אַ ניט-אָפּ ראָוטיישאַן.
    ///
    /// # Complexity
    ///
    /// נעמט `*O*(min(mid, len() - mid))` צייט און קיין עקסטרע פּלאַץ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// ראָוטייץ די צוויי-ענדיקט ריי `k` ערטער צו די רעכט.
    ///
    /// Equivalently,
    /// - ראָוטייץ דער ערשטער נומער אין די שטעלע `k`.
    /// - פּאַפּס די לעצטע `k` ייטאַמז און פּושיז זיי צו די פראָנט.
    /// - ראָוטייץ קס 00 קס ערטער צו די לינקס.
    ///
    /// # Panics
    ///
    /// אויב קס 01 קס איז גרעסער ווי קס 00 קס.
    /// באַמערקונג אַז קס 00 קס טוט קס 01 קס ז 0 פּאַניק 0 ז און איז אַ ניט-אָפּ ראָוטיישאַן.
    ///
    /// # Complexity
    ///
    /// נעמט `*O*(min(k, len() - k))` צייט און קיין עקסטרע פּלאַץ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // זיכערהייט: די פאלגענדע צוויי מעטהאָדס דאַרפן די ראָוטיישאַן
    // זיין ווייניקער ווי העלפט די לענג פון די דעק.
    //
    // `wrap_copy` ריקווייערז אַז `min(x, cap() - x) + copy_len <= cap()`, אָבער `min` איז קיינמאָל מער ווי האַלב פון די קאַפּאַציטעט, ראַגאַרדלאַס פון X, אַזוי עס איז געזונט צו רופן דאָ ווייַל מיר רופן מיט עפּעס ווייניקער ווי האַלב פון די לענג, וואָס איז קיינמאָל העכער ווי האַלב פון די קאַפּאַציטעט.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// ביינערי אָנפֿרעגן דעם סאָרטירט `VecDeque` פֿאַר אַ געגעבן עלעמענט.
    ///
    /// אויב די ווערט איז געפֿונען, [`Result::Ok`] איז אומגעקערט מיט די אינדעקס פון די ריכטן עלעמענט.
    /// אויב עס זענען קייפל שוועבעלעך, יעדער פון די שוועבעלעך קען זיין אומגעקערט.
    /// אויב די ווערט איז ניט געפֿונען, [`Result::Err`] איז אומגעקערט מיט די אינדעקס וווּ אַ ריכטן עלעמענט קען זיין ינסערטאַד בשעת די סדר סדר.
    ///
    ///
    /// # Examples
    ///
    /// קוקט אַרויף אַ סעריע פון פיר עלעמענטן.
    /// דער ערשטער איז געפֿונען מיט אַ יינציק באשלאסן שטעלע;די רגע און דריט זענען נישט געפֿונען;די פערטע קען גלייַכן קיין שטעלע אין קס 00 קס.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// אויב איר ווילן צו שטעלן אַ נומער אין אַ סאָרטירט קס 00 קס, בשעת איר האַלטן די סאָרט סדר:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// ביינערי אָנפֿרעגן דעם סאָרטירט `VecDeque` מיט אַ קאָמפּאַראַטאָר פונקציע.
    ///
    /// דער קאָמפּאַראַטאָר פונקציע זאָל ינסטרומענט אַ סדר קאָנסיסטענט מיט די סאָרט סדר פון די אַנדערלייינג `VecDeque`, און צוריקקומען אַ סדר קאָד אַז ינדיקייץ צי דער אַרגומענט איז `Less`, `Equal` אָדער `Greater` ווי די געוואלט ציל.
    ///
    ///
    /// אויב די ווערט איז געפֿונען, [`Result::Ok`] איז אומגעקערט מיט די אינדעקס פון די ריכטן עלעמענט.אויב עס זענען קייפל שוועבעלעך, יעדער פון די שוועבעלעך קען זיין אומגעקערט.
    /// אויב די ווערט איז ניט געפֿונען, [`Result::Err`] איז אומגעקערט מיט די אינדעקס וווּ אַ ריכטן עלעמענט קען זיין ינסערטאַד בשעת די סדר סדר.
    ///
    /// # Examples
    ///
    /// קוקט אַרויף אַ סעריע פון פיר עלעמענטן.דער ערשטער איז געפֿונען מיט אַ יינציק באשלאסן שטעלע;די רגע און דריט זענען נישט געפֿונען;די פערטע קען גלייַכן קיין שטעלע אין קס 00 קס.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// ביינערי אָנפֿרעגן דעם סאָרטירט `VecDeque` מיט אַ שליסל יקסטראַקשאַן פונקציע.
    ///
    /// אַסומז אַז די `VecDeque` איז סאָרטירט דורך די שליסל, פֿאַר בייַשפּיל מיט [`make_contiguous().sort_by_key()`](#method.make_contiguous) ניצן די זעלבע שליסל יקסטראַקשאַן פונקציאָנירן.
    ///
    ///
    /// אויב די ווערט איז געפֿונען, [`Result::Ok`] איז אומגעקערט מיט די אינדעקס פון די ריכטן עלעמענט.
    /// אויב עס זענען קייפל שוועבעלעך, יעדער פון די שוועבעלעך קען זיין אומגעקערט.
    /// אויב די ווערט איז ניט געפֿונען, [`Result::Err`] איז אומגעקערט מיט די אינדעקס וווּ אַ ריכטן עלעמענט קען זיין ינסערטאַד בשעת די סדר סדר.
    ///
    /// # Examples
    ///
    /// קוקט אַרויף אַ סעריע פון פיר עלעמענטן אין אַ רעפטל פון פּערז סאָרטירט דורך זייער רגע עלעמענטן.
    /// דער ערשטער איז געפֿונען מיט אַ יינציק באשלאסן שטעלע;די רגע און דריט זענען נישט געפֿונען;די פערטע קען גלייַכן קיין שטעלע אין קס 00 קס.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// מאַדאַפייז די `VecDeque` אין-אָרט אַזוי אַז `len()` איז גלייַך צו new_len, אָדער דורך רימוווינג וידעפדיק עלעמענטן פון די צוריק אָדער דורך אַפּענדינג קלאָונז פון `value` צו די צוריק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// קערט דער אינדעקס אין די אַנדערלייינג באַפער פֿאַר אַ געגעבן לאַדזשיקאַל עלעמענט אינדעקס.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // גרייס איז שטענדיק אַ מאַכט פון 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// רעכענען די נומער פון עלעמענטן לינקס צו זיין לייענען אין די באַפער
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // גרייס איז שטענדיק אַ מאַכט פון 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // שטענדיק דיוויזאַבאַל אין דרייַ סעקשאַנז, פֿאַר בייַשפּיל: זיך: [a b c|d e f] אנדערע: [0 1 2 3|4 5] פראָנט=3, מיטן=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // עס איז ניט מעגלעך צו נוצן Hash::hash_slice אויף סלייסאַז אומגעקערט דורך אַס_ סלייסאַז אופֿן, ווייַל זייער לענג קענען זיין אַנדערש אין אַנדערש יידעניקאַל דעקוועס.
        //
        //
        // כאַשער נאָר געראַנטיז די עקוויוואַלענט פֿאַר די מעטהאָדס פּונקט די זעלבע שטעלן פון רופט.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// קאַנסומז די `VecDeque` אין אַ פראָנט-צו-צוריק יטעראַטאָר, וואָס גיט עלעמענטן דורך ווערט.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // די פֿונקציע זאָל זיין די מאָראַליש עקוויוואַלענט פון:
        //
        //      פֿאַר נומער אין iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// פֿון אַ [`Vec<T>`] אַ [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// דאָס אַוווידז ריאַלאָוקייטינג ווו מעגלעך, אָבער די באדינגונגען פֿאַר דעם זענען שטרענג און אונטערטעניק צו טוישן, און אַזוי זאָל ניט זיין רילייד אויף אויב די `Vec<T>` איז פֿון `From<VecDeque<T>>` און איז נישט ריאַלאַקייטיד.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // עס איז קיין פאַקטיש אַלאַקיישאַן פֿאַר זסטס צו זאָרג וועגן קאַפּאַציטעט, אָבער קס 01 קס קען נישט שעפּן ווי פיל לענג ווי קס 00 קס.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // מיר דאַרפֿן צו ענדערן די גרייס אויב די קאַפּאַציטעט איז נישט אַ מאַכט פון צוויי, צו קליין אָדער נישט האָבן לפּחות איין פריי פּלאַץ.
            // מיר טאָן דאָס בשעת עס איז נאָך אין די `Vec`, אַזוי די זאכן קענען פאַלן אויף panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// פֿון אַ [`VecDeque<T>`] אַ [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// דעם קיינמאָל דאַרף צו שייַעך-אַלאַקייט, אָבער עס דאַרף צו טאָן *O*(*N*) דאַטן באַוועגונג אויב די קייַלעכיק באַפער איז נישט אין די אָנהייב פון די אַלאַקיישאַן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // דער איינער איז *אָ*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // דער דאַרף דאַטן ריעריינדזש.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}