//! א דאַבלי-לינגקט רשימה מיט אָונד נאָודז.
//!
//! די `LinkedList` אַלאַוז פּושינג און פּאַפּינג עלעמענטן אין יעדער סוף אין קעסיידערדיק צייט.
//!
//! NOTE: עס איז כּמעט שטענדיק בעסער צו נוצן [`Vec`] אָדער [`VecDeque`] ווייַל מענגע-באזירט קאַנטיינערז זענען בכלל פאַסטער, מער זיקאָרן עפעקטיוו און נוצן בעסער די קפּו קאַש.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// א דאַבלי-לינגקט רשימה מיט אָונד נאָודז.
///
/// די `LinkedList` אַלאַוז פּושינג און פּאַפּינג עלעמענטן אין יעדער סוף אין קעסיידערדיק צייט.
///
/// NOTE: עס איז כּמעט שטענדיק בעסער צו נוצן `Vec` אָדער `VecDeque` ווייַל מענגע-באזירט קאַנטיינערז זענען בכלל פאַסטער, מער זיקאָרן עפעקטיוו און נוצן בעסער די קפּו קאַש.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// אַ יטעראַטאָר איבער די עלעמענטן פון אַ קס 00 קס.
///
/// דעם קס 01 קס איז באשאפן דורך קס 00 קס.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) אַראָפּנעמען לטובת `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// א מיוטאַבאַל יטעראַטאָר איבער די עלעמענטן פון אַ קס 00 קס.
///
/// דעם קס 01 קס איז באשאפן דורך קס 00 קס.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // מיר האָבן *נישט* אויסשליסלעך די גאנצע רשימה דאָ, באַווייַזן צו נאָדע ס קס 01 קס זענען כאַנדיד דורך די יטעראַטאָר!אַזוי זיין אָפּגעהיט ווען איר נוצן דעם;די מעטהאָדס גערופֿן מוזן זיין אַווער אַז עס קען זיין אַליאַסינג פּוינטערז צו קס 00 קס.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// אַן אָונער יטעראַטאָר איבער די עלעמענטן פון אַ `LinkedList`.
///
/// דעם `struct` איז באשאפן דורך די [`into_iter`] אופֿן אויף [`LinkedList`] (צוגעשטעלט דורך די `IntoIterator` ז 0 טראַיט 0 ז).
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// פּריוואַט מעטהאָדס
impl<T> LinkedList<T> {
    /// לייגט די געגעבן נאָדע צו די פראָנט פון דער רשימה.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // דעם אופֿן איז זאָרג ניט צו שאַפֿן מיוטאַבאַל באַווייַזן צו גאַנץ נאָודז, צו האַלטן די גילטיקייט פון אַליאַסינג פּוינטערז אין קס 00 קס.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // ניט קריייטינג נייַ מוטאַבאַל קס 01 קס באַווייַזן אָוווערלאַפּינג קס 00 קס.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// רימוווז און קערט דער נאָדע אין די פראָנט פון דער רשימה.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // דעם אופֿן איז זאָרג ניט צו שאַפֿן מיוטאַבאַל באַווייַזן צו גאַנץ נאָודז, צו האַלטן די גילטיקייט פון אַליאַסינג פּוינטערז אין קס 00 קס.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // ניט קריייטינג נייַ מוטאַבאַל קס 01 קס באַווייַזן אָוווערלאַפּינג קס 00 קס.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// לייגט די געגעבן נאָדע צו די צוריק פון די רשימה.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // דעם אופֿן איז זאָרג ניט צו שאַפֿן מיוטאַבאַל באַווייַזן צו גאַנץ נאָודז, צו האַלטן די גילטיקייט פון אַליאַסינג פּוינטערז אין קס 00 קס.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // ניט קריייטינג נייַ מוטאַבאַל קס 01 קס באַווייַזן אָוווערלאַפּינג קס 00 קס.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// רימוווז און קערט די נאָדע אין די צוריק פון דער רשימה.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // דעם אופֿן איז זאָרג ניט צו שאַפֿן מיוטאַבאַל באַווייַזן צו גאַנץ נאָודז, צו האַלטן די גילטיקייט פון אַליאַסינג פּוינטערז אין קס 00 קס.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // ניט קריייטינג נייַ מוטאַבאַל קס 01 קס באַווייַזן אָוווערלאַפּינג קס 00 קס.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// ונלינקס די ספּעסאַפייד נאָדע פון די קראַנט רשימה.
    ///
    /// ווארענונג: דאָס וועט נישט קאָנטראָלירן אַז די צוגעשטעלט נאָדע געהערט צו די קראַנט רשימה.
    ///
    /// דעם אופֿן נעמט זאָרג ניט צו מאַכן מיוטאַבאַל באַווייַזן צו קס 00 קס, צו טייַנען די גילטיקייט פון אַליאַסינג פּוינטערז.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // דאָס איז אונדזער איצט, מיר קענען שאַפֿן אַן &mut.

        // ניט קריייטינג נייַ מוטאַבאַל קס 01 קס באַווייַזן אָוווערלאַפּינג קס 00 קס.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // די נאָדע איז די קאָפּ נאָדע
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // די נאָדע איז די עק נאָדע
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// ספּלייסאַז אַ סעריע פון נאָודז צווישן צוויי יגזיסטינג נאָודז.
    ///
    /// ווארענונג: דאָס וועט נישט קאָנטראָלירן אַז די צוגעשטעלט נאָדע געהערט צו די צוויי יגזיסטינג רשימות.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // דעם אופֿן איז זאָרג צו נישט מאַכן קייפל מיוטאַבאַל באַווייַזן צו גאַנץ נאָודז אין דער זעלביקער צייט, צו האַלטן די גילטיקייט פון אַליאַסינג פּוינטערז אין קס 00 קס.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// דיטאַטשאַז אַלע נאָודז פֿון אַ לינגקט רשימה ווי אַ סעריע פון נאָודז.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // די שפּאַלטן נאָדע איז די נייַ קאָפּ נאָדע פון די רגע טייל
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // פאַרריכטן די קאָפּ פּטר פון די רגע טייל
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // די שפּאַלטן נאָדע איז דער נייַ עק נאָדע פון דער ערשטער טייל און אָונז די קאָפּ פון די רגע טייל.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // פאַרריכטן די עק פּטר פון דער ערשטער טייל
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// קרעאַטעס אַ ליידיק קס 00 קס.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// קרעאַטעס אַ ליידיק קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// מאַך אַלע עלעמענטן פֿון קס 00 קס צו די סוף פון די רשימה.
    ///
    /// דאָס ריוזיז אַלע די נאָודז פון קס 01 קס און מאָווינג זיי צו קס 00 קס.
    /// נאָך דעם אָפּעראַציע, `other` ווערט ליידיק.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(1) צייט און *O*(1) זכּרון.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` איז אָוקיי דאָ ווייַל מיר האָבן ויסשליסיק אַקסעס צו די ינטייערטי פון ביידע רשימות.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// מאָווינג אַלע עלעמענטן פֿון קס 00 קס צו די אָנהייב פון דער רשימה.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` איז אָוקיי דאָ ווייַל מיר האָבן ויסשליסיק אַקסעס צו די ינטייערטי פון ביידע רשימות.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// גיט אַ פֿאָרווערטס יטעראַטאָר.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// פּראָווידעס אַ פאָרויס יטעראַטאָר מיט מיוטאַבאַל באַווייַזן.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// גיט אַ לויפֿער אין די פראָנט עלעמענט.
    ///
    /// דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט אויב די רשימה איז ליידיק.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// גיט אַ לויפֿער מיט עדיטינג אַפּעריישאַנז אין די פראָנט עלעמענט.
    ///
    /// דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט אויב די רשימה איז ליידיק.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// גיט אַ לויפֿער אין די צוריק עלעמענט.
    ///
    /// דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט אויב די רשימה איז ליידיק.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// גיט אַ לויפֿער מיט עדיטינג אַפּעריישאַנז אין די צוריק עלעמענט.
    ///
    /// דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט אויב די רשימה איז ליידיק.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// קערט `true` אויב די `LinkedList` איז ליידיק.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(1) צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// קערט די לענג פון די `LinkedList`.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(1) צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// רימוווז אַלע עלעמענטן פון די קס 00 קס.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(*n*) צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// קערט `true` אויב די `LinkedList` כּולל אַן עלעמענט גלייַך צו די געגעבן ווערט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// פּראָווידעס אַ דערמאָנען צו די פראָנט עלעמענט, אָדער `None` אויב די רשימה איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// פּראָווידעס אַ מיוטאַבאַל דערמאָנען צו די פראָנט עלעמענט, אָדער `None` אויב די רשימה איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// גיט אַ דערמאָנען צו די צוריק עלעמענט, אָדער `None` אויב די רשימה איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// פּראָווידעס אַ מיוטאַבאַל דערמאָנען צו די צוריק עלעמענט, אָדער `None` אויב די רשימה איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// מוסיף אַן עלעמענט ערשטער אין דער רשימה.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(1) צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// רימוווז דער ערשטער עלעמענט און קערט עס אָדער `None` אויב די רשימה איז ליידיק.
    ///
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(1) צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// אַפּפּענדס אַן עלעמענט צו די צוריק פון די רשימה.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(1) צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// רימוווז די לעצטע עלעמענט פֿון דער רשימה און קערט עס אָדער `None` אויב עס איז ליידיק.
    ///
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(1) צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// ספּליץ די רשימה אין צוויי אין די געגעבן אינדעקס.
    /// קערט אַלץ נאָך די געגעבן אינדעקס, אַרייַנגערעכנט די אינדעקס.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(*n*) צייט.
    ///
    /// # Panics
    ///
    /// ז 0 פּאַניקס 0 ז אויב קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // ונטער, מיר יטערייט צו די 'איך-1' נאָדע, פֿון די אָנהייב אָדער די סוף, דיפּענדינג אויף וואָס וואָלט זיין פאַסטער.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // אַנשטאָט פון סקיפּינג ניצן .skip() (וואָס קריייץ אַ נייַ סטרוקטור), מיר האָפּקען מאַניואַלי אַזוי מיר קענען אַקסעס די קאָפּ פעלד אָן דיפּענדינג אויף די ימפּלאַמענטיישאַן דעטאַילס פון Skip.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // בעסער אַוועק פון די סוף
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// רימוווז די עלעמענט אין דער געגעבן אינדעקס און קערט עס.
    ///
    /// די אָפּעראַציע זאָל רעכענען אין *O*(*n*) צייט.
    ///
    /// # Panics
    /// ז 0 פּאַניקס 0 ז אויב ביי>=לענ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // ונטער, מיר יטערייט צו די נאָדע ביי דער געגעבן אינדעקס, פֿון די אָנהייב אָדער די סוף, דיפּענדינג אויף וואָס וואָלט זיין פאַסטער.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// קריייץ אַן יטעראַטאָר וואָס ניצט אַ קלאָוזשער צו באַשליסן אויב אַן עלעמענט זאָל זיין אַוועקגענומען.
    ///
    /// אויב די קלאָוזשער קערט אמת, די עלעמענט איז אַוועקגענומען און יילדאַד.
    /// אויב די קלאָוזשער קערט פאַלש, די עלעמענט בלייבט אין דער רשימה און וועט ניט זיין יילדאַד דורך יטעראַטאָר.
    ///
    /// באַמערקונג אַז `drain_filter` לאָזן איר מיוטייט יעדער עלעמענט אין די פילטער קלאָוזשער, ראַגאַרדלאַס פון צי איר קלייַבן צו האַלטן אָדער אַראָפּנעמען עס.
    ///
    ///
    /// # Examples
    ///
    /// ספּליטינג אַ רשימה אין יוואַנז און שאַנסן, ריוזינג דער אָריגינעל רשימה:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // ויסמיידן באָרגן ישוז.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // פאָרזעצן די זעלבע שלייף מיר טאָן אונטן.דאָס נאָר לויפט ווען אַ דעסטרוקטאָר פּאַניק.
                // אויב אן אנדער panics, דאָס וועט אַבאָרט.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // דאַרפֿן אַן אַנבאַונדיד לעבן צו באַקומען 'אַ
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // דאַרפֿן אַן אַנבאַונדיד לעבן צו באַקומען 'אַ
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // דאַרפֿן אַן אַנבאַונדיד לעבן צו באַקומען 'אַ
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // דאַרפֿן אַן אַנבאַונדיד לעבן צו באַקומען 'אַ
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// א לויפֿער איבער אַ קס 00 קס.
///
/// א קס 00 קס איז ווי אַ יטעראַטאָר, אַחוץ אַז עס קענען פרילי זוכן צוריק-און-אַרויס.
///
/// קורסאָרס שטענדיק מנוחה צווישן צוויי עלעמענטן אין דער רשימה און אינדעקס אויף אַ לאַדזשיקאַללי קייַלעכיק וועג.
/// צו אַקאַמאַדייט דעם, עס איז אַ "ghost" ניט-עלעמענט וואָס גיט `None` צווישן די קאָפּ און די עק פון דער רשימה.
///
///
/// ווען באשאפן, די קורסאָרס אָנהייבן אין די פראָנט פון דער רשימה, אָדער די "ghost" ניט-עלעמענט אויב די רשימה איז ליידיק.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// א לויפֿער איבער אַ קס 00 קס מיט עדיטינג אַפּעריישאַנז.
///
/// א קס 00 קס איז ווי אַ יטעראַטאָר, אַחוץ אַז עס קענען פרילי זוכן צוריק-און-אַרויס, און קענען בעשאָלעם מיוטייט די רשימה בעשאַס יטעראַטיאָן.
/// דאָס איז ווייַל די לעבן פון זיין רידוסט באַווייַזן איז טייד צו זיין אייגענע לעבן, אַנשטאָט פון די אַנדערלייינג רשימה.
/// דאָס מיינט אַז קורסאָרס קענען נישט טראָגן קייפל עלעמענטן אין אַמאָל.
///
/// קורסאָרס שטענדיק מנוחה צווישן צוויי עלעמענטן אין דער רשימה און אינדעקס אויף אַ לאַדזשיקאַללי קייַלעכיק וועג.
/// צו אַקאַמאַדייט דעם, עס איז אַ "ghost" ניט-עלעמענט וואָס גיט `None` צווישן די קאָפּ און די עק פון דער רשימה.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// רעטורנס די לויפֿער שטעלע אינדעקס אין די `LinkedList`.
    ///
    /// דעם קערט `None` אויב דער לויפֿער דערווייַל ווייזט צו די "ghost" ניט-עלעמענט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// מאַך די לויפֿער צו די ווייַטער עלעמענט פון די קס 00 קס.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס וועט מאַך עס צו דער ערשטער עלעמענט פון די `LinkedList`.
    /// אויב עס איז געוויזן צו די לעצטע עלעמענט פון די `LinkedList`, דאָס וועט אַריבערפירן עס צו די "ghost" ניט-עלעמענט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // מיר האבן ניט קיין יעצטיגן עלעמענט;דער לויפֿער איז געזעסן אין דער אָנהייב שטעלע. דער ווייַטער עלעמענט זאָל זיין דער הויפּט פון דער רשימה
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // מיר האָבן אַ פריערדיקן עלעמענט, אַזוי לאָזן ס גיין צו די ווייַטער
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// מאַך די לויפֿער צו די פריערדיקע עלעמענט פון די `LinkedList`.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס וועט מאַך עס צו די לעצטע עלעמענט פון די `LinkedList`.
    /// אויב עס איז אנגעוויזן אויף דער ערשטער עלעמענט פון די `LinkedList`, דאָס וועט מאַך עס צו די "ghost" ניט-עלעמענט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // קיין קראַנט.מיר זענען אין די אָנהייב פון די רשימה.טראָגן קיינער און שפּרינגען צו די סוף.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // האָבן אַ פּריוו.טראָגן עס און גיין צו די פריערדיקע עלעמענט.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// רעטורנס אַ רעפֿערענץ צו דעם עלעמענט וואָס דער לויפֿער איז דערווייַל פּוינטינג צו.
    ///
    /// דעם קערט `None` אויב דער לויפֿער דערווייַל ווייזט צו די "ghost" ניט-עלעמענט.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// רעטורנס אַ רעפֿערענץ צו דער ווייַטער עלעמענט.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס קערט דער ערשטער עלעמענט פון די `LinkedList`.
    /// אויב עס ווייזט צו די לעצטע עלעמענט פון די `LinkedList`, דאָס קערט `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// רעטורנס אַ רעפֿערענץ צו די פריערדיקע עלעמענט.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס קערט דער לעצט עלעמענט פון די `LinkedList`.
    /// אויב עס איז שפּיציק צו דער ערשטער עלעמענט פון די קס 01 קס, דאָס קערט קס 00 קס.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// רעטורנס די לויפֿער שטעלע אינדעקס אין די `LinkedList`.
    ///
    /// דעם קערט `None` אויב דער לויפֿער דערווייַל ווייזט צו די "ghost" ניט-עלעמענט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// מאַך די לויפֿער צו די ווייַטער עלעמענט פון די קס 00 קס.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס וועט מאַך עס צו דער ערשטער עלעמענט פון די `LinkedList`.
    /// אויב עס איז געוויזן צו די לעצטע עלעמענט פון די `LinkedList`, דאָס וועט אַריבערפירן עס צו די "ghost" ניט-עלעמענט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // מיר האבן ניט קיין יעצטיגן עלעמענט;דער לויפֿער איז געזעסן אין דער אָנהייב שטעלע. דער ווייַטער עלעמענט זאָל זיין דער הויפּט פון דער רשימה
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // מיר האָבן אַ פריערדיקן עלעמענט, אַזוי לאָזן ס גיין צו די ווייַטער
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// מאַך די לויפֿער צו די פריערדיקע עלעמענט פון די `LinkedList`.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס וועט מאַך עס צו די לעצטע עלעמענט פון די `LinkedList`.
    /// אויב עס איז אנגעוויזן אויף דער ערשטער עלעמענט פון די `LinkedList`, דאָס וועט מאַך עס צו די "ghost" ניט-עלעמענט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // קיין קראַנט.מיר זענען אין די אָנהייב פון די רשימה.טראָגן קיינער און שפּרינגען צו די סוף.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // האָבן אַ פּריוו.טראָגן עס און גיין צו די פריערדיקע עלעמענט.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// רעטורנס אַ רעפֿערענץ צו דעם עלעמענט וואָס דער לויפֿער איז דערווייַל פּוינטינג צו.
    ///
    /// דעם קערט `None` אויב דער לויפֿער דערווייַל ווייזט צו די "ghost" ניט-עלעמענט.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// רעטורנס אַ רעפֿערענץ צו דער ווייַטער עלעמענט.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס קערט דער ערשטער עלעמענט פון די `LinkedList`.
    /// אויב עס ווייזט צו די לעצטע עלעמענט פון די `LinkedList`, דאָס קערט `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// רעטורנס אַ רעפֿערענץ צו די פריערדיקע עלעמענט.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, דאָס קערט דער לעצט עלעמענט פון די `LinkedList`.
    /// אויב עס איז שפּיציק צו דער ערשטער עלעמענט פון די קס 01 קס, דאָס קערט קס 00 קס.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// רעטורנס אַ לייענען-בלויז לויפֿער אָנווייַזן צו דעם קראַנט עלעמענט.
    ///
    /// די לעבן פון די אומגעקערט קס 02 קס איז געבונדן צו די קס 01 קס, וואָס מיטל אַז עס קען נישט יקסיד די קס 03 קס און אַז די קס 04 קס איז פאַרפרוירן פֿאַר די לעבן פון די קס 00 קס.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// איצט דער רשימה עדיטינג אַפּעריישאַנז

impl<'a, T> CursorMut<'a, T> {
    /// ינסערט אַ נייַע עלעמענט אין די `LinkedList` נאָך די קראַנט.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, די נייַע עלעמענט איז ינסערטאַד אין די פראָנט פון די `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // די אינדעקס פון די "ghost" ניט-עלעמענט איז געביטן.
                self.index = self.list.len;
            }
        }
    }

    /// ינסערט אַ נייַע עלעמענט אין די `LinkedList` איידער די קראַנט.
    ///
    /// אויב דער לויפֿער ווייזט אויף די "ghost" ניט-עלעמענט, די נייַע עלעמענט איז ינסערטאַד אין די סוף פון די `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// רימוווז די קראַנט עלעמענט פֿון די `LinkedList`.
    ///
    /// די עלעמענט וואָס איז אַוועקגענומען איז אומגעקערט, און דער לויפֿער איז אריבערגעפארן צו ווייַזן צו דער ווייַטער עלעמענט אין די `LinkedList`.
    ///
    ///
    /// אויב דער לויפֿער דערווייַל ווייזט צו די "ghost" ניט-עלעמענט, קיין עלעמענט איז אַוועקגענומען און `None` איז אומגעקערט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// רימוווז די קראַנט עלעמענט פֿון די `LinkedList` אָן דילאַקייטינג די רשימה נאָדע.
    ///
    /// די נאָדע וואָס איז אַוועקגענומען איז אומגעקערט ווי אַ נייַע `LinkedList` כּולל בלויז דעם נאָדע.
    /// דער לויפֿער איז אריבערגעפארן צו פונט צו דער ווייַטער עלעמענט אין דעם קראַנט `LinkedList`.
    ///
    /// אויב דער לויפֿער דערווייַל ווייזט צו די "ghost" ניט-עלעמענט, קיין עלעמענט איז אַוועקגענומען און `None` איז אומגעקערט.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// ינסערט די יסודות פון די געגעבן `LinkedList` נאָך די קראַנט.
    ///
    /// אויב דער לויפֿער ווייזט צו די "ghost" ניט-עלעמענט, די נייַ עלעמענטן זענען ינסערטאַד אין די אָנהייב פון די `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // די אינדעקס פון די "ghost" ניט-עלעמענט איז געביטן.
                self.index = self.list.len;
            }
        }
    }

    /// ינסערט די יסודות פון די געגעבן `LinkedList` איידער די קראַנט.
    ///
    /// אויב דער לויפֿער ווייזט אויף די "ghost" ניט-עלעמענט, די נייַע עלעמענטן זענען ינסערטאַד אין די סוף פון די `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// ספּליץ די רשימה אין צוויי נאָך דעם קראַנט עלעמענט.
    /// דערנאָך וועט צוריקקומען אַ נייַע רשימה וואָס באַשטייט פון אַלץ נאָך די לויפֿער, און דער אָריגינעל רשימה וועט האַלטן אַלץ איידער.
    ///
    ///
    /// אויב דער לויפֿער ווייזט אויף די "ghost" ניט-עלעמענט, די גאנצע אינהאַלט פון די `LinkedList` איז אריבערגעפארן.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // די "ghost" אינדעקס פון ניט-עלעמענט איז געביטן צו 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// ספּליץ די רשימה אין צוויי איידער די קראַנט עלעמענט.
    /// דערנאָך וועט צוריקקומען אַ נייַע רשימה וואָס כּולל אַלץ איידער די לויפֿער, און דער אָריגינעל רשימה וועט האַלטן אַלץ נאָך.
    ///
    ///
    /// אויב דער לויפֿער ווייזט אויף די "ghost" ניט-עלעמענט, די גאנצע אינהאַלט פון די `LinkedList` איז אריבערגעפארן.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// אַ יטעראַטאָר געשאפן דורך רופן `drain_filter` אויף לינקעדליסט.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` איז אָוקיי מיט אַליאַסינג `element` באַווייַזן.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// קאַנסומז די רשימה אין אַ יטעראַטאָר, וואָס גיט עלעמענטן דורך ווערט.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// פאַרזיכערן אַז `LinkedList` און זיין לייענען בלויז יטעראַטאָרס זענען קאָוואַריאַנט אין זייער פּאַראַמעטערס.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}