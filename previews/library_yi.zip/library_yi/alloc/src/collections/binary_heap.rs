//! א בילכערקייַט ריי ימפּלאַמענאַד מיט אַ ביינערי קופּע.
//!
//! ינסערשאַן און פּאַפּינג די גרעסטע עלעמענט האָבן קס 00 קס צייט קאַמפּלעקסיטי.
//! קאָנטראָלירונג דעם גרעסטן עלעמענט איז *O*(1).קאָנווערטינג אַ ז 0 וועקטאָר 0 ז צו אַ ביינערי קופּע קענען ווערן געטאן אין-אָרט, און האט *אָ*(*ן*) קאַמפּלעקסיטי.
//! א ביינערי קופּע קענען אויך זיין קאָנווערטעד צו אַ סאָרטעד ז 0 וועקטאָר 0 ז אין-אָרט, אַלאַוינג עס צו ווערן געניצט פֿאַר אַן *אָ*(*נ*\* קס 00 קס אין-אָרט העאַפּסאָרט.
//!
//! # Examples
//!
//! דאָס איז אַ גרעסערע ביישפּיל וואָס ימפּלאַמענט [Dijkstra's algorithm][dijkstra] צו סאָלווע די [shortest path problem][sssp] אויף אַ [directed graph][dir_graph].
//!
//! עס ווייזט ווי צו נוצן [`BinaryHeap`] מיט מנהג טייפּס.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // די בילכערקייַט ריי דעפּענדס אויף `Ord`.
//! // עקספּליסיטלי ינסטרומענט די trait אַזוי די ריי ווערט אַ מין-קופּע אַנשטאָט אַ מאַקס-קופּע.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // נאָטיץ אַז די קאָס אָרדערד מיר.
//!         // אין פאַל פון אַ בונד, מיר פאַרגלייכן שטעלעס, דעם שריט איז נייטיק צו מאַכן ימפּלאַמענטיישאַנז פון קס 00 קס און קס 01 קס קאָנסיסטענט.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` דאַרף זיין ימפּלאַמענאַד ווי געזונט.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // יעדער נאָדע איז רעפּריזענטיד ווי אַ `usize` פֿאַר אַ קירצער ימפּלאַמענטיישאַן.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // די שאָרטיסט דרך אַלגערידאַם פון Dijkstra.
//!
//! // אָנהייבן בייַ `start` און נוצן `dist` צו שפּור די קראַנט שאָרטיסט ווייַטקייט צו יעדער נאָדע.די ימפּלאַמענטיישאַן איז נישט זיקאָרן-עפעקטיוו, ווייַל עס קען לאָזן דופּליקאַט נאָודז אין די ריי.
//! //
//! // עס אויך ניצט `usize::MAX` ווי אַ סענטינעל ווערט פֿאַר אַ סימפּלער ימפּלאַמענטיישאַן.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=קראַנט שאָרטיסט ווייַטקייט פון קס 01 קס צו קס 00 קס
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // מיר זענען ביי `start`, מיט אַ נול פּרייַז
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // ונטערזוכן די גרענעץ מיט נידעריק קאָס נאָדעס (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // אַלטערנאַטיוועלי, מיר קען פאָרזעצן צו געפֿינען אַלע שאָרטיסט פּאַטס
//!         if position == goal { return Some(cost); }
//!
//!         // וויכטיק ווי מיר קען האָבן שוין געפֿונען אַ בעסער וועג
//!         if cost > dist[position] { continue; }
//!
//!         // פֿאַר יעדער נאָדע מיר קענען דערגרייכן, זען אויב מיר קענען געפֿינען אַ וועג מיט אַ נידעריקער פּרייַז דורך דעם נאָדע
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // אויב אַזוי, לייג עס צו די גרענעץ און פאָרזעצן
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // אָפּרו, מיר האָבן איצט געפֿונען אַ בעסער וועג
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ציל ניט ריטשאַבאַל
//!     None
//! }
//!
//! fn main() {
//!     // דאָס איז דער דירעקט דירעקט גראַפיק וואָס מיר וועלן נוצן.
//!     // די נאָדע נומערן קאָראַספּאַנדז צו די פאַרשידענע שטאַטן, און די edge ווייץ סימבאָליזירן די קאָס פון מאָווינג פון איין נאָדע צו אנדערן.
//!     //
//!     // באַמערקונג אַז די עדזשאַז זענען איין-וועג.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // די גראַפיק איז רעפּריזענטיד ווי אַ אַדזשאַסטאַנסי רשימה ווו יעדער אינדעקס, קאָראַספּאַנדינג צו אַ נאָדע ווערט, האט אַ רשימה פון אַוטגאָוינג עדזשאַז.
//!     // אויסדערוויילט פֿאַר זייַן עפעקטיווקייַט.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // נאָדע 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // נאָדע 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // נאָדע 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // נאָדע 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // נאָדע 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// א בילכערקייַט ריי ימפּלאַמענאַד מיט אַ ביינערי קופּע.
///
/// דאָס וועט זיין אַ מאַקס-קופּע.
///
/// עס איז אַ לאָגיק טעות פֿאַר אַ נומער צו זיין מאַדאַפייד אַזוי אַז די אָרדערינג פון די נומער קאָרעוו צו קיין אנדערע נומער, ווי די `Ord` זאָטראַט 0 ז איז באשלאסן, ענדערונגען בשעת עס איז אין די קופּע.
///
/// דאָס איז נאָרמאַלי בלויז מעגלעך דורך קס 00 קס, קס 01 קס, גלאבאלע שטאַט, קס 02 קס, אָדער אַנסייף קאָד.
/// די אָפּפירונג ריזאַלטינג פון אַזאַ אַ לאָגיק טעות איז ניט ספּעסאַפייד, אָבער וועט נישט רעזולטאַט אין אַנדיפיינד נאַטור.
/// דאָס קען אַרייַננעמען panics, פאַלש רעזולטאַטן, אַבאָרץ, זכּרון ליקס און ניט-טערמאַניישאַן.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // מיט טיפּ ינפערענסע, לאָזן אונדז דורכפירן אַן יקספּליסאַט טיפּ סיגנאַטורע (וואָס וואָלט זיין `BinaryHeap<i32>` אין דעם בייַשפּיל).
/////
/// let mut heap = BinaryHeap::new();
///
/// // מיר קענען נוצן פּיק צו קוקן אין די ווייַטער נומער פון די קופּע.
/// // אין דעם פאַל, עס זענען קיין יטעמס אין עס נאָך אַזוי מיר באַקומען קיינער.
/// assert_eq!(heap.peek(), None);
///
/// // זאל ס לייגן עטלעכע סקאָרז ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // איצט פּיק ווייזט די מערסט וויכטיק נומער אין די קופּע.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // מיר קענען קאָנטראָלירן די לענג פון אַ קופּע.
/// assert_eq!(heap.len(), 3);
///
/// // מיר קענען יבערקוקן די זאכן אין די קופּע, כאָטש זיי זענען אומגעקערט אין אַ טראַפ-סדר.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // אויב מיר אָנשטאָט די סקאָרז, זיי זאָל קומען צוריק אין סדר.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // מיר קענען ויסמעקן די קופּע פון קיין רוען ייטאַמז.
/// heap.clear();
///
/// // דער קופּע זאָל איצט זיין ליידיק.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `std::cmp::Reverse` אָדער אַ מנהג `Ord` ימפּלאַמענטיישאַן קענען ווערן גענוצט צו מאַכן `BinaryHeap` אַ מין-קופּע.
/// דאָס מאכט `heap.pop()` צוריקקומען דער קלענסטער ווערט אַנשטאָט פון די גרעסטע.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // ראַפּט וואַלועס אין קס 00 קס
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // אויב מיר פּונקט די סקאָרז איצט, זיי זאָל קומען צוריק אין די פאַרקערט סדר.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # צייט קאַמפּלעקסיטי
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// די ווערט פֿאַר קס 00 קס איז אַ געריכט קאָסטן;די אופֿן דאַקיומענטיישאַן גיט אַ מער דיטיילד אַנאַליסיס.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// סטרוקטור ראַפּינג אַ מיוטאַבאַל דערמאָנען צו די גרעסטע נומער פון אַ קס 00 קס.
///
///
/// די `struct` איז באשאפן דורך די [`peek_mut`] אופֿן אויף [`BinaryHeap`].
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // זיכערהייט: פּעעקמוט איז בלויז ינסטאַנטיד פֿאַר ניט-ליידיק הויפנס.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // זיכער: פּעעקמוט איז בלויז ינסטאַנטיד פֿאַר ניט-ליידיק הויפנס
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // זיכער: פּעעקמוט איז בלויז ינסטאַנטיד פֿאַר ניט-ליידיק הויפנס
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// רימוווז די פּיקט ווערט פון די קופּע און קערט עס.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// קרעאַטעס אַ ליידיק קס 00 קס.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// קרעאַטעס אַ ליידיק קס 00 קס ווי אַ מאַקס-קופּע.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// קרעאַטעס אַ ליידיק קס 00 קס מיט אַ ספּעציפיש קאַפּאַציטעט.
    /// דעם פּרעאַללאָקאַטעס גענוג זכּרון פֿאַר קס 00 קס עלעמענטן, אַזוי די קס 01 קס טאָן ניט האָבן צו זיין ריאַלאַקייטיד ביז עס כּולל לפּחות אַז פילע וואַלועס.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו די גרעסטע נומער אין די ביינערי קופּע, אָדער `None` אויב עס איז ליידיק.
    ///
    /// Note: אויב די `PeekMut` ווערט ליקט, די קופּע קען זיין אין אַ סתירה.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # צייט קאַמפּלעקסיטי
    ///
    /// אויב די נומער איז מאַדאַפייד, די קאַמפּלעקסיטי פון די ערגסט פאַל איז *O*(log(*n*)), אַנדערש דאָס איז *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// רימוווז די גרעסטע נומער פון די ביינערי קופּע און קערט עס אָדער `None` אויב עס איז ליידיק.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # צייט קאַמפּלעקסיטי
    ///
    /// די פּרייַז פון די ערגסט פאַל פון קס 01 קס אויף אַ קופּע מיט *n* עלעמענטן איז קס 00 קס.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // זיכערקייט: קס 00 קס מיטל אַז קס 01 קס> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// פּושאַז אַ נומער אַנטו די ביינערי קופּע.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # צייט קאַמפּלעקסיטי
    ///
    /// די געריכט קאָס פון `push`, דורכשניטלעך איבער יעדער מעגלעך אָרדערינג פון די פּושינג עלעמענטן, און איבער אַ גענוג גרויס נומער פון פּושיז, איז *O*(1).
    ///
    /// דאָס איז די מערסט מינינגפאַל פּרייַז מעטריק ווען פּושינג עלעמענטן וואָס זענען *נישט* שוין אין קיין סאָרטעד מוסטער.
    ///
    /// די צייט קאַמפּלעקסיטי דיגריידז אויב עלעמענטן זענען פּושט אין די מערסט אַסענדינג סדר.
    /// אין די ערגסט פאַל, עלעמענטן זענען פּושט אין אַסענדינג סאָרטעד סדר און די אַמאָרטיזעד פּרייַז פּער שטופּן איז *O*(log(*n*)) קעגן אַ קופּע מיט *n* עלעמענטן.
    ///
    /// די ערגסט פאַל פון אַ *איין* רוף צו קס 00 קס איז *O*(*n*).די ערגסט פאַל אַקערז ווען די קאַפּאַציטעט איז ויסגעמאַטערט און עס דאַרף אַ גרייס.
    /// די גרייס פון די גרייס איז אַמאָרטיזעד אין די פריערדיקע פיגיערז.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // זיכערקייט: זינט מיר פּושט אַ נייַ נומער עס מיטל אַז
        //  old_len=קס 01 קס, 1 <קס 00 קס
        unsafe { self.sift_up(0, old_len) };
    }

    /// קאַנסומז די `BinaryHeap` און קערט אַ vector אין סדר (ascending) סדר.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // זיכערקייט: קס 00 קס גייט פון קס 01 קס צו 1 (ביידע אַרייַנגערעכנט),
            //  אַזוי עס איז שטענדיק אַ גילטיק אינדעקס צו אַקסעס.
            //  עס איז זיכער צו אַקסעס אינדעקס 0 (ד"ה קס 00 קס) ווייַל
            //  1 <=סוף <קס 00 קס, וואָס מיטל קס 01 קס>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // זיכערקייט: קס 00 קס גייט פון קס 01 קס צו 1 (ביידע אַרייַנגערעכנט) אַזוי:
            //  0 <1 <=סוף <=קס 01 קס, 1 <קס 02 קס וואָס מיטל 0 <סוף און סוף <קס 00 קס.
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // די ימפּלעמענטאַטיאָנס פון סיפט_ופּ און סיפט_דאָוון נוצן אַנסייף בלאַקס אין סדר צו רירן אַן עלעמענט אויס פון די vector (לאָזן אַ לאָך), יבעררוק צוזאמען די אנדערע און אַריבערפירן די אַוועקגענומען עלעמענט צוריק אין די vector אין די לעצט אָרט פון די לאָך.
    //
    // די `Hole` טיפּ איז געניצט צו פאָרשטעלן דעם, און מאַכן זיכער אַז די לאָך איז אָנגעפילט אין די סוף פון זיין פאַרנעם, אפילו אויף panic.
    // ניצן אַ לאָך ראַדוסאַז די קעסיידערדיק פאַקטאָר קאַמפּערד צו נוצן סוואַפּס, וואָס ינוואַלווז צוויי מאָל ווי פילע מאָוועס.
    //
    //
    //
    //

    /// # Safety
    ///
    /// די קאַללער מוזן גאַראַנטירן אַז `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // נעמען די ווערט פון `pos` און מאַכן אַ לאָך.
        // זיכערקייט: די קאָלער געראַנטיז אַז פּאַס <קס 00 קס
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // זיכערקייט: קס 00 קס> אָנהייב>=0, וואָס מיטל קס 01 קס> 0
            //  און אַזוי hole.pos(), 1 קען נישט אַנדערפלאָו.
            //  דעם געראַנטיז אַז פאָטער <קס 01 קס אַזוי עס איז אַ גילטיק אינדעקס און אויך!=קס 00 קס.
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // זיכערקייט: זעלביקער ווי אויבן
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// נעמען אַן עלעמענט ביי `pos` און מאַך עס אַראָפּ די קופּע, בשעת די קינדער זענען גרעסער.
    ///
    ///
    /// # Safety
    ///
    /// די קאַללער מוזן גאַראַנטירן אַז `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // זיכערקייט: די קאַללער געראַנטיז אַז פּאַס <ענד <=קס 00 קס.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // שלייף ינוועריאַנט: קינד==2 * קס 00 קס + 1.
        while child <= end.saturating_sub(2) {
            // פאַרגלייכן מיט די גרעסערע פון די צוויי זיכערקייט: קינד <סוף, 1 <קס 01 קס און קינד + 1 <סוף <=קס 00 קס, אַזוי זיי זענען גילטיק ינדעקסיז.
            //
            //  קינד==2 *קס 03 קס + 1!=קס 02 קס און קינד + 1==2* קס 03 קס + 2!=קס 00 קס.
            // FIXME: 2 *קס 00 קס + 1 אָדער 2* קס 01 קס 2 קען לויפן איבער אויב טי איז אַ זסט
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // אויב מיר זענען שוין אין סדר, האַלטן.
            // זיכערקייט: קינד איז איצט די אַלט קינד אָדער דער אַלט קינד + 1
            //  מיר האָבן שוין פּראָווען אַז ביידע זענען <קס 01 קס און!=קס 00 קס
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // זיכערקייט: זעלביקער ווי אויבן.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // זיכערקייט: &&קורץ קרייַז, וואָס מיטל אַז אין די
        //  צווייטע צושטאַנד עס איז שוין אמת אַז קינד==סוף, 1 <קס 00 קס.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // זיכערקייט: קינד איז שוין פּראָווען אַ גילטיק אינדעקס און
            //  קינד==2 * קס 01 קס + 1!=קס 00 קס.
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// די קאַללער מוזן גאַראַנטירן אַז `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // זיכערקייט: pos <len איז געראַנטיד דורך די קאָלער און
        //  דאָך לענ=קס 01 קס <=קס 00 קס.
        unsafe { self.sift_down_range(pos, len) };
    }

    /// נעמען אַן עלעמענט אין `pos` און מאַך עס אַלע די וועג אַראָפּ די קופּע, און סיפט עס אַרויף צו זיין שטעלע.
    ///
    ///
    /// Note: דאָס איז פאַסטער ווען די עלעמענט איז באַוווסט צו זיין גרויס/זאָל זיין נעענטער צו די דנאָ.
    ///
    /// # Safety
    ///
    /// די קאַללער מוזן גאַראַנטירן אַז `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // זיכערקייט: די קאָלער געראַנטיז אַז פּאַס <קס 00 קס.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // שלייף ינוועריאַנט: קינד==2 * קס 00 קס + 1.
        while child <= end.saturating_sub(2) {
            // זיכערקייט: קינד <סוף, 1 <קס 00 קס און
            //  קינד + 1 <סוף <=קס 00 קס, אַזוי זיי זענען גילטיק ינדעקסיז.
            //  קינד==2 *קס 03 קס + 1!=קס 02 קס און קינד + 1==2* קס 03 קס + 2!=קס 00 קס.
            //
            // FIXME: 2 *קס 00 קס + 1 אָדער 2* קס 01 קס 2 קען לויפן איבער אויב טי איז אַ זסט
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // זיכערקייט: זעלביקער ווי אויבן
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // זיכערקייט: קינד==סוף, 1 <קס 00 קס, אַזוי עס איז אַ גילטיק אינדעקס
            //  און קינד==2 * קס 01 קס + 1!=קס 00 קס.
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // זיכערקייט: פּאַס איז די שטעלע אין דער לאָך און איז שוין פּראָווען
        //  צו זיין אַ גילטיק אינדעקס.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // זיכערהייט: n סטאַרץ פֿון self.len()/2 און גייט אַראָפּ צו 0.
            //  דער בלויז פאַל ווען! (N <self.len()) איז אויב self.len() ==0, אָבער עס איז רולד אויס דורך די שלייף צושטאַנד.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// מאַך אַלע די עלעמענטן פון קס 01 קס אין קס 00 קס, ליווינג קס 02 קס ליידיק.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` נעמט O(len1 + len2) אָפּעראַטיאָנס און וועגן 2 *(len1 + len2) קאַמפּעראַסאַנז אין די ערגסט פאַל בשעת `extend` נעמט O(len2* log(len1)) אַפּעריישאַנז און וועגן 1 *len2* log_2(len1) קאַמפּעראַסאַנז אין די ערגסט פאַל, אַסומינג len1>= len2.
        // פֿאַר גרעסערע הויפנס, די קראָסאָוווער פונט ניט מער גייט דעם ריזאַנינג און איז געווען באשלאסן עמפּיריקלי.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// רעטורנס אַ יטעראַטאָר וואָס ריטריווז עלעמענטן אין הויפן סדר.
    /// די ריטריווד עלעמענטן זענען אַוועקגענומען פון דער אָריגינעל קופּע.
    /// די רוען עלעמענטן וועט זיין אַוועקגענומען אויף פאַלן אין קופּע סדר.
    ///
    /// Note:
    /// * `.drain_sorted()` איז *אָ*(*ן*\* קס 01 קס; פיל סלאָוער ווי קס 00 קס.
    ///   איר זאָל נוצן די לעצטע פֿאַר רובֿ קאַסעס.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // רימוווז אַלע עלעמענטן אין קופּע סדר
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// ריטיינז בלויז די עלעמענטן וואָס זענען באַשטימט דורך דעם פּרעדיקאַט.
    ///
    /// אין אנדערע ווערטער, אַראָפּנעמען אַלע עלעמענטן קס 01 קס אַזוי אַז קס 02 קס קערט קס 00 קס.
    /// די עלעמענטן זענען באזוכט אין אַנסאָרטאַד (און ונספּעסיפיעד) סדר.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // נאָר האַלטן אפילו נומערן
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// קערט אַ יטעראַטאָר וואָס באזוכט אַלע וואַלועס אין די אַנדערלייינג ז 0 וועקטאָר 0 ז, אין אַרביטראַריש סדר.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // דרוקן 1, 2, 3, 4 אין אַרביטראַרישער סדר
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// רעטורנס אַ יטעראַטאָר וואָס ריטריווז עלעמענטן אין הויפן סדר.
    /// דעם אופֿן קאַנסומז דער אָריגינעל קופּע.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// רעטורנס די גרעסטע נומער אין די ביינערי קופּע, אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # צייט קאַמפּלעקסיטי
    ///
    /// קאָסטן זענען *אָ*(1) אין די ערגסט פאַל.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// קערט די נומער פון עלעמענטן וואָס די ביינערי קופּע קענען האַלטן אָן ריאַלאַקייטינג.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// רעסערוועס די מינימום קאַפּאַציטעט פֿאַר פּונקט `additional` מער עלעמענטן צו זיין ינסערטאַד אין די געגעבן `BinaryHeap`.
    /// טוט גאָרנישט אויב די קאַפּאַציטעט איז שוין גענוג.
    ///
    /// באַמערקונג אַז די אַלאַקייטער קען געבן די זאַמלונג מער פּלאַץ ווי עס ריקווייערז.
    /// דעריבער, די קאַפּאַציטעט קען נישט זיין רילייד צו זיין פּונקט מינימאַל.
    /// בעסער [`reserve`] אויב future ינסערשאַנז זענען געריכט.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט אָוווערפלאָוז `usize`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// ריזערווז קאַפּאַציטעט פֿאַר לפּחות קס 01 קס מער עלעמענטן צו זיין ינסערטאַד אין די קס 00 קס.
    /// די זאַמלונג קען רעזערווירן מער פּלאַץ צו ויסמיידן אָפט ריאַלאַקיישאַנז.
    ///
    /// # Panics
    ///
    /// Panics אויב די נייַ קאַפּאַציטעט אָוווערפלאָוז `usize`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// דיסמיסט ווי פיל נאָך קאַפּאַציטעט ווי מעגלעך.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// דיסקאַרדס קאַפּאַציטעט מיט אַ נידעריקער גרענעץ.
    ///
    /// די קאַפּאַציטעט וועט זיין לפּחות ווי גרויס ווי די לענג און די סאַפּלייד ווערט.
    ///
    ///
    /// אויב די קראַנט קאַפּאַציטעט איז ווייניקער ווי דער נידעריקער שיעור, דאָס איז אַ ניט-אַפּ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// קאַנסומז די `BinaryHeap` און קערט די אַנדערלייינג vector אין אַרביטראַריש סדר.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // וועט דרוקן אין עטלעכע סדר
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// רעטורנס די לענג פון די ביינערי קופּע.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// טשעקס אויב די ביינערי קופּע איז ליידיק.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// קלירז די ביינערי קופּע, צוריקקומען אַ יטעראַטאָר איבער די אַוועקגענומען עלעמענטן.
    ///
    /// די עלעמענטן זענען אַוועקגענומען אין אַרביטראַריש סדר.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// דראָפּס אַלע ייטאַמז פון די ביינערי קופּע.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// לאָך רעפּראַזענץ אַ לאָך אין אַ רעפטל הייסט אַן אינדעקס אָן גילטיק ווערט (ווייַל עס איז אריבערגעפארן פון אָדער דופּליקייטיד).
///
/// אין פאַל, `Hole` וועט ומקערן די רעפטל דורך פילונג די לאָך שטעלע מיט די ווערט וואָס איז געווען אָריגינעל אַוועקגענומען.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// שאַפֿן אַ נייַ `Hole` ביי אינדעקס `pos`.
    ///
    /// אַנסייף ווייַל פּאָוז מוזן זיין אין די דאַטן רעפטל.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // זיכער: פּאָ זאָל זיין ין דער רעפטל
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// רעטורנס אַ רעפֿערענץ צו די עלעמענט אַוועקגענומען.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// קערט אַ רעפֿערענץ צו די `index` עלעמענט.
    ///
    /// אַנסייף ווייַל אינדעקס מוזן זיין אין די דאַטן רעפטל און נישט גלייַך צו פּאָס.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// מאַך לאָך צו נייַ אָרט
    ///
    /// אַנסייף ווייַל אינדעקס מוזן זיין אין די דאַטן רעפטל און נישט גלייַך צו פּאָס.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // פּלאָמבירן די לאָך ווידער
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// אַ יטעראַטאָר איבער די עלעמענטן פון אַ קס 00 קס.
///
/// דעם קס 01 קס איז באשאפן דורך קס 00 קס.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) אַראָפּנעמען לטובת `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// אַן אָונער יטעראַטאָר איבער די עלעמענטן פון אַ `BinaryHeap`.
///
/// די `struct` איז באשאפן דורך [`BinaryHeap::into_iter()`] (צוגעשטעלט דורך די `IntoIterator` trait).
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// א דריינינג יטעראַטאָר איבער די עלעמענטן פון אַ קס 00 קס.
///
/// דעם קס 01 קס איז באשאפן דורך קס 00 קס.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// א דריינינג יטעראַטאָר איבער די עלעמענטן פון אַ קס 00 קס.
///
/// דעם קס 01 קס איז באשאפן דורך קס 00 קס.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// רימוווז הויפן עלעמענטן אין הויפן סדר.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// קאָנווערט אַ `Vec<T>` אין אַ `BinaryHeap<T>`.
    ///
    /// די קאַנווערזשאַן כאַפּאַנז אין-אָרט און האט *O*(*N*) צייט קאַמפּלעקסיטי.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// קאָנווערט אַ `BinaryHeap<T>` אין אַ `Vec<T>`.
    ///
    /// די קאַנווערזשאַן ריקווייערז קיין דאַטן באַוועגונג אָדער אַלאַקיישאַן און האט קעסיידערדיק צייט קאַמפּלעקסיטי.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// קריייץ אַ קאַנסומינג יטעראַטאָר, וואָס הייסט איינער וואָס מאָווינג יעדער ווערט פון די ביינערי קופּע אין אַרביטראַריש סדר.
    /// די ביינערי קופּע קענען ניט זיין געוויינט נאָך רופן דעם.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // דרוקן 1, 2, 3, 4 אין אַרביטראַרישער סדר
    /// for x in heap.into_iter() {
    ///     // רענטגענ האט טיפּ קס 01 קס, נישט קס 00 קס
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}