use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// א פּלאַן פֿאַר קראַך פּרובירן דאַמי ינסטאַנסיז וואָס מאָניטאָר באַזונדער געשעענישן.
/// עטלעכע ינסטאַנסיז קען זיין קאַנפיגיערד צו panic אין עטלעכע פונט.
/// געשעענישן זענען קס 01 קס, קס 02 קס אָדער אַן אַנאָנימע באַנוצערס קס 00 קס.
///
/// קראַך טעסט דאַמיז זענען יידענאַפייד און אָרדערד דורך אַ ID, אַזוי זיי קענען ווערן געניצט ווי שליסלען אין אַ BTreeMap.
/// די ימפּלאַמענטיישאַן בעקיוון ניצט טוט נישט פאַרלאָזנ אויף עפּעס דיפיינד אין די crate, אַחוץ פון די `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// קרעאַטעס אַ קראַך פּרובירן באָק פּלאַן.די `id` באשלאסן סדר און יקוואַלאַטי פון ינסטאַנסיז.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// קרעאַטעס אַ בייַשפּיל פון אַ קראַך פּרובירן באָק אַז רעקאָרדירט וואָס געשעענישן עס יקספּיריאַנסיז און אָפּטיאָנאַללי panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// קערט ווי פילע מאָל די ינסטאַנסיז פון די באָק זענען קלאָונד.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// קערט ווי פילע מאָל די פאַלן פון די באָק האָבן שוין דראַפּט.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// קערט ווי פילע מאָל די `query` מיטגליד איז געווען ינוואָוקאַד אין ינסטאַנסיז פון די באָק.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// עטלעכע אַנאָנימע באַנוצערס אָנפֿרעג, דער רעזולטאַט פון וואָס איז שוין געגעבן.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}