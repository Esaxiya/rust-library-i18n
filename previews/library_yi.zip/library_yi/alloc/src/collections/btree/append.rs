use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// אַפּפּענדס אַלע שליסל-ווערט פּערז פון דער פאַרבאַנד פון צוויי יטעראַטאָרס, וואָס ינקריסינג אַ `length` בייַטעוודיק אויף דעם וועג.דער יענער מאכט עס גרינגער פֿאַר די קאַללער צו ויסמיידן אַ רינען ווען אַ קאַפּ האַנדלער פּאַניק.
    ///
    /// אויב ביידע יטעראַטאָרס פּראָדוצירן די זעלבע שליסל, דעם אופֿן דראָז די פּאָר פון די לינקס יטעראַטאָר און אַפּפּענדז די פּאָר פון די רעכט יטעראַטאָר.
    ///
    /// אויב איר ווילט אַז דער בוים זאָל ענדיקן אין אַ שטרענג אַסענדינג סדר, ווי פֿאַר אַ `BTreeMap`, ביידע יטעראַטאָרס זאָל פּראָדוצירן שליסלען אין שטרענג אַסענדינג סדר, יעדער גרעסער ווי אַלע שליסלען אין דעם בוים, אַרייַנגערעכנט קיין שליסלען וואָס זענען שוין אין דעם בוים.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // מיר גרייטן זיך צו צונויפגיסן `left` און `right` אין אַ סאָרטירט סיקוואַנס אין לינעאַר צייט.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // דערווייַל, מיר בויען אַ בוים פֿון די סאָרטעד סיקוואַנס אין לינעאַר צייט.
        self.bulk_push(iter, length)
    }

    /// פּושאַז אַלע שליסל-ווערט פּערז צו די סוף פון די בוים, ינקרימענדינג אַ `length` בייַטעוודיק אויף דעם וועג.
    /// דער יענער מאכט עס גרינגער פֿאַר די קאַללער צו ויסמיידן אַ רינען ווען די יטעראַטאָר פּאַניק.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // יטעראַטע דורך אַלע שליסל-ווערט פּערז, פּושינג זיי אין נאָודז אויף די רעכט מדרגה.
        for (key, value) in iter {
            // פּרובירן צו שטופּן די שליסל-ווערט פּאָר אין די קראַנט בלאַט נאָדע.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // קיין פּלאַץ לינקס, גיין אַרויף און שטופּן דאָרט.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // געפֿונען אַ נאָדע מיט פּלאַץ לינקס, שטופּן דאָ.
                                open_node = parent;
                                break;
                            } else {
                                // גיי אַרויף ווידער.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // מיר זענען אין שפּיץ, שאַפֿן אַ נייַ וואָרצל נאָדע און שטופּן דאָרט.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // שטופּן שליסל-ווערט פּאָר און נייַ רעכט סובטרעע.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // גיין אַראָפּ צו די רעכט בלאַט.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // ינקרעמענט לענג יעדער יטעראַטיאָן, צו מאַכן זיכער אַז די מאַפּע טראפנס די אַפּפּענדעד עלעמענטן אפילו אויב די יטעראַטאָר פּאַניקס.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// אַ יטעראַטאָר פֿאַר מערדזשינג צוויי אויסגעשטעלט סיקוואַנסיז אין איין
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// אויב צוויי שליסלען זענען גלייַך, קערט די שליסל-ווערט פּאָר פֿון די רעכט מקור.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}