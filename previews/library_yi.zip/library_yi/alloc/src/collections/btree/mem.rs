use core::intrinsics;
use core::mem;
use core::ptr;

/// דאָס ריפּלייסיז די ווערט הינטער די `v` יינציק רעפֿערענץ דורך פאַך די באַטייַטיק פונקציע.
///
///
/// אויב אַ panic אַקערז אין די `change` קלאָוזשער, די גאנצע פּראָצעס וועט זיין אַבאָרטיד.
#[allow(dead_code)] // האַלטן ווי יללוסטראַטיאָן און פֿאַר future נוצן
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// דאָס ריפּלייסיז די ווערט הינטער די `v` יינציק רעפֿערענץ דורך פאַך די באַטייַטיק פונקציע און קערט אַ רעזולטאַט באקומען אויף דעם וועג.
///
///
/// אויב אַ panic אַקערז אין די `change` קלאָוזשער, די גאנצע פּראָצעס וועט זיין אַבאָרטיד.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}