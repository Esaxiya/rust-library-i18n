// דאָס איז אַן פּרווון צו ימפּלאַמענטיישאַן נאָך דעם אידעאל
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// זינט Z0 רוסט 0 ז טוט ניט אַקשלי אָפענגיק טייפּס און פּאַלימאָרפיק רעקורסיאָן, מיר מאַכן גענוג מיט אַנסאַפעטי.
//

// א הויפּט ציל פון דעם מאָדולע איז צו ויסמיידן קאַמפּלעקסיטי דורך טרעאַטינג דעם בוים ווי אַ דזשאַנעריק (אויב טשודנע שייפּט) קאַנטיינער און אַוווידיד צו האַנדלען מיט רובֿ פון די B-Tree ינוואַריאַנץ.
//
// ווי אַזאַ, דעם מאָדולע קען נישט זאָרגן צי די איינסן זענען אויסגעשטעלט, וואָס נאָודז קענען זיין ונדערפולל, אָדער אפילו וואָס ונדערפולל מיטל.מיר פאַרלאָזנ זיך אָבער אויף עטלעכע ינוועריאַנץ:
//
// - ביימער מוזן האָבן יונאַפאָרמלי קס 00 קס.דעם מיטל אַז יעדער דרך אַראָפּ צו אַ בלאַט פון אַ געגעבן נאָדע האט פּונקט די זעלבע לענג.
// - א נאָדע מיט די לענג `n` האט `n` שליסלען, `n` וואַלועס און `n + 1` עדזשאַז.
//   דעם ימפּלייז אַז אפילו אַ ליידיק נאָדע האט לפּחות איין ז 0 עדגע 0 ז.
//   פֿאַר אַ בלאַט נאָדע, "having an edge" מיינט בלויז אַז מיר קענען ידענטיפיצירן אַ שטעלע אין די נאָדע, ווייַל בלאַט עדזשאַז זענען ליידיק און דאַרפֿן קיין דאַטן פאַרטרעטונג.
// אין אַ ינערלעך נאָדע, אַ edge ביידע יידענאַפייד אַ שטעלע און כּולל אַ טייַטל צו אַ קינד נאָדע.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// די אַנדערלייינג פאַרטרעטונג פון בלאַט נאָודז און טייל פון די פאַרטרעטונג פון ינערלעך נאָודז.
struct LeafNode<K, V> {
    /// מיר וועלן זיין קאָוואַריאַנט אין קס 01 קס און קס 00 קס.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// די אינדעקס פון דעם נאָדע אין די `edges` מענגע פון די פאָטער נאָדע.
    /// `*node.parent.edges[node.parent_idx]` זאָל זיין די זעלבע זאַך ווי `node`.
    /// דעם איז געראַנטיד צו זיין ינישיייטיד ווען `parent` איז ניט-נאַל.
    parent_idx: MaybeUninit<u16>,

    /// די נומער פון שליסלען און וואַלועס אַז נאָדע סטאָרז.
    len: u16,

    /// די ערייז סטאָרינג די פאַקטיש דאַטן פון די נאָדע.
    /// בלויז די ערשטע `len` עלעמענטן פון יעדער מענגע זענען יניטיאַליזעד און גילטיק.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// יניטיאַליזעס אַ נייַע `LeafNode` אין-אָרט.
    unsafe fn init(this: *mut Self) {
        // ווי אַ גענעראַל פּאָליטיק, מיר לאָזן פעלדער אַנינישיייטיד אויב זיי קענען זיין, ווייַל דאָס זאָל זיין אַ ביסל פאַסטער און גרינגער צו שפּור אין וואַלגרינד.
        //
        unsafe {
            // עלטערן_ידקס, שליסלען, און וואַלס זענען אַלע מייַאָנעליניניט
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// קרעאַטעס אַ נייַ באַקסעד קס 00 קס.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// די אַנדערלייינג פאַרטרעטונג פון ינערלעך נאָודז.ווי מיט 'LeafNode`s, די זאָל זיין פאַרבאָרגן הינטער' BoxedNode 'צו פאַרמייַדן דראַפּינג אַניניטיאַליזעד שליסלען און וואַלועס.
/// קיין טייַטל צו די `InternalNode` קענען זיין גלייך וואַרפן צו אַ טייַטל צו די אַנדערלייינג `LeafNode` חלק פון די נאָדע, אַלאַוינג קאָד צו פירן אויף בלאַט און ינערלעך נאָודז דזשאַנעריקלי אָן אפילו קאָנטראָלירן וואָס פון די צוויי אַ טייַטל ווייזט אויף.
///
/// די פאַרמאָג איז ענייבאַלד דורך די נוצן פון `repr(C)`.
///
#[repr(C)]
// gdb_providers.py ניצט דעם טיפּ נאָמען פֿאַר ינטראַספּעקשאַן.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// די פּוינטערז צו די קינדער פון דעם נאָדע.
    /// `len + 1` עטלעכע פון זיי זענען גערעכנט יניטיאַליזעד און גילטיק, אַחוץ אַז לעבן דעם סוף, בשעת דער בוים איז געהאלטן דורך באָרגן טיפּ קס 00 קס, עטלעכע פון די פּוינטערז זענען דאַנגגלינג.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// קרעאַטעס אַ נייַ באַקסעד קס 00 קס.
    ///
    /// # Safety
    /// אַן ינוועריאַנט פון ינערלעך נאָודז איז אַז זיי האָבן לפּחות איין יניטיאַלייזד און גילטיק edge.
    /// די פונקציע קען נישט שטעלן אַזאַ edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // מיר נאָר דאַרפֿן צו ינישאַלייז די דאַטן;די עדזשאַז זענען מייַבעוניניניט.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// א געראטן, ניט-נאַל טייַטל צו אַ נאָדע.דאָס איז אָדער אַ אָונד טייַטל צו קס 01 קס אָדער אַן אָונד טייַטל צו קס 00 קס.
///
/// אָבער, `BoxedNode` כּולל קיין אינפֿאָרמאַציע וועגן וואָס פון די צוויי טייפּס פון נאָודז עס אַקשלי כּולל, און טייל פון די פעלן פון אינפֿאָרמאַציע איז נישט אַ באַזונדער טיפּ און האט קיין דעסטרוקטאָר.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// דער וואָרצל נאָדע פון אַן אָונד בוים.
///
/// באַמערקונג אַז דאָס טוט נישט האָבן אַ דעסטרוקטאָר, און עס מוזן זיין רייניקונג מאַניואַלי.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// קערט אַ נייַ אָונד בוים מיט אַן אייגענע וואָרצל נאָדע וואָס איז טכילעס ליידיק.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` מוזן נישט זיין נול.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// מוטאַבלי באַראָוז די אָונד וואָרצל נאָדע.
    /// ניט ענלעך `reborrow_mut`, דאָס איז זיכער ווייַל די צוריקקער ווערט קענען ניט זיין געניצט צו צעשטערן דעם וואָרצל און עס קען נישט זיין אנדערע באַווייַזן צו דעם בוים.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// אַ ביסל מיוטאַבאַל באַראָוז די אָונד וואָרצל נאָדע.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// יריווערסאַבלי טראַנזישאַנז צו אַ רעפֿערענץ וואָס אַלאַוז דורכפאָר און אָפפערס דעסטרוקטיווע מעטהאָדס און ביסל אַנדערש.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// מוסיף אַ נייַ ינערלעך נאָדע מיט אַ איין edge וואָס ווייזט צו די פריערדיקע וואָרצל נאָדע, מאַכן דעם נייַ נאָדע די וואָרצל נאָדע און צוריקקומען עס.
    /// דאָס ינקריסיז די הייך פון 1 און איז די פאַרקערט פון `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, אַחוץ אַז מיר נאָר פארגעסן אַז מיר זענען ינערלעך איצט:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// רימוווז די ינערלעך וואָרצל נאָדע, ניצן זיין ערשטער קינד ווי די נייַ וואָרצל נאָדע.
    /// ווי עס איז בדעה בלויז צו זיין גערופן ווען דער וואָרצל נאָדע האט בלויז איין קינד, קיין רייניקונג איז געטאן אויף קיין שליסלען, וואַלועס און אנדערע קינדער.
    ///
    /// דאָס דיקריסיז די הייך פון 1 און איז די פאַרקערט פון `push_internal_level`.
    ///
    /// ריקווייערז ויסשליסיק אַקסעס צו די קס 00 קס כייפעץ אָבער נישט צו די וואָרצל נאָדע;
    /// עס וועט נישט פאַרקריפּלט אנדערע כאַנדאַלז אָדער באַווייַזן צו דער וואָרצל נאָדע.
    ///
    /// Panics אויב עס איז קיין ינערלעך מדרגה, דאס הייסט אויב דער וואָרצל נאָדע איז אַ בלאַט.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // זיכערקייט: מיר האָבן געזאָגט אַז מיר זענען ינערלעך.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // זיכערקייט: מיר באַראָוד `self` אויסשליסלעך און די באָרגן טיפּ איז ויסשליסיק.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // זיכערקייט: דער ערשטער edge איז שטענדיק יניטיאַליזעד.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` איז שטענדיק קאָוואַריאַנט אין `K` און `V`, אפילו ווען `BorrowType` איז `Mut`.
// דעם איז טעקניקלי פאַלש, אָבער קען נישט רעזולטאַט אין אַנסאַפעטי רעכט צו ינערלעך נוצן פון קס 01 קס ווייַל מיר בלייבן גאָר דזשאַנעריק איבער קס 02 קס און קס 00 קס.
//
// אָבער, ווען אַן עפֿנטלעכע טיפּ ראַפּס `NodeRef`, מאַכן זיכער אַז עס איז די ריכטיק דיפעראַנסיז.
//
/// א רעפֿערענץ צו אַ נאָדע.
///
/// דער טיפּ האט אַ נומער פון פּאַראַמעטערס וואָס קאָנטראָלירן ווי עס אַקץ:
/// - `BorrowType`: א באָק טיפּ וואָס באשרייבט די סאָרט פון באָרגן און קאַריז אַ גאַנץ לעבן.
///    - ווען דאָס איז קס 01 קס, די קס 02 קס אַקץ בעערעך ווי קס 00 קס.
///    - אויב דאָס איז `ValMut<'a>`, די `NodeRef` אַקץ בעערעך ווי `&'a Node` וועגן קיז און בוים סטרוקטור, אָבער אויך אַלאַוז פילע מיוטאַבאַל באַווייַזן צו וואַלועס איבער די בוים.
///    - ווען דאָס איז `Mut<'a>`, די `NodeRef` אַקץ בעערעך ווי `&'a mut Node`, כאָטש ינסערט מעטהאָדס לאָזן אַ מיוטאַבאַל טייַטל צו אַ ווערט צו קאָויגז.
///    - ווען דאָס איז `Owned`, די `NodeRef` אַקץ בעערעך ווי `Box<Node>`, אָבער עס האט נישט אַ דעסטרוקטאָר, און עס מוזן זיין רייניקונג מאַניואַלי.
///    - אויב דאָס איז `Dying`, די `NodeRef` איז נאָך בעערעך ווי `Box<Node>`, אָבער מיט מעטהאָדס צו צעשטערן דעם בוים ביסל ביי ביסל, און געוויינטלעך מעטהאָדס, כאָטש זיי זענען נישט אנגעצייכנט ווי אַנסייף צו רופן, קענען רופן UB אויב עס איז פאַלש גערופן.
///
///   זינט X11X אַלאַוז נאַוואַגייטינג דורך דעם בוים, `BorrowType` אַפּלייז יפעקטיוולי צו די גאנצע בוים, ניט נאָר צו די נאָדע זיך.
/// - `K` און קס 00 קס: דאָס זענען די טייפּס פון שליסלען און וואַלועס סטאָרד אין די נאָודז.
/// - `Type`: דאָס קען זיין `Leaf`, `Internal` אָדער `LeafOrInternal`.
/// ווען דאָס איז `Leaf`, די `NodeRef` ווייזט צו אַ בלאַט נאָדע, ווען `Internal`, די `NodeRef` ווייזט צו אַ ינערלעך נאָדע, און ווען דאָס איז `LeafOrInternal`, די `NodeRef` קען ווייַזן צו יעדער טיפּ פון נאָדע.
///   `Type` איז געהייסן קס 01 קס ווען געוויינט אַרויס קס 00 קס.
///
/// ביידע קס 00 קס און קס 01 קס באַגרענעצן וואָס מעטהאָדס מיר ינסטרומענט, צו גווורע סטאַטיק טיפּ זיכערקייַט.עס זענען לימיטיישאַנז צו נוצן אַזאַ ריסטריקשאַנז:
/// - פֿאַר יעדער טיפּ פּאַראַמעטער, מיר קענען בלויז דעפינירן אַ מעטאָד אָדער דזשענעראַלי אָדער פֿאַר אַ באַזונדער טיפּ.
/// פֿאַר בייַשפּיל, מיר קענען נישט דעפינירן אַ מעטאָד ווי קס 01 קס דזשאַנעריקלי פֿאַר אַלע קס 00 קס, אָדער אַמאָל פֿאַר אַלע טייפּס וואָס האָבן אַ גאַנץ לעבן ווייַל מיר וועלן עס זאָל צוריקקומען קס 02 קס באַווייַזן.
///   דעריבער, מיר דעפינירן עס בלויז פֿאַר די מינדסטער שטאַרק טיפּ `Immut<'a>`.
/// - מיר קענען נישט באַקומען ימפּליסאַט געצווונגען פון זאָגן קס 01 קס צו קס 00 קס.
///   דעריבער, מיר האָבן צו עקספּרעססלי רופן קס 01 קס אויף אַ מער שטאַרק קס 02 קס צו דערגרייכן אַ מעטאָד ווי קס 00 קס.
///
/// אַלע מעטהאָדס אויף קס 00 קס וואָס ווייַזן עטלעכע רעפֿערענץ, אָדער:
/// - נעמען קס 01 קס לויט ווערט, און צוריקקומען די לעבן געטראגן דורך קס 00 קס.
///   צו נוצן אַזאַ אַ אופֿן, מיר דאַרפֿן צו רופן X00 קס.
/// - נעמען קס 01 קס דורך דערמאָנען, און קס 02 קס צוריקקומען די לעבן פון דער רעפֿערענץ אַנשטאָט פון די לעבן געטראגן דורך קס 00 קס.
/// דער וועג די באַראָוינג קאָנטראָליאָר געראַנטיז אַז די `NodeRef` בלייבט באַראָוד ווי לאַנג ווי די אומגעקערט רעפֿערענץ איז געניצט.
///   די מעטהאָדס וואָס שטיצן ינסערטשאַן בייגן דעם הערשן דורך צוריקקומען אַ רוי טייַטל, דאָס הייסט אַ רעפֿערענץ אָן קיין לעבן.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// די נומער פון לעוועלס וואָס די נאָדע און די בלעטער זענען באַזונדער, אַ קעסיידערדיק נומער פון די נאָדע וואָס קענען נישט זיין דיסקרייבד דורך `Type`, און די נאָדע זיך איז נישט סטאָרד.
    /// מיר נאָר דאַרפֿן צו קראָם די הייך פון די וואָרצל נאָדע און דערייווד די הייך פון יעדער אנדערע נאָדע.
    /// מוזן זיין נול אויב `Type` איז `Leaf` און ניט-נול אויב `Type` איז `Internal`.
    ///
    ///
    height: usize,
    /// דער טייַטל צו די בלאַט אָדער ינערלעך נאָדע.
    /// די דעפֿיניציע פון קס 00 קס ינשורז אַז דער טייַטל איז גילטיק אין קיין וועג.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// אַנפּאַק אַ נאָדע רעפערענץ וואָס איז געווען פּאַקט ווי `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// יקספּאָוזד די דאַטן פון אַ ינערלעך נאָדע.
    ///
    /// קערט אַ רוי פּטר צו ויסמיידן ינוואַלידייטינג אנדערע באַווייַזן צו דעם נאָדע.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // זיכערקייט: די סטאַטיק נאָדע טיפּ איז `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// באָראָוז ויסשליסיק אַקסעס צו די דאַטן פון אַ ינערלעך נאָדע.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// געפֿינען די לענג פון די נאָדע.דאָס איז די נומער פון שליסלען אָדער וואַלועס.
    /// די נומער פון עדזשאַז איז `len() + 1`.
    /// באַמערקונג אַז טראָץ זיכער, רופן דעם פֿונקציע קען האָבן די זייַט ווירקונג פון ינוואַלאַדייטינג מיוטאַבאַל באַווייַזן אַז אַנסייף קאָד באשאפן.
    ///
    pub fn len(&self) -> usize {
        // קריטיש, מיר בלויז אַקסעס די `len` פעלד דאָ.
        // אויב באָרראָוגהטיפּע איז קס 00 קס, עס קען זיין בוילעט מיוטאַבאַל באַווייַזן צו וואַלועס וואָס מיר מוזן נישט פאַרקריפּלט.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// קערט די נומער פון לעוועלס אַז די נאָדע און בלעטער זענען באַזונדער.
    /// נול הייך מיטל אַז די נאָדע איז אַ בלאַט זיך.
    /// אויב איר בילד ביימער מיט די שורש אויף שפּיץ, די נומער זאגט אין וואָס הייך די נאָדע אויס.
    /// אויב איר בילד ביימער מיט בלעטער אויף שפּיץ, די נומער זאגט ווי הויך דער בוים יקסטענדז אויבן די נאָדע.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// טעמפּערעראַלי נעמט אן אנדער, יממוטאַבאַל דערמאָנען צו די זעלבע נאָדע.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// יקספּאָוזיז די בלאַט חלק פון קיין בלאַט אָדער ינערלעך נאָדע.
    ///
    /// קערט אַ רוי פּטר צו ויסמיידן ינוואַלידייטינג אנדערע באַווייַזן צו דעם נאָדע.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // די נאָדע מוזן זיין גילטיק פֿאַר לפּחות די LeafNode חלק.
        // דאָס איז נישט אַ רעפֿערענץ אין די נאָדערעף טיפּ ווייַל מיר טאָן ניט וויסן אויב עס זאָל זיין יינציק אָדער שערד.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// געפֿינען די פאָטער פון די קראַנט נאָדע.
    /// קערט `Ok(handle)` אויב די קראַנט נאָדע אַקטשאַוואַלי האט אַ פאָטער, ווו `handle` ווייזט צו די edge פון די פאָטער וואָס ווייזט צו די קראַנט נאָדע.
    ///
    /// קערט קס 01 קס אויב די קראַנט נאָדע האט קיין פאָטער, געבן צוריק די אָריגינעל קס 00 קס.
    ///
    /// די מעטאָד נאָמען אַסומז איר בילד ביימער מיט די וואָרצל נאָדע אויף שפּיץ.
    ///
    /// `edge.descend().ascend().unwrap()` און קס 00 קס זאָל ביידע, נאָך הצלחה, טאָן גאָרנישט.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // מיר דאַרפֿן צו נוצן רוי פּוינטערז צו נאָודז ווייַל אויב BorrowType איז marker::ValMut, עס קען זיין בוילעט מיוטאַבאַל באַווייַזן צו וואַלועס וואָס מיר מוזן נישט פאַרקריפּלט.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// באַמערקונג אַז `self` מוזן זיין נאַנעמפּטי.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// באַמערקונג אַז `self` מוזן זיין נאַנעמפּטי.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// יקספּאָוזד די בלאַט חלק פון קיין בלאַט אָדער ינערלעך נאָדע אין אַ ימיוטאַבאַל בוים.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // זיכערקייט: עס קען זיין קיין מיוטאַבאַל באַווייַזן אין דעם בוים באַראָוד ווי `Immut`.
        unsafe { &*ptr }
    }

    /// באָרראָווס אַ מיינונג פון די שליסלען סטאָרד אין די נאָדע.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// ענלעך צו קס 00 קס, געץ אַ רעפֿערענץ צו אַ פאָטער נאָדע פון אַ נאָדע, אָבער אויך דילאַקייץ די קראַנט נאָדע אין דעם פּראָצעס.
    /// דאָס איז אַנסייף ווייַל די קראַנט נאָדע וועט נאָך זיין צוטריטלעך טראָץ דילאַקייטיד.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ונסאַפעלי אַססעסס צו די קאַמפּיילער די סטאַטיק אינפֿאָרמאַציע אַז דער נאָדע איז אַ קס 00 קס.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ונסאַפעלי אַססעסס צו די קאַמפּיילער די סטאַטיק אינפֿאָרמאַציע אַז די נאָדע איז אַן `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// טעמפּערעראַלי נעמט אן אנדער, מיוטאַבאַל דערמאָנען צו די זעלבע נאָדע.היט אייך, ווייַל דעם אופֿן איז זייער געפערלעך, טאָפּל אַזוי ווייַל עס קען נישט גלייך דערשייַנען געפערלעך.
    ///
    /// ווייַל מיוטאַבאַל פּוינטערז קענען אַרומוואַנדערן ערגעץ אַרום דעם בוים.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) באַטראַכטן צו לייגן אן אנדער טיפּ פּאַראַמעטער צו קס 00 קס וואָס ריסטריקץ די נוצן פון נאַוויגאַציע מעטהאָדס אויף ריבאָרראָוועד פּוינטערז, פּרעווענטינג דעם אַנסייף.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// באָראָוז ויסשליסיק אַקסעס צו די בלאַט טייל פון קיין בלאַט אָדער ינערלעך נאָדע.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // זיכערקייט: מיר האָבן ויסשליסיק אַקסעס צו די גאנצע נאָדע.
        unsafe { &mut *ptr }
    }

    /// אָפפערס ויסשליסיק אַקסעס צו די בלאַט חלק פון קיין בלאַט אָדער ינערלעך נאָדע.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // זיכערקייט: מיר האָבן ויסשליסיק אַקסעס צו די גאנצע נאָדע.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// באָראָוז ויסשליסיק אַקסעס צו אַן עלעמענט פון דער שליסל סטאָרידזש געגנט.
    ///
    /// # Safety
    /// `index` איז אין גווול פון 0 .. קאַפּאַסיטי
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // זיכערקייט: די קאַללער קענען נישט קענען צו רופן זיך מעטהאָדס אויף זיך
        // ביז דער שליסל רעפטל רעפערענץ איז דראַפּט ווייַל מיר האָבן יינציק אַקסעס פֿאַר די לעבן פון די באַראָוד.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// באָראָוז ויסשליסיק אַקסעס צו אַן עלעמענט אָדער רעפטל פון די ווערט סטאָרידזש געגנט פון די נאָדע.
    ///
    /// # Safety
    /// `index` איז אין גווול פון 0 .. קאַפּאַסיטי
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // זיכערקייט: די קאַללער קענען נישט קענען צו רופן זיך מעטהאָדס אויף זיך
        // ביז דער ווערט רעפטל רעפערענץ איז דראַפּט ווייַל מיר האָבן יינציק אַקסעס פֿאַר די לעבן פון די באַראָוד.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// באָראָוז ויסשליסיק אַקסעס צו אַן עלעמענט אָדער רעפטל פון די סטאָרידזש געגנט פון די נאָדע פֿאַר ז0 עדגע 0 ז אינהאַלט.
    ///
    /// # Safety
    /// `index` איז אין גווול פון 0 .. CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // זיכערקייט: די קאַללער קענען נישט קענען צו רופן זיך מעטהאָדס אויף זיך
        // ביז די edge רעפטל פון רעפטל איז דראַפּט ווייַל מיר האָבן יינציק אַקסעס פֿאַר די לעבן פון די באַראָוד.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - די נאָדע האט מער ווי `idx` יניטיאַלייזד עלעמענטן.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // מיר בלויז מאַכן אַ רעפֿערענץ צו די איין עלעמענט וואָס מיר זענען אינטערעסירט אין, צו ויסמיידן אַליאַסינג מיט בוילעט באַווייַזן צו אנדערע עלעמענטן, אין באַזונדער, יענע אומגעקערט צו די קאַללער אין פריער יטעראַטיאָנס.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // מיר מוזן צווינגען אַנסייזד מענגע פּוינטערז ווייַל Rust אַרויסגעבן קס 00 קס.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// באָראָוז ויסשליסיק אַקסעס צו די לענג פון די נאָדע.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// שטעלט די לינק פון די נאָדע צו זיין פאָטער edge, אָן ינוואַלאַדייטינג אנדערע באַווייַזן צו די נאָדע.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// קלירז די וואָרצל ס לינק צו זיין פאָטער edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// לייגט אַ שליסל-ווערט פּאָר צו די סוף פון די נאָדע.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// יעדער נומער וואָס איז אומגעקערט דורך `range` איז אַ גילטיק edge אינדעקס פֿאַר די נאָדע.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// לייגט אַ שליסל-ווערט פּאָר, און אַ Z0 עדגע 0 ז צו גיין צו די רעכט פון די פּאָר, צו די סוף פון די נאָדע.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// טשעקס צי אַ נאָדע איז אַ `Internal` נאָדע אָדער אַ `Leaf` נאָדע.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// א רעפֿערענץ צו אַ ספּעציפיש שליסל-ווערט פּאָר אָדער ז 0 עדגע 0 ז ין אַ נאָדע.
/// די `Node` פּאַראַמעטער מוזן זיין אַ `NodeRef`, בשעת די `Type` קענען זיין `KV` (סיגנאַלינג אַ שעפּן אויף אַ שליסל-ווערט פּאָר) אָדער `Edge` (סיגנאַלינג אַ שעפּן אויף אַ edge).
///
/// באַמערקונג אַז אפילו קס 00 קס נאָודז קענען האָבן קס 01 קס כאַנדאַלז.
/// אַנשטאָט רעפּריזענטינג אַ טייַטל צו אַ קינד נאָדע, דאָס רעפּראַזענץ די ספּייסאַז ווו קינד פּוינטערז וואָלט גיין צווישן די שליסל-ווערט פּערז.
/// צום ביישפּיל, אין אַ נאָדע מיט לענג 2, עס וואָלט זיין 3 מעגלעך edge לאָוקיישאַנז, איינער צו די לינקס פון די נאָדע, איינער צווישן די צוויי פּערז און איינער רעכט פון די נאָדע.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// מיר טאָן ניט דאַרפֿן די פול אַלגעמיינע פון `#[derive(Clone)]`, ווייַל די בלויז `Node` וועט זיין `קלאָון` איז ווען עס איז אַ ימיוטאַבאַל רעפֿערענץ און דעריבער `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ריטריווז די נאָדע אַז כּולל די Z0 עדגע 0 ז אָדער שליסל-ווערט פּאָר דעם שעפּן ווייזט צו.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// קערט די שטעלע פון דעם שעפּן אין די נאָדע.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// קרעאַטעס אַ נייַ שעפּן צו אַ שליסל-ווערט פּאָר אין `node`.
    /// אַנסייף ווייַל די קאַללער מוזן ענשור אַז קס 00 קס.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// קען זיין אַ עפנטלעך ימפּלאַמענטיישאַן פון PartialEq, אָבער בלויז געניצט אין דעם מאָדולע.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// נעמט טעמפּערעראַלי אן אנדער יממוטאַבאַל שעפּן אויף דער זעלביקער אָרט.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // מיר קענען נישט נוצן Handle::new_kv אָדער Handle::new_edge ווייַל מיר טאָן ניט וויסן אונדזער טיפּ
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// ונסאַפעלי אַססעסס צו די קאַמפּיילער די סטאַטיק אינפֿאָרמאַציע אַז די נאָדע פון די שעפּן איז אַ קס X קס.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// טעמפּערעראַלי נעמט אן אנדער, מיוטאַבאַל שעפּן אויף דער זעלביקער אָרט.
    /// היט אייך, ווייַל דעם אופֿן איז זייער געפערלעך, טאָפּל אַזוי ווייַל עס קען נישט גלייך דערשייַנען געפערלעך.
    ///
    ///
    /// פֿאַר פּרטים, זען `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // מיר קענען נישט נוצן Handle::new_kv אָדער Handle::new_edge ווייַל מיר טאָן ניט וויסן אונדזער טיפּ
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// קרעאַטעס אַ נייַ שעפּן צו אַ edge אין `node`.
    /// אַנסייף ווייַל די קאַללער מוזן ענשור אַז קס 00 קס.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// מיט אַ edge אינדעקס וווּ מיר וועלן צו שטעלן זיך אין אַ נאָדע אָנגעפילט צו קאַפּאַציטעט, קאַמפּיוץ אַ פיליק קוו אינדעקס פון אַ שפּאַלטן פונט און ווו צו דורכפירן די ינסערשאַן.
///
/// דער ציל פון די שפּאַלטן פונט איז אַז דער שליסל און ווערט צו ענדיקן זיך אין אַ פאָטער נאָדע;
/// די שליסלען, וואַלועס און עדזשאַז צו די לינקס פון די שפּאַלטן פונט ווערן די לינקס קינד;
/// די שליסלען, וואַלועס און עדזשאַז צו די רעכט פון די שפּאַלטן פונט ווערן די רעכט קינד.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust אַרויסגעבן קס 00 קס פרוווט צו דערקלערן די סיממעטריק כּללים.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ינסערט אַ נייַ שליסל-ווערט פּאָר צווישן די שליסל-ווערט פּערז צו די רעכט און לינקס פון דעם edge.
    /// דעם אופֿן אַסומז אַז עס איז גענוג פּלאַץ אין די נאָדע פֿאַר די נייַ פּאָר צו פּאַסיק.
    ///
    /// די אומגעקערט טייַטל ווייזט צו די ינסערטאַד ווערט.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ינסערט אַ נייַ שליסל-ווערט פּאָר צווישן די שליסל-ווערט פּערז צו די רעכט און לינקס פון דעם edge.
    /// דער אופֿן ספּליץ די נאָדע אויב עס איז נישט גענוג פּלאַץ.
    ///
    /// די אומגעקערט טייַטל ווייזט צו די ינסערטאַד ווערט.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// פיקסיז די פאָטער טייַטל און אינדעקס אין די קינד נאָדע וואָס די edge פֿאַרבינדט צו.
    /// דאָס איז נוציק ווען די אָרדערינג פון עדזשאַז איז פארענדערט,
    fn correct_parent_link(self) {
        // שאַפֿן באַקקפּאָינט אָן אַנוואַלידייטינג אנדערע באַווייַזן צו די נאָדע.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ינסערט אַ נייַ שליסל-ווערט פּאָר און אַ Z0 עדגע 0 ז וואָס וועט גיין צו די רעכט פון די נייַ פּאָר צווישן דעם Z0 עדגע 0 ז און די שליסל-ווערט פּאָר צו די רעכט פון דעם Z0 עדגע 0 ז.
    /// דעם אופֿן אַסומז אַז עס איז גענוג פּלאַץ אין די נאָדע פֿאַר די נייַ פּאָר צו פּאַסיק.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ינסערט אַ נייַ שליסל-ווערט פּאָר און אַ Z0 עדגע 0 ז וואָס וועט גיין צו די רעכט פון די נייַ פּאָר צווישן דעם Z0 עדגע 0 ז און די שליסל-ווערט פּאָר צו די רעכט פון דעם Z0 עדגע 0 ז.
    /// דער אופֿן ספּליץ די נאָדע אויב עס איז נישט גענוג פּלאַץ.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ינסערט אַ נייַ שליסל-ווערט פּאָר צווישן די שליסל-ווערט פּערז צו די רעכט און לינקס פון דעם edge.
    /// דער אופֿן ספּליץ די נאָדע אויב עס איז נישט גענוג פּלאַץ און פרוווט צו שטעלן די שפּאַלטן אַוועק אין די פאָטער נאָדער רעקורסיוועלי ביז די וואָרצל איז ריטשט.
    ///
    ///
    /// אויב די אומגעקערט רעזולטאַט איז אַ `Fit`, די נאָדע פון זיין שעפּן קענען זיין די edge נאָדע אָדער אַן אָוועס.
    /// אויב די אומגעקערט רעזולטאַט איז אַ `Split`, די `left` פעלד איז דער וואָרצל נאָדע.
    /// די אומגעקערט טייַטל ווייזט צו די ינסערטאַד ווערט.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// געפֿינען דעם נאָדע צו די edge.
    ///
    /// די מעטאָד נאָמען אַסומז איר בילד ביימער מיט די וואָרצל נאָדע אויף שפּיץ.
    ///
    /// `edge.descend().ascend().unwrap()` און קס 00 קס זאָל ביידע, נאָך הצלחה, טאָן גאָרנישט.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // מיר דאַרפֿן צו נוצן רוי פּוינטערז צו נאָודז ווייַל אויב BorrowType איז marker::ValMut, עס קען זיין בוילעט מיוטאַבאַל באַווייַזן צו וואַלועס וואָס מיר מוזן נישט פאַרקריפּלט.
        // עס איז קיין זאָרג צו אַקסעס די הייך פעלד ווייַל די ווערט איז קאַפּיד.
        // היט אייך אַז אַמאָל די נאָדע טייַטל איז דערפעראַנייטיד, מיר אַקסעס די עדזשאַז מענגע מיט אַ רעפֿערענץ (Rust אַרויסגעבן קס 00 קס) און ינוואַלידייט קיין אנדערע באַווייַזן צו אָדער ין דער מענגע, אויב עס איז אַרום.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // מיר קענען נישט רופן באַזונדער שליסל און ווערט מעטהאָדס, ווייַל די פאַך פון די רגע ינוואַלידייץ די רעפֿערענץ פֿון דער ערשטער.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// פאַרבייַטן די שליסל און ווערט אַז די קוו שעפּן רעפערס צו.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// העלפּס ימפּלאַמענטיישאַנז פון קס 01 קס פֿאַר אַ באַזונדער קס 00 קס, דורך זאָרגן פון בלאַט דאַטן.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// ספּליץ די אַנדערלייינג נאָדע אין דריי פּאַרץ:
    ///
    /// - די נאָדע איז טראַנגקייטיד בלויז כּולל די שליסל-ווערט פּערז צו די לינקס פון דעם שעפּן.
    /// - דער שליסל און די ווערט פון דעם שעפּן שפּיציק זענען יקסטראַקטיד.
    /// - אַלע שליסל-ווערט פּערז רעכט צו דעם שעפּן זענען שטעלן אין אַ נייַע אַלאַקייטיד נאָדע.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// רימוווז די שליסל-ווערט פּאָר שפּיציק אויף דעם שעפּן און קערט עס צוזאַמען מיט די edge אַז די שליסל-ווערט פּאָר קאַלאַפּסט אין.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// ספּליץ די אַנדערלייינג נאָדע אין דריי פּאַרץ:
    ///
    /// - די נאָדע איז טראַנגקייטיד צו כּולל בלויז די עדזשאַז און שליסל-ווערט פּערז צו די לינקס פון דעם שעפּן.
    /// - דער שליסל און די ווערט פון דעם שעפּן שפּיציק זענען יקסטראַקטיד.
    /// - אַלע די עדזשאַז און שליסל-ווערט פּערז רעכט צו דעם שעפּן זענען שטעלן אין אַ נייַ אַלאַקייטיד נאָדע.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// רעפּראַזענץ אַ סעסיע פֿאַר יוואַליוייטינג און דורכפירן אַ באַלאַנסינג אָפּעראַציע אַרום אַן אינערלעכער שליסל-ווערט פּאָר.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// טשוזיז אַ באַלאַנסינג קאָנטעקסט ינוואַלווינג די נאָדע ווי אַ קינד, אַזוי צווישן די קוו מיד צו די לינקס אָדער צו די רעכט אין די פאָטער נאָדע.
    /// קערט אַ `Err` אויב עס איז קיין פאָטער.
    /// Panics אויב דער פאָטער איז ליידיק.
    ///
    /// בעסער די לינקס זייַט צו זיין אָפּטימאַל אויב די געגעבן נאָדע איז עפעס ונדערפולל, דאָס איז בלויז אַז עס האט ווייניקערע עלעמענטן ווי זיין לינקס סיבלינג און ווי זיין רעכט סיבלינג.
    /// אין דעם פאַל, צונויפגיסן מיט די לינקס סיבלינג איז פאַסטער, ווייַל מיר נאָר דאַרפֿן צו מאַך די N יסודות פון די נאָדע, אַנשטאָט פון שיפטינג זיי צו די רעכט און מאַך מער ווי N עלעמענטן אין פראָנט.
    /// סטילינג פון די לינקס סיבלינג איז אויך טיפּיקלי פאַסטער, ווייַל מיר נאָר דאַרפֿן צו יבעררוק די N עלעמענטן פון די נאָדע צו די רעכט, אַנשטאָט פון שיפטינג לפּחות N פון די סיבלינג ס עלעמענטן צו די לינקס.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// קערט צי צונויפגיסן איז מעגלעך, ד"ה צי עס איז גענוג פּלאַץ אין אַ נאָדע צו פאַרבינדן די הויפט קוו מיט ביידע שכייניש קינד נאָודז.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// דורכפירן אַ צונויפגיסן און לאָזן אַ קלאָוזשער באַשליסן וואָס צו צוריקקומען.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // זיכערקייט: די הייך פון די נאָדעס וואָס זענען מערדזשד איז ונטער דער הייך
                // פון די נאָדע פון דעם ז 0 עדגע 0 ז, אַזוי אויבן נול, אַזוי זיי זענען ינערלעך.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// צונויפגיסן די שליסל-ווערט פּאָר פון די פאָטער און ביידע שכייניש קינד נאָודז אין די לינקס קינד נאָדע און קערט די שרינגק פאָטער נאָדע.
    ///
    ///
    /// Panics סייַדן מיר `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// צונויפגיסן די שליסל-ווערט פּאָר פון די פאָטער און ביידע שכייניש קינד נאָודז אין די לינקס קינד נאָדע און קערט דער קינד נאָדע.
    ///
    ///
    /// Panics סייַדן מיר `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// צונויפגיסן די שליסל-ווערט פּאָר פון די פאָטער און ביידע שכייניש קינד נאָודז אין די לינקס קינד נאָדע און קערט די edge שעפּן אין דעם קינד נאָדע ווו די טראַקט קינד edge ענדיקט זיך,
    ///
    ///
    /// Panics סייַדן מיר `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// רימוווז אַ שליסל-ווערט פּאָר פון די לינקס קינד און שטעלן עס אין די שליסל-ווערט סטאָרידזש פון די פאָטער, בשעת פּושינג די אַלט פאָטער שליסל-ווערט פּאָר אין די רעכט קינד.
    ///
    /// קערט צו די edge אין די רעכט קינד וואָס איז קאָראַספּאַנדינג צו די אָריגינעל edge וואָס איז געווען ספּעציפיצירט דורך `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// רימוווז אַ שליסל-ווערט פּאָר פון די רעכט קינד און לייגט עס אין די שליסל-ווערט סטאָרידזש פון די פאָטער, בשעת פּושינג די אַלט פאָטער שליסל-ווערט פּאָר אויף די לינקס קינד.
    ///
    /// קערט צו די ז 0 עדגע 0 ז אין די לינקס קינד ספּעציפיצירט דורך קס 00 קס, וואָס האט ניט רירן.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// דעם סטילינג ענלעך צו `steal_left` אָבער סטילז קייפל עלעמענטן אין אַמאָל.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // מאַכט זיכער אַז מיר קענען גאַנווענען בעשאָלעם.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // מאַך בלאַט דאַטן.
            {
                // מאַכן פּלאַץ פֿאַר סטאָלען עלעמענטן אין די רעכט קינד.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // מאַך עלעמענטן פון די לינקס קינד צו די רעכט.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // מאַך די לינקס-מערסט סטאָלען פּאָר צו די פאָטער.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // מאַך די שליסל-ווערט פּאָר פון די עלטערן צו די רעכט קינד.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // מאַכן פּלאַץ פֿאַר סטאָלען עדזשאַז.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // גאַנווענען עדזשאַז.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// די סיממעטריק קלאָון פון קס 00 קס.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // מאַכט זיכער אַז מיר קענען גאַנווענען בעשאָלעם.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // מאַך בלאַט דאַטן.
            {
                // מאַך די רעכט סטאָלען פּאָר צו די פאָטער.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // מאַך די שליסל-ווערט פּאָר פון די עלטערן צו די לינקס קינד.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // מאַך עלעמענטן פון די רעכט קינד צו די לינקס.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // פּלאָמבירן ריס ווו סטאָלען עלעמענטן זענען געווען.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // גאַנווענען עדזשאַז.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // פּלאָמבירן ריס ווו סטאָלען עדזשאַז געוויינט צו זיין.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// רימוווז סטאַטיק אינפֿאָרמאַציע אַז די נאָדע איז אַ `Leaf` נאָדע.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// רימוווז קיין סטאַטיק אינפֿאָרמאַציע אַז די נאָדע איז אַן `Internal` נאָדע.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// טשעקס צי די אַנדערלייינג נאָדע איז אַן `Internal` נאָדע אָדער אַ `Leaf` נאָדע.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// מאַך די סאַפיקס נאָך קס 01 קס פון איין נאָדע צו אנדערן.`right` מוזן זיין ליידיק.
    /// דער ערשטער edge פון `right` בלייבט אַנטשיינדזשד.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// רעזולטאַט פון ינסערשאַן, ווען אַ נאָדע דאַרף זיין יקספּאַנדיד ווייַטער פון זיין קאַפּאַציטעט.
pub struct SplitResult<'a, K, V, NodeType> {
    // אָלטערד נאָדע אין יגזיסטינג בוים מיט עלעמענטן און עדזשאַז וואָס זענען צו די לינקס פון `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // עטלעכע שליסל און ווערט שפּאַלטן אַוועק, צו זיין ינסערטאַד אנדערש.
    pub kv: (K, V),
    // אָונד, אַנאַטטשט, נייַ נאָדע מיט עלעמענטן און עדזשאַז וואָס געהערן צו די רעכט פון `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // צי נאָדע רעפערענצן פון דעם באַראָוד טיפּ לאָזן אַריבער צו אנדערע נאָודז אין דעם בוים.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // דורכפאָר איז ניט נידעד, עס כאַפּאַנז ניצן די רעזולטאַט פון קסקסנומקסקס.
        // דורך דיסייבלינג דורך דורכפאָר און בלויז שאַפֿן נייַע באַווייַזן צו רוץ, מיר וויסן אַז יעדער רעפֿערענץ פון די `Owned` טיפּ איז צו אַ וואָרצל נאָדע.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// ינסערט אַ ווערט אין אַ רעפטל פון יניטיאַליזעד עלעמענטן נאכגעגאנגען דורך איין וניניטיאַליזעד עלעמענט.
///
/// # Safety
/// די רעפטל האט מער ווי `idx` עלעמענטן.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// רימוווז און קערט אַ ווערט פֿון אַ רעפטל פון אַלע יניטיאַליזעד עלעמענטן, וואָס לאָזן איין טריינינג וניניטיאַליזעד עלעמענט.
///
///
/// # Safety
/// די רעפטל האט מער ווי `idx` עלעמענטן.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// שיפט די עלעמענטן אין אַ רעפטל `distance` שטעלעס צו די לינקס.
///
/// # Safety
/// די רעפטל האט לפּחות קס 00 קס עלעמענטן.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// שיפט די עלעמענטן אין אַ רעפטל `distance` שטעלעס צו די רעכט.
///
/// # Safety
/// די רעפטל האט לפּחות קס 00 קס עלעמענטן.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// באוועגט אַלע וואַלועס פון אַ רעפטל פון יניטיאַליזעד עלעמענטן צו אַ רעפטל פון אַניניטיאַליזעד עלעמענטן, ליווינג הינטער `src` ווי אַלע אַניניטיאַליזעד.
///
/// אַרבעט ווי `dst.copy_from_slice(src)`, אָבער `T` דאַרף נישט זיין `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;