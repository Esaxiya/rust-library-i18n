use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// די האַרץ פון אַ יטעראַטאָר וואָס צונויפגיסן די פּראָדוקציע פון צוויי שטרענג אַרופגאַנג יטעראַטאָרס, למשל אַ פאַרבאַנד אָדער אַ סיממעטריק חילוק.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// בענטשמאַרקס פאַסטער ווי ראַפּינג ביידע יטעראַטאָרס אין אַ פּעעקאַבלע, מיסטאָמע ווייַל מיר קענען פאַרגינענ זיך צו אָנטאָן אַ FusedIterator bound.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// קריייץ אַ נייַע האַרץ פֿאַר אַ יטעראַטאָר צונויפגיסן אַ פּאָר פון קוואלן.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// קערט דער ווייַטער פּאָר פון ייטאַמז סטיימינג פֿון די פּאָר פון קוואלן וואָס זענען מערדזשד.
    /// אויב ביידע אומגעקערט אָפּציעס אַנטהאַלטן אַ ווערט, די ווערט איז גלייַך און אַקערז אין ביידע מקורים.
    /// אויב איינער פון די אומגעקערט אָפּציעס כּולל אַ ווערט, די ווערט קען נישט פאַלן אין די אנדערע מקור (אָדער די מקורים זענען נישט שטרענג אַסענדינג).
    ///
    /// אויב קיין אָפּגעקערט אָפּציע כּולל אַ ווערט, יטעראַטיאָן איז פאַרטיק און סאַבסאַקוואַנט קאַללס וועט צוריקקומען די זעלבע ליידיק פּאָר.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// קערט אַ פּאָר פון אויבערשטער גווול פֿאַר די `size_hint` פון די לעצט יטעראַטאָר.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}