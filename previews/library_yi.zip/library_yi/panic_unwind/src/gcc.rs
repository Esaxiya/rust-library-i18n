//! ימפּלאַמענטיישאַן פון panics באַקט דורך libgcc/libunwind (אין עטלעכע פאָרעם).
//!
//! פֿאַר הינטערגרונט וועגן ויסנעם האַנדלינג און סטאַק אַנוויינדינג, ביטע זען "Exception Handling in LLVM" קס 01 קס און דאָקומענטן לינגקט פֿון אים.
//! דאָס איז אויך גוט לייענען:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## א קורץ קיצער
//!
//! ויסנעם האַנדלינג כאַפּאַנז אין צוויי פייזאַז: אַ זוכן פאַסע און אַ רייניקונג פאַסע.
//!
//! אין ביידע פייזאַז, די אַנוויינער איז סטאַק ראָמען פֿון שפּיץ צו דנאָ מיט אינפֿאָרמאַציע פֿון די סטאַק ראַם אָפּרוען סעקשאַנז פון די קראַנט מאַדזשולז ("module" דאָ רעפערס צו אַ אַס מאָדולע, הייסט אַן עקסעקוטאַבלע אָדער אַ דינאַמיש ביבליאָטעק).
//!
//!
//! פֿאַר יעדער סטאַק ראַם, עס ינוואָוקס די פֿאַרבונדן "personality routine", וועמענס אַדרעס איז אויך סטאָרד אין די אָפּטיילונג אינפֿאָרמאַציע אָפּטיילונג.
//!
//! אין דער זוך פייז, די אַרבעט פון אַ פערזענלעכקייט רוטין איז צו ונטערזוכן אויסנאַם כייפעץ וואָס איז ארלנגעווארפן, און צו באַשליסן צי עס זאָל זיין געכאפט אין דעם ראַם.אַמאָל די האַנדלער ראַם איז יידענאַפייד, די רייניקונג פאַסע הייבט זיך.
//!
//! אין די רייניקונג פאַסע, די אַנוויינער ינוואָוקס יעדער פּערזענלעכקייט רוטין ווידער.
//! דעם מאָל עס דיסיידז וואָס (אויב קיין) קלינאַפּ קאָד דאַרף זיין לויפן פֿאַר די קראַנט אָנלייגן ראַם.אויב אַזוי, די קאָנטראָל איז טראַנספערד צו אַ ספּעציעלע ז 0 בראַנטש 0 ז אין די פונקציאָנירן גוף, די קס 00 קס, וואָס ינוואָוקס דיסטראַקטערז, פריי זיקאָרן, עטק.
//! אין די סוף פון די לאַנדינג בלאָק, קאָנטראָל איז טראַנספערד צוריק צו די אַנוויינד און אַנוויינדינג רעזאַמייז.
//!
//! אַמאָל סטאַק איז אַנוואַונד אַראָפּ צו די האַנדלער ראַם מדרגה, אַנוויינדינג סטאַפּס און די לעצטע פּערזענלעכקייט רוטין טראַנספערס קאָנטראָל צו די כאַפּן בלאָק.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Z0 רוסט 0 ז ס ויסנעם קלאַס ידענטיפיער.
// דאָס איז געניצט דורך פּערזענלעכקייט רוטינז צו באַשליסן צי דער ויסנעם איז ארלנגעווארפן דורך זייער רונטימע.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-פאַרקויפער, שפּראַך
    0x4d4f5a_00_52555354
}

// רעגיסטרי ידס זענען אויפגעהויבן פון LLVM ס קס 00 קס און קס 01 קס פֿאַר יעדער אַרקאַטעקטשער, און דאַן מאַפּט צו דוווואַרף רעגיסטרירן נומערן דורך רעגיסטרירן דעפֿיניציע טישן (טיפּיקלי<arch>RegisterInfo.td, זוכן פֿאַר "DwarfRegNum").
//
// זען אויך http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // עאַקס, עדקס

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // ראַקס, רדקס

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// די ווייַטערדיקע קאָד איז באזירט אויף C און C++ פּערזענלעכקייט רוטינז פון GCC.פֿאַר דערמאָנען, זען:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI פּערזענלעכקייט רוטין.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ניצט די פעליקייַט רוטין אַנשטאָט ווייַל עס ניצט SjLj אַנוויינדינג.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces אויף ARM וועט רופן די פּערזענלעכקייט רוטין מיט שטאַט==_US_VIRTUAL_UNWIND_FRAME |_וס_פאָרסע_ונווינד.
                // אין יענע קאַסעס, מיר וועלן פאָרזעצן צו אַנוויינדינג דעם אָנלייגן, אַנדערש אַלע אונדזער באַקטראַסעס וואָלט ענדיקן זיך __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // די דוואָרף אַנוויינער אַסומז אַז _ונווינד_קאָנטעקסט האלט אַזאַ ווי די פונקציע און לסדאַ פּוינטערז, אָבער ARM EHABI שטעלן זיי אין די ויסנעם פון די כייפעץ.
            // צו ופהיטן סיגנאַטשערז פון פאַנגקשאַנז ווי קס 01 קס, וואָס נעמען בלויז די קאָנטעקסט טייַטל, GCC פערזענלעכקייט רוטינז סטאַש אַ טייַטל צו ויסנעם_אָבדזשעקט אין דעם קאָנטעקסט, ניצן אָרט רעזערווירט פֿאַר ARM ס "scratch register" קס 00 קס.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... א מער פּרינסאַפּאַלד צוגאַנג וואָלט זיין צו צושטעלן די פול דעפֿיניציע פון ARM ס 'ונווינד_קאָנטעקסט אין אונדזער ליבונווינד בינדינגס און ברענגען די פארלאנגט דאַטן פון דאָרט גלייַך, בייפּאַס די דוואַרף קאַמפּאַטאַבילאַטי פאַנגקשאַנז.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI ריקווייערז די פּערזענלעכקייט רוטין צו דערהייַנטיקן די SP ווערט אין די שלאַבאַן קאַש פון די ויסנעם כייפעץ.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // אויף ARM EHABI, די פּערזענלעכקייט רוטין איז פאַראַנטוואָרטלעך פֿאַר אַקשלי אַנוויינדינג אַ איין אָנלייגן ראַם איידער צוריקקומען (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // דיפיינד אין libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // ניט ויסצאָלן פערזענלעכקייט רוטין, וואָס איז געניצט גלייַך אויף רובֿ טאַרגאַץ און מינאַצאַד אויף קס 00 קס קס 01 קס דורך סעה.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // אויף x86_64 MinGW טאַרגאַץ, SEH אָבער די אַנוויינדינג מעקאַניזאַם אָבער די אַנוויינד האַנדלער דאַטן (aka LSDA) ניצט GCC קאַמפּאַטאַבאַל קאָדירונג.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // די פּערזענלעכקייט רוטין פֿאַר רובֿ פון אונדזער טאַרגאַץ.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // די אַדרעס אַדרעס ווייזט 1 בייט פאַרגאַנגענהייט די רופן ינסטרוקטיאָן, וואָס קען זיין אין דער ווייַטער IP קייט אין די LSDA קייט טיש.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ראַם אַנוויינד אינפֿאָרמאַציע רעגיסטראַציע
//
// די בילד פון יעדער מאָדולע כּולל אַן אָפּטיילונג פֿאַר ראַם אַנוויינד אינפֿאָרמאַציע (יוזשאַוואַלי קס 01 קס).ווען אַ מאָדולע איז loaded/unloaded אין דעם פּראָצעס, די אַנוויינער מוזן זיין ינפאָרמד וועגן דעם אָרט פון דעם אָפּטיילונג אין זכּרון.די מעטהאָדס פון אַטשיווינג ווערייישאַן דורך פּלאַטפאָרמע.
// אויף עטלעכע (למשל, קס 02 קס), די אַנוויינער קענען אַנטדעקן זיך אָפּטיילונג אינפֿאָרמאַציע סעקשאַנז אויף זיך (דורך דינאַמיקאַללי ינומערייטינג די לאָודיד מאַדזשולז דורך די קס 00 קס; אנדערע, ווי קס 01 קס, דאַרפן מאַדזשולז צו אַקטיוולי פאַרשרייַבן זייער אַנוויינד אינפֿאָרמאַציע סעקשאַנז דורך אַנוויינער אַפּי.
//
//
// דעם מאָדולע דיפיינז צוויי סימבאָלס וואָס זענען ריפערד צו און גערופֿן פֿון rsbegin.rs צו פאַרשרייַבן אונדזער אינפֿאָרמאַציע אין די GCC runtime.
// די ימפּלאַמענטיישאַן פון סטאַק אַנוויינדינג איז (פֿאַר איצט) דיפערד צו libgcc_eh, אָבער Rust crates נוצן די Rust-ספּעציפיש פּאָזיציע ווייזט צו ויסמיידן פּאָטענציעל קלאַשיז מיט קיין GCC רונטימע.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}