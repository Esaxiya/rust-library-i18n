//! Utilities פֿאַר פּאַרסינג דוואַרף-ענקאָודיד דאַטן סטרימז.
//! זען קס 01 קס, קס 02 קס נאָרמאַל, אָפּטיילונג 7, קס 00 קס
//!

// דער מאָדולע איז געניצט בלויז איצט דורך x86_64-pc-windows-gnu, אָבער מיר קאַמפּיילד עס אומעטום צו ויסמיידן ראַגרעשאַנז.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // דוואָרף סטרימז זענען פּאַקט, אַזוי, למשל, אַ u32 וואָלט נישט דאַווקע זיין אַליינד אויף אַ גרענעץ פון 4 בייט.
    // דאָס קען אָנמאַכן פּראָבלעמס אויף פּלאַטפאָרמס מיט שטרענג אַליינמאַנט רעקווירעמענץ.
    // דורך ראַפּינג דאַטן אין אַ "packed" סטראַקט, מיר זאָגן די באַקענד צו דזשענערייט קס 01 קס קאָד.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 און SLEB128 ענקאָדינגס זענען דיפיינד אין סעקשאַן קס 01 קס, קס 00 קס.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}