//! אַנוויינדינג panics פֿאַר Miri.
use alloc::boxed::Box;
use core::any::Any;

// דער טיפּ פון פּיילאָוד אַז מירי מאָטאָר פּראַפּאַגייץ דורך אַנוויינדינג פֿאַר אונדז.
// מוזן זיין טייַטל-סייזד.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// מירי-צוגעשטעלט עקסטערן פונקציאָנירן צו אָנהייבן אַנוויינדינג.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // די פּיילאָוד מיר פאָרן צו `miri_start_panic` וועט זיין פּונקט דער אַרגומענט מיר באַקומען אין `cleanup` אונטן.
    // אַזוי מיר נאָר קעסטל עס אַמאָל, צו באַקומען עפּעס טייַטל-סייזד.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // צוריקקריגן די אַנדערלייינג קס 00 קס.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}