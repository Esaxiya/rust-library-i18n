//! ימפּלאַמענטיישאַן פון panics דורך אַנוויינדינג פון אָנלייגן
//!
//! די crate איז אַן ימפּלאַמענטיישאַן פון panics אין Rust מיט "most native" סטאַק אַנוויינדינג מעקאַניזאַם פון די פּלאַטפאָרמע פֿאַר וואָס עס איז קאַמפּיילד.
//! אין דעם פאַל, עס איז דערווייַל קאַטאַגערייזד אין דריי באַקאַץ:
//!
//! 1. MSVC טאַרגאַץ נוצן SEH אין די `seh.rs` טעקע.
//! 2. Emscripten ניצט C++ אויסנעמען אין די `emcc.rs` טעקע.
//! 3. אַלע אנדערע טאַרגאַץ נוצן libunwind/libgcc אין די `gcc.rs` טעקע.
//!
//! מער דאַקיומענטיישאַן וועגן יעדער ימפּלאַמענטיישאַן קענען זיין געפֿונען אין די ריספּעקטיוו מאָדולע.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` איז אַניוזד מיט מירי, אַזוי שטילקייַט וואָרנינגז.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // די סטאַרטאַפּ אַבדזשעקץ פון ז 0 רוסט 0 ז רונטימע אָפענגען אויף די סימבאָלס, אַזוי מאַכן זיי עפנטלעך.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // טאַרגאַץ וואָס טאָן ניט שטיצן אַנוויינדינג.
        // - arch=wasm32
        // - OS=גאָרניט ("bare metal" טאַרגאַץ)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // ניצן מירי רונטימע.
        // מיר דאַרפֿן נאָך אויך לאָדן די נאָרמאַל רונטימע אויבן, ווייַל rustc יקספּעקץ עטלעכע לאַנג זאכן פֿון דאָרט צו זיין דיפיינד.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // ניצן די פאַקטיש רונטימע.
        use real_imp as imp;
    }
}

extern "C" {
    /// האַנדלער אין ליבסטד גערופן ווען אַ panic כייפעץ איז דראַפּט אַרויס פון `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// האַנדלער אין ליבסטד גערופן ווען אַ פרעמד ויסנעם איז געכאפט.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// פּאָזיציע פונט פֿאַר רייזינג אַ ויסנעם, נאָר דעלאַגייץ צו די פּלאַטפאָרמע-ספּעציפיש ימפּלאַמענטיישאַן.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}