#![feature(no_core)]
#![no_core]

// זען rustc-std-workspace-core פֿאַר וואָס דאָס crate איז דארף.

// רענאַמע די crate צו ויסמיידן קאַנפליקטינג מיט די אַלאַקייטינג מאָדולע אין liballoc.
extern crate alloc as foo;

pub use foo::*;