//! קליענט-זייַט טייפּס.

use super::*;

macro_rules! define_handles {
    (
        'owned: $($oty:ident,)*
        'interned: $($ity:ident,)*
    ) => {
        #[repr(C)]
        #[allow(non_snake_case)]
        pub struct HandleCounters {
            $($oty: AtomicUsize,)*
            $($ity: AtomicUsize,)*
        }

        impl HandleCounters {
            // FIXME(eddyb) ניצן אַן דערמאָנען צו די קס 00 קס, אַנשטאָט פון אַ ראַפּער קס 01 קס טייַטל, אַמאָל קס 02 קס קענען דערמאָנען `סטאַטיק`ס.
            //
            extern "C" fn get() -> &'static Self {
                static COUNTERS: HandleCounters = HandleCounters {
                    $($oty: AtomicUsize::new(1),)*
                    $($ity: AtomicUsize::new(1),)*
                };
                &COUNTERS
            }
        }

        // FIXME(eddyb) דזשענערייט די דעפֿיניציע פון קס 01 קס אין קס 00 קס.
        #[repr(C)]
        #[allow(non_snake_case)]
        pub(super) struct HandleStore<S: server::Types> {
            $($oty: handle::OwnedStore<S::$oty>,)*
            $($ity: handle::InternedStore<S::$ity>,)*
        }

        impl<S: server::Types> HandleStore<S> {
            pub(super) fn new(handle_counters: &'static HandleCounters) -> Self {
                HandleStore {
                    $($oty: handle::OwnedStore::new(&handle_counters.$oty),)*
                    $($ity: handle::InternedStore::new(&handle_counters.$ity),)*
                }
            }
        }

        $(
            #[repr(C)]
            pub(crate) struct $oty(handle::Handle);
            impl !Send for $oty {}
            impl !Sync for $oty {}

            // פֿאָרווערטס `Drop::drop` צו די טאָכיק קס 01 קס אופֿן.
            impl Drop for $oty {
                fn drop(&mut self) {
                    $oty(self.0).drop();
                }
            }

            impl<S> Encode<S> for $oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    let handle = self.0;
                    mem::forget(self);
                    handle.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, '_, HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$oty, $oty>
            {
                fn decode(r: &mut Reader<'_>, s: &mut HandleStore<server::MarkedTypes<S>>) -> Self {
                    s.$oty.take(handle::Handle::decode(r, &mut ()))
                }
            }

            impl<S> Encode<S> for &$oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> Decode<'_, 's, HandleStore<server::MarkedTypes<S>>>
                for &'s Marked<S::$oty, $oty>
            {
                fn decode(r: &mut Reader<'_>, s: &'s HandleStore<server::MarkedTypes<S>>) -> Self {
                    &s.$oty[handle::Handle::decode(r, &mut ())]
                }
            }

            impl<S> Encode<S> for &mut $oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, 's, HandleStore<server::MarkedTypes<S>>>
                for &'s mut Marked<S::$oty, $oty>
            {
                fn decode(
                    r: &mut Reader<'_>,
                    s: &'s mut HandleStore<server::MarkedTypes<S>>
                ) -> Self {
                    &mut s.$oty[handle::Handle::decode(r, &mut ())]
                }
            }

            impl<S: server::Types> Encode<HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$oty, $oty>
            {
                fn encode(self, w: &mut Writer, s: &mut HandleStore<server::MarkedTypes<S>>) {
                    s.$oty.alloc(self).encode(w, s);
                }
            }

            impl<S> DecodeMut<'_, '_, S> for $oty {
                fn decode(r: &mut Reader<'_>, s: &mut S) -> Self {
                    $oty(handle::Handle::decode(r, s))
                }
            }
        )*

        $(
            #[repr(C)]
            #[derive(Copy, Clone, PartialEq, Eq, Hash)]
            pub(crate) struct $ity(handle::Handle);
            impl !Send for $ity {}
            impl !Sync for $ity {}

            impl<S> Encode<S> for $ity {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, '_, HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$ity, $ity>
            {
                fn decode(r: &mut Reader<'_>, s: &mut HandleStore<server::MarkedTypes<S>>) -> Self {
                    s.$ity.copy(handle::Handle::decode(r, &mut ()))
                }
            }

            impl<S: server::Types> Encode<HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$ity, $ity>
            {
                fn encode(self, w: &mut Writer, s: &mut HandleStore<server::MarkedTypes<S>>) {
                    s.$ity.alloc(self).encode(w, s);
                }
            }

            impl<S> DecodeMut<'_, '_, S> for $ity {
                fn decode(r: &mut Reader<'_>, s: &mut S) -> Self {
                    $ity(handle::Handle::decode(r, s))
                }
            }
        )*
    }
}
define_handles! {
    'owned:
    FreeFunctions,
    TokenStream,
    TokenStreamBuilder,
    TokenStreamIter,
    Group,
    Literal,
    SourceFile,
    MultiSpan,
    Diagnostic,

    'interned:
    Punct,
    Ident,
    Span,
}

// FIXME(eddyb) דזשענערייט די ימפּלס דורך מוסטער-ריכטן די נעמען פון מעטהאָדס, און קען נוצן דעם בייַזייַן פון קס 00 קס צו ויסטיילן צווישן 'אָונד און' ינטערנעד, אויבן.
//
// אַלטערנאַטיוועלי, ספּעציעלע 'מאָדעס' קען זיין ליסטעד פון טייפּס אין וויטה_אַפּי אַנשטאָט פון מוסטער וואָס ריכטן זיך אויף מעטהאָדס, דאָ און אין סערווער דעקל.
//
//

impl Clone for TokenStream {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for TokenStreamIter {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for Group {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for Literal {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Literal")
            // פֿאָרמאַטירן די סאָרט אָן ציטירט, ווי אין `kind: Float`
            .field("kind", &format_args!("{}", &self.debug_kind()))
            .field("symbol", &self.symbol())
            // פֿאָרמאַט `Some("...")` אויף איין שורה אפילו אין {:#?} מאָדע
            .field("suffix", &format_args!("{:?}", &self.suffix()))
            .field("span", &self.span())
            .finish()
    }
}

impl Clone for SourceFile {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.debug())
    }
}

macro_rules! define_client_side {
    ($($name:ident {
        $(fn $method:ident($($arg:ident: $arg_ty:ty),* $(,)?) $(-> $ret_ty:ty)*;)*
    }),* $(,)?) => {
        $(impl $name {
            $(pub(crate) fn $method($($arg: $arg_ty),*) $(-> $ret_ty)* {
                Bridge::with(|bridge| {
                    let mut b = bridge.cached_buffer.take();

                    b.clear();
                    api_tags::Method::$name(api_tags::$name::$method).encode(&mut b, &mut ());
                    reverse_encode!(b; $($arg),*);

                    b = bridge.dispatch.call(b);

                    let r = Result::<_, PanicMessage>::decode(&mut &b[..], &mut ());

                    bridge.cached_buffer = b;

                    r.unwrap_or_else(|e| panic::resume_unwind(e.into()))
                })
            })*
        })*
    }
}
with_api!(self, self, define_client_side);

enum BridgeState<'a> {
    /// קיין סערווער איז דערווייַל פארבונדן צו דעם קליענט.
    NotConnected,

    /// א סערווער איז פארבונדן און בארעכטיגט פֿאַר ריקוועס.
    Connected(Bridge<'a>),

    /// אַקסעס צו די בריק איז עקסקלוסיוולי קונה (למשל בעשאַס `BridgeState::with`).
    ///
    InUse,
}

enum BridgeStateL {}

impl<'a> scoped_cell::ApplyL<'a> for BridgeStateL {
    type Out = BridgeState<'a>;
}

thread_local! {
    static BRIDGE_STATE: scoped_cell::ScopedCell<BridgeStateL> =
        scoped_cell::ScopedCell::new(BridgeState::NotConnected);
}

impl BridgeState<'_> {
    /// נעמען ויסשליסיק קאָנטראָל פון די פאָדעם-היגע קס 00 קס, און פאָרן עס צו קס 01 קס, מיוטאַבלי.
    /// די שטאַט וועט זיין ריסטאָרד נאָך `f` עגזיץ, אפילו דורך panic, אַרייַנגערעכנט `f` מאַדאַפאַקיישאַנז.
    ///
    ///
    /// נ.ב., בשעת קס 01 קס איז פליסנדיק, די פאָדעם-היגע שטאַט איז קס 00 קס.
    ///
    ///
    fn with<R>(f: impl FnOnce(&mut BridgeState<'_>) -> R) -> R {
        BRIDGE_STATE.with(|state| {
            state.replace(BridgeState::InUse, |mut state| {
                // FIXME(#52812) פאָרן קס 00 קס גלייַך צו קס 01 קס ווען קס 02 קס איז ניטאָ
                f(&mut *state)
            })
        })
    }
}

impl Bridge<'_> {
    pub(crate) fn is_available() -> bool {
        BridgeState::with(|state| match state {
            BridgeState::Connected(_) | BridgeState::InUse => true,
            BridgeState::NotConnected => false,
        })
    }

    fn enter<R>(self, f: impl FnOnce() -> R) -> R {
        let force_show_panics = self.force_show_panics;
        // באַהאַלטן די פעליקייַט רעזולטאַט panic אין `proc_macro` יקספּאַנשאַנז.
        // נ.ב.דער סערווער קען נישט טאָן דאָס ווייַל עס קען נוצן אַ אַנדערש ליבסטד.
        static HIDE_PANICS_DURING_EXPANSION: Once = Once::new();
        HIDE_PANICS_DURING_EXPANSION.call_once(|| {
            let prev = panic::take_hook();
            panic::set_hook(Box::new(move |info| {
                let show = BridgeState::with(|state| match state {
                    BridgeState::NotConnected => true,
                    BridgeState::Connected(_) | BridgeState::InUse => force_show_panics,
                });
                if show {
                    prev(info)
                }
            }));
        });

        BRIDGE_STATE.with(|state| state.set(BridgeState::Connected(self), f))
    }

    fn with<R>(f: impl FnOnce(&mut Bridge<'_>) -> R) -> R {
        BridgeState::with(|state| match state {
            BridgeState::NotConnected => {
                panic!("procedural macro API is used outside of a procedural macro");
            }
            BridgeState::InUse => {
                panic!("procedural macro API is used while it's already in use");
            }
            BridgeState::Connected(bridge) => f(bridge),
        })
    }
}

/// א קליענט-זייַט קס 00 קס (יוזשאַוואַלי אַ פונקציע טייַטל), וואָס קען נוצן אַ אַנדערש קס 01 קס ווי די סערווער, אָבער קענען זיין ינטעראַקטיד מיט קאַמפּאַטאַבילאַטי.
///
///
/// נ.ב., `F` מוזן האָבן FFI-פרייַנדלעך זיקאָרן אויסלייג (למשל, אַ טייַטל).
/// די רופן אַבי פון פונקציאָנירן פּוינטערז געניצט פֿאַר קס 00 קס דאַרף ניט גלייַכן צווישן סערווער און קליענט, ווייַל עס איז בלויז דורכגעגאנגען צווישן זיי און קס 01 קס גערופֿן דורך דעם קליענט.
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
pub struct Client<F> {
    // FIXME(eddyb) ניצן אַן דערמאָנען צו די קס 00 קס, אַנשטאָט פון אַ ראַפּער קס 01 קס טייַטל, אַמאָל קס 02 קס קענען דערמאָנען `סטאַטיק`ס.
    //
    pub(super) get_handle_counters: extern "C" fn() -> &'static HandleCounters,
    pub(super) run: extern "C" fn(Bridge<'_>, F) -> Buffer<u8>,
    pub(super) f: F,
}

/// קליענט-זייַט העלפער פֿאַר האַנדלינג מיט קליענט ז 0 פּאַניקס 0 ז, אַרייַן די בריק, דעסעריאַליזינג אַרייַנשרייַב און סיריאַליזינג פּראָדוקציע.
///
// FIXME(eddyb) אפֿשר פאַרבייַטן `Bridge::enter` מיט דעם?
fn run_client<A: for<'a, 's> DecodeMut<'a, 's, ()>, R: Encode<()>>(
    mut bridge: Bridge<'_>,
    f: impl FnOnce(A) -> R,
) -> Buffer<u8> {
    // די ערשטע `cached_buffer` כּולל די אַרייַנשרייַב.
    let mut b = bridge.cached_buffer.take();

    panic::catch_unwind(panic::AssertUnwindSafe(|| {
        bridge.enter(|| {
            let reader = &mut &b[..];
            let input = A::decode(reader, &mut ());

            // שטעלן די `cached_buffer` צוריק אין די `Bridge` פֿאַר ריקוועס.
            Bridge::with(|bridge| bridge.cached_buffer = b.take());

            let output = f(input);

            // נעמען די `cached_buffer` צוריק פֿאַר די פּראָדוקציע ווערט.
            b = Bridge::with(|bridge| bridge.cached_buffer.take());

            // HACK(eddyb) באַזונדער קאָדירונג אַ הצלחה ווערט קס 00 קס פון קאָדירונג אַ ז 0 פּאַניק 0 ז קס 01 קס צו ויסמיידן כאַנדאַלז אַרויס די קס 02 קס פאַרנעם, און צו כאַפּן ז 0 פּאַניק 0 ז וואָס קען פּאַסירן בשעת קאָדירונג די הצלחה.
            //
            // באַמערקונג אַז panics זאָל זיין אוממעגלעך אויסער דעם פונט, אָבער דאָס איז דיפענסיוולי טריינג צו ויסמיידן אַקסאַדענטאַל פּאַניקינג ריטשינג די `extern "C"` (וואָס `abort` אָבער קען נישט דערווייַל, אַזוי דאָס איז אויך פּאַטענטשאַלי פּרעווענטינג וב).
            //
            //
            //
            //
            //
            //
            b.clear();
            Ok::<_, ()>(output).encode(&mut b, &mut ());
        })
    }))
    .map_err(PanicMessage::from)
    .unwrap_or_else(|e| {
        b.clear();
        Err::<(), _>(e).encode(&mut b, &mut ());
    });
    b
}

impl Client<fn(crate::TokenStream) -> crate::TokenStream> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn expand1(f: fn(crate::TokenStream) -> crate::TokenStream) -> Self {
        extern "C" fn run(
            bridge: Bridge<'_>,
            f: impl FnOnce(crate::TokenStream) -> crate::TokenStream,
        ) -> Buffer<u8> {
            run_client(bridge, |input| f(crate::TokenStream(input)).0)
        }
        Client { get_handle_counters: HandleCounters::get, run, f }
    }
}

impl Client<fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn expand2(
        f: fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        extern "C" fn run(
            bridge: Bridge<'_>,
            f: impl FnOnce(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
        ) -> Buffer<u8> {
            run_client(bridge, |(input, input2)| {
                f(crate::TokenStream(input), crate::TokenStream(input2)).0
            })
        }
        Client { get_handle_counters: HandleCounters::get, run, f }
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
pub enum ProcMacro {
    CustomDerive {
        trait_name: &'static str,
        attributes: &'static [&'static str],
        client: Client<fn(crate::TokenStream) -> crate::TokenStream>,
    },

    Attr {
        name: &'static str,
        client: Client<fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream>,
    },

    Bang {
        name: &'static str,
        client: Client<fn(crate::TokenStream) -> crate::TokenStream>,
    },
}

impl ProcMacro {
    pub fn name(&self) -> &'static str {
        match self {
            ProcMacro::CustomDerive { trait_name, .. } => trait_name,
            ProcMacro::Attr { name, .. } => name,
            ProcMacro::Bang { name, .. } => name,
        }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn custom_derive(
        trait_name: &'static str,
        attributes: &'static [&'static str],
        expand: fn(crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::CustomDerive { trait_name, attributes, client: Client::expand1(expand) }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn attr(
        name: &'static str,
        expand: fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::Attr { name, client: Client::expand2(expand) }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn bang(
        name: &'static str,
        expand: fn(crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::Bang { name, client: Client::expand1(expand) }
    }
}