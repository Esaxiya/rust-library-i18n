# די `rustc-std-workspace-std` crate

זען דאַקיומענטיישאַן פֿאַר די `rustc-std-workspace-core` crate.