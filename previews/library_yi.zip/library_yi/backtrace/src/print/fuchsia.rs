use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr נעמט אַ קאַללבאַקק וואָס וועט באַקומען אַ dl_phdr_info טייַטל פֿאַר יעדער DSO וואָס איז לינגקט אין דעם פּראָצעס.
    // dl_iterate_phdr אויך ינשורז אַז די דינאַמיש לינקער איז פארשפארט פון אָנהייב צו ענדיקן די יטעראַטיאָן.
    // אויב די קאַללבאַקק קערט אַ ניט-נול ווערט, די יטעראַטיאָן איז טערמאַנייטיד פרי.
    // 'data' וועט זיין דורכגעגאנגען ווי די דריט אַרגומענט צו די קאַללבאַקק אויף יעדער רופן.
    // 'size' גיט די גרייס פון די דל_פדר_ינפאָ.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// מיר דאַרפֿן צו פּאַריז די בויען שייַן און עטלעכע יקערדיק פּראָגראַם כעדער דאַטן וואָס מיטל אַז מיר דאַרפֿן אַ ביסל פון די ELF ספּעק.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// איצט מיר האָבן צו רעפּלאַקייט די ביסל סטרוקטור פון די דל_פדר_ינפאָ טיפּ וואָס איז גענוצט דורך די קראַנט דינאַמיש לינקער פון פוטשסיאַ.
// Chromium אויך האט דעם אַבי גרענעץ און קראַשפּאַד.
// יווענטשאַוואַלי מיר וואָלט ווי צו מאַך די קאַסעס צו נוצן שרעטל-זוכן, אָבער מיר'ד דאַרפֿן צו צושטעלן אַז אין די סדק און וואָס איז נישט נאָך געטאן.
//
// אזוי מיר (און זיי) זענען סטאַק צו נוצן דעם אופֿן וואָס ינקערז אַ ענג קאַפּלינג מיט די פוטשסיאַ ליבק.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // מיר האָבן קיין וועג צו וויסן אויב e_phoff און e_phnum זענען גילטיק.
    // libc זאָל ענשור דאָס פֿאַר אונדז אָבער אַזוי עס איז זיכער צו פאָרעם אַ רעפטל דאָ.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr רעפּראַזענץ אַ 64-ביסל עלף פּראָגראַם כעדער אין די ענדיינאַס פון די ציל אַרקאַטעקטשער.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr רעפּראַזענץ אַ גילטיק ELF פּראָגראַם כעדער און זייַן אינהאַלט.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // מיר האָבן קיין וועג צו קאָנטראָלירן צי p_addr אָדער p_memsz זענען גילטיק.
    // Fuchsia's libc פּאַרסירט די נאָטעס ערשטער, אָבער ווייַל זיי זענען דאָ, די כעדערז מוזן זיין גילטיק.
    //
    // באַמערקונג יטער טוט נישט דאַרפן די אַנדערלייינג דאַטן צו זיין גילטיק אָבער עס דאַרף צו זיין גילטיק.
    // מיר צוטרוי אַז ליבק האט ינשורד אַז דאָס איז דער פאַל פֿאַר אונדז דאָ.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// די טאָן טיפּ פֿאַר בויען ידס.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr רעפּראַזענץ אַן ELF טאָן כעדער אין די ענדיינאַס פון די ציל.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// באַמערקונג רעפּראַזענץ אַ ELF טאָן (כעדער + אינהאַלט).
// דער נאָמען איז לינקס ווי אַ u8 רעפטל ווייַל עס איז ניט שטענדיק נול טערמאַנייטיד און rust מאכט עס גרינג גענוג צו קאָנטראָלירן אַז די ביטעס גלייך.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// נאָטעיטער לאָזן איר בעשאָלעם יטערירן איבער אַ צעטל אָפּשניט.
// ווי באַלד ווי אַ טעות קומט אָדער עס זענען ניט מער הערות טערמאַנייץ.
// אויב איר יטעראַטע איבער פאַרקריפּלט דאַטן, עס וועט פונקציאָנירן ווי קיין נאָטיץ זענען געפֿונען.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // עס איז אַ שטייגער פונקציאָנירן אַז דער טייַטל און גרייס געגעבן אַ גילטיק קייט פון ביטעס אַז אַלע קענען זיין לייענען.
    // די אינהאַלט פון די ביטעס קענען זיין עפּעס אָבער די קייט מוזן זיין גילטיק פֿאַר דעם צו זיין זיכער.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// אַליינ_טאָ אַליינז קס 00 קס צו 'צו'-בייט אַליינמאַנט אַסומינג קס 01 קס איז אַ מאַכט פון 2.
// דעם גייט אַ נאָרמאַל מוסטער אין C/C ++ ELF פּאַרסינג קאָד וווּ (X + צו, 1)&-to איז געניצט.
// Z0 רוסט 0 ז ניט לאָזן איר ניגייט נוצן אַזוי איך נוצן
// 2 ס-דערגאַנג קאַנווערזשאַן צו ריקריייט אַז.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 קאַנסומז נומער ביטעס פון די רעפטל (אויב פאָרשטעלן) און אַדישנאַלי ינשורז אַז די לעצט רעפטל איז געהעריק אַליינד.
// אויב די נומער פון בייט בייז איז אויך גרויס, אָדער די סלייס קענען ניט זיין ריאַליינד דערנאָכדעם ווייַל עס זענען נישט גענוג רוען ביטעס יגזיסטינג, קיינער איז אומגעקערט און די רעפטל איז נישט מאַדאַפייד.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// די פאַנגקשאַנז האָבן קיין פאַקטיש ינוואַריאַנץ וואָס די קאַללער מוזן האַלטן אַנדערער ווי די 'bytes' זאָל זיין אַליינד פֿאַר פאָרשטעלונג (און אין עטלעכע ריכטיק אַרקאַטעקטשערז).
// די וואַלועס אין די Elf_Nhdr פעלדער קען זיין ומזין אָבער די פונקציע ינשורז ניט אַזאַ זאַך.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // דאָס איז זיכער ווי לאַנג ווי עס איז גענוג פּלאַץ און מיר נאָר באשטעטיקט אַז אין די אויב ויסזאָגונג אויבן אַזוי דאָס זאָל נישט זיין אַנסייף.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // באַמערקונג אַז sice_of: :<Elf_Nhdr>() איז שטענדיק 4-בייט אַליינד.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // קוק אויב מיר האָבן ריטשט די סוף.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // מיר דורכפירן אַ נהדר אָבער מיר קערפאַלי באַטראַכטן די ריזאַלטינג סטרוקטור.
        // מיר טאָן ניט צוטרוי די נאַמעסז אָדער דעסקסז און מיר מאַכן קיין אַנסייף דיסיזשאַנז באזירט אויף דעם טיפּ.
        //
        // אפילו אויב מיר באַקומען גאַנץ מיסט, מיר זאָל נאָך זיין זיכער.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ינדיקייץ אַז אַ אָפּשניט איז עקסאַקיוטאַבאַל.
const PERM_X: u32 = 0b00000001;
/// ינדיקייץ אַז אַ אָפּשניט איז שרייבן.
const PERM_W: u32 = 0b00000010;
/// ינדיקייץ אַז אַ אָפּשניט איז ליינעוודיק.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// רעפּראַזענץ אַן ELF אָפּשניט ביי רונטימע.
struct Segment {
    /// גיט די ווירטואַל אַדרעס פון די רונטימע פון די אינהאַלט פון דעם אָפּשניט.
    addr: usize,
    /// גיט די זכּרון גרייס פון דעם אינהאַלט פון דעם אָפּשניט.
    size: usize,
    /// גיט די מאָדולע ווירטואַל אַדרעס פון דעם אָפּשניט מיט די ELF טעקע.
    mod_rel_addr: usize,
    /// גיט די פּערמישאַנז געפֿונען אין די ELF טעקע.
    /// די פּערמישאַנז זענען נישט דאַווקע די פּערמישאַנז פאָרשטעלן אין רונטימע.
    flags: Perm,
}

/// לעץ איינער יטעראַטע איבער סעגמאַנץ פון אַ דסאָ.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// רעפּראַזענץ אַן ELF DSO (Dynamic Shared Object).
/// דעם טיפּ באַווייַזן די דאַטן סטאָרד אין די פאַקטיש DSO ווי צו מאַכן זיין אייגענע קאָפּיע.
struct Dso<'a> {
    /// די דינאַמיש לינקער שטענדיק געבן אונדז אַ נאָמען, אפילו אויב די נאָמען איז ליידיק.
    /// אין דעם פאַל פון די הויפּט עקסעקוטאַבלע, דעם נאָמען וועט זיין ליידיק.
    /// אין דעם פאַל פון אַ שערד כייפעץ, דאָס איז די סאָנאַמע (זען דט_סאָנאַמע).
    name: &'a str,
    /// אויף Fuchsia, כּמעט אַלע בינאַריעס האָבן בויען ידס, אָבער דאָס איז נישט אַ שטרענג רעקווירימענט.
    /// עס איז קיין וועג צו גלייַכן DSO אינפֿאָרמאַציע מיט אַ פאַקטיש ELF טעקע דערנאָכדעם אויב עס איז קיין build_id, אַזוי מיר דאַרפן יעדער DSO דאָ.
    ///
    /// DSO ס אָן אַ בילד_יד זענען איגנאָרירט.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// קערט אַ יטעראַטאָר איבער סעגמאַנץ אין דעם דסאָ.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// די ערראָרס קאָדירן ישוז וואָס שטייען בשעת פּאַרסינג אינפֿאָרמאַציע וועגן יעדער DSO.
///
enum Error {
    /// NameError מיטל אַז אַ טעות איז פארגעקומען בשעת קאַנווערטינג אַ C נוסח שטריקל אין אַ rust שטריקל.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError מיטל אַז מיר האָבן ניט געפֿונען אַ בויען שייַן.
    /// דאָס קען זיין ווייַל די DSO האט קיין בילד שייַן אָדער ווייַל די אָפּשניט מיט די בילד שייַן איז פאַלש.
    ///
    BuildIDError,
}

/// רופט 'dso' אָדער 'error' פֿאַר יעדער DSO לינגקט אין דעם פּראָצעס דורך די דינאַמיש לינקער.
///
///
/// # Arguments
///
/// * `visitor` - א DsoPrinter וואָס וועט האָבן איינער פון עסן מעטהאָדס גערופֿן פֿאַר יעדער DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ינשור אַז info.name וועט ווייַזן צו אַ גילטיק אָרט.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// די פֿונקציע פּרינץ די Fuchsia סימבאַלייזער מאַרקאַפּ פֿאַר אַלע אינפֿאָרמאַציע קאַנטיינד אין אַ DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}