//! א מאָדולע צו העלפן פירן דבגהעלפּ בינדינגס אויף Windows
//!
//! באַקקטראַסעס אויף קס 00 קס (לפּחות פֿאַר מסווק) זענען לאַרגעלי פּאַוערד דורך קס 01 קס און די פאַרשידן פאַנגקשאַנז אַז עס כּולל.
//! די פאַנגקשאַנז זענען דערווייַל לאָודיד *דינאַמיקאַללי* אלא ווי סטאַטיקלי פֿאַרבינדונג צו קס 00 קס.
//! דערווייַל, דאָס איז דורכגעקאָכט דורך די סטאַנדאַרט ביבליאָטעק (און עס איז טעאָרעאַלי פארלאנגט), אָבער עס איז אַן אָנשטרענגונג צו רעדוצירן די סטאַטיק דלל דעפּענדענסיעס פון אַ ביבליאָטעק, ווייַל באַקטראַסעס זענען יוזשאַוואַלי שיין אַפּשאַנאַל.
//!
//! ווי געזאָגט, קס 01 קס כּמעט שטענדיק הצלחה אויף קס 00 קס.
//!
//! באַמערקונג אַז זינט מיר לאָודינג אַלע די שטיצן דינאַמיקאַללי, מיר קענען נישט טאַקע נוצן די רוי זוך אין `winapi`, אָבער מיר דאַרפֿן צו דעפינירן די פונקציע טייַטל טייפּס זיך און נוצן דאָס.
//! מיר טאָן ניט טאַקע וועלן צו דופּליקאַט ווינאַפּי, אַזוי מיר האָבן אַ Cargo שטריך `verify-winapi` וואָס אַסערץ אַז אַלע בינדינגס גלייַכן יענע אין ווינאַפּי און דעם שטריך איז ענייבאַלד אויף סי.
//!
//! לעסאָף, איר וועט באַמערקן אַז די דלל פֿאַר קס 00 קס איז קיינמאָל אַנלאָודיד, און אַז ס 'איצט ינטענשאַנאַל.
//! די טראכטן איז אַז מיר קענען גלאָובאַלי קאַש עס און נוצן עס צווישן רופט צו די API, אַוווידינג טייַער loads/unloads.
//! אויב דאָס איז אַ פּראָבלעם פֿאַר רינען דעטעקטאָרס אָדער עפּעס ווי דאָס, מיר קענען אַריבער די בריק ווען מיר באַקומען דאָרט.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// ארבעטן אַרום `SymGetOptions` און `SymSetOptions`, נישט זייַענדיק פאָרשטעלן אין ווינאַפּי זיך.
// אַנדערש, דאָס איז נאָר געניצט ווען מיר טאָפּל-קאָנטראָל טייפּס קעגן ווינאַפּי.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // נאָך נישט דיפיינד אין ווינאַפּי
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // דאָס איז דיפיינד אין ווינאַפּי, אָבער עס איז פאַלש (FIXME ווינאַפּי-רס#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // נאָך נישט דיפיינד אין ווינאַפּי
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// דער מאַקראָו איז געניצט צו דעפינירן אַ `Dbghelp` סטרוקטור וואָס ינערלעך כּולל אַלע די פונקציע פּוינטערז וואָס מיר קענען אַרייַן.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// די לאָודיד דלל פֿאַר קס 00 קס
            dll: HMODULE,

            // יעדער פונקציע טייַטל פֿאַר יעדער פֿונקציע מיר קען נוצן
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // טכילעס, מיר האָבן נישט לאָודיד די דלל
            dll: 0 as *mut _,
            // ערשט אַלע פאַנגקשאַנז זענען שטעלן צו נול צו זאָגן אַז זיי דאַרפֿן צו זיין דינאַמיק לאָודיד.
            //
            $($name: 0,)*
        };

        // קאַנוויניאַנס טייפּדיף פֿאַר יעדער פונקציע טיפּ.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// פרווון צו עפענען `dbghelp.dll`.
            /// קערט הצלחה אויב עס אַרבעט אָדער טעות אויב `LoadLibraryW` פיילז.
            ///
            /// Panics אויב ביבליאָטעק איז שוין לאָודיד.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // פונקציאָנירן פֿאַר יעדער אופֿן וואָס מיר וואָלט ווי צו נוצן.
            // אויב גערופֿן, עס וועט לייענען די קאַשט פונקציע טייַטל אָדער אַרייַן עס און צוריקקומען די לאָודיד ווערט.
            // לאָודז זענען אַססיסטעד צו מצליח זיין.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // קאַנוויניאַנס פּראַקסי צו נוצן די קלינאַפּ לאַקס צו באַווייַזן dbghelp פאַנגקשאַנז.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// יניטיאַליזירן אַלע נויטיק שטיצן צו אַקסעס `dbghelp` API פאַנגקשאַנז פֿון דעם crate.
///
///
/// באַמערקונג אַז די פֿונקציע איז **זיכער**, עס ינערלעך האט זיין אייגענע סינגקראַנאַזיישאַן.
/// אויך טאָן אַז עס איז זיכער צו רופן דעם פֿונקציע קייפל מאָל רעקורסיוועלי.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // דער ערשטער זאַך וואָס מיר דאַרפֿן צו טאָן איז צו סינגקראַנייז דעם פֿונקציע.דאָס קען זיין גערופֿן קאַנקעראַנטלי פֿון אנדערע פֿעדעם אָדער רעקורסיוועלי אין איין פאָדעם.
        // באַמערקונג אַז עס ס 'טריקיער ווי אַז ווייַל וואָס מיר' רע ניצן דאָ, קס 00 קס,*אויך* דאַרף זיין סינגקראַנייזד מיט אַלע אנדערע קאַללערס צו קס 01 קס אין דעם פּראָצעס.
        //
        // טיפּיקאַללי עס זענען נישט טאַקע אַזוי פילע רופט צו קס 00 קס אין דער זעלביקער פּראָצעס, און מיר קענען מיסטאָמע בעשאָלעם יבערנעמען אַז מיר זענען די בלויז אָנעס צו עס.
        // עס זענען, אָבער, איינער ערשטיק אנדערע באַניצער מיר האָבן צו זאָרג וועגן וואָס איז ייראַניקלי זיך, אָבער אין דער נאָרמאַל ביבליאָטעק.
        // די Rust נאָרמאַל ביבליאָטעק דעפּענדס אויף דעם crate פֿאַר שטיצן פֿאַר באַקקטראַסע, און די crate אויך יגזיסץ אויף crates.io.
        // דעם מיטל אַז אויב די סטאַנדאַרט ביבליאָטעק פּרינטינג אַ ז 0 פּאַניק 0 ז באַקטראַסע, עס קען ראַסע מיט דעם ז 0 קראַטע 0 ז קומענדיק פון קס 00 קס, קאָזינג סעגפאָלץ.
        //
        // צו סאָלווע דעם סינגקראַנאַזיישאַן פּראָבלעם, מיר נוצן דאָ אַ Windows-ספּעציפיש טריק (נאָך אַלע, אַ Windows-ספּעציפיש ריסטריקשאַן וועגן סינגקראַנאַזיישאַן).
        // מיר מאַכן אַ *סעסיע-היגע* געהייסן מוטעקס צו באַשיצן דעם רוף.
        // די כוונה דאָ איז אַז דער נאָרמאַל ביבליאָטעק און דעם ז 0 קראַטע 0 ז טאָן ניט האָבן צו טיילן ז 0 רוסט 0 ז-מדרגה אַפּיס צו סינגקראַנייז דאָ אָבער קענען אַנשטאָט אַרבעט הינטער די סינז צו מאַכן זיכער אַז זיי סינגקראַנייזינג מיט יעדער אנדערער.
        //
        // אויף דעם וועג, ווען די פאַנגקשאַנז זענען גערופֿן דורך דער נאָרמאַל ביבליאָטעק אָדער דורך crates.io, מיר קענען זיין זיכער אַז דער זעלביקער מוטעקס איז קונה.
        //
        // אַזוי אַלע איז צו זאָגן אַז דער ערשטער זאַך מיר טאָן דאָ איז אַז מיר אַטאָמישעלי מאַכן אַ קס 01 קס וואָס איז אַ געהייסן מוטעקס אויף קס 00 קס.
        // מיר סינגקראַנייז אַ ביסל מיט אנדערע פֿעדעם וואָס ספּעציפיצירן די פונקציאָנירן און ענשור אַז בלויז איין שעפּן איז באשאפן פּער בייַשפּיל פון דעם פֿונקציע.
        // באַמערקונג אַז די שעפּן איז קיינמאָל קלאָוזד אַמאָל עס איז סטאָרד אין די גלאבאלע.
        //
        // נאָך די שלאָס, מיר נאָר קריגן עס, און אונדזער `Init` שעפּן מיר וועלן זיין פאַראַנטוואָרטלעך פֿאַר דראַפּינג עס יווענטשאַוואַלי.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // גוט, פיו!איצט מיר אַלע סאַפערלי סינגקראַנייזד, לאָזן אַקטשאַוואַלי אָנהייבן פּראַסעסינג אַלץ.
        // ערשטער, מיר דאַרפֿן צו ענשור אַז `dbghelp.dll` איז טאַקע לאָודיד אין דעם פּראָצעס.
        // מיר טאָן דאָס דינאַמיקאַללי צו ויסמיידן אַ סטאַטיק דעפּענדענסי.
        // היסטאָריש, דאָס איז דורכגעקאָכט צו אַרבעט אַרום טשודנע פֿאַרבינדונג ישוז און איז בדעה צו מאַכן בינאַריעס אַ ביסל מער פּאָרטאַטיוו ווייַל דאָס איז לאַרגעלי נאָר אַ דיבאַגינג נוצן.
        //
        //
        // אַמאָל מיר האָבן אָפּענעד קס 00 קס, מיר דאַרפֿן צו רופן עטלעכע יניטיאַליזאַטיאָן פאַנגקשאַנז אין עס, און דיטיילד מער אונטן.
        // מיר נאָר טאָן דאָס אַמאָל, אַזוי מיר האָבן אַ גלאבאלע באָאָלעאַן וואָס ינדיקייץ צי מיר זענען נאָך געטאן אָדער נישט.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // ענשור אַז די קס 01 קס פאָן איז באַשטימט ווייַל לויט MSVC ס דאָקומענטן וועגן דעם: קס 00 קס, אַזוי לאָזן ס טאָן דאָס!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // אַקטשאַוואַלי יניטיאַליזירן סימבאָלס מיט MSVC.באַמערקונג אַז דאָס קען פאַרלאָזן, אָבער מיר איגנאָרירן עס.
        // עס איז נישט אַ פּלאַץ פון פריערדיק קונסט פֿאַר דעם פּער זיך, אָבער LLVM ינערלי סימז צו איגנאָרירן די צוריקקער ווערט דאָ און איינער פון די סאַניטיזער לייברעריז אין LLVM פּרינץ אַ סקערי ווארענונג אויב דאָס פיילז אָבער בייסיקלי יגנאָרז עס אין די לאַנג לויפן.
        //
        //
        // אין איין פאַל דאָס קומט פיל פֿאַר Rust איז אַז די סטאַנדאַרט ביבליאָטעק און די crate אויף crates.io ביידע ווילן צו קאָנקורירן פֿאַר `SymInitializeW`.
        // די סטאַנדאַרט ביבליאָטעק כיסטאָריקאַלי געוואלט צו יניטיאַליזירן די רייניקונג רובֿ פון די צייט, אָבער איצט אַז דאָס איז ניצן דעם crate, עס מיינען אַז עמעצער וועט אָנהייבן ערשט צו יניטיאַליזאַטיאָן און די אנדערע וועט נעמען דעם יניטיאַליזאַטיאָן.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}