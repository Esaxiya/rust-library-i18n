use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// פאַרטרעטונג פון אַן אָונד און זעלבסט-קאַנטיינד באַקטראַסע.
///
/// די סטרוקטור קענען ווערן גענוצט צו כאַפּן אַ באַקטראַס ביי פאַרשידן פונקטן אין אַ פּראָגראַם און שפּעטער צו דורכקוקן וואָס די באַקטראַס איז געווען אין דער צייט.
///
///
/// `Backtrace` שטיצט שיין-דרוקן פון באַקקטראַסיז דורך די `Debug` ימפּלאַמענטיישאַן.
///
/// # פארלאנגט פֿעיִקייטן
///
/// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // פראַמעס דאָ זענען ליסטעד פֿון שפּיץ-צו-דנאָ פון דעם אָנלייגן
    frames: Vec<BacktraceFrame>,
    // די אינדעקס וואָס מיר גלויבן איז די פאַקטיש אָנהייב פון די באַקטראַס, אויב איר לאָזן ראָמען ווי קס 01 קס און קס 00 קס.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// קאַפּטשערד ווערסיע פון אַ ראַם אין אַ באַקטראַסע.
///
/// דעם טיפּ איז אומגעקערט ווי אַ רשימה פֿון `Backtrace::frames` און רעפּראַזענץ איין אָנלייגן ראַם אין אַ קאַפּטשערד באַקטראַסע.
///
/// # פארלאנגט פֿעיִקייטן
///
/// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// קאַפּטשערד ווערסיע פון אַ סימבאָל אין אַ באַקטראַס.
///
/// דעם טיפּ איז אומגעקערט ווי אַ רשימה פֿון `BacktraceFrame::symbols` און רעפּראַזענץ די מעטאַדאַטאַ פֿאַר אַ סימבאָל אין אַ באַקטראַסע.
///
/// # פארלאנגט פֿעיִקייטן
///
/// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// קאַפּטשערז אַ באַקטראַס בייַ די קאַללסייט פון דעם פֿונקציע, און אומגעקערט אַן אָונד פאַרטרעטונג.
    ///
    /// די פֿונקציע איז נוציק פֿאַר רעפּריזענטינג אַ באַקקטראַס ווי אַ כייפעץ אין ז 0 רוסט 0 ז.דעם אומגעקערט ווערט קענען זיין געשיקט איבער פֿעדעם און געדרוקט אנדערש, און דער ציל פון דעם ווערט איז צו זיין גאָר קאַנטיינד.
    ///
    /// באַמערקונג אַז אויף עטלעכע פּלאַטפאָרמס די אַקוואַזישאַן פון אַ פול באַקטראַסאַז און סאַלווינג עס קען זיין זייער טייַער.
    /// אויב די פּרייַז איז צו פיל פֿאַר דיין אַפּלאַקיישאַן, עס איז רעקאַמענדיד צו נוצן `Backtrace::new_unresolved()` אַנשטאָט וואָס ויסמיידן די סימבאָל האַכלאָטע שריט (וואָס יוזשאַוואַלי נעמט די לאָנגעסט) און אַלאַוז דיפערינג עס צו אַ שפּעטער דאַטע.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ווילן צו מאַכן זיכער אַז עס איז אַ ראַם צו באַזייַטיקן
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// ענלעך צו קסקסנומקס קס אַחוץ אַז דאָס קען נישט האַלטן קיין סימבאָלס, דאָס סימפּלי קאַפּטשערז די באַקטראַס ווי אַ רשימה פון ווענדט.
    ///
    /// שפּעטער, די `resolve` פונקציע קענען זיין רופט צו האַלטן די סימבאָלס פון די באַקטראַסאַז אין ליינעוודיק נעמען.
    /// די פֿונקציע יגזיסץ ווייַל די האַכלאָטע פּראָצעס קען מאל נעמען אַ באַטייטיק סומע פון צייט, כאָטש קיין באַקקטראַס קען זיין זעלטן געדרוקט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // קיין סימבאָל נעמען
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // סימבאָל נעמען איצט פאָרשטעלן
    /// ```
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    ///
    #[inline(never)] // ווילן צו מאַכן זיכער אַז עס איז אַ ראַם צו באַזייַטיקן
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// רעטורנס די ראָמען פון ווען דעם באַקטראַס איז קאַפּטשערד.
    ///
    /// דער ערשטער פּאָזיציע פון דעם רעפטל איז מסתּמא די פונקציע `Backtrace::new`, און די לעצטע ראַם איז מיסטאָמע עפּעס וועגן דעם פֿאָדעם אָדער די הויפּט פונקציע סטאַרטעד.
    ///
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// אויב דעם באַקטראַס איז באשאפן פֿון `new_unresolved`, די פֿונקציע וועט האַלטן אַלע אַדרעסעס אין די באַקטראַס צו זייער סימבאָליש נעמען.
    ///
    ///
    /// אויב דעם באַקטראַס איז ביז אַהער ריזאַלווד אָדער באשאפן דורך קס 00 קס, די פֿונקציע טוט גאָרנישט.
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// רעטורנס די רשימה פון סימבאָלס וואָס די ראַם קאָראַספּאַנדז צו.
    ///
    /// נאָרמאַללי, עס איז בלויז איין סימבאָל פּער ראַם, אָבער מאל אויב אַ נומער פון פאַנגקשאַנז זענען ינליינד אין איין ראַם, קייפל סימבאָלס וועט זיין אומגעקערט.
    /// דער ערשטער ליסטעד סימבאָל איז די "innermost function", די לעצטע סימבאָל איז די ויסווייניקסט (לעצטע קאַללער).
    ///
    /// באַמערקונג אַז אויב די ראַם איז פֿון אַן אַנריזאַלווד באַקטראַס, דאָס וועט ווייַזן אַ ליידיק רשימה.
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// זעלביקער ווי קס 00 קס
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // ווען דרוקן פּאַטס, מיר פּרובירן צו פּאַס די CWD אויב עס יגזיסץ, אַנדערש מיר נאָר דרוקן די דרך ווי-איז.
        // באַמערקונג אַז מיר טאָן דאָס בלויז פֿאַר די קורץ פֿאָרמאַט, ווייַל אויב עס איז פול, מיר מאַשמאָעס וועלן צו דרוקן אַלץ.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}