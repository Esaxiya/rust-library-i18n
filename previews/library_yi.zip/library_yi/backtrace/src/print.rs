#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// א פאָרמאַטטער פֿאַר באַקטראַסעס.
///
/// דער טיפּ קענען ווערן גענוצט צו דרוקן אַ באַקקטראַס ראַגאַרדלאַס פון ווו די באַקטראַס זיך קומט פון.
/// אויב איר האָט אַ `Backtrace` טיפּ, די `Debug` ימפּלאַמענטיישאַן שוין ניצט דעם דרוק פֿאָרמאַט.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// די סטיילז פון דרוקן וואָס מיר קענען דרוקן
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// פּרינץ אַ טערסער באַקקטראַסע וואָס יידילי בלויז כּולל באַטייַטיק אינפֿאָרמאַציע
    Short,
    /// פּרינץ אַ באַקטראַס וואָס כּולל אַלע מעגלעך אינפֿאָרמאַציע
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// שאַפֿן אַ נייַ קס 01 קס וואָס שרייבט רעזולטאַט צו די צוגעשטעלט קס 00 קס.
    ///
    /// די `format` אַרגומענט וועט קאָנטראָלירן די סטיל אין וואָס די באַקטראַס איז געדרוקט, און די `print_path` אַרגומענט וועט ווערן גענוצט צו דרוקן די `BytesOrWideString` ינסטאַנסיז פון פילענאַמעס.
    /// דער טיפּ זיך טוט נישט דרוקן קיין פילענאַמעס, אָבער דעם קאַללבאַקק איז פארלאנגט צו טאָן דאָס.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// פּרינץ אַ האַגדאָמע פֿאַר די באַקקטראַסע צו דרוקן.
    ///
    /// אין עטלעכע פּלאַטפאָרמס, דאָס איז פארלאנגט פֿאַר באַקטראַסעס צו זיין גאָר סימבאַלייטיד שפּעטער, און אַנדערש דאָס זאָל זיין דער ערשטער אופֿן איר רופן נאָך קריייטינג אַ `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// לייגט אַ ראַם צו די באַקקטראַס פּראָדוקציע.
    ///
    /// דעם יבערגעבן קערט אַן RAII בייַשפּיל פון אַ `BacktraceFrameFmt` וואָס קענען ווערן גענוצט צו דרוקן אַ ראַם, און ביי צעשטערונג עס ינקראַמאַנט די ראַם טאָמבאַנק.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// קאַמפּליץ די באַקקטראַסע פּראָדוקציע.
    ///
    /// דערווייַל עס איז אַ ניט-אָפּ אָבער איז מוסיף פֿאַר קאַמפּאַטאַבילאַטי future מיט באַקטראַס פאָרמאַץ.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // דערווייַל אַ ניט-אָפּ--אַרייַנגערעכנט דעם hook צו לאָזן future אַדישאַנז.
        Ok(())
    }
}

/// א פאָרמאַטטער פֿאַר בלויז איין ראַם פון אַ באַקטראַס.
///
/// דעם טיפּ איז באשאפן דורך די `BacktraceFmt::frame` פונקציע.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// פּרינץ אַ קס 00 קס מיט דעם ראַם פאָרמאַטטער.
    ///
    /// דאָס וועט רעקורסיוועלי דרוקן אַלע `BacktraceSymbol` ינסטאַנסיז אין די `BacktraceFrame`.
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// פּרינץ אַ קס 01 קס ין אַ קס 00 קס.
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: דאָס איז נישט גרויס אַז מיר טאָן ניט דרוקן עפּעס
            // מיט ניט-וטפ 8 פילענאַמעס.
            // צומ גליק כּמעט אַלץ איז קסקסנומקסקס אַזוי דאָס זאָל נישט זיין צו שלעכט.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// פּרינץ אַ רוי טרייסט קס 01 קס און קס 00 קס, טיפּיקלי פֿון די רוי קאַללבאַקקס פון דעם ז 0 קראַטע 0 ז.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// לייגט אַ רוי ראַם צו די באַקקטראַסע רעזולטאַט.
    ///
    /// דער אופֿן, ניט ענלעך דעם פריערדיקן, נעמט רוי אַרגומענטן אין פאַל זיי קומען פֿון פאַרשידענע לאָוקיישאַנז.
    /// באַמערקונג אַז דאָס קען זיין גערופן עטלעכע מאָל פֿאַר איין ראַם.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// לייגט אַ רוי ראַם צו די באַקקטראַסע רעזולטאַט, אַרייַנגערעכנט זייַל אינפֿאָרמאַציע.
    ///
    /// דעם אופֿן, ווי די פריערדיקע, נעמט רוי אַרגומענטן אין פאַל זיי קומען פֿון פאַרשידענע לאָוקיישאַנז.
    /// באַמערקונג אַז דאָס קען זיין גערופן עטלעכע מאָל פֿאַר איין ראַם.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // פוטשסיאַ קען נישט סימבאָליזירן אין אַ פּראָצעס, אַזוי עס האט אַ ספּעציעל פֿאָרמאַט וואָס קענען ווערן גענוצט צו סימבאָליזירן שפּעטער.
        // דרוק דעם אַנשטאָט פון דרוקן ווענדט זיך אין אונדזער פֿאָרמאַט דאָ.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ניט דאַרפֿן צו דרוקן "null" ראָמען, עס בייסיקלי נאָר מיטל אַז די סיסטעם צוריק שפּור איז געווען אַ ביסל לאָעט צו שפּור צוריק ווייַט.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // צו רעדוצירן TCB גרייס אין סגקס ענקלאַווע, מיר טאָן נישט וועלן צו ינסטרומענט פונקציאָנירן פונקציאָנירן סימבאָל האַכלאָטע.
        // אלא, מיר קענען דרוקן דעם אָפסעט פון דעם אַדרעס דאָ, וואָס קען זיין שפּעטער מאַפּט צו ריכטיק פונקציאָנירן.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // דרוק דעם אינדעקס פון די ראַם און די אַפּשאַנאַל ינסטרוקטיאָן טייַטל פון די ראַם.
        // אויב מיר ניטאָ ווייַטער פון דער ערשטער סימבאָל פון דעם ראַם, אָבער מיר נאָר דרוקן צונעמען ווייטספּייס.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // דערנאָך שרייַבן די סימבאָל נאָמען מיט די אָלטערנאַטיוו פאָרמאַטטינג פֿאַר מער אינפֿאָרמאַציע אויב מיר זענען אַ פול באַקטראַס.
        // דאָ מיר אויך האַנדלען מיט סימבאָלס וואָס האָבן קיין נאָמען,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // און לעצט, דרוקן די filename/line נומער אויב זיי זענען בארעכטיגט.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line זענען געדרוקט אויף שורות אונטער די סימבאָל נאָמען, אַזוי דרוקן אַ צונעמען ווייטספּייס צו סאָרט זיך רעכט.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // דעלעגאַט צו אונדזער ינערלעך קאַללבאַקק צו דרוקן די פילענאַמע און דרוקן די שורה נומער.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // לייג זייַל נומער, אויב פאַראַנען.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // די ערשטע סימבאָל פון אַ ראַם איז זאָרג פֿאַר אונדז
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}