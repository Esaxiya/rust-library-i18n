//! שטיצן פֿאַר סימבאָליפיקאַטיאָן ניצן די `gimli` crate אויף crates.io
//!
//! דאָס איז די ניט ויסצאָלן ימפּלאַמענטיישאַן פֿאַר סימבאָלאַטיאָן פֿאַר Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // סטאַטיק לעבן איז אַ ליגן צו כאַק אַרום מאַנגל פון שטיצן פֿאַר זיך-רעפערענטשאַל סטראַקץ.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // קאָנווערט צו 'סטאַטיק לעבן, ווייַל די סימבאָלס זאָל נאָר באָרגן `map` און `stash` און מיר ופהיטן זיי ווייטער.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // פֿאַר לאָודינג געבוירן ביבליאָטעק אויף קס 00 קס, זען עטלעכע דיסקוסיעס אויף קס 01 קס פֿאַר די פאַרשידן סטראַטעגיעס דאָ.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // מינגוו לייברעריז דערווייַל טאָן ניט שטיצן ASLR (rust-lang/rust#16514), אָבער דללס קענען נאָך זיין רילאָוקייטיד אין די אַדרעס פּלאַץ.
            // עס שיינט אַז אַדרעסעס אין דיבאַג אינפֿאָרמאַציע זענען ווי אויב די ביבליאָטעק איז לאָודיד אין די "image base", וואָס איז אַ פעלד אין די COFF טעקע כעדערז.
            // זינט דאָס איז וואָס דעבוגינפאָ מיינט צו רשימה מיר פּאַרס די סימבאָל טיש און קראָם ווענדט ווי אויב די ביבליאָטעק איז לאָודיד אין "image base".
            //
            // אָבער, די ביבליאָטעק קען נישט זיין לאָודיד אין "image base".
            // (מאַשמאָעס עפּעס אַנדערש קען זיין לאָודיד דאָרט?) דאָ איז די `bias` פעלד קומט אין שפּיל, און מיר דאַרפֿן צו רעכענען די ווערט פון `bias` דאָ.צום באַדויערן, אָבער עס איז נישט קלאָר ווי צו קויפן דאָס פֿון אַ לאָודיד מאָדולע.
            // וואָס מיר האָבן, אָבער, איז די פאַקטיש מאַסע אַדרעס (`modBaseAddr`).
            //
            // ווי אַ ביסל ויסוואָרף מיר איצט מאַפּ די טעקע, לייענען די אינפֿאָרמאַציע פון די טעקע כעדער און דאַן די MMAP.דאָס איז ווייסטפאַל ווייַל מיר וועלן מיסטאָמע ריאָופּאַן די ממאַפּ שפּעטער, אָבער דאָס זאָל איצט זיין גענוג גענוג.
            //
            // אַמאָל מיר האָבן די `image_base` (די לאָואַסט לאָודינג אָרט) און די `base_addr` (די פאַקטיש לאָודינג אָרט), מיר קענען פּלאָמבירן די `bias` (דיפעראַנסיז צווישן די פאַקטיש און די געוואלט), און די סטייטיד אַדרעס פון יעדער אָפּשניט איז די `image_base` ווייַל דאָס איז וואָס די טעקע זאגט.
            //
            //
            // איצט עס מיינט אַז ניט ווי ELF/MachO מיר קענען פאַרענדיקן איין אָפּשניט פּער ביבליאָטעק, ניצן ELF/MachO ווי די גאַנץ גרייס.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS ניצט די Mach-O טעקע פֿאָרמאַט און ניצט DYLD ספּעציפיש אַפּיס צו מאַסע אַ רשימה פון געבוירן ביבליאָטעק וואָס זענען טייל פון די אַפּלאַקיישאַן.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // ברענגען די נאָמען פון דעם ביבליאָטעק וואָס קאָראַספּאַנדז צו די וועג פון וווּ איר קענען אַרייַן עס.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // מאַסע די בילד כעדער פון דער ביבליאָטעק און דעלעגאַט צו `object` צו פּאַרס אַלע די מאַסע קאַמאַנדז אַזוי מיר קענען רעכענען אַלע די סעגמאַנץ ינוואַלווד דאָ.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // יטעראַטע איבער די סעגמאַנץ און פאַרשרייַבן באַוווסט מקומות פֿאַר סעגמאַנץ וואָס מיר געפֿינען.
            // אַדדיטיאָנאַללי רעקאָרדירן אינפֿאָרמאַציע וועגן טעקסט סעגמאַנץ פֿאַר פּראַסעסינג שפּעטער, זען ווייטער באַמערקונגען.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // באַשליסן די "slide" פֿאַר דעם ביבליאָטעק, וואָס ענדיקן די פאָרורטייל וואָס מיר נוצן צו געפֿינען אויס ווו די זכּרון אַבדזשעקץ זענען לאָודיד.
            // דאָס איז אַ ביסל מאָדנע מאָדנע און איז דער רעזולטאַט פון טריינג אַ ביסל טינגז אין די ווילד און זען וואָס סטיקס.
            //
            // די אַלגעמיינע געדאַנק איז אַז די `bias` פּלוס `stated_virtual_memory_address` פון אַ אָפּשניט וועט זיין ווו אין די פאַקטיש אַדרעס פּלאַץ די אָפּשניט איז.
            // די אנדערע זאַך מיר פאַרלאָזנ זיך איז אָבער אַז אַ פאַקטיש אַדרעס מינוס די `bias` איז דער אינדעקס צו קוקן אַרויף אין די סימבאָל טיש און דעבוגינפאָ.
            //
            // עס טורנס אָבער אַז די חשבונות זענען פאַלש פֿאַר סיסטעם לאָודיד לייברעריז.פֿאַר געבוירן עקסעקוטאַבלעס, עס איז ריכטיק.
            // ליפטינג עטלעכע לאָגיק פון די מקור פון LLDB, עס האט אַ ספּעציעלע קייסינג פֿאַר די ערשטער `__TEXT` אָפּטיילונג לאָודיד פֿון די טעקע אָפסעט 0 מיט אַ נאָנזעראָ גרייס.
            // צוליב וועלכער סיבה ווען דאָס איז פאָרשטעלן, עס מיינט צו מיינען אַז די סימבאָל טיש איז קאָרעוו צו די וומאַדדר רוק פֿאַר די ביבליאָטעק.
            // אויב עס איז *נישט* פאָרשטעלן, דער סימבאָל טיש איז קאָרעוו צו די וומאַדדר רוק פּלוס די סטייטיד אַדרעס פון די אָפּשניט.
            //
            // צו האַנדלען מיט די סיטואַציע אויב מיר * טאָן ניט געפֿינען אַ טעקסט אָפּטיילונג אין די טעקע אָפסעט נול, מיר פאַרגרעסערן די פאָרורטייל מיט די סטייטיד אַדרעס פון דער ערשטער טעקסט סעקשאַנז און אויך פאַרמינערן אַלע סטייטיד אַדרעסעס.
            //
            // אַזוי, די סימבאָל טיש איז שטענדיק שייכות צו די פאָרורטייל סומע.
            // דאָס סימז צו האָבן די רעכט רעזולטאַטן פֿאַר סימבאַלייזינג דורך די סימבאָל טיש.
            //
            // האָנעסטלי איך בין נישט גאַנץ זיכער צי דאָס איז רעכט אָדער אויב עס איז עפּעס אַנדערש וואָס זאָל אָנווייַזן ווי צו טאָן דאָס.
            // איצט, דאָס מיינט צו אַרבעט גענוג (?) און מיר זאָל שטענדיק קענען צו טוויק דעם איבער צייט אויב נייטיק.
            //
            // פֿאַר עטלעכע מער אינפֿאָרמאַציע, זען #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // אנדערע קס 00 קס (למשל
        // לינוקס) פּלאַטפאָרמס נוצן ELF ווי אַ כייפעץ טעקע פֿאָרמאַט און יוזשאַוואַלי ימפּלאַמענאַד אַן API גערופֿן `dl_iterate_phdr` צו מאַסע געבוירן לייברעריז.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` זאָל זיין אַ גילטיק פּוינטערז.
        // `vec` זאָל זיין אַ גילטיק טייַטל צו אַ `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 קען נישט שטיצן דיבאַג אינפֿאָרמאַציע, אָבער די בויען סיסטעם וועט שטעלן דיבאַג אינפֿאָרמאַציע אויף די קסקסנומקס קס.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // אַלץ אַנדערש זאָל נוצן ELF, אָבער קען נישט וויסן ווי צו אַרייַנשטעלן געבוירן לייברעריז.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// כל באַקאַנטע שערד לייברעריז האָבן שוין לאָודיד.
    libraries: Vec<Library>,

    /// מאַפּפּינגס קאַש וווּ מיר האַלטן פּאַרסט קאַרליק אינפֿאָרמאַציע.
    ///
    /// די רשימה האט אַ פאַרפעסטיקט קאַפּאַציטעט פֿאַר זיין גאַנץ ליפטיים וואָס קיינמאָל ינקריסיז.
    /// די `usize` עלעמענט פון יעדער פּאָר איז אַן אינדעקס אין `libraries` אויבן ווו `usize::max_value()` רעפּראַזענץ די קראַנט עקסעקוטאַבלע.
    ///
    /// די `Mapping` איז קאָראַספּאַנדיד פּאַרסעד קאַרליק אינפֿאָרמאַציע.
    ///
    /// באַמערקונג אַז דאָס איז בייסיקלי אַ LRU קאַש, און מיר וועלן יבעררוק די טינגז דאָ ווי מיר סימבאָליזירן ווענדט.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// אָפּשניט פון די ביבליאָטעק לאָודיד אין זכּרון און ווו זיי זענען לאָודיד.
    segments: Vec<LibrarySegment>,
    /// די "bias" פון דעם ביבליאָטעק איז יוזשאַוואַלי ווו עס איז לאָודיד אין זכּרון.
    /// די ווערט איז מוסיף צו די סטייטיד אַדרעס פון יעדער אָפּשניט צו באַקומען די פאַקטיש ווירטואַל זכּרון אַדרעס וואָס די אָפּשניט איז לאָודיד אין.
    /// אין אַדישאַן, דעם פאָרורטייל איז סאַבטראַקטיד פֿון פאַקטיש ווירטואַל זכּרון ווענדט צו אינדעקס אין דעבוגינפאָ און די סימבאָל טיש.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// די סטייטיד אַדרעס פון דעם אָפּשניט אין די כייפעץ טעקע.
    /// דאָס איז נישט אַקטשאַוואַלי ווו די אָפּשניט איז לאָודיד, אָבער דעם אַדרעס פּלוס די כּולל ביבליאָטעק ס קס 00 קס איז ווו צו געפֿינען עס.
    ///
    stated_virtual_memory_address: usize,
    /// די גרייס פון דעם אָפּשניט אין זכּרון.
    len: usize,
}

// אַנסייף ווייַל דאָס איז פארלאנגט צו זיין ויסווייניק סינגקראַנייזד
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // אַנסייף ווייַל דאָס איז פארלאנגט צו זיין ויסווייניק סינגקראַנייזד
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // א זייער קליין, זייער פּשוט LRU קאַש פֿאַר מאַפּינגז פֿאַר דיבאַג אינפֿאָרמאַציע.
        //
        // די שלאָגן קורס זאָל זיין זייער הויך ווייַל די טיפּיש אָנלייגן קען נישט אַריבער צווישן פילע שערד לייברעריז.
        //
        // די `addr2line::Context` סטראַקטשערז זענען שיין טייַער צו מאַכן.
        // די קאָס איז געריכט צו זיין אַבאָרטיד דורך סאַבסאַקוואַנט קס 00 קס קוויריז, וואָס ליווערידזש די סטראַקטשערז געבויט ווען קאַנסטרוקטינג `אַדדר 2 ליניע: : קאָנטעקסט`ס צו באַקומען אָנגענעם ספּעעדופּס.
        //
        // אויב מיר טאָן ניט האָבן דעם קאַש, די אַמערטיזיישאַן וואָלט קיינמאָל פּאַסירן, און סימבאָליזינג באַקקטראַסעס וואָלט זיין ססססללללאָאָאָאָוווווווו.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ערשטער, פּרובירן אויב די `lib` האט אַ אָפּשניט מיט `addr` (האַנדלינג רילאָוקיישאַן).אויב די טשעק דורכגעגאנגען, מיר קענען פאָרזעצן ווייטער און טאַקע איבערזעצן דעם אַדרעס.
                //
                // באַמערקונג אַז מיר נוצן `wrapping_add` דאָ צו ויסמיידן אָוווערפלאָו טשעקס.עס איז געווען געזען אין די ווילד אַז די SVMA + פאָרורטייל קאַמפּיאַטיישאַן אָוווערפלאָוז.
                // עס מיינט אַ ביסל מאָדנע אַז עס קען פּאַסירן, אָבער מיר קענען נישט מאַכן אַ ריזיק סומע וועגן אים אַנדערש ווי מיסטאָמע נאָר איגנאָרירן די סעגמאַנץ ווייַל זיי מיסטאָמע אָנווייַזן אין פּלאַץ.
                //
                // דעם ערידזשנאַלי געקומען אַרויף אין rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // איצט, `lib` כּולל `addr`, מיר קענען פאָרלייגן די פאָרורטייל צו געפֿינען די סטייטיד וויראַל זכּרון אַדרעס.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // ינוועראַנט: נאָך דעם קאַנדישאַנאַל קאַמפּליץ אָן פרי צוריקקומען
        // פֿון אַ טעות, די קאַש פּאָזיציע פֿאַר דעם דרך איז ביי אינדעקס 0.

        if let Some(idx) = idx {
            // ווען די מאַפּינג איז שוין אין די קאַש, מאַך עס צו די פראָנט.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // ווען די מאַפּינג איז נישט אין די קאַש, שאַפֿן אַ נייַע מאַפּינג, אַרייַן עס אין די פראָנט פון די קאַש און יוויקט די אָולדאַסט קאַש פּאָזיציע אויב נייטיק.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // טאָן ניט רינען די `'static` לעבן, מאַכן זיכער אַז דאָס איז בלויז צו זיך
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // פאַרלענגערן די לעבן פון קס 00 קס צו קס 01 קס זינט מיר זענען ליידער פארלאנגט צו דאָ, אָבער עס ס טאָמיד געגאנגען אויס ווי אַ רעפֿערענץ אַזוי קיין רעפֿערענץ צו עס זאָל זיין פּערסיסטאַד ווייַטער פון דעם ראַם סייַ ווי סייַ.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // לעסאָף, באַקומען אַ קאַשט מאַפּינג אָדער שאַפֿן אַ נייַע מאַפּינג פֿאַר דעם טעקע און אָפּשאַצן די DWARF אינפֿאָרמאַציע צו געפֿינען די file/line/name פֿאַר דעם אַדרעס.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// מיר זענען ביכולת צו געפֿינען ראַם אינפֿאָרמאַציע פֿאַר דעם סימבאָל, און די ראַם פון 'אַדדר 2 ליניע' ינערלעך האט אַלע די ניט-פּינטלעך דעטאַילס.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// קען נישט געפֿינען דיבאַג אינפֿאָרמאַציע, אָבער מיר געפֿונען עס אין די סימבאָל טיש פון די שרעטל עקסעקוטאַבלע.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}