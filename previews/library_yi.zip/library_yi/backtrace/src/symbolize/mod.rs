use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// באַשליסן אַן אַדרעס צו אַ סימבאָל און פאָרן די סימבאָל צו די ספּעסאַפייד קלאָוזשער.
///
/// די פֿונקציע וועט אָפּקוקן די געגעבן אַדרעס אין געביטן אַזאַ ווי די היגע סימבאָל טיש, דינאַמיש סימבאָל טיש, אָדער דוואָרף דיבאַג אינפֿאָרמאַציע (דיפּענדינג אויף די אַקטיווייטיד ימפּלאַמענטיישאַן) צו געפֿינען סימבאָלס צו טראָגן.
///
///
/// די קלאָוזשער קען נישט זיין גערופֿן אויב די האַכלאָטע קען נישט זיין דורכגעקאָכט, און עס קען אויך זיין גערופן מער ווי איין מאָל אין פאַל פון ינליינד פאַנגקשאַנז.
///
/// יילד סימבאָלס רעפּראַזענץ די דורכפירונג אין די ספּעציפיצירט `addr`, און אומגעקערט קס 01 קס פּערז פֿאַר דעם אַדרעס (אויב עס איז בנימצא)
///
/// באַמערקונג אַז אויב איר האָבן `Frame`, עס איז רעקאַמענדיד צו נוצן די `resolve_frame` פונקציע אַנשטאָט פון דעם.
///
/// # פארלאנגט פֿעיִקייטן
///
/// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
///
/// # Panics
///
/// די פונקציע סטרייווז צו קיינמאָל ז 0 פּאַניק 0 ז, אָבער אויב די `cb` צוגעשטעלט ז 0 פּאַניקס 0 ז, עטלעכע פּלאַטפאָרמס וועט צווינגען אַ טאָפּל ז 0 פּאַניק 0 ז צו אַבאָרט דעם פּראָצעס.
/// עטלעכע פּלאַטפאָרמס נוצן אַ C ביבליאָטעק וואָס ינערלעך ניצט קאַללבאַקקס וואָס קענען ניט זיין אַנוואָונד דורך, אַזוי פּאַניקינג פון קס 00 קס קען צינגל אַ פּראָצעס אַבאָרט.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // נאָר קוק אין די שפּיץ ראַם
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// באַשליסן אַ פריער כאַפּן ראַם צו אַ סימבאָל און פאָרן די סימבאָל צו די ספּעסאַפייד קלאָוזשער.
///
/// דעם פונקטיאָן פּערפאָרמז די זעלבע פונקציע ווי קס 00 קס אַחוץ אַז עס נעמט אַ קס 01 קס ווי אַן אַרגומענט אַנשטאָט פון אַן אַדרעס.
/// דאָס קען לאָזן עטלעכע פּלאַטפאָרמע ימפּלאַמענטיישאַנז פון באַקטראַסינג צו צושטעלן מער פּינטלעך אינפֿאָרמאַציע אָדער אינפֿאָרמאַציע וועגן ינלינע ראָמען.
///
/// עס איז רעקאַמענדיד צו נוצן דאָס אויב איר קענען.
///
/// # פארלאנגט פֿעיִקייטן
///
/// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
///
/// # Panics
///
/// די פונקציע סטרייווז צו קיינמאָל ז 0 פּאַניק 0 ז, אָבער אויב די `cb` צוגעשטעלט ז 0 פּאַניקס 0 ז, עטלעכע פּלאַטפאָרמס וועט צווינגען אַ טאָפּל ז 0 פּאַניק 0 ז צו אַבאָרט דעם פּראָצעס.
/// עטלעכע פּלאַטפאָרמס נוצן אַ C ביבליאָטעק וואָס ינערלעך ניצט קאַללבאַקקס וואָס קענען ניט זיין אַנוואָונד דורך, אַזוי פּאַניקינג פון קס 00 קס קען צינגל אַ פּראָצעס אַבאָרט.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // נאָר קוק אין די שפּיץ ראַם
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP וואַלועס פֿון סטאַק ראָמען זענען טיפּיקלי קס 00 קס די ינסטרוקטיאָן *נאָך* די רופן אַז ס 'די פאַקטיש סטאַק שפּור.
// אויב דאָס סימבאָליזירן דעם, די X00 קס נומער איז איינער פאָרויס און טאָמער אין די פּאָסל אויב עס ס לעבן די סוף פון די פונקציע.
//
// דאָס איז בייסיקלי שטענדיק דער פאַל אויף אַלע פּלאַטפאָרמס, אַזוי מיר שטענדיק אַראָפּרעכענען איינער פון אַ ריזאַלווד IP צו האַלטן עס צו די פריערדיקע רופן ינסטרוקטיאָן אַנשטאָט פון וואָס די אינסטרוקציע איז אומגעקערט צו.
//
//
// ידעאַללי מיר וואָלט נישט טאָן דאָס.
// ידעאַללי, מיר וואָלט דאַרפן די קאַלערז פון די קס 00 קס אַפּיס דאָ צו מאַניואַלי טאָן די קס 01 קס און טאָן אַז זיי וועלן אָרט אינפֿאָרמאַציע פֿאַר די *פרייַערדיק* ינסטרוקטיאָן, נישט די קראַנט.
// ידעאַללי, מיר וואָלט אויך ויסשטעלן `Frame` אויב מיר טאַקע די אַדרעס פון דער ווייַטער לימעד אָדער די קראַנט.
//
// פֿאַר איצט, כאָטש דאָס איז אַ שיין נישע דייַגע, אַזוי מיר ינטראַקטיווע שטענדיק אַראָפּרעכענען איינער.
// קאָנסומערס זאָל האַלטן ארבעטן און באַקומען גאַנץ גוטע רעזולטאַטן, אַזוי מיר זאָל זיין גוט גענוג.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// די זעלבע ווי `resolve`, נאָר אַנסייף ווייַל עס איז ונסינטשראָניזעד.
///
/// די פֿונקציע האט נישט סינגקראַנאַזיישאַן גואַראַנטעעס אָבער איז בארעכטיגט ווען די `std` שטריך פון דעם crate איז נישט קאַמפּיילד אין.
/// זען די `resolve` פונקציע פֿאַר מער דאַקיומענטיישאַן און ביישפילן.
///
/// # Panics
///
/// זען אינפֿאָרמאַציע אויף `resolve` פֿאַר קאַוועאַץ פון `cb` פּאַניקקינג.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// די זעלבע ווי `resolve_frame`, נאָר אַנסייף ווייַל עס איז ונסינטשראָניזעד.
///
/// די פֿונקציע האט נישט סינגקראַנאַזיישאַן גואַראַנטעעס אָבער איז בארעכטיגט ווען די `std` שטריך פון דעם crate איז נישט קאַמפּיילד אין.
/// זען די `resolve_frame` פונקציע פֿאַר מער דאַקיומענטיישאַן און ביישפילן.
///
/// # Panics
///
/// זען אינפֿאָרמאַציע אויף `resolve_frame` פֿאַר קאַוועאַץ פון `cb` פּאַניקקינג.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// א trait רעפּריזענטינג די האַכלאָטע פון אַ סימבאָל אין אַ טעקע.
///
/// די trait איז יילדאַד ווי אַ trait כייפעץ צו די קלאָוזשער צו די `backtrace::resolve` פונקציע, און עס איז כמעט דיספּאַטשט ווייַל עס איז אומבאַקאַנט וואָס ימפּלאַמענטיישאַן איז הינטער אים.
///
///
/// א סימבאָל קענען געבן קאָנטעקסטואַל אינפֿאָרמאַציע וועגן אַ פֿונקציע, למשל די נאָמען, פילענאַמע, שורה נומער, גענוי אַדרעס, אאז"ו ו.
/// ניט אַלע אינפֿאָרמאַציע איז שטענדיק בנימצא אין אַ סימבאָל, אָבער אַלע מעטהאָדס ווייַזן אַן `Option`.
///
///
pub struct Symbol {
    // TODO: דעם לעבן געבונדן דאַרף זיין פּערסיסטאַד יווענטשאַוואַלי צו קס 00 קס,
    // אָבער דאָס איז דערווייַל אַ ברייקינג ענדערונג.
    // דערווייַל, דאָס איז זיכער ווייַל `Symbol` איז שטענדיק רענדערד דורך דערמאָנען און קענען ניט זיין קלאָונד.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// רעטורנס די נאָמען פון דעם פֿונקציע.
    ///
    /// די אומגעקערט סטרוקטור קענען ווערן גענוצט צו אָנפרעגן פאַרשידן פּראָפּערטיעס וועגן דעם סימבאָל נאָמען:
    ///
    ///
    /// * די `Display` ימפּלאַמענטיישאַן וועט דרוקן די דימאַנגגאַל סימבאָל.
    /// * די רוי `str` ווערט פון די סימבאָל קענען זיין אַקסעסט (אויב עס איז גילטיק utf-8).
    /// * די רוי ביטעס פֿאַר די סימבאָל נאָמען קענען זיין אַקסעסט.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// רעטורנס די סטאַרטינג אַדרעס פון דעם פֿונקציע.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// רעטורנס די רוי פילענאַמע ווי אַ רעפטל.
    /// דאָס איז דער הויפּט נוציק פֿאַר `no_std` ינווייראַנמאַנץ.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// קערט דער זייַל נומער פֿאַר וואָס דער סימבאָל איז דערווייַל עקסאַקיוטינג.
    ///
    /// בלויז גימלי דערווייַל פּראָווידעס אַ ווערט דאָ און אפילו בלויז אויב קס 01 קס קערט קס 00 קס, און אַזוי עס איז דעריבער אונטערטעניק צו ענלעך קאַוועאַץ.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// רעטורנס די שורה נומער פֿאַר ווו דעם סימבאָל איז דערווייַל עקסאַקיוטינג.
    ///
    /// דער צוריקקער ווערט איז טיפּיקלי `Some` אויב `filename` קערט `Some`, און דעריבער איז אונטערטעניק צו ענלעך קאַוועאַץ.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// קערט דער טעקע נאָמען וווּ די פונקציע איז דיפיינד.
    ///
    /// דאָס איז דערווייַל בלויז בנימצא ווען ליבבאַקטראַסע אָדער גימלי איז געניצט (למשל
    /// unix אנדערע פּלאַטפאָרמס) און ווען אַ ביינערי איז קאַמפּיילד מיט דעבוגינפאָ.
    /// אויב קיין פון די באדינגונגען זענען נישט מקיים, דאָס קען מיסטאָמע צוריקקומען `None`.
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // אפֿשר אַ פּאַרסט C++ סימבאָל, אויב פּאַרסינג די מאַנגגאַלד סימבאָל ווי Rust ניט אַנדערש.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // מאַכט זיכער צו האַלטן דעם נול-סייזד, אַזוי די `cpp_demangle` שטריך האט קיין פּרייַז ווען פאַרקריפּלט.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// א ראַפּער אַרום אַ סימבאָל נאָמען צו צושטעלן ערגאַנאַמיק אַקסעסעריז צו די דימאַנגגאַלד נאָמען, רוי ביטעס, רוי שטריקל, עטק.
///
// לאָזן טויט קאָד ווען `cpp_demangle` שטריך איז נישט ענייבאַלד.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// קריייץ אַ נייַ סימבאָל נאָמען פֿון די רוי אַנדערלייינג ביטעס.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// קערט די רוי קס 01 קס סימבאָל נאָמען ווי אַ קס 02 קס אויב די סימבאָל איז גילטיק קס 00 קס.
    ///
    /// ניצן די `Display` ימפּלאַמענטיישאַן אויב איר ווילט די דעמאַנגלעד ווערסיע.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// רעטורנס די רוי סימבאָל נאָמען ווי אַ רשימה פון ביטעס
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // דאָס קען זיין פּרינטעד אויב די דעמאַנגגאַלד סימבאָל איז נישט אַקשלי גילטיק, אַזוי האַנדלען מיט די טעות דאָ מיט גראַציעז דורך נישט פּראַפּאַגייטינג עס אַוטווערדז.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// פּרווון צו צוריקקריגן אַז קאַשט זיקאָרן געניצט צו סימבאָליש אַדרעסעס.
///
/// דער אופֿן וועט פּרווון צו באַפרייַען גלאבאלע דאַטן סטראַקטשערז וואָס זענען אַנדערש קאַשט גלאָובאַלי אָדער אין דעם פאָדעם וואָס יוזשאַוואַלי רעפּריזענטיד די דוואַרף אינפֿאָרמאַציע אָדער ענלעך.
///
///
/// # Caveats
///
/// די פונקציע איז שטענדיק בנימצא, אָבער עס קען נישט טאָן עפּעס אין רובֿ ימפּלעמענטאַטיאָנס.
/// לייברעריז ווי dbghelp אָדער libbacktrace טאָן ניט צושטעלן פאַסילאַטיז צו האַנדלען מיט די שטאַט און פירן די אַלאַקייטיד זכּרון.
/// דערווייַל, די `gimli-symbolize` שטריך פון דעם crate איז די בלויז שטריך וואָס די פֿונקציע האט קיין ווירקונג.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}