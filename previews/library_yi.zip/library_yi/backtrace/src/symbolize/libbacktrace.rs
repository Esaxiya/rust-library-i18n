//! סימבאָליש סטראַטעגיע ניצן די דוואַרף פּאַרסינג קאָד אין ליבבאַקטראַסע.
//!
//! די ליבבאַקטראַסע C ביבליאָטעק, טיפּיקלי פונאנדערגעטיילט מיט gcc, שטיצט ניט בלויז דזשענערייטינג אַ באַקקטראַס (וואָס מיר טאָן ניט טאַקע נוצן), אָבער אויך סימבאָליזירן די באַקטראַס און האַנדלען מיט קאַרליק דיבאַג אינפֿאָרמאַציע וועגן טינגז ווי ינליינד ראָמען און וואָס.
//!
//!
//! דאָס איז לעפיערעך קאָמפּליצירט רעכט צו אַ פּלאַץ פון פאַרשידן קאַנסערנז דאָ, אָבער די גרונט געדאַנק איז:
//!
//! * ערשטער מיר רופן `backtrace_syminfo`.אויב מיר קענען דאָס באַקומען סימבאָל אינפֿאָרמאַציע פון די דינאַמיש סימבאָל טיש.
//! * ווייַטער מיר רופן `backtrace_pcinfo`.דאָס וועט פּאַרס דעבוגינפאָ טישן אויב זיי זענען בנימצא און לאָזן אונדז צו צוריקקריגן אינפֿאָרמאַציע וועגן ינלינע ראָמען, פילענאַמעס, שורה נומערן, עטק.
//!
//! עס זענען אַ פּלאַץ פון טריקערי וועגן די קאַרליק טישן אין ליבבאַקטראַסע, אָבער אַלעווייַ עס איז נישט דער סוף פון דער וועלט און איז קלאָר גענוג ווען איר לייענען אונטן.
//!
//! דאָס איז די ניט ויסצאָלן סימבאָלאַטיאָן סטראַטעגיע פֿאַר ניט-מסווק און ניט-אָסקס פּלאַטפאָרמס.אָבער, דאָס איז די פעליקייַט סטראַטעגיע פֿאַר OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // אויב מעגלעך בעסער די `function` נאָמען וואָס קומט פֿון דעבוגינפאָ און קענען זיין טיפּיקלי מער פּינטלעך פֿאַר ביישפּיל ראָמען פֿאַר בייַשפּיל.
                // אויב דאָס איז נישט פאָרשטעלן, פאַלן צוריק צו דער נאָמען פון די סימבאָל טיש אין `symname`.
                //
                // באַמערקונג אַז יז קס 01 קס קען פילן עפּעס ווייניקער פּינטלעך, פֿאַר בייַשפּיל זייַענדיק ליסטעד ווי קס 02 קס איז ניט טייד פון קס 00 קס.
                //
                // עס איז נישט טאַקע קלאָר וואָס, אָבער קוילעלדיק די `function` נאָמען מיינט מער פּינטלעך.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // טאָן גאָרנישט פֿאַר איצט
}

/// טיפּ פון די X01 קס טייַטל דורכגעגאנגען אין קס 00 קס
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // אַמאָל די קאַללבאַקק איז ינוואָוקד פֿון קס 01 קס ווען מיר אָנהייבן ריזאַלווינג, מיר גיין ווייטער צו רופן קס 00 קס.
    // די `backtrace_pcinfo` פֿונקציע וועט באַראַטנ דיבאַג אינפֿאָרמאַציע און אַטעמפּץ צו טאָן טינגז ווי צו צוריקקריגן קס 01 קס אינפֿאָרמאַציע און ינליינד ראָמען.
    // באַמערקונג אַז קס 01 קס קען פאַרלאָזן אָדער טאָן ניט טאָן פיל אויב עס איז נישט דיבאַג אינפֿאָרמאַציע, אַזוי אויב דאָס כאַפּאַנז, מיר וועלן זיכער רופן די קאַללבאַקק מיט לפּחות איין סימבאָל פֿון די קס 00 קס.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// טיפּ פון די `data` טייַטל אין `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// די ליבבאַקטראַסע אַפּי שטיצט קריייטינג אַ שטאַט, אָבער עס קען נישט שטיצן דיסטרויינג אַ שטאַט.
// איך פּערסנאַלי נעמען דאָס צו מיינען אַז אַ שטאַט איז מענט צו ווערן באשאפן און לעבן אויף אייביק.
//
// איך וואָלט ווי צו פאַרשרייבן אַן at_exit() האַנדלער וואָס רייניקן דעם שטאַט, אָבער ליבבאַקטראַסע גיט קיין וועג צו טאָן דאָס.
//
// מיט די קאַנסטריינץ, די פֿונקציע האט אַ סטאַטיקלי קאַשט שטאַט וואָס איז קאַלקיאַלייטיד דער ערשטער מאָל דאָס איז געבעטן.
//
// געדענקען אַז באַקקטראַסינג אַלע כאַפּאַנז סיריאַללי (איין גלאבאלע שלאָס).
//
// באַמערקונג די פעלן פון סינגקראַנאַזיישאַן דאָ איז רעכט צו דער פאָדערונג אַז `resolve` איז ויסווייניק סינגקראַנייזד.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // דו זאלסט נישט נוצן טרעאַדסאַפע קייפּאַבילאַטיז פון ליבבאַקטראַסע ווייַל מיר שטענדיק רופן עס אין אַ סינגקראַנייזד וועג.
        //
        0,
        error_cb,
        ptr::null_mut(), // קיין עקסטרע דאַטן
    );

    return STATE;

    // באַמערקונג אַז ליבבאַקטראַסע קענען אַרבעטן אין אַלע, עס דאַרף צו געפֿינען די דוואָרף דיבאַג אינפֿאָרמאַציע פֿאַר די קראַנט עקסעקוטאַבלע.דאָס איז יוזשאַוואַלי דורכגעקאָכט דורך אַ נומער פון מעקאַניזאַמז, אַרייַנגערעכנט, אָבער נישט לימיטעד צו:
    //
    // * /proc/self/exe אויף שטיצט פּלאַטפאָרמס
    // * די פילענאַמע איז דורכגעקאָכט בפירוש ביי שאַפֿן שטאַט
    //
    // די ליבבאַקטראַסע ביבליאָטעק איז אַ גרויס נומער פון C קאָד.געוויינטלעך, דאָס מיינט וואַלנעראַביליטיז מיט זכּרון זיכערקייַט, ספּעציעל ווען האַנדלינג מיט דיפאָרמד דעבוגינפאָ.
    // ליבסטד איז היסטאָריש אין פילע פון די.
    //
    // אויב קס 00 קס איז געניצט, מיר קענען יוזשאַוואַלי איגנאָרירן די, ווייַל מיר יבערנעמען אַז ליבבאַקטראַסע איז קס 01 קס און אַנדערש טוט נישט טאָן טשודנע טינגז מיט קס 02 קס קאַרליק דעבוג אינפֿאָרמאַציע.
    //
    //
    // אויב מיר פאָרן אַ פילענאַמע, עס איז מעגלעך אויף עטלעכע פּלאַטפאָרמס (ווי BSDs) ווו אַ בייזע אַקטיאָר קען פאַרשאַפן אַן אַרביטראַריש טעקע צו זיין אָרט.
    // דאָס מיינט אַז אויב מיר זאָגן ליבבאַקקטראַסע וועגן אַ פילענאַמע, עס קען זיין ניצן אַ אַרביטראַריש טעקע, עפשער קאָזינג סעגפאָלץ.
    // אויב מיר טאָן ניט זאָגן ליבבאַקטראַסע עפּעס, עס וועט נישט טאָן עפּעס אויף פּלאַטפאָרמס וואָס טאָן ניט שטיצן פּאַטס ווי קס 00 קס!
    //
    // געגעבן אַלע וואָס מיר פּרובירן ווי שווער ווי מעגלעך צו *נישט* פאָרן אין אַ פילענאַמע, אָבער מיר מוזן אויף פּלאַטפאָרמס וואָס טאָן ניט שטיצן /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // באַמערקונג אַז יידילי מיר וואָלט נוצן קס 00 קס, אָבער מיר קענען נישט דאַרפן קס 01 קס דאָ.
            //
            // ניצן `_NSGetExecutablePath` צו מאַסע די קראַנט עקסעקוטאַבלע דרך אין אַ סטאַטיק געגנט (וואָס אויב עס איז צו קליין נאָר געבן אַרויף).
            //
            //
            // באַמערקונג אַז מיר געטרויען ליבבאַקקטראַסע דאָ צו נישט שטאַרבן אויף פאַרדאָרבן עקסעקוטאַבלעס, אָבער דאָס איז זיכער ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows האט אַ מאָדע פון עפן טעקעס אַז נאָך עפן עס קענען ניט זיין אויסגעמעקט.
            // אין אַלגעמיין, וואָס מיר וועלן דאָ ווייַל מיר וועלן צו ענשור אַז אונדזער עקסעקוטאַבלע איז נישט טשאַנגינג אונטער אונדז נאָך מיר געבן עס צו ליבבאַקטראַסע, אַלעווייַ מיטינג די פיייקייט צו פאָרן אַרביטראַריש דאַטן אין ליבבאַקטראַסע (וואָס קען זיין מיסאַנדאַלד).
            //
            //
            // אויב מיר טאָן אַ טאַנצן דאָ צו פּרווון צו באַקומען אַ סאָרט פון שלאָס אויף אונדזער בילד:
            //
            // * נעמען אַ שעפּן צו דעם קראַנט פּראָצעס, מאַסע די פילענאַמע.
            // * עפֿן אַ טעקע צו די פילענאַמע מיט די רעכט פלאַגס.
            // * רילאָוד די טעקע נאָמען פון דעם קראַנט פּראָצעס און מאַכן זיכער אַז עס איז די זעלבע
            //
            // אויב דאָס אַלע פּאַסיז, אין טעאָריע האָבן טאַקע געעפנט די טעקע פון אונדזער פּראָצעס און מיר זענען געראַנטיד אַז דאָס וועט נישט טוישן.FWIW אַ בינטל פון דעם איז קאַפּיד פֿון libstd היסטאָריש, אַזוי דאָס איז מיין בעסטער ינטערפּריטיישאַן פון וואָס איז געווען געשעעניש.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // דאָס לעבט אין סטאַטיק זכּרון אַזוי מיר קענען צוריקקומען עס ..
                static mut BUF: [i8; N] = [0; N];
                // ... און דאָס לעבן אויף דעם אָנלייגן זינט עס איז צייַטווייַליק
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // בעקיוון ליקס קס 00 קס דאָ ווייַל ווייל אַז עפענען זאָל ופהיטן אונדזער שלאָס אויף דעם טעקע נאָמען.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // מיר ווילן צו צוריקקומען אַ פּעקל וואָס איז נול-טערמאַנייטיד, אַזוי אויב אַלץ איז געווען אָנגעפילט און עס איז גלייַך צו די גאַנץ לענג, דאָס איז גלייך צו דורכפאַל.
                //
                //
                // אויב איר אומגעקערט הצלחה, מאַכן זיכער אַז די נול בייט איז אַרייַנגערעכנט אין די רעפטל.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // באַקקטראַסע ערראָרס זענען דערווייַל סוועפּט אונטער די טעפּעך
    let state = init_state();
    if state.is_null() {
        return;
    }

    // רוף די `backtrace_syminfo` API וואָס (פֿון לייענען די קאָד) זאָל רופן `syminfo_cb` פּונקט אַמאָל (אָדער דורכפאַל מיט אַ מיסטאָמע טעות).
    // מיר האַנדלען מיט מער `syminfo_cb`.
    //
    // באַמערקונג אַז מיר טאָן דאָס ווייַל `syminfo` וועט אָנקוקן די סימבאָל טיש און געפֿינען סימבאָל נעמען אפילו אויב עס איז קיין דיבאַג אינפֿאָרמאַציע אין די ביינערי.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}