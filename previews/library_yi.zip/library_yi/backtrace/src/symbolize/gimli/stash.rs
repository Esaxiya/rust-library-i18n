// בלויז געוויינט אויף Linux רעכט איצט, אַזוי לאָזן טויט קאָד אנדערש
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// א פּשוט ארענע אַלאַקייטער פֿאַר בייט באַפערז.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// אַללאָקאַטעס אַ באַפער פון די ספּעסאַפייד גרייס און קערט אַ מיוטאַבאַל דערמאָנען צו אים.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // זיכערהייט: דאָס איז די בלויז פונקציע וואָס קאַנסטראַקץ מיוטאַבאַל
        // דערמאָנען צו קס 00 קס.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // זיכערקייט: מיר קיינמאָל באַזייַטיקן עלעמענטן פֿון קס 00 קס, אַזוי אַ רעפֿערענץ
        // צו די דאַטן ין קיין באַפער וועט לעבן ווי לאַנג ווי `self` טוט.
        &mut buffers[i]
    }
}