//! פּלאַטפאָרמע אָפענגיק טייפּס.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// א פּלאַטפאָרמע פרייַ פאַרטרעטונג פון אַ שטריקל.
/// ווען ארבעטן מיט קס 00 קס ענייבאַלד, עס איז רעקאַמענדיד צו די קאַנוויניאַנס מעטהאָדס פֿאַר פּראַוויידינג קאַנווערזשאַנז צו קס 01 קס טייפּס.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// א רעפטל, טיפּיקלי צוגעשטעלט אויף קס 00 קס פּלאַטפאָרמס.
    Bytes(&'a [u8]),
    /// ברייט סטרינגס טיפּיקאַללי פֿון Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// לאָססי קאַנווערץ צו אַ קס 01 קס, וועט אַלאַקייט אויב קס 02 קס איז ניט גילטיק קס 03 קס אָדער אויב קס 04 קס איז קס 00 קס.
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// גיט אַ קס 01 קס פאַרטרעטונג פון קס 00 קס.
    ///
    /// # פארלאנגט פֿעיִקייטן
    ///
    /// די פונקציע ריקווייערז די `std` שטריך פון די `backtrace` crate צו זיין ענייבאַלד, און די `std` שטריך איז ענייבאַלד דורך פעליקייַט.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}