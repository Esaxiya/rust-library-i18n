# backtrace-rs

[Documentation](https://docs.rs/backtrace)

א ביבליאָטעק פֿאַר אַקוויירינג באַקטראַסעס אין רונטימע פֿאַר ז 0 רוסט 0 ז.
דער ביבליאָטעק יימז צו פֿאַרבעסערן די שטיצן פון דער נאָרמאַל ביבליאָטעק דורך פּראַוויידינג אַ פּראָגראַממאַטיק צובינד צו אַרבעטן מיט, אָבער עס אויך שטיצט סימפּלי דרוקן דעם קראַנט באַקטראַסע ווי ליבסטד ס panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

צו סימפּלי כאַפּן אַ באַקטראַס און אָפּגעבן האַנדלען מיט אים ביז אַ שפּעטער צייט, איר קענען נוצן די שפּיץ-מדרגה קס 00 קס טיפּ.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

אויב איר ווילט מער רוי אַקסעס צו די פאַקטיש טרייסינג פאַנגקשאַנאַליטי, איר קענען נוצן די `trace` און `resolve` פאַנגקשאַנז גלייַך.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // האַלטן דעם ינסטרוקטיאָן טייַטל צו אַ סימבאָל נאָמען
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // פאָרזעצן צו די ווייַטער ראַם
    });
}
```

# License

דער פּרויעקט איז לייסאַנסט אונטער איינער פון די

 * Apache License, ווערסיע 2.0, ([LICENSE-APACHE](LICENSE-APACHE) אָדער http://www.apache.org/licenses/LICENSE-2.0)
 * MIT דערלויבעניש ([LICENSE-MIT](LICENSE-MIT) אָדער http://opensource.org/licenses/MIT)

אין דיין אָפּציע.

### Contribution

סיידן איר עקספּרעסלי זאָגן אַנדערש, קיין צושטייער וואָס איז בעקאַבאָלעדיק דערלאנגט פֿאַר ינקלוזשאַן אין באַקקטראַסע-רס דורך איר, ווי דיפיינד אין די Apache-2.0 דערלויבעניש, וועט זיין צווייענדיק לייסאַנסט ווי אויבן אָן קיין נאָך טערמינען אָדער באדינגונגען.







