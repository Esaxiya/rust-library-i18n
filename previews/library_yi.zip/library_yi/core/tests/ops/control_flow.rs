use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // דאָס איז נישט סטאַביל ייבערפלאַך געגנט, אָבער העלפּס צו האַלטן `?` ביליק צווישן זיי, אפילו אויב LLVM קען נישט שטענדיק נוצן דאָס רעכט איצט.
    //
    // (סאַדלי רעזולטאַט און אָפּציע זענען סתירה, אַזוי ControlFlow קען נישט גלייַכן ביידע.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}