use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // מירי איז אויך פּאַמעלעך
fn exact_sanity_test() {
    // דער פּראָבע ענדס אַרויף וואָס איך קען נאָר יבערנעמען איז אַ ווינקל-יש פאַל פון די `exp2` ביבליאָטעק פונקציאָנירן, דיפיינד אין וועלכער C רונטימע מיר נוצן.
    // אין VS 2013, די פֿונקציע האט משמעות אַ זשוק ווייַל דעם פּראָבע פיילז ווען לינגקט, אָבער מיט ווס 2015 די זשוק איז פאַרפעסטיקט ווייַל די פּראָבע לויפט פּונקט פייַן.
    //
    // דער זשוק מיינט צו זיין אַ חילוק אין צוריקקומען ווערט פון קס 01 קס, ווו אין VS 2013 עס קערט אַ טאָפּל מיט די ביסל מוסטער קס 02 קס און אין ווס 2015 עס קערט קס 00 קס.
    //
    //
    // איצט, איגנאָרירן דעם פּראָבע לעגאַמרע אויף MSVC ווייַל עס איז סייַ ווי סייַ טעסטעד און מיר זענען נישט סופּער אינטערעסירט אין טעסטינג די exp2 ימפּלאַמענטיישאַן פון יעדער פּלאַטפאָרמע.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}