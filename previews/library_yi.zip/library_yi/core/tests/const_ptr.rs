// אַליינד צו צוויי ביטעס
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // זינט DATA.as_ptr() איז אַליינד צו צוויי ביטעס, אַדינג 1 בייט צו וואָס אַ אַנאַליינד * קאַנסט קס 00 קס
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// פן קס 01 קס {נוצן קס 00 קס;
//
//    קאָנסט פן קס 00 קס-> קס 01 קס {לאָזן מוט רעס=0;
//        אומזיכער {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        רעס} קאָנסט ALIGNED: קס 01 קס=קס 00 קס;
//    אַססערט_עק! (ALIGNED, 42);
//
//    const fn write_unaligned()-> [u16; 2] {let mut two_aligned=קס 00 קס;
//        אַנסייף {let unaligned_ptr= (two_aligned.as_mut_ptr() as *mut u8).add(1) as* mut u16;
//            פּטר: : שרייב_ונאַליינד (ונאַליגנעד_פּטר, קס 01 קס;} צוויי_אַליינד} קאָנסט ונאַליינעד: קס 02 קס=קס 00 קס;
//
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);}
//
//
//
//
//
//
//
//
//
//

// #[test]
// פן קס 00 קס {קאָנסט פן קס 01 קס-> קס 02 קס {לאָזן מוט רעס=0;
//        אַנסייף קס 03 קס רעס} קאָנסט אַליינד: קס 02 קס=קס 00 קס;
//
//    אַססערט_עק! (ALIGNED, 42);
//
//    const fn write_unaligned()-> [u16; 2] {let mut two_aligned=קס 00 קס;
//        אַנסייף {let unaligned_ptr= (two_aligned.as_mut_ptr() as *mut u8).add(1) as* mut u16;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        צוויי_אַליינד} קאָנסט UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);}
//
//
//
//
//
//
//
//
//
//
//