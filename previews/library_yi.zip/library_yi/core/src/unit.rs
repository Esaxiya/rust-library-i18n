use crate::iter::FromIterator;

/// קאַלאַפּס אַלע אַפּאַראַט זאכן פון אַ יטעראַטאָר אין איין.
///
/// דאָס איז מער נוצלעך ווען קאַמביינד מיט אַבסטראַקשאַנז אויף העכער מדרגה, ווי קאַלעקטינג צו אַ `Result<(), E>` ווו איר נאָר זאָרגן וועגן ערראָרס:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}