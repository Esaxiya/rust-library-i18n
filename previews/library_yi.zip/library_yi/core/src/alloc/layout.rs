use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// די פונקציע איז גענוצט אויף איין אָרט און די ימפּלאַמענטיישאַן קען זיין ינליינד, אָבער די פריערדיקע פרווון צו מאַכן זאָורסטק 0 ז סלאָוער:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// אויסלייג פון אַ בלאָק פון זכּרון.
///
/// אַ בייַשפּיל פון קס 00 קס דיסקרייבז אַ באַזונדער אויסלייג פון זכּרון.
/// איר בויען אַ `Layout` ווי אַן ינפּוט צו געבן צו אַ אַלאַקייטער.
///
/// אַלע לייאַוץ האָבן אַ פארבונדן גרייס און אַ מאַכט-פון-צוויי אַליינמאַנט.
///
/// (באַמערקונג אַז לייאַוץ זענען *ניט* פארלאנגט צו האָבן ניט-נול גרייס, כאָטש `GlobalAlloc` ריקווייערז אַז אַלע זיקאָרן ריקוועס זענען ניט-נול אין גרייס.
/// א קאָלער מוזן אָדער ענשור אַז די באדינגונגען ווי דעם זענען מקיים, נוצן ספּעציפיש אַלאַקייטערז מיט לוסער באדערפענישן, אָדער נוצן די מער ווייך `Allocator` צובינד.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // גרייס פון די פארלאנגט זיקאָרן בלאָק, געמאסטן אין ביטעס.
    size_: usize,

    // אַליינמאַנט פון די געבעטן בלאָק פון זכּרון, געמאסטן אין ביטעס.
    // מיר ענשור אַז דאָס איז שטענדיק אַ מאַכט-פון-צוויי, ווייַל API ס ווי קס 00 קס דאַרפן עס און עס איז אַ גלייַך קאַנסטריינט צו אָנטאָן אויף אויסלייג קאַנסטראַקטערז.
    //
    //
    // (אָבער, מיר טאָן ניט אַנאַלאַדזשאַסלי דאַרפן `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// בויען אַ קס 01 קס פון אַ געגעבן קס 02 קס און קס 00 קס, אָדער קערט קס 03 קס אויב קיין פון די ווייַטערדיקע באדינגונגען זענען נישט מקיים:
    ///
    /// * `align` טאר נישט זיין נול,
    ///
    /// * `align` מוזן זיין אַ מאַכט פון צוויי,
    ///
    /// * `size`, ווען ראַונדיד אַרויף צו די ניראַסט קייפל פון קס 00 קס, מוזן נישט לויפן (י.ע., די ראַונדיד ווערט מוזן זיין ווייניקער ווי אָדער גלייַך צו קס 01 קס).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (מאַכט-פון-צוויי ימפּלייז אַליינ!=0.)

        // די ראַונדיד גרייס איז:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // מיר וויסן פון אויבן אַז אַליינ!=0.
        // אויב אַדינג (אַליינ, 1) טוט נישט לויפן, די ראָונדינג אַרויף וועט זיין פייַן.
        //
        // קאָנווערסעלי,&-מאַסקינג מיט! (אַליין, 1) וועט אַראָפּרעכענען אַוועק בלויז נידעריק-סדר-ביטן.
        // אויב די לויפן איז אַקערז מיט די סומע, די&-מאַסק קענען נישט אַראָפּרעכענען גענוג צו ופמאַכן דעם לויפן.
        //
        //
        // אויבן ימפּלייז אַז קאָנטראָלירונג פֿאַר סוממאַטיאָן לויפן איז ביידע נייטיק און גענוג.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // זיכערקייט: די באדינגונגען פֿאַר קס 00 קס זענען געווען
        // אויבן אָפּגעשטעלט.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// קרעאַטעס אַ אויסלייג, בייפּאַסינג אַלע טשעקס.
    ///
    /// # Safety
    ///
    /// די פֿונקציע איז אַנסייף ווייַל עס קען נישט באַשטעטיקן די פּריקאַנדישאַנז פון [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // זיכערקייט: די קאַללער מוזן ענשור אַז `align` איז גרעסער ווי נול.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// די מינימום גרייס אין ביטעס פֿאַר אַ זיקאָרן בלאָק פון דעם אויסלייג.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// די מינימום בייט אַליינמאַנט פֿאַר אַ זיקאָרן בלאָק פון דעם אויסלייג.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// קאָנסטרוקץ אַ קס 01 קס פּאַסיק פֿאַר אַ ווערט פון טיפּ קס 00 קס.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // זיכערקייט: די זשורוסט איז געראַנטיד צו זיין אַ מאַכט פון צוויי און
        // די גרייס + אַליין קאָמבאָ איז געראַנטיד צו פּאַסיק אין אונדזער אַדרעס פּלאַץ.
        // צוליב דעם, נוצן די ונקעקקעד קאַנסטראַקטער דאָ צו ויסמייַדן ינסערטינג קאָד panics אויב עס איז נישט אָפּטימיזעד גענוג גענוג.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// טראגט אויסלייג דיסקרייבינג אַ רעקאָרד וואָס קען זיין געניצט צו אַלאַקייט באַקינג סטרוקטור פֿאַר קס 00 קס (וואָס קען זיין אַ ז 0 טראַט 0 ז אָדער אנדערע אַנסייזד טיפּ ווי אַ רעפטל).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // זיכערקייט: זען סייכל אין `new` פֿאַר וואָס דאָס איז ניצן די אַנסייף וואַריאַנט
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// טראגט אויסלייג דיסקרייבינג אַ רעקאָרד וואָס קען זיין געניצט צו אַלאַקייט באַקינג סטרוקטור פֿאַר קס 00 קס (וואָס קען זיין אַ ז 0 טראַט 0 ז אָדער אנדערע אַנסייזד טיפּ ווי אַ רעפטל).
    ///
    /// # Safety
    ///
    /// די פֿונקציע איז בלויז זיכער צו רופן אויב די ווייַטערדיקע באדינגונגען זענען:
    ///
    /// - אויב קס 01 קס איז קס 00 קס, די פונקציע איז שטענדיק זיכער צו רופן.
    /// - אויב די אַנסייזד עק פון `T` איז:
    ///     - אין אַ [slice], די לענג פון די רעפטל עק זאָל זיין אַן ינטיאַליזעד ינטאַדזשער, און די גרייס פון די *גאַנץ ווערט*(דינאַמיש עק לענג + סטאַטיקלי סייזד פּרעפיקס) מוזן פּאַסיק אין `isize`.
    ///     - אַ [trait object], די VTable טייל פון די טייַטל מוזן אָנווייַזן צו אַ גילטיק VTABEL פֿאַר די טיפּ `T` קונה דורך אַן אַנסייזינג קאָוערסיאָן, און די גרייס פון די *גאַנץ ווערט*(דינאַמיש עק לענג + סטאַטיקלי סייזד פּרעפיקס) מוזן פּאַסיק אין `isize`.
    ///
    ///     - אַ (unstable) [extern type], די פונקציע איז שטענדיק זיכער צו רופן, אָבער קען panic אָדער אַנדערש צוריקקומען די אומרעכט ווערט, ווייַל די ויסווייניקסט טיפּ פון דעם טיפּ איז נישט באַוווסט.
    ///     דאָס איז דער זעלביקער נאַטור ווי [`Layout::for_value`] אויף אַ דערמאָנען צו אַן עקסטערן עק.
    ///     - אַנדערש, עס איז קאָנסערוואַטיוולי ניט דערלויבט צו רופן דעם פֿונקציע.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // זיכערקייט: מיר פאָרן די פּרירעקוואַזאַץ פון די פאַנגקשאַנז צו די קאָלער
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // זיכערקייט: זען סייכל אין `new` פֿאַר וואָס דאָס איז ניצן די אַנסייף וואַריאַנט
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// קרעאַטעס אַ `NonNull` וואָס איז דאַנגגלינג, אָבער געזונט אַליינד פֿאַר דעם אויסלייג.
    ///
    /// באַמערקונג אַז די טייַטל ווערט קען פּאַטענטשאַלי רעפּראַזענץ אַ גילטיק טייַטל, וואָס מיטל אַז דאָס דאַרף ניט זיין געוויינט ווי אַ "not yet initialized" סענטינעל ווערט.
    /// טייפּס אַז פויל אַלאַקייט מוזן שפּור יניטיאַליזאַטיאָן דורך עטלעכע אנדערע מיטלען.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // זיכערקייט: אַליינ איז געראַנטיד צו זיין ניט-נול
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// קרעאַטעס אַ אויסלייג דיסקרייבינג די רעקאָרד וואָס קענען האָבן אַ ווערט פון דער זעלביקער אויסלייג ווי קס 00 קס, אָבער אַז איז אויך אַליינד צו אַליינמאַנט קס 01 קס (געמאסטן אין ביטעס).
    ///
    ///
    /// אויב קס 01 קס שוין טרעפן די פּריסקרייבד אַליינמאַנט, קערט קס 00 קס.
    ///
    /// באַמערקונג אַז דעם אופֿן טוט נישט לייגן קיין וואַטן צו די קוילעלדיק גרייס, ראַגאַרדלאַס פון צי די אומגעקערט אויסלייג האט אַ אַנדערש אַליינמאַנט.
    /// אין אנדערע ווערטער, אויב `K` האט גרייס 16, `K.align_to(32)` וועט *נאָך* האָבן גרייס 16.
    ///
    /// קערט אַ טעות אויב די קאָמבינאַציע פון קס 01 קס און די געגעבן קס 02 קס ווייאַלייץ די באדינגונגען ליסטעד אין קס 00 קס.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// קערט די נומער פון וואַטן וואָס מיר מוזן אַרייַנלייגן נאָך `self` צו ענשור אַז די ווייַטערדיק אַדרעס וועט באַפרידיקן `align` (געמאסטן אין ביטעס).
    ///
    /// למשל, אויב `self.size()` איז 9, `self.padding_needed_for(4)` קערט צוריק 3, ווייַל דאָס איז די מינימום נומער פון ביטן פון וואַטן וואָס איז פארלאנגט צו באַקומען אַ 4-אַליינד אַדרעס (אַסומינג אַז די קאָראַספּאַנדינג זיקאָרן בלאָק סטאַרץ ביי אַ 4-אַליינד אַדרעס).
    ///
    ///
    /// דער צוריקקער ווערט פון דעם פֿונקציע האט קיין טייַטש אויב `align` איז נישט אַ מאַכט-פון-צוויי.
    ///
    /// באַמערקונג אַז די נוצן פון די אומגעקערט ווערט ריקווייערז `align` צו זיין ווייניקער ווי אָדער גלייַך צו די אַליינמאַנט פון די סטאַרטינג אַדרעס פֿאַר די גאנצע אַלאַקייטיד זיקאָרן בלאָק.איין וועג צו באַפרידיקן דעם באַגרענעצונג איז צו ענשור `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // ראַונדיד אַרויף ווערט איז:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // און דעמאָלט מיר צוריקקומען די וואַטן דיפעראַנס: `len_rounded_up - len`.
        //
        // מיר נוצן מאַדזשאַלער אַריטמעטיק איבער:
        //
        // 1. align איז געראַנטיד צו זיין> 0, אַזוי align, 1 איז שטענדיק גילטיק.
        //
        // 2.
        // `len + align - 1` קענען ביי רובֿ ווי X00 קס, אַזוי די&-מאַסק מיט קס 02 קס וועט ענשור אַז אין דעם פאַל פון לויפן, קס 01 קס זיך איז 0.
        //
        //    דער צוריקקער וואַטן, ווען מוסיף צו קס 01 קס, ייעלדס 0, וואָס טריוויאַללי סאַטיספייז די אַליינמאַנט קס 00 קס.
        //
        // (דאָך, פרווון צו אַלאַקייט בלאַקס פון זכּרון וועמענס גרייס און וואַטן לויפן אויף די אויבן שטייגער זאָל אָנמאַכן די אַלאַקייטער צו געבן אַ טעות סייַ ווי סייַ.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// קרעאַטעס אַ אויסלייג דורך ראַונדינג די גרייס פון דעם אויסלייג צו אַ קייפל פון די אַליינמאַנט פון דעם אויסלייג.
    ///
    ///
    /// דאָס איז עקוויוואַלענט צו לייגן דעם רעזולטאַט פון `padding_needed_for` צו די קראַנט גרייס פון דעם אויסלייג.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // דאָס קען נישט לויפן.ציטירן פון די ינוועריאַנט פון אויסלייג:
        // > `size`, ווען ראַונדיד אַרויף צו די ניראַסט קייפל פון קס 00 קס,
        // > מוזן נישט לויפן (י.ע., די ראַונדיד ווערט מוזן זיין ווייניקער ווי
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// קרעאַטעס אַ אויסלייג דיסקרייבינג די רעקאָרד פֿאַר קס 01 קס ינסטאַנסיז פון קס 00 קס, מיט אַ פּאַסיק סומע פון וואַטן צווישן יעדער צו ענשור אַז יעדער בייַשפּיל איז געגעבן זייַן געבעטן גרייס און אַליינמאַנט.
    /// אויף הצלחה, קערט `(k, offs)` ווו `k` איז די אויסלייג פון די מענגע און `offs` איז די ווייַטקייט צווישן די אָנהייב פון יעדער עלעמענט אין די מענגע.
    ///
    /// אויף אַריטמעטיק לויפן, קערט `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // דאָס קען נישט לויפן.ציטירן פון די ינוועריאַנט פון אויסלייג:
        // > `size`, ווען ראַונדיד אַרויף צו די ניראַסט קייפל פון קס 00 קס,
        // > מוזן נישט לויפן (י.ע., די ראַונדיד ווערט מוזן זיין ווייניקער ווי
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // זיכערהייט: self.align איז שוין באַוווסט גילטיק און alloc_size איז געווען
        // פּאַדיד שוין.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// קרעאַטעס אַ אויסלייג דיסקרייבינג די רעקאָרד פֿאַר קס 01 קס נאכגעגאנגען דורך קס 00 קס, אַרייַנגערעכנט קיין נויטיק וואַטן צו ענשור אַז קס 02 קס וועט זיין רעכט אַליינד, אָבער *קיין טריילינג וואַטן*.
    ///
    /// כּדי צופּאַסן די C פאַרטרעטונג אויסלייג קס 00 קס, איר זאָל רופן קס 01 קס נאָך יקסטענדינג די אויסלייג מיט אַלע פעלדער.
    /// (עס איז קיין וועג צו גלייַכן דעם פעליקייַט ז 0 רוסט 0 ז פאַרטרעטונג אויסלייג קס 00 קס
    ///
    /// באַמערקונג אַז די אַליינמאַנט פון די ריזאַלטינג אויסלייג וועט זיין די מאַקסימום פון די `self` און `next`, צו ענשור אַליינמאַנט פון ביידע פּאַרץ.
    ///
    /// קערט `Ok((k, offset))`, ווו `k` איז אויסלייג פון די קאַנקאַטאַנייטיד רעקאָרד און `Ok((k, offset))` איז די קאָרעוו אָרט, אין ביטעס, פון די אָנהייב פון די `next` עמבעדיד אין די קאַנקאַטאַנייטיד רעקאָרד (אַסומינג אַז די רעקאָרד זיך סטאַרץ ביי פאָטאָ 0).
    ///
    ///
    /// אויף אַריטמעטיק לויפן, קערט `LayoutError`.
    ///
    /// # Examples
    ///
    /// צו רעכענען די אויסלייג פון אַ `#[repr(C)]` סטרוקטור און די אָפסעץ פון די פעלדער פֿון די פעלדער 'לייאַוץ:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // געדענקט צו ענדיקן מיט `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // פּרובירן אַז עס אַרבעט
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// קרעאַטעס אַ אויסלייג דיסקרייבינג די רעקאָרד פֿאַר קס 01 קס ינסטאַנסיז פון קס 00 קס, אָן קיין וואַטן צווישן יעדער בייַשפּיל.
    ///
    /// באַמערקונג אַז, ניט ענלעך `repeat`, `repeat_packed` קען נישט גאַראַנטירן אַז די ריפּיטיד ינסטאַנסיז פון `self` וועט זיין רעכט אַליינד, אפילו אויב אַ געוויזן בייַשפּיל פון `self` איז רעכט אַליינד.
    /// אין אנדערע ווערטער, אויב די `repeat_packed` אויסלייג איז געניצט צו אַלאַקייט אַ מענגע, עס איז נישט געראַנטיד אַז אַלע עלעמענטן אין די מענגע וועט זיין רעכט אַליינד.
    ///
    /// אויף אַריטמעטיק לויפן, קערט `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// קרעאַטעס אַ אויסלייג דיסקרייבינג די רעקאָרד פֿאַר קס 00 קס נאכגעגאנגען דורך קס 01 קס אָן נאָך וואַטן צווישן די צוויי.
    /// זינט קיין וואַטן איז ינסערטאַד, די אַליינמאַנט פון קס 00 קס איז ירעלאַוואַנט, און איז נישט ינקאָרפּערייטיד * אין די ריזאַלטינג אויסלייג.
    ///
    ///
    /// אויף אַריטמעטיק לויפן, קערט `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// קרעאַטעס אַ אויסלייג דיסקרייבינג די רעקאָרד פֿאַר אַ קס 00 קס.
    ///
    /// אויף אַריטמעטיק לויפן, קערט `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// די פּאַראַמעטערס צו קס 00 קס אָדער אנדערע קס 01 קס קאַנסטראַקטער טאָן ניט באַפרידיקן די דאַקיאַמענטאַד קאַנסטריינץ.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (מיר דאַרפֿן דאָס פֿאַר דאַונסטרים ימפּלאַמענטיישאַן פון trait טעות)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}