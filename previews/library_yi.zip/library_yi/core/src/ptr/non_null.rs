use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` אָבער ניט-נול און קאָוואַריאַנט.
///
/// דאָס איז אָפט די ריכטיק זאַך צו נוצן ווען איר בויען דאַטן סטראַקטשערז מיט רוי פּוינטערז, אָבער עס איז לעסאָף מער געפערלעך צו נוצן ווייַל פון די נאָך פּראָפּערטיעס.אויב איר ניטאָ ניט זיכער צי איר זאָל נוצן `NonNull<T>`, נאָר נוצן `*mut T`!
///
/// ניט ענלעך קס 01 קס, דער טייַטל דאַרף שטענדיק זיין ניט-נאַל, אפילו אויב דער טייַטל איז קיינמאָל דערפעראַנסט.דאָס איז אַזוי אַז ענומס קענען נוצן דעם פאַרבאָטן ווערט ווי אַ דיסקרימינאַנט-קס 02 קס האט די זעלבע גרייס ווי קס 00 קס.
/// די טייַטל קען נאָך באָמבלען אויב עס איז נישט דערפעראַנסט.
///
/// ניט ענלעך `*mut T`, `NonNull<T>` איז געווען אויסדערוויילט צו זיין קאָוואַריאַנט איבער `T`.דאָס מאכט עס מעגלעך צו נוצן קס 03 קס ווען איר בויען קאָוואַריאַנט טייפּס, אָבער ינטראַדוסיז די ריזיקירן פון ונסאָונדנעסס אויב געוויינט אין אַ טיפּ וואָס זאָל ניט אַקשלי זיין קאָוואַריאַנט.
/// (די פאַרקערט ברירה איז געווען געמאכט פֿאַר `*mut T`, כאָטש די ונסאָונדנעסס טעקניקלי קען נאָר זיין געפֿירט דורך רופן אַנסייף פאַנגקשאַנז.)
///
/// קאָוואַריאַנסע איז ריכטיק פֿאַר רובֿ זיכער אַבסטראַקשאַנז, אַזאַ ווי קס 00 קס, קס 01 קס, קס 02 קס, קס 03 קס, און קס 04 קס.דאָס איז דער פאַל ווייַל זיי צושטעלן אַ עפנטלעך אַפּי אַז גייט די נאָרמאַל שערד XOR מיוטאַבאַל כּללים פון Rust.
///
/// אויב דיין טיפּ קען נישט זיין בעשאָלעם קאָוואַריאַנט, איר מוזן ענשור אַז עס כּולל עטלעכע נאָך פעלד צו צושטעלן ינוועריאַנס.אָפט דעם פעלד וועט זיין אַ טיפּ [`PhantomData`] ווי `PhantomData<Cell<T>>` אָדער `PhantomData<&'a mut T>`.
///
/// נאָטיץ אַז קס 02 קס האט אַ קס 03 קס בייַשפּיל פֿאַר קס 00 קס.אָבער, דאָס קען נישט טוישן דעם פאַקט אַז מיוטינג דורך אַ (טייַטל דערייווד פון אַ) שערד רעפֿערענץ איז אַנדיפיינד די נאַטור סייַדן די מיוטיישאַן כאַפּאַנז ין אַ קס 01 קס.דער זעלביקער גייט פֿאַר קריייטינג אַ מיוטאַבאַל רעפֿערענץ פֿון אַ שערד רעפֿערענץ.
///
/// ווען איר נוצן דעם `From` בייַשפּיל אָן אַ `UnsafeCell<T>`, עס איז דיין פֿאַראַנטוואָרטלעכקייט צו ענשור אַז `as_mut` איז קיינמאָל גערופן, און `as_ptr` איז קיינמאָל געניצט פֿאַר מיוטיישאַן.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` פּוינטערז זענען נישט קס 00 קס ווייַל די דאַטן וואָס זיי דערמאָנען קען זיין אַליאַסעד.
// נ.ב., דעם ימפּ איז ומנייטיק, אָבער זאָל צושטעלן בעסער טעות אַרטיקלען.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` פּוינטערז זענען נישט קס 00 קס ווייַל די דאַטן וואָס זיי דערמאָנען קען זיין אַליאַסעד.
// נ.ב., דעם ימפּ איז ומנייטיק, אָבער זאָל צושטעלן בעסער טעות אַרטיקלען.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// קריייץ אַ נייַ `NonNull` וואָס איז דאַנגגלינג, אָבער געזונט אַליינד.
    ///
    /// דאָס איז נוציק פֿאַר יניטיאַליזינג טייפּס וואָס פויל אַלאַקייט, ווי `Vec::new`.
    ///
    /// באַמערקונג אַז דער טייַטל ווערט קען פּאַטענטשאַלי רעפּראַזענץ אַ גילטיק טייַטל צו אַ `T`, וואָס מיטל אַז דאָס דאַרף ניט זיין געוויינט ווי אַ "not yet initialized" סענטינעל ווערט.
    /// טייפּס אַז פויל אַלאַקייט מוזן שפּור יניטיאַליזאַטיאָן דורך עטלעכע אנדערע מיטלען.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // זיכערקייט: קס 00 קס קערט אַ ניט-נול נוצן וואָס איז קאַסטיד
        // צו א * מוט טי.
        // דעריבער, `ptr` איז ניט נאַל און די באדינגונגען פֿאַר רופן new_unchecked() זענען רעספּעקטעד.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// קערט אַ שערד באַווייַזן צו די ווערט.אין קאַנטראַסט צו [`as_ref`], דאָס דאַרף נישט זיין ינישאַלייזד.
    ///
    /// פֿאַר די מיוטאַבאַל אַנטקעגענער, קס 00 קס.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אופֿן, איר דאַרפֿן צו ענשור אַז אַלע פון די פאלגענדע איז אמת:
    ///
    /// * דער טייַטל זאָל זיין רעכט אַליינד.
    ///
    /// * עס מוזן זיין קס 01 קס אין דעם זינען דיפיינד אין קס 00 קס.
    ///
    /// * איר מוזן דורכפירן די אַליאַסינג כּללים פון Rust, ווייַל די אומגעקערט לעבן `'a` איז אַרביטרעראַלי אויסדערוויילט און טוט נישט דאַווקע פאַרטראַכטן די פאַקטיש לעבן פון די דאַטן.
    ///
    ///   אין באַזונדער, די געדויער פון דעם לעבן קען נישט זיין מיוטייטיד פֿאַר די געדויער פון דעם לעבן (אַחוץ ין `UnsafeCell`).
    ///
    /// דאָס אַפּלייז אפילו אויב דער רעזולטאַט פון דעם אופֿן איז אַניוזד!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // זיכערהייט: די קאַללער מוזן גאַראַנטירן אַז `self` טרעפן אַלע די
        // באדערפענישן פֿאַר אַ רעפֿערענץ.
        unsafe { &*self.cast().as_ptr() }
    }

    /// קערט אַ יינציק באַווייַזן צו די ווערט.אין קאַנטראַסט צו [`as_mut`], דאָס דאַרף נישט זיין ינישאַלייזד.
    ///
    /// פֿאַר די שערד אַנטקעגענער זען קס 00 קס.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אופֿן, איר דאַרפֿן צו ענשור אַז אַלע פון די פאלגענדע איז אמת:
    ///
    /// * דער טייַטל זאָל זיין רעכט אַליינד.
    ///
    /// * עס מוזן זיין קס 01 קס אין דעם זינען דיפיינד אין קס 00 קס.
    ///
    /// * איר מוזן דורכפירן די אַליאַסינג כּללים פון Rust, ווייַל די אומגעקערט לעבן `'a` איז אַרביטרעראַלי אויסדערוויילט און טוט נישט דאַווקע פאַרטראַכטן די פאַקטיש לעבן פון די דאַטן.
    ///
    ///   אין באַזונדער, פֿאַר די געדויער פון דעם לעבן, דער זכּרון צו וואָס דער טייַטל ווייזט אויף זאָל ניט זיין אַקסעסט (לייענען אָדער געשריבן) דורך קיין אנדערע טייַטל.
    ///
    /// דאָס אַפּלייז אפילו אויב דער רעזולטאַט פון דעם אופֿן איז אַניוזד!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // זיכערהייט: די קאַללער מוזן גאַראַנטירן אַז `self` טרעפן אַלע די
        // באדערפענישן פֿאַר אַ רעפֿערענץ.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// קרעאַטעס אַ נייַ קס 00 קס.
    ///
    /// # Safety
    ///
    /// `ptr` מוזן זיין ניט-נאַל.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `ptr` איז ניט-נאַל.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// קרעאַטעס אַ נייַ קס 00 קס אויב קס 01 קס איז ניט-נאַל.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // זיכערקייט: דער טייַטל איז שוין אָפּגעשטעלט און איז ניט נאַל
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// פּערפאָרמז די זעלבע פאַנגקשאַנאַליטי ווי קס 00 קס, אַחוץ אַז אַ קס 01 קס טייַטל איז אומגעקערט, ווי קעגן צו אַ רוי קס 02 קס טייַטל.
    ///
    ///
    /// זען די דאָקומענטאַטיאָן פון [`std::ptr::from_raw_parts`] פֿאַר מער דעטאַילס.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // זיכערקייט: דער רעזולטאַט פון קס 00 קס איז ניט-נאַל ווייַל קס 01 קס איז.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// צעלייגנ אַ (עפשער ברייט) טייַטל אין איז אַדרעס און מעטאַדאַטאַ קאַמפּאָונאַנץ.
    ///
    /// דער טייַטל קענען זיין שפּעטער ריקאַנסטראַקטיד מיט [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// קונה די אַנדערלייינג קס 00 קס טייַטל.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// רעטורנס אַ שערד דערמאָנען צו די ווערט.אויב די ווערט קען זיין אַנינישיייטיד, [`as_uninit_ref`] מוזן זיין אַנשטאָט.
    ///
    /// פֿאַר די מיוטאַבאַל אַנטקעגענער, קס 00 קס.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אופֿן, איר דאַרפֿן צו ענשור אַז אַלע פון די פאלגענדע איז אמת:
    ///
    /// * דער טייַטל זאָל זיין רעכט אַליינד.
    ///
    /// * עס מוזן זיין קס 01 קס אין דעם זינען דיפיינד אין קס 00 קס.
    ///
    /// * דער טייַטל מוזן ווייַזן צו אַן ינישיייטיד בייַשפּיל פון קס 00 קס.
    ///
    /// * איר מוזן דורכפירן די אַליאַסינג כּללים פון Rust, ווייַל די אומגעקערט לעבן `'a` איז אַרביטרעראַלי אויסדערוויילט און טוט נישט דאַווקע פאַרטראַכטן די פאַקטיש לעבן פון די דאַטן.
    ///
    ///   אין באַזונדער, די געדויער פון דעם לעבן קען נישט זיין מיוטייטיד פֿאַר די געדויער פון דעם לעבן (אַחוץ ין `UnsafeCell`).
    ///
    /// דאָס אַפּלייז אפילו אויב דער רעזולטאַט פון דעם אופֿן איז אַניוזד!
    /// (דער טייל וועגן ינישאַלייזד איז נאָך נישט גאָר באַשלאָסן, אָבער ביז איצט, דער בלויז זיכער צוגאַנג איז צו ענשור אַז זיי זענען טאַקע ינישאַלייזד.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // זיכערהייט: די קאַללער מוזן גאַראַנטירן אַז `self` טרעפן אַלע די
        // באדערפענישן פֿאַר אַ רעפֿערענץ.
        unsafe { &*self.as_ptr() }
    }

    /// קערט אַ יינציק דערמאָנען צו די ווערט.אויב די ווערט קען זיין אַנינישיייטיד, [`as_uninit_mut`] מוזן זיין אַנשטאָט.
    ///
    /// פֿאַר די שערד אַנטקעגענער זען קס 00 קס.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אופֿן, איר דאַרפֿן צו ענשור אַז אַלע פון די פאלגענדע איז אמת:
    ///
    /// * דער טייַטל זאָל זיין רעכט אַליינד.
    ///
    /// * עס מוזן זיין קס 01 קס אין דעם זינען דיפיינד אין קס 00 קס.
    ///
    /// * דער טייַטל מוזן ווייַזן צו אַן ינישיייטיד בייַשפּיל פון קס 00 קס.
    ///
    /// * איר מוזן דורכפירן די אַליאַסינג כּללים פון Rust, ווייַל די אומגעקערט לעבן `'a` איז אַרביטרעראַלי אויסדערוויילט און טוט נישט דאַווקע פאַרטראַכטן די פאַקטיש לעבן פון די דאַטן.
    ///
    ///   אין באַזונדער, פֿאַר די געדויער פון דעם לעבן, דער זכּרון צו וואָס דער טייַטל ווייזט אויף זאָל ניט זיין אַקסעסט (לייענען אָדער געשריבן) דורך קיין אנדערע טייַטל.
    ///
    /// דאָס אַפּלייז אפילו אויב דער רעזולטאַט פון דעם אופֿן איז אַניוזד!
    /// (דער טייל וועגן ינישאַלייזד איז נאָך נישט גאָר באַשלאָסן, אָבער ביז איצט, דער בלויז זיכער צוגאַנג איז צו ענשור אַז זיי זענען טאַקע ינישאַלייזד.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // זיכערהייט: די קאַללער מוזן גאַראַנטירן אַז `self` טרעפן אַלע די
        // באדערפענישן פֿאַר אַ מיוטאַבאַל דערמאָנען.
        unsafe { &mut *self.as_ptr() }
    }

    /// קאַסץ צו אַ טייַטל פון אן אנדער טיפּ.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // זיכערקייט: קס 00 קס איז אַ קס 01 קס טייַטל וואָס איז דאַווקע ניט-נאַל
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// קרעאַטעס אַ ניט-נאַל רוי רעפטל פֿון אַ דין טייַטל און אַ לענג.
    ///
    /// די `len` אַרגומענט איז די נומער פון **עלעמענטן**, נישט די נומער פון ביטעס.
    ///
    /// די פֿונקציע איז זיכער, אָבער דערפערענסינג די צוריקקער ווערט איז אַנסייף.
    /// זען די דאַקיומענטיישאַן פון קס 00 קס פֿאַר פּעקל זיכערקייַט רעקווירעמענץ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // שאַפֿן אַ רעפטל טייַטל ווען איר אָנהייבן מיט אַ טייַטל צו דער ערשטער עלעמענט
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (באַמערקונג אַז דעם בייַשפּיל אַרטיפיסיאַללי דעמאַנסטרייץ די נוצן פון דעם אופֿן, אָבער `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // זיכערקייט: קס 00 קס איז אַ קס 01 קס טייַטל וואָס איז דאַווקע ניט-נאַל
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// רעטורנס די לענג פון אַ ניט-נול רוי רעפטל.
    ///
    /// די אומגעקערט ווערט איז די נומער פון **עלעמענטן**, נישט די נומער פון ביטעס.
    ///
    /// די פֿונקציע איז זיכער, אפילו ווען די ניט-נול רוי רעפטל קענען ניט זיין דערפעראַנסט צו אַ רעפטל ווייַל דער טייַטל האט נישט אַ גילטיק אַדרעס.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// קערט אַ ניט-נול טייַטל צו די באַפער פון די רעפטל.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // זיכערקייט: מיר וויסן `self` איז ניט-נאַל.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// קערט אַ רוי טייַטל צו די באַפער פון די רעפטל.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// רעטורנס אַ שערד דערמאָנען צו אַ רעפטל פון עפשער אַניניטיאַליזעד וואַלועס.אין קאַנטראַסט צו [`as_ref`], דאָס דאַרף נישט זיין ינישאַלייזד.
    ///
    /// פֿאַר די מיוטאַבאַל אַנטקעגענער, קס 00 קס.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אופֿן, איר דאַרפֿן צו ענשור אַז אַלע פון די פאלגענדע איז אמת:
    ///
    /// * דער טייַטל מוזן זיין קס 00 קס פֿאַר רידערז פֿאַר קס 01 קס פילע ביטעס, און עס מוזן זיין רעכט אַליינד.דעם מיטל אין באַזונדער:
    ///
    ///     * די גאנצע זיקאָרן קייט פון דעם רעפטל מוזן זיין קאַנטיינד אין אַ איין אַלאַקייטיד כייפעץ!
    ///       סלייסאַז קענען קיינמאָל שפּאַן איבער קייפל אַלאַקייטיד אַבדזשעקץ.
    ///
    ///     * דער טייַטל מוזן זיין אַליינד אפילו פֿאַר נול-לענג סלייסיז.
    ///     איין סיבה פֿאַר דעם איז אַז אָפּטימיזאַטיאָנס פון ענאַם אויסלייג קען פאַרלאָזנ זיך אַז באַווייַזן (אַרייַנגערעכנט סלייסיז פון קיין לענג) זענען אַליינד און ניט-נול צו ויסטיילן זיי פון אנדערע דאַטן.
    ///
    ///     איר קענען קריגן אַ טייַטל וואָס איז ניצט ווי קס 01 קס פֿאַר נול-לענג סלייסאַז ניצן קס 00 קס.
    ///
    /// * די גאַנץ גרייס `ptr.len() * mem::size_of::<T>()` פון די רעפטל דאַרף נישט זיין גרעסער ווי `isize::MAX`.
    ///   זען די זיכערקייַט דאַקיומענטיישאַן פון קס 00 קס.
    ///
    /// * איר מוזן דורכפירן די אַליאַסינג כּללים פון Rust, ווייַל די אומגעקערט לעבן `'a` איז אַרביטרעראַלי אויסדערוויילט און טוט נישט דאַווקע פאַרטראַכטן די פאַקטיש לעבן פון די דאַטן.
    ///   אין באַזונדער, די געדויער פון דעם לעבן קען נישט זיין מיוטייטיד פֿאַר די געדויער פון דעם לעבן (אַחוץ ין `UnsafeCell`).
    ///
    /// דאָס אַפּלייז אפילו אויב דער רעזולטאַט פון דעם אופֿן איז אַניוזד!
    ///
    /// זען אויך [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// רעטורנס אַ יינציק דערמאָנען צו אַ רעפטל פון עפשער אַניניטיאַליזעד וואַלועס.אין קאַנטראַסט צו [`as_mut`], דאָס דאַרף נישט זיין ינישאַלייזד.
    ///
    /// פֿאַר די שערד אַנטקעגענער זען קס 00 קס.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אופֿן, איר דאַרפֿן צו ענשור אַז אַלע פון די פאלגענדע איז אמת:
    ///
    /// * דער טייַטל מוזן זיין [valid] פֿאַר פילע ביטעס צו לייענען און שרייבן פֿאַר [valid], און עס מוזן זיין רעכט אַליינד.דעם מיטל אין באַזונדער:
    ///
    ///     * די גאנצע זיקאָרן קייט פון דעם רעפטל מוזן זיין קאַנטיינד אין אַ איין אַלאַקייטיד כייפעץ!
    ///       סלייסאַז קענען קיינמאָל שפּאַן איבער קייפל אַלאַקייטיד אַבדזשעקץ.
    ///
    ///     * דער טייַטל מוזן זיין אַליינד אפילו פֿאַר נול-לענג סלייסיז.
    ///     איין סיבה פֿאַר דעם איז אַז אָפּטימיזאַטיאָנס פון ענאַם אויסלייג קען פאַרלאָזנ זיך אַז באַווייַזן (אַרייַנגערעכנט סלייסיז פון קיין לענג) זענען אַליינד און ניט-נול צו ויסטיילן זיי פון אנדערע דאַטן.
    ///
    ///     איר קענען קריגן אַ טייַטל וואָס איז ניצט ווי קס 01 קס פֿאַר נול-לענג סלייסאַז ניצן קס 00 קס.
    ///
    /// * די גאַנץ גרייס `ptr.len() * mem::size_of::<T>()` פון די רעפטל דאַרף נישט זיין גרעסער ווי `isize::MAX`.
    ///   זען די זיכערקייַט דאַקיומענטיישאַן פון קס 00 קס.
    ///
    /// * איר מוזן דורכפירן די אַליאַסינג כּללים פון Rust, ווייַל די אומגעקערט לעבן `'a` איז אַרביטרעראַלי אויסדערוויילט און טוט נישט דאַווקע פאַרטראַכטן די פאַקטיש לעבן פון די דאַטן.
    ///   אין באַזונדער, פֿאַר די געדויער פון דעם לעבן, דער זכּרון צו וואָס דער טייַטל ווייזט אויף זאָל ניט זיין אַקסעסט (לייענען אָדער געשריבן) דורך קיין אנדערע טייַטל.
    ///
    /// דאָס אַפּלייז אפילו אויב דער רעזולטאַט פון דעם אופֿן איז אַניוזד!
    ///
    /// זען אויך [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // דאָס איז זיכער ווייַל `memory` איז גילטיק פֿאַר רידערז און שרייבט פֿאַר קס 01 קס פילע ביטעס.
    /// // באַמערקונג אַז פאַך `memory.as_mut()` איז נישט ערלויבט דאָ ווייַל די אינהאַלט קען זיין אַנינישיייטיד.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// קערט אַ רוי טייַטל צו אַן עלעמענט אָדער סובסליסע, אָן דורכקוקן גווול.
    ///
    /// רופן דעם אופֿן מיט אַן אויס-פון-גווול אינדעקס אָדער ווען `self` איז נישט דערפערענסאַבלע איז *[אַנדיפיינד נאַטור]* אפילו אויב די ריזאַלטינג טייַטל איז נישט געניצט.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // זיכערהייט: די קאַללער ינשורז אַז קס 00 קס איז דערפערענסאַבלע און קס 01 קס אין-גווול.
        // דעריבער, דער ריזאַלטינג טייַטל קען נישט זיין NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // זיכערקייט: א יינציק טייַטל קען נישט זיין נאַל, אַזוי די באדינגונגען פֿאַר
        // new_unchecked() זענען רעספּעקטעד.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // זיכערקייט: א מיוטאַבאַל רעפֿערענץ קען נישט זיין נאַל.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // זיכערקייט: א רעפֿערענץ קען נישט זיין נאַל, אַזוי די באדינגונגען פֿאַר
        // new_unchecked() זענען רעספּעקטעד.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}