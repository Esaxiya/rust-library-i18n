use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// א ראַפּער אַרום אַ רוי ניט-נאַל `*mut T` וואָס ינדיקייץ אַז די באַזיצער פון דעם ראַפּער אָונז דער רעפערענט.
/// נוציק פֿאַר בנין אַבסטראַקשאַנז ווי קס 01 קס, קס 02 קס, קס 03 קס און קס 00 קס.
///
/// ניט ענלעך קס 01 קס, קס 02 קס ביכייווז קס 03 קס עס איז געווען אַ בייַשפּיל פון קס 00 קס.
/// עס ימפּלאַמאַנץ קס 01 קס אויב קס 02 קס איז קס 00 קס.
/// עס אויך ימפּלייז די סאָרט פון שטאַרק אַליאַסינג געראַנטיז אַז `T` קען זיין געריכט:
/// דער רעפערענט פון דער טייַטל זאָל ניט זיין מאַדאַפייד אָן אַ יינציק דרך צו זיין יינציק.
///
/// אויב איר ניטאָ זיכער אויב עס איז ריכטיק צו נוצן `Unique` פֿאַר דיין צוועקן, באַטראַכטן ניצן `NonNull`, וואָס האט שוואַך סעמאַנטיקס.
///
///
/// ניט ענלעך קס 00 קס, דער טייַטל דאַרף שטענדיק זיין ניט-נאַל, אפילו אויב דער טייַטל איז קיינמאָל דערפעראַנסט.
/// דאָס איז אַזוי אַז ענומס קענען נוצן דעם פאַרבאָטן ווערט ווי אַ דיסקרימינאַנט-קס 01 קס האט די זעלבע גרייס ווי קס 00 קס.
/// די טייַטל קען נאָך באָמבלען אויב עס איז נישט דערפעראַנסט.
///
/// ניט ענלעך קס 01 קס, קס 02 קס איז קאָוואַריאַנט איבער X00 קס.
/// דאָס זאָל שטענדיק זיין ריכטיק פֿאַר קיין טיפּ וואָס אַפּפּליאַנסעס די ייליאַסינג רעקווירעמענץ פון יוניק.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: דער מאַרקער האט קיין קאַנסאַקווענסאַז פֿאַר וועריאַנס, אָבער עס איז נייטיק
    // פֿאַר דראָפּקק פֿאַרשטיין אַז מיר לאַדזשיקאַללי פאַרמאָגן אַ קס 00 קס.
    //
    // פֿאַר פּרטים, זען:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` פּוינטערז זענען קס 00 קס אויב קס 01 קס איז קס 02 קס ווייַל די דאַטן זיי רעפערענץ זענען אַנאַליאַסד.
/// באַמערקונג אַז דעם ייליאַסינג ינוועראַנט איז אַנפאָרסעד דורך די טיפּ סיסטעם;די אַבסטראַקציע ניצן די `Unique` מוזן דורכפירן דעם.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` פּוינטערז זענען קס 00 קס אויב קס 01 קס איז קס 02 קס ווייַל די דאַטן זיי רעפערענץ זענען אַנאַליאַסד.
/// באַמערקונג אַז דעם ייליאַסינג ינוועראַנט איז אַנפאָרסעד דורך די טיפּ סיסטעם;די אַבסטראַקציע ניצן די `Unique` מוזן דורכפירן דעם.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// קריייץ אַ נייַ `Unique` וואָס איז דאַנגגלינג, אָבער געזונט אַליינד.
    ///
    /// דאָס איז נוציק פֿאַר יניטיאַליזינג טייפּס וואָס פויל אַלאַקייט, ווי `Vec::new`.
    ///
    /// באַמערקונג אַז דער טייַטל ווערט קען פּאַטענטשאַלי רעפּראַזענץ אַ גילטיק טייַטל צו אַ `T`, וואָס מיטל אַז דאָס דאַרף ניט זיין געוויינט ווי אַ "not yet initialized" סענטינעל ווערט.
    /// טייפּס אַז פויל אַלאַקייט מוזן שפּור יניטיאַליזאַטיאָן דורך עטלעכע אנדערע מיטלען.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // זיכערקייט: קס 00 קס קערט אַ גילטיק, ניט-נאַל טייַטל.די
        // די באדינגונגען צו רופן new_unchecked() זענען אַזוי רעספּעקטעד.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// קרעאַטעס אַ נייַ קס 00 קס.
    ///
    /// # Safety
    ///
    /// `ptr` מוזן זיין ניט-נאַל.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `ptr` איז ניט-נאַל.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// קרעאַטעס אַ נייַ קס 00 קס אויב קס 01 קס איז ניט-נאַל.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // זיכערקייט: דער טייַטל איז שוין אָפּגעשטעלט און איז ניט נאַל.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// קונה די אַנדערלייינג קס 00 קס טייַטל.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// דערפערענסעס די אינהאַלט.
    ///
    /// די ריזאַלטינג לעבן איז פארבונדן צו זיך, אַזוי דעם ביכייווז "as if" עס איז געווען טאַקע אַ ביישפּיל פון T וואָס איז באַראָוד.
    /// אויב איר דאַרפֿן אַ לענגערע (unbound) לעבן, נוצן `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // זיכערהייט: די קאַללער מוזן גאַראַנטירן אַז `self` טרעפן אַלע די
        // באדערפענישן פֿאַר אַ רעפֿערענץ.
        unsafe { &*self.as_ptr() }
    }

    /// די אינהאַלט איז בישליימעס דערקענט.
    ///
    /// די ריזאַלטינג לעבן איז פארבונדן צו זיך, אַזוי דעם ביכייווז "as if" עס איז געווען טאַקע אַ ביישפּיל פון T וואָס איז באַראָוד.
    /// אויב איר דאַרפֿן אַ לענגערע (unbound) לעבן, נוצן `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // זיכערהייט: די קאַללער מוזן גאַראַנטירן אַז `self` טרעפן אַלע די
        // באדערפענישן פֿאַר אַ מיוטאַבאַל דערמאָנען.
        unsafe { &mut *self.as_ptr() }
    }

    /// קאַסץ צו אַ טייַטל פון אן אנדער טיפּ.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // זיכערקייט: קס 00 קס קריייץ אַ נייַ יינציק און דאַרף
        // דער געגעבן טייַטל איז נישט נאַל.
        // זינט מיר פאָרן זיך ווי אַ טייַטל, עס קען נישט זיין נאַל.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // זיכערקייט: א מיוטאַבאַל רעפֿערענץ קען נישט זיין נאַל
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}