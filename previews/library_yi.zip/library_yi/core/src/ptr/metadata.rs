#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// פּראָווידעס די טייַטל מעטאַדאַטאַ טיפּ פון קיין טיפּ-צו טיפּ.
///
/// # טייַטל מעטאַדאַטאַ
///
/// רוי טייַטל טייפּס און דערמאָנען טייפּס אין ז 0 רוסט 0 ז קענען זיין געדאַנק פון צוויי פּאַרץ:
/// אַ דאַטן טייַטל וואָס כּולל די זכּרון אַדרעס פון די ווערט און עטלעכע מעטאַדאַטאַ.
///
/// פֿאַר סטאַטיקלי-סייזד טייפּס (וואָס ינסטרומענט די קס 01 קס ז 0 טראַיצ 0 ז) ווי געזונט ווי פֿאַר קס 02 קס טייפּס, פּוינטערז זענען געזאגט צו זיין "דין": מעטאַדאַטאַ איז נול-סייזד און זייַן טיפּ איז קס 00 קס.
///
///
/// פּוינטערז צו קס 00 קס זענען געזאָגט "ברייט" אָדער "פעט", זיי האָבן ניט-נול-סייזד מעטאַדאַטאַ:
///
/// * פֿאַר סטראַקט וואָס די לעצטע פעלד איז אַ דסט, מעטאַדאַטאַ איז די מעטאַדאַטאַ פֿאַר די לעצטע פעלד
/// * פֿאַר די קס 01 קס טיפּ, מעטאַדאַטאַ איז די לענג אין ביטעס ווי קס 00 קס
/// * פֿאַר סלייסאַז טייפּס ווי קס 01 קס, מעטאַדאַטאַ איז די לענג אין זאכן ווי קס 00 קס
/// * פֿאַר ז 0 טראַיט 0 ז אַבדזשעקץ ווי קס 00 קס, מעטאַדאַטאַ איז קס 01 קס (למשל קס 02 קס)
///
/// אין די future, די Rust שפּראַך קען באַקומען נייַע מינים פון טייפּס מיט פאַרשידענע טייַטל מעטאַדאַטאַ.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # די קס 00 קס ז 0 טראַיט 0 ז
///
/// די פונט פון דעם trait איז די `Metadata` פֿאַרבונדן טיפּ, וואָס איז `()` אָדער `usize` אָדער `DynMetadata<_>` ווי אויבן דיסקרייבד.
/// עס איז אויטאָמאַטיש ימפּלאַמענאַד פֿאַר יעדער טיפּ.
/// עס קען זיין אנגענומען צו זיין ימפּלאַמענאַד אין אַ דזשאַנעריק קאָנטעקסט, אפילו אָן אַ קאָראַספּאַנדינג געבונדן.
///
/// # Usage
///
/// רוי פּוינטערז קענען זיין דיקאַמפּאָוזד אין די דאַטן אַדרעס און מעטאַדאַטאַ קאַמפּאָונאַנץ מיט זייער [`to_raw_parts`] אופֿן.
///
/// אַלטערנאַטיוועלי, מעטאַדאַטאַ אַליין קענען זיין יקסטראַקטאַד מיט די [`metadata`] פונקציע.
/// א רעפֿערענץ קענען זיין דורכגעגאנגען צו [`metadata`] און ימפּליסאַטלי געצווונגען.
///
/// א קס 01 קס טייַטל קענען זיין שטעלן צוזאַמען פֿון זיין אַדרעס און מעטאַדאַטאַ מיט קס 02 קס אָדער קס 00 קס.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// דער טיפּ פֿאַר מעטאַדאַטאַ אין פּוינטערז און באַווייַזן צו `Self`.
    #[lang = "metadata_type"]
    // NOTE: האַלטן trait bounds אין `static_assert_expected_bounds_for_metadata`
    //
    // אין קס 00 קס אין סינק מיט די דאָ:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// פּוינטערז צו טייפּס ימפּלאַמענינג דעם אַליאַס ז 0 טראַיט 0 ז זענען "דין".
///
/// דעם כולל סטאַטיקלי-'סיזעד 'טייפּס און קס 00 קס טייפּס.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: טאָן ניט סטייבאַלייז דעם איידער אַליאַסיז פון trait זענען סטאַביל אין דער שפּראַך?
pub trait Thin = Pointee<Metadata = ()>;

/// עקסטראַקט די מעטאַדאַטאַ קאָמפּאָנענט פון אַ טייַטל.
///
/// וואַלועס פון טיפּ קס 01 קס, קס 02 קס, אָדער קס 03 קס קענען זיין דורכגעגאנגען גלייַך צו דעם פֿונקציע ווי זיי ימפּליסאַטלי צווינגען צו קס 00 קס.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // זיכערהייט: אַקסעס די ווערט פון די קס 00 קס פאַרבאַנד איז זיכער זינט * קאָנסט ט
    // און פּטרקאָמפּאָנענץ<T>האָבן די זעלבע זכּרון לייאַוץ.
    // בלויז ז 0 סטד 0 ז קענען מאַכן דעם גאַראַנטירן.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// פאָרמס אַ קס 00 קס רוי טייַטל פֿון אַ דאַטן אַדרעס און מעטאַדאַטאַ.
///
/// די פֿונקציע איז זיכער אָבער דער אומגעקערט טייַטל איז ניט דאַווקע זיכער צו דערפעראַנס.
/// פֿאַר סלייסאַז, זען די דאַקיומענטיישאַן פון [`slice::from_raw_parts`] פֿאַר זיכערקייַט רעקווירעמענץ.
/// פֿאַר trait אַבדזשעקץ, די מעטאַדאַטאַ מוזן קומען פֿון אַ טייַטל צו דער זעלביקער אַנדערלייינג ערידזשד טיפּ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // זיכערהייט: אַקסעס די ווערט פון די קס 00 קס פאַרבאַנד איז זיכער זינט * קאָנסט ט
    // און פּטרקאָמפּאָנענץ<T>האָבן די זעלבע זכּרון לייאַוץ.
    // בלויז ז 0 סטד 0 ז קענען מאַכן דעם גאַראַנטירן.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// פּערפאָרמז די זעלבע פאַנגקשאַנאַליטי ווי קס 00 קס, אַחוץ אַז אַ רוי קס 01 קס טייַטל איז אומגעקערט, ווי קעגן צו אַ רוי קס 02 קס טייַטל.
///
///
/// זען די דאָקומענטאַטיאָן פון [`from_raw_parts`] פֿאַר מער דעטאַילס.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // זיכערהייט: אַקסעס די ווערט פון די קס 00 קס פאַרבאַנד איז זיכער זינט * קאָנסט ט
    // און פּטרקאָמפּאָנענץ<T>האָבן די זעלבע זכּרון לייאַוץ.
    // בלויז ז 0 סטד 0 ז קענען מאַכן דעם גאַראַנטירן.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// מאַנואַל ימפּ דארף צו ויסמיידן `T: Copy` געבונדן.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// מאַנואַל ימפּ דארף צו ויסמיידן `T: Clone` געבונדן.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// די מעטאַדאַטאַ פֿאַר אַ `Dyn = dyn SomeTrait` ז 0 טראַט 0 ז כייפעץ טיפּ.
///
/// עס איז אַ טייַטל צו אַ ווטאַבלע (ווירטואַל רופן טיש) וואָס רעפּראַזענץ אַלע די נויטיק אינפֿאָרמאַציע צו מאַניפּולירן די באַטאָנען טיפּ סטאָרד אין אַ ז 0 טראַט 0 ז כייפעץ.
/// דער טאַבלע עס כּולל:
///
/// * טיפּ גרייס
/// * טיפּ אַליינמאַנט
/// * אַ טייַטל צו די טיפּ `drop_in_place` ימפּ (קען זיין אַ ניט-אָפּ פֿאַר קלאָר-אַלט-דאַטן)
/// * פּוינטערז צו אַלע מעטהאָדס פֿאַר די ימפּלאַמענטיישאַן פון די trait
///
/// באַמערקונג אַז די ערשטע דריי זענען ספּעציעל ווייַל זיי זענען נויטיק צו אַלאַקייט, פאַלן און האַנדללאָקאַט קיין trait כייפעץ.
///
/// עס איז מעגלעך צו נאָמען דעם סטרוקטור מיט אַ טיפּ פּאַראַמעטער וואָס איז נישט אַ `dyn` trait כייפעץ (פֿאַר בייַשפּיל `DynMetadata<u64>`), אָבער נישט צו באַקומען אַ באַטייטיק ווערט פון דעם סטרוקטור.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// דער פּראָסט פּרעפיקס פון אַלע ווטאַבלעס.עס איז נאכגעגאנגען דורך פונקציאָנירן פּוינטערז פֿאַר ז 0 טראַיט 0 ז מעטהאָדס.
///
/// פּריוואַט ימפּלאַמענטיישאַן דעטאַל פון קס 00 קס עטק.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// קערט די גרייס פון דעם טיפּ פארבונדן מיט דעם ווטאַבלע.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// רעטורנס די אַליינמאַנט פון די טיפּ פארבונדן מיט דעם ווטאַבלע.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// קערט די גרייס און אַליינמאַנט צוזאַמען ווי אַ קס 00 קס
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // זיכערקייט: דער קאַמפּיילער ימיטיד דעם וואַטאַבלע פֿאַר אַ באַטאָנען ז 0 רוסט 0 ז טיפּ
        // איז באַוווסט צו האָבן אַ גילטיק אויסלייג.דער זעלביקער סייכל ווי אין `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// מאַנואַל ימפּליקס דארף צו ויסמיידן `Dyn: $Trait` גווול.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}