#![stable(feature = "futures_api", since = "1.36.0")]

//! אַסינטשראָנאָוס וואַלועס.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// דעם טיפּ איז דארף ווייַל:
///
/// אַ) גענעראַטאָרס קענען נישט ינסטרומענט קס 00 קס, אַזוי מיר דאַרפֿן צו פאָרן אַ רוי טייַטל (זען קס 01 קס).
///
/// b) רוי פּוינטערז און `NonNull` זענען נישט `Send` אָדער `Sync`, אַזוי אַז יעדער future non-Send/Sync וואָלט אויך זיין, און מיר טאָן ניט וועלן דאָס.
///
/// עס אויך סימפּלאַפייז די HIR לאָוערינג פון `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ראַפּט אַ גענעראַטאָר אין אַ future.
///
/// די פֿונקציע קערט אַ `GenFuture` ונטער, אָבער כיידז עס אין `impl Trait` צו געבן בעסער טעות אַרטיקלען (X0 `impl Future` ווי `GenFuture<[closure.....]>`).
///
// דאָס איז `const` צו ויסמיידן עקסטרע ערראָרס נאָך מיר צוריקקריגן פון `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // מיר פאַרלאָזנ אויף די פאַקט אַז async/await futures זענען ימווואַבאַל צו שאַפֿן זיך-רעפערענטשאַל באַראָוז אין די אַנדערלייינג גענעראַטאָר.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // זיכערקייט: זיכער ווייַל מיר זענען !Unpin + !Drop, און דאָס איז נאָר אַ פעלד פּרויעקציע.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // נעמענ זיכ ווידער די גענעראַטאָר און ווענדן די `&mut Context` אין אַ `NonNull` רוי טייַטל.
            // די קס 01 קס לאָוערינג וועט בעשאָלעם וואַרפן עס צוריק צו אַ קס 00 קס.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `cx.0` איז אַ גילטיק טייַטל
    // אַז פולפילז אַלע די רעקווירעמענץ פֿאַר אַ מיוטאַבאַל רעפֿערענץ.
    unsafe { &mut *cx.0.as_ptr().cast() }
}