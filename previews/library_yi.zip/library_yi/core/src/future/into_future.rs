use crate::future::Future;

/// קאָנווערסיאָן אין אַ `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// דער רעזולטאַט וואָס די future וועט פּראָדוצירן נאָך קאַמפּלישאַן.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// וואָס סאָרט פון future מיר מאַכן פון דעם?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// קרעאַטעס אַ future פֿון אַ ווערט.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}