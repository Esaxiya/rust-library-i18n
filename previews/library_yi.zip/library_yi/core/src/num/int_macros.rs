macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// דער קלענסטער ווערט וואָס קענען זיין רעפּריזענטיד דורך דעם ינטאַדזשער טיפּ.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// די גרעסטע ווערט וואָס קענען זיין רעפּריזענטיד דורך דעם ינטאַדזשער טיפּ.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// די גרייס פון דעם גאַנץ נומער טיפּ אין ביטן.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// קאַנווערץ אַ שטריקל רעפטל אין אַ געגעבן באַזע צו אַ ינטאַדזשער.
        ///
        /// דער שטריקל איז געריכט צו זיין אַן אַפּשאַנאַל `+` אָדער `-` צייכן, נאכגעגאנגען דורך דידזשאַץ.
        /// לידינג און טריילינג ווייַס ספּייסאַז פאָרשטעלן אַ טעות.
        /// דידזשאַץ זענען אַ סאַבסעט פון די אותיות, דיפּענדינג אויף `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// די פונקציע panics אויב `radix` איז ניט אין די קייט פון 2 צו 36.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// קערט די נומער פון די ביינערי פאַרטרעטונג פון `self`.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// קערט די נומער פון זעראָס אין די ביינערי פאַרטרעטונג פון `self`.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// קערט די נומער פון לידינג זעראָס אין די ביינערי פאַרטרעטונג פון `self`.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// קערט די נומער פון טריילינג זעראָס אין די ביינערי פאַרטרעטונג פון `self`.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// קערט די נומער פון לידינג אָנעס אין די ביינערי פאַרטרעטונג פון קס 00 קס.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// קערט די נומער פון טריילינג אין די ביינערי פאַרטרעטונג פון `self`.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// שיפט די ביטן צו די לינקס מיט אַ ספּעציפֿיש סומע, קס 00 קס, ראַפּינג די טראַנגקייטיד ביטן צו די סוף פון די ריזאַלטינג ינטאַדזשער.
        ///
        ///
        /// ביטע טאָן אַז דאָס איז נישט די זעלבע אָפּעראַציע ווי די `<<` שיפטינג אָפּעראַטאָר!
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// שיפט די ביטן צו אַ רעכט ספּעציפיצירטע סומע רעכט, `n`, ראַפּינג די טראַנגקייטיד ביטן צו די אָנהייב פון די ריזאַלטינג ינטאַדזשער.
        ///
        ///
        /// ביטע טאָן אַז דאָס איז נישט די זעלבע אָפּעראַציע ווי די `>>` שיפטינג אָפּעראַטאָר!
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// ריווערסאַז די ביטע סדר פון די גאַנץ נומער.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// לאָזן עם=קס 00 קס;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// ריווערסאַז די סדר פון ביטן אין די גאַנץ נומער.
        /// די מינדסטער באַטייטיק ביסל ווערט די מערסט באַטייטיק ביסל, רגע מינדסטער באַטייטיק ביסל ווערט רגע מערסט באַטייטיק ביסל, עטק.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// לאָזן עם=קס 00 קס;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// קאַנווערץ אַ גאַנץ נומער פון גרויס ענדיאַן צו די ענדיינאַס פון די ציל.
        ///
        /// אויף גרויס ענדיאַן, דאָס איז אַ ניט-אָפּ.אויף קליין ענדיאַן די ביטעס זענען סוואַפּט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אויב CFG! (ציל_ענדיאַן= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// אנדערש {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// קאַנווערץ אַ גאַנץ נומער פון קליין ענדיאַן צו די ציל פון די ציל.
        ///
        /// אויף קליין ענדיאַן, דאָס איז אַ ניט-אָפּ.אויף גרויס אַנדיאַן די ביטעס זענען סוואַפּט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אויב CFG! (ציל_ענדיאַן= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// אנדערש {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// קאָנווערט `self` צו גרויס ענדיאַן פֿון די ענדיינאַס פון די ציל.
        ///
        /// אויף גרויס ענדיאַן, דאָס איז אַ ניט-אָפּ.אויף קליין ענדיאַן די ביטעס זענען סוואַפּט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אויב CFG! (ציל_ענדיאַן= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } אַנדערש קס 00 קס
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // אָדער ניט צו זיין?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// קאָנווערט `self` צו קליין ענדיאַן פֿון די ענדיינאַס פון די ציל.
        ///
        /// אויף קליין ענדיאַן, דאָס איז אַ ניט-אָפּ.אויף גרויס אַנדיאַן די ביטעס זענען סוואַפּט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// אויב CFG! (ציל_ענדיאַן= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } אַנדערש קס 00 קס
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// אָפּגעשטעלט גאַנץ נומער דערצו.
        /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ונטשעקקעד ינטאַדזשער דערצו.קאַמפּיוץ קס 00 קס, אַסומינג אַז לויפן קען נישט פּאַסירן.
        /// דער רעזולטאַט אין ונדעפינעד נאַטור ווען
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// אָפּגעשטעלט ינטאַדזשער כיסער.
        /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ונטשעקקעד ינטאַדזשער כיסער.קאַמפּיוץ קס 00 קס, אַסומינג אַז לויפן קען נישט פּאַסירן.
        /// דער רעזולטאַט אין ונדעפינעד נאַטור ווען
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// אָפּגעשטעלט גאַנץ נומער קייפל.
        /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ונטשעקקעד ינטאַדזשער קייפל.קאַמפּיוץ קס 00 קס, אַסומינג אַז לויפן קען נישט פּאַסירן.
        /// דער רעזולטאַט אין ונדעפינעד נאַטור ווען
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// אָפּגעשטעלט גאַנץ נומער אָפּטייל.
        /// קאַמפּיוץ קס 00 קס, רענטגענ קס 01 קס אויב קס 02 קס אָדער די אָפּטייל רעזולטאַטן אין לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // זיכערקייט: דיווייס דורך נול און דורך INT_MIN זענען אויבן אָפּגעשטעלט
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// אָפּגעשטעלט עוקלידיאַן אָפּטייל.
        /// קאַמפּיוץ קס 00 קס, רענטגענ קס 01 קס אויב קס 02 קס אָדער די אָפּטייל רעזולטאַטן אין לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// אָפּגעשטעלט גאַנץ רעשט.
        /// קאַמפּיוץ קס 00 קס, רענטגענ קס 01 קס אויב קס 02 קס אָדער די אָפּטייל רעזולטאַטן אין לויפן.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // זיכערקייט: דיווייס דורך נול און דורך INT_MIN זענען אויבן אָפּגעשטעלט
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// אָפּגעשטעלט Euclidean רעשט.
        /// קאַמפּיוץ קס 00 קס, רענטגענ קס 01 קס אויב קס 02 קס אָדער די אָפּטייל רעזולטאַטן אין לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// אָפּגעשטעלט נעגאַטיאָן.
        /// קאַמפּיוץ קס 01 קס, אומגעקערט קס 02 קס אויב קס 00 קס.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// אָפּגעשטעלט שיפט לינקס.
        /// קאַמפּיוץ קס 01 קס, רענטגענ קס 02 קס אויב קס 03 קס איז גרעסער ווי אָדער גלייַך צו די נומער פון ביטן אין קס 00 קס.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// אָפּגעשטעלט שיפט רעכט.
        /// קאַמפּיוץ קס 01 קס, רענטגענ קס 02 קס אויב קס 03 קס איז גרעסער ווי אָדער גלייַך צו די נומער פון ביטן אין קס 00 קס.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// אָפּגעשטעלט אַבסאָלוט ווערט.
        /// קאַמפּיוץ קס 01 קס, אומגעקערט קס 02 קס אויב קס 00 קס.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// אָפּגעשטעלט עקספּאָונענשייישאַן.
        /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // זינט עקספּ!=0, לעסאָף די עקספּ מוזן זיין 1.
            // האַנדלען מיט די לעצט ביסל פון די עקספּאָנענט סעפּעראַטלי, ווייַל סקווערינג די באַזע דערנאָכדעם איז ניט נייטיק און קען פאַרשאַפן אַ יבעריק לויפן.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// סאַטוראַטינג ינטאַדזשער דערצו.
        /// קאַמפּיוץ קס 00 קס, סאַטשערייטינג אין נומעריק באַונדז אַנשטאָט פון אָוווערפלאָוינג.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// סאַטוראַטינג ינטאַדזשער כיסער.
        /// קאַמפּיוץ קס 00 קס, סאַטשערייטינג אין נומעריק באַונדז אַנשטאָט פון אָוווערפלאָוינג.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// סאַטוראַטינג ינטאַדזשער נעגאַטיוו.
        /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב קס 02 קס אַנשטאָט פון אָוווערפלאָוינג.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// סאַטשערייטינג אַבסאָלוט ווערט.
        /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב קס 02 קס אַנשטאָט פון אָוווערפלאָוינג.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// סאַטוראַטינג ינטאַדזשער קייפל.
        /// קאַמפּיוץ קס 00 קס, סאַטשערייטינג אין נומעריק באַונדז אַנשטאָט פון אָוווערפלאָוינג.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// סאַטשערייטינג ינטאַדזשער עקספּאָונענשייישאַן.
        /// קאַמפּיוץ קס 00 קס, סאַטשערייטינג אין נומעריק באַונדז אַנשטאָט פון אָוווערפלאָוינג.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// ראַפּינג קס 00 קס דערצו.
        /// קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// ראַפּינג קס 00 קס כיסער.
        /// קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// ראַפּינג קס 00 קס קייפל.
        /// קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// ראַפּינג קס 01 קס אָפּטייל.קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// דער בלויז פאַל ווען אַזאַ ראַפּינג קענען פּאַסירן איז ווען מען צעטיילט `MIN / -1` אויף אַ געחתמעט טיפּ (ווו `MIN` איז די נעגאַטיוו מינימאַל ווערט פֿאַר דעם טיפּ);דאָס איז עקוויוואַלענט צו קס 00 קס, אַ positive ווערט וואָס איז צו גרויס צו פאָרשטעלן אין דעם טיפּ.
        /// אין אַזאַ אַ פאַל, די פֿונקציע קערט `MIN` זיך.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// ראַפּינג עוקלידיאַן אָפּטייל.
        /// קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// ראַפּינג וועט נאָר פּאַסירן אין `MIN / -1` אויף אַ געחתמעט טיפּ (ווו `MIN` איז די נעגאַטיוו מינימאַל ווערט פֿאַר דעם טיפּ).
        /// דאָס איז עקוויוואַלענט צו `-MIN`, אַ positive ווערט וואָס איז צו גרויס צו פאָרשטעלן אין דעם טיפּ.
        /// אין דעם פאַל, דעם אופֿן קערט `MIN` זיך.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// ראַפּינג קס 01 קס רעשט.קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// אַזאַ ייַנוויקלען אַרום אַקשלי קיינמאָל אַקערז מאַטאַמאַטיקאַללי;ימפּלאַמענטיישאַן אַרטאַפאַקץ מאַכן קס 00 קס פאַרקריפּלט פֿאַר קס 01 קס אויף אַ געחתמעט טיפּ (ווו קס 02 קס איז די נעגאַטיוו מינימאַל ווערט).
        ///
        /// אין אַזאַ אַ פאַל, די פֿונקציע קערט `0`.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// ראַפּינג עוקלידיאַן רעשט.קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// ראַפּינג וועט נאָר פּאַסירן אין `MIN % -1` אויף אַ געחתמעט טיפּ (ווו `MIN` איז די נעגאַטיוו מינימאַל ווערט פֿאַר דעם טיפּ).
        /// אין דעם פאַל, דעם אופֿן קערט 0.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// ראַפּינג קס 01 קס נעגאַטיוו.קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// דער בלויז פאַל ווען אַזאַ ראַפּינג קענען פּאַסירן איז ווען מען ניגייץ `MIN` אויף אַ געחתמעט טיפּ (ווו `MIN` איז די נעגאַטיוו מינימאַל ווערט פֿאַר דעם טיפּ);דאָס איז אַ positive ווערט וואָס איז צו גרויס צו פאָרשטעלן אין דעם טיפּ.
        /// אין אַזאַ אַ פאַל, די פֿונקציע קערט `MIN` זיך.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// ז 0 פּאַניק 0 ז-פֿרייַ ביטוויסע יבעררוק-לינקס;ייעלדס קס 00 קס, ווו קס 01 קס רימוווז קיין הויך-סדר ביטן פון קס 02 קס וואָס וואָלט פאַרשאַפן די יבעררוק צו יקסיד די ביטווידט פון דעם טיפּ.
        ///
        /// באַמערקונג אַז דאָס איז *נישט* די זעלבע ווי אַ דרייען-לינקס;די רהס פון אַ ראַפּינג יבעררוק-לינקס איז ריסטריקטיד צו די קייט פון דעם טיפּ, אלא ווי די ביטן שיפטעד פֿון די להס זייַענדיק אומגעקערט צו די אנדערע סוף.
        ///
        /// די פּרימיטיוו ינטאַדזשער טייפּס אַלע ימפּלאַמענאַד אַ קס 00 קס פונקציע, וואָס קען זיין וואָס איר ווילט אַנשטאָט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // זיכערקייט: די מאַסקע פון דעם טיפּ פון ביטזייז ינשורז אַז מיר טאָן ניט יבעררוק
            // אויס פון גווול
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// ז 0 פּאַניק 0 ז-פֿרייַ ביטוויסע יבעררוק-רעכט;ייעלדס קס 00 קס, ווו קס 01 קס רימוווז קיין הויך-סדר ביטן פון קס 02 קס וואָס וואָלט פאַרשאַפן די יבעררוק צו יקסיד די ביטווידט פון דעם טיפּ.
        ///
        /// באַמערקונג אַז דאָס איז *נישט* די זעלבע ווי אַ דריי-רעכט;די רהס פון אַ ראַפּינג יבעררוק רעכט איז ריסטריקטיד צו די קייט פון דעם טיפּ, אלא ווי די ביטן שיפטעד פֿון די להס זייַענדיק אומגעקערט צו די אנדערע סוף.
        ///
        /// די פּרימיטיוו ינטאַדזשער טייפּס אַלע ימפּלאַמענאַד אַ קס 00 קס פונקציע, וואָס קען זיין וואָס איר ווילט אַנשטאָט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // זיכערקייט: די מאַסקע פון דעם טיפּ פון ביטזייז ינשורז אַז מיר טאָן ניט יבעררוק
            // אויס פון גווול
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// ראַפּינג קס 01 קס אַבסאָלוט ווערט.קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// דער בלויז פאַל ווען אַזאַ ראַפּינג קענען פּאַסירן איז ווען מען נעמט די אַבסאָלוט ווערט פון די נעגאַטיוו מינימאַל ווערט פֿאַר דעם טיפּ;דאָס איז אַ positive ווערט וואָס איז צו גרויס צו פאָרשטעלן אין דעם טיפּ.
        /// אין אַזאַ אַ פאַל, די פֿונקציע קערט `MIN` זיך.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// קאַמפּיוץ די אַבסאָלוט ווערט פון קס 00 קס אָן ראַפּינג אָדער פּאַניקקינג.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// ראַפּינג (modular) עקספּאָנענטיאַטיאָן.
        /// קאַמפּיוץ קס 00 קס, ראַפּינג אַרום די גרענעץ פון דעם טיפּ.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // זינט עקספּ!=0, לעסאָף די עקספּ מוזן זיין 1.
            // האַנדלען מיט די לעצט ביסל פון די עקספּאָנענט סעפּעראַטלי, ווייַל סקווערינג די באַזע דערנאָכדעם איז ניט נייטיק און קען פאַרשאַפן אַ יבעריק לויפן.
            //
            //
            acc.wrapping_mul(base)
        }

        /// קאַלקיאַלייץ קס 01 קס + קס 00 קס
        ///
        /// רעטורנס אַ טופּאַל פון די דערצו צוזאמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אַריטמעטיק לויפן וועט פאַלן.
        /// אויב אַן אָוווערפלאָו וואָלט פּאַסירן, די ראַפּט ווערט איז אומגעקערט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// קאַלקיאַלייץ קס 01 קס, קס 00 קס
        ///
        /// רעטורנס אַ טופּאַל פון די כיסער צוזאמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אַריטמעטיק לויפן וועט פאַלן.
        /// אויב אַן אָוווערפלאָו וואָלט פּאַסירן, די ראַפּט ווערט איז אומגעקערט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// קאַלקיאַלייץ די קייפל פון קס 01 קס און קס 00 קס.
        ///
        /// רעטורנס אַ טופּאַל פון די קייפל צוזאמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אַריטמעטיק לויפן וועט פאַלן.
        /// אויב אַן אָוווערפלאָו וואָלט פּאַסירן, די ראַפּט ווערט איז אומגעקערט.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, אמת));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// קאַלקיאַלייץ די דיווייזער ווען קס 01 קס איז צעטיילט דורך קס 00 קס.
        ///
        /// קערט אַ טופּאַל פון די דיווייסער צוזאמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אַריטמעטיק לויפן וועט פאַלן.
        /// אויב אַ אָוווערפלאָו וואָלט פּאַסירן, זיך איז אומגעקערט.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// קאַלקיאַלייץ די קוואָטיענט פון Euclidean אָפּטייל `self.div_euclid(rhs)`.
        ///
        /// קערט אַ טופּאַל פון די דיווייסער צוזאמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אַריטמעטיק לויפן וועט פאַלן.
        /// אויב אַ לויפן וועט פאַלן `self` איז אומגעקערט.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// קאַלקיאַלייץ די רעשט ווען `self` איז צעטיילט דורך `rhs`.
        ///
        /// רעטורנס אַ טופּאַל פון די רעשט נאָך דיוויידינג צוזאַמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אַריטמעטיק לויפן וועט פאַלן.
        /// אויב אַ לויפן וועט פאַלן 0 איז אומגעקערט.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// אָוווערפלאָוינג Euclidean רעשט.קאַלקיאַלייץ קס 00 קס.
        ///
        /// רעטורנס אַ טופּאַל פון די רעשט נאָך דיוויידינג צוזאַמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אַריטמעטיק לויפן וועט פאַלן.
        /// אויב אַ לויפן וועט פאַלן 0 איז אומגעקערט.
        ///
        /// # Panics
        ///
        /// די פֿונקציע וועט panic אויב `rhs` איז 0.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// ניגייץ זיך, אָוווערפלאָוינג אויב דאָס איז גלייַך צו די מינימום ווערט.
        ///
        /// קערט אַ טאָפּל פון די נעגאַטיוו ווערסיע פון זיך צוזאַמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אָוווערפלאָו געטראפן.
        /// אויב `self` איז די מינימום ווערט (למשל, `i32::MIN` פֿאַר וואַלועס פון טיפּ `i32`), די מינימום ווערט וועט זיין אומגעקערט ווידער און `true` וועט זיין אומגעקערט פֿאַר אַ אָוווערפלאָו געשעעניש.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// שיפץ זיך לינקס דורך `rhs` ביטן.
        ///
        /// רעטורנס אַ טאָפּל פון די שיפטיד ווערסיע פון זיך צוזאמען מיט אַ באָאָלעאַן ינדאַקייטינג צי די יבעררוק ווערט איז געווען גרעסער ווי אָדער גלייַך צו די נומער פון ביטן.
        /// אויב די יבעררוק ווערט איז אויך גרויס, די ווערט איז מאַסקט (N-1) ווו N איז די נומער פון ביטן, און די ווערט איז געניצט צו דורכפירן די יבעררוק.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0 קס 10, אמת));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// שיפץ זיך רעכט דורך `rhs` ביטן.
        ///
        /// רעטורנס אַ טאָפּל פון די שיפטיד ווערסיע פון זיך צוזאמען מיט אַ באָאָלעאַן ינדאַקייטינג צי די יבעררוק ווערט איז געווען גרעסער ווי אָדער גלייַך צו די נומער פון ביטן.
        /// אויב די יבעררוק ווערט איז אויך גרויס, די ווערט איז מאַסקט (N-1) ווו N איז די נומער פון ביטן, און די ווערט איז געניצט צו דורכפירן די יבעררוק.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0 קס 1, אמת));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// קאַמפּיוץ די אַבסאָלוט ווערט פון `self`.
        ///
        /// קערט אַ טאָפּל פון די אַבסאָלוט ווערסיע פון זיך צוזאַמען מיט אַ באָאָלעאַן ינדאַקייטינג צי אַ אָוווערפלאָו געטראפן.
        /// אויב זיך איז די מינימום ווערט
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// דערנאָך די מינימום ווערט וועט זיין אומגעקערט ווידער און אמת וועט זיין אומגעקערט פֿאַר אַ אָוווערפלאָו געשעעניש.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// רייזאַז זיך צו די מאַכט פון קס 00 קס, ניצן עקספּאָונענשייישאַן דורך סקווערינג.
        ///
        /// קערט אַ טופּאַל פון די עקספּאָונענשייישאַן צוזאַמען מיט אַ bool וואָס ינדיקייץ צי אַ אָוווערפלאָו געטראפן.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, אמת));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // קראַצן פּלאַץ פֿאַר סטאָרינג רעזולטאַטן פון אָוווערפלאָוינג_מול.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // זינט עקספּ!=0, לעסאָף די עקספּ מוזן זיין 1.
            // האַנדלען מיט די לעצט ביסל פון די עקספּאָנענט סעפּעראַטלי, ווייַל סקווערינג די באַזע דערנאָכדעם איז ניט נייטיק און קען פאַרשאַפן אַ יבעריק לויפן.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// רייזאַז זיך צו די מאַכט פון קס 00 קס, ניצן עקספּאָונענשייישאַן דורך סקווערינג.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // זינט עקספּ!=0, לעסאָף די עקספּ מוזן זיין 1.
            // האַנדלען מיט די לעצט ביסל פון די עקספּאָנענט סעפּעראַטלי, ווייַל סקווערינג די באַזע דערנאָכדעם איז ניט נייטיק און קען פאַרשאַפן אַ יבעריק לויפן.
            //
            //
            acc * base
        }

        /// קאַלקיאַלייץ די קוואָטיענט פון די Euclidean אָפּטייל פון `self` דורך `rhs`.
        ///
        /// דעם קאַמפּיוץ די ינטאַדזשער קס 02 קס אַזוי אַז קס 01 קס, מיט קס 00 קס.
        ///
        ///
        /// אין אנדערע ווערטער, דער רעזולטאַט איז קס 01 קס ראַונדיד צו די ינטאַדזשער קס 02 קס אַזוי אַז קס 00 קס.
        /// אויב `self > 0`, דאָס איז גלייַך צו קייַלעכיק צו נול (די פעליקייַט אין Rust);
        /// אויב קס 00 קס, דאָס איז גלייַך צו קייַלעכיק צו +/-ומענדיקייַט.
        ///
        /// # Panics
        ///
        /// די פונקציע וועט panic אויב `rhs` איז 0 אָדער די אָפּטייל רעזולטאַטן אין לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// לאָזן ב=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 קס 00 קס, קס 09 קס);//7>=קס 03 קס* קס 04 קס קס 01 קס, קס 01 קס);//קס 05 קס>=4 *קס 06 קס קס 02 קס, 2);//קס 07 קס>=קס 08 קס* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// רעכענען די מינדסטער נאַנעגאַטיוו רעשט פון קס 00 קס.
        ///
        /// דאָס איז דורכגעקאָכט ווי דורך די אַלגערידאַם פון די עוקלידיאַן אָפּטייל-געגעבן `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` און `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// די פונקציע וועט panic אויב `rhs` איז 0 אָדער די אָפּטייל רעזולטאַטן אין לויפן.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// לאָזן ב=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// קאַמפּיוץ די אַבסאָלוט ווערט פון `self`.
        ///
        /// # אָוווערפלאָו נאַטור
        ///
        /// די אַבסאָלוט ווערט פון
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// קענען ניט זיין רעפּריזענטיד ווי אַן
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// און טריינג צו רעכענען עס וועט פאַרשאַפן אַ לויפן.
        /// דעם מיטל אַז קאָד אין דיבאַג מאָדע וועט צינגל אַ panic אין דעם פאַל און אָפּטימיזעד קאָד וועט צוריקקומען
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// אָן אַ panic.
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // באַמערקונג אַז די#[ינלינע] אויבן מיטל אַז די אָוווערפלאָו סעמאַנטיקס פון די כיסער אָפענגען אויף די crate וואָס מיר זייַנען ינליינד אין.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// קערט אַ נומער רעפּריזענטינג צייכן פון קסקסנומקסקס.
        ///
        ///  - `0` אויב די נומער איז נול
        ///  - `1` אויב די נומער איז positive
        ///  - `-1` אויב די נומער איז נעגאַטיוו
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// קערט `true` אויב `self` איז positive און `false` אויב די נומער איז נול אָדער נעגאַטיוו.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// קערט `true` אויב `self` איז נעגאַטיוו און `false` אויב די נומער איז נול אָדער positive.
        ///
        ///
        /// # Examples
        ///
        /// באַסיק באַניץ:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// צוריקקומען די זכּרון פאַרטרעטונג פון דעם ינטאַדזשער ווי אַ בייט מענגע אין גרויס אָרדיאַן קס 00 קס בייטן סדר.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ווייַזן די זיקאָרן פאַרטרעטונג פון דעם ינטאַדזשער ווי אַ בייט מענגע אין ביסל-ענדייאַן בייטן סדר.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ווייַזן די זיקאָרן פאַרטרעטונג פון דעם גאַנץ נומער ווי אַ בייט מענגע אין געבוירן בייט סדר.
        ///
        /// ווי די געבוירן ענדייאַנעסס פון די ציל פּלאַטפאָרמע איז געניצט, פּאָרטאַטיוו קאָד זאָל נוצן [`to_be_bytes`] אָדער [`to_le_bytes`], ווי צונעמען, אַנשטאָט.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     ביטעס, אויב CFG! (ציל_ענדיאַן= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// אנדערש {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // זיכערקייט: קאָנסט געזונט ווייַל ינטאַדזשערז זענען קלאָר אַלט דאַטייפּס אַזוי מיר קענען שטענדיק
        // יבערמאַכן זיי צו ערייז פון ביטעס
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // זיכערקייט: ינטאַדזשערז זענען קלאָר אַלט דאַטאַ טייפּס אַזוי מיר קענען שטענדיק יבערמאַכן זיי צו
            // ערייז פון ביטעס
            unsafe { mem::transmute(self) }
        }

        /// ווייַזן די זיקאָרן פאַרטרעטונג פון דעם גאַנץ נומער ווי אַ בייט מענגע אין געבוירן בייט סדר.
        ///
        ///
        /// [`to_ne_bytes`] זאָל זיין בילכער איבער דעם ווען מעגלעך.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// לאָזן ביטעס=קס 00 קס;
        /// assert_eq!(
        ///     ביטעס, אויב CFG! (ציל_ענדיאַן= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// אנדערש {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // זיכערקייט: ינטאַדזשערז זענען קלאָר אַלט דאַטאַ טייפּס אַזוי מיר קענען שטענדיק יבערמאַכן זיי צו
            // ערייז פון ביטעס
            unsafe { &*(self as *const Self as *const _) }
        }

        /// שאַפֿן אַ גאַנץ נומער פון זיין פאַרטרעטונג ווי אַ בייט מענגע אין גרויס אַנדיאַן.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// נוצן קס 00 קס;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * אַרייַנשרייַב=מנוחה;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// שאַפֿן אַ גאַנץ נומער פון די פאַרטרעטונג ווי אַ בייט מענגע אין קליין ענדיאַן.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// נוצן קס 00 קס;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * אַרייַנשרייַב=מנוחה;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// שאַפֿן אַ ינטאַדזשער ווערט פֿון זיין זכּרון פאַרטרעטונג ווי אַ בייט מענגע אין געבוירן ענדיינאַס.
        ///
        /// ווי די געבוירן ענדייאַנעסס פון די ציל פּלאַטפאָרמע איז געניצט, פּאָרטאַטיוו קאָד מיסטאָמע וויל צו נוצן [`from_be_bytes`] אָדער [`from_le_bytes`], ווי געהעריק אַנשטאָט.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// אנדערש {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// נוצן קס 00 קס;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * אַרייַנשרייַב=מנוחה;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // זיכערקייט: קאָנסט געזונט ווייַל ינטאַדזשערז זענען קלאָר אַלט דאַטייפּס אַזוי מיר קענען שטענדיק
        // יבערמאַכן צו זיי
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // זיכערהייט: ינטאַדזשערז זענען קלאָר אַלט דאַטייפּס, אַזוי מיר קענען שטענדיק יבערמאַכן צו זיי
            unsafe { mem::transmute(bytes) }
        }

        /// נייַ קאָד זאָל בעסער נוצן
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// רעטורנס דער קלענסטער ווערט וואָס קענען זיין רעפּריזענטיד דורך דעם גאַנץ נומער.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// נייַ קאָד זאָל בעסער נוצן
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// רעטורנס די גרעסטע ווערט וואָס קענען זיין רעפּריזענטיד דורך דעם ינטאַדזשער טיפּ.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}