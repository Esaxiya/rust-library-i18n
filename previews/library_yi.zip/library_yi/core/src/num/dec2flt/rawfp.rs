//! ביסל פידלינג אויף positive IEEE 754 פלאָוץ.נעגאַטיוו נומערן זענען נישט און דאַרפֿן ניט זיין כאַנדאַלד.
//! נאָרמאַל פלאָוטינג פונט נומערן האָבן אַ קאַנאַנאַקאַל פאַרטרעטונג ווי (פראַק, עקספּ) אַזוי אַז די ווערט איז 2 <sup>עקספּ</sup> * (1 + קס 00 קס ווו N איז די נומער פון ביטן.
//!
//! סובנאָרמאַלס זענען אַ ביסל אַנדערש און טשודנע, אָבער דער זעלביקער פּרינציפּ אַפּלייז.
//!
//! דאָ, אָבער, מיר פאָרשטעלן זיי ווי (sig, k) מיט f positive, אַזוי אַז די ווערט איז f *
//! 2 <sup>e</sup> .אין אַדישאַן צו מאַכן די "hidden bit" יקספּליסאַט, דאָס ענדערונגען די עקספּאָנענט דורך די אַזוי גערופענע מאַנטיססאַ יבעררוק.
//!
//! אין אַ אַנדערש וועג, נאָרמאַלי פלאָוץ זענען געשריבן ווי (1), אָבער דאָ זיי זענען געשריבן ווי (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! מיר רופן (1) די **פראַקשאַנאַל פאַרטרעטונג** און (2) די **ינטאַגראַל פאַרטרעטונג**.
//!
//! פילע פאַנגקשאַנז אין דעם מאָדולע האָבן בלויז נאָרמאַל נומערן.די דעק 2 פלט רוטינז קאַנסערוואַטיוולי נעמען די יונאַווערסאַלי-ריכטיק פּאַמעלעך וועג (אַלגאָריטהם ב) פֿאַר זייער קליין און זייער גרויס נומערן.
//! דער אַלגערידאַם דאַרף בלויז next_float() וואָס האַנדלען מיט סובנאָרמאַלז און זעראָס.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// אַ העלפער ז 0 טראַיט 0 ז צו ויסמייַדן דופּליקייטינג בייסיקלי אַלע די קאַנווערזשאַן קאָד פֿאַר קס 01 קס און קס 00 קס.
///
/// זען די דאָקומענט פון די פאָטער פון די פאָטער פֿאַר וואָס דאָס איז נייטיק.
///
/// זאָל **קיינמאָל** זיין ימפּלאַמענאַד פֿאַר אנדערע טייפּס אָדער זיין געוויינט אַרויס די דעק 2 פלט מאָדולע.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// טיפּ געניצט דורך קס 01 קס און קס 00 קס.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// פּערפאָרמז אַ רוי טראַנסמוטאַטיאָן צו אַ גאַנץ נומער.
    fn to_bits(self) -> Self::Bits;

    /// פּערפאָרמז אַ רוי טראַנסמוטאַטיאָן פֿון אַ גאַנץ נומער.
    fn from_bits(v: Self::Bits) -> Self;

    /// רעטורנס די קאַטעגאָריע אַז די נומער פאלס אין.
    fn classify(self) -> FpCategory;

    /// רעטורנס די מאַנטיססאַ, עקספּאָנענט און צייכן ווי ינטאַדזשערז.
    fn integer_decode(self) -> (u64, i16, i8);

    /// דעקאָדעס די לאָזנ שווימען.
    fn unpack(self) -> Unpacked;

    /// וואַרפן פֿון אַ קליין גאַנץ נומער וואָס קענען זיין רעפּריזענטיד פּונקט.
    /// Panic אויב די ינטאַדזשער קענען ניט זיין רעפּריזענטיד, די אנדערע קאָד אין דעם מאָדולע מאכט זיכער צו קיינמאָל לאָזן דאָס פּאַסירן.
    fn from_int(x: u64) -> Self;

    /// באַקומען די ווערט 10 <sup>e</sup> פֿון אַ פאַר-קאַמפּיוטאַד טיש.
    /// Panics פֿאַר קס 00 קס.
    fn short_fast_pow10(e: usize) -> Self;

    /// וואָס די נאָמען זאגט.
    /// עס איז גרינגער צו שווער קאָד ווי דזשאַגאַלינג ינטרינסיקס און כאָופּינג די LLVM קעסיידער פאָולדז.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // א קאָנסערוואַטיווע געבונדן מיט די דעצימאַל דידזשאַץ פון ינפּוץ וואָס קענען נישט פּראָדוצירן לויפן אָדער נול אָדער
    /// סובנאָרמאַלס.מיסטאָמע די דעצימאַל עקספּאָנענט פון די מאַקסימום נאָרמאַל ווערט, דערפאר די נאָמען.
    const MAX_NORMAL_DIGITS: usize;

    /// ווען די מערסט באַטייטיק דעצימאַל ציפֿער האט אַ פּלאַץ ווערט גרעסער ווי דעם, די נומער איז אַוואַדע ראַונדיד צו ומענדיקייַט.
    ///
    const INF_CUTOFF: i64;

    /// ווען די מערסט באַטייטיק דעצימאַל ציפֿער האט אַ פּלאַץ ווערט ווייניקער ווי דעם, די נומער איז אַוואַדע ראַונדיד צו נול.
    ///
    const ZERO_CUTOFF: i64;

    /// די נומער פון ביטן אין דער עקספּאָנענט.
    const EXP_BITS: u8;

    /// די נומער פון ביטן אין די באַטייטיק,*אַרייַנגערעכנט* די פאַרבאָרגן ביסל.
    const SIG_BITS: u8;

    /// די נומער פון ביטן אין די באַטייטיק,*עקסקלודינג* די פאַרבאָרגן ביסל.
    const EXPLICIT_SIG_BITS: u8;

    /// די מאַקסימום לעגאַל עקספּאָנענט אין פראַקשאַנאַל פאַרטרעטונג.
    const MAX_EXP: i16;

    /// די מינימום לעגאַל עקספּאָנענט אין פראַקשאַנאַל פאַרטרעטונג, עקסקלודינג סובנאָרמאַלס.
    const MIN_EXP: i16;

    /// `MAX_EXP` פֿאַר ינטאַגראַל פאַרטרעטונג, הייסט, מיט די יבעררוק געווענדט.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` ענקאָודיד (י.ע. מיט פאָטאָ פאָרורטייל)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` פֿאַר ינטאַגראַל פאַרטרעטונג, הייסט, מיט די יבעררוק געווענדט.
    const MIN_EXP_INT: i16;

    /// די מאַקסימום נאָרמאַלייזד באַטייטיק אין ינטאַגראַל פאַרטרעטונג.
    const MAX_SIG: u64;

    /// די מינימאַל נאָרמאַלייזד באַטייטיק אין ינטאַגראַל פאַרטרעטונג.
    const MIN_SIG: u64;
}

// מערסטנס אַ וואָרקאַראָונד פֿאַר קס 00 קס.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// רעטורנס די מאַנטיססאַ, עקספּאָנענט און צייכן ווי ינטאַדזשערז.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // עקספּאָנענט פאָרורטייל + מאַנטיססאַ יבעררוק
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe איז ומזיכער צי `as` ראָונדס ריכטיק אויף אַלע פּלאַטפאָרמס.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// רעטורנס די מאַנטיססאַ, עקספּאָנענט און צייכן ווי ינטאַדזשערז.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // עקספּאָנענט פאָרורטייל + מאַנטיססאַ יבעררוק
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe איז ומזיכער צי `as` ראָונדס ריכטיק אויף אַלע פּלאַטפאָרמס.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// קאַנווערץ אַן `Fp` צו די קלאָוסאַסט טיפּ פון מאַשין לאָזנ שווימען.
/// קען נישט שעפּן סובנאָרמאַל רעזולטאַטן.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f איז 64 ביסל, אַזוי XE האט אַ מאַנטיססאַ יבעררוק פון 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// קייַלעכיק די 64-ביסל באַטייטיק צו T::SIG_BITS ביטן מיט האַלב-צו-אפילו.
/// קען נישט שעפּן עקספּאָנענט לויפן.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // סטרויערן מאַנטיססאַ יבעררוק
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// פאַרקערט פון קס 00 קס פֿאַר נאָרמאַלייזד נומערן.
/// Panics אויב די באַטייטיק אָדער עקספּאָנענט זענען נישט גילטיק פֿאַר נאָרמאַלייזד נומערן.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // אַראָפּנעמען די פאַרבאָרגן ביסל
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // סטרויערן די עקספּאָנענט פֿאַר עקספּאָנענט פאָרורטייל און מאַנטיססאַ יבעררוק
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // לאָזן צייכן ביסל ביי 0 קס 00 קס, אונדזער נומערן זענען אַלע positive
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// בויען אַ סובנאָרמאַל.א מאַנטיססאַ פון 0 איז ערלויבט און קאַנסטראַקץ נול.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // קאָדעד עקספּאָנענט איז 0, די צייכן ביסל איז 0, אַזוי מיר נאָר האָבן צו יבערטראַכטן די ביטן.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// דערנענטערנ זיך אַ ביגנום מיט אַ Fp.ראָונדס ין 0.5 ULP מיט האַלב-צו-אפילו.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // מיר שניידן אַוועק אַלע ביטן איידער די אינדעקס קס 00 קס, הייסט, מיר יפעקטיוולי רעכט-יבעררוק מיט אַ סומע פון קס 01 קס, אַזוי דאָס איז אויך דער עקספּאָנענט מיר דאַרפֿן.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // קייַלעכיק קס 00 קס דיפּענדינג אויף די טראַנגקייטיד ביטן.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// טרעפט די גרעסטע פלאָוטינג פונט נומער קלענערער ווי דער אַרגומענט.
/// קען נישט שעפּן סובנאָרמאַלס, נול אָדער עקספּאָנענט אַנדערפלאָו.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// דער קלענסטער פלאָוטינג נומער איז שטרענג גרעסער ווי די אַרגומענט.
// די אָפּעראַציע איז סאַטשערייטינג, הייסט, next_float(inf) ==inf.
// ניט ענלעך די מערסט קאָד אין דעם מאָדולע, די פֿונקציע האַנדלען מיט נול, סובנאָרמאַלס און ינפיניטיעס.
// אָבער, ווי אַלע אנדערע קאָד דאָ, עס קען נישט האַנדלען מיט NaN און נעגאַטיוו נומערן.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // דאָס מיינט צו גוט צו זיין אמת, אָבער עס אַרבעט.
        // 0.0 איז קאָדעד ווי די גאַנץ-נול וואָרט.סובנאָרמאַלס זענען 0 קס 000 ם ... עם ווו m איז די מאַנטיססאַ.
        // אין באַזונדער, דער קלענסטער סובנאָרמאַל איז 0 קס 0 ... 01 און די גרעסטע איז 0 קס 000 ף ... F.
        // דער קלענסטער נאָרמאַל נומער איז 0 קס 0010 ... 0, אַזוי די ווינקל פאַל אַרבעט אויך.
        // אויב די ינקראַמאַנט אָוווערפלאָוז די מאַנטיססאַ, די טראָגן ביסל ינגקראַמאַנץ די עקספּאָנענט ווי מיר וועלן, און די מאַנטיססאַ ביטן ווערן נול.
        // ווייַל פון די פאַרבאָרגן ביסל קאַנווענשאַן, דאָס אויך איז פּונקט וואָס מיר וועלן!
        // לעסאָף, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}