//! וואַלאַדייטינג און דיקאַמפּאָוזינג אַ דעצימאַל שטריקל פון די פאָרעם:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! אין אנדערע ווערטער, נאָרמאַל פלאָוטינג פונט סינטאַקס, מיט צוויי אויסנעמען: קיין צייכן און קיין האַנדלינג פון קס 02 קס און קס 01 קס.די זענען כאַנדאַלד דורך די דרייווער פונקציע (super::dec2flt).
//!
//! כאָטש רעקאַגנייזינג גילטיק ינפּוץ איז לעפיערעך גרינג, דעם מאָדולע אויך האט צו אָפּוואַרפן די קאַונטלאַס פאַרקריפּלט ווערייישאַנז, קיינמאָל ז 0 פּאַניק 0 ז, און דורכפירן סך טשעקס אַז די אנדערע מאַדזשולז פאַרלאָזנ זיך צו נישט ז 0 פּאַניק 0 ז (אָדער לויפן) אין קער.
//!
//! צו מאַכן ענינים ערגער, אַלע וואָס כאַפּאַנז אין אַ איין פאָרן איבער די אַרייַנשרייַב.
//! אַזוי זיין אָפּגעהיט ווען מאַדאַפייינג עפּעס און קאָנטראָלירן די אנדערע מאַדזשולז טאָפּל.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// די טשיקאַווע פּאַרץ פון אַ דעצימאַל שטריקל.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// די דעצימאַל עקספּאָנענט, געראַנטיד צו האָבן ווייניקער ווי 18 דעצימאַל דידזשאַץ.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// טשעקס אויב די אַרייַנשרייַב שטריקל איז אַ גילטיק פלאָוטינג נומער נומער און אויב אַזוי, געפינען די ינטאַגראַל טייל, די בראָכצאָל טייל און דער עקספּאָנענט אין עס.
/// טוט נישט שעפּן וואונדער.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // ניט דידזשאַץ איידער 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // מיר דאַרפן לפּחות איין ציפֿער איידער אָדער נאָך די פונט.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // טריילינג אָפּפאַל נאָך פראַקשאַנאַל טייל
            }
        }
        _ => Invalid, // טריילינג אָפּפאַל נאָך ערשטער ציפֿער שטריקל
    }
}

/// קאַרווז אַוועק דעצימאַל דידזשאַץ אַרויף צו דער ערשטער ניט-ציפֿער כאַראַקטער.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// עקספּאָנענט יקסטראַקשאַן און טעות קאָנטראָלירונג.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // טריילינג אָפּפאַל נאָך עקספּאָנענט
    }
    if number.is_empty() {
        return Invalid; // ליידיק עקספּאָנענט
    }
    // אין דעם פונט, מיר זיכער האָבן אַ גילטיק שטריקל פון דידזשאַץ.עס קען זיין צו לאַנג צו שטעלן אַ `i64`, אָבער אויב עס ס אַזוי ריזיק, די ינפּוט איז אַוואַדע נול אָדער ומענדיקייַט.
    // זינט יעדער נול אין די דעצימאַל דידזשאַץ נאָר אַדזשאַסטיד די עקספּאָנענט דורך +/-1, ביי עקספּ=10 ^ 18, דער אַרייַנשרייַב זאָל זיין 17 עקסאַביטע קס 00 קס פון זעראָס צו באַקומען רימאָוטלי נאָענט צו זיין ענדלעך.
    //
    // דאָס איז נישט פּונקט אַ נוצן פאַל וואָס מיר דאַרפֿן צו באַזאָרגן פֿאַר.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}