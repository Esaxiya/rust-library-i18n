//! נוצן פאַנגקשאַנז פֿאַר ביגנאַמז וואָס טאָן ניט מאַכן צו פיל זינען צו ווערן מעטהאָדס.

// FIXME די נאָמען פון דעם מאָדולע איז אַ ביסל נעבעך, ווייַל אנדערע מאַדזשולז אויך אַרייַנפיר `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// פּרובירן צי טראַנגקייטינג אַלע ביטן ווייניקער באַטייַטיק ווי `ones_place` ינטראַדוסיז אַ קאָרעוו טעות ווייניקער, גלייַך אָדער גרעסער ווי 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // אויב אַלע רוען ביטן זענען נול, עס ס '= 0.5 ULP, אַנדערש> 0.5 אויב עס זענען ניט מער ביטן (האַלב_ביט==0), די אונטן אויך קערט ריכטיק גלייַך.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// קאָנווערט אַ ASCII שטריקל מיט בלויז דעצימאַל דידזשאַץ צו אַ `u64`.
///
/// טוט ניט דורכפירן טשעקס פֿאַר לויפן אָדער פאַרקריפּלט אותיות, אַזוי אויב די קאָלער איז ניט אָפּגעהיט, דער רעזולטאַט איז פאַלש און קענען ז 0 פּאַניק 0 ז (כאָטש עס וועט ניט זיין קס 00 קס).
/// דערצו, ליידיק סטרינגס זענען באהאנדלט ווי נול.
/// די פֿונקציע יגזיסץ ווייַל
///
/// 1. ניצן קס 01 קס אויף קס 02 קס ריקווייערז קס 00 קס, וואָס איז שלעכט, און
/// 2. די רעזולטאַטן פון קס 00 קס און קס 01 קס צוזאַמען צוזאַמען איז מער קאָמפּליצירט ווי די גאנצע פֿונקציע.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// קאָנווערט אַ שטריקל פון ASCII דידזשאַץ אין אַ ביגנום.
///
/// ווי `from_str_unchecked`, די פונקציע איז רילייז אויף די פּאַרסער צו ויסמיידן ניט-דידזשאַץ.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// ונראַפּפּס אַ ביגנום אין אַ 64 גאַנץ ינטאַדזשער.Panics אויב די נומער איז אויך גרויס.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// אויסצוגן אַ קייט פון ביטן.

/// אינדעקס 0 איז דער מינדסטער באַטייטיק ביסל און די קייט איז האַלב-אָפן ווי געוויינטלעך.
/// Panics אויב געבעטן צו עקסטראַקט מער ביטן ווי פּאַסיק אין די צוריקקער טיפּ.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}