//! טעות טייפּס פֿאַר קאַנווערזשאַן צו ינטאַגראַל טייפּס.

use crate::convert::Infallible;
use crate::fmt;

/// דער טעות טיפּ איז אומגעקערט ווען אַ דורכגעקאָכט קאַנווערזשאַן ינטעגראַל קאַנווערזשאַן פיילז.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // גלייכן ווי צווינגען צו מאַכן זיכער אַז קאָד ווי קס 01 קס אויבן וועט האַלטן ארבעטן ווען קס 02 קס ווערט אַ אַליאַס צו קס 00 קס.
        //
        //
        match never {}
    }
}

/// א טעות וואָס קענען זיין אומגעקערט ווען פּאַרסינג אַ גאַנץ נומער.
///
/// דער טעות איז געניצט ווי די טעות טיפּ פֿאַר די `from_str_radix()` פאַנגקשאַנז אויף די פּרימיטיוו ינטאַדזשער טייפּס, אַזאַ ווי [`i8::from_str_radix`].
///
/// # פּאָטענציעל ז
///
/// צווישן אנדערע סיבות, `ParseIntError` קענען זיין ארלנגעווארפן ווייַל פון לידינג אָדער טריילינג ווייַס פּלאַץ אין די שטריקל, למשל, ווען עס איז באקומען פֿון דער נאָרמאַל אַרייַנשרייַב.
///
/// ניצן די [`str::trim()`] אופֿן ינשורז אַז קיין ווייספּייס בלייבט איידער פּאַרסינג.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// ענום צו קראָם די פאַרשידן טייפּס פון ערראָרס וואָס קענען אָנמאַכן פּאַרסינג אַ גאַנץ נומער צו פאַרלאָזן.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// ווערט פּאַרסעד איז ליידיק.
    ///
    /// צווישן אנדערע סיבות, דעם וואַריאַנט וועט זיין קאַנסטראַקטאַד ווען פּאַרסינג אַ ליידיק שטריקל.
    Empty,
    /// כּולל אַ פאַרקריפּלט ציפֿער אין זיין קאָנטעקסט.
    ///
    /// צווישן אנדערע סיבות, דעם וואַריאַנט וועט זיין קאַנסטראַקטאַד ווען פּאַרסינג אַ שטריקל וואָס כּולל אַ ניט-ASCII טשאַר.
    ///
    /// דער וואַריאַנט איז אויך קאַנסטראַקטאַד ווען אַ `+` אָדער `-` איז מיספּלייסט אין אַ שטריקל אויף זיך אָדער אין די מיטל פון אַ נומער.
    ///
    ///
    InvalidDigit,
    /// ינטעגער איז צו גרויס צו קראָם אין ציל ינטאַדזשער טיפּ.
    PosOverflow,
    /// ינטעגער איז צו קליין צו קראָם אין ציל ינטאַדזשער טיפּ.
    NegOverflow,
    /// ווערט איז נול
    ///
    /// דער וואַריאַנט וועט זיין ימיטיד ווען די פּאַרסינג שטריקל האט אַ ווערט פון נול, וואָס איז ומלעגאַל פֿאַר ניט-נול טייפּס.
    ///
    Zero,
}

impl ParseIntError {
    /// רעזולטאַט די דיטיילד גרונט פון פּאַרסינג אַ ינטאַדזשער דורכפאַל.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}