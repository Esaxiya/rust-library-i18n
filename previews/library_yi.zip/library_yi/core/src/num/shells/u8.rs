//! קאַנסטאַנץ פֿאַר די 8-ביסל אַנסיינד ינטאַדזשער טיפּ.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! ניו קאָד זאָל נוצן די פארבונדן קאַנסטאַנץ גלייַך אויף די פּרימיטיוו טיפּ.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }