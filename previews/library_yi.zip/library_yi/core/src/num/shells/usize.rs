//! קאָנסטאַנץ פֿאַר די טייַטל-אַנסיינד ינטאַדזשער טיפּ סייזד.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! ניו קאָד זאָל נוצן די פארבונדן קאַנסטאַנץ גלייַך אויף די פּרימיטיוו טיפּ.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }