//! כּמעט דירעקט (אָבער אַ ביסל אָפּטימיזעד) ז 0 רוסט 0 ז איבערזעצונג פון פיגורע 3 פון "פּרינטינג פלאָוטינג-פונט נומערן געשווינד און אַקיעראַטלי" [^ 1].
//!
//!
//! [^1]: Burger, RG and Dybvig, RK 1996. פּרינטינג פלאָוטינג-נומערן
//!   געשווינד און אַקיעראַטלי.סיגפּלאַן נישט.31, 5 (מאי. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// פּרעקאַלקולאַטעד ערייז פון `Digit`s פֿאַר 10 ^ (2 ^ N)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// בלויז ניצלעך ווען קס 01 קס;`scaleN` זאָל זיין `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// די שאָרטיסט מאָדע ימפּלאַמענטיישאַן פֿאַר דראַגאָן.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // די נומער `v` צו פֿאָרמאַט איז באַוווסט צו זיין:
    // - גלייַך צו קס 00 קס;
    // - פּריסטיד דורך `(mant - 2 *minus)* 2^exp` אין דער אָריגינעל טיפּ;און
    // - נאכגעגאנגען דורך `(mant + 2 *plus)* 2^exp` אין דער אָריגינעל טיפּ.
    //
    // דאָך, `minus` און `plus` קענען נישט זיין נול.(פֿאַר ינפיניטיעס, מיר נוצן וואַלועס וואָס זענען נישט-פון-קייט.) מיר אויך יבערנעמען אַז אין מינדסטער איין ציפֿער איז דזשענערייטאַד, דאָס הייסט, `mant` קען נישט זיין נול אויך.
    //
    // דאָס אויך מיטל אַז קיין נומער צווישן קס 00 קס און קס 01 קס וועט מאַפּ צו דעם פּינטלעך פלאָוטינג נומער נומער, מיט גווול ינקלודעד ווען די אָריגינעל מאַנטיססאַ איז געווען גלייך (ד"ה, קס 02 קס).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` איז קס 00 קס
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // אָפּשאַצן קס 01 קס פֿון אָריגינעל ינפּוץ סאַטיספייינג קס 00 קס.
    // די ענג געבונדן קס 00 קס סאַטיספייינג קס 01 קס איז שפּעטער קאַלקיאַלייטיד.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // גער `{mant, plus, minus} * 2^exp` אין די פראַקשאַנאַל פאָרעם אַזוי אַז:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // טיילן `mant` דורך `10^k`.איצט `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // פיקסאַפּ ווען `mant + plus > scale` (אָדער `>=`).
    // מיר טאָן ניט מאַדאַפייינג `scale`, ווייַל מיר קענען האָפּקען די ערשט קייפל אַנשטאָט.
    // איצט קס 00 קס און מיר זענען גרייט צו דזשענערייט דידזשאַץ.
    //
    // טאָן אַז קס 01 קס *קענען* זיין נול ווען קס 00 קס.
    // אין דעם פאַל, רונדינג-אַרויף צושטאַנד (קס 00 קס ווייטער) וועט זיין טריגערד מיד.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // עקוויוואַלענט צו סקיילינג קס 00 קס דורך 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // קאַש קס 00 קס פֿאַר ציפֿער דור.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // ינוואַריאַנץ, ווו `d[0..n-1]` זענען דידזשאַץ ביז איצט:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (אַזוי קס 01 קס) ווו קס 00 קס איז אַ סטענאָגראַפיע פֿאַר `ד [איך] * 10 ^ (דזשי) + ...
        // + ד [דזש-1] * 10 + קס 00 קס.

        // דזשענערייט איין ציפֿער: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // דאָס איז אַ סימפּלאַפייד באַשרייַבונג פון די מאַדאַפייד דראַגאָן אַלגערידאַם.
        // פילע ינטערמידייט דעריוואַטיאָנס און קאַמפּליטנאַס טענות זענען איבערגעהיפּערט פֿאַר קאַנוויניאַנס.
        //
        // אָנהייבן מיט מאַדאַפייד ינוועריאַנץ, ווייַל מיר האָבן דערהייַנטיקט `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // יבערנעמען אַז `d[0..n-1]` איז די שאָרטיסט פאַרטרעטונג צווישן `low` און `high`, דאָס הייסט, `d[0..n-1]` סאַטיספייז ביידע פון די פאלגענדע, אָבער `d[0..n-2]` קען נישט:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (בייעקטיוויטי: דידזשאַץ קייַלעכיק צו קס 00 קס);און
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (די לעצטע ציפֿער איז ריכטיק).
        //
        // די רגע צושטאַנד סימפּלאַפייז צו קס 00 קס.
        // סאַלווינג ינוואַריאַנץ אין טערמינען פון קס 00 קס, קס 01 קס און קס 02 קס גיט אַ סימפּלער ווערסיע פון דער ערשטער צושטאַנד: `-plus < mant < minus`.
        // זינט קס 01 קס, מיר האָבן די ריכטיק שאָרטיסט פאַרטרעטונג ווען קס 02 קס און קס 00 קס.
        // (די ערשטע ווערט `mant <= minus` ווען די אָריגינעל מאַנטיססאַ איז גלייך.)
        //
        // ווען די רגע קען נישט האַלטן (`2 * מאַנט> וואָג '), מיר דאַרפֿן צו פאַרגרעסערן די לעצטע ציפֿער.
        // דאָס איז גענוג פֿאַר ריסטאָרינג די צושטאַנד: מיר וויסן שוין אַז די ציפֿער דור געראַנטיז קס 00 קס.
        // אין דעם פאַל, דער ערשטער צושטאַנד ווערט `-plus < mant - scale < minus`.
        // זינט קס 01 קס נאָך דעם דור, מיר האָבן קס 00 קס.
        // (ווידער, דאָס ווערט `scale <= mant + plus` ווען די אָריגינעל מאַנטיססאַ איז גלייך.)
        //
        // אין קורצן:
        // - האַלטן `down` (האַלטן דידזשאַץ ווי עס איז) ווען `mant < minus` (אָדער `<=`).
        // - האַלטן `up` (פאַרגרעסערן די לעצטע ציפֿער) ווען `scale < mant + plus` (אָדער `<=`).
        // - האַלטן דזשענערייטינג אַנדערש.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // מיר האָבן די שאָרטיסט פאַרטרעטונג, גיינ ווייַטער צו די ראַונדינג

        // ומקערן די ינוואַריאַנץ.
        // דאָס מאכט אַלגערידאַם שטענדיק פאַרענדיקן: קס 00 קס און קס 01 קס ינקריסיז שטענדיק, אָבער קס 02 קס איז קליפּט מאָדולאָ קס 03 קס און קס 04 קס איז פאַרפעסטיקט.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ראָונדינג אַרויף כאַפּאַנז ווען i) בלויז די ראַונדינג-אַרויף צושטאַנד איז געווען טריגערד, אָדער ii) ביידע טנאָים זענען טריגערד און בונד ברייקינג פּראַפערז ראַונדינג אַרויף.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // אויב די ראָונדינג אַרויף ענדערונגען די לענג, דער עקספּאָנענט זאָל אויך טוישן.
        // עס מיינט אַז דער צושטאַנד איז זייער שווער צו באַפרידיקן (עפשער אוממעגלעך), אָבער מיר זענען פּונקט זיכער און קאָנסיסטענט דאָ.
        //
        // זיכערהייט: מיר האָבן דעם ערשטן זיקאָרן איניציאליזירט.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // זיכערהייט: מיר האָבן דעם ערשטן זיקאָרן איניציאליזירט.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// די פּינטלעך און פאַרפעסטיקט מאָדע ימפּלאַמענטיישאַן פֿאַר דראַגאָן.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // אָפּשאַצן קס 01 קס פֿון אָריגינעל ינפּוץ סאַטיספייינג קס 00 קס.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // טיילן `mant` דורך `10^k`.איצט `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // פיקסאַפּ ווען קס 01 קס, ווו קס 00 קס.
    // אין סדר צו האַלטן די פאַרפעסטיקט ביגנום, מיר טאַקע נוצן `mant + floor(plus) >= scale`.
    // מיר טאָן ניט מאַדאַפייינג `scale`, ווייַל מיר קענען האָפּקען די ערשט קייפל אַנשטאָט.
    // ווידער מיט די שאָרטיסט אַלגערידאַם, `d[0]` קענען זיין נול אָבער יווענטשאַוואַלי זיין ראַונדיד.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // עקוויוואַלענט צו סקיילינג קס 00 קס דורך 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // אויב מיר אַרבעטן מיט די לעצטע-ציפֿער באַגרענעצונג, מיר דאַרפֿן צו פאַרקירצן די באַפער איידער די פאַקטיש רענדערינג צו ויסמיידן טאָפּל ראָונדינג.
    //
    // טאָן אַז מיר האָבן צו פאַרגרעסערן די באַפער ווידער ווען ראַונדינג אַרויף כאַפּאַנז!
    let mut len = if k < limit {
        // אָאָפּס, מיר קענען נישט אפילו פּראָדוצירן *איין* ציפֿער.
        // דאָס איז מעגלעך ווען מיר זאָגן עפּעס ווי 9.5 און עס איז ראַונדיד צו 10.
        // מיר צוריקקומען אַ ליידיק באַפער, מיט אַ ויסנעם פון די שפּעטער קייַלעכיק-אַרויף פאַל וואָס אַקערז ווען `k == limit` און מוזן פּראָדוצירן פּונקט איין ציפֿער.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // קאַש קס 00 קס פֿאַר ציפֿער דור.
        // (דאָס קען זיין טייַער, אַזוי טאָן ניט רעכענען זיי ווען די באַפער איז ליידיק.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ווייַטערדיק דידזשאַץ זענען אַלע זעראָעס, מיר האַלטן דאָ טאָן ניט פּרוּווט צו דורכפירן ראַונדינג!אלא, פּלאָמבירן רוען דידזשאַץ.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // זיכערהייט: מיר האָבן דעם ערשטן זיקאָרן איניציאליזירט.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // אויב מיר האַלטן אין די דידזשאַץ אויב די ווייַטערדיקע דידזשאַץ זענען פּונקט 5000, קאָנטראָלירן די פריערדיקן ציפֿער און פּרובירן צו קייַלעכיק צו גלייך (י.ע. ויסמיידן די ראָונדינג אַרויף ווען די פריערדיקע ציפֿער איז גלייך).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // זיכערקייט: קס 00 קס איז ינישאַלייזד.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // אויב די ראָונדינג אַרויף ענדערונגען די לענג, דער עקספּאָנענט זאָל אויך טוישן.
        // אָבער מיר האָבן שוין געבעטן אַ פאַרפעסטיקט נומער פון דידזשאַץ, אַזוי טאָן ניט טוישן די באַפער ...
        // זיכערהייט: מיר האָבן דעם ערשטן זיקאָרן איניציאליזירט.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... סיידן מיר האָבן שוין פארלאנגט די פאַרפעסטיקט פּינטלעכקייַט אַנשטאָט.
            // מיר אויך דאַרפֿן צו קאָנטראָלירן אַז אויב דער אָריגינעל באַפער איז ליידיק, די נאָך ציפֿער קענען זיין מוסיף בלויז ווען `k == limit` (edge פאַל).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // זיכערהייט: מיר האָבן דעם ערשטן זיקאָרן איניציאליזירט.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}