//! דעקאָדעס אַ פלאָוטינג פונט ווערט אין יחיד פּאַרץ און טעות ריינדזשאַז.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// דיקאָודאַד אַנסיינד ענדלעך ווערט, אַזאַ ווי:
///
/// - דער אָריגינעל ווערט יקוואַלז `mant * 2^exp`.
///
/// - קיין נומער פון קס 00 קס צו קס 01 קס וועט קייַלעכיק צו דער אָריגינעל ווערט.
/// די קייט איז ינקלוסיוו בלויז ווען `inclusive` איז `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// די סקיילד מאַנטיסאַ.
    pub mant: u64,
    /// דער נידעריקער טעות קייט.
    pub minus: u64,
    /// דער אויבערשטער טעות קייט.
    pub plus: u64,
    /// די שערד עקספּאָנענט אין באַזע 2.
    pub exp: i16,
    /// אמת ווען די טעות קייט איז ינקלוסיוו.
    ///
    /// אין IEEE 754, דאָס איז אמת ווען די אָריגינעל מאַנטיססאַ איז געווען גלייך.
    pub inclusive: bool,
}

/// דעקאָדעד אַנסיינד ווערט.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// ינפיניטיעס, אָדער positive אָדער נעגאַטיוו.
    Infinite,
    /// נול, positive אָדער נעגאַטיוו.
    Zero,
    /// ענדלעך נומערן מיט ווייַטער דיקאָודאַד פעלדער.
    Finite(Decoded),
}

/// א טיפּ פון פלאָוטינג פונט וואָס קענען זיין 'דעקאָדע' ד.
pub trait DecodableFloat: RawFloat + Copy {
    /// די מינימום positive נאָרמאַלייזד ווערט.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// קערט אַ צייכן (אמת ווען נעגאַטיוו) און `FullDecoded` ווערט פון די פלאָוטינג נומער.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // שכנים: (מאַנט, 2, עקספּ)-(מאַנט, עקספּ)-(מאַנט + 2, עקספּ)
            // Float::integer_decode שטענדיק ייַנגעמאַכץ די עקספּאָנענט, אַזוי די מאַנטיססאַ איז סקיילד פֿאַר סובנאָרמאַלס.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // שכנים: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ווו maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // שכנים: (מאַנט, 1, עקספּ)-(מאַנט, עקספּ)-(מאַנט + 1, עקספּ)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}