//! קעסיידערדיק קאַנסטאַנץ פֿאַר די קס 00 קס איין-פּינטלעכקייַט פלאָוטינג פונט טיפּ.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! מאַטאַמאַטיקאַללי באַטייטיק נומערן זענען צוגעשטעלט אין די `consts` סאַב-מאָדולע.
//!
//! פֿאַר די קאַנסטאַנץ וואָס זענען דיפיינד גלייַך אין דעם מאָדולע (אַנדערש פון די וואָס זענען דיפיינד אין די `consts` סאַב-מאָדולע), נייַ קאָד זאָל אַנשטאָט נוצן די פארבונדן קאַנסטאַנץ וואָס זענען דיפיינד גלייַך אויף די קס 01 קס טיפּ.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// די ראַדיקס אָדער באַזע פון די ינערלעך פאַרטרעטונג פון `f32`.
/// ניצן אַנשטאָט [`f32::RADIX`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // בדעה וועג
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// נומער פון באַטייטיק דידזשאַץ אין באַזע 2.
/// ניצן אַנשטאָט [`f32::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // בדעה וועג
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// דערנענטערנ נומער פון באַטייטיק דידזשאַץ אין באַזע 10.
/// ניצן אַנשטאָט [`f32::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // בדעה וועג
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] ווערט פֿאַר קס 00 קס.
/// ניצן אַנשטאָט [`f32::EPSILON`].
///
/// דאָס איז די חילוק צווישן `1.0` און די ווייַטער גרעסערע רעפּריזענטאַבאַל נומער.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // בדעה וועג
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// קלענסטער ענדלעך קס 00 קס ווערט.
/// ניצן אַנשטאָט [`f32::MIN`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // בדעה וועג
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// קלענסטער positive נאָרמאַל קס 00 קס ווערט.
/// ניצן אַנשטאָט [`f32::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // בדעה וועג
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// גרעסטע ענדלעך `f32` ווערט.
/// ניצן אַנשטאָט [`f32::MAX`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // בדעה וועג
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// איינער גרעסער ווי די מינימום מעגלעך נאָרמאַל מאַכט פון 2 עקספּאָנענט.
/// ניצן אַנשטאָט [`f32::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // בדעה וועג
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// מאַקסימום מעגלעך מאַכט פון 2 עקספּאָנענט.
/// ניצן אַנשטאָט [`f32::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // בדעה וועג
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// מינימום מעגלעך נאָרמאַל מאַכט פון 10 עקספּאָנענט.
/// ניצן אַנשטאָט [`f32::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // בדעה וועג
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// מאַקסימום מעגלעך מאַכט פון 10 עקספּאָנענט.
/// ניצן אַנשטאָט [`f32::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // בדעה וועג
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// ניט אַ נומער קס 00 קס.
/// ניצן אַנשטאָט [`f32::NAN`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // בדעה וועג
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// ומענדיקייַט קס 00 קס.
/// ניצן אַנשטאָט [`f32::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // בדעה וועג
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// נעגאַטיוו ומענדיקייַט קס 00 קס.
/// ניצן אַנשטאָט [`f32::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // אָפּגעלאָזן וועג
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // בדעה וועג
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// יקערדיק מאַטאַמאַטיקאַל קאַנסטאַנץ.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: פאַרבייַטן מיט מאַטאַמאַטיקאַל קאַנסטאַנץ פֿון cmath.

    /// אַרטשימעדעס 'קעסיידערדיק קס 00 קס
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// די פול קרייַז קעסיידערדיק קס 00 קס
    ///
    /// גלייַך צו 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// עולער ס נומער קס 00 קס
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// די ראַדיקס אָדער באַזע פון די ינערלעך פאַרטרעטונג פון `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// נומער פון באַטייטיק דידזשאַץ אין באַזע 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// דערנענטערנ נומער פון באַטייטיק דידזשאַץ אין באַזע 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] ווערט פֿאַר קס 00 קס.
    ///
    /// דאָס איז די חילוק צווישן `1.0` און די ווייַטער גרעסערע רעפּריזענטאַבאַל נומער.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// קלענסטער ענדלעך קס 00 קס ווערט.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// קלענסטער positive נאָרמאַל קס 00 קס ווערט.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// גרעסטע ענדלעך `f32` ווערט.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// איינער גרעסער ווי די מינימום מעגלעך נאָרמאַל מאַכט פון 2 עקספּאָנענט.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// מאַקסימום מעגלעך מאַכט פון 2 עקספּאָנענט.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// מינימום מעגלעך נאָרמאַל מאַכט פון 10 עקספּאָנענט.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// מאַקסימום מעגלעך מאַכט פון 10 עקספּאָנענט.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// ניט אַ נומער קס 00 קס.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// ומענדיקייַט קס 00 קס.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// נעגאַטיוו ומענדיקייַט קס 00 קס.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// קערט `true` אויב די ווערט איז `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): קס 00 קס איז עפנטלעך אַנאַוויילאַבאַל אין ליבקאָרע ווייַל פון קאַנסערנז וועגן פּאָרטאַביליטי, אַזוי די ימפּלאַמענטיישאַן איז פֿאַר פּריוואַט נוצן ינעווייניק.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// קערט `true` אויב די ווערט איז positive ומענדיקייַט אָדער נעגאַטיוו ומענדיקייַט, און `false` אַנדערש.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// קערט קס 01 קס אויב די נומער איז ניט ינפאַנאַט אדער קס 00 קס.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // עס איז ניט דאַרפֿן צו האַנדלען מיט NaN סעפּעראַטלי: אויב זיך איז NaN, די פאַרגלייַך איז נישט אמת, פּונקט ווי געוואלט.
        //
        self.abs_private() < Self::INFINITY
    }

    /// קערט `true` אויב די נומער איז [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // וואַלועס צווישן קס 00 קס און קס 01 קס זענען סובנאָרמאַל.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// קערט `true` אויב די נומער איז ניט נול, Infinite, [subnormal] אָדער `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // וואַלועס צווישן קס 00 קס און קס 01 קס זענען סובנאָרמאַל.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// קערט די פלאָוטינג פונט קאַטעגאָריע פון די נומער.
    /// אויב בלויז איין פאַרמאָג וועט זיין טעסטעד, עס איז בכלל פאַסטער צו נוצן די ספּעציפיש פּרעדיקאַט אַנשטאָט.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// קערט `true` אויב `self` האט אַ positive צייכן, אַרייַנגערעכנט `+0.0`, `NaN`s מיט positive צייכן ביסל און positive ומענדיקייַט.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// קערט `true` אויב `self` האט אַ נעגאַטיוו צייכן, אַרייַנגערעכנט `-0.0`, `NaN`s מיט נעגאַטיוו צייכן ביסל און נעגאַטיוו ומענדיקייַט.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 זאגט: קס 00 קס איז אמת אויב און נאָר אויב קס האט נעגאַטיוו צייכן.
        // יססיגמינוס אַפּלייז אויך צו זעראָס און נאַנס.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// נעמט די קעגנאַנאַנדיק קס 00 קס פון אַ נומער, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// קאָנווערט ראַדיאַנס צו דיגריז.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // ניצן אַ קעסיידערדיק פֿאַר בעסער פּינטלעכקייַט.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// קאַנווערץ דיגריז צו ראַדיאַנס.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// רעטורנס די מאַקסימום פון די צוויי נומערן.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// אויב איינער פון די אַרגומענטן איז NaN, די אנדערע אַרגומענט איז אומגעקערט.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// רעטורנס די מינימום פון די צוויי נומערן.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// אויב איינער פון די אַרגומענטן איז NaN, די אנדערע אַרגומענט איז אומגעקערט.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// ראָונדס צו נול און קאַנווערץ צו קיין פּרימיטיוו ינטאַדזשער טיפּ, אַסומינג אַז די ווערט איז ענדלעך און פיץ אין דעם טיפּ.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// די ווערט מוזן:
    ///
    /// * ניט זיין קס 00 קס
    /// * ניט זיין ינפאַנאַט
    /// * זיין רעפּראַזענטאַבאַל אין די צוריקקומען טיפּ `Int`, נאָך ויסמיידן זיין פראַקשאַנאַל טייל
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// רוי טראַנסמוטאַטיאָן צו קס 00 קס.
    ///
    /// דאָס איז דערווייַל יידעניקאַל צו קס 00 קס אויף אַלע פּלאַטפאָרמס.
    ///
    /// זען `from_bits` פֿאַר עטלעכע דיסקוסיעס וועגן די טראַנספּאָרטאַביליטי פון די אָפּעראַציע (עס זענען כּמעט קיין ישוז).
    ///
    /// באַמערקונג אַז די פֿונקציע איז אַנדערש פון `as` קאַסטינג, וואָס פּרווון צו ופהיטן די *נומעריק* ווערט און נישט די ביטווייז ווערט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() איז נישט קאַסטינג!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // זיכערהייט: קס 00 קס איז אַ קלאָר אַלט דאַטייפּ, אַזוי מיר קענען שטענדיק יבערמאַכן צו אים
        unsafe { mem::transmute(self) }
    }

    /// רוי טראַנסמוטאַטיאָן פֿון `u32`.
    ///
    /// דאָס איז דערווייַל יידעניקאַל צו קס 00 קס אויף אַלע פּלאַטפאָרמס.
    /// עס טורנס אויס אַז עס איז ינקרעדאַבלי פּאָרטאַטיוו פֿאַר צוויי סיבות:
    ///
    /// * פלאָוץ און ינטס האָבן די זעלבע ענדיינאַס אויף אַלע שטיצט פּלאַטפאָרמס.
    /// * IEEE-754 ספּעציפיצירט די ביסל אויסלייג פון פלאָוץ.
    ///
    /// אָבער, עס איז איין קייוויאַט: איידער די 2008 ווערסיע פון IEEE-754, ווי אַזוי צו טייַטשן די NaN סיגנאַלינג ביסל איז נישט פאקטיש ספּעסאַפייד.
    /// רובֿ פּלאַטפאָרמס (נאָוטאַלי x86 און ARM) פּיקט די ינטערפּריטיישאַן וואָס איז לעסאָף סטאַנדערדייזד אין 2008, אָבער עטלעכע נישט (נאָוטאַבלי מיפּס).
    /// דעריבער, אַלע סיגנאַלינג נאַנס אויף קס 01 קס זענען שטיל נאַנס אויף קס 00 קס, און וויצע ווערסאַ.
    ///
    /// אלא ווי טריינג צו ופהיטן די סיגנאַלינג-נעס קרייַז-פּלאַטפאָרמע, די ימפּלאַמענטיישאַן פאַוואָרס פּרעזערווינג די פּינטלעך ביטן.
    /// דעם מיטל אַז קיין פּיילאָודז וואָס זענען קאָדעד אין NaNs וועט זיין אפגעהיט אפילו אויב דער רעזולטאַט פון דעם אופֿן איז געשיקט איבער די נעץ פון אַ x86 מאַשין צו אַ MIPS.
    ///
    ///
    /// אויב די רעזולטאַטן פון דעם אופֿן זענען בלויז מאַניפּיאַלייטיד דורך די זעלבע אַרקאַטעקטשער אַז זיי געשאפן, עס איז קיין זאָרג פון פּאָרטאַביליטי.
    ///
    /// אויב די ינפּוט איז נישט NaN, עס איז קיין זאָרג פֿאַר פּאָרטאַביליטי.
    ///
    /// אויב איר טאָן ניט זאָרגן וועגן סיגנאַלינגנעסס (זייער מסתּמא), עס איז קיין זאָרג פֿאַר פּאָרטאַביליטי.
    ///
    /// באַמערקונג אַז די פֿונקציע איז אַנדערש פון `as` קאַסטינג, וואָס פּרווון צו ופהיטן די *נומעריק* ווערט און נישט די ביטווייז ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // זיכערהייט: קס 00 קס איז אַ קלאָר אַלט דאַטייפּ, אַזוי מיר קענען שטענדיק יבערשיקן פון אים
        // עס טורנס אויס אַז די זיכערקייט ישוז מיט sNaN זענען אָוווערבלאָון!האָאָרייַ!
        unsafe { mem::transmute(v) }
    }

    /// ווייַזן די זיקאָרן פאַרטרעטונג פון דעם פלאָוטינג נומער נומער ווי אַ בייט מענגע אין גרויס-אַנדיאַן קס 00 קס ביטע סדר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// ווייַזן די זיקאָרן פאַרטרעטונג פון דעם פלאָוטינג נומער נומער ווי אַ בייט מענגע אין ביסל-ענדייאַן בייטן סדר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// צוריקקומען די זכּרון פאַרטרעטונג פון דעם פלאָוטינג נומער נומער ווי אַ בייט מענגע אין געבוירן בייט סדר.
    ///
    /// ווי די געבוירן ענדייאַנעסס פון די ציל פּלאַטפאָרמע איז געניצט, פּאָרטאַטיוו קאָד זאָל נוצן [`to_be_bytes`] אָדער [`to_le_bytes`], ווי צונעמען, אַנשטאָט.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// צוריקקומען די זכּרון פאַרטרעטונג פון דעם פלאָוטינג נומער נומער ווי אַ בייט מענגע אין געבוירן בייט סדר.
    ///
    ///
    /// [`to_ne_bytes`] זאָל זיין בילכער איבער דעם ווען מעגלעך.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // זיכערקייט: קס 00 קס איז אַ קלאָר אַלט דאַטע טיפּ, אַזוי מיר קענען שטענדיק יבערמאַכן צו אים
        unsafe { &*(self as *const Self as *const _) }
    }

    /// שאַפֿן אַ פלאָוטינג ווערט פון זיין פאַרטרעטונג ווי אַ בייט מענגע אין גרויס אַנדיאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// שאַפֿן אַ פלאָוטינג פונט ווערט פון זיין פאַרטרעטונג ווי אַ בייט מענגע אין קליין ענדיאַן.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// שאַפֿן אַ פלאָוטינג פונט ווערט פון זיין פאַרטרעטונג ווי אַ בייט מענגע אין געבוירן ענדיאַן.
    ///
    /// ווי די געבוירן ענדייאַנעסס פון די ציל פּלאַטפאָרמע איז געניצט, פּאָרטאַטיוו קאָד מיסטאָמע וויל צו נוצן [`from_be_bytes`] אָדער [`from_le_bytes`], ווי געהעריק אַנשטאָט.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// קערט אַ אָרדערינג צווישן זיך און אנדערע וואַלועס.
    /// ניט ענלעך די נאָרמאַל פּאַרטיייש פאַרגלייַך צווישן פלאָוטינג נומערן, די פאַרגלייַך שטענדיק פּראָדוצירן אַ אָרדערינג אין לויט מיט די גאַנץ אָרדער פּרעדיקאַט ווי דיפיינד אין די פלאָוטינג פונט נאָרמאַל IEEE 754 (2008 רעוויזיע).
    /// די וואַלועס זענען אָרדערד אין די פאלגענדע סדר:
    /// - נעגאַטיוו שטיל נאַ
    /// - נעגאַטיוו סיגנאַלינג NaN
    /// - נעגאַטיוו ומענדיקייַט
    /// - נעגאַטיוו נומערן
    /// - נעגאַטיוו סובנאָרמאַל נומערן
    /// - נעגאַטיוו נול
    /// - Positive נול
    /// - Positive סובנאָרמאַל נומערן
    /// - Positive נומערן
    /// - Positive ומענדיקייַט
    /// - Positive סיגנאַלינג NaN
    /// - Positive שטיל נאַ
    ///
    /// באַמערקונג אַז די פֿונקציע קען נישט שטענדיק שטימען צו די [`PartialOrd`] און [`PartialEq`] ימפּלאַמענטיישאַנז פון `f32`.אין באַזונדער, זיי באַטראַכטן נעגאַטיוו און positive נול ווי גלייַך, בשעת קס 03 קס איז נישט.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // אין פאַל פון נעגאַטיוועס, פליפּ אַלע די ביטן אַחוץ דעם צייכן צו דערגרייכן אַן ענלעך אויסלייג ווי צוויי ס קאָמפּלעמענט ינטאַדזשערז
        //
        // פארוואס אַרבעט דאָס?IEEE 754 פלאָוץ באַשטייט פון דריי פעלדער:
        // צייכן ביסל, עקספּאָנענט און מאַנטיססאַ.די סכום פון עקספּאָנענט און מאַנטיססאַ פעלדער ווי אַ גאַנץ האָבן די פאַרמאָג אַז זייער ביטווייז סדר איז גלייַך צו די נומעריק מאַגנאַטוד ווו די מאַגנאַטוד איז דיפיינד.
        // די מאַגנאַטוד איז נישט נאָרמאַלי דיפיינד אויף נאַן וואַלועס, אָבער IEEE 754 גאַנץ סדר דיפיינז די נאַן וואַלועס צו נאָכפאָלגן די ביטווייז סדר.דאָס פירט צו סדר דערקלערט אין דעם דאָק קאָמענטאַר.
        // אָבער, די פאַרטרעטונג פון מאַגנאַטוד איז די זעלבע פֿאַר נעגאַטיוו און positive נומערן-בלויז די צייכן ביסל איז אַנדערש.
        // צו לייכט פאַרגלייכן די פלאָוץ ווי געחתמעט ינטאַדזשערז, מיר דאַרפֿן צו פליען די עקספּאָנענט און מאַנטיססאַ ביטן אין פאַל פון נעגאַטיוו נומערן.
        // מיר קאַנווערץ יפעקטיוולי די נומערן צו "two's complement" פאָרעם.
        //
        // צו מאַכן די פליפּינג, מיר בויען אַ מאַסקע און XOR קעגן אים.
        // מיר רעכענען אַ קס 00 קס מאַסקע פון נעגאַטיוו-געחתמעט וואַלועס: רעכט שיפטינג צייכן-יקסטענדז די ינטאַדזשער, אַזוי מיר קס 01 קס די מאַסקע מיט צייכן ביטן, און דעמאָלט גער צו ונסיגנעד צו שטופּן איין נול ביסל.
        //
        // אויף positive וואַלועס, די מאַסקע איז אַלע זעראָס, אַזוי עס איז אַ ניט-אָפּ.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// באַגרענעצן אַ ווערט צו אַ זיכער מעהאַלעך סייַדן עס איז NaN.
    ///
    /// קערט קס 02 קס אויב קס 03 קס איז גרעסער ווי קס 01 קס, און קס 04 קס אויב קס 05 קס איז ווייניקער ווי קס 00 קס.
    /// אַנדערש דעם קערט `self`.
    ///
    /// באַמערקונג אַז די פֿונקציע קערט נאַן אויב די ערשטע ווערט איז אויך נאַ.
    ///
    /// # Panics
    ///
    /// Panics אויב `min > max`, `min` איז NaN, אָדער `max` איז NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}