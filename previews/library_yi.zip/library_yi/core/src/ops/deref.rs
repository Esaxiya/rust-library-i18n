/// געוויינט פֿאַר ימיוטאַבאַל דערפערענסינג אַפּעריישאַנז ווי קס 00 קס.
///
/// אין אַדישאַן צו זיין געוויינט פֿאַר יקספּליסאַט דערפערענסינג אַפּעריישאַנז מיט די (unary) קס 02 קס אָפּעראַטאָר אין ימיוטאַבאַל קאַנטעקסץ, קס 00 קס איז אויך ימפּליסאַטלי געניצט דורך די קאַמפּיילער אין פילע צושטאנדן.
/// דעם מעקאַניזאַם איז גערופֿן קס 00 קס.
/// אין מיוטאַבאַל קאַנטעקסץ, [`DerefMut`] איז געניצט.
///
/// ימפּלאַמענינג קס 01 קס פֿאַר קלוג פּוינטערז מאכט אַקסעס די דאַטן הינטער זיי באַקוועם, וואָס איז וואָס זיי ינסטרומענט קס 00 קס.
/// אויף די אנדערע האַנט, די כּללים וועגן קס 00 קס און קס 01 קס זענען דיזיינד ספּאַסיפיקלי צו אַקאַמאַדייט קלוג פּוינטערז.
/// צוליב דעם,**`Deref` זאָל זיין ימפּלאַמענאַד בלויז פֿאַר קלוג פּוינטערז** צו ויסמיידן צעמישונג.
///
/// פֿאַר ענלעך סיבות,**די trait זאָל קיינמאָל פאַרלאָזן**.דורכפאַל בעשאַס דערפערענסינג קענען זיין גאָר קאַנפיוזינג ווען `Deref` איז ינוואָוקט ימפּליסאַטלי.
///
/// # מער וועגן `Deref` געצווונגען
///
/// אויב קס 02 קס ימפּלאַמאַנץ קס 00 קס, און קס 03 קס איז אַ ווערט פון טיפּ קס 01 קס, דעמאָלט:
///
/// * אין ימיוטאַבאַל קאַנטעקסץ, `*x` (ווו `T` איז ניט אַ רעפֿערענץ און נישט אַ רוי טייַטל) איז עקוויוואַלענט צו `* Deref::deref(&x)`.
/// * וואַלועס פון טיפּ קס 01 קס זענען געצווונגען צו וואַלועס פון טיפּ קס 00 קס
/// * `T` ימפּליסאַטלי ימפּלאַמענאַד אַלע די קס 01 קס מעטהאָדס פון דעם טיפּ קס 00 קס.
///
/// פֿאַר מער דעטאַילס, [the chapter in *The Rust Programming Language*][book] ווי געזונט ווי די רעפֿערענץ סעקשאַנז אויף [the dereference operator][ref-deref-op], [method resolution] און [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// א סטרוקטור מיט אַ איין פעלד וואָס איז צוטריטלעך דורך דערפערענסינג די סטרוקטור.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// די ריזאַלטינג טיפּ נאָך דערפערענסינג.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// דערפערענסעס די ווערט.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// געוויינט פֿאַר מיוטאַבאַל דערפערענסינג אַפּעריישאַנז, ווי אין `*v = 1;`.
///
/// אין אַדישאַן צו זיין געוויינט פֿאַר יקספּליסאַט דערפערענסינג אַפּעריישאַנז מיט די (unary) קס 02 קס אָפּעראַטאָר אין מיוטאַבאַל קאַנטעקסץ, די `DerefMut` איז אויך ימפּליסאַטלי געניצט דורך די קאַמפּיילער אין פילע צושטאנדן.
/// דעם מעקאַניזאַם איז גערופֿן קס 00 קס.
/// אין ימיוטאַבאַל קאַנטעקסץ, [`Deref`] איז געניצט.
///
/// ימפּלאַמענינג קס 01 קס פֿאַר קלוג פּוינטערז מאכט מיוטינג די דאַטן הינטער זיי באַקוועם, וואָס איז וואָס זיי ינסטרומענט קס 00 קס.
/// אויף די אנדערע האַנט, די כּללים וועגן קס 00 קס און קס 01 קס זענען דיזיינד ספּאַסיפיקלי צו אַקאַמאַדייט קלוג פּוינטערז.
/// צוליב דעם,**`DerefMut` זאָל זיין ימפּלאַמענאַד בלויז פֿאַר קלוג פּוינטערז** צו ויסמיידן צעמישונג.
///
/// פֿאַר ענלעך סיבות,**די trait זאָל קיינמאָל פאַרלאָזן**.דורכפאַל בעשאַס דערפערענסינג קענען זיין גאָר קאַנפיוזינג ווען `DerefMut` איז ינוואָוקט ימפּליסאַטלי.
///
/// # מער וועגן `Deref` געצווונגען
///
/// אויב קס 02 קס ימפּלאַמאַנץ קס 00 קס, און קס 03 קס איז אַ ווערט פון טיפּ קס 01 קס, דעמאָלט:
///
/// * אין מיוטאַבאַל קאַנטעקסץ, `*x` (וווּ `T` איז ניט קיין רעפֿערענץ און נישט אַ רוי טייַטל) איז עקוויוואַלענט צו `* DerefMut::deref_mut(&mut x)`.
/// * וואַלועס פון טיפּ קס 01 קס זענען געצווונגען צו וואַלועס פון טיפּ קס 00 קס
/// * `T` ימפּליסאַטלי ימפּלאַמענאַד אַלע די קס 01 קס מעטהאָדס פון דעם טיפּ קס 00 קס.
///
/// פֿאַר מער דעטאַילס, [the chapter in *The Rust Programming Language*][book] ווי געזונט ווי די רעפֿערענץ סעקשאַנז אויף [the dereference operator][ref-deref-op], [method resolution] און [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// א סטרוקטור מיט אַ איין פעלד וואָס איז מאַדאַפייאַבאַל דורך דערפערענסינג די סטרוקטור.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// מיט דיפערענטשאַל דיפעראַנסיז פון די ווערט.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// ינדיקייץ אַז אַ סטרוקטור קענען זיין געוויינט ווי אַ מעטאָד ופנעמער אָן די `arbitrary_self_types` שטריך.
///
/// דאָס איז ימפּלאַמענאַד דורך סטדליב טייַטל טייפּס ווי קס 01 קס, קס 02 קס, קס 03 קס און קס 00 קס.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}