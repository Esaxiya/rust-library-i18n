/// די דערצו אָפּעראַטאָר קס 00 קס.
///
/// באַמערקונג אַז `Rhs` איז `Self` דורך פעליקייַט, אָבער דאָס איז נישט מאַנדאַטאָרי.
/// פֿאַר בייַשפּיל, [`std::time::SystemTime`] ימפּלאַמאַנץ `Add<Duration>`, וואָס פּערמיץ אַפּעריישאַנז פון די פאָרעם `SystemTime = SystemTime + Duration`.
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## לייג פונקטן
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Add for Point {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
/// ## ימפּלאַמענינג קס 00 קס מיט דזשאַנעריקס
///
/// דאָ איז אַ בייַשפּיל פון די זעלבע `Point` סטראַקטשער וואָס ימפּלאַמענאַד די `Add` Z0 טראט 0 ז מיט דזשאַנעריקס.
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // נאָטיץ אַז די ימפּלאַמענטיישאַן ניצט די פֿאַרבונדן טיפּ קס 00 קס.
/// impl<T: Add<Output = T>> Add for Point<T> {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
#[lang = "add"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(all(_Self = "{integer}", Rhs = "{float}"), message = "cannot add a float to an integer",),
    on(all(_Self = "{float}", Rhs = "{integer}"), message = "cannot add an integer to a float",),
    message = "cannot add `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} + {Rhs}`"
)]
#[doc(alias = "+")]
pub trait Add<Rhs = Self> {
    /// די ריזאַלטינג טיפּ נאָך אַפּלייינג די `+` אָפּעראַטאָר.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 + 1, 13);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn add(self, rhs: Rhs) -> Self::Output;
}

macro_rules! add_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Add for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add(self, other: $t) -> $t { self + other }
        }

        forward_ref_binop! { impl Add, add for $t, $t }
    )*)
}

add_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// די כיסער אָפּעראַטאָר קס 00 קס.
///
/// באַמערקונג אַז `Rhs` איז `Self` דורך פעליקייַט, אָבער דאָס איז נישט מאַנדאַטאָרי.
/// פֿאַר בייַשפּיל, [`std::time::SystemTime`] ימפּלאַמאַנץ `Sub<Duration>`, וואָס אַלאַוז אַפּעריישאַנז פון די פאָרעם `SystemTime = SystemTime - Duration`.
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## סובטראַקטאַבלע פונקטן
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Sub for Point {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 3, y: 3 } - Point { x: 2, y: 3 },
///            Point { x: 1, y: 0 });
/// ```
///
/// ## ימפּלאַמענינג קס 00 קס מיט דזשאַנעריקס
///
/// דאָ איז אַ בייַשפּיל פון די זעלבע `Point` סטראַקטשער וואָס ימפּלאַמענאַד די `Sub` Z0 טראט 0 ז מיט דזשאַנעריקס.
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // נאָטיץ אַז די ימפּלאַמענטיישאַן ניצט די פֿאַרבונדן טיפּ קס 00 קס.
/// impl<T: Sub<Output = T>> Sub for Point<T> {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Point {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 2, y: 3 } - Point { x: 1, y: 0 },
///            Point { x: 1, y: 3 });
/// ```
///
#[lang = "sub"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} - {Rhs}`"
)]
#[doc(alias = "-")]
pub trait Sub<Rhs = Self> {
    /// די ריזאַלטינג טיפּ נאָך אַפּלייינג די `-` אָפּעראַטאָר.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 - 1, 11);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn sub(self, rhs: Rhs) -> Self::Output;
}

macro_rules! sub_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Sub for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub(self, other: $t) -> $t { self - other }
        }

        forward_ref_binop! { impl Sub, sub for $t, $t }
    )*)
}

sub_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// די קייפל אָפּעראַטאָר קס 00 קס.
///
/// באַמערקונג אַז `Rhs` איז `Self` דורך פעליקייַט, אָבער דאָס איז נישט מאַנדאַטאָרי.
///
/// # Examples
///
/// ## מולטיפּיאַבלע באַרדאַסדיק נומערן
///
/// ```
/// use std::ops::Mul;
///
/// // לויט די פונדאַמענטאַל טעאָרעם פון אַריטמעטיק, באַרדאַסדיק נומערן אין לאָואַסט טערמינען זענען יינציק.
/// // דורך בעכעסקעם 'ראַטיאָנאַל' ס אין רידוסט פאָרעם, מיר קענען אַרויספירן קס 01 קס און קס 00 קס.
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // רעדוצירן צו די לאָואַסט טנאָים דורך דיוויידינג דורך די גרעסטע פּראָסט דיוויזאָר.
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Mul for Rational {
///     // די קייפל פון באַרדאַסדיק נומערן איז אַ פארמאכט אָפּעראַציע.
///     type Output = Self;
///
///     fn mul(self, rhs: Self) -> Self {
///         let numerator = self.numerator * rhs.numerator;
///         let denominator = self.denominator * rhs.denominator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // Euclid ס צוויי-טויזנט-יאָר-אַלט אַלגערידאַם צו געפֿינען די גרעסטע פּראָסט דיוויזאָר.
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(2, 3) * Rational::new(3, 4),
///            Rational::new(1, 2));
/// ```
///
/// ## מאַלטאַפּלייינג vectors דורך סקאַלאַרס ווי אין לינעאַר אַלגעבראַ
///
/// ```
/// use std::ops::Mul;
///
/// struct Scalar { value: usize }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<usize> }
///
/// impl Mul<Scalar> for Vector {
///     type Output = Self;
///
///     fn mul(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v * rhs.value).collect() }
///     }
/// }
///
/// let vector = Vector { value: vec![2, 4, 6] };
/// let scalar = Scalar { value: 3 };
/// assert_eq!(vector * scalar, Vector { value: vec![6, 12, 18] });
/// ```
#[lang = "mul"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} * {Rhs}`"
)]
#[doc(alias = "*")]
pub trait Mul<Rhs = Self> {
    /// די ריזאַלטינג טיפּ נאָך אַפּלייינג די `*` אָפּעראַטאָר.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 * 2, 24);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn mul(self, rhs: Rhs) -> Self::Output;
}

macro_rules! mul_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Mul for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul(self, other: $t) -> $t { self * other }
        }

        forward_ref_binop! { impl Mul, mul for $t, $t }
    )*)
}

mul_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// די אָפּטייל אָפּעראַטאָר קס 00 קס.
///
/// באַמערקונג אַז `Rhs` איז `Self` דורך פעליקייַט, אָבער דאָס איז נישט מאַנדאַטאָרי.
///
/// # Examples
///
/// ## דיווידאַבלע באַרדאַסדיק נומערן
///
/// ```
/// use std::ops::Div;
///
/// // לויט די פונדאַמענטאַל טעאָרעם פון אַריטמעטיק, באַרדאַסדיק נומערן אין לאָואַסט טערמינען זענען יינציק.
/// // דורך בעכעסקעם 'ראַטיאָנאַל' ס אין רידוסט פאָרעם, מיר קענען אַרויספירן קס 01 קס און קס 00 קס.
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // רעדוצירן צו די לאָואַסט טנאָים דורך דיוויידינג דורך די גרעסטע פּראָסט דיוויזאָר.
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Div for Rational {
///     // די אָפּטייל פון באַרדאַסדיק נומערן איז אַ פארמאכט אָפּעראַציע.
///     type Output = Self;
///
///     fn div(self, rhs: Self) -> Self::Output {
///         if rhs.numerator == 0 {
///             panic!("Cannot divide by zero-valued `Rational`!");
///         }
///
///         let numerator = self.numerator * rhs.denominator;
///         let denominator = self.denominator * rhs.numerator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // Euclid ס צוויי-טויזנט-יאָר-אַלט אַלגערידאַם צו געפֿינען די גרעסטע פּראָסט דיוויזאָר.
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(1, 2) / Rational::new(3, 4),
///            Rational::new(2, 3));
/// ```
///
/// ## ייַנטיילן ז 0 וועקטאָרס 0 ז דורך סקאַלאַרס ווי אין לינעאַר אַלגעבראַ
///
/// ```
/// use std::ops::Div;
///
/// struct Scalar { value: f32 }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<f32> }
///
/// impl Div<Scalar> for Vector {
///     type Output = Self;
///
///     fn div(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v / rhs.value).collect() }
///     }
/// }
///
/// let scalar = Scalar { value: 2f32 };
/// let vector = Vector { value: vec![2f32, 4f32, 6f32] };
/// assert_eq!(vector / scalar, Vector { value: vec![1f32, 2f32, 3f32] });
/// ```
#[lang = "div"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot divide `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} / {Rhs}`"
)]
#[doc(alias = "/")]
pub trait Div<Rhs = Self> {
    /// די ריזאַלטינג טיפּ נאָך אַפּלייינג די `/` אָפּעראַטאָר.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 / 2, 6);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn div(self, rhs: Rhs) -> Self::Output;
}

macro_rules! div_impl_integer {
    ($($t:ty)*) => ($(
        /// די אָפּעראַציע ראָונדס צו נול, טראַינינג קיין פראַקשאַנאַל טייל פון די פּינטלעך רעזולטאַט.
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! div_impl_float {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_float! { f32 f64 }

/// די רעשט אָפּעראַטאָר קס 00 קס.
///
/// באַמערקונג אַז `Rhs` איז `Self` דורך פעליקייַט, אָבער דאָס איז נישט מאַנדאַטאָרי.
///
/// # Examples
///
/// דעם בייַשפּיל ימפּלאַמאַנץ קס 00 קס אויף אַ קס 01 קס כייפעץ.
/// נאָך די ימפּלאַמענטיישאַן פון קס 00 קס, מען קענען נוצן די קס 01 קס אָפּעראַטאָר צו געפֿינען אויס וואָס די רוען עלעמענטן פון דער רעפטל וואָלט זיין נאָך ספּליטינג עס אין גלייַך סלייסיז פון אַ געגעבן לענג.
///
///
/// ```
/// use std::ops::Rem;
///
/// #[derive(PartialEq, Debug)]
/// struct SplitSlice<'a, T: 'a> {
///     slice: &'a [T],
/// }
///
/// impl<'a, T> Rem<usize> for SplitSlice<'a, T> {
///     type Output = Self;
///
///     fn rem(self, modulus: usize) -> Self::Output {
///         let len = self.slice.len();
///         let rem = len % modulus;
///         let start = len - rem;
///         Self {slice: &self.slice[start..]}
///     }
/// }
///
/// // אויב מיר צעטיילן&[0, 1, 2, 3, 4, 5, 6, 7] אין סלייסאַז פון גרייס 3, די רעשט וואָלט זיין&[6, 7].
/////
/// assert_eq!(SplitSlice { slice: &[0, 1, 2, 3, 4, 5, 6, 7] } % 3,
///            SplitSlice { slice: &[6, 7] });
/// ```
///
#[lang = "rem"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot mod `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} % {Rhs}`"
)]
#[doc(alias = "%")]
pub trait Rem<Rhs = Self> {
    /// די ריזאַלטינג טיפּ נאָך אַפּלייינג די `%` אָפּעראַטאָר.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 % 10, 2);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rem(self, rhs: Rhs) -> Self::Output;
}

macro_rules! rem_impl_integer {
    ($($t:ty)*) => ($(
        /// די אָפּעראַציע סאַטיספייז `n % d == n - (n / d) * d`.
        /// דער רעזולטאַט האט דער זעלביקער צייכן ווי די לינקס אָפּעראַנד.
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! rem_impl_float {
    ($($t:ty)*) => ($(

        /// די רעשט פון די אָפּטייל פון צוויי פלאָוץ.
        ///
        /// די רעשט האט דער זעלביקער צייכן ווי די דיווידענד און איז קאַמפּיוטאַד ווי: `x - (x / y).trunc() * y`.
        ///
        /// # Examples
        ///
        /// ```
        /// let x: f32 = 50.50;
        /// let y: f32 = 8.125;
        /// let remainder = x - (x / y).trunc() * y;
        ///
        /// // דער ענטפער צו ביידע אַפּעריישאַנז איז 1.75
        /// assert_eq!(x % y, remainder);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_float! { f32 f64 }

/// די ונאַרי נעגאַטיוו אָפּעראַטאָר קס 00 קס.
///
/// # Examples
///
/// אַ ימפּלאַמענטיישאַן פון קס 01 קס פֿאַר קס 00 קס, וואָס אַלאַוז די נוצן פון קס 02 קס צו ניגייט זייַן ווערט.
///
///
/// ```
/// use std::ops::Neg;
///
/// #[derive(Debug, PartialEq)]
/// enum Sign {
///     Negative,
///     Zero,
///     Positive,
/// }
///
/// impl Neg for Sign {
///     type Output = Self;
///
///     fn neg(self) -> Self::Output {
///         match self {
///             Sign::Negative => Sign::Positive,
///             Sign::Zero => Sign::Zero,
///             Sign::Positive => Sign::Negative,
///         }
///     }
/// }
///
/// // א נעגאַטיוו positive איז אַ נעגאַטיוו.
/// assert_eq!(-Sign::Positive, Sign::Negative);
/// // א טאָפּל נעגאַטיוו איז אַ positive.
/// assert_eq!(-Sign::Negative, Sign::Positive);
/// // נול איז זיין נעגאַטיוו.
/// assert_eq!(-Sign::Zero, Sign::Zero);
/// ```
#[lang = "neg"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "-")]
pub trait Neg {
    /// די ריזאַלטינג טיפּ נאָך אַפּלייינג די `-` אָפּעראַטאָר.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// פּערפאָרמז די ונאַרי `-` אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// let x: i32 = 12;
    /// assert_eq!(-x, -12);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn neg(self) -> Self::Output;
}

macro_rules! neg_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Neg for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn neg(self) -> $t { -self }
        }

        forward_ref_unop! { impl Neg, neg for $t }
    )*)
}

neg_impl! { isize i8 i16 i32 i64 i128 f32 f64 }

/// די דערצו אַסיינמאַנט אָפּעראַטאָר קס 00 קס.
///
/// # Examples
///
/// דעם בייַשפּיל קריייץ אַ `Point` סטרוקטור אַז ימפּלאַמאַנץ די `AddAssign` Z0 טראט 0 ז, און דאַן דעמאַנסטרייץ לייגן-אַסיינינג צו אַ מיוטאַבאַל `Point`.
///
///
/// ```
/// use std::ops::AddAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl AddAssign for Point {
///     fn add_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 1, y: 0 };
/// point += Point { x: 2, y: 3 };
/// assert_eq!(point, Point { x: 3, y: 3 });
/// ```
#[lang = "add_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot add-assign `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} += {Rhs}`"
)]
#[doc(alias = "+")]
#[doc(alias = "+=")]
pub trait AddAssign<Rhs = Self> {
    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x += 1;
    /// assert_eq!(x, 13);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn add_assign(&mut self, rhs: Rhs);
}

macro_rules! add_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl AddAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add_assign(&mut self, other: $t) { *self += other }
        }

        forward_ref_op_assign! { impl AddAssign, add_assign for $t, $t }
    )+)
}

add_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// די כיסער אָפּעראַטאָר קס 00 קס.
///
/// # Examples
///
/// דעם בייַשפּיל קריייץ אַ `Point` סטרוקטור אַז ימפּלאַמאַנץ די `SubAssign` Z0 טראט 0 ז, און דאַן דעמאַנסטרייץ סאַב-אַסיינינג צו אַ מיוטאַבאַל `Point`.
///
///
/// ```
/// use std::ops::SubAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl SubAssign for Point {
///     fn sub_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 3, y: 3 };
/// point -= Point { x: 2, y: 3 };
/// assert_eq!(point, Point {x: 1, y: 0});
/// ```
#[lang = "sub_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract-assign `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} -= {Rhs}`"
)]
#[doc(alias = "-")]
#[doc(alias = "-=")]
pub trait SubAssign<Rhs = Self> {
    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x -= 1;
    /// assert_eq!(x, 11);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn sub_assign(&mut self, rhs: Rhs);
}

macro_rules! sub_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl SubAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub_assign(&mut self, other: $t) { *self -= other }
        }

        forward_ref_op_assign! { impl SubAssign, sub_assign for $t, $t }
    )+)
}

sub_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// די קייפל אַסיינמאַנט אָפּעראַטאָר קס 00 קס.
///
/// # Examples
///
/// ```
/// use std::ops::MulAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl MulAssign<f64> for Frequency {
///     fn mul_assign(&mut self, rhs: f64) {
///         self.hertz *= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 50.0 };
/// frequency *= 4.0;
/// assert_eq!(Frequency { hertz: 200.0 }, frequency);
/// ```
#[lang = "mul_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} *= {Rhs}`"
)]
#[doc(alias = "*")]
#[doc(alias = "*=")]
pub trait MulAssign<Rhs = Self> {
    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x *= 2;
    /// assert_eq!(x, 24);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn mul_assign(&mut self, rhs: Rhs);
}

macro_rules! mul_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl MulAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul_assign(&mut self, other: $t) { *self *= other }
        }

        forward_ref_op_assign! { impl MulAssign, mul_assign for $t, $t }
    )+)
}

mul_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// אָפּטייל אָפּעראַטאָר קס 00 קס.
///
/// # Examples
///
/// ```
/// use std::ops::DivAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl DivAssign<f64> for Frequency {
///     fn div_assign(&mut self, rhs: f64) {
///         self.hertz /= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 200.0 };
/// frequency /= 4.0;
/// assert_eq!(Frequency { hertz: 50.0 }, frequency);
/// ```
#[lang = "div_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot divide-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} /= {Rhs}`"
)]
#[doc(alias = "/")]
#[doc(alias = "/=")]
pub trait DivAssign<Rhs = Self> {
    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x /= 2;
    /// assert_eq!(x, 6);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn div_assign(&mut self, rhs: Rhs);
}

macro_rules! div_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl DivAssign for $t {
            #[inline]
            fn div_assign(&mut self, other: $t) { *self /= other }
        }

        forward_ref_op_assign! { impl DivAssign, div_assign for $t, $t }
    )+)
}

div_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// די רעשט אַסיינמאַנט אָפּעראַטאָר קס 00 קס.
///
/// # Examples
///
/// ```
/// use std::ops::RemAssign;
///
/// struct CookieJar { cookies: u32 }
///
/// impl RemAssign<u32> for CookieJar {
///     fn rem_assign(&mut self, piles: u32) {
///         self.cookies %= piles;
///     }
/// }
///
/// let mut jar = CookieJar { cookies: 31 };
/// let piles = 4;
///
/// println!("Splitting up {} cookies into {} even piles!", jar.cookies, piles);
///
/// jar %= piles;
///
/// println!("{} cookies remain in the cookie jar!", jar.cookies);
/// ```
#[lang = "rem_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot mod-assign `{Self}` by `{Rhs}``",
    label = "no implementation for `{Self} %= {Rhs}`"
)]
#[doc(alias = "%")]
#[doc(alias = "%=")]
pub trait RemAssign<Rhs = Self> {
    /// פּערפאָרמז די קס 00 קס אָפּעראַציע.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x %= 10;
    /// assert_eq!(x, 2);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn rem_assign(&mut self, rhs: Rhs);
}

macro_rules! rem_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl RemAssign for $t {
            #[inline]
            fn rem_assign(&mut self, other: $t) { *self %= other }
        }

        forward_ref_op_assign! { impl RemAssign, rem_assign for $t, $t }
    )+)
}

rem_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }