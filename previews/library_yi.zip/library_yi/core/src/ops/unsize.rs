use crate::marker::Unsize;

/// Trait וואָס ינדיקייץ אַז דאָס איז אַ טייַטל אָדער אַ ראַפּער פֿאַר איין, ווו אַנסייזינג קענען זיין דורכגעקאָכט אויף דער פּאָינטעע.
///
/// זען די [DST coercion RFC][dst-coerce] און [the nomicon entry on coercion][nomicon-coerce] פֿאַר מער דעטאַילס.
///
/// פֿאַר געבויט-טייַטל טייפּס, פּוינטערז צו קס 00 קס וועט קאָנסערס צו פּוינטערז צו קס 01 קס אויב קס 02 קס דורך קאַנווערטינג פון אַ דין טייַטל צו אַ פעט טייַטל.
///
/// פֿאַר מנהג טייפּס, די געצווונגען דאָ אַרבעט דורך קאָוערסינג קס 00 קס צו קס 01 קס צוגעשטעלט אַן ימפּ פון קס 02 קס יגזיסץ.
/// אַזאַ אַ ימפּ קענען בלויז זיין געשריבן אויב `Foo<T>` האט בלויז אַ איין ניט-פאַנטאָמדאַטאַ פעלד מיט `T`.
/// אויב דער טיפּ פון דעם פעלד איז קס 00 קס, עס דאַרף זיין אַ ימפּלאַמענטיישאַן פון קס 01 קס.
/// די געצווונגען וועט אַרבעטן דורך קאָוערסינג די `Bar<T>` פעלד אין `Bar<U>` און פּלאָמבירן די מנוחה פון די פעלדער פֿון `Foo<T>` צו שאַפֿן אַ `Foo<U>`.
/// דעם וועט יפעקטיוולי בויער אַראָפּ צו אַ טייַטל פעלד און צווינגען אַז.
///
/// בכלל, פֿאַר קלוג פּוינטערז איר וועט מאַכשער קס 00 קס, מיט אַן אַפּשאַנאַל קס 01 קס געבונדן אויף קס 02 קס זיך.
/// פֿאַר ראַפּערז טייפּס וואָס גלייַך ימבעד קס 02 קס ווי קס 03 קס און קס 01 קס, איר קענען גלייַך ימפּלאַמענטאַד קס 00 קס.
///
/// דאָס וועט לאָזן קאָוערשאַן פון טייפּס ווי קס 00 קס אַרבעט.
///
/// [`Unsize`][unsize] איז געניצט צו צייכן טייפּס וואָס קענען זיין געצווונגען צו דסטס אויב הינטער פּוינטערז.דער קאַמפּיילער איז אויטאָמאַטיש ימפּלאַמענאַד.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut ה-> קס 00 קס יו
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut ה-> קס 00 קס
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut ה-> * מוט יו
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut ה-> * קאָנסט יו
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * קאָנסט יו
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *מוט טי->* מוט יו
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *מוט ה->* קאָנסט יו
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *קאָנסט ה->* קאָנסט יו
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// דאָס איז געניצט פֿאַר כייפעץ זיכערהייט, צו קאָנטראָלירן אַז די ופנעמער טיפּ פון אַ מעטאָד קענען זיין געשיקט.
///
/// א ביישפּיל ימפּלאַמענטיישאַן פון די trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut ה-> קס 00 קס יו
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *קאָנסט ה->* קאָנסט יו
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *מוט טי->* מוט יו
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}