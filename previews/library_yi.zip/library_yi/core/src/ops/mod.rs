//! אָווערלאָאַדאַבלע אָפּערייטערז.
//!
//! דורך ימפּלאַמענינג די ז 0 טראַיצ 0 ז אַלאַוז איר צו אָווערלאָאַד זיכער אָפּערייטערז.
//!
//! עטלעכע פון די traits זענען ימפּאָרטיד דורך די prelude, אַזוי זיי זענען בנימצא אין יעדער Rust פּראָגראַם.בלויז אָפּערייטערז מיט traits קענען זיין אָוווערלאָודיד.
//! צום ביישפּיל, די אַדישאַן אָפּעראַטאָר קס 00 קס קענען זיין אָוווערלאָודיד דורך די [`Add`] ז 0 טראַיט 0 ז, אָבער זינט די אַסיינמאַנט אָפּעראַטאָר קס 02 קס האט קיין באַקינג ז 0 טראַיט 0 ז, עס איז קיין וועג צו אָוווערלאָודינג די סעמאַנטיקס.
//! אין אַדישאַן, דעם מאָדולע אָפפערס קיין מעקאַניזאַם צו שאַפֿן נייַ אָפּערייטערז.
//! אויב טרייטלאַס אָוווערלאָודינג אָדער קאַסטאַמייזד אָפּערייטערז זענען פארלאנגט, איר זאָל קוקן צו מאַקראָס אָדער קאַמפּיילער פּלוגינס צו פאַרברייטערן די סינטאַקס פון Rust.
//!
//! ימפּלאַמענטיישאַנז פון אָפּעראַטאָר traits זאָל זיין סאַפּרייזינגלי אין זייער ריספּעקטיוו קאַנטעקסץ, מיט זייער געוויינטלעך מינינגז און [operator precedence].
//! למשל, ווען ימפּלאַמענטינג [`Mul`], די אָפּעראַציע זאָל האָבן עטלעכע געראָטנקייַט צו קייפל (און טיילן די דערוואַרט פּראָפּערטיעס ווי אַסאָוסייטיוואַטי).
//!
//! באַמערקונג אַז די אָפּערייטערז קס 01 קס און קס 02 קס קורץ-קרייַז, הייסט, זיי בלויז אָפּשאַצן זייער רגע אָפּעראַנד אויב עס קאַנטריביוץ צו דער רעזולטאַט.זינט די אָפּפירונג איז נישט ענפאָרסאַבאַל דורך traits, `&&` און `||` זענען נישט געשטיצט ווי אָווערלאָאַדאַבלע אָפּערייטערז.
//!
//! פילע אָפּערייטערז נעמען זייער אָפּעראַנדז דורך ווערט.אין ניט-דזשאַנעריק קאַנטעקסץ מיט געבויט-אין טייפּס, דאָס איז יוזשאַוואַלי נישט אַ פּראָבלעם.
//! אָבער, ניצן די אָפּערייטערז אין דזשאַנעריק קאָד, ריקווייערז עטלעכע ופמערקזאַמקייט אויב די וואַלועס האָבן צו זיין ריוזד ווי די אָפּערייטערז פאַרנוצן זיי.איין אָפּציע איז צו נוצן [`clone`] טייל מאָל.
//! אן אנדער אָפּציע איז צו פאַרלאָזנ זיך די ינוואַלווד טייפּס צו צושטעלן נאָך אָפּעראַטאָר ימפּלעמענטאַטיאָנס פֿאַר באַווייַזן.
//! פֿאַר בייַשפּיל, פֿאַר אַ באַניצער-דיפיינד טיפּ קס 00 קס וואָס איז געמיינט צו שטיצן דערצו, עס איז מיסטאָמע אַ גוטע געדאַנק צו האָבן ביידע `T` און `&T` ינסטרומענט די traits [`Add<T>`][`Add`] און [`Add<&T>`][`Add`] אַזוי אַז דזשאַנעריק קאָד קענען זיין געשריבן אָן ומנייטיק קלאָונינג.
//!
//!
//! # Examples
//!
//! דעם בייַשפּיל קריייץ אַ `Point` סטרוקטור אַז ימפּלאַמאַנץ [`Add`] און [`Sub`], און דעמאַנסטרייץ די אַדינג און אַראָפּרעכענען פון צוויי `פונט` ס.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! פֿאַר בייַשפּיל ימפּלאַמענטיישאַן, זען די דאָקומענטאַטיאָן פֿאַר יעדער trait.
//!
//! די [`Fn`], [`FnMut`] און [`FnOnce`] traits זענען ימפּלאַמענאַד דורך טייפּס וואָס קענען זיין ינוואָוקט ווי פאַנגקשאַנז.באַמערקונג אַז קס 06 קס נעמט קס 03 קס, קס 04 קס נעמט קס 07 קס און קס 08 קס נעמט קס 00 קס.
//! די קאָראַספּאַנדז צו די דריי מינים פון מעטהאָדס וואָס קענען זיין ינוואָוקט אויף אַ בייַשפּיל: רוף-דורך-דערמאָנען, רוף-דורך-מיוטאַבאַל-רעפֿערענץ און רוף-דורך-ווערט.
//! די מערסט פּראָסט נוצן פון די traits איז ווי אַ גרענעץ צו העכער-פונקטיאָנס וואָס נעמען פאַנגקשאַנז אָדער קלאָוזשערז ווי טענות.
//!
//! נעמען אַ [`Fn`] ווי אַ פּאַראַמעטער:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! נעמען אַ [`FnMut`] ווי אַ פּאַראַמעטער:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! נעמען אַ [`FnOnce`] ווי אַ פּאַראַמעטער:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` קאַנסומז זיין קאַפּטשערד וועריאַבאַלז, אַזוי עס קען נישט לויפן מער ווי איין מאָל
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // אויב איר פּרובירן צו רופן די `func()` ווידער, עס וועט וואַרפן אַ `use of moved value` טעות פֿאַר `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` קענען ניט מער זיין ינוואָוקט אין דעם פונט
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;