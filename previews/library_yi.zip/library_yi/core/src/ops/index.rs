/// געוויינט פֿאַר ינדעקסינג אַפּעריישאַנז קס 00 קס אין יממוטאַבאַל קאַנטעקסץ.
///
/// `container[index]` איז אַקשלי סינטאַקטיק צוקער פֿאַר `*container.index(index)`, אָבער בלויז ווען געוויינט ווי אַ ימיוטאַבאַל ווערט.
/// אויב אַ מוטאַבאַל ווערט איז געבעטן, [`IndexMut`] איז אַנשטאָט.
/// דאָס אַלאַוז פייַן טינגז אַזאַ ווי קס 01 קס אויב די טיפּ פון קס 02 קס ימפּלאַמאַנץ קס 00 קס.
///
/// # Examples
///
/// די פאלגענדע בייַשפּיל ימפּלאַמענטאַד `Index` אויף אַ בלויז לייענען `NucleotideCount` קאַנטיינער, אַזוי אַז יחיד קאַונץ קענען זיין ריטריווד מיט אינדעקס סינטאַקס.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// די אומגעקערט טיפּ נאָך ינדעקסינג.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// פּערפאָרמז די ינדעקסינג קס 00 קס אָפּעראַציע.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// געוויינט פֿאַר ינדעקסינג אַפּעריישאַנז קס 00 קס אין מיוטאַבאַל קאַנטעקסץ.
///
/// `container[index]` איז אַקשלי סינטאַקטיק צוקער פֿאַר `*container.index_mut(index)`, אָבער בלויז ווען געוויינט ווי אַ מיוטאַבאַל ווערט.
/// אויב אַ יממוטאַבאַל ווערט איז געבעטן, די [`Index`] trait איז אַנשטאָט.
/// דאָס אַלאַוז פייַן טינגז אַזאַ ווי קס 00 קס.
///
/// # Examples
///
/// א זייער פּשוט ימפּלאַמענטיישאַן פון אַ `Balance` סטרוקטור וואָס האט צוויי זייטן, וואָס יעדער קענען זיין ינדאַקייטיד מיוטאַבאַל און יממוטאַבלי.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // אין דעם פאַל, `balance[Side::Right]` איז צוקער פֿאַר `*balance.index(Side::Right)`, ווייַל מיר נאָר לייענען*`balance[Side::Right]` און נישט שרייבן עס.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // אין דעם פאַל, `balance[Side::Left]` איז צוקער פֿאַר `*balance.index_mut(Side::Left)`, ווייַל מיר שרייבן `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// פּערפאָרמז די מיוטאַבאַל ינדעקסינג קס 00 קס אָפּעראַציע.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}