/// א Z0 טראט 0 ז פֿאַר קאַסטאַמייז די נאַטור פון די `?` אָפּעראַטאָר.
///
/// א טיפּ ימפּלאַמענינג קס 00 קס איז איינער וואָס האט אַ קאַנאַנאַקאַל וועג צו קוק עס אין טערמינען פון אַ קס 01 קס דיטשאָטאָמי.
/// דעם trait אַלאַוז ביידע יקסטראַקטינג די הצלחה אָדער דורכפאַל וואַלועס פון אַ יגזיסטינג בייַשפּיל און קריייטינג אַ נייַע בייַשפּיל פון אַ הצלחה אָדער דורכפאַל ווערט.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// דער טיפּ פון דעם ווערט ווען וויוד ווי געראָטן.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// דער טיפּ פון דעם ווערט ווען וויוד ווי ניט אַנדערש.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// אַפּלייז די אָפּעראַטאָר קס 01 קס.א צוריקקער פון קס 02 קס מיטל אַז די דורכפירונג זאָל פאָרזעצן נאָרמאַלי, און דער רעזולטאַט פון קס 03 קס איז די ווערט קס 00 קס.
    /// א צוריקקער פון קס 01 קס מיטל אַז דורכפירונג זאָל ז 0 בראַנטש 0 ז צו די ינערמאָוסט ענקלאָוזינג קס 00 קס, אָדער צוריקקומען פון די פונקציע.
    ///
    /// אויב אַן `Err(e)` רעזולטאַט איז אומגעקערט, די ווערט `e` וועט זיין "wrapped" אין די צוריקקער טיפּ פון די ענקלאָוזינג פאַרנעם (וואָס מוזן זיך ינסטרומענט `Try`).
    ///
    /// ספּאַסיפיקלי, די ווערט `X::from_error(From::from(e))` איז אומגעקערט, ווו `X` איז די צוריקקער טיפּ פון די ענקלאָוזינג פונקציע.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// ראַפּט אַ טעות ווערט צו בויען די קאַמפּאַזאַט רעזולטאַט.
    /// פֿאַר בייַשפּיל, `Result::Err(x)` און `Result::from_error(x)` זענען עקוויוואַלענט.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// ראַפּט אַן OK ווערט צו בויען די קאַמפּאַזאַט רעזולטאַט.
    /// פֿאַר בייַשפּיל, `Result::Ok(x)` און `Result::from_ok(x)` זענען עקוויוואַלענט.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}