use crate::fmt;
use crate::hash::Hash;

/// אַ אַנבאַונדיד קייט קס 00 קס.
///
/// `RangeFull` איז בפֿרט געניצט ווי אַ קס 01 קס, זייַן סטענאָגראַפיע איז קס 00 קס.
/// עס קען נישט דינען ווי אַ [`Iterator`] ווייַל עס האט נישט אַ סטאַרטינג פונט.
///
/// # Examples
///
/// די קס 01 קס סינטאַקס איז אַ קס 00 קס:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// עס טוט נישט האָבן אַן [`IntoIterator`] ימפּלאַמענטיישאַן, אַזוי איר קענען נישט נוצן עס אין אַ `for` שלייף גלייַך.
/// דאָס וועט נישט צונויפנעמען:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] איז געניצט ווי [slicing index], און די פול מענגע איז אַ פּענעץ.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // דאָס איז די `RangeFull`
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// א קס 01 קס קייט באַונדאַד ינקלוסיוו אונטן און אויסשליסלעך אויבן קס 00 קס.
///
///
/// די קייט קס 01 קס כּולל אַלע וואַלועס מיט קס 00 קס.
/// עס איז ליידיק אויב `start >= end`.
///
/// # Examples
///
/// די קס 01 קס סינטאַקס איז אַ קס 00 קס:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // דאָס איז אַ `Range`
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // ניט קאָפּיע-זען קס 00 קס
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// דער נידעריקער גרענעץ פון די קייט (inclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// דער אויבערשטער גרענעץ פון די קייט (exclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// קערט קס 00 קס אויב קס 01 קס איז קאַנטיינד אין די קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// קערט `true` אויב די קייט כּולל קיין ייטאַמז.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// די קייט איז ליידיק אויב קיין זייַט איז ינקאַמפּעראַבאַל:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// א קייט בלויז באַגרענעצט ינקלוסיוולי אונטער (`start..`).
///
/// די `RangeFrom` `start..` כּולל אַלע וואַלועס מיט `x >= start`.
///
/// *באַמערקונג*: אָווערפלאָוו אין די קס 00 קס ימפּלאַמענטיישאַן (ווען די קאַנטיינד דאַטן טיפּ ריטשאַז זיין נומעריקאַל שיעור) איז ערלויבט צו ז 0 פּאַניק 0 ז, ייַנוויקלען, אָדער אָנזעטיקן.
/// די אָפּפירונג איז דיפיינד דורך די ימפּלאַמענטיישאַן פון די [`Step`] trait.
/// פֿאַר פּרימיטיוו ינטאַדזשערז, דאָס גייט די נאָרמאַל כּללים, און רעספּעקט די אָוווערפלאָו טשעקס פּראָפיל (ז 0 פּאַניק 0 ז אין דיבאַג, ייַנוויקלען אין מעלדונג).
/// באַמערקונג אויך אַז אָוווערפלאָו כאַפּאַנז פריער ווי איר קען יבערנעמען: די אָוווערפלאָו כאַפּאַנז אין די רוף צו קסקסנומקסקס אַז ייעלדס די מאַקסימום ווערט, ווייַל די קייט מוזן זיין באַשטימט צו אַ שטאַט צו געבן די ווייַטער ווערט.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// די קס 01 קס סינטאַקס איז אַ קס 00 קס:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // דאָס איז אַ `RangeFrom`
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // ניט קאָפּיע-זען קס 00 קס
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// דער נידעריקער גרענעץ פון די קייט (inclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// קערט קס 00 קס אויב קס 01 קס איז קאַנטיינד אין די קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// א ריי בלויז לימיטעד אויבן (`..end`).
///
/// די `RangeTo` `..end` כּולל אַלע וואַלועס מיט `x < end`.
/// עס קען נישט דינען ווי אַ [`Iterator`] ווייַל עס האט נישט אַ סטאַרטינג פונט.
///
/// # Examples
///
/// די קס 01 קס סינטאַקס איז אַ קס 00 קס:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// עס טוט נישט האָבן אַן [`IntoIterator`] ימפּלאַמענטיישאַן, אַזוי איר קענען נישט נוצן עס אין אַ `for` שלייף גלייַך.
/// דאָס וועט נישט צונויפנעמען:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// ווען געניצט ווי [slicing index], `RangeTo` טראגט אַ פּעקל פון אַלע מענגע עלעמענטן איידער די אינדעקס ינדאַקייטיד דורך `end`.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // דאָס איז אַ `RangeTo`
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// דער אויבערשטער גרענעץ פון די קייט (exclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// קערט קס 00 קס אויב קס 01 קס איז קאַנטיינד אין די קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// א קייט לימיטעד ינקלוסיוולי אונטער און אויבן (`start..=end`).
///
/// די `RangeInclusive` `start..=end` כּולל אַלע וואַלועס מיט `x >= start` און `x <= end`.עס איז ליידיק סייַדן `start <= end`.
///
/// דעם יטעראַטאָר איז קס 00 קס, אָבער די ספּעציפֿיש וואַלועס פון קס 01 קס און קס 02 קס נאָך יטעראַטיאָן איז פאַרטיק זענען **ונספּעסיפיעד** אנדערע ווי אַז קס 03 קס וועט צוריקקומען קס 04 קס אַמאָל קיין מער וואַלועס וועט זיין Produced.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// די קס 01 קס סינטאַקס איז אַ קס 00 קס:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // דאָס איז אַ `RangeInclusive`
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // ניט קאָפּיע-זען קס 00 קס
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // באַמערקונג אַז די פעלדער דאָ זענען נישט עפנטלעך צו לאָזן טשאַנגינג די פאַרטרעטונג אין די future;אין באַזונדער, כאָטש מיר קען יקספּאָוזד קס 00 קס, מאַדאַפייינג זיי אָן טשאַנגינג קס 01 קס פּריוואַט פעלדער קען פירן צו פאַלש נאַטור, אַזוי מיר טאָן נישט וועלן צו שטיצן דעם מאָדע.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // די פעלד איז:
    //  - `false` אויף קאַנסטראַקשאַן
    //  - `false` ווען יטעראַטיאָן ייעלד אַן עלעמענט און יטעראַטאָר איז נישט ויסגעמאַטערט
    //  - `true` ווען יטעראַטיאָן איז געניצט צו ויסמאַטערן די יטעראַטאָר
    //
    // דאָס איז פארלאנגט צו שטיצן PartialEq און Hash אָן PartialOrd געבונדן אָדער ספּעשאַלאַזיישאַן.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// קריייץ אַ נייַ ינקלוסיוו קייט.עקוויוואַלענט צו שרייבן `start..=end`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// קערט דער נידעריקער גרענעץ פון די קייט (inclusive).
    ///
    /// ווען איר נוצן אַ ינקלוסיוו קייט פֿאַר יטעראַטיאָן, די וואַלועס פון `start()` און [`end()`] זענען נישט ספּעסאַפייד נאָך די יטעראַטיאָן געענדיקט.
    /// צו באַשליסן צי די ינקלוסיוו קייט איז ליידיק, נוצן די [`is_empty()`] אופֿן אַנשטאָט פון קאַמפּערינג `start() > end()`.
    ///
    /// Note: די ווערט וואָס איז אומגעקערט דורך דעם אופֿן איז נישט ספּעציפיצירט נאָך דעם ווי די קייט איז יטעראַטעד צו יגזאָסטשאַן.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// קערט דער אויבערשטער גרענעץ פון די קייט (inclusive).
    ///
    /// ווען איר נוצן אַ ינקלוסיוו קייט פֿאַר יטעראַטיאָן, די וואַלועס פון [`start()`] און `end()` זענען נישט ספּעסאַפייד נאָך די יטעראַטיאָן געענדיקט.
    /// צו באַשליסן צי די ינקלוסיוו קייט איז ליידיק, נוצן די [`is_empty()`] אופֿן אַנשטאָט פון קאַמפּערינג `start() > end()`.
    ///
    /// Note: די ווערט וואָס איז אומגעקערט דורך דעם אופֿן איז נישט ספּעציפיצירט נאָך דעם ווי די קייט איז יטעראַטעד צו יגזאָסטשאַן.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// דיסטרוקטורעס די `RangeInclusive` אין (נידעריקער גרענעץ, אויבערשטער (inclusive) געבונדן).
    ///
    /// Note: די ווערט וואָס איז אומגעקערט דורך דעם אופֿן איז נישט ספּעציפיצירט נאָך דעם ווי די קייט איז יטעראַטעד צו יגזאָסטשאַן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// קאָנווערט צו אַ ויסשליסיק קס 00 קס פֿאַר קס 01 קס ימפּלאַמענטיישאַנז.
    /// די קאַללער איז פאַראַנטוואָרטלעך פֿאַר האַנדלינג מיט `end == usize::MAX`.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // אויב מיר זענען נישט ויסגעמאַטערט, מיר ווילן צו נאָר שנייַדן קקסנומקס.
        // אויב מיר זענען ויסגעמאַטערט, די סלייסינג מיט `end + 1..end + 1` גיט אונדז אַ ליידיק קייט וואָס איז נאָך אונטערטעניק צו גווול טשעקס פֿאַר די ענדפּוינט.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// קערט קס 00 קס אויב קס 01 קס איז קאַנטיינד אין די קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// דעם אופֿן שטענדיק קערט `false` נאָך יטעראַטיאָן איז פאַרטיק:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // פּינטלעך פעלד וואַלועס זענען ונספּעסיפיעד דאָ
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// קערט `true` אויב די קייט כּולל קיין ייטאַמז.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// די קייט איז ליידיק אויב קיין זייַט איז ינקאַמפּעראַבאַל:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// דעם אופֿן קערט `true` נאָך יטעראַטיאָן איז פאַרטיק:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // פּינטלעך פעלד וואַלועס זענען ונספּעסיפיעד דאָ
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// א קייט בלויז באַגרענעצט ינקלוסיוולי העכער (`..=end`).
///
/// די `RangeToInclusive` `..=end` כּולל אַלע וואַלועס מיט `x <= end`.
/// עס קען נישט דינען ווי אַ [`Iterator`] ווייַל עס האט נישט אַ סטאַרטינג פונט.
///
/// # Examples
///
/// די קס 01 קס סינטאַקס איז אַ קס 00 קס:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// עס טוט נישט האָבן אַן [`IntoIterator`] ימפּלאַמענטיישאַן, אַזוי איר קענען נישט נוצן עס אין אַ `for` שלייף גלייַך.דאָס וועט נישט צונויפנעמען:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// ווען געוויינט ווי אַ קס 01 קס, קס 02 קס טראגט אַ רעפטל פון אַלע מענגע עלעמענטן ביז און מיט די אינדעקס אנגעוויזן דורך קס 00 קס.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // דאָס איז אַ `RangeToInclusive`
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// דער אויבערשטער גרענעץ פון די קייט (inclusive)
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// קערט קס 00 קס אויב קס 01 קס איז קאַנטיינד אין די קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>קענען ניט ימפּ פון <RangeTo<Idx>> ווייַל אַנדערפלאָו וואָלט זיין מעגלעך מיט (..0).into()
//

/// אַ ענדפּוינט פון אַ קייט פון שליסלען.
///
/// # Examples
///
/// 'געבונדן' זענען קייט ענדפּוינץ:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// ניצן אַ טופּלע פון `באָונד`ס ווי אַ אַרגומענט צו קס 00 קס.
/// באַמערקונג אַז אין רובֿ פאלן, עס איז בעסער צו נוצן די קייט סינטאַקס (`1..5`) אַנשטאָט.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// אַן ינקלוסיוו געבונדן.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// אַ ויסשליסיק געבונדן.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// אַ ינפאַנאַט ענדפּוינט.ינדיקייץ אַז עס איז קיין געבונדן אין דעם ריכטונג.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// קאָנווערץ פון קס 01 קס צו קס 00 קס.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// קאָנווערץ פון קס 01 קס צו קס 00 קס.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// מאַפּ אַ קס 00 קס צו אַ קס 01 קס דורך קלאָונינג די אינהאַלט פון די געבונדן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` איז ימפּלאַמענאַד דורך די געבויט-אין ריי טייפּס פון Rust, געשאפן דורך קייט סינטאַקס ווי קס 01 קס, קס 02 קס, קס 03 קס, קס 04 קס, קס 05 קס אָדער קס 00 קס.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// אָנהייב אינדעקס געבונדן.
    ///
    /// קערט דער אָנהייב ווערט ווי אַ `Bound`.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// סוף אינדעקס געבונדן.
    ///
    /// קערט דער סוף ווערט ווי אַ `Bound`.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// קערט קס 00 קס אויב קס 01 קס איז קאַנטיינד אין די קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// פעסטשטעלן! (קס 00 קס;
    /// assert!(!(3..5).contains(&2));
    ///
    /// פעסטשטעלן! (קס 00 קס;
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // ווען די יטיראַטאָר איז ויסגעמאַטערט, מיר יוזשאַוואַלי האָבן אָנהייב==סוף, אָבער מיר וועלן אַז די קייט זאָל זיין ליידיק מיט גאָרנישט.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}