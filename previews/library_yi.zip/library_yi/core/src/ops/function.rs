/// די ווערסיע פון די רופן אָפּעראַטאָר אַז נעמט אַן ימיוטאַבאַל ופנעמער.
///
/// ינסטאַנסיז פון קס 00 קס קענען זיין ריפּיטידלי גערופֿן אָן מיוטייטינג שטאַט.
///
/// *די trait (`Fn`) איז ניט צו זיין צעמישט מיט [function pointers] (`fn`).*
///
/// `Fn` איז ימפּלאַמענאַד אויטאָמאַטיש דורך קלאָוזשערז וואָס נעמען בלויז יממוטאַבלע באַווייַזן צו קאַפּטשערד וועריאַבאַלז אָדער טאָן ניט כאַפּן גאָרנישט ווי געזונט ווי (safe) קס 01 קס (מיט עטלעכע קייוויאַץ, זען זייער דאַקיומענטיישאַן פֿאַר מער דעטאַילס).
///
/// אַדדיטיאָנאַללי, פֿאַר קיין טיפּ קס 03 קס אַז ימפּלאַמאַנץ קס 00 קס, קס 02 קס ימפּלאַמאַנץ קס 01 קס אויך.
///
/// זינט [`FnMut`] און [`FnOnce`] זענען סופּער טרייץ פון `Fn`, קיין `Fn` קענען ווערן גענוצט ווי אַ פּאַראַמעטער וווּ אַ [`FnMut`] אָדער [`FnOnce`] איז געריכט.
///
/// ניצן קס 00 קס ווי אַ געבונדן ווען איר ווילן צו אָננעמען אַ פּאַראַמעטער פון פונקציע-ווי טיפּ און איר דאַרפֿן צו רופן עס ריפּיטידלי און אָן מיוטייטינג שטאַט (למשל, ווען איר רופן עס קאַנקעראַנטלי).
/// אויב איר טאָן ניט דאַרפֿן אַזאַ שטרענג רעקווירעמענץ, נוצן [`FnMut`] אָדער [`FnOnce`] ווי גווול.
///
/// זען די [chapter on closures in *The Rust Programming Language*][book] פֿאַר מער אינפֿאָרמאַציע וועגן דעם טעמע.
///
/// די ספּעציעלע סינטאַקס פֿאַר `Fn` traits (למשל
/// `Fn(usize, bool) -> נוצן ").יענע אינטערעסירט אין די טעכניש דעטאַילס קענען אָפּשיקן צו [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## פאַך אַ קלאָוזשער
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## ניצן אַ `Fn` פּאַראַמעטער
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // אַזוי אַז regex קענען פאַרלאָזנ זיך `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// פּערפאָרמז די רופן אָפּעראַציע.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// די ווערסיע פון די רופן אָפּעראַטאָר אַז נעמט אַ מיוטאַבאַל ופנעמער.
///
/// X00 קס ינסטאַנסיז קענען זיין גערופן ריפּיטידלי און קענען מיוטייט שטאַט.
///
/// `FnMut` איז ימפּלאַמענאַד אויטאָמאַטיש דורך קלאָוזשערז וואָס נעמען מיוטאַבאַל באַווייַזן צו קאַפּטשערד וועריאַבאַלז, ווי געזונט ווי אַלע טייפּס אַז ינסטרומענט קס 00 קס, למשל, קס 01 קס קס 02 קס (זינט קס 03 קס איז אַ סופּערטראַט פון קס 04 קס).
/// אַדדיטיאָנאַללי, פֿאַר קיין טיפּ קס 03 קס אַז ימפּלאַמאַנץ קס 00 קס, קס 02 קס ימפּלאַמאַנץ קס 01 קס אויך.
///
/// זינט [`FnOnce`] איז אַ סופּערטראַט פון `FnMut`, קיין `FnMut` קענען זיין געוויינט וווּ [`FnOnce`] איז געריכט, און זינט [`Fn`] איז אַ סובטראַטיאָן פון `FnMut`, איר קענען נוצן [`Fn`] וווּ `FnMut` איז געריכט.
///
/// ניצן קס 00 קס ווי אַ געבונדן ווען איר ווילן צו אָננעמען אַ פּאַראַמעטער פון פונקציע-ווי טיפּ און איר דאַרפֿן צו רופן עס ריפּיטידלי, בשעת אַלאַוינג עס צו מיוטייט שטאַט.
/// אויב איר טאָן ניט וועלן די פּאַראַמעטער צו מיוטייט שטאַט, נוצן [`Fn`] ווי אַ געבונדן;אויב איר טאָן ניט דאַרפֿן צו רופן עס ריפּיטידלי, נוצן [`FnOnce`].
///
/// זען די [chapter on closures in *The Rust Programming Language*][book] פֿאַר מער אינפֿאָרמאַציע וועגן דעם טעמע.
///
/// די ספּעציעלע סינטאַקס פֿאַר `Fn` traits (למשל
/// `Fn(usize, bool) -> נוצן ").יענע אינטערעסירט אין די טעכניש דעטאַילס קענען אָפּשיקן צו [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## רופן אַ מיוטאַבאַל קאַפּטשערינג קלאָוזשער
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## ניצן אַ `FnMut` פּאַראַמעטער
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // אַזוי אַז regex קענען פאַרלאָזנ זיך `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// פּערפאָרמז די רופן אָפּעראַציע.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// די ווערסיע פון די רופן אָפּעראַטאָר וואָס נעמט אַ ביי-ווערט ופנעמער.
///
/// ינסטאַנסיז פון קס 01 קס קענען זיין גערופן, אָבער קען נישט זיין געראָטן קייפל מאָל.דעריבער, אויב דער בלויז זאַך וואָס איז באַוווסט וועגן אַ טיפּ איז אַז עס ימפּלאַמאַנץ `FnOnce`, עס קען נאָר זיין גערופֿן אַמאָל.
///
/// `FnOnce` איז אויטאָמאַטיש ימפּלאַמענאַד דורך קלאָוזשערז אַז קען פאַרנוצן קאַפּטשערד וועריאַבאַלז, ווי געזונט ווי אַלע טייפּס אַז ינסטרומענט קס 00 קס, למשל, קס 01 קס קס 02 קס (זינט קס 03 קס איז אַ סופּערטראַיט פון קס 04 קס).
///
///
/// זינט ביידע [`Fn`] און [`FnMut`] זענען סאַבסטרייץ פון `FnOnce`, יעדער [`Fn`] אָדער [`FnMut`] קענען זיין געוויינט ווו אַ `FnOnce` איז געריכט.
///
/// ניצן `FnOnce` ווי אַ געבונדן ווען איר ווילן צו אָננעמען אַ פּאַראַמעטער פון פונקציע-ווי טיפּ און נאָר דאַרפֿן צו רופן עס אַמאָל.
/// אויב איר דאַרפֿן צו רופן די פּאַראַמעטער ריפּיטידלי, נוצן [`FnMut`] ווי אַ געבונדן;אויב איר אויך דאַרפֿן עס צו נישט מיוטייט שטאַט, נוצן [`Fn`].
///
/// זען די [chapter on closures in *The Rust Programming Language*][book] פֿאַר מער אינפֿאָרמאַציע וועגן דעם טעמע.
///
/// די ספּעציעלע סינטאַקס פֿאַר `Fn` traits (למשל
/// `Fn(usize, bool) -> נוצן ").יענע אינטערעסירט אין די טעכניש דעטאַילס קענען אָפּשיקן צו [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ניצן אַ `FnOnce` פּאַראַמעטער
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` קאַנסומז זיין קאַפּטשערד וועריאַבאַלז, אַזוי עס קען נישט לויפן מער ווי איין מאָל.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // אויב איר פּרובירן צו רופן די `func()` ווידער, עס וועט וואַרפן אַ `use of moved value` טעות פֿאַר `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` קענען ניט מער זיין ינוואָוקט אין דעם פונט
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // אַזוי אַז regex קענען פאַרלאָזנ זיך `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// די אומגעקערט טיפּ נאָך די רופן אָפּעראַטאָר איז געניצט.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// פּערפאָרמז די רופן אָפּעראַציע.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}