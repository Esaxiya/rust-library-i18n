//! Trait ימפּלאַמענטיישאַנז פֿאַר קס 00 קס.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// ימפּלאַמאַנץ אָרדערינג סטרינגס.
///
/// סטרינגס זענען אָרדערד [lexicographically](Ord#lexicographical-comparison) דורך זייער בייט וואַלועס.
/// דעם אָרדערד אוניקאָד קאָד ווייזט באזירט אויף זייער שטעלעס אין די קאָד טשאַרץ.
/// דאָס איז נישט דאַווקע די זעלבע ווי "alphabetical" סדר, וואָס וועריז דורך שפּראַך און לאָקאַל.
/// סאָרטינג סטרינגס לויט קולטורלי אנגענומען סטאַנדאַרדס ריקווייערז היגע ספּעציפיש דאַטן וואָס זענען אַרויס די פאַרנעם פון די `str` טיפּ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// ימפּלאַמאַנץ פאַרגלייַך אַפּעריישאַנז אויף סטרינגס.
///
/// סטרינגס זענען קאַמפּערד קקסנומקס דורך זייער בייט וואַלועס.
/// דאָס קאַמפּערז יוניקאָדע קאָד ווייזט באזירט אויף זייער שטעלעס אין די קאָד טשאַרץ.
/// דאָס איז נישט דאַווקע די זעלבע ווי "alphabetical" סדר, וואָס וועריז דורך שפּראַך און לאָקאַל.
/// קאַמפּערינג סטרינגס לויט קולטורלי-אנגענומען סטאַנדאַרדס ריקווייערז היגע ספּעציפיש דאַטן וואָס זענען אַרויס די פאַרנעם פון די `str` טיפּ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// ימפּלאַמאַנץ סאַבסטריישאַן סלייסינג מיט סינטאַקסקס קס 01 קס אָדער קס 00 קס.
///
/// רעטורנס אַ רעפטל פון די גאנצע שטריקל, הייסט, קערט `&self` אָדער `&mut self`.עקוויוואַלענט צו `&זיך [0 ..
/// len] `אָדער`&מוט זיך [0 ..
/// len]`.
/// ניט ענלעך אנדערע ינדעקסינג אַפּעריישאַנז, דאָס קען קיינמאָל panic.
///
/// די אָפּעראַציע איז *O*(1).
///
/// איידער 1.20.0, די ינדעקסינג אַפּעריישאַנז זענען נאָך געשטיצט דורך דירעקט ימפּלאַמענטיישאַן פון `Index` און `IndexMut`.
///
/// עקוויוואַלענט צו קס 01 קס אָדער קס 00 קס.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// ימפּלאַמאַנץ סאַבסטריישאַן סלייסינג מיט סינטאַקסקס קס 01 קס אָדער קס 00 קס.
///
/// רעטורנס אַ רעפטל פון די געגעבן שטריקל פון די בייט קייט [`אָנהייבן ', קס 00 קס).
///
/// די אָפּעראַציע איז *O*(1).
///
/// איידער 1.20.0, די ינדעקסינג אַפּעריישאַנז זענען נאָך געשטיצט דורך דירעקט ימפּלאַמענטיישאַן פון `Index` און `IndexMut`.
///
/// # Panics
///
/// Panics אויב `begin` אָדער `end` טוט נישט פונט צו די סטאַרטינג בייז פאָטאָ פון אַ כאַראַקטער (ווי דיפיינד דורך `is_char_boundary`), אויב `begin > end`, אָדער `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // די וועט panic:
/// // בייט 2 ליגט אין קס 00 קס:
/// // &s [2 .3];
///
/// // ביטע 8 ליגט אין `老`&s [1 ..
/// // 8];
///
/// // ביטע 100 איז אַרויס די שטריקל&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז קס 00 קס און קס 01 קס זענען אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            // מיר אויך אָפּגעשטעלט טשאַר באַונדריז, אַזוי דאָס איז גילטיק UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז קס 00 קס און קס 01 קס זענען אויף אַ טשאַר גרענעץ.
            // מיר וויסן אַז דער טייַטל איז יינציק ווייַל מיר האָבן עס פֿון `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // זיכערקייט: די קאָלער געראַנטיז אַז קס 01 קס איז אין גווול פון קס 00 קס
        // וואָס סאַטיספייז אַלע די באדינגונגען פֿאַר קס 00 קס.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // זיכערקייט: זען באַמערקונגען פֿאַר קס 00 קס.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary טשעקס אַז דער אינדעקס איז אין [0, .len()] קען נישט רייוז `get` ווי אויבן, ווייַל פון NLL קאָנפליקט
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז קס 00 קס און קס 01 קס זענען אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// ימפּלאַמאַנץ סאַבסטריישאַן סלייסינג מיט סינטאַקסקס קס 01 קס אָדער קס 00 קס.
///
/// רעטורנס אַ רעפטל פון די געגעבן שטריקל פון די בייט קייט [`0`, קס 00 קס).
/// עקוויוואַלענט צו קס 01 קס אָדער קס 00 קס.
///
/// די אָפּעראַציע איז *O*(1).
///
/// איידער 1.20.0, די ינדעקסינג אַפּעריישאַנז זענען נאָך געשטיצט דורך דירעקט ימפּלאַמענטיישאַן פון `Index` און `IndexMut`.
///
/// # Panics
///
/// Panics אויב `end` קען נישט פונט צו די אָנהייב פון די פאָטאָ פון אַ כאַראַקטער (ווי `is_char_boundary` איז דיפיינד) אָדער `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `end` איז אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `end` איז אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `end` איז אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// ימפּלאַמאַנץ סאַבסטריישאַן סלייסינג מיט סינטאַקסקס קס 01 קס אָדער קס 00 קס.
///
/// רעטורנס אַ רעפטל פון די געגעבן שטריקל פון די בייט קייט [`אָנהייבן ', קס 00 קס).עקוויוואַלענט צו`&זיך [אָנהייבן ..
/// len] `אָדער`&מוט זיך [אָנהייבן ..
/// len]`.
///
/// די אָפּעראַציע איז *O*(1).
///
/// איידער 1.20.0, די ינדעקסינג אַפּעריישאַנז זענען נאָך געשטיצט דורך דירעקט ימפּלאַמענטיישאַן פון `Index` און `IndexMut`.
///
/// # Panics
///
/// Panics אויב `begin` קען נישט פונט צו די אָנהייב פון די פאָטאָ פון אַ כאַראַקטער (ווי `is_char_boundary` איז דיפיינד) אָדער `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `start` איז אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `start` איז אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // זיכערקייט: די קאָלער געראַנטיז אַז קס 01 קס איז אין גווול פון קס 00 קס
        // וואָס סאַטיספייז אַלע די באדינגונגען פֿאַר קס 00 קס.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // זיכערקייט: יידעניקאַל צו קס 00 קס.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `start` איז אויף אַ טשאַר גרענעץ,
            // און מיר פאָרן אין אַ זיכער רעפֿערענץ, אַזוי דער צוריקקער ווערט וועט אויך זיין איינער.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// ימפּלאַמאַנץ סאַבסטריישאַן סלייסינג מיט סינטאַקסקס קס 01 קס אָדער קס 00 קס.
///
/// קערט אַ רעפטל פון די געגעבן שטריקל פון די בייט קייט קס 01 קס.עקוויוואַלענט צו קס 03 קס אָדער קס 02 קס, אַחוץ אויב קס 04 קס האט די מאַקסימום ווערט פֿאַר קס 00 קס.
///
/// די אָפּעראַציע איז *O*(1).
///
/// # Panics
///
/// Panics אויב `begin` ווייזט נישט אויף די אָנהייב בייז אָפסעט פון אַ כאַראַקטער (ווי דיפיינד דורך `is_char_boundary`), אויב `end` טוט נישט פונט צו די ענדיקן ביי אָפסעט פון אַ כאַראַקטער (`end + 1` איז אָדער אַ אָנהייב ביי אָפסט אָדער גלייַך צו `len`), אויב `begin > end`, אָדער אויב `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// ימפּלאַמאַנץ סאַבסטריישאַן סלייסינג מיט סינטאַקסקס קס 01 קס אָדער קס 00 קס.
///
/// קערט אַ רעפטל פון די געגעבן שטריקל פון די בייט קייט קס 00 קס.
/// עקוויוואַלענט צו קס 01 קס, אַחוץ אויב קס 02 קס האט די מאַקסימום ווערט פֿאַר קס 00 קס.
///
/// די אָפּעראַציע איז *O*(1).
///
/// # Panics
///
/// Panics אויב `end` ווייזט נישט צו די סאָף ביי אָפסעט פון אַ כאַראַקטער (`end + 1` איז אָדער אַן אָנהייב ביי אָפסט ווי דיפיינד דורך `is_char_boundary`, אָדער גלייַך צו `len`) אָדער `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// פּאַרס אַ ווערט פון אַ שטריקל
///
/// די [`from_str`] אופֿן פון `FromStr` איז אָפט געניצט ימפּליסאַטלי, דורך די [`parse`] אופֿן פון [`str`].
/// ביישפילן פֿון [[פּאַרס]] פֿאַר ביישפילן.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` האט נישט אַ לעבן פּאַראַמעטער, און אַזוי איר קענט בלויז פּאַרס טייפּס וואָס טאָן ניט אַנטהאַלטן אַ לעבן פּאַראַמעטער זיך.
///
/// אין אנדערע ווערטער איר קענט פּאַרסירן אַ `i32` מיט `FromStr`, אָבער נישט אַ `&i32`.
/// איר קענט פּאַרסירן אַ סטרוקטור וואָס כּולל אַן `i32`, אָבער נישט איינער וואָס כּולל אַן `&i32`.
///
/// # Examples
///
/// באַסיק ימפּלאַמענטיישאַן פון קס 00 קס אויף אַ בייַשפּיל קס 01 קס טיפּ:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// די פארבונדן טעות וואָס קענען זיין אומגעקערט פֿון פּאַרסינג.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// פּאַרסיז אַ שטריקל קס 00 קס צו צוריקקומען אַ ווערט פון דעם טיפּ.
    ///
    /// אויב פּאַרסינג סאַקסידז, צוריקקומען די ווערט ין קס 01 קס, אַנדערש ווען די שטריקל איז קראַנק-פאָרמאַטטעד, ווייַזן אַ טעות ספּעציפיש צו די ין קס 00 קס.
    /// די טעות טיפּ איז ספּעציפיש פֿאַר ימפּלאַמענטיישאַן פון די trait.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ מיט קס 01 קס, אַ טיפּ אַז ימפּלאַמאַנץ קס 00 קס:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// פּאַרס אַ `bool` פֿון אַ שטריקל.
    ///
    /// ייעלדס אַ קס 00 קס, ווייַל קס 01 קס קען אָדער קען זיין אַקטשאַוואַלי פּאַרסעאַבלע.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// באַמערקונג, אין פילע קאַסעס, די `.parse()` אופֿן אויף `str` איז מער געהעריק.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}