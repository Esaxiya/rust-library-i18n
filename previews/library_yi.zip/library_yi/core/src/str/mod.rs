//! שטריקל מאַניפּיאַליישאַן.
//!
//! פֿאַר מער דעטאַילס, זען די [`std::str`] מאָדולע.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. אויס פון גווול
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. אָנהייבן <=סוף
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. כאַראַקטער גרענעץ
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // געפֿינען די כאַראַקטער
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` מוזן זיין ווייניקער ווי לענ און אַ טשאַר גרענעץ
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// קערט די לענג פון `self`.
    ///
    /// די לענג איז אין ביטעס, ניט [`טשאַר`] אָדער גראַפעמעס.
    /// אין אנדערע ווערטער, עס קען נישט זיין וואָס אַ מענטש האלט די לענג פון די שטריקל.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// קערט `true` אויב `self` האט אַ לענג פון נול ביטעס.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// טשעקס אַז `אינדעקס`-טה בייט איז דער ערשטער בייט אין אַ UTF-8 קאָד פונט סיקוואַנס אָדער די סוף פון די שטריקל.
    ///
    ///
    /// דער אָנהייב און דער סוף פון דעם שטריקל (ווען `אינדעקס==קס 00 קס איז גערעכנט ווי לימאַץ.
    ///
    /// קערט קס 01 קס אויב קס 02 קס איז גרעסער ווי קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // אָנהייב פון קס 00 קס
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // רגע בייט פון קס 00 קס
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // דריט בייט פון קס 00 קס
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 און len זענען שטענדיק גוט.
        // טעסט פֿאַר 0 בישליימעס אַזוי אַז עס קענען לייכט אָפּטימיזירן די טשעק און האָפּקען לייענען שטריקל דאַטן פֿאַר דעם פאַל.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // דאָס איז אַ ביסל מאַגיש עקוויוואַלענט צו: b <128 ||ב>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// קאַנווערץ אַ שטריקל רעפטל צו אַ בייט רעפטל.
    /// ניצן די [`from_utf8`] פונקציע צו קאָנווערט די בייט רעפטל אין אַ שטריקל רעפטל.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // זיכערקייט: קאָנסט געזונט ווייַל מיר יבערמאַכן צוויי טייפּס מיט דער זעלביקער אויסלייג
        unsafe { mem::transmute(self) }
    }

    /// קאָנווערץ אַ מיוטאַבאַל שטריקל רעפטל צו אַ מיוטאַבאַל בייט רעפטל.
    ///
    /// # Safety
    ///
    /// די קאַללער מוזן ענשור אַז די אינהאַלט פון די רעפטל איז גילטיק UTF-8 איידער די באָרגן ענדס און די אַנדערלייינג `str` איז געניצט.
    ///
    ///
    /// די נוצן פון `str` וועמענס אינהאַלט איז נישט גילטיק UTF-8 איז אַנדיפיינד נאַטור.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // זיכערקייט: די וואַרפן פון קס 01 קס צו קס 02 קס איז זיכער זינט קס 00 קס
        // האט דער זעלביקער אויסלייג ווי קס 00 קס (בלויז ליבסטד קענען מאַכן דעם גאַראַנטירן).
        // דער ווייזן דערפעראַנס איז זיכער ווייַל עס קומט פֿון אַ מיוטאַבאַל רעפֿערענץ וואָס איז געראַנטיד גילטיק פֿאַר שרייבן.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// קאַנווערץ אַ שטריקל רעפטל צו אַ רוי טייַטל.
    ///
    /// ווי שטריקל סלייסאַז זענען אַ רעפטל פון ביטעס, די רוי טייַטל ווייזט צו אַ [`u8`].
    /// דער טייַטל וועט ווייַזן די ערשטע בייט פון די שטריקל רעפטל.
    ///
    /// די קאַללער מוזן ענשור אַז די אומגעקערט טייַטל איז קיינמאָל געשריבן צו.
    /// אויב איר דאַרפֿן צו מיוטייט די אינהאַלט פון די שטריקל רעפטל, נוצן [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// קאַנווערץ אַ מיוטאַבאַל שטריקל רעפטל צו אַ רוי טייַטל.
    ///
    /// ווי שטריקל סלייסאַז זענען אַ רעפטל פון ביטעס, די רוי טייַטל ווייזט צו אַ [`u8`].
    /// דער טייַטל וועט ווייַזן די ערשטע בייט פון די שטריקל רעפטל.
    ///
    /// עס איז דיין פֿאַראַנטוואָרטלעכקייט צו מאַכן זיכער אַז די שטריקל סלייס נאָר מאַדאַפייד אויף אַ וועג אַז עס בלייבט גילטיק קס 00 קס.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// קערט אַ סובסליסע פון קס 00 קס.
    ///
    /// דאָס איז די ניט-פּאַניקינג אָלטערנאַטיוו צו ינדעקסינג די `str`.
    /// קערט [`None`] ווען עקוויוואַלענט ינדעקסינג אָפּעראַציע וואָלט panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ינדיסעס נישט אויף קס 00 קס סיקוואַנס באַונדריז
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // אויס פון גווול
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// קערט אַ מיוטאַבאַל סובסליסע פון קס 00 קס.
    ///
    /// דאָס איז די ניט-פּאַניקינג אָלטערנאַטיוו צו ינדעקסינג די `str`.
    /// קערט [`None`] ווען עקוויוואַלענט ינדעקסינג אָפּעראַציע וואָלט panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ריכטיק לענג
    /// assert!(v.get_mut(0..5).is_some());
    /// // אויס פון גווול
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// רעטורנס אַן ונקעקקעד סובסליסע פון קס 00 קס.
    ///
    /// דאָס איז די אָפּגעשטעלט אַלטערנאַטיוו צו ינדעקסינג די `str`.
    ///
    /// # Safety
    ///
    /// קאַללערס פון דעם פֿונקציע זענען פאַראַנטוואָרטלעך אַז די פּריקאַנדישאַנז זענען צופֿרידן:
    ///
    /// * דער סטאַרטינג אינדעקס זאָל נישט יקסיד די סאָף אינדעקס;
    /// * ינדעקסיז מוזן זיין אין גווול פון דער אָריגינעל רעפטל;
    /// * ינדעקסיז מוזן זיין אויף די UTF-8 סיקוואַנס באַונדריז.
    ///
    /// אויב ניט, די אומגעקערט שטריקל סלייס קען דערמאָנען פאַרקריפּלט זכּרון אָדער אָנרירן די ינוואַריאַנץ קאַמיונאַקייטיד דורך די קס 00 קס טיפּ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // זיכערקייט: די קאַללער מוזן אַפּכאָולד די זיכערקייַט אָפּמאַך פֿאַר קס 00 קס;
        // די רעפטל איז דערעפערענסאַבלע ווייַל קס 00 קס איז אַ זיכער רעפֿערענץ.
        // די אומגעקערט טייַטל איז זיכער ווייַל `SliceIndex` ימפּלייז האָבן צו גאַראַנטירן אַז עס איז.
        unsafe { &*i.get_unchecked(self) }
    }

    /// קערט אַ מיוטאַבאַל, ונקעקקעד סובסליסע פון קס 00 קס.
    ///
    /// דאָס איז די אָפּגעשטעלט אַלטערנאַטיוו צו ינדעקסינג די `str`.
    ///
    /// # Safety
    ///
    /// קאַללערס פון דעם פֿונקציע זענען פאַראַנטוואָרטלעך אַז די פּריקאַנדישאַנז זענען צופֿרידן:
    ///
    /// * דער סטאַרטינג אינדעקס זאָל נישט יקסיד די סאָף אינדעקס;
    /// * ינדעקסיז מוזן זיין אין גווול פון דער אָריגינעל רעפטל;
    /// * ינדעקסיז מוזן זיין אויף די UTF-8 סיקוואַנס באַונדריז.
    ///
    /// אויב ניט, די אומגעקערט שטריקל סלייס קען דערמאָנען פאַרקריפּלט זכּרון אָדער אָנרירן די ינוואַריאַנץ קאַמיונאַקייטיד דורך די קס 00 קס טיפּ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // זיכערקייט: די קאַללער מוזן אַפּכאָולד די זיכערקייַט אָפּמאַך פֿאַר קס 00 קס;
        // די רעפטל איז דערעפערענסאַבלע ווייַל קס 00 קס איז אַ זיכער רעפֿערענץ.
        // די אומגעקערט טייַטל איז זיכער ווייַל `SliceIndex` ימפּלייז האָבן צו גאַראַנטירן אַז עס איז.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// קרעאַטעס אַ שטריקל רעפטל פון אן אנדער שטריקל רעפטל, בייפּאַסינג זיכערקייַט טשעקס.
    ///
    /// דאָס איז בכלל נישט רעקאַמענדיד, נוצן מיט וואָרענען!פֿאַר אַ זיכער אָלטערנאַטיוו, קס 01 קס און קס 00 קס.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// די נייַ רעפטל איז פֿון `begin` צו `end`, אַרייַנגערעכנט `begin` אָבער עקסקלודינג `end`.
    ///
    /// זען די [`slice_mut_unchecked`] אופֿן צו באַקומען אַ מיוטאַבאַל שטריקל רעפטל.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// קאַללערס פון דעם פֿונקציע זענען פאַראַנטוואָרטלעך אַז דריי פּריקאַנדישאַנז זענען צופֿרידן:
    ///
    /// * `begin` מוזן נישט יקסיד `end`.
    /// * `begin` און `end` מוזן זיין בייט שטעלעס אין די שטריקל רעפטל.
    /// * `begin` און קס 00 קס מוזן ליגן אויף קס 01 קס סיקוואַנס באַונדריז.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // זיכערקייט: די קאַללער מוזן אַפּכאָולד די זיכערקייַט אָפּמאַך פֿאַר קס 00 קס;
        // די רעפטל איז דערעפערענסאַבלע ווייַל קס 00 קס איז אַ זיכער רעפֿערענץ.
        // די אומגעקערט טייַטל איז זיכער ווייַל `SliceIndex` ימפּלייז האָבן צו גאַראַנטירן אַז עס איז.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// קרעאַטעס אַ שטריקל רעפטל פון אן אנדער שטריקל רעפטל, בייפּאַסינג זיכערקייַט טשעקס.
    /// דאָס איז בכלל נישט רעקאַמענדיד, נוצן מיט וואָרענען!פֿאַר אַ זיכער אָלטערנאַטיוו, קס 01 קס און קס 00 קס.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// די נייַ רעפטל איז פֿון `begin` צו `end`, אַרייַנגערעכנט `begin` אָבער עקסקלודינג `end`.
    ///
    /// אָנקוקן אַן יממוטאַבאַל שטריקל סלייסט, זען די [`slice_unchecked`] אופֿן.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// קאַללערס פון דעם פֿונקציע זענען פאַראַנטוואָרטלעך אַז דריי פּריקאַנדישאַנז זענען צופֿרידן:
    ///
    /// * `begin` מוזן נישט יקסיד `end`.
    /// * `begin` און `end` מוזן זיין בייט שטעלעס אין די שטריקל רעפטל.
    /// * `begin` און קס 00 קס מוזן ליגן אויף קס 01 קס סיקוואַנס באַונדריז.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // זיכערקייט: די קאַללער מוזן אַפּכאָולד די זיכערקייַט אָפּמאַך פֿאַר קס 00 קס;
        // די רעפטל איז דערעפערענסאַבלע ווייַל קס 00 קס איז אַ זיכער רעפֿערענץ.
        // די אומגעקערט טייַטל איז זיכער ווייַל `SliceIndex` ימפּלייז האָבן צו גאַראַנטירן אַז עס איז.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// טיילן אַ שטריקל רעפטל אין צוויי אין אַן אינדעקס.
    ///
    /// דער אַרגומענט, `mid`, זאָל זיין אַ פאָטאָ ביי ביי די אָנהייב פון די שטריקל.
    /// עס מוזן אויך זיין אויף די גרענעץ פון אַ UTF-8 קאָד פונט.
    ///
    /// די צוויי סלייסיז אומגעקערט גיין פון די אָנהייב פון די שטריקל רעפטל צו קס 00 קס, און פון קס 01 קס צו די סוף פון די שטריקל רעפטל.
    ///
    /// זען די [`split_at_mut`] אופֿן צו באַקומען מיוטאַבאַל שטריקל סלייסיז.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics אויב `mid` איז נישט אויף אַ UTF-8 קאָד פונט גרענעץ, אָדער אויב עס איז פאַרגאַנגענהייט די סוף פון די לעצטע קאָד פונט פון די שטריקל רעפטל.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // יס_טשאַר_באָונדאַרי טשעקס אַז דער אינדעקס איז אין [0, .len()]
        if self.is_char_boundary(mid) {
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `mid` איז אויף אַ טשאַר גרענעץ.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// טיילן אַ מיוטאַבאַל שטריקל רעפטל אין צוויי אין אַן אינדעקס.
    ///
    /// דער אַרגומענט, `mid`, זאָל זיין אַ פאָטאָ ביי ביי די אָנהייב פון די שטריקל.
    /// עס מוזן אויך זיין אויף די גרענעץ פון אַ UTF-8 קאָד פונט.
    ///
    /// די צוויי סלייסיז אומגעקערט גיין פון די אָנהייב פון די שטריקל רעפטל צו קס 00 קס, און פון קס 01 קס צו די סוף פון די שטריקל רעפטל.
    ///
    /// אָנקוקן אַנמוטאַבאַל שטריקל סלייסאַז, זען די [`split_at`] אופֿן.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics אויב `mid` איז נישט אויף אַ UTF-8 קאָד פונט גרענעץ, אָדער אויב עס איז פאַרגאַנגענהייט די סוף פון די לעצטע קאָד פונט פון די שטריקל רעפטל.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // יס_טשאַר_באָונדאַרי טשעקס אַז דער אינדעקס איז אין [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // זיכערקייט: פּונקט אָפּגעשטעלט אַז `mid` איז אויף אַ טשאַר גרענעץ.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// קערט אַ יטעראַטאָר איבער די [`טשאַר`] s פון אַ שטריקל רעפטל.
    ///
    /// ווי אַ שטריקל רעפטל באשטייט פון גילטיק קס 01 קס, מיר קענען יטעראַטע דורך אַ שטריקל רעפטל דורך קס 00 קס.
    /// דער אופֿן קערט אַזאַ יטעראַטאָר.
    ///
    /// עס איז וויכטיק צו געדענקען אַז [`char`] רעפּראַזענץ אַ אוניקאָד סקאַלאַר ווערט, און קען נישט גלייַכן דיין געדאַנק וועגן וואָס אַ 'character' איז.
    ///
    /// יטעראַטיאָן איבער גראַפעמע קלאַסטערז קען זיין וואָס איר טאַקע ווילן.
    /// די פאַנגקשאַנאַליטי איז נישט צוגעשטעלט דורך דער נאָרמאַל ביבליאָטעק פון Rust, קאָנטראָליר crates.io אַנשטאָט.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// געדענקט, [`טשאַר`ס] קען נישט גלייַכן דיין ינטוישאַן וועגן אותיות:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ניט קס 00 קס
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// קערט אַ יטעראַטאָר איבער די [`טשאַר`] s פון אַ שטריקל רעפטל און זייער שטעלעס.
    ///
    /// ווי אַ שטריקל רעפטל באשטייט פון גילטיק קס 01 קס, מיר קענען יטעראַטע דורך אַ שטריקל רעפטל דורך קס 00 קס.
    /// דער אופֿן קערט אַ יטעראַטאָר פון די [`טשאַר`] און זייער בייט שטעלעס.
    ///
    /// די יטעראַטאָר ייעלדס טופּאַלז.די שטעלע איז ערשטער, די [`char`] איז רגע.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// געדענקט, [`טשאַר`ס] קען נישט גלייַכן דיין ינטוישאַן וועגן אותיות:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // נישט (0, קס 00 קס)
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // טאָן די 3 דאָ, די לעצטע כאַראַקטער גענומען צוויי ביטעס
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// אַ יטעראַטאָר איבער די ביטעס פון אַ שטריקל רעפטל.
    ///
    /// ווי אַ שטריקל רעפטל באשטייט פון אַ סיקוואַנס פון ביטעס, מיר קענען יטערירן דורך אַ שטריקל רעפטל דורך בייט.
    /// דער אופֿן קערט אַזאַ יטעראַטאָר.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// ספּליץ אַ שטריקל רעפטל דורך ווייטספּייס.
    ///
    /// די יטעראַטאָר אומגעקערט וועט צוריקקומען שטריקל סלייסאַז וואָס זענען סאַב-סלייסיז פון דער אָריגינעל שטריקל סלייסט, אפגעשיידט דורך קיין סומע פון ווייט ספּייס.
    ///
    ///
    /// 'Whitespace' איז דיפיינד לויט די טערמינען פון Unicode Derived Core Property `White_Space`.
    /// אויב איר נאָר ווילן צו שפּאַלטן אויף ASCII ווהיטעספּאַסע אַנשטאָט, נוצן [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// אַלע מינים פון ווייטספּייס זענען קאַנסידערד:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ספּליץ אַ שטריקל רעפטל דורך ASCII ווייטספּייס.
    ///
    /// די יטעראַטאָר אומגעקערט וועט צוריקקומען שטריקל סלייסאַז וואָס זענען סאַב-סלייסאַז פון דער אָריגינעל שטריקל סלייסט, אפגעשיידט דורך קיין סומע פון ASCII ווייט ספּייס.
    ///
    ///
    /// ניצן [`split_whitespace`] צו שפּאַלטן דורך Unicode `Whitespace`.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// אַלע מינים פון ASCII ווייטספּייס זענען קאַנסידערד:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// אַ יטעראַטאָר איבער די שורות פון אַ שטריקל, ווי שטריקל סלייסיז.
    ///
    /// שורות זענען געענדיקט מיט אַ נייַ ליניע (`\n`) אָדער אַ וועגעלע צוריקקומען מיט אַ שורה קאָרמען (`\r\n`).
    ///
    /// די ענדיקן פון די לעצט שורה איז אַפּשאַנאַל.
    /// א שטריקל וואָס ענדס מיט אַ לעצט שורה ענדיקן וועט צוריקקומען די זעלבע שורות ווי אַן אַנדערש יידעניקאַל שטריקל אָן אַ לעצט שורה ענדיקן.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// די ענדיקן פון די לעצט שורה איז נישט פארלאנגט:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// אַ יטעראַטאָר איבער די שורות פון אַ שטריקל.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// קערט אַ יטעראַטאָר פון קס 01 קס איבער די שטריקל ענקאָודיד ווי קס 00 קס.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// קערט `true` אויב די געגעבן מוסטער גלייַכן אַ סאַב-רעפטל פון דעם שטריקל רעפטל.
    ///
    /// קערט `false` אויב נישט.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// קערט `true` אויב די געגעבן מוסטער גלייַכן אַ פּרעפיקס פון דעם שטריקל רעפטל.
    ///
    /// קערט `false` אויב נישט.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// קערט `true` אויב די געגעבן מוסטער גלייַכן אַ סאַפיקס פון דעם שטריקל רעפטל.
    ///
    /// קערט `false` אויב נישט.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// קערט דער בייט אינדעקס פון דער ערשטער כאַראַקטער פון דעם שטריקל רעפטל וואָס גלייַכן די מוסטער.
    ///
    /// קערט [`None`] אויב די מוסטער טוט נישט גלייַכן.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// מער קאָמפּליצירט פּאַטערנז ניצן פונט-פֿרייַ סטיל און קלאָוזשערז:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ניט געפֿינען די מוסטער:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// רעטורנס די בייט אינדעקס פֿאַר דער ערשטער כאַראַקטער פון די רעכט רעכט גלייַכן פון דעם מוסטער אין דעם שטריקל רעפטל.
    ///
    /// קערט [`None`] אויב די מוסטער טוט נישט גלייַכן.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// מער קאָמפּליצירט פּאַטערנז מיט קלאָוזשערז:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ניט געפֿינען די מוסטער:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// אַ יטעראַטאָר איבער סאַבסטרישאַנז פון דעם שטריקל רעפטל, אפגעשיידט דורך אותיות מאַטשט דורך אַ מוסטער.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר וועט זיין אַ [`DoubleEndedIterator`] אויב די מוסטער אַלאַוז אַ פאַרקערט זוכן און forward/reverse זוכן די זעלבע עלעמענטן.
    /// דאָס איז אמת פֿאַר, למשל, קס 01 קס, אָבער נישט פֿאַר קס 00 קס.
    ///
    /// אויב דער מוסטער אַלאַוז אַ פאַרקערט זוכן, אָבער די רעזולטאַטן קען זיין אַנדערש פון אַ פאָרויס זוכן, די [`rsplit`] אופֿן קענען זיין געוויינט.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// אויב די מוסטער איז אַ רעפטל פון טשאַרס, שפּאַלטן אויף יעדער פּאַסירונג פון קיין פון די אותיות:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// א מער קאָמפּליצירט מוסטער, ניצן אַ קלאָוזשער:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// אויב אַ שטריקל כּולל קייפל קאַנטיגיואַס סעפּאַראַטאָרס, איר וועט ענדיקן מיט ליידיק סטרינגס אין די פּראָדוקציע:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// קאַנטיניואַס סעפּאַראַטאָרס זענען אפגעשיידט דורך די ליידיק שטריקל.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// סעפּאַראַטאָרס אין די אָנהייב אָדער סוף פון אַ שטריקל זענען נעיגהבאָורעד דורך ליידיק סטרינגס.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// ווען די ליידיק שטריקל איז געניצט ווי אַ סעפּאַראַטאָר, עס סעפּערייץ יעדער כאַראַקטער אין די שטריקל, צוזאַמען מיט די אָנהייב און סוף פון די שטריקל.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// קאַנטיגיואַס סעפּאַראַטאָרס קענען פירן צו עפשער כידעשדיק נאַטור ווען ווייַס ספּייס איז געניצט ווי די סעפּאַראַטאָרדער קאָד איז ריכטיק:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ עס גיט איר:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ניצן [`split_whitespace`] פֿאַר דעם נאַטור.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// אַ יטעראַטאָר איבער סאַבסטרישאַנז פון דעם שטריקל רעפטל, אפגעשיידט דורך אותיות מאַטשט דורך אַ מוסטער.
    /// אַנדערש פון די יטעראַטאָר געשאפן דורך קס 00 קס אין אַז קס 01 קס לאָזן די מאַטשט טייל ווי דער טערמאַנייטער פון די סאַבסטרינג.
    ///
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// אויב די לעצטע עלעמענט פון דער שטריקל איז גלייַכן, דער עלעמענט איז באטראכט ווי דער טערמאַנייטער פון די פריערדיקע סאַבסטרינג.
    /// דער סאַבסטרישאַן איז די לעצטע נומער וואָס יטעראַטאָר האָט אומגעקערט.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// א יטעראַטאָר איבער סאַבסטרישאַנז פון די געגעבן שטריקל רעפטל, אפגעשיידט דורך אותיות מאַטשט דורך אַ מוסטער און יילדאַד אין פאַרקערט סדר.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר ריקווייערז אַז דער מוסטער שטיצט אַ פאַרקערט זוכן, און עס איז אַ [`DoubleEndedIterator`] אויב אַ forward/reverse זוכן די זעלבע עלעמענטן.
    ///
    ///
    /// די [`split`] אופֿן קענען זיין געוויינט פֿאַר יטערייטינג פון די פראָנט.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// א מער קאָמפּליצירט מוסטער, ניצן אַ קלאָוזשער:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// אַ יטעראַטאָר איבער סאַבסטרינגז פון די געגעבן שטריקל רעפטל, אפגעשיידט דורך אותיות מאַטשט דורך אַ מוסטער.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// עקוויוואַלענט צו קס 00 קס, אַחוץ אַז די טריילינג סאַבסטרינג איז סקיפּט אויב ליידיק.
    ///
    /// [`split`]: str::split
    ///
    /// דעם אופֿן קענען ווערן גענוצט פֿאַר דאַטן _terminated_ ווי _separated_ דורך אַ מוסטער.
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר וועט זיין אַ [`DoubleEndedIterator`] אויב די מוסטער אַלאַוז אַ פאַרקערט זוכן און forward/reverse זוכן די זעלבע עלעמענטן.
    /// דאָס איז אמת פֿאַר, למשל, קס 01 קס, אָבער נישט פֿאַר קס 00 קס.
    ///
    /// אויב דער מוסטער אַלאַוז אַ פאַרקערט זוכן, אָבער די רעזולטאַטן קען זיין אַנדערש פון אַ פאָרויס זוכן, די [`rsplit_terminator`] אופֿן קענען זיין געוויינט.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// אַן יטעראַטאָר איבער `self` סאַבסטרישאַנז, אפגעשיידט דורך אותיות מאַטשט דורך אַ מוסטער און יילדאַד אין פאַרקערט סדר.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// עקוויוואַלענט צו קס 00 קס, אַחוץ אַז די טריילינג סאַבסטרינג איז סקיפּט אויב ליידיק.
    ///
    /// [`split`]: str::split
    ///
    /// דעם אופֿן קענען ווערן גענוצט פֿאַר דאַטן _terminated_ ווי _separated_ דורך אַ מוסטער.
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר ריקווייערז אַז דער מוסטער שטיצט אַ פאַרקערט זוכן, און עס איז טאָפּל געענדיקט אויב אַ forward/reverse זוכן גיט די זעלבע עלעמענטן.
    ///
    ///
    /// די [`split_terminator`] אופֿן קענען זיין געוויינט פֿאַר יטערייטינג פון די פראָנט.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// אַן יטעראַטאָר איבער סאַבסטרישאַנז פון די געגעבן שטריקל רעפטל, אפגעשיידט דורך אַ מוסטער, ריסטריקטיד צו צוריקקומען צו רובֿ קס 00 קס זאכן.
    ///
    /// אויב `n` סאַבסטריישאַנז זענען אומגעקערט, די לעצטע סאַבסטריישאַן (די `n` סאַבסטרינג) כּולל די רעשט פון די שטריקל.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר וועט נישט זיין טאָפּל געענדיקט ווייַל עס איז נישט עפעקטיוו צו שטיצן.
    ///
    /// אויב דער מוסטער אַלאַוז אַ פאַרקערט זוכן, די [`rsplitn`] אופֿן קענען זיין געוויינט.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// א מער קאָמפּליצירט מוסטער, ניצן אַ קלאָוזשער:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// אַ יטעראַטאָר איבער סאַבסטרישאַנז פון דעם שטריקל סלייסט, אפגעשיידט דורך אַ מוסטער, סטאַרטינג פון די סוף פון די שטריקל, לימיטעד צו צוריקקומען צו רובֿ קס 00 קס זאכן.
    ///
    ///
    /// אויב `n` סאַבסטריישאַנז זענען אומגעקערט, די לעצטע סאַבסטריישאַן (די `n` סאַבסטרינג) כּולל די רעשט פון די שטריקל.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר וועט נישט זיין טאָפּל געענדיקט ווייַל עס איז נישט עפעקטיוו צו שטיצן.
    ///
    /// פֿאַר ספּליטינג פון די פראָנט, די [`splitn`] אופֿן קענען זיין געוויינט.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// א מער קאָמפּליצירט מוסטער, ניצן אַ קלאָוזשער:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// ספּליץ די שטריקל אויף דער ערשטער פּאַסירונג פון די ספּעסאַפייד דעלימיטער און קערט פּרעפיקס איידער דעלימיטער און סאַפיקס נאָך דעלימיטער.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// ספּליץ די שטריקל אויף די לעצטע פּאַסירונג פון די ספּעסאַפייד דעלימיטאָר און קערט פּרעפיקס איידער דעלימיטאָר און סאַפיקס נאָך דעלימיטער.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// אַ יטעראַטאָר איבער די דיסדזשאָינט שוועבעלעך פון אַ מוסטער אין די געגעבן שטריקל רעפטל.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר וועט זיין אַ [`DoubleEndedIterator`] אויב די מוסטער אַלאַוז אַ פאַרקערט זוכן און forward/reverse זוכן די זעלבע עלעמענטן.
    /// דאָס איז אמת פֿאַר, למשל, קס 01 קס, אָבער נישט פֿאַר קס 00 קס.
    ///
    /// אויב דער מוסטער אַלאַוז אַ פאַרקערט זוכן, אָבער די רעזולטאַטן קען זיין אַנדערש פון אַ פאָרויס זוכן, די [`rmatches`] אופֿן קענען זיין געוויינט.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// אַ יטעראַטאָר איבער די דיסדזשאָינט שוועבעלעך פון אַ מוסטער אין דעם שטריקל רעפטל, יילדאַד אין פאַרקערט סדר.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר ריקווייערז אַז דער מוסטער שטיצט אַ פאַרקערט זוכן, און עס איז אַ [`DoubleEndedIterator`] אויב אַ forward/reverse זוכן די זעלבע עלעמענטן.
    ///
    ///
    /// די [`matches`] אופֿן קענען זיין געוויינט פֿאַר יטערייטינג פון די פראָנט.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// אַ יטעראַטאָר איבער די דיסדזשאָינט שוועבעלעך פון אַ מוסטער אין דעם שטריקל רעפטל ווי געזונט ווי די אינדעקס אַז די גלייַכן סטאַרץ ביי.
    ///
    /// פֿאַר שוועבעלעך פון `pat` ין `self` וואָס אָוווערלאַפּ, בלויז די ינדאַסיז קאָראַספּאַנדינג צו דער ערשטער גלייַכן זענען אומגעקערט.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר וועט זיין אַ [`DoubleEndedIterator`] אויב די מוסטער אַלאַוז אַ פאַרקערט זוכן און forward/reverse זוכן די זעלבע עלעמענטן.
    /// דאָס איז אמת פֿאַר, למשל, קס 01 קס, אָבער נישט פֿאַר קס 00 קס.
    ///
    /// אויב דער מוסטער אַלאַוז אַ פאַרקערט זוכן, אָבער די רעזולטאַטן קען זיין אַנדערש פון אַ פאָרויס זוכן, די [`rmatch_indices`] אופֿן קענען זיין געוויינט.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // בלויז דער ערשטער קס 00 קס
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// אַ יטעראַטאָר איבער די שיידן שוועבעלעך פון אַ מוסטער אין קס 00 קס, יילדאַד אין פאַרקערט סדר צוזאמען מיט די אינדעקס פון די גלייַכן.
    ///
    /// פֿאַר שוועבעלעך פון `pat` אין `self` וואָס אָוווערלאַפּ, בלויז די ינדאַסיז קאָראַספּאַנדינג צו די לעצטע גלייַכן זענען אומגעקערט.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # יטעראַטאָר נאַטור
    ///
    /// די אומגעקערט יטעראַטאָר ריקווייערז אַז דער מוסטער שטיצט אַ פאַרקערט זוכן, און עס איז אַ [`DoubleEndedIterator`] אויב אַ forward/reverse זוכן די זעלבע עלעמענטן.
    ///
    ///
    /// די [`match_indices`] אופֿן קענען זיין געוויינט פֿאַר יטערייטינג פון די פראָנט.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // בלויז די לעצטע קס 00 קס
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// רעטורנס אַ שטריקל רעפטל מיט לידינג און טריילינג ווייטספּייס אַוועקגענומען.
    ///
    /// 'Whitespace' איז דיפיינד לויט די טערמינען פון Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// קערט אַ שטריקל רעפטל מיט לידינג ווייטספּייס אַוועקגענומען.
    ///
    /// 'Whitespace' איז דיפיינד לויט די טערמינען פון Unicode Derived Core Property `White_Space`.
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// `start` אין דעם קאָנטעקסט מיטל דער ערשטער שטעלע פון די ביט שטריקל;פֿאַר אַ לינקס-צו-רעכט שפּראַך ווי ענגליש אָדער רוסיש, דאָס וועט זיין לינקס זייַט, און פֿאַר רעכט-צו-לינקס שפּראַכן ווי אַראַביש אָדער העברעיש, דאָס וועט זיין די רעכט זייַט.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// רעטורנס אַ שטריקל רעפטל מיט טריילינג ווייטספּייס אַוועקגענומען.
    ///
    /// 'Whitespace' איז דיפיינד לויט די טערמינען פון Unicode Derived Core Property `White_Space`.
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// `end` אין דעם קאָנטעקסט מיטל די לעצטע שטעלע פון די בייט שטריקל;פֿאַר אַ לינקס-צו-רעכט שפּראַך ווי ענגליש אָדער רוסיש, דאָס וועט זיין רעכט זייַט, און פֿאַר רעכט-צו-לינקס שפּראַכן ווי אַראַביש אָדער העברעיש, דאָס וועט זיין די לינקס זייַט.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// קערט אַ שטריקל רעפטל מיט לידינג ווייטספּייס אַוועקגענומען.
    ///
    /// 'Whitespace' איז דיפיינד לויט די טערמינען פון Unicode Derived Core Property `White_Space`.
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// 'Left' אין דעם קאָנטעקסט מיטל דער ערשטער שטעלע פון די בייט שטריקל;פֿאַר אַ שפּראַך ווי אַראַביש אָדער העברעיש וואָס איז 'רעכט צו לינקס' אלא ווי 'לינקס צו רעכט', דאָס איז די _right_ זייַט, נישט די לינקס.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// רעטורנס אַ שטריקל רעפטל מיט טריילינג ווייטספּייס אַוועקגענומען.
    ///
    /// 'Whitespace' איז דיפיינד לויט די טערמינען פון Unicode Derived Core Property `White_Space`.
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// 'Right' אין דעם קאָנטעקסט מיטל די לעצטע שטעלע פון די בייט שטריקל;פֿאַר אַ שפּראַך ווי אַראַביש אָדער העברעיש וואָס איז 'רעכט צו לינקס' אלא ווי 'לינקס צו רעכט', דאָס איז די _left_ זייַט, נישט די רעכט.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// רעטורנס אַ שטריקל רעפטל מיט אַלע פּרעפיקסעס און סופפיקסעס וואָס גלייַכן אַ מוסטער ריפּיטידלי אַוועקגענומען.
    ///
    /// די [pattern] קענען זיין אַ [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// א מער קאָמפּליצירט מוסטער, ניצן אַ קלאָוזשער:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // געדענקען ערליאַסט באַוווסט גלייַכן, ריכטיק עס ונטער אויב
            // לעצטע גלייַכן איז אַנדערש
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // זיכערקייט: `Searcher` איז באַוווסט צו ווייַזן גילטיק ינדאַסיז.
        unsafe { self.get_unchecked(i..j) }
    }

    /// רעטורנס אַ שטריקל רעפטל מיט אַלע פּרעפיקסעס וואָס גלייַכן אַ מוסטער ריפּיטידלי אַוועקגענומען.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// `start` אין דעם קאָנטעקסט מיטל דער ערשטער שטעלע פון די ביט שטריקל;פֿאַר אַ לינקס-צו-רעכט שפּראַך ווי ענגליש אָדער רוסיש, דאָס וועט זיין לינקס זייַט, און פֿאַר רעכט-צו-לינקס שפּראַכן ווי אַראַביש אָדער העברעיש, דאָס וועט זיין די רעכט זייַט.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // זיכערקייט: `Searcher` איז באַוווסט צו ווייַזן גילטיק ינדאַסיז.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// רעטורנס אַ שטריקל רעפטל מיט די פּרעפיקס אַוועקגענומען.
    ///
    /// אויב די שטריקל סטאַרץ מיט די מוסטער קס 01 קס, קערט סאַבסטרינג נאָך די פּרעפיקס, אלנגעוויקלט אין קס 00 קס.
    /// ניט ענלעך קס 00 קס, דעם אופֿן רימוווז די פּרעפיקס פּונקט אַמאָל.
    ///
    /// אויב די שטריקל הייבט נישט מיט `prefix`, קערט `None`.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// קערט אַ שטריקל רעפטל מיט די סאַפיקס אַוועקגענומען.
    ///
    /// אויב די שטריקל ענדס מיט די מוסטער קס 01 קס, קערט די סאַבסטרינג איידער די סאַפיקס, אלנגעוויקלט אין קס 00 קס.
    /// ניט ענלעך קס 00 קס, דעם אופֿן רימוווז די סופפיקס פּונקט אַמאָל.
    ///
    /// אויב די שטריקל ענדיקן נישט מיט קס 01 קס, קערט קס 00 קס.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// רעטורנס אַ שטריקל רעפטל מיט אַלע סאַפיקס וואָס גלייַכן אַ מוסטער ריפּיטידלי אַוועקגענומען.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// `end` אין דעם קאָנטעקסט מיטל די לעצטע שטעלע פון די בייט שטריקל;פֿאַר אַ לינקס-צו-רעכט שפּראַך ווי ענגליש אָדער רוסיש, דאָס וועט זיין רעכט זייַט, און פֿאַר רעכט-צו-לינקס שפּראַכן ווי אַראַביש אָדער העברעיש, דאָס וועט זיין די לינקס זייַט.
    ///
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// א מער קאָמפּליצירט מוסטער, ניצן אַ קלאָוזשער:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // זיכערקייט: `Searcher` איז באַוווסט צו ווייַזן גילטיק ינדאַסיז.
        unsafe { self.get_unchecked(0..j) }
    }

    /// רעטורנס אַ שטריקל רעפטל מיט אַלע פּרעפיקסעס וואָס גלייַכן אַ מוסטער ריפּיטידלי אַוועקגענומען.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// 'Left' אין דעם קאָנטעקסט מיטל דער ערשטער שטעלע פון די בייט שטריקל;פֿאַר אַ שפּראַך ווי אַראַביש אָדער העברעיש וואָס איז 'רעכט צו לינקס' אלא ווי 'לינקס צו רעכט', דאָס איז די _right_ זייַט, נישט די לינקס.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// רעטורנס אַ שטריקל רעפטל מיט אַלע סאַפיקס וואָס גלייַכן אַ מוסטער ריפּיטידלי אַוועקגענומען.
    ///
    /// די [pattern] קענען זיין אַ `&str`, [`char`], אַ רעפטל פון [`טשאַר`] s, אָדער אַ פונקציע אָדער קלאָוזשער אַז דיטערמאַנז אויב אַ כאַראַקטער גלייַכן.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # טעקסט דירעקטיאָנאַליטי
    ///
    /// א שטריקל איז אַ סיקוואַנס פון ביטעס.
    /// 'Right' אין דעם קאָנטעקסט מיטל די לעצטע שטעלע פון די בייט שטריקל;פֿאַר אַ שפּראַך ווי אַראַביש אָדער העברעיש וואָס איז 'רעכט צו לינקס' אלא ווי 'לינקס צו רעכט', דאָס איז די _left_ זייַט, נישט די רעכט.
    ///
    ///
    /// # Examples
    ///
    /// פּשוט פּאַטערנז:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// א מער קאָמפּליצירט מוסטער, ניצן אַ קלאָוזשער:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// פּאַרס דעם שטריקל רעפטל אין אן אנדער טיפּ.
    ///
    /// ווייַל `parse` איז אַזוי גענעראַל, עס קען אָנמאַכן פּראָבלעמס מיט טיפּ ינפעראַנס.
    /// ווי אַזאַ, `parse` איז איינער פון די ווייניק מאָל איר וועט זען די סינטאַקס, מיט די באַרימט 'turbofish': `::<>`.
    ///
    /// דאָס העלפּס די ינפעראַנס אַלגערידאַם צו ספּעציפיצירן פֿאַר וואָס טיפּ איר'רע טריינג צו פּאַרסירן.
    ///
    /// `parse` איר קענען אָפּשיקן אין קיין טיפּ וואָס ימפּלאַמאַנץ די [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// [`Err`] וועט צוריקקומען אויב עס איז ניט מעגלעך צו פּאַרס דעם שטריקל רעפטל אין די געבעטן טיפּ.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// ניצן די 'turbofish' אַנשטאָט פון אַנאָטייטינג `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// ניט צו פּאַרס:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// טשעקס אויב אַלע אותיות אין דעם שטריקל זענען אין די ASCII קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // מיר קענען מייַכל יעדער בייט ווי כאַראַקטער דאָ: אַלע מולטי ביטע אותיות אָנהייבן מיט אַ בייט וואָס איז נישט אין די אַסקי ריי, אַזוי מיר וועלן שוין האַלטן דאָרט.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// טשעקס אַז צוויי סטרינגס זענען אַן ASCII פאַל-ינסענסיטיוו גלייַכן.
    ///
    /// די זעלבע ווי `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, אָבער אָן אַלאַקייטינג און קאַפּיינג טעמפּערעריז.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// קאַנווערץ דעם שטריקל צו זיין ASCII אויבערשטער פאַל עקוויוואַלענט אין-אָרט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`to_ascii_uppercase()`] צו צוריקקריגן אַ נייַע אויבערשטער ווערט אָן מאַדאַפייינג די יגזיסטינג.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // זיכערקייט: זיכער ווייַל מיר יבערמאַכן צוויי טייפּס מיט דער זעלביקער אויסלייג.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// קאָנווערץ דעם שטריקל צו זיין ASCII עקוויוואַלענט אין-אָרט עקוויוואַלענט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`to_ascii_lowercase()`] צו צוריקקריגן אַ נייַע ווערט מיט נידעריק נידעריקער קאַסעס אָן מאַדאַפאַקיישאַן.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // זיכערקייט: זיכער ווייַל מיר יבערמאַכן צוויי טייפּס מיט דער זעלביקער אויסלייג.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// ווייַזן אַן יטעראַטאָר אַז יסקייפּס יעדער טשאַר אין קס 01 קס מיט קס 00 קס.
    ///
    ///
    /// Note: בלויז עקסטענדעד גראַפעמע קאָדעפּאָינץ וואָס אָנהייבן די שטריקל וועט זיין אנטרונען.
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// ווייַזן אַן יטעראַטאָר אַז יסקייפּס יעדער טשאַר אין קס 01 קס מיט קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// ווייַזן אַן יטעראַטאָר אַז יסקייפּס יעדער טשאַר אין קס 01 קס מיט קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// קרעאַטעס אַ ליידיק סטר
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// קרעאַטעס אַ ליידיק מיוטאַבאַל סטר
    #[inline]
    fn default() -> Self {
        // זיכערקייט: די ליידיק שטריקל איז גילטיק UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// א נאָמען, קלאָנעאַבלע FN טיפּ
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // זיכערקייט: נישט זיכער
        unsafe { from_utf8_unchecked(bytes) }
    };
}