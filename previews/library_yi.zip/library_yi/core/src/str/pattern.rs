//! די שטריקל מוסטער אַפּי.
//!
//! דער מוסטער API אָפפערס אַ דזשאַנעריק מעקאַניזאַם פֿאַר ניצן פאַרשידענע מוסטער טייפּס ווען איר זוכן אַ שטריקל.
//!
//! פֿאַר מער דעטאַילס, זען די traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] און [`DoubleEndedSearcher`].
//!
//! כאָטש דעם אַפּי איז אַנסטייבאַל, עס איז יקספּאָוזד דורך סטאַביל אַפּיס אויף די קס 00 קס טיפּ.
//!
//! # Examples
//!
//! [`Pattern`] איז קס 04 קס אין די סטאַביל אַפּי פֿאַר קס 01 קס, קס 02 קס, סלייסיז פון קס 03 קס, און פאַנגקשאַנז און קלאָוזשערז ימפּלאַמענינג קס 00 קס.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // טשאַר מוסטער
//! assert_eq!(s.find('n'), Some(2));
//! // רעפטל פון טשאַרס מוסטער
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // קלאָוזשער מוסטער
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// א שטריקל מוסטער.
///
/// א קס 01 קס יקספּרעסאַז אַז די ימפּלאַמענינג טיפּ קענען ווערן געניצט ווי אַ שטריקל מוסטער פֿאַר זוכן אין אַ קס 00 קס.
///
/// פֿאַר בייַשפּיל, ביידע `'a'` און `"aa"` זענען פּאַטערנז וואָס וואָלט גלייַכן ביי אינדעקס `1` אין די שטריקל `"baaaab"`.
///
/// די trait זיך אַקטאַד ווי אַ בילדער פֿאַר אַ פֿאַרבונדן [`Searcher`] טיפּ, וואָס אַרבעט די פאַקטיש אַרבעט פון דערגייונג פֿאַלן פון די מוסטער אין אַ שטריקל.
///
///
/// דעפּענדינג אויף דעם טיפּ פון דעם מוסטער, די נאַטור פון מעטהאָדס ווי קס 00 קס און קס 01 קס קענען טוישן.
/// די טיש אונטן דיסקרייבז עטלעכע פון די ביכייוויערז.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// פארבונדן סעאַרטשער פֿאַר דעם מוסטער
    type Searcher: Searcher<'a>;

    /// בויען די פֿאַרבונדענע סערטשער פֿון `self` און די `haystack` צו זוכן אין.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// טשעקס צי די מוסטער גלייַכן ערגעץ אין די היי סטאַק
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// טשעקס צי די מוסטער גלייַכן אין די פראָנט פון די היי סטאַק
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// טשעקס צי די מוסטער גלייַכן אין די צוריק פון די היי סטאַק
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// רימוווז די מוסטער פֿון די פראָנט פון היי סטאַק, אויב עס גלייַכן.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // זיכערקייט: `Searcher` איז באַוווסט צו ווייַזן גילטיק ינדאַסיז.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// רימוווז די מוסטער פֿון די צוריק פון היי סטאַק, אויב עס גלייַכן.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // זיכערקייט: `Searcher` איז באַוווסט צו ווייַזן גילטיק ינדאַסיז.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// רעזולטאַט פון פאַך קס 01 קס אָדער קס 00 קס.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// יקספּרעסאַז אַז אַ גלייַכן פון דעם מוסטער איז געפֿונען אין `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// יקספּרעסאַז אַז `haystack[a..b]` איז פארווארפן ווי אַ מעגלעך גלייַכן פון דעם מוסטער.
    ///
    /// באַמערקונג אַז עס קען זיין מער ווי איין `Reject` צווישן צוויי `Match`es, עס איז קיין פאָדערונג פֿאַר זיי צו זיין קאַמביינד אין איין.
    ///
    ///
    Reject(usize, usize),
    /// יקספּרעסאַז אַז יעדער ביי פון די היי סטאַק איז באזוכט און ענדיקן די יטעראַטיאָן.
    ///
    Done,
}

/// א זוכער פֿאַר אַ שטריקל מוסטער.
///
/// די ז 0 טראַיט 0 ז פּראָווידעס מעטהאָדס פֿאַר שאַרף פֿאַר ניט-אָוווערלאַפּינג שוועבעלעך פון אַ מוסטער סטאַרטינג פון די פראָנט קס 00 קס פון אַ שטריקל.
///
/// עס וועט זיין ימפּלאַמענאַד דורך די `Searcher` טייפּס פון די [`Pattern`] ז 0 טראט 0 ז.
///
/// די trait איז אנגעצייכנט אַנסייף ווייַל די ינדאַסיז וואָס זענען געפֿונען דורך די [`next()`][Searcher::next] מעטהאָדס זענען פארלאנגט צו ליגן אויף גילטיק utf8 באַונדריז אין די כייסטאַק.
/// דעם ינייבאַלז קאָנסומערס פון דעם ז 0 טראַיט 0 ז צו רעפטל די היי סטאַק אָן נאָך רונטימע טשעקס.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter פֿאַר די אַנדערלייינג שטריקל צו זיין געזוכט אין
    ///
    /// וועט שטענדיק צוריקקומען די זעלבע קס 00 קס.
    fn haystack(&self) -> &'a str;

    /// דער ווייַטער זוכן שריט סטאַרץ פון די פראָנט.
    ///
    /// - קערט [`Match(a, b)`][SearchStep::Match] אויב `haystack[a..b]` גלייַכן די מוסטער.
    /// - קערט קס 00 קס אויב קס 01 קס קען נישט גלייַכן די מוסטער, אפילו טייל.
    /// - קערט [`Done`][SearchStep::Done] אויב יעדער ביי פון די היי סטאַק איז באזוכט.
    ///
    /// דער טייַך פון [`Match`][SearchStep::Match] און [`Reject`][SearchStep::Reject] וואַלועס אַרויף צו אַ [`Done`][SearchStep::Done] וועט אַנטהאַלטן אינדעקס ריינדזשאַז וואָס זענען שכייניש, ניט-אָוווערלאַפּינג, קאַווערינג די גאנצע כייסטאַק און לייגן די utf8 באַונדריז.
    ///
    ///
    /// א [`Match`][SearchStep::Match] רעזולטאַט דאַרף כּולל די גאנצע מאַטשט מוסטער, אָבער [`Reject`][SearchStep::Reject] רעזולטאַטן קען זיין צעטיילט אין אַרביטראַריש פילע שכייניש פראַגמאַנץ.ביידע ריינדזשאַז קען זיין נול לענג.
    ///
    /// ווי אַ בייַשפּיל, די מוסטער קס 00 קס און די כייסטאַק קס 01 קס קען פּראָדוצירן דעם טייַך
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// געפֿינען די ווייַטער [`Match`][SearchStep::Match] רעזולטאַט.זען קס 00 קס.
    ///
    /// ניט ענלעך קס 00 קס, עס איז קיין גאַראַנטירן אַז די אומגעקערט ריינדזשאַז פון דעם און קס 01 קס וועט אָוווערלאַפּ.
    /// דעם וועט קערן `(start_match, end_match)`, ווו סטאַרט_מאַטטש איז דער אינדעקס פון ווו די גלייַכן הייבט, און ענד_מאַטטש איז דער אינדעקס נאָך די סוף פון די גלייַכן.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// געפֿינען די ווייַטער [`Reject`][SearchStep::Reject] רעזולטאַט.זען קס 02 קס און קס 00 קס.
    ///
    /// ניט ענלעך קס 00 קס, עס איז קיין גאַראַנטירן אַז די אומגעקערט ריינדזשאַז פון דעם און קס 01 קס וועט אָוווערלאַפּ.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// א פאַרקערט סעאַרטשער פֿאַר אַ שטריקל מוסטער.
///
/// די ז 0 טראַיט 0 ז פּראָווידעס מעטהאָדס פֿאַר שאַרף פֿאַר ניט-אָוווערלאַפּינג שוועבעלעך פון אַ מוסטער סטאַרטינג פֿון די הינטער X00 קס פון אַ שטריקל.
///
/// עס וועט זיין ימפּלאַמענאַד דורך די [`Searcher`] טייפּס פון די [`Pattern`] ז 0 טראט 0 ז, אויב דער מוסטער שטיצט זוכן פֿון דער צוריק.
///
///
/// די אינדעקס ריינדזשאַז פון דעם trait וואָס זענען אומגעקערט זענען נישט פארלאנגט צו גלייך גלייך צו די פֿאָרווערטס זוכן אין פאַרקערט.
///
/// פֿאַר די סיבה וואָס די trait איז אנגעצייכנט אַנסייף, זען זיי trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// פּערפאָרמז די ווייַטער זוכן שריט סטאַרטינג פון די צוריק.
    ///
    /// - קערט קס 00 קס אויב קס 01 קס גלייַכן דעם מוסטער.
    /// - קערט קס 00 קס אויב קס 01 קס קען נישט גלייַכן דעם מוסטער, אפילו טייל.
    /// - קערט [`Done`][SearchStep::Done] אויב יעדער ביי פון די היי סטאַק איז באזוכט
    ///
    /// דער טייַך פון [`Match`][SearchStep::Match] און [`Reject`][SearchStep::Reject] וואַלועס אַרויף צו אַ [`Done`][SearchStep::Done] וועט אַנטהאַלטן אינדעקס ריינדזשאַז וואָס זענען שכייניש, ניט-אָוווערלאַפּינג, קאַווערינג די גאנצע כייסטאַק און לייגן די utf8 באַונדריז.
    ///
    ///
    /// א [`Match`][SearchStep::Match] רעזולטאַט דאַרף כּולל די גאנצע מאַטשט מוסטער, אָבער [`Reject`][SearchStep::Reject] רעזולטאַטן קען זיין צעטיילט אין אַרביטראַריש פילע שכייניש פראַגמאַנץ.ביידע ריינדזשאַז קען זיין נול לענג.
    ///
    /// ווי אַ בייַשפּיל, די מוסטער קס 03 קס און היי סטאַק קס 04 קס קען פּראָדוצירן דעם טייַך קס 01 קס, קס 02 קס, קס 00 קס, Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// געפֿינען די ווייַטער [`Match`][SearchStep::Match] רעזולטאַט.
    /// זען קס 00 קס.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// געפֿינען די ווייַטער [`Reject`][SearchStep::Reject] רעזולטאַט.
    /// זען קס 00 קס.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// א מאַרקער trait צו עקספּרעסס אַז אַ [`ReverseSearcher`] קענען זיין געניצט פֿאַר אַ [`DoubleEndedIterator`] ימפּלאַמענטיישאַן.
///
/// פֿאַר דעם, די [`Searcher`] און [`ReverseSearcher`] דאַרפֿן צו נאָכפאָלגן די באדינגונגען:
///
/// - אַלע רעזולטאַטן פון `next()` מוזן זיין יידעניקאַל צו די `next_back()` רעזולטאַטן אין פאַרקערט סדר.
/// - `next()` און קס 01 קס דאַרפֿן צו ביכייוו ווי די צוויי ענדס פון אַ קייט פון וואַלועס, דאָס איז זיי קענען נישט קס 00 קס.
///
/// # Examples
///
/// `char::Searcher` איז אַ קס 00 קס ווייַל זוכן פֿאַר אַ קס 01 קס בלויז ריקווייערז איר קוק אין איין אין אַ צייַט, וואָס ביכייווז די זעלבע פֿון ביידע ענדס.
///
/// `(&str)::Searcher` איז נישט אַ קס 01 קס ווייַל די מוסטער קס 02 קס אין די היי סטאַק קס 03 קס גלייַכן ווי קס 04 קס אָדער קס 00 קס, דיפּענדינג פון וואָס זייַט עס איז געזוכט.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// ימפּל פֿאַר טשאַר
/////////////////////////////////////////////////////////////////////////////

/// פארבונדן טיפּ פֿאַר קס 00 קס.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // זיכערקייַט ינוועריאַנט: קס 00 קס מוזן זיין אַ גילטיק קס 01 קס בייט אינדעקס פון קס 02 קס דעם ינוואַראַרי קענען זיין צעבראכן *ין* נעקסט_מאַטטש און נעקסט_מאַטטש_באַקק, אָבער זיי מוזן אַרויסגאַנג מיט פינגער אויף גילטיק קאָד פונט באַונדריז.
    //
    //
    /// `finger` איז די קראַנט בייט אינדעקס פון די פאָרויס זוכן.
    /// ימאַגינע אַז עס יגזיסץ איידער די בייט ביי זיין אינדעקס, י.ע.
    /// `haystack[finger]` איז דער ערשטער בייט פון די רעפטל וואָס מיר מוזן דורכקוקן בעשאַס פאָרויס זוכן
    ///
    finger: usize,
    /// `finger_back` איז די קראַנט בייט אינדעקס פון דער פאַרקערט זוכן.
    /// ימאַגינע אַז עס יגזיסץ נאָך די בייט ביי זיין אינדעקס, י.ע.
    /// היי סטאַק [פינגער_באַקק, 1] איז די לעצטע בייט פון די רעפטל וואָס מיר מוזן דורכקוקן בעשאַס פֿאָרווערטס זוכן (און אַזוי דער ערשטער ביטע צו זיין ינספּעקטיד ווען איר רופן קס 00 קס.
    ///
    finger_back: usize,
    /// דער כאַראַקטער וואָס איז געזוכט פֿאַר
    needle: char,

    // זיכערקייַט ינוועריאַנט: קס 00 קס מוזן זיין ווייניקער ווי 5
    /// די נומער ביטעס קס 01 קס נעמט ווען ענקאָודיד אין קס 00 קס.
    utf8_size: usize,
    /// א קס 01 קס ענקאָודיד קאָפּיע פון די קס 00 קס
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // זיכערקייט: 1-4 גאַראַנטירן זיכערקייַט פון קס 00 קס
        // 1. `self.finger` און `self.finger_back` זענען ביי יוניקאָדע באַונדריז (דאָס איז ינוועראַנט)
        // 2. `self.finger >= 0` זינט עס סטאַרץ ביי 0 און בלויז ינקריסיז
        // 3. `self.finger < self.finger_back` ווייַל אַנדערש טשאַר קס 01 קס וואָלט צוריקקומען קס 00 קס
        // 4.
        // `self.finger` קומט איידער די סוף פון די היי סטאַק ווייַל `self.finger_back` סטאַרץ אין די סוף און בלויז דיקריסאַז
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // לייג ביטע פאָטאָ פון קראַנט כאַראַקטער אָן שייַעך-קאָדירונג ווי קס 00 קס
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // באַקומען די היי סטאַק נאָך די לעצטע כאַראַקטער געפֿונען
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // די לעצטע בייט פון די utf8 קאָדעד נאָדל SAFETY: מיר האָבן אַן ינוועראַנט אַז `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // דער נייַ פינגער איז דער אינדעקס פון די בייט מיר געפֿונען, פּלוס איינער, זינט מיר מעמטשר'ד פֿאַר די לעצטע בייט פון די כאַראַקטער.
                //
                // באַמערקונג אַז דאָס קען נישט שטענדיק געבן אונדז אַ פינגער אויף די UTF8 גרענעץ.
                // אויב מיר * טאָן ניט געפֿינען אונדזער כאַראַקטער, מיר קען האָבן ינדאַקייטיד צו די ניט-לעצטע בייט פון אַ 3-בייט אָדער 4-בייט כאַראַקטער.
                // מיר קענען נישט נאָר האָפּקען צו דער ווייַטער גילטיק סטאַרטינג בייט ווייַל אַ כאַראַקטער ווי ꁁ (U + A041 יי סילאַבלע פּאַ), קס 00 קס קס 01 קס וועט שטענדיק געפֿינען די רגע בייט ווען איר זוכט פֿאַר די דריט.
                //
                //
                // אָבער, דאָס איז טאָוטאַלי אָוקיי.
                // בשעת מיר האָבן די ינוועריאַנט אַז קס 01 קס איז אויף אַ קס 02 קס גרענעץ, דעם ינוועריאַנט איז נישט רילייד אויף אין דעם אופֿן (עס איז רילייד אויף אין קס 00 קס.
                //
                // מיר וועלן בלויז אַרויסגאַנג דעם אופֿן ווען מיר דערגרייכן דעם סוף פון דער שטריקל אָדער אויב מיר געפֿינען עפּעס.ווען מיר געפֿינען עפּעס, די `finger` וועט זיין באַשטימט צו אַ UTF8 גרענעץ.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // גאָרנישט געפונען, אַרויסגאַנג
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // לאָזן next_reject נוצן די פעליקייַט ימפּלאַמענטיישאַן פון די סעאַרטשער ז 0 טראַיט 0 ז
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // זיכערהייט: זען דעם באַמערקונג פֿאַר next() אויבן
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // אַראָפּרעכענען ביי אָפסעט פון קראַנט כאַראַקטער אָן שייַעך-קאָדירונג ווי קס 00 קס
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // באַקומען די כייסטאַק צו די לעצטע כאַראַקטער געזוכט אָבער נישט אַרייַנגערעכנט
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // די לעצטע בייט פון די utf8 קאָדעד נאָדל SAFETY: מיר האָבן אַן ינוועראַנט אַז `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // מיר האָבן געזוכט אַ רעפטל פון self.finger, לייגן self.finger צו צוריקקריגן די אָריגינעל אינדעקס
                //
                let index = self.finger + index;
                // מעמרטשר וועט צוריקקומען די אינדעקס פון די בייט וואָס מיר וועלן צו געפֿינען.
                // אין פאַל פון אַ ASCII כאַראַקטער, דאָס איז טאַקע ווען מיר ווינטשן אונדזער נייַ פינגער צו זיין ("after" די געפֿונען טשאַר אין די פּאַראַדיגם פון פאַרקערט יטעראַטיאָן).
                //
                // פֿאַר מולטיביט טשאַרס, מיר דאַרפֿן צו האָפּקען די נומער פון מער ביטעס ווי ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // מאַך פינגער צו איידער די כאַראַקטער געפֿונען (י.ע. ביי זיין אָנהייב אינדעקס)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // מיר קענען נישט נוצן finger_back=אינדעקס, גרייס + 1 דאָ.
                // אויב מיר געפונען די לעצטע טשאַר פון אַ אַנדערש-סייזד כאַראַקטער (אָדער די מיטל בייט פון אַ אַנדערש כאַראַקטער) מיר דאַרפֿן צו זעץ די פינגער_באַק אַראָפּ צו קס 00 קס.
                // די סימאַלערלי מאכט `finger_back` די פּאָטענציעל צו זיין ניט מער אויף אַ גרענעץ, אָבער דאָס איז גוט ווייַל מיר נאָר אַרויסגאַנג דעם פֿונקציע אויף אַ גרענעץ אָדער ווען די היי סטאַק איז גאָר געזוכט.
                //
                //
                // ניט ענלעך next_match, דאָס קען נישט האָבן די פּראָבלעם פון ריפּיטיד ביטעס אין utf-8 ווייַל מיר זוכן פֿאַר די לעצטע בייט, און מיר קענען בלויז געפֿינען די לעצטע בייט ווען איר זוכן אין פאַרקערט.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // גאָרנישט געפונען, אַרויסגאַנג
                return None;
            }
        }
    }

    // לאָזן next_reject_back נוצן די פעליקייַט ימפּלאַמענטיישאַן פון די סעאַרטשער ז 0 טראַיט 0 ז
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// זוך פֿאַר טשאַרס וואָס זענען גלייַך צו אַ געגעבן קס 00 קס.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// ימפּלייז פֿאַר אַ MultiCharEq ראַפּער
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // פאַרגלייכן לענגקטס פון די ינעראַטאָר בייט רעפטל צו געפֿינען די לענג פון די קראַנט טשאַר
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // פאַרגלייכן לענגקטס פון די ינעראַטאָר בייט רעפטל צו געפֿינען די לענג פון די קראַנט טשאַר
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl for&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: טוישן/אַראָפּנעמען רעכט צו אַמביגיואַטי אין טייַטש.

/// פארבונדן טיפּ פֿאַר קס 00 קס.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// זוך פֿאַר טשאַרז וואָס זענען גלייַך צו קיין פון די [`טשאַר`] s אין די רעפטל.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// ימפּלייז פֿאַר F: קס 00 קס-> ז0באָול 0 ז
/////////////////////////////////////////////////////////////////////////////

/// פארבונדן טיפּ פֿאַר קס 00 קס.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// זוכן פֿאַר [`טשאַר`] s וואָס גלייַכן די געגעבן פּרעדיקאַט.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// ימפּל פֿאַר&&סטר
/////////////////////////////////////////////////////////////////////////////

/// דעלעגאַטעס צו די `&str` ימפּ.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// ימפּל פֿאַר קס 00 קס
/////////////////////////////////////////////////////////////////////////////

/// ניט-אַלאַקייטינג סאַבסטריטינג זוכן.
///
/// וועט שעפּן די מוסטער `""` ווי אומגעקערט ליידיק שוועבעלעך אין יעדער כאַראַקטער גרענעץ.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// טשעקס צי די מוסטער גלייַכן אין די פראָנט פון די היי סטאַק.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// רימוווז די מוסטער פֿון די פראָנט פון היי סטאַק, אויב עס גלייַכן.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // זיכערקייט: פּרעפיקס איז פּונקט וועראַפייד צו עקסיסטירן.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// טשעקס צי די מוסטער גלייַכן אין די צוריק פון די היי סטאַק.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// רימוווז די מוסטער פֿון די צוריק פון היי סטאַק, אויב עס גלייַכן.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // זיכערקייט: סאַפיקס איז פּונקט וועראַפייד צו עקסיסטירן.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// צוויי-וועג סאַבסטרינג סערטשער
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// פארבונדן טיפּ פֿאַר קס 00 קס.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // ליידיק נאָדל רידזשעקץ יעדער טשאַר און גלייַכן יעדער ליידיק שטריקל צווישן זיי
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher טראגט גילטיק *מאַטש* ינדיסעס אַז שפּאַלטן אין טשאַר באַונדריז ווי לאַנג ווי עס איז ריכטיק ריכטן און אַז הייסטאַק און נאָדל זענען גילטיק UTF-8 *רידזשעקץ* פון די אַלגערידאַם קענען פאַלן אויף קיין ינדיסיז, אָבער מיר וועלן גיין זיי מאַניואַלי צו דער ווייַטער כאַראַקטער גרענעץ, אַזוי אַז זיי זענען קס 01 קס זיכער.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // האָפּקען צו ווייַטער טשאַר גרענעץ
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // שרייַבן `true` און `false` קאַסעס צו מוטיקן די קאַמפּיילער צו ספּעשאַלייז די צוויי קאַסעס סעפּעראַטלי.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // האָפּקען צו ווייַטער טשאַר גרענעץ
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // שרייַבן `true` און `false`, ווי `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// די ינערלעך שטאַט פון די צוויי-וועג סאַבסטריטינג זוכן אַלגערידאַם.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// קריטיש פאַקטאָריזאַטיאָן אינדעקס
    crit_pos: usize,
    /// קריטיש פאַקטאָריזאַטיאָן אינדעקס פֿאַר ריווערסט נאָדל
    crit_pos_back: usize,
    period: usize,
    /// `byteset` איז אַן געשפּרייט (ניט טייל פון די צוויי-וועג אַלגערידאַם);
    /// עס איז אַ 64-ביסל קס 00 קס, ווו יעדער שטעלן ביסל קס 01 קס קאָראַספּאַנדז צו אַ (ביטע&63)==דזש פאָרשטעלן אין די נאָדל.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// אינדעקס אין נאָדל איידער וואָס מיר האָבן שוין גלייַכן
    memory: usize,
    /// אינדעקס אין נאָדל נאָך וואָס מיר האָבן שוין מאַטשט
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // א ספּעציעל ליינעוודיק דערקלערונג פון וואָס דאָ איז געגאנגען צו געפֿינען אין Crochemore און Rytter ס בוך "Text Algorithms", ch 13.
        // ספּאַסיפיקלי זען די קאָד פֿאַר קס 00 קס אויף פּ.
        // 323.
        //
        // וואָס ס 'געגאנגען אויף איז אַז מיר האָבן עטלעכע קריטיש פאַקטאָריזאַטיאָן (u, v) פון די נאָדל, און מיר וועלן צו באַשליסן צי u איז אַ סאַפיקס פון&v [.. צייַט].
        // אויב עס איז, מיר נוצן "Algorithm CP1".
        // אַנדערש מיר נוצן "Algorithm CP2", וואָס איז אָפּטימיזעד פֿאַר די צייט פון די נאָדל איז גרויס.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // קורץ צייט פאַל-די פּינטלעך פּינטלעך רעכענען אַ באַזונדער קריטיש פאַקטאָריזאַטיאָן פֿאַר די ריווערסט נאָדל x=u 'v' ווו | v '|<קס 00 קס.
            //
            // דאָס איז ספּיד אַרויף דורך די באַוווסט צייט.
            // באַמערקונג אַז אַ פאַל ווי קס=קס 00 קס קען זיין פאַקטאָרעד פּונקט פאָרווערדז (crit_pos=1, period=3) בשעת עס איז פאַקטאָרעד מיט דערנענטערנ צייט אין פאַרקערט (crit_pos=2, period=2).
            // מיר נוצן די געגעבן פאַרקערט פאַקטאָריזאַטיאָן אָבער מיר האַלטן די פּינטלעך צייַט.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // לאַנג צייט-מיר האָבן אַ דערנענטערנ זיך צו די פאַקטיש צייט און טאָן ניט נוצן מעמאָריזאַטיאָן.
            //
            //
            // דערנענטערנ זיך די צייט דורך max(|u|, |v|) + 1 נידעריקער.
            // די קריטיש פאַקטאָריזאַטיאָן איז עפעקטיוו צו נוצן פֿאַר פאָרויס און פאַרקערט זוכן.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // באָק ווערט צו באַטראַכטן אַז די צייט איז לאַנג
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // איינער פון די הויפּט געדאנקען פון צוויי-וועג איז אַז מיר פאַקטאָריז די נאָדל אין צוויי כאַווז, (u, v), און אָנהייבן טריינג צו געפֿינען v אין די היי סטאַק דורך סקאַנינג לינקס צו רעכט.
    // אויב v שוועבעלעך, מיר פּרובירן צו גלייַכן איר דורך סקאַנינג רעכטס צו לינקס.
    // ווי ווייַט מיר קענען שפּרינגען ווען מיר טרעפן אַ מיסמאַטש איז באזירט אויף די פאַקט אַז (u, v) איז אַ קריטיש פאַקטאָריזאַטיאָן פֿאַר די נאָדל.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` ניצט `self.position` ווי לויפֿער
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // קאָנטראָלירן אַז מיר האָבן פּלאַץ צו זוכן אין שטעלע + נעעדלע_לאַסט קענען נישט לויפן, אויב מיר יבערנעמען אַז סלייסאַז זענען באַונדאַד דורך די קייט פון יסייז.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // געשווינד שפּרינגען דורך גרויס פּאָרשאַנז אַנרילייטיד צו אונדזער סאַבסטרישאַן
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // זען אויב די רעכט טייל פון די נאָדל גלייַכן
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // זען אויב די לינקס טייל פון די נאָדל גלייַכן
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // מיר האָבן געפונען אַ גלייַכן!
            let match_pos = self.position;

            // Note: לייגן קס 00 קס אַנשטאָט פון קס 01 קס צו האָבן אָוווערלאַפּינג שוועבעלעך
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // שטעלן צו קס 00 קס, קס 01 קס פֿאַר אָוווערלאַפּינג שוועבעלעך
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // נאָכגיין די יידיאַז אין `next()`.
    //
    // די זוך זענען סיממעטריק, מיט period(x) = period(reverse(x)) און local_period(u, v) = local_period(reverse(v), reverse(u)), אַזוי אויב (u, v) איז אַ קריטיש פאַקטאָריזאַטיאָן, אַזוי (reverse(v), reverse(u)).
    //
    //
    // פֿאַר די פאַרקערט פאַל, מיר האָבן קאַלקיאַלייטיד אַ קריטיש פאַקטאָריזאַטיאָן קס=ו 'V' (פעלד קס 02 קס).מיר דאַרפֿן | u |&נבספּ;&נבספּ;&נבספּ;&נבספּ;<קס 01 קס פֿאַר די פאַרקערט.
    //
    // צו זוכן פאַרקערט דורך דעם היי סטאַק, מיר זוכן פאָרויס דורך אַ ריווערסט היי סטאַק מיט אַ ריווערסט נאָדל, וואָס ריכטן זיך ערשטער u 'און דעמאָלט v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` ניצט `self.end` ווי לויפֿער-אַזוי `next()` און `next_back()` זענען פרייַ.
        //
        let old_end = self.end;
        'search: loop {
            // קאָנטראָלירן אַז מיר האָבן פּלאַץ צו זוכן אין סוף, needle.len() וועט דרייען אַרום ווען עס איז ניט מער פּלאַץ, אָבער רעכט צו די סלייסט לימאַץ, עס קען קיינמאָל זיין ארומגעגאנגען אין די לענג פון היי סטאַק.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // געשווינד שפּרינגען דורך גרויס פּאָרשאַנז אַנרילייטיד צו אונדזער סאַבסטרישאַן
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // זען אויב די לינקס טייל פון די נאָדל גלייַכן
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // זען אויב די רעכט טייל פון די נאָדל גלייַכן
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // מיר האָבן געפונען אַ גלייַכן!
            let match_pos = self.end - needle.len();
            // Note: אונטער קס 00 קס אַנשטאָט קס 01 קס צו האָבן אָוווערלאַפּינג שוועבעלעך
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // צונויפרעכענען די מאַקסימום סאַפיקס פון `arr`.
    //
    // די מאַקסימום סאַפיקס איז אַ מעגלעך קריטיש פאַקטאָריזאַטיאָן (u, v) פון `arr`.
    //
    // קערט (`i`, `p`) ווו `i` איז די סטאַרטינג אינדעקס פון v און `p` איז די צייט פון v.
    //
    // `order_greater` דיטערמאַנז אויב די לעקסיקאַל סדר איז קס 01 קס אָדער קס 00 קס.
    // ביידע אָרדערס מוזן זיין קאַמפּיוטאַד-די אָרדערינג מיט דעם גרעסטן `i` גיט אַ קריטיש פאַקטאָריזאַטיאָן.
    //
    //
    // אין לאַנג קאַסעס, די ריזאַלטינג צייט איז נישט פּינטלעך (עס איז צו קורץ).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // קאָראַספּאַנדז צו איך אין די פּאַפּיר
        let mut right = 1; // קאָראַספּאַנדז צו דזש אין די פּאַפּיר
        let mut offset = 0; // קאָראַספּאַנדז צו ק אין די פּאַפּיר, אָבער סטאַרטינג בייַ 0
        // צו גלייַכן 0-באזירט ינדעקסינג.
        let mut period = 1; // קאָראַספּאַנדז צו פּ אין די פּאַפּיר

        while let Some(&a) = arr.get(right + offset) {
            // `left` וועט זיין ינבאַונדז ווען `right` איז.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // סופיקס איז קלענערער, די צייט איז גאַנץ פּרעפיקס ביז איצט.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // שטייַגן דורך יבערכאַזערונג פון די קראַנט צייַט.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // סופיקס איז גרעסערע, אָנהייב פֿון די איצטיקע אָרט.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // רעכענען די מאַקסימום סאַפיקס פון די פאַרקערט פון `arr`.
    //
    // די מאַקסימום סאַפיקס איז אַ מעגלעך קריטיש פאַקטאָריזאַטיאָן (u ', v') פון `arr`.
    //
    // קערט `i` ווו `i` איז די סטאַרטינג אינדעקס פון V ', פֿון די צוריק;
    // קערט גלייך ווען אַ X00 קס צייַט איז ריטשט.
    //
    // `order_greater` דיטערמאַנז אויב די לעקסיקאַל סדר איז קס 01 קס אָדער קס 00 קס.
    // ביידע אָרדערס מוזן זיין קאַמפּיוטאַד-די אָרדערינג מיט דעם גרעסטן `i` גיט אַ קריטיש פאַקטאָריזאַטיאָן.
    //
    //
    // אין לאַנג קאַסעס, די ריזאַלטינג צייט איז נישט פּינטלעך (עס איז צו קורץ).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // קאָראַספּאַנדז צו איך אין די פּאַפּיר
        let mut right = 1; // קאָראַספּאַנדז צו דזש אין די פּאַפּיר
        let mut offset = 0; // קאָראַספּאַנדז צו ק אין די פּאַפּיר, אָבער סטאַרטינג בייַ 0
        // צו גלייַכן 0-באזירט ינדעקסינג.
        let mut period = 1; // קאָראַספּאַנדז צו פּ אין די פּאַפּיר
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // סופיקס איז קלענערער, די צייט איז גאַנץ פּרעפיקס ביז איצט.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // שטייַגן דורך יבערכאַזערונג פון די קראַנט צייַט.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // סופיקס איז גרעסערע, אָנהייב פֿון די איצטיקע אָרט.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy אַלאַוז די אַלגערידאַם צו געשווינד האָפּקען ניט-שוועבעלעך ווי געשווינד ווי מעגלעך, אָדער צו אַרבעטן אין אַ מאָדע ווו עס עמיץ רידזשעקץ לעפיערעך געשווינד.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// האָפּקען צו גלייַכן ינטערוואַלז ווי געשווינד ווי מעגלעך
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// עמיט רעדזשעקץ קעסיידער
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}