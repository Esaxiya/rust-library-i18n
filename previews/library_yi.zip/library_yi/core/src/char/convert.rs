//! כאַראַקטער קאַנווערזשאַנז.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// קאָנווערט אַ קס 01 קס צו אַ קס 00 קס.
///
/// באַמערקונג אַז אַלע [`טשאַר`] s זענען גילטיק [`ו32`] s, און קענען זיין וואַרפן צו איינער מיט
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// אָבער, די פאַרקערט איז ניט אמת: ניט אַלע גילטיק [`u32`] s זענען גילטיק [`טשאַר`] s.
/// `from_u32()` וועט צוריקקומען קס 01 קס אויב די ינפּוט איז נישט אַ גילטיק ווערט פֿאַר אַ קס 00 קס.
///
/// פֿאַר קסקסקסקס פֿאַר אַ אַנסייף ווערסיע פון דעם פֿונקציע וואָס יגנאָרז די טשעקס.
///
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// אומגעקערט קס 01 קס ווען די ינפּוט איז נישט אַ גילטיק קס 00 קס:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// קאָנווערט אַ `u32` צו אַ `char`, יגנאָרינג די גילטיקייַט.
///
/// באַמערקונג אַז אַלע [`טשאַר`] s זענען גילטיק [`ו32`] s, און קענען זיין וואַרפן צו איינער מיט
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// אָבער, די פאַרקערט איז ניט אמת: ניט אַלע גילטיק [`u32`] s זענען גילטיק [`טשאַר`] s.
/// `from_u32_unchecked()` וועט איגנאָרירן דעם, און בליינדלי וואַרפן צו קס 00 קס, עפשער קריייטינג אַ פאַרקריפּלט איינער.
///
///
/// # Safety
///
/// די פֿונקציע איז אַנסייף ווייַל עס קען בויען פאַרקריפּלט `char` וואַלועס.
///
/// פֿאַר אַ זיכער ווערסיע פון דעם פֿונקציע, זען די [`from_u32`] פונקציע.
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `i` איז אַ גילטיק טשאַר ווערט.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// קאָנווערט אַ [`char`] אין אַ [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// קאָנווערט אַ [`char`] אין אַ [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // די טשאַר איז קאַסטעד צו די ווערט פון די קאָד פונט, און נול-עקסטענדעד צו 64 ביסל.
        // זען קס 00 קס
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// קאָנווערט אַ [`char`] אין אַ [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // די טשאַר איז קאַסטעד צו די ווערט פון די קאָד פונט, און נול-עקסטענדעד צו 128 ביסל.
        // זען קס 00 קס
        c as u128
    }
}

/// מאַפּס אַ בייט אין 0 קס 00 ..=0 קס פף צו אַ קס 00 קס וועמענס קאָד פונט האט די זעלבע ווערט, אין ו + 0000 ..=ו + 00 פף.
///
/// אוניקאָד איז דיזיינד אַזוי אַז דאָס יפעקטיוולי דעקאָדעס ביטעס מיט די כאַראַקטער קאָדירונג וואָס IANA רופט ISO-8859-1.
/// די קאָדירונג איז קאַמפּאַטאַבאַל מיט ASCII.
///
/// באַמערקונג אַז דאָס איז אַנדערש פון ISO/IEC 8859-1 אַקאַ
/// ISO 8859-1 (מיט אַ ווייניקער ביפסטייק), וואָס בלעטער עטלעכע "blanks", בייט וואַלועס וואָס זענען נישט אַסיינד צו קיין כאַראַקטער.
/// ISO-8859-1 (די IANA one) אַסיינז זיי צו די C0 און C1 קאָנטראָל קאָודז.
///
/// באַמערקונג אַז דאָס איז *אויך* אַנדערש פון Windows-1252 אַקאַ
/// קאָד בלאַט 1252, וואָס איז אַ סופּערסעט קס 00 קס 8859-1 וואָס אַסיינז עטלעכע (ניט אַלע!) בלאַנקס צו פּונקטואַציע און פאַרשידן לאַטייַן אותיות.
///
/// צו פאַרמישן די זאכן ווייַטער, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` און `windows-1252` זענען אַלע ייליאַסיז פֿאַר אַ סופּערסעט פון Windows-1252 וואָס פּלאָמבירן די רוען בלאַנקס מיט קאָראַספּאַנדינג קס 04 קס און קס 05 קס קאָנטראָל קאָודז.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// קאָנווערט אַ [`u8`] אין אַ [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// א טעות וואָס קענען זיין אומגעקערט ווען פּאַרסינג אַ טשאַר.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // זיכערקייט: אָפּגעשטעלט אַז דאָס איז אַ לעגאַל אוניקאָד ווערט
            Ok(unsafe { transmute(i) })
        }
    }
}

/// די טעות טיפּ איז אומגעקערט ווען אַ קאַנווערזשאַן פון u32 צו טשאַר פיילז.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// קאָנווערט אַ ציפֿער אין די געגעבן ראַדיקס צו אַ `char`.
///
/// א קס 01 קס דאָ איז מאל אויך גערופן אַ קס 00 קס.
/// א ראַדיקס פון צוויי ינדיקייץ אַ ביינערי נומער, אַ ראַדיקס פון צען, דעצימאַל, און אַ ראַדיקס פון זעכצן, העקסאַדעסימאַל, צו געבן עטלעכע פּראָסט וואַלועס.
///
/// אַרביטראַרי ראַדיסעס זענען געשטיצט.
///
/// `from_digit()` וועט צוריקקומען `None` אויב די אַרייַנשרייַב איז נישט אַ ציפֿער אין די געגעבן ראַדיקס.
///
/// # Panics
///
/// Panics אויב איר געבן אַ ראַדיקס גרעסער ווי 36.
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // דעצימאַל 11 איז אַ איין ציפֿער אין באַזע 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// קערט `None` ווען די ינפּוט איז נישט אַ ציפֿער:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// פאָרן אַ גרויס ראַדיקס, קאָזינג אַ panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}