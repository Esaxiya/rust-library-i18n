//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// די העכסטן גילטיק קאָד פונט אַז `char` קענען האָבן.
    ///
    /// א קס 02 קס איז אַ קס 00 קס, וואָס מיטל אַז עס איז אַ קס 01 קס, אָבער בלויז אין אַ זיכער קייט.
    /// `MAX` איז די העכסטן גילטיק קאָד פונט וואָס איז אַ גילטיק קס 00 קס.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () איז געניצט אין אוניקאָד צו פאָרשטעלן אַ דיקאָודינג טעות.
    ///
    /// עס קען פּאַסירן, למשל, ווען די [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) בייז X-X קס ביטעס זענען געשאפן.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// די ווערסיע פון [Unicode](http://www.unicode.org/) וואָס די Unicode פּאַרץ פון `char` און `str` מעטהאָדס זענען באזירט אויף.
    ///
    /// ניו ווערסיעס פון אוניקאָד זענען קעסיידער באפרייט און דערנאָך אַלע מעטהאָדס אין דער נאָרמאַל ביבליאָטעק דיפּענדינג אויף אוניקאָד זענען דערהייַנטיקט.
    /// דעריבער די נאַטור פון עטלעכע `char` און `str` מעטהאָדס און די ווערט פון דעם קעסיידערדיק ענדערונגען איבער צייַט.
    /// דאָס איז *נישט* באטראכט ווי אַ ברייקינג ענדערונג.
    ///
    /// די ווערסיע נאַמבערינג סכעמע איז דערקלערט אין [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// קרעאַטעס אַ יטעראַטאָר איבער די קס 01 קס קאָדעד קאָד ווייזט אין קס 00 קס, אומגעקערט אַנפּערד סעראַגאַץ ווי `ערר`ס.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// א לאָססי דיקאָודער קענען זיין באקומען דורך ריפּלייסט די `Err` רעזולטאַטן מיט די פאַרבייַט כאַראַקטער:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// קאָנווערט אַ קס 01 קס צו אַ קס 00 קס.
    ///
    /// באַמערקונג אַז אַלע `טשאַר`ס זענען גילטיק [`ו32`] s, און קענען זיין וואַרפן צו איינער מיט
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// אָבער, די פאַרקערט איז נישט אמת: ניט אַלע גילטיק [`u32`] s זענען גילטיק`טשאַר`ס.
    /// `from_u32()` וועט צוריקקומען קס 01 קס אויב די ינפּוט איז נישט אַ גילטיק ווערט פֿאַר אַ קס 00 קס.
    ///
    /// פֿאַר קסקסקסקס פֿאַר אַ אַנסייף ווערסיע פון דעם פֿונקציע וואָס יגנאָרז די טשעקס.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// אומגעקערט קס 01 קס ווען די ינפּוט איז נישט אַ גילטיק קס 00 קס:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// קאָנווערט אַ `u32` צו אַ `char`, יגנאָרינג די גילטיקייַט.
    ///
    /// באַמערקונג אַז אַלע `טשאַר`ס זענען גילטיק [`ו32`] s, און קענען זיין וואַרפן צו איינער מיט
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// אָבער, די פאַרקערט איז נישט אמת: ניט אַלע גילטיק [`u32`] s זענען גילטיק`טשאַר`ס.
    /// `from_u32_unchecked()` וועט איגנאָרירן דעם, און בליינדלי וואַרפן צו קס 00 קס, עפשער קריייטינג אַ פאַרקריפּלט איינער.
    ///
    ///
    /// # Safety
    ///
    /// די פֿונקציע איז אַנסייף ווייַל עס קען בויען פאַרקריפּלט `char` וואַלועס.
    ///
    /// פֿאַר אַ זיכער ווערסיע פון דעם פֿונקציע, זען די [`from_u32`] פונקציע.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // זיכערהייט: דער זיכערקייט אָפּמאַך מוזן זיין אַפּכעלד דורך די קאָלער.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// קאָנווערט אַ ציפֿער אין די געגעבן ראַדיקס צו אַ `char`.
    ///
    /// א קס 01 קס דאָ איז מאל אויך גערופן אַ קס 00 קס.
    /// א ראַדיקס פון צוויי ינדיקייץ אַ ביינערי נומער, אַ ראַדיקס פון צען, דעצימאַל, און אַ ראַדיקס פון זעכצן, העקסאַדעסימאַל, צו געבן עטלעכע פּראָסט וואַלועס.
    ///
    /// אַרביטראַרי ראַדיסעס זענען געשטיצט.
    ///
    /// `from_digit()` וועט צוריקקומען `None` אויב די אַרייַנשרייַב איז נישט אַ ציפֿער אין די געגעבן ראַדיקס.
    ///
    /// # Panics
    ///
    /// Panics אויב איר געבן אַ ראַדיקס גרעסער ווי 36.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // דעצימאַל 11 איז אַ איין ציפֿער אין באַזע 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// קערט `None` ווען די ינפּוט איז נישט אַ ציפֿער:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// פאָרן אַ גרויס ראַדיקס, קאָזינג אַ panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// טשעקס אויב אַ `char` איז אַ ציפֿער אין די געגעבן ראַדיקס.
    ///
    /// א קס 01 קס דאָ איז מאל אויך גערופן אַ קס 00 קס.
    /// א ראַדיקס פון צוויי ינדיקייץ אַ ביינערי נומער, אַ ראַדיקס פון צען, דעצימאַל, און אַ ראַדיקס פון זעכצן, העקסאַדעסימאַל, צו געבן עטלעכע פּראָסט וואַלועס.
    ///
    /// אַרביטראַרי ראַדיסעס זענען געשטיצט.
    ///
    /// קאַמפּערד מיט קס 01 קס, דעם פֿונקציע בלויז אנערקענט די אותיות קס 02 קס, קס 03 קס און קס 00 קס.
    ///
    /// 'Digit' איז דיפיינד בלויז די פאלגענדע אותיות:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// פֿאַר אַ מער פולשטענדיק פארשטאנד פון קס 01 קס, זען קס 00 קס.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics אויב איר געבן אַ ראַדיקס גרעסער ווי 36.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// פאָרן אַ גרויס ראַדיקס, קאָזינג אַ panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// קאָנווערט אַ `char` צו אַ ציפֿער אין די געגעבן ראַדיקס.
    ///
    /// א קס 01 קס דאָ איז מאל אויך גערופן אַ קס 00 קס.
    /// א ראַדיקס פון צוויי ינדיקייץ אַ ביינערי נומער, אַ ראַדיקס פון צען, דעצימאַל, און אַ ראַדיקס פון זעכצן, העקסאַדעסימאַל, צו געבן עטלעכע פּראָסט וואַלועס.
    ///
    /// אַרביטראַרי ראַדיסעס זענען געשטיצט.
    ///
    /// 'Digit' איז דיפיינד בלויז די פאלגענדע אותיות:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// קערט `None` אויב די `char` טוט נישט אָפּשיקן צו אַ ציפֿער אין די געגעבן ראַדיקס.
    ///
    /// # Panics
    ///
    /// Panics אויב איר געבן אַ ראַדיקס גרעסער ווי 36.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// דורכפאַל פון אַ ניט-ציפֿער רעזולטאַטן אין דורכפאַל:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// פאָרן אַ גרויס ראַדיקס, קאָזינג אַ panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // די קאָד איז צעטיילט דאָ צו פֿאַרבעסערן דורכפירונג גיכקייַט פֿאַר קאַסעס ווו די `radix` איז קעסיידערדיק און 10 אָדער קלענערער
        //
        let val = if likely(radix <= 10) {
            // אויב נישט אַ ציפֿער, אַ נומער גרעסער ווי ראַדיקס וועט זיין באשאפן.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// רעטורנס אַ יטעראַטאָר וואָס גיט די העקסאַדעסימאַל אוניקאָד אַנטלויפן פון אַ כאַראַקטער ווי `טשאַר`ס.
    ///
    /// דאָס וועט אַנטלויפן אותיות מיט די Rust סינטאַקס פון די פאָרעם `\u{NNNNNN}`, ווו `NNNNNN` איז אַ העקסאַדעסימאַל פאַרטרעטונג.
    ///
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // אָדער-ינג 1 ינשורז אַז פֿאַר C==0 די קאָד קאַלקיאַלייץ אַז איין ציפֿער זאָל זיין געדרוקט און (וואָס איז די זעלבע) ויסמיידן די (31, 32) אַנדערפלאָו
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // דער אינדעקס פון די מערסט באַטייטיק העקס ציפֿער
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// אַן עקסטענדעד ווערסיע פון קס 00 קס וואָס אָפּטיאָנאַללי אַלאַוז עסקאַפּינג עקסטענדעד גראַפעמע קאָדעפּאָינטס.
    /// דאָס אַלאַוז אונדז צו פאָרמירן אותיות ווי נאָנספּאַסינג מאַרקס בעסער ווען זיי זענען אין די אָנהייב פון אַ שטריקל.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// רעטורנס אַ יטעראַטאָר וואָס ייעלדס די ליטעראַל אַנטלויפן קאָד פון אַ כאַראַקטער ווי `טשאַר`ס.
    ///
    /// דאָס וועט אַנטלויפן די אותיות ענלעך צו די `Debug` ימפּלאַמענטיישאַנז פון `str` אָדער `char`.
    ///
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// רעטורנס אַ יטעראַטאָר וואָס ייעלדס די ליטעראַל אַנטלויפן קאָד פון אַ כאַראַקטער ווי `טשאַר`ס.
    ///
    /// די פעליקייַט איז אויסדערוויילט מיט אַ פאָרורטייל צו פּראָדוצירן ליטעראַלס וואָס זענען לעגאַל אין אַ פאַרשיידנקייַט פון שפּראַכן, אַרייַנגערעכנט C++ 11 און ענלעך C-משפּחה שפּראַכן.
    /// די פּינטלעך כּללים זענען:
    ///
    /// * קוויטל איז אנטרונען ווי קס 00 קס.
    /// * וועגעלע צוריקקומען איז אנטרונען ווי קס 00 קס.
    /// * שורה קאָרמען איז אנטרונען ווי קס 00 קס.
    /// * איין ציטירן איז אנטרונען ווי `\'`.
    /// * טאָפּל ציטירן איז אנטרונען ווי `\"`.
    /// * Backslash איז אנטרונען ווי `\\`.
    /// * קיין כאַראַקטער אין די 'פּרינטאַבאַל אַסקי' קייט קס 01 קס .. קס 00 קס ינקלוסיוו איז נישט אנטרונען.
    /// * אַלע אנדערע אותיות זענען העקסאַדעסימאַל אוניקאָד יסקייפּס;זען קס 00 קס.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// קערט די נומער פון ביטעס וואָס `char` וואָלט דאַרפֿן אויב עס איז קאָדעד אין UTF-8.
    ///
    /// די נומער פון ביטעס איז שטענדיק צווישן 1 און 4, אַרייַנגערעכנט.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// די קס 01 קס טיפּ געראַנטיז אַז די אינהאַלט איז קס 00 קס, און אַזוי מיר קענען פאַרגלייכן די לענג וואָס עס וואָלט נעמען אויב יעדער קאָד פונט איז געווען רעפּריזענטיד ווי אַ קס 02 קס קעגן די קס 03 קס זיך:
    ///
    ///
    /// ```
    /// // ווי טשאַרז
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ביידע קענען זיין רעפּריזענטיד ווי דרייַ ביטעס
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ווי אַ קס 01 קס, די צוויי זענען ענקאָודיד אין קס 00 קס
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // מיר קענען זען אַז זיי נעמען זעקס ביטעס גאַנץ ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... פּונקט ווי די &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// קערט די נומער פון 16-ביסל קאָד וניץ דעם `char` וואָלט דאַרפֿן אויב עס איז קאָדעד אין UTF-16.
    ///
    ///
    /// זען די דאָקומענטאַטיאָן פֿאַר [`len_utf8()`] פֿאַר מער דערקלערונג פון דעם באַגריף.
    /// די פֿונקציע איז אַ שפּיגל אָבער פֿאַר קס 01 קס אַנשטאָט פון קס 00 קס.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// קאָדעס דעם כאַראַקטער ווי UTF-8 אין די צוגעשטעלט בייט באַפער, און דאַן קערט די סובסליסע פון די באַפער וואָס כּולל די ענקאָודיד כאַראַקטער.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב די באַפער איז נישט גרויס גענוג.
    /// א באַפער פון לענג פיר איז גרויס גענוג צו ענקאָוד קיין `char`.
    ///
    /// # Examples
    ///
    /// אין ביידע ביישפילן, 'ß' נעמט צוויי ביטעס צו ענקאָוד.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// א קליין קליין באַפער:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // זיכערקייט: קס 01 קס איז נישט אַ סעראַגאַט, אַזוי דאָס איז גילטיק קס 00 קס.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// ענקאָוד דעם כאַראַקטער ווי קס 00 קס אין די צוגעשטעלט קס 01 קס באַפער, און דאַן קערט די סובסליסע פון די באַפער אַז כּולל די ענקאָודיד כאַראַקטער.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב די באַפער איז נישט גרויס גענוג.
    /// א באַפער פון לענג 2 איז גרויס גענוג צו ענקאָוד קיין `char`.
    ///
    /// # Examples
    ///
    /// אין ביידע די ביישפילן, '𝕊' נעמט צוויי U16 צו ענקאָוד.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// א קליין קליין באַפער:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// קערט `true` אויב די `char` האט די `Alphabetic` פאַרמאָג.
    ///
    /// `Alphabetic` איז דיסקרייבד אין טשאַפּטער 4 (כאַראַקטער פּראָפּערטיעס) פון די [Unicode Standard] און ספּעציפיצירט אין די [Unicode Character Database][ucd] קס 00 קס.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ליבע איז פילע זאכן, אָבער עס איז נישט אַלפאַבעטיק
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// קערט `true` אויב די `char` האט די `Lowercase` פאַרמאָג.
    ///
    /// `Lowercase` איז דיסקרייבד אין טשאַפּטער 4 (כאַראַקטער פּראָפּערטיעס) פון די [Unicode Standard] און ספּעציפיצירט אין די [Unicode Character Database][ucd] קס 00 קס.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // די פאַרשידן כינעזיש סקריפּס און פּונקטואַציע טאָן ניט האָבן קאַסעס, און אַזוי:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// קערט `true` אויב די `char` האט די `Uppercase` פאַרמאָג.
    ///
    /// `Uppercase` איז דיסקרייבד אין טשאַפּטער 4 (כאַראַקטער פּראָפּערטיעס) פון די [Unicode Standard] און ספּעציפיצירט אין די [Unicode Character Database][ucd] קס 00 קס.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // די פאַרשידן כינעזיש סקריפּס און פּונקטואַציע טאָן ניט האָבן קאַסעס, און אַזוי:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// קערט `true` אויב די `char` האט די `White_Space` פאַרמאָג.
    ///
    /// `White_Space` איז ספּעסיפיעד אין די קס 01 קס קס 00 קס.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // אַ ניט-ברייקינג פּלאַץ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// קערט קס 01 קס אויב דעם קס 02 קס סאַטיספייז אָדער קס 03 קס אָדער קס 00 קס.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// קערט `true` אויב דעם `char` האט די אַלגעמיינע קאַטעגאָריע פֿאַר קאָנטראָל קאָודז.
    ///
    /// קאָנטראָל קאָודז (קאָד ווייזט מיט די אַלגעמיינע קאַטעגאָריע פון קס 03 קס) זענען דיסקרייבד אין טשאַפּטער 4 (כאַראַקטער פּראָפּערטיעס) פון די קס 01 קס און ספּעציפיצירט אין די קס 02 קס קס 00 קס.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // ו + 009 ק, שטריקל טערמינאַטאָר
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// קערט `true` אויב די `char` האט די `Grapheme_Extend` פאַרמאָג.
    ///
    /// `Grapheme_Extend` איז דיסקרייבד אין קס 01 קס און ספּעסאַפייד אין די קס 02 קס קס 00 קס.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// קערט `true` אויב די `char` האט איינער פון די אַלגעמיינע קאַטעגאָריעס פֿאַר נומערן.
    ///
    /// די אַלגעמיינע קאַטעגאָריעס פֿאַר נומערן (`Nd` פֿאַר דעצימאַל דידזשאַץ, `Nl` פֿאַר נומער-ווי נומעריק אותיות, און `No` פֿאַר אנדערע נומעריק אותיות) זענען ספּעציפיצירט אין די [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// קערט אַ יטעראַטאָר וואָס גיט די קליין קאַרטל מאַפּינג פון דעם `char` ווי איינער אָדער מער
    /// `char`s.
    ///
    /// אויב דעם `char` האט נישט אַ קליין מאַפּינג, די יטעראַטאָר גיט די זעלבע `char`.
    ///
    /// אויב דעם `char` האט אַן איינער-צו-איינער קליין קאַרטל מאַפּינג געגעבן דורך די [Unicode Character Database][ucd] קס 01 קס, די יטעראַטאָר ייעלדס אַז `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// אויב דעם קס 01 קס ריקווייערז ספּעציעל קאָנסידעראַטיאָנס (למשל קייפל `טשאַר`ס), די יטעראַטאָר ייעלדס די`טשאַר`ע (s) געגעבן דורך קס 00 קס.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// די אָפּעראַציע דורכפירן אַ ומבאַדינגט מאַפּינג אָן טיילערינג.דאָס הייסט, די קאַנווערזשאַן איז פרייַ פון קאָנטעקסט און שפּראַך.
    ///
    /// אין די [Unicode Standard], טשאַפּטער 4 (Character Properties) באהאנדלט קאַסעס מאַפּינג אין אַלגעמיין און טשאַפּטער 3 (Conformance) דיסקוסיעס די פעליקייַט אַלגערידאַם פֿאַר פאַל קאַנווערזשאַן.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // מאל דער רעזולטאַט איז מער ווי איין כאַראַקטער:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // אותיות וואָס טאָן ניט האָבן גרויס און קליין אותיות קאַנווערזשאַן אין זיך.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// רעטורנס אַ יטעראַטאָר וואָס ברענגט די גרויס אותיות פון דעם `char` ווי איינער אָדער מער
    /// `char`s.
    ///
    /// אויב די `char` האט נישט קיין גרויסע אותיות, די יטעראַטאָר גיט די זעלבע `char`.
    ///
    /// אויב דעם `char` האט אַן איינער-צו-איינער גרויסע מאַפּינג געגעבן דורך די [Unicode Character Database][ucd] קס 01 קס, די יטעראַטאָר ברענגט דעם `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// אויב דעם קס 01 קס ריקווייערז ספּעציעל קאָנסידעראַטיאָנס (למשל קייפל `טשאַר`ס), די יטעראַטאָר ייעלדס די`טשאַר`ע (s) געגעבן דורך קס 00 קס.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// די אָפּעראַציע דורכפירן אַ ומבאַדינגט מאַפּינג אָן טיילערינג.דאָס הייסט, די קאַנווערזשאַן איז פרייַ פון קאָנטעקסט און שפּראַך.
    ///
    /// אין די [Unicode Standard], טשאַפּטער 4 (Character Properties) באהאנדלט קאַסעס מאַפּינג אין אַלגעמיין און טשאַפּטער 3 (Conformance) דיסקוסיעס די פעליקייַט אַלגערידאַם פֿאַר פאַל קאַנווערזשאַן.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ווי אַ יטעראַטאָר:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ניצן `println!` גלייַך:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ביידע זענען עקוויוואַלענט צו:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// ניצן `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // מאל דער רעזולטאַט איז מער ווי איין כאַראַקטער:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // אותיות וואָס טאָן ניט האָבן גרויס און קליין אותיות קאַנווערזשאַן אין זיך.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # באַמערקונג אויף היגע
    ///
    /// אין טערקיש, די עקוויוואַלענט פון 'i' אין לאַטייַן האט פינף פארמען אַנשטאָט פון צוויי:
    ///
    /// * 'Dotless': איך/איך, יז געשריבן איך
    /// * 'Dotted': איך/איך
    ///
    /// באַמערקונג אַז 'i' מיט קליין דאַץ X איז די זעלבע ווי די לאַטייַן.דעריבער:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// די ווערט פון קס 04 קס דאָ רילייז אויף די שפּראַך פון די טעקסט: אויב מיר זענען אין קס 01 קס, עס זאָל זיין קס 02 קס, אָבער אויב מיר זענען אין קס 03 קס, עס זאָל זיין קס 00 קס.
    /// `to_uppercase()` טוט ניט נעמען דאָס אין חשבון, און אַזוי:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// האלט אַריבער שפּראַכן.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// טשעקס אויב די ווערט איז אין די ASCII קייט.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// מאכט אַ קאָפּיע פון די ווערט אין זיין ASCII אויבערשטער פאַל עקוויוואַלענט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`make_ascii_uppercase()`] צו ויסקערן די ווערט אין פּלאַץ.
    ///
    /// צו נוצן גרויס אותיות ASCII אותיות אין אַדישאַן צו ניט ASCII אותיות, נוצן [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// מאכט אַ קאָפּיע פון די ווערט אין אַן ASCII עקוויוואַלענט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`make_ascii_lowercase()`] צו קלענערער די ווערט אין פּלאַץ.
    ///
    /// צו נוצן AS00II אותיות אין אַדישאַן צו ניט-ASCII אותיות, נוצן [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// טשעקס אַז צוויי וואַלועס זענען אַן ASCII פאַל-ינסענסיטיוו גלייַכן.
    ///
    /// עקוויוואַלענט צו קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// קאָנווערץ דעם טיפּ צו זיין ASCII אויבערשטער פאַל עקוויוואַלענט אין-אָרט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`to_ascii_uppercase()`] צו צוריקקריגן אַ נייַע אויבערשטער ווערט אָן מאַדאַפייינג די יגזיסטינג.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// קאָנווערץ דעם טיפּ צו זיין ASCII עקוויוואַלענט אין-אָרט עקוויוואַלענט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`to_ascii_lowercase()`] צו צוריקקריגן אַ נייַע ווערט מיט נידעריק נידעריקער קאַסעס אָן מאַדאַפאַקיישאַן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// טשעקס אויב די ווערט איז אַן ASCII אַלפאַבעטיק כאַראַקטער:
    ///
    /// - U + 0041 קס 01 קס ..=ו + 005 אַ קס 00 קס, אָדער
    /// - U + 0061 קס 01 קס ..=ו + 007 אַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// טשעקס אויב די ווערט איז אַ ASCII גרויסע אותיות:
    /// U + 0041 קס 01 קס ..=ו + 005 אַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// טשעקס אויב די ווערט איז אַן ASCII קליין אותיות:
    /// U + 0061 קס 01 קס ..=ו + 007 אַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// טשעקס אויב די ווערט איז אַן ASCII אַלפאַנומעריק כאַראַקטער:
    ///
    /// - U + 0041 קס 01 קס ..=ו + 005 אַ קס 00 קס, אָדער
    /// - U + 0061 קס 01 קס ..=ו + 007 אַ קס 00 קס, אָדער
    /// - U + 0030 קס 01 קס ..=ו + 0039 קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// טשעקס אויב די ווערט איז אַן ASCII דעצימאַל ציפֿער:
    /// U + 0030 קס 01 קס ..=ו + 0039 קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// טשעקס אויב די ווערט איז אַן ASCII העקסאַדעסימאַל ציפֿער:
    ///
    /// - U + 0030 קס 01 קס ..=ו + 0039 קס 00 קס, אָדער
    /// - U + 0041 קס 01 קס ..=ו + 0046 קס 00 קס, אָדער
    /// - U + 0061 קס 01 קס ..=ו + 0066 קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// טשעקס אויב די ווערט איז אַ ASCII פּונקטואַציע כאַראַקטער:
    ///
    /// - U + 0021 ..=U + 002 ף קס 00 קס, אָדער
    /// - U + 003A ..=U + 0040 קס 00 קס, אָדער
    /// - U + 005B ..=U + 0060 `[\] ^ _` קס 00 קס, אָדער
    /// - U + 007B ..=U + 007E קס 00 קס
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// טשעקס אויב די ווערט איז אַ ASCII גראַפיק כאַראַקטער:
    /// U + 0021 קס 01 קס ..=ו + 007 ע קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// טשעקס אויב די ווערט איז אַ ASCII ווייטספּייס כאַראַקטער:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, אָדער U + 000D קאַריערע צוריק.
    ///
    /// Rust ניצט די ווהאַטווג ינפראַ סטאַנדאַרד ס קס 00 קס.עס זענען עטלעכע אנדערע זוך אין ברייט נוצן.
    /// פֿאַר בייַשפּיל, [the POSIX locale][pct] כולל U + 000B ווערטיקאַל קוויטל ווי געזונט ווי אַלע די אויבן אותיות, אָבער-פֿון דער זעלביקער זעלביקער באַשרייַבונג-[די פעליקייַט הערשן פֿאַר "field splitting" אין די Bourne shell][bfs] האלט *בלויז* SPACE, HORIZONTAL TAB, און שורה קאָרמען ווי ווהיטעספּאַסע.
    ///
    ///
    /// אויב איר שרייבט אַ פּראָגראַם וואָס וועט פּראַסעסט אַן יגזיסטינג טעקע פֿאָרמאַט, קאָנטראָלירן וואָס די פֿאָרמאַט איז די דעפֿיניציע פון ווהיטעספּאַסע איידער איר נוצן דעם פֿונקציע.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// טשעקס אויב די ווערט איז אַן ASCII קאָנטראָל כאַראַקטער:
    /// ו + 0000 נול ..=ו + 001 ף אַפּאַראַט סעפּאַראַטאָר, אָדער ו + 007 ף ויסמעקן.
    /// באַמערקונג אַז רובֿ ASCII ווהיטעספּאַסע אותיות זענען קאָנטראָל אותיות, אָבער SPACE איז נישט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ענקאָודז אַ רוי u32 ווערט ווי UTF-8 אין די צוגעשטעלט ביטע באַפער, און דאַן קערט די סובסליסע פון די באַפער וואָס כּולל די קאָדעד כאַראַקטער.
///
///
/// ניט ענלעך `char::encode_utf8`, דעם אופֿן אויך כאַנדאַלז קאָדעקס אין די סעראַגאַט קייט.
/// (קרעאַטינג אַ קס 01 קס אין די סעראַגאַט קייט איז וב.) דער רעזולטאַט איז גילטיק קס 02 קס אָבער ניט גילטיק קס 00 קס.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics אויב די באַפער איז נישט גרויס גענוג.
/// א באַפער פון לענג פיר איז גרויס גענוג צו ענקאָוד קיין `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// ענקאָודז אַ רוי u32 ווערט ווי UTF-16 אין די צוגעשטעלט `u16` באַפער, און דאַן קערט די סובסליסע פון די באַפער וואָס כּולל די קאָדעד כאַראַקטער.
///
///
/// ניט ענלעך `char::encode_utf16`, דעם אופֿן אויך כאַנדאַלז קאָדעקס אין די סעראַגאַט קייט.
/// (שאַפֿן אַ `char` אין די סעראַגאַט קייט איז UB.)
///
/// # Panics
///
/// Panics אויב די באַפער איז נישט גרויס גענוג.
/// א באַפער פון לענג 2 איז גרויס גענוג צו ענקאָוד קיין `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // זיכערקייט: יעדער אָרעם קאָנטראָלירן צי עס זענען גענוג ביטן צו שרייַבן אין
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // די BMP פאלן דורך
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // סאַפּלאַמענטערי פּליינז ברעכן אין סעראַגאַץ.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}