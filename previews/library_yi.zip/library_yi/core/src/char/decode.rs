//! UTF-8 און קס 00 קס דיקאָודינג יטעראַטאָרס

use crate::fmt;

use super::from_u32_unchecked;

/// א איטעראטאר וואס דעקאָדירט UTF-16 קאָדירטע קאָד פונקטן פון א איטעראַטאָר פון `u16`s.
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Clone, Debug)]
pub struct DecodeUtf16<I>
where
    I: Iterator<Item = u16>,
{
    iter: I,
    buf: Option<u16>,
}

/// א טעות וואָס קענען זיין אומגעקערט ווען דיקאָודינג פון UTF-16 קאָד ווייזט.
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct DecodeUtf16Error {
    code: u16,
}

/// קרעאַטעס אַ יטעראַטאָר איבער די קס 01 קס קאָדעד קאָד ווייזט אין קס 00 קס, אומגעקערט אַנפּערד סעראַגאַץ ווי `ערר`ס.
///
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::char::decode_utf16;
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
///         .collect::<Vec<_>>(),
///     vec![
///         Ok('𝄞'),
///         Ok('m'), Ok('u'), Ok('s'),
///         Err(0xDD1E),
///         Ok('i'), Ok('c'),
///         Err(0xD834)
///     ]
/// );
/// ```
///
/// א לאָססי דיקאָודער קענען זיין באקומען דורך ריפּלייסט די `Err` רעזולטאַטן מיט די פאַרבייַט כאַראַקטער:
///
/// ```
/// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
///        .collect::<String>(),
///     "𝄞mus�ic�"
/// );
/// ```
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[inline]
pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
    DecodeUtf16 { iter: iter.into_iter(), buf: None }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl<I: Iterator<Item = u16>> Iterator for DecodeUtf16<I> {
    type Item = Result<char, DecodeUtf16Error>;

    fn next(&mut self) -> Option<Result<char, DecodeUtf16Error>> {
        let u = match self.buf.take() {
            Some(buf) => buf,
            None => self.iter.next()?,
        };

        if u < 0xD800 || 0xDFFF < u {
            // זיכערקייט: נישט אַ סעראַגאַט
            Some(Ok(unsafe { from_u32_unchecked(u as u32) }))
        } else if u >= 0xDC00 {
            // אַ טריילינג סעראַגאַט
            Some(Err(DecodeUtf16Error { code: u }))
        } else {
            let u2 = match self.iter.next() {
                Some(u2) => u2,
                // eof
                None => return Some(Err(DecodeUtf16Error { code: u })),
            };
            if u2 < 0xDC00 || u2 > 0xDFFF {
                // נישט אַן טריילינג סעראַגאַט, אַזוי מיר זענען נישט אַ גילטיק סעראַגאַט פּאָר, אַזוי ריוויינד צו רידיקאָוד קס 00 קס ווייַטער צייַט.
                //
                self.buf = Some(u2);
                return Some(Err(DecodeUtf16Error { code: u }));
            }

            // אַלע גוט, אַזוי לעץ דיקאָוד עס.
            let c = (((u - 0xD800) as u32) << 10 | (u2 - 0xDC00) as u32) + 0x1_0000;
            // זיכערקייט: מיר האָבן אָפּגעשטעלט אַז דאָס איז אַ לעגאַל אוניקאָד ווערט
            Some(Ok(unsafe { from_u32_unchecked(c) }))
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (low, high) = self.iter.size_hint();
        // מיר קען זיין גאָר גילטיק סורראָגאַטעס (2 עלעמענטן פּער טשאַר), אָדער גאָר ניט-סורראָגאַטעס (1 עלעמענט פּער טשאַר)
        //
        (low / 2, high)
    }
}

impl DecodeUtf16Error {
    /// קערט דער אַנפּייערד סעראַגאַט וואָס געפֿירט דעם טעות.
    #[stable(feature = "decode_utf16", since = "1.9.0")]
    pub fn unpaired_surrogate(&self) -> u16 {
        self.code
    }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl fmt::Display for DecodeUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "unpaired surrogate found: {:x}", self.code)
    }
}