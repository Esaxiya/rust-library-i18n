use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// א ראַפּער טיפּ צו בויען אַנינישיייטיד ינסטאַנסיז פון קס 00 קס.
///
/// # יניטיאַליזאַטיאָן טאָמיד
///
/// דער קאַמפּיילער, אין אַלגעמיין, אַסומז אַז אַ בייַטעוודיק איז רעכט יניטיאַלייזד לויט די באדערפענישן פון די טיפּ פון די בייַטעוודיק.פֿאַר בייַשפּיל, אַ בייַטעוודיק פון דער דערמאָנען טיפּ מוזן זיין אַליינד און ניט-NULL.
/// דאָס איז אַן ינוועריאַנט וואָס דאַרף *שטענדיק* זיין אַפּכעלד, אפילו אין אַנסייף קאָד.
/// דעריבער, נול-יניטיאַליזינג אַ בייַטעוודיק פון דער רעפֿערענץ טיפּ ז ינסטאַנטאַניאַס קס 00 קס, קיין ענין צי די רעפֿערענץ טאָמיד געוויינט צו אַקסעס זכּרון:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // אַנדיפיינד נאַטור!⚠️
/// // די עקוויוואַלענט קאָד מיט `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // אַנדיפיינד נאַטור!⚠️
/// ```
///
/// דער קאַמפּיילער איז עקספּלויטאַד פֿאַר פאַרשידן אָפּטימיזאַטיאָנס, אַזאַ ווי עלידינג לויפן-צייט טשעקס און אָפּטימיזינג `enum` אויסלייג.
///
/// סימילאַרלי, לעגאַמרע אַנינישיייטיד זכּרון קען האָבן קיין אינהאַלט, בשעת אַ `bool` מוזן שטענדיק זיין `true` אָדער `false`.דעריבער, קריייטינג אַן אַנינישיייטיד קס 03 קס איז אַנדיפיינד נאַטור:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // אַנדיפיינד נאַטור!⚠️
/// // די עקוויוואַלענט קאָד מיט `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // אַנדיפיינד נאַטור!⚠️
/// ```
///
/// דערצו, וניניטיאַליזעד זכּרון איז ספּעציעל ווייַל עס האט נישט אַ פאַרפעסטיקט ווערט ("fixed" טייַטש קס 01 קס).רידינג פון דער זעלביקער אַניניטיאַליזעד בייט קייפל מאָל קענען געבן פאַרשידענע רעזולטאַטן.
/// דאָס מאכט עס אַנדיפיניד נאַטור צו האָבן אַנינישיייטיד דאַטן אין אַ בייַטעוודיק אפילו אויב די בייַטעוודיק האט אַ ינטאַדזשער טיפּ, וואָס אַנדערש קענען האַלטן קיין *פאַרפעסטיקט* ביסל מוסטער:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // אַנדיפיינד נאַטור!⚠️
/// // די עקוויוואַלענט קאָד מיט `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // אַנדיפיינד נאַטור!⚠️
/// ```
/// (נאָטיץ אַז די כּללים אַרום אַניניטיאַליזעד ינטאַדזשערז זענען נישט פיינאַלייזד נאָך, אָבער ביז זיי זענען, עס איז קעדייַיק צו ויסמיידן זיי.)
///
/// אין אַדישאַן, געדענקען אַז רובֿ טייפּס האָבן נאָך ינוואַריאַנץ נאָך בלויז גערעכנט ווי ינישאַלייזד אויף די טיפּ מדרגה.
/// פֿאַר בייַשפּיל, אַ '1'-ינישיייטיד קס 00 קס איז גערעכנט יניטיאַליזעד (אונטער די קראַנט ימפּלאַמענטיישאַן; דאָס איז נישט אַ סטאַביל גאַראַנטירן) ווייַל דער קאַמפּיילער ווייסט דער בלויז פאָדערונג איז אַז די דאַטן טייַטל מוזן זיין ניט-נאַל.
/// אויב איר מאַכן אַזאַ `Vec<T>`, דאָס קען נישט מאַכן *באַלדיק* ונדעפינעד נאַטור, אָבער עס וועט פאַרשאַפן אַנדיפיינד נאַטור מיט רובֿ זיכער אַפּעריישאַנז (אַרייַנגערעכנט דראַפּינג עס).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` באדינט צו געבן אַנסייף קאָד צו האַנדלען מיט אַנינישיייטיד דאַטן.
/// עס איז אַ סיגנאַל צו די קאַמפּיילער וואָס ינדיקייץ אַז די דאַטן דאָ קען * נישט זיין ינישאַלייזד:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // שאַפֿן אַן עקספּרעסלי אַנינישיייטיד רעפֿערענץ.
/// // דער קאַמפּיילער ווייסט אַז דאַטן אין אַ `MaybeUninit<T>` קען זיין פאַרקריפּלט, און דאָס איז נישט UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // באַשטעטיק עס צו אַ גילטיק ווערט.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // עקסטראַקט די יניטיאַליזעד דאַטן-דאָס איז בלויז ערלויבט *נאָך* רעכט יניגאַליזינג קס 00 קס!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// דער קאַמפּיילער קען נישט מאַכן קיין פאַלש אַסאַמפּשאַנז אָדער אָפּטימיזאַטיאָנס אויף דעם קאָד.
///
/// איר קענען טראַכטן פון `MaybeUninit<T>` ווי אַ ביסל ווי `Option<T>`, אָבער אָן קיין פון די לויפן-צייט טראַקינג און אָן קיין זיכערקייַט טשעקס.
///
/// ## out-pointers
///
/// איר קענען נוצן קס 01 קס צו ינסטרומענט קס 00 קס: אַנשטאָט פון אומגעקערט דאַטן פֿון אַ פונקציע, פאָרן עס אַ טייַטל צו עטלעכע קס 02 קס זכּרון צו שטעלן די רעזולטאַט.
/// דאָס קען זיין נוציק ווען עס איז וויכטיק פֿאַר די קאָלער צו קאָנטראָלירן ווי דער זכּרון דער רעזולטאַט איז סטאָרד אין אַלאַקייטיד, און איר ווילן צו ויסמיידן ומנייטיק מאָוועס.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` קען נישט פאַלן די אַלט אינהאַלט, וואָס איז וויכטיק.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // איצט מיר וויסן `v` איז ינישיייטיד!דאָס אויך מאכט זיכער אַז די vector איז רעכט דראַפּט.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## יניטיאַליזינג אַ מענגע עלעמענט-דורך-עלעמענט
///
/// `MaybeUninit<T>` קענען ווערן גענוצט צו יניטיאַליזירן אַ גרויס מענגע עלעמענט-דורך-עלעמענט:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // שאַפֿן אַן אַנינישיייטיד מענגע פון `MaybeUninit`.
///     // די `assume_init` איז זיכער ווייַל דער טיפּ וואָס מיר פאָדערן צו האָבן ינישיייטיד דאָ איז אַ בינטל פון `אפֿשר Uninit`s וואָס טאָן ניט דאַרפן יניטיאַליזאַטיאָן.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // דראַפּינג אַ קס 00 קס טוט גאָרנישט.
///     // אויב איר נוצן רוי טייַטל אַסיינמאַנט אַנשטאָט פון `ptr::write`, די אַלט אַניניטיאַליזעד ווערט קען נישט פאַלן.
/////
///     // אויב עס איז אַ panic בעשאַס דעם שלייף, מיר האָבן אַ זכּרון רינען, אָבער עס איז קיין פּראָבלעם פֿאַר זכּרון זיכערקייַט.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // אַלץ איז ינישיייטיד.
///     // יבערמאַכן די מענגע צו די ינישיייטיד טיפּ.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// איר קענט אויך אַרבעטן מיט טייל ינישיייטיד ערייז וואָס קען זיין געפֿונען אין דאַטסטראַקטורעס פון נידעריק מדרגה.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // שאַפֿן אַן אַנינישיייטיד מענגע פון `MaybeUninit`.
/// // די `assume_init` איז זיכער ווייַל דער טיפּ וואָס מיר פאָדערן צו האָבן ינישיייטיד דאָ איז אַ בינטל פון `אפֿשר Uninit`s וואָס טאָן ניט דאַרפן יניטיאַליזאַטיאָן.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ציילן די נומער פון עלעמענטן וואָס מיר האָבן באַשטימט.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // פאַלן פֿאַר יעדער נומער אין די מענגע אויב מיר אַלאַקייטיד עס.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## יניטיאַליזינג אַ סטרוקטור פעלד-דורך-פעלד
///
/// איר קענט נוצן `MaybeUninit<T>` און די [`std::ptr::addr_of_mut`] מאַקראָו צו יניטיאַליזירן סטראַקץ פעלד דורך פעלד:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // יניטיאַליזינג די קס 00 קס פעלד
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // ערשטיק די `list` פעלד אויב עס איז אַ panic, די `String` אין די `name` פעלד ליקס.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // כל פעלדער זענען ינישיייטיד, אַזוי מיר רופן `assume_init` צו באַקומען אַן ערשט Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` איז געראַנטיד צו האָבן די זעלבע גרייס, אַליינמאַנט און אַבי ווי קס 00 קס:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// אָבער געדענקען אַז אַ טיפּ *מיט* אַ קס 00 קס איז ניט דאַווקע דער זעלביקער אויסלייג;Rust קען בכלל נישט גאַראַנטירן אַז די `Foo<T>` פעלדער האָבן די זעלבע סדר ווי אַ `Foo<U>`, אפילו אויב `T` און `U` האָבן די זעלבע גרייס און אַליינמאַנט.
///
/// דערצו ווייַל קיין ווערט איז גילטיק פֿאַר אַ `MaybeUninit<T>`, דער קאַמפּיילער קען נישט צולייגן non-zero/niche-filling אָפּטימיזאַטיאָנס, וואָס ריזאַלטיד אין אַ גרעסערע גרייס:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// אויב `T` איז FFI-זיכער, דאָס איז `MaybeUninit<T>`.
///
/// בשעת `MaybeUninit` איז `#[repr(transparent)]` (ינדאַקייטינג עס געראַנטיז די זעלבע גרייס, אַליינמאַנט, און ABI ווי `T`), דאָס טוט נישט טוישן קיין פון די פריערדיקע קייוויאַץ.
/// `Option<T>` און קס 01 קס קען האָבן פאַרשידענע סיזעס, און טייפּס מיט אַ פעלד פון טיפּ 02 קס קענען זיין געלייגט (און סייזד) דיפערענטלי ווי אויב דאָס פעלד איז געווען קס 00 קס.
/// `MaybeUninit` איז אַ פאַרבאַנד טיפּ, און קס 01 קס אויף יוניאַנז איז אַנסטייבאַל (זען קס 00 קס.
/// מיט די צייט, די פּינטלעך געראַנטיז פון קס 01 קס אויף יוניאַנז קען יוואַלוו, און קס 02 קס קען אָדער קען ניט בלייַבן קס 00 קס.
/// ווי געזאָגט, `MaybeUninit<T>` וועט *שטענדיק* גאַראַנטירן אַז עס האט די זעלבע גרייס, אַליינמאַנט און ABI ווי `T`;נאָר די וועג קס 02 קס ימפּלאַמאַנץ אַז גאַראַנטירן קען יוואַלוו.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// אַזוי מיר קענען ייַנוויקלען אנדערע טייפּס אין עס.דאָס איז נוציק פֿאַר גענעראַטאָרס.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // נישט רופן `T::clone()`, מיר קענען נישט וויסן אויב מיר זענען גענוג ינישיייטיד פֿאַר דעם.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// קרעאַטעס אַ נייַ קס 00 קס יניטיאַלייזד מיט די געגעבן ווערט.
    /// עס איז זיכער צו רופן [`assume_init`] אויף דעם צוריקקער ווערט פון דעם פֿונקציע.
    ///
    /// באַמערקונג אַז דראַפּינג אַ `MaybeUninit<T>` וועט קיינמאָל רופן דעם פאַל 'T' ס קאַפּ קאָד.
    /// עס איז דיין פֿאַראַנטוואָרטלעכקייט צו מאַכן זיכער אַז `T` דראַפּט אויב עס ינישאַלייזד.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// קרעאַטעס אַ נייַע קס 00 קס אין אַ אַנינישיייטיד שטאַט.
    ///
    /// באַמערקונג אַז דראַפּינג אַ `MaybeUninit<T>` וועט קיינמאָל רופן דעם פאַל 'T' ס קאַפּ קאָד.
    /// עס איז דיין פֿאַראַנטוואָרטלעכקייט צו מאַכן זיכער אַז `T` דראַפּט אויב עס ינישאַלייזד.
    ///
    /// זען די [type-level documentation][MaybeUninit] פֿאַר עטלעכע ביישפילן.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// שאַפֿן אַ נייַע נומער פון `MaybeUninit<T>` ייטאַמז אין אַן אַנינישיייטיד שטאַט.
    ///
    /// Note: אין אַ future Rust ווערסיע, דעם אופֿן קען ווערן ומנייטיק ווען עריינדזשד ליטעראַל סינטאַקס אַלאַוז [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// די ביישפּיל אונטן קען נוצן `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// רעטורנס אַ (עפשער קלענערער) רעפטל פון דאַטן וואָס איז טאַקע לייענען
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // זיכערהייט: אַן אַני-יניטיאַלייזד קס 00 קס איז גילטיק.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// קרעאַטעס אַ נייַ קס 00 קס אין אַ אַנינישיייטיד שטאַט, מיט די זכּרון אָנגעפילט מיט קס 01 קס ביטעס.עס דעפּענדס אויף קס 02 קס צי דאָס איז שוין רעכט צו יניטיאַליזאַטיאָן.
    ///
    /// פֿאַר בייַשפּיל, `MaybeUninit<usize>::zeroed()` איז ינישיייטיד, אָבער `MaybeUninit<&'static i32>::zeroed()` איז נישט ווייַל באַווייַזן מוזן נישט זיין נאַל.
    ///
    /// באַמערקונג אַז דראַפּינג אַ `MaybeUninit<T>` וועט קיינמאָל רופן דעם פאַל 'T' ס קאַפּ קאָד.
    /// עס איז דיין פֿאַראַנטוואָרטלעכקייט צו מאַכן זיכער אַז `T` דראַפּט אויב עס ינישאַלייזד.
    ///
    /// # Example
    ///
    /// ריכטיק באַניץ פון דעם פֿונקציע: יניטיאַליזינג אַ סטרוקטור מיט נול, וווּ אַלע פעלדער פון סטרוקטור קענען האַלטן די ביסל מוסטער 0 ווי אַ גילטיק ווערט.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *פאַלש* באַניץ פון דעם פֿונקציע: רופן `x.zeroed().assume_init()` ווען `0` איז נישט אַ גילטיק ביסל מוסטער פֿאַר דעם טיפּ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // אין אַ פּאָר מיר מאַכן אַ קס 00 קס וואָס טוט נישט האָבן אַ גילטיק דיסקרימינאַנט.
    /// // דאָס איז אַנדיפיינד נאַטור.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // זיכערקייט: קס 00 קס ווייזט צו אַלאַקייטיד זכּרון.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// שטעלט די ווערט פון די `MaybeUninit<T>`.
    /// דאָס אָווועררייץ קיין פריערדיקע ווערט אָן דראַפּינג עס, אַזוי זיין אָפּגעהיט ניט צו נוצן דעם צוויי מאָל סייַדן איר ווילן צו האָפּקען די דעסטרוקטאָר.
    ///
    /// פֿאַר דיין קאַנוויניאַנס, דאָס קערט אויך אַ מיוטאַבאַל דערמאָנען צו די (איצט בעשאָלעם יניטיאַליזעד) אינהאַלט פון קס 00 קס.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // זיכערקייט: מיר האָבן דעם ערשט ינישאַלייזד.
        unsafe { self.assume_init_mut() }
    }

    /// געץ אַ טייַטל צו די קאַנטיינד ווערט.
    /// לייענען פון דעם טייַטל אָדער ווענדן עס צו אַ רעפֿערענץ איז אַנדיפיינד, סייַדן די `MaybeUninit<T>` איז ינישיייטיד.
    /// שרייבן צו זכּרון אַז דער טייַטל קס 00 קס ווייזט צו איז אַנדיפיינד די נאַטור (אַחוץ אין די `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// ריכטיק באַניץ פון דעם אופֿן:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // שאַפֿן אַ רעפֿערענץ אין די `MaybeUninit<T>`.דאָס איז אָוקיי ווייַל מיר ינישאַלייזד עס.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// פאַלש באַניץ פון דעם אופֿן:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // מיר האָבן באשאפן אַ רעפֿערענץ צו אַ אַנינישיייטיד ז 0 וועקטאָר 0 ז!דאָס איז אַנדיפיינד נאַטור.⚠️
    /// ```
    ///
    /// (נאָטיץ אַז די כּללים אַרום באַווייַזן צו אַנינישיייטיד דאַטן זענען נישט פיינאַלייזד נאָך, אָבער ביז זיי זענען, עס איז קעדייַיק צו ויסמיידן זיי.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` און קס 00 קס זענען ביידע קס 01 קס אַזוי מיר קענען וואַרפן די טייַטל.
        self as *const _ as *const T
    }

    /// געץ אַ מיוטאַבאַל טייַטל צו די קאַנטיינד ווערט.
    /// לייענען פון דעם טייַטל אָדער ווענדן עס צו אַ רעפֿערענץ איז אַנדיפיינד, סייַדן די `MaybeUninit<T>` איז ינישיייטיד.
    ///
    /// # Examples
    ///
    /// ריכטיק באַניץ פון דעם אופֿן:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // שאַפֿן אַ רעפֿערענץ אין די `MaybeUninit<Vec<u32>>`.
    /// // דאָס איז אָוקיי ווייַל מיר ינישאַלייזד עס.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// פאַלש באַניץ פון דעם אופֿן:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // מיר האָבן באשאפן אַ רעפֿערענץ צו אַ אַנינישיייטיד ז 0 וועקטאָר 0 ז!דאָס איז אַנדיפיינד נאַטור.⚠️
    /// ```
    ///
    /// (נאָטיץ אַז די כּללים אַרום באַווייַזן צו אַנינישיייטיד דאַטן זענען נישט פיינאַלייזד נאָך, אָבער ביז זיי זענען, עס איז קעדייַיק צו ויסמיידן זיי.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` און קס 00 קס זענען ביידע קס 01 קס אַזוי מיר קענען וואַרפן די טייַטל.
        self as *mut _ as *mut T
    }

    /// יקסטראַקץ די ווערט פון די `MaybeUninit<T>` קאַנטיינער.דאָס איז אַ גרויס וועג צו ענשור אַז די דאַטן וועט פאַלן, ווייַל די ריזאַלטינג קס 01 קס איז אונטערטעניק צו די געוויינטלעך קאַפּ האַנדלינג.
    ///
    /// # Safety
    ///
    /// עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די `MaybeUninit<T>` טאַקע איז אין אַן ינישאַלייזד שטאַט.רופן דעם ווען די אינהאַלט איז נישט נאָך ינישיייטיד ז גלייך אַנדיפיינד נאַטור.
    /// די [type-level documentation][inv] כּולל מער אינפֿאָרמאַציע וועגן דעם ינעראַליזיישאַן ינוועריאַנט.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// אין אַדישאַן, געדענקען אַז רובֿ טייפּס האָבן נאָך ינוואַריאַנץ נאָך בלויז גערעכנט ווי ינישאַלייזד אויף די טיפּ מדרגה.
    /// פֿאַר בייַשפּיל, אַ '1'-ינישיייטיד קס 00 קס איז גערעכנט יניטיאַליזעד (אונטער די קראַנט ימפּלאַמענטיישאַן; דאָס איז נישט אַ סטאַביל גאַראַנטירן) ווייַל דער קאַמפּיילער ווייסט דער בלויז פאָדערונג איז אַז די דאַטן טייַטל מוזן זיין ניט-נאַל.
    ///
    /// אויב איר מאַכן אַזאַ `Vec<T>`, דאָס קען נישט מאַכן *באַלדיק* ונדעפינעד נאַטור, אָבער עס וועט פאַרשאַפן אַנדיפיינד נאַטור מיט רובֿ זיכער אַפּעריישאַנז (אַרייַנגערעכנט דראַפּינג עס).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ריכטיק באַניץ פון דעם אופֿן:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// פאַלש באַניץ פון דעם אופֿן:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` נאָך נישט געווען ינישיייטיד, אַזוי די לעצטע שורה געפֿירט אַנדיפיינד נאַטור.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `self` איז ינישיייטיד.
        // דאָס אויך מיטל אַז `self` מוזן זיין אַ `value` וואַריאַנט.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// לייענען די ווערט פון די `MaybeUninit<T>` קאַנטיינער.די ריזאַלטינג קס 01 קס איז אונטערטעניק צו די געוויינטלעך קאַפּ האַנדלינג.
    ///
    /// אויב מעגלעך, עס איז בילכער צו נוצן [`assume_init`] אַנשטאָט, וואָס פּריווענץ דיופּלאַקייטינג די אינהאַלט פון די `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די `MaybeUninit<T>` טאַקע איז אין אַן ינישאַלייזד שטאַט.אויב איר רופן דעם אינהאַלט ווען די אינהאַלט איז נישט גאָר יניטיאַליזעד, איז אַנדיפיינד די נאַטור.
    /// די [type-level documentation][inv] כּולל מער אינפֿאָרמאַציע וועגן דעם ינעראַליזיישאַן ינוועריאַנט.
    ///
    /// דערצו, די בלעטער אַ קאָפּיע פון די זעלבע דאַטן אין די `MaybeUninit<T>`.
    /// אויב איר נוצן קייפל עקזעמפלארן פון די דאַטן (דורך `assume_init_read` פאַך קייפל מאָל, אָדער ערשטער `assume_init_read` און [`assume_init`]), דאָס איז דיין פֿאַראַנטוואָרטלעכקייט צו ענשור אַז די דאַטן קענען טאַקע זיין דופּליקייטיד.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ריכטיק באַניץ פון דעם אופֿן:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` איז `Copy`, אַזוי מיר קען לייענען עטלעכע מאָל.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // דופּליקאַט אַ `None` ווערט איז אָוקיי, אַזוי מיר קען לייענען עטלעכע מאָל.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// פאַלש באַניץ פון דעם אופֿן:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // מיר איצט באשאפן צוויי קאפיעס פון די זעלבע vector, וואָס וועט פירן צו אַ טאָפּל-פריי ⚠️ ווען זיי ביידע פאַלן!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `self` איז ינישיייטיד.
        // לייענען פון `self.as_ptr()` איז זיכער זינט `self` זאָל זיין ינישיייטיד.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// דראָפּס די קאַנטיינד ווערט אין פּלאַץ.
    ///
    /// אויב איר האָט אָונערשיפּ פון די `MaybeUninit`, איר קענען נוצן [`assume_init`] אַנשטאָט.
    ///
    /// # Safety
    ///
    /// עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די `MaybeUninit<T>` טאַקע איז אין אַן ינישאַלייזד שטאַט.אויב איר רופן דעם אינהאַלט ווען די אינהאַלט איז נישט גאָר יניטיאַליזעד, איז אַנדיפיינד די נאַטור.
    ///
    /// אין אַדישאַן, אַלע נאָך ינוועריאַנץ פון די טיפּ `T` מוזן זיין צופֿרידן, ווייַל די `Drop` ימפּלאַמענטיישאַן פון `T` (אָדער זיין מיטגלידער) קען פאַרלאָזנ אויף דעם.
    /// פֿאַר בייַשפּיל, אַ '1'-ינישיייטיד קס 00 קס איז גערעכנט יניטיאַליזעד (אונטער די קראַנט ימפּלאַמענטיישאַן; דאָס איז נישט אַ סטאַביל גאַראַנטירן) ווייַל דער קאַמפּיילער ווייסט דער בלויז פאָדערונג איז אַז די דאַטן טייַטל מוזן זיין ניט-נאַל.
    ///
    /// דראַפּינג אַזאַ אַ `Vec<T>` אָבער וועט פאַרשאַפן ונדעפינעד נאַטור.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `self` איז ינישיייטיד און
        // סאַטיספייז אַלע ינוואַריאַנץ פון קס 00 קס.
        // דראַפּינג די ווערט אין פּלאַץ איז זיכער אויב דאָס איז דער פאַל.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// געץ אַ שערד דערמאָנען צו די קאַנטיינד ווערט.
    ///
    /// דאָס קען זיין נוציק ווען מיר וועלן אַקסעס צו אַן `MaybeUninit` וואָס איז ינישיייטיד, אָבער מיר האָבן נישט אָונערשיפּ פון די `MaybeUninit` (פּרעווענטינג די נוצן פון `.assume_init()`).
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אינהאַלט ווען די אינהאַלט איז נישט נאָך ינישיייטיד, דאָס איז אַנדיפיינד די נאַטור: עס איז אַרויף צו די רופן צו גאַראַנטירן אַז די `MaybeUninit<T>` טאַקע איז אין אַן ינישאַלייזד שטאַט.
    ///
    ///
    /// # Examples
    ///
    /// ### ריכטיק באַניץ פון דעם אופֿן:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // יניטיאַליזירן `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // איצט עס איז באַוווסט אַז אונדזער קס 00 קס איז ינישיייטיד, עס איז אָוקיי צו שאַפֿן אַ שערד רעפֿערענץ צו אים:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // זיכערקייט: קס 00 קס איז ינישיייטיד.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### פאַלש באַניץ פון דעם אופֿן:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // מיר האָבן באשאפן אַ רעפֿערענץ צו אַ אַנינישיייטיד ז 0 וועקטאָר 0 ז!דאָס איז אַנדיפיינד נאַטור.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // ערשט די `MaybeUninit` מיט `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // דערמאָנען צו אַן אַנינישיייטיד קס 00 קס: וב!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `self` איז ינישיייטיד.
        // דאָס אויך מיטל אַז `self` מוזן זיין אַ `value` וואַריאַנט.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// געץ אַ מיוטאַבאַל (unique) דערמאָנען צו די קאַנטיינד ווערט.
    ///
    /// דאָס קען זיין נוציק ווען מיר וועלן אַקסעס צו אַן `MaybeUninit` וואָס איז ינישיייטיד, אָבער מיר האָבן נישט אָונערשיפּ פון די `MaybeUninit` (פּרעווענטינג די נוצן פון `.assume_init()`).
    ///
    /// # Safety
    ///
    /// אויב איר רופן דעם אינהאַלט ווען די אינהאַלט איז נישט נאָך ינישיייטיד, דאָס איז אַנדיפיינד די נאַטור: עס איז אַרויף צו די רופן צו גאַראַנטירן אַז די `MaybeUninit<T>` טאַקע איז אין אַן ינישאַלייזד שטאַט.
    /// פֿאַר בייַשפּיל, `.assume_init_mut()` קענען ניט זיין געניצט צו ינישאַלייז אַ `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### ריכטיק באַניץ פון דעם אופֿן:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// יניטיאַליזעס *אַלע* די ביטעס פון די אַרייַנשרייַב באַפער.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // יניטיאַליזירן `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // איצט מיר וויסן אַז `buf` איז ינישיייטיד, אַזוי מיר קען `.assume_init()` עס.
    /// // אָבער, ניצן `.assume_init()` קען צינגל אַ `memcpy` פון 2048 ביטעס.
    /// // צו באַשטעטיקן אונדזער באַפער איז ינישיייטיד אָן קאַפּיינג עס, מיר אַפּגרייד די `&mut MaybeUninit<[u8; 2048]>` צו אַ `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // זיכערקייט: קס 00 קס איז ינישיייטיד.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // איצט מיר קענען נוצן `buf` ווי אַ נאָרמאַל רעפטל:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### פאַלש באַניץ פון דעם אופֿן:
    ///
    /// איר קענען נישט נוצן `.assume_init_mut()` צו ינישאַלייז אַ ווערט:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // מיר האָבן באשאפן אַ קס 01 קס דערמאָנען צו אַן אַנינישיייטיד קס 00 קס!
    ///     // דאָס איז אַנדיפיינד נאַטור.⚠️
    /// }
    /// ```
    ///
    /// פֿאַר בייַשפּיל, איר קענען נישט [`Read`] אין אַ אַנינישיייטיד באַפער:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) דערמאָנען צו אַנינישיייטיד זכּרון!
    ///                             // דאָס איז אַנדיפיינד נאַטור.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// איר קענט נישט נוצן דירעקט פעלד אַקסעס צו דורכפירן גראַדזשואַל יניטיאַליזאַטיאָן פון פעלד דורך פעלד:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) דערמאָנען צו אַנינישיייטיד זכּרון!
    ///                  // דאָס איז אַנדיפיינד נאַטור.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) דערמאָנען צו אַנינישיייטיד זכּרון!
    ///                  // דאָס איז אַנדיפיינד נאַטור.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): מיר דערווייַל פאַרלאָזנ זיך אַז די אויבן איז פאַלש, דאָס הייסט מיר האָבן באַווייַזן צו אַנינישיייטיד דאַטן (למשל אין `libcore/fmt/float.rs`).
    // מיר זאָל מאַכן אַ לעצט באַשלוס וועגן די כּללים איידער סטייבאַלאַזיישאַן.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `self` איז ינישיייטיד.
        // דאָס אויך מיטל אַז `self` מוזן זיין אַ `value` וואַריאַנט.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// יקסטראַקץ די וואַלועס פון אַ מענגע פון `MaybeUninit` קאַנטיינערז.
    ///
    /// # Safety
    ///
    /// עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז אַלע יסודות פון דער מענגע זענען אין אַן יניטיאַליזעד שטאַט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // זיכערקייט: איצט זיכער ווי מיר ינישאַלייטיד אַלע עלעמענטן
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * די קאַללער געראַנטיז אַז אַלע יסודות פון די מענגע זענען יניטיאַליזעד
        // * `MaybeUninit<T>` און T זענען געראַנטיד צו האָבן די זעלבע אויסלייג
        // * MaybeUnint קען נישט פאַלן, אַזוי עס זענען קיין טאָפּל פרייז און אַזוי די קאַנווערזשאַן איז זיכער
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// אויב אַלע יסודות זענען ינישיייטיד, באַקומען אַ פּעקל צו זיי.
    ///
    /// # Safety
    ///
    /// עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די `MaybeUninit<T>` עלעמענטן טאַקע זענען אין אַן ינישאַלייזד שטאַט.
    ///
    /// אויב איר רופן דעם אינהאַלט ווען די אינהאַלט איז נישט גאָר יניטיאַליזעד, איז אַנדיפיינד די נאַטור.
    ///
    /// זען [`assume_init_ref`] פֿאַר מער דעטאַילס און ביישפילן.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // זיכערקייט: קאַסטינג רעפטל צו אַ קסקסנומקסקס איז זיכער ווייַל די קאַללער געראַנטיז אַז
        // `slice` איז יניטיאַליזעד, און `MaybeUninit` איז געראַנטיד צו האָבן די זעלבע אויסלייג ווי `T`.
        // די דערגרייה טייַטל איז גילטיק ווייַל עס רעפערס צו זיקאָרן אָונד דורך קס 00 קס, וואָס איז אַ רעפֿערענץ און אַזוי געראַנטיד צו זיין גילטיק פֿאַר רידינגז.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// אויב אַלע די עלעמענטן זענען ינישיייטיד, באַקומען אַ מיוטאַבאַל רעפטל צו זיי.
    ///
    /// # Safety
    ///
    /// עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז די `MaybeUninit<T>` עלעמענטן טאַקע זענען אין אַן ינישאַלייזד שטאַט.
    ///
    /// אויב איר רופן דעם אינהאַלט ווען די אינהאַלט איז נישט גאָר יניטיאַליזעד, איז אַנדיפיינד די נאַטור.
    ///
    /// זען [`assume_init_mut`] פֿאַר מער דעטאַילס און ביישפילן.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // זיכערהייט: ענלעך צו זיכערקייַט הערות פֿאַר קס 00 קס, אָבער מיר האָבן אַ
        // מיוטאַבאַל רעפֿערענץ וואָס איז אויך געראַנטיד צו זיין גילטיק פֿאַר שרייבט.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// געץ אַ טייַטל צו דער ערשטער עלעמענט פון דער מענגע.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// געץ אַ מיוטאַבאַל טייַטל צו דער ערשטער עלעמענט פון דער מענגע.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// קאפיעס די עלעמענטן פון קס 02 קס צו קס 01 קס, ריסטערינג אַ מיוטאַבאַל דערמאָנען צו די איצט יניטאַלייזד אינהאַלט פון קס 00 קס.
    ///
    /// אויב קס 02 קס טוט נישט ינסטרומענט קס 01 קס, נוצן קס 00 קס
    ///
    /// דאָס איז ענלעך צו קס 00 קס.
    ///
    /// # Panics
    ///
    /// די פֿונקציע וועט panic אויב די צוויי סלייסאַז האָבן פאַרשידענע לענגקטס.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // זיכערקייט: מיר האָבן פּונקט קאַפּיד אַלע עלעמענטן פון לענ אין די ספּער קאַפּאַציטעט
    /// // די ערשטע src.len() עלעמענטן פון די וועק זענען גילטיק איצט.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // זיכערקייט: &[ה] און&[מייַבעליוניניט<T>] האָבן די זעלבע אויסלייג
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // זיכערהייט: גילטיק עלעמענטן זענען פּונקט קאַפּיד אין `this`, אַזוי עס איז יניטאַלייזד
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// קלאָונז די עלעמענטן פֿון קס 02 קס צו קס 01 קס, ריסטערינג אַ מיוטאַבאַל דערמאָנען צו די איצט יניטאַליזעד אינהאַלט פון קס 00 קס.
    /// קיין שוין יניטאַליזעד עלעמענטן וועט ניט זיין דראַפּט.
    ///
    /// אויב קס 02 קס ימפּלאַמאַנץ קס 01 קס, נוצן קס 00 קס
    ///
    /// דאָס איז ענלעך צו [`slice::clone_from_slice`], אָבער נישט פאַלן יגזיסטינג עלעמענטן.
    ///
    /// # Panics
    ///
    /// די פונקציע וועט ז 0 פּאַניק 0 ז אויב די צוויי סלייסאַז האָבן פאַרשידענע לענגקטס, אָדער אויב די ימפּלאַמענטיישאַן פון קס 00 קס ז 0 פּאַניקס 0 ז.
    ///
    /// אויב עס איז panic, די שוין קלאָונד עלעמענטן וועט זיין דראַפּט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // זיכערקייט: מיר האָבן פּונקט קלאָונד אַלע עלעמענטן פון לענ אין די ספּער קאַפּאַציטעט
    /// // די ערשטע src.len() עלעמענטן פון די וועק זענען גילטיק איצט.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ניט ענלעך copy_from_slice, דאָס קען נישט רופן clone_from_slice אויף דעם רעפטל, דאָס איז ווייַל `MaybeUninit<T: Clone>` טוט נישט ינסטרומענט קלאָון.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // זיכערקייט: דעם רוי רעפטל כּולל בלויז יניטיאַליזעד אַבדזשעקץ
                // אַז ס וואָס, עס איז ערלויבט צו פאַלן עס.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: מיר דאַרפֿן צו זיין בישליימעס סלייסט צו די זעלבע לענג
        // צו קאָנטראָלירן די גווול צו זיין עליד, און דער אָפּטימיזער וועט דזשענערייט מעמקפּי פֿאַר פּשוט קאַסעס (פֿאַר בייַשפּיל T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // היטן איז נידז X00 קס ז 0 פּאַניק 0 ז קען פּאַסירן בעשאַס אַ קלאָון
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // זיכערקייט: גילטיק עלעמענטן זענען פּונקט געשריבן אין `this`, אַזוי עס איז יניטאַליזעד
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}