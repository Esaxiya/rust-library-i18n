use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// א ראַפּער צו ינכיבאַט די קאַמפּיילער פון אויטאָמאַטיש רופן די דעסטרוקטאָר פון T.
/// דעם ראַפּער איז 0-פּרייַז.
///
/// `ManuallyDrop<T>` איז אונטערטעניק צו דער זעלביקער אויסלייג אָפּטימיזאַטיאָנס ווי `T`.
/// דעריבער, עס האט קיין ווירקונג אויף די אַסאַמפּשאַנז אַז דער קאַמפּיילער גיט וועגן זיין אינהאַלט.
/// פֿאַר בייַשפּיל, יניטיאַליזינג אַ קסקסנומקסקס מיט קסקסנומקסקס איז אַנדיפיינד נאַטור.
/// אויב איר דאַרפֿן צו האַנדלען מיט אַנינישיייטיד דאַטן, נוצן [`MaybeUninit<T>`] אַנשטאָט.
///
/// באַמערקונג אַז אַקסעס די ווערט ין אַ `ManuallyDrop<T>` איז זיכער.
/// דעם מיטל אַז אַ `ManuallyDrop<T>` וועמענס אינהאַלט איז דראַפּט, זאָל נישט זיין יקספּאָוזד דורך אַ עפנטלעך זיכער אַפּי.
/// קאָראַספּאַנדינגלי, `ManuallyDrop::drop` איז אַנסייף.
///
/// # `ManuallyDrop` און פאַלן סדר.
///
/// ז 0 רוסט 0 ז האט אַ געזונט-דיפיינד קס 00 קס פון וואַלועס.
/// צו מאַכן זיכער אַז פעלדער אָדער לאָוקאַלז זענען דראַפּט אין אַ ספּעציפיש סדר, סדר די דעקלעריישאַנז אַזוי אַז די ימפּליסאַט קאַפּ סדר איז די ריכטיק.
///
/// עס איז מעגלעך צו נוצן `ManuallyDrop` צו קאָנטראָלירן די פאַלן סדר, אָבער דאָס ריקווייערז אַנסייף קאָד און עס איז שווער צו טאָן ריכטיק אין דעם בייַזייַן פון אַנוויינדינג.
///
///
/// פֿאַר בייַשפּיל, אויב איר ווילן צו מאַכן זיכער אַז אַ ספּעציפיש פעלד איז דראַפּט נאָך די אנדערע, מאַכן עס די לעצטע פעלד פון אַ סטרוקטור:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` וועט זיין דראַפּט נאָך `children`.
///     // Z0 רוסט 0 ז געראַנטיז אַז פעלדער זענען דראַפּט אין די סדר פון דעקלאַראַציע.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// ראַפּט אַ ווערט צו זיין מאַניואַלי דראַפּט.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // איר קענט נאָך בעשאָלעם אַרבעטן אויף די ווערט
    /// assert_eq!(*x, "Hello");
    /// // אָבער `Drop` וועט נישט לויפן דאָ
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// יקסטראַקץ די ווערט פון די `ManuallyDrop` קאַנטיינער.
    ///
    /// דעם אַלאַוז די ווערט צו זיין דראַפּט ווידער.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // דעם דראָפּס די `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// נעמט די ווערט פון די `ManuallyDrop<T>` קאַנטיינער.
    ///
    /// דער אופֿן איז בפֿרט בדעה צו אַריבערפירן וואַלועס אין קאַפּ.
    /// אַנשטאָט ניצן [`ManuallyDrop::drop`] צו מאַניואַלי פאַלן די ווערט, איר קענען נוצן דעם אופֿן צו נעמען די ווערט און נוצן עס ווי געוואלט.
    ///
    /// ווען מעגלעך, עס איז בילכער צו נוצן [`into_inner`][`ManuallyDrop::into_inner`] אַנשטאָט, וואָס פּריווענץ דיופּלאַקייטינג די אינהאַלט פון די `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// די פֿונקציע סעמאַנטיקאַללי באוועגט די קאַנטיינד ווערט אָן פּרעווענטינג ווייַטער באַניץ, ליווינג די שטאַט פון דעם קאַנטיינער אַנטשיינדזשד.
    /// עס איז דיין פֿאַראַנטוואָרטלעכקייט צו ענשור אַז די `ManuallyDrop` איז נישט געניצט ווידער.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // זיכערקייט: מיר לייענען פֿון אַ רעפֿערענץ וואָס איז געראַנטיד
        // צו זיין גילטיק פֿאַר לייענט.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// מאַניואַלי טראפנס די קאַנטיינד ווערט.דאָס איז פּונקט עקוויוואַלענט צו רופן [`ptr::drop_in_place`] מיט אַ טייַטל צו די קאַנטיינד ווערט.
    /// ווי אַזאַ, אויב דער כּולל ווערט איז אַ פּאַקט סטרוקטור, די דעסטרוקטאָר וועט זיין גערופֿן אין-אָרט אָן מאָווינג די ווערט, און אַזוי קענען זיין געוויינט צו בעשאָלעם פאַלן [pinned] דאַטן.
    ///
    /// אויב איר האָט אָונערשיפּ פון די ווערט, איר קענט נוצן [`ManuallyDrop::into_inner`] אַנשטאָט.
    ///
    /// # Safety
    ///
    /// די פֿונקציע ראַנז די דעסטראַקטאָר פון די קאַנטיינד ווערט.
    /// חוץ די ענדערונגען פון די דעסטרוקטאָר זיך, דער זכּרון איז לינקס אַנטשיינדזשד, און אַזוי ווי די קאַמפּיילער איז נאָך אַ ביסל מוסטער וואָס איז גילטיק פֿאַר דעם טיפּ קס 00 קס.
    ///
    ///
    /// אָבער, די "zombie" ווערט זאָל נישט זיין יקספּאָוזד צו זיכער קאָד, און די פֿונקציע זאָל נישט זיין גערופֿן מער ווי אַמאָל.
    /// צו נוצן אַ ווערט נאָך די דראַפּט, אָדער פאַלן אַ ווערט קייפל מאָל, קענען אָנמאַכן ונדעפינעד נאַטור (דיפּענדינג אויף וואָס `drop` טוט).
    /// דעם טיפּ סיסטעם איז יוזשאַוואַלי פּריווענטיד, אָבער די קס 00 קס וסערס מוזן האַלטן די געראַנטיז אָן הילף פון די קאַמפּיילער.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // זיכערקייט: מיר פאַרלאָזן די ווערט פון אַ מיוטאַבאַל באַווייַזן
        // וואָס איז געראַנטיד צו זיין גילטיק פֿאַר שרייבן.
        // עס איז אַרויף צו די קאָלער צו מאַכן זיכער אַז קסקסנומקסקס איז נישט דראַפּט ווידער.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}