//! דאָס איז אַ ינערלעך מאָדולע געניצט דורך די ifmt!רונטימע.די סטראַקטשערז זענען ימיטיד צו סטאַטיק ערייז צו פּריקאָמפּילע פֿאָרמאַט סטרינגס איידער די צייט.
//!
//! די זוך זענען ענלעך צו זייער `ct` יקוויוואַלאַנץ, אָבער אַנדערש אין דעם אַז זיי קענען זיין סטאַטיקלי אַלאַקייטיד און זענען אַ ביסל אָפּטימיזעד פֿאַר די רונטימע.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// מעגלעך אַליינמאַנץ וואָס קענען זיין פארלאנגט ווי טייל פון אַ פאָרמאַטטינג דירעקטיוו.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// אָנווייַז אַז די אינהאַלט זאָל זיין לינקס-אַליינד.
    Left,
    /// אָנווייַז אַז אינהאַלט זאָל זיין רעכט-אַליינד.
    Right,
    /// אָנווייַז אַז אינהאַלט זאָל זיין צענטער-אַליינד.
    Center,
    /// קיין אַליינמאַנט איז געווען געבעטן.
    Unknown,
}

/// געוויינט דורך ספּעסאַפאַקערז [width](https://doc.rust-lang.org/std/fmt/#width) און [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// ספּעציפיצירט מיט אַ ליטעראַל נומער, סטאָרז די ווערט
    Is(usize),
    /// ספּעציפיצירט מיט קס 01 קס און קס 02 קס סינטאַקסיז, סטאָרז די אינדעקס אין קס 00 קס
    Param(usize),
    /// נישט אויסגערעכנט
    Implied,
}