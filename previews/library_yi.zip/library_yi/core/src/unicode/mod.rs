#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// די ווערסיע פון [Unicode](http://www.unicode.org/) וואָס די Unicode פּאַרץ פון `char` און `str` מעטהאָדס זענען באזירט אויף.
///
/// ניו ווערסיעס פון אוניקאָד זענען קעסיידער באפרייט און דערנאָך אַלע מעטהאָדס אין דער נאָרמאַל ביבליאָטעק דיפּענדינג אויף אוניקאָד זענען דערהייַנטיקט.
/// דעריבער די נאַטור פון עטלעכע `char` און `str` מעטהאָדס און די ווערט פון דעם קעסיידערדיק ענדערונגען איבער צייַט.
/// דאָס איז *נישט* באטראכט ווי אַ ברייקינג ענדערונג.
///
/// די ווערסיע נאַמבערינג סכעמע איז דערקלערט אין [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// פֿאַר נוצן אין ליבאַלאָק, ניט שייַעך-יקספּאָרטאַד אין ליבסטד.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;