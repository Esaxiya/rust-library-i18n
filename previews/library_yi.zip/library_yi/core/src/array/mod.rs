//! ימפּלעמענטאַטיאָנס פון טינגז ווי `Eq` פֿאַר ערייז מיט פאַרפעסטיקט לענג אַרויף צו אַ זיכער לענג.
//! יווענטשאַוואַלי מיר זאָל קענען צו אַלגעמיין צו אַלע לענגקטס.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// קאָנווערט אַ רעפֿערענץ צו קס 00 קס אין אַ רעפֿערענץ צו אַ מענגע פון לענג 1 (אָן קאַפּיינג).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // זיכערקייט: קאָנווערטינג קס 00 קס צו קס 01 קס איז געזונט.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// קאָנווערץ אַ מיוטאַבאַל דערמאָנען צו קס 00 קס אין אַ מיוטאַבאַל דערמאָנען צו אַ מענגע פון לענג 1 (אָן קאַפּיינג).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // זיכערקייט: קאָנווערטינג קס 00 קס צו קס 01 קס איז געזונט.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// נוצן ז 0 טראַיט 0 ז ימפּלאַמענאַד בלויז אויף ערייז פון פאַרפעסטיקט גרייס
///
/// די ז 0 טראַיט 0 ז קענען ווערן גענוצט צו ינסטרומענט אנדערע ז 0 טראַיצ 0 ז אויף פאַרפעסטיקט-גרייס ערייז אָן קאָזינג פיל מעטאַדאַטאַ בלאָוט.
///
/// די trait איז אנגעצייכנט אַנסייף צו באַגרענעצן ימפּלעמענטאָרס צו פאַרפעסטיקט גרייס ערייז.
/// א באַניצער פון דעם ז 0 טראַיט 0 ז קענען יבערנעמען אַז ימפּלעמענטאָרס האָבן די פּינטלעך אויסלייג אין זכּרון פון אַ פאַרפעסטיקט גרייס מענגע (פֿאַר בייַשפּיל, פֿאַר אַנסייף יניטיאַליזאַטיאָן).
///
///
/// באַמערקונג אַז די traits [`AsRef`] און [`AsMut`] צושטעלן ענלעך מעטהאָדס פֿאַר טייפּס וואָס קען נישט זיין פאַרפעסטיקט ערייז.
/// ימפּלעמענטאָרס זאָל אָנשטאָט די traits אַנשטאָט.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// קאָנווערץ די מענגע צו ימיוטאַבאַל רעפטל
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// קאָנווערץ די מענגע צו מיוטאַבאַל רעפטל
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// די טעות טיפּ אומגעקערט ווען אַ קאַנווערזשאַן פון אַ רעפטל צו אַ מענגע פיילז.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // זיכערקייט: גוט ווייַל מיר פּונקט אָפּגעשטעלט אַז די לענג איז פּאַסיק
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // זיכערקייט: גוט ווייַל מיר פּונקט אָפּגעשטעלט אַז די לענג איז פּאַסיק
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: עטלעכע ווייניקער וויכטיק ימפּלס זענען איבערגעהיפּערט צו רעדוצירן קאָד בלאָוטיד
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// ימפּלאַמאַנץ פאַרגלייַך פון די ערייז [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// די ניט ויסצאָלן ימפּלס קענען ניט זיין געטאן מיט const generics ווייַל `[T; 0]` דאַרף נישט זיין ימפּלאַמענאַד דורך Default, און עס איז נישט געשטיצט נאָך ימפּלאַק בלאַקס פֿאַר פאַרשידענע נומערן.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// קערט אַ מענגע פון דער זעלביקער גרייס ווי קס 00 קס, מיט פונקציע קס 01 קס געווענדט צו יעדער עלעמענט אין סדר.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // זיכערקייט: מיר וויסן פֿאַר זיכער אַז דעם יטעראַטאָר וועט פּונקט געבן `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'זיפּס אַרויף' צוויי ערייז אין אַ איין מענגע פון פּערז.
    ///
    /// `zip()` קערט אַ נייַע מענגע ווו יעדער עלעמענט איז אַ טאָפּל ווו דער ערשטער עלעמענט קומט פון דער ערשטער מענגע, און די רגע עלעמענט קומט פון די רגע מענגע.
    ///
    /// אין אנדערע ווערטער, עס זיפּס צוויי ערייז צוזאַמען, אין אַ איין.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // זיכערקייט: מיר וויסן פֿאַר זיכער אַז דעם יטעראַטאָר וועט פּונקט געבן `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// רעטורנס אַ רעפטל מיט די גאנצע מענגע.עקוויוואַלענט צו קס 00 קס.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// קערט אַ מיוטאַבאַל רעפטל מיט די גאנצע מענגע.
    /// עקוויוואַלענט צו קס 00 קס.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// באָרגן יעדער עלעמענט און קערט אַ מענגע פון באַווייַזן מיט די זעלבע גרייס ווי `self`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// דער אופֿן איז דער הויפּט נוציק אויב קאַמביינד מיט אנדערע מעטהאָדס, ווי [`map`](#method.map).
    /// אויף דעם וועג, איר קענט ויסמיידן די אָריגינעל מענגע אויב די עלעמענטן זענען נישט `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // מיר קענען נאָך אַקסעס די אָריגינעל מענגע: עס איז נישט אריבערגעפארן.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // זיכערקייט: מיר וויסן פֿאַר זיכער אַז דעם יטעראַטאָר וועט פּונקט געבן `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// בענדז יעדער עלעמענט מיוטאַבלי און קערט אַ מענגע פון מיוטאַבאַל באַווייַזן מיט די זעלבע גרייס ווי קס 00 קס.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // זיכערקייט: מיר וויסן פֿאַר זיכער אַז דעם יטעראַטאָר וועט פּונקט געבן `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// פּולז קס 00 קס זאכן פון קס 01 קס און קערט זיי ווי אַ מענגע.
/// אויב די יטעראַטאָר ייעלדס ווייניקער ווי `N` ייטאַמז, די פֿונקציע יגזיבאַץ אַנדיפיינד נאַטור.
///
///
/// זען [`collect_into_array`] פֿאַר מער אינפֿאָרמאַציע.
///
/// # Safety
///
/// עס איז אַרויף צו די קאַללער צו גאַראַנטירן אַז קס 00 קס ייעלדס לפּחות קס 01 קס ייטאַמז.
/// ווייאַלייטינג דעם צושטאַנד זייַנען ונדעפינעד נאַטור.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` דאָ איז עפּעס אַן עקספּערימענט.דאָס איז נאָר אַן
    // ינערלעך פֿונקציע, אַזוי פילן פריי צו באַזייַטיקן אויב דאָס געבונדן טורנס אויס צו זיין אַ שלעכט געדאַנק.
    // אין דעם פאַל, געדענקען צו אַראָפּנעמען די נידעריקער `debug_assert!` ונטער!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // זיכערקייט: קאַווערד דורך די פונקציע קאָנטראַקט.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// פּולז קס 01 קס ייטאַמז פון קס 02 קס און קערט זיי ווי אַ מענגע.אויב די יטעראַטאָר ייעלדס ווייניקער ווי `N` ייטאַמז, `None` איז אומגעקערט און אַלע שוין יילד ייטאַמז זענען דראַפּט.
///
/// זינט די יטעראַטאָר איז דורכגעגאנגען ווי אַ מיוטאַבאַל רעפֿערענץ און די פֿונקציע רופט `next` בייַ רובֿ X1X מאָל, די יטעראַטאָר קענען נאָך זיין געניצט נאָך צו צוריקקריגן די רוען ייטאַמז.
///
///
/// אויב `iter.next()` פּאַניקז, אַלע ייטאַמז וואָס האָבן שוין יילדאַד דורך יטעראַטאָר פאַלן.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // זיכערקייט: אַ ליידיק מענגע איז שטענדיק ינכאַבאַטאַד און האט קיין גילטיקייט ינוואַריאַרץ.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // זיכערקייט: דעם רוי רעפטל כּולל בלויז יניטיאַליזעד אַבדזשעקץ.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // זיכערקייט: קס 00 קס סטאַרץ ביי 0, איז געוואקסן דורך איינער אין די
        // שלייף און די שלייף איז אַבאָרטיד אַמאָל עס ריטשאַז ען (וואָס איז קס 00 קס.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // קאָנטראָלירן צי די גאנצע מענגע איז געווען ינישיייטיד.
        if guard.initialized == N {
            mem::forget(guard);

            // זיכערקייט: די אויבן צושטאַנד באַשטעטיקט אַז אַלע עלעמענטן זענען
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // דאָס איז בלויז ריטשט אויב די יטעראַטאָר איז ויסגעמאַטערט איידער קס 01 קס ריטשאַז קס 00 קס.
    //
    // אויך טאָן אַז `guard` איז דראַפּט דאָ, דראַפּינג אַלע שוין ינישיייטיד עלעמענטן.
    None
}