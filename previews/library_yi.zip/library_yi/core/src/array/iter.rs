//! דיפיינז די `IntoIter` אָונד יטעראַטאָר פֿאַר ערייז.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// א ביי-ווערט [array] יטעראַטאָר.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// דאָס איז די מענגע וואָס מיר יבערקוקן.
    ///
    /// עלעמענטן מיט אינדעקס `i` וווּ `alive.start <= i < alive.end` האָבן נישט נאָך געווען יילדאַד און זענען גילטיק אַרעאַס איינסן.
    /// עלעמענטן מיט ינדעקסיז קס 00 קס אָדער קס 01 קס האָבן שוין יילדאַד און מוזן ניט זיין אַקסעסט ענימאָר!יענע טויט עלעמענטן קען אפילו זיין אין אַ גאָר אַנינישיייטיד שטאַט!
    ///
    ///
    /// די ינוואַריאַנץ זענען אַזוי:
    /// - `data[alive]` איז לעבעדיק (י.ע. כּולל גילטיק עלעמענטן)
    /// - `data[..alive.start]` און `data[alive.end..]` זענען טויט (ד"ה די עלעמענטן זענען שוין לייענען און מוזן ניט זיין גערירט ענימאָר!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// די עלעמענטן אין קס 00 קס וואָס האָבן ניט געווען יילדאַד נאָך.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// קריייץ אַ נייַ יטעראַטאָר איבער די געגעבן `array`.
    ///
    /// *באַמערקונג*: דעם אופֿן קען זיין דעפּרעסאַטעד אין די future נאָך [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // דער טיפּ פון קס 01 קס איז אַ קס 02 קס דאָ, אַנשטאָט פון קס 00 קס
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // זיכערקייט: די טראַנסמוט דאָ איז אַקשלי זיכער.די דאָקס פון קס 00 קס
        // promise:
        //
        // > `MaybeUninit<T>` איז געראַנטיד צו האָבן די זעלבע גרייס און אַליינמאַנט
        // > ווי קס 00 קס.
        //
        // די דאָקומענטן אפילו ווייַזן אַ טראַנסמוטע פון אַ מענגע פון קס 01 קס צו אַ מענגע פון קס 00 קס.
        //
        //
        // מיט דעם, דעם יניטיאַליזיישאַן סאַטיספייז די ינוואַריאַנץ.

        // FIXME(LukasKalbertodt): טאַקע נוצן `mem::transmute` דאָ, אַמאָל עס אַרבעט מיט const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // ביז דאַן מיר קענען נוצן `mem::transmute_copy` צו שאַפֿן אַ ביטווייז קאָפּיע ווי אַ אַנדערש טיפּ, און פאַרגעסן `array` אַזוי אַז עס איז נישט דראַפּט.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// קערט אַ יממוטאַבאַל רעפטל פון אַלע עלעמענטן וואָס האָבן נישט נאָך געווען יילדאַד.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // זיכערהייט: מיר וויסן אַז אַלע עלעמענטן אין קס 00 קס זענען רעכט יניטיאַליזעד.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// קערט אַ מיוטאַבאַל רעפטל פון אַלע עלעמענטן וואָס האָבן נישט נאָך געווען יילדאַד.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // זיכערהייט: מיר וויסן אַז אַלע עלעמענטן אין קס 00 קס זענען רעכט יניטיאַליזעד.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // באַקומען די ווייַטער אינדעקס פֿון די פראָנט.
        //
        // ינקרעאַסינג קס 01 קס מיט 1 מיינטיינז די ינוועראַנט וועגן X00 קס.
        // אָבער, רעכט צו דעם ענדערונג, פֿאַר אַ קורץ צייט, די לעבעדיק זאָנע איז נישט `data[alive]` ענימאָר, אָבער `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // לייענען דעם עלעמענט פֿון די מענגע.
            // זיכערקייט: קס 00 קס איז אַן אינדעקס אין די ערשטע קס 01 קס געגנט פון די
            // מענגע.לייענען דעם עלעמענט מיטל אַז קס 00 קס איז גערעכנט ווי טויט איצט (י.ע. טאָן ניט אָנרירן).
            // ווי `idx` איז געווען דער אָנהייב פון די לעבעדיק זאָנע, די לעבעדיק זאָנע איז איצט `data[alive]` ווידער, ריסטאָרינג אַלע ינוואַריאַנץ.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // באַקומען די ווייַטער אינדעקס פֿון די צוריק.
        //
        // דיקריסינג קס 01 קס ביי 1 מיינטיינז די ינוועראַנט וועגן X00 קס.
        // אָבער, רעכט צו דעם ענדערונג, פֿאַר אַ קורץ צייט, די לעבעדיק זאָנע איז נישט `data[alive]` ענימאָר, אָבער `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // לייענען דעם עלעמענט פֿון די מענגע.
            // זיכערקייט: קס 00 קס איז אַן אינדעקס אין די ערשטע קס 01 קס געגנט פון די
            // מענגע.לייענען דעם עלעמענט מיטל אַז קס 00 קס איז גערעכנט ווי טויט איצט (י.ע. טאָן ניט אָנרירן).
            // ווי `idx` איז געווען דער סוף פון די לעבעדיק-זאָנע, די לעבעדיק זאָנע איז איצט `data[alive]` ווידער, ריסטאָרינג אַלע ינוואַריאַנץ.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // זיכערהייט: דאָס איז זיכער: `as_mut_slice` קערט פּונקט די סאַב-רעפטל
        // פון עלעמענטן וואָס זענען נישט אריבערגעפארן נאָך און וואָס בלייבן צו זיין דראַפּט.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // וועט קיינמאָל אַנדערפלאָו רעכט צו די טאָמיד `לעבעדיק. אָנהייב <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// די יטעראַטאָר ריפּאָרץ טאַקע די ריכטיק לענג.
// די נומער פון קס 01 קס עלעמענטן (וואָס וועט נאָך זיין יילדאַד) איז די לענג פון די קייט קס X קס.
// די קייט איז דיקריסט אין די X1X אָדער `next_back` לענג.
// עס איז שטענדיק דיקריסט דורך 1 אין די מעטהאָדס, אָבער נאָר אויב `Some(_)` איז אומגעקערט.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // באַמערקונג, מיר טאָן ניט טאַקע דאַרפֿן צו גלייַכן די פּינטלעך זעלביקער לעבעדיק קייט, אַזוי מיר קענען נאָר קלאָון אין פאָטאָ 0 ראַגאַרדלאַס פון ווו `self` איז.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // קלאָון אַלע לעבעדיק עלעמענטן.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // שרייב אַ קלאָון אין די נייַע מענגע און דערהייַנטיקן די לעבעדיק קייט.
            // אויב קלאָונינג panics, מיר וועלן ריכטיק פאַלן די פריערדיקע ייטאַמז.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // בלויז דרוקן די עלעמענטן וואָס זענען נישט יילד נאָך: מיר קענען נישט אַקסעס די ייעלדאַד עלעמענטן ענימאָר.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}