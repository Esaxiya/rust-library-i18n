//! די מאָדולע ימפּלאַמאַנץ די `Any` trait, וואָס אַלאַוז דינאַמיש טייפּינג פון קיין `'static` טיפּ דורך רונטימע אָפּשפּיגלונג.
//!
//! `Any` זיך קענען ווערן גענוצט צו באַקומען אַ `TypeId`, און האט מער פֿעיִקייטן ווען געוויינט ווי אַ trait כייפעץ.
//! ווי `&dyn Any` (אַ באַראָוד trait כייפעץ), עס האט די `is` און `downcast_ref` מעטהאָדס, צו פּרובירן אויב די קאַנטיינד ווערט איז פון אַ געגעבן טיפּ, און צו באַקומען אַ דערמאָנען צו די ינער ווערט ווי אַ טיפּ.
//! ווי `&mut dyn Any`, עס איז אויך די `downcast_mut` אופֿן צו באַקומען אַ מיוטאַבאַל רעפֿערענץ צו די ינער ווערט.
//! `Box<dyn Any>` מוסיף די `downcast` אופֿן, וואָס פרוווט צו בייַטן צו אַ `Box<T>`.
//! פֿאַר מער אינפֿאָרמאַציע, זען די [`Box`] דאַקיומענטיישאַן.
//!
//! באַמערקונג אַז קס 00 קס איז לימיטעד צו טעסטינג צי אַ ווערט איז פון אַ ספּעסאַפייד באַטאָנען טיפּ, און קענען ניט זיין געניצט צו פּרובירן צי אַ טיפּ ימפּלאַמאַנץ אַ ז 0 טראַיט 0 ז.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # סמאַרט פּוינטערז און קס 00 קס
//!
//! איין אָפּפירונג צו האַלטן אין זינען ווען איר נוצן `Any` ווי אַ trait כייפעץ, ספּעציעל מיט טייפּס ווי `Box<dyn Any>` אָדער `Arc<dyn Any>`, איז אַז פשוט רופן `.type_id()` אויף די ווערט וועט פּראָדוצירן די `TypeId` פון די *קאַנטיינער*, נישט די אַנדערלייינג trait כייפעץ.
//!
//! דאָס קען זיין אַוווידאַד דורך קאַנווערטינג די קלוג טייַטל אין אַ `&dyn Any` אַנשטאָט, וואָס וועט צוריקקומען די `TypeId` פון די כייפעץ.
//! צום ביישפיל:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // איר'רע מער מסתּמא צו וועלן דאָס:
//! let actual_id = (&*boxed).type_id();
//! // ... ווי דאָס:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! באטראכט אַ סיטואַציע וווּ מיר וועלן צו ויסמעקן אַ ווערט וואָס איז דורכגעגאנגען צו אַ פונקציע.
//! מיר וויסן די ווערט וואָס מיר ארבעטן אויף ימפּלאַמאַנץ דעבוג, אָבער מיר טאָן ניט וויסן די באַטאָנען טיפּ.מיר וועלן צו געבן ספּעציעלע באַהאַנדלונג פֿאַר עטלעכע טייפּס: אין דעם פאַל, דרוקן די לענג פון סטרינג וואַלועס איידער זייער ווערט.
//! מיר טאָן ניט וויסן די באַטאָנען טיפּ פון אונדזער ווערט אין די קאַמפּיילד צייט, אַזוי מיר דאַרפֿן צו נוצן רונטימע אָפּשפּיגלונג אַנשטאָט.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // לאַגער פונקציע פֿאַר קיין טיפּ אַז ימפּלאַמאַנץ דעבוג.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // פּרוּווט צו בייַטן אונדזער ווערט צו אַ `String`.
//!     // אויב געראָטן, מיר וועלן צו ווייַזן די לענג פון די שטריקל און די ווערט.
//!     // אויב ניט, עס איז אַ אַנדערש טיפּ: נאָר דרוקן עס אַנאַדאָרן.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // די פֿונקציע וויל צו קלאָץ די פּאַראַמעטער איידער איר אַרבעט מיט אים.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... טאָן עטלעכע אנדערע אַרבעט
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// קיין trait
///////////////////////////////////////////////////////////////////////////////

/// א ז 0 טראַיט 0 ז צו עמיאַלייט דינאַמיש טייפּינג.
///
/// רובֿ טייפּס ינסטרומענט קס 00 קס.אָבער, קיין טיפּ וואָס כּולל אַ ניט-"סטאַטיק" דערמאָנען קען נישט.
/// זען די [module-level documentation][mod] פֿאַר מער דעטאַילס.
///
/// [mod]: crate::any
// די trait איז נישט אַנסייף, כאָטש מיר פאַרלאָזנ זיך די ספּעציפֿישקייט פון די `type_id` פונקציאָנירן אין אַנסייף קאָד (למשל `downcast`).נאָרמאַללי, דאָס וואָלט זיין אַ פּראָבלעם, אָבער ווייַל די בלויז ימפּלאַמענטיישאַן פון קס 02 קס איז אַ פאַרדעקן ימפּלאַמענטיישאַן, קיין אנדערע קאָד קענען ינסטרומענט קס 00 קס.
//
// מיר קען גלייך מאַכן דעם trait אַנסייף-דאָס קען נישט פאַרשאַפן ברייקידזש, ווייַל מיר קאָנטראָלירן אַלע ימפּלעמענטאַטיאָנס-אָבער מיר קלייַבן ניט צו, ווייַל דאָס איז ניט טאַקע נויטיק און קען צעמישן וסערס וועגן די דיסטינגקשאַן פון אַנסייף traits און אַנסייף מעטהאָדס (ד"ה, `type_id` איז נאָך זיכער צו רופן, אָבער מיר וואָלט מסתּמא וועלן צו אָנווייַזן ווי אַזאַ אין דאַקיומענטיישאַן.
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// געץ די קס 01 קס פון קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// פאַרלענגערונג מעטהאָדס פֿאַר קיין אַבדזשעקץ פון trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ענסורע אַז דער רעזולטאַט פון למשל, דזשוינינג אַ פאָדעם קענען זיין געדרוקט און דערנאָך געוויינט מיט קס 00 קס.
// קען יווענטשאַוואַלי ניט מער זיין נידז אויב דעפּעש אַרבעט מיט ופּקאַסטינג.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// קערט קס 01 קס אויב די באַקסט טיפּ איז די זעלבע ווי קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // באַקומען קס 00 קס פון דעם טיפּ מיט וואָס די פֿונקציע איז ינסטאַנטיד.
        let t = TypeId::of::<T>();

        // באַקומען `TypeId` פון די טיפּ אין די trait כייפעץ (`self`).
        let concrete = self.type_id();

        // פאַרגלייכן ביידע 'טיפּעיד' ס אויף יקוואַלאַטי.
        t == concrete
    }

    /// רעטורנס עטלעכע דערמאָנען צו די באַקסט ווערט אויב עס איז פון טיפּ קס 00 קס, אָדער קס 01 קס אויב עס איז נישט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // זיכערקייט: פּונקט אָפּגעשטעלט צי מיר ווייזן צו די ריכטיק טיפּ, און מיר קענען פאַרלאָזנ זיך
            // אַז טשעק פֿאַר זכּרון זיכערקייַט ווייַל מיר האָבן ימפּלאַמענאַד קיין פֿאַר אַלע טייפּס;קיין אנדערע ימפּלייז קענען עקסיסטירן ווי זיי וואָלט קאָנפליקט מיט אונדזער ימפּ.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// רעטורנס עטלעכע מיוטאַבאַל דערמאָנען צו די באַקסט ווערט אויב עס איז פון טיפּ קס 00 קס, אָדער קס 01 קס אויב נישט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // זיכערקייט: פּונקט אָפּגעשטעלט צי מיר ווייזן צו די ריכטיק טיפּ, און מיר קענען פאַרלאָזנ זיך
            // אַז טשעק פֿאַר זכּרון זיכערקייַט ווייַל מיר האָבן ימפּלאַמענאַד קיין פֿאַר אַלע טייפּס;קיין אנדערע ימפּלייז קענען עקסיסטירן ווי זיי וואָלט קאָנפליקט מיט אונדזער ימפּ.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// פֿאָרווערטס צו די דיפיינד אופֿן פון די טיפּ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// פֿאָרווערטס צו די דיפיינד אופֿן פון די טיפּ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// פֿאָרווערטס צו די דיפיינד אופֿן פון די טיפּ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// פֿאָרווערטס צו די דיפיינד אופֿן פון די טיפּ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// פֿאָרווערטס צו די דיפיינד אופֿן פון די טיפּ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// פֿאָרווערטס צו די דיפיינד אופֿן פון די טיפּ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// טיפּעיד און זייַן מעטהאָדס
///////////////////////////////////////////////////////////////////////////////

/// א קס 00 קס רעפּראַזענץ אַ גלאָובאַלי יינציק ידענטיפיער פֿאַר אַ טיפּ.
///
/// יעדער `TypeId` איז אַן אָופּייק כייפעץ וואָס אַלאַוז נישט דורכקוק וואָס איז ין, אָבער אַלאַוז יקערדיק אַפּעריישאַנז אַזאַ ווי קלאָונינג, פאַרגלייַך, דרוקן און ווייַזן.
///
///
/// א קס 01 קס איז דערווייַל בלויז בארעכטיגט פֿאַר טייפּס וואָס געבן X00 קס, אָבער די באַגרענעצונג קען זיין אַוועקגענומען אין די future.
///
/// בשעת `TypeId` ימפּלאַמאַנץ `Hash`, `PartialOrd` און `Ord`, עס איז כדאי צו באמערקן אַז די האַשעס און אָרדערינג וועט בייַטן צווישן Rust ריליסיז.
/// היט אייך פון רילייינג אויף זיי ין דיין קאָד!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// קערט די `TypeId` פון דעם טיפּ מיט וואָס די דזשאַנעריק פונקציע איז ינסטאַנטיד.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// קערט דער נאָמען פון אַ טיפּ ווי אַ שטריקל רעפטל.
///
/// # Note
///
/// דאָס איז בדעה פֿאַר דיאַגנאָסטיק נוצן.
/// די פּינטלעך אינהאַלט און פֿאָרמאַט פון די שטריקל וואָס איז אומגעקערט זענען נישט ספּעציפיצירט, אַחוץ צו זיין אַ בעסטער-מי באַשרייַבונג פון דעם טיפּ.
/// פֿאַר בייַשפּיל, `"Option<String>"` און `"std::option::Option<std::string::String>"` צווישן די סטרינגס אַז `type_name::<Option<String>>()` קען צוריקקומען.
///
///
/// די אומגעקערט שטריקל דאַרף ניט זיין באטראכט ווי אַ יינציק ידענטיפיער פון אַ טיפּ, ווייַל קייפל טייפּס קען מאַפּ צו די זעלבע טיפּ נאָמען.
/// סימילאַרלי, עס איז קיין גאַראַנטירן אַז אַלע פּאַרץ פון אַ טיפּ וועט זיין געוויזן אין די אומגעקערט שטריקל: פֿאַר בייַשפּיל, לעבן ספּעציפיצירן זענען דערווייַל נישט אַרייַנגערעכנט.
/// אין אַדישאַן, דער רעזולטאַט קען טוישן צווישן די ווערסיעס פון די קאַמפּיילער.
///
/// די קראַנט ימפּלאַמענטיישאַן ניצט די זעלבע ינפראַסטראַקטשער ווי קאַמפּיילער דייאַגנאַסטיקס און דעבוגינפאָ, אָבער דאָס איז נישט געראַנטיד.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// קערט דער נאָמען פון דעם טיפּ פון די שפּיציק ווערט ווי אַ שטריקל רעפטל.
/// דאָס איז די זעלבע ווי `type_name::<T>()`, אָבער קענען זיין געוויינט ווען די טיפּ פון אַ בייַטעוודיק איז נישט לייכט בנימצא.
///
/// # Note
///
/// דאָס איז בדעה פֿאַר דיאַגנאָסטיק נוצן.די פּינטלעך אינהאַלט און פֿאָרמאַט פון די שטריקל זענען נישט ספּעסיפיעד, אַחוץ צו זיין אַ בעסטער-מי באַשרייַבונג פון דעם טיפּ.
/// פֿאַר בייַשפּיל, `type_name_of_val::<Option<String>>(None)` קען צוריקקומען `"Option<String>"` אָדער `"std::option::Option<std::string::String>"`, אָבער נישט `"foobar"`.
///
/// אין אַדישאַן, דער רעזולטאַט קען טוישן צווישן די ווערסיעס פון די קאַמפּיילער.
///
/// די פונקציע קען נישט האַלטן trait אַבדזשעקץ, דאָס מיינט אַז `type_name_of_val(&7u32 as &dyn Debug)` קען צוריקקומען `"dyn Debug"`, אָבער נישט `"u32"`.
///
/// דער טיפּ נאָמען זאָל ניט זיין קאַנסידערד ווי אַ יינציק ידענטיפיער פון אַ טיפּ;
/// קייפל טייפּס קענען טיילן די זעלבע טיפּ נאָמען.
///
/// די קראַנט ימפּלאַמענטיישאַן ניצט די זעלבע ינפראַסטראַקטשער ווי קאַמפּיילער דייאַגנאַסטיקס און דעבוגינפאָ, אָבער דאָס איז נישט געראַנטיד.
///
/// # Examples
///
/// פּרינץ די פעליקייַט ינטאַדזשער און לאָזנ שווימען טייפּס.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}