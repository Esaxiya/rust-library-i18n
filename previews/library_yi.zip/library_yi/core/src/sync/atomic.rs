//! אַטאָמישע טייפּס
//!
//! אַטאָמישע טייפּס צושטעלן פּרימיטיוו שערד-זכּרון קאָמוניקאַציע צווישן פֿעדעם און זענען די בלאַקס פון אנדערע קאַנקעראַנט טייפּס.
//!
//! דעם מאָדולע דיפיינז אַטאָמישע ווערסיעס פון אַ סעלעקטעד נומער פון פּרימיטיוו טייפּס, אַרייַנגערעכנט [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], אאז"ו ו.
//! אַטאָמישע טייפּס פאָרשטעלן אַפּעריישאַנז וואָס, ווען געוויינט ריכטיק, סינגקראַנייז דערהייַנטיקונגען צווישן פֿעדעם.
//!
//! יעדער אופֿן נעמט אַן [`Ordering`] וואָס רעפּראַזענץ די שטאַרקייט פון די זכּרון שלאַבאַן פֿאַר די אָפּעראַציע.די אָרדערינגז זענען די זעלבע ווי די [C++20 atomic orderings][1].פֿאַר מער אינפֿאָרמאַציע, זען די [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! אַטאָמישע וועריאַבאַלז קענען זיין ייַנטיילן צווישן פֿעדעם (זיי ינסטרומענט קס 01 קס), אָבער זיי טאָן ניט צושטעלן די מעקאַניזאַם פֿאַר ייַנטיילונג און נאָכגיין די קס 00 קס פון ז 0 רוסט 0 ז.
//!
//! די מערסט פּראָסט וועג צו טיילן אַן אַטאָמישע בייַטעוודיק איז צו שטעלן עס אין אַ [`Arc`][arc] (אַן אַטאָמישלי רעפעררעד-גערעכנט שערד טייַטל).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! אַטאָמישע טייפּס קענען זיין סטאָרד אין סטאַטיק וועריאַבאַלז, ינישאַלייזד מיט קעסיידערדיק יניטיאַליזערס ווי קס 00 קס.אַטאָמישע סטאַטיקס זענען אָפט געניצט פֿאַר פויל גלאבאלע יניטיאַליזיישאַן.
//!
//! # Portability
//!
//! אַלע אַטאָמישע טייפּס אין דעם מאָדולע זענען געראַנטיד צו זיין [lock-free] אויב זיי זענען בארעכטיגט.דאָס מיינט אַז זיי טאָן ניט קריגן אַ גלאבאלע מוטעקס ינעווייניק.אַטאָמישע טייפּס און אַפּעריישאַנז זענען נישט געראַנטיד צו זיין וואַרטן-פריי.
//! דעם מיטל אַז אַפּעריישאַנז ווי קס 00 קס קען זיין ימפּלאַמענאַד מיט אַ פאַרגלייכן און-ויסבייַטן שלייף.
//!
//! אַטאָמישע אַפּעריישאַנז קענען זיין ימפּלאַמענאַד אין די ינסטרוקטיאָן שיכטע מיט אַטאָמישע גרעסערע גרייס.פֿאַר בייַשפּיל, עטלעכע פּלאַטפאָרמס נוצן אַטאָמישע ינסטרומענץ פון 4 בייט צו ינסטרומענט קס 00 קס.
//! באַמערקונג אַז די עמיאַליישאַן זאָל נישט האָבן אַ פּראַל אויף די ריכטיק פון קאָד, עס איז נאָר עפּעס צו זיין אַווער פון.
//!
//! די אַטאָמישע טייפּס אין דעם מאָדולע קען נישט זיין בארעכטיגט אויף אַלע פּלאַטפאָרמס.די אַטאָמישע טייפּס דאָ זענען אַלע וויידלי בנימצא, אָבער, און קענען בכלל זיין רילייד אויף יגזיסטינג.עטלעכע נאָוטאַבאַל אויסנעמען זענען:
//!
//! * PowerPC און MIPS פּלאַטפאָרמס מיט 32-ביסל פּוינטערז טאָן ניט האָבן קס 01 קס אָדער קס 02 קס טייפּס.
//! * ARM פּלאַטפאָרמס ווי `armv5te` וואָס זענען נישט פֿאַר Linux בלויז X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X X 1 X
//! אויף קס 00 קס, די CAS אַפּעריישאַנז זענען ימפּלאַמענאַד דורך קס 01 קס, וואָס קען קומען מיט אַ פאָרשטעלונג שטראָף.
//! * ARM טאַרגאַץ מיט `thumbv6m` צושטעלן בלויז `load` און `store` אַפּעריישאַנז, און טאָן ניט שטיצן קאָמפּאַרע און ויסבייַטן (CAS) אַפּעריישאַנז, אַזאַ ווי `swap`, `fetch_add`, עטק.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! באַמערקונג אַז future פּלאַטפאָרמס קען זיין מוסיף וואָס אויך טאָן ניט האָבן שטיצן פֿאַר עטלעכע אַטאָמישע אַפּעריישאַנז.מאַקסימאַללי פּאָרטאַטיוו קאָד וועט וועלן צו זיין אָפּגעהיט וועגן וואָס אַטאָמישע טייפּס זענען געניצט.
//! `AtomicUsize` און `AtomicIsize` זענען בכלל די מערסט פּאָרטאַטיוו, אָבער אפילו זיי זענען נישט בנימצא אומעטום.
//! פֿאַר דערמאָנען, די `std` ביבליאָטעק ריקווייערז טייַטל, סייזד אַטאָמיקס, כאָטש `std` איז נישט.
//!
//! דערווייַל איר דאַרפֿן צו נוצן קס 00 קס בפֿרט צו קאַנדישאַנאַלי זאַמלען אין קאָד מיט אַטאָמיקס.עס איז אַן אַנסטייבאַל `#[cfg(target_has_atomic)]` וואָס קען זיין סטייבאַלייזד אין די future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! א פּשוט ספּינלאָקק:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // וואַרטן פֿאַר די אנדערע פאָדעם צו באַפרייַען די שלאָס
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! האַלטן אַ גלאבאלע ציילן פון לעבן פֿעדעם:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// א באָאָלעאַן טיפּ וואָס קענען זיין שערד בעשאָלעם צווישן פֿעדעם.
///
/// דער טיפּ איז דער זעלביקער אין-זכּרון פאַרטרעטונג ווי אַ [`bool`].
///
/// **באַמערקונג**: דעם טיפּ איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע לאָודז און סטאָרז פון קס 00 קס.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// קרעאַטעס אַן `AtomicBool` ינישאַלייזד צו `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// שיקן איז ימפּליסאַטלי ימפּלאַמענאַד פֿאַר אַטאָמיקבאָאָל.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// א רוי טייַטל טיפּ וואָס קענען זיין בעשאָלעם שערד צווישן פֿעדעם.
///
/// דער טיפּ איז דער זעלביקער אין-זכּרון פאַרטרעטונג ווי אַ `*mut T`.
///
/// **באַמערקונג**: דעם טיפּ איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע לאָודז און סטאָרז פון פּוינטערז.
/// די גרייס איז דעפּענדס אויף די גרייס פון דער ציל טייַטל.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// קרעאַטעס אַ נאַל קס 00 קס.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// אַטאָמאַן זכּרון אָרדערס
///
/// זכּרון אָרדערינגז ספּעציפיצירן די וועג אַטאָמישע אַפּעריישאַנז סינגקראַנייז זכּרון.
/// אין די וויקאַסט [`Ordering::Relaxed`], נאָר די זכּרון גערירט דורך די אָפּעראַציע איז סינגקראַנייזד.
/// אויף די אנדערע האַנט, אַ קראָם-מאַסע פּאָר פון קס 00 קס אַפּעריישאַנז סינגקראַנייז אנדערע זכּרון און אַדישנאַל אַ גאַנץ סדר פון אַזאַ אַפּעריישאַנז איבער אַלע פֿעדעם.
///
///
/// די זכּרון אָרדערס פון Rust זענען [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// פֿאַר מער אינפֿאָרמאַציע, זען די [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ניט קיין אָרדערינג קאַנסטריינץ, נאָר אַטאָמישע אַפּעריישאַנז.
    ///
    /// קאָראַספּאַנדז צו [`memory_order_relaxed`] אין C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// צוזאַמען מיט אַ קראָם, אַלע פריער אַפּעריישאַנז זענען אָרדערד איידער קיין מאַסע פון דעם ווערט מיט [`Acquire`] (אָדער שטארקער) אָרדערינג.
    ///
    /// אין באַזונדער, אַלע פריערדיקע שרייבן ווערן קענטיק פֿאַר אַלע פֿעדעם וואָס דורכפירן אַן [`Acquire`] (אָדער שטארקער) מאַסע פון דעם ווערט.
    ///
    /// באמערקט אַז ניצן דעם אָרדערינג פֿאַר אַן אָפּעראַציע וואָס קאַמביינז לאָודז און סטאָרז, פירן צו אַ [`Relaxed`] מאַסע אָפּעראַציע!
    ///
    /// די אָרדערינג איז בלויז אָנווענדלעך פֿאַר אַפּעריישאַנז וואָס קענען דורכפירן אַ קראָם.
    ///
    /// קאָראַספּאַנדז צו [`memory_order_release`] אין C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// אויב די לאָודיד ווערט איז געשריבן דורך אַ קראָם אָפּעראַציע מיט [`Release`] (אָדער שטארקער) אָרדערינג, אַלע די סאַבסאַקוואַנט אַפּעריישאַנז זענען אָרדערד נאָך די קראָם.
    /// אין באַזונדער, אַלע סאַבסאַקוואַנט לאָודז וועט זען דאַטן געשריבן איידער די קראָם.
    ///
    /// נאָטיץ אַז ניצן דעם אָרדערינג פֿאַר אַ אָפּעראַציע וואָס קאַמביינז לאָודז און סטאָרז, פירן צו אַ [`Relaxed`] קראָם אָפּעראַציע!
    ///
    /// די אָרדערינג איז בלויז אָנווענדלעך פֿאַר אַפּעריישאַנז וואָס קענען דורכפירן אַ מאַסע.
    ///
    /// קאָראַספּאַנדז צו [`memory_order_acquire`] אין C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// האט די יפעקס פון ביידע [`Acquire`] און [`Release`] צוזאַמען:
    /// פֿאַר לאָודז עס ניצט [`Acquire`] אָרדערינג.פֿאַר סטאָרז עס ניצט די [`Release`] אָרדערינג.
    ///
    /// נאָטיץ אַז אין די פאַל פון `compare_and_swap`, עס איז מעגלעך אַז די אָפּעראַציע ענדיקן נישט קיין קראָם און דערפאר עס נאָר [`Acquire`] אָרדערינג.
    ///
    /// אָבער, `AcqRel` וועט קיינמאָל דורכפירן אַקסעס [`Relaxed`].
    ///
    /// די אָרדערינג איז בלויז אָנווענדלעך פֿאַר אַפּעריישאַנז וואָס פאַרבינדן ביידע לאָודז און סטאָרז.
    ///
    /// קאָראַספּאַנדז צו [`memory_order_acq_rel`] אין C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// ווי [`אַקקווירע`]/[`ריליס`]/[`AcqRel`](פֿאַר ריספּעקטיוולי מאַסע, קראָם און מאַסע-מיט אַפּעריישאַנז) מיט די נאָך גאַראַנטירן אַז אַלע פֿעדעם זען אַלע סאַקווענטשאַלי קאָנסיסטענט אַפּעריישאַנז אין דער זעלביקער סדר .
    ///
    ///
    /// קאָראַספּאַנדז צו [`memory_order_seq_cst`] אין C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// אַ קס 01 קס יניטיאַלייזד צו קס 00 קס.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// קרעאַטעס אַ נייַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// קערט אַ מיוטאַבאַל דערמאָנען צו די אַנדערלייינג קסקסנומקסקס.
    ///
    /// דאָס איז זיכער ווייַל די מיוטאַבאַל רעפֿערענץ געראַנטיז אַז קיין אנדערע פֿעדעם זענען קאַנקעראַנטלי אַקסעס די אַטאָמישע דאַטן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // זיכערקייט: די מיוטאַבאַל דערמאָנען געראַנטיז יינציק אָונערשיפּ.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// באַקומען אַטאָמישע אַקסעס צו אַ `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // זיכערקייט: די מיוטאַבאַל דערמאָנען געראַנטיז יינציק אָונערשיפּ, און
        // די אַליינמאַנט פון ביידע `bool` און `Self` איז 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// קאַנסומז די אַטאָמישע און קערט די קאַנטיינד ווערט.
    ///
    /// דאָס איז זיכער ווייַל אַקסעס `self` דורך ווערט געראַנטיז אַז קיין אנדערע פֿעדעם זענען קאַנקעראַנטלי אַקסעס די אַטאָמישע דאַטן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// לאָודז אַ ווערט פון די bool.
    ///
    /// `load` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
    /// מעגלעך וואַלועס זענען קס 01 קס, קס 02 קס און קס 00 קס.
    ///
    /// # Panics
    ///
    /// Panics אויב `order` איז [`Release`] אָדער [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // זיכערקייט: קיין דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס און רוי
        // טייַטל דורכגעגאנגען איז גילטיק ווייַל מיר האָבן עס פֿון אַ רעפֿערענץ.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// סטאָרז אַ ווערט אין די bool.
    ///
    /// `store` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
    /// מעגלעך וואַלועס זענען קס 01 קס, קס 02 קס און קס 00 קס.
    ///
    /// # Panics
    ///
    /// Panics אויב `order` איז [`Acquire`] אָדער [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // זיכערקייט: קיין דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס און רוי
        // טייַטל דורכגעגאנגען איז גילטיק ווייַל מיר האָבן עס פֿון אַ רעפֿערענץ.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// סטאָרז אַ ווערט אין די bool, און צוריקקומען די פריערדיקע ווערט.
    ///
    /// `swap` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
    /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
    ///
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// סטאָרז אַ ווערט אין די [`bool`] אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
    ///
    /// די צוריקקער ווערט איז שטענדיק די פריערדיקע ווערט.אויב עס איז גלייַך צו `current`, די ווערט איז דערהייַנטיקט.
    ///
    /// `compare_and_swap` אויך נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
    /// באמערקט אַז אפילו ווען איר נוצן [`AcqRel`], די אָפּעראַציע קען פאַרלאָזן און דעריבער פּונקט דורכפירן אַן `Acquire` מאַסע, אָבער נישט האָבן `Release` סעמאַנטיקס.
    /// ניצן קס 01 קס מאכט די קראָם טייל פון דעם אָפּעראַציע קס 02 קס אויב עס כאַפּאַנז, און ניצן קס 03 קס מאכט די מאַסע טייל קס 00 קס.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # מייגרייטינג צו קס 01 קס און קס 00 קס
    ///
    /// `compare_and_swap` איז עקוויוואַלענט צו קס 00 קס מיט די פאלגענדע מאַפּינג פֿאַר זכּרון אָרדערס:
    ///
    /// אָריגינעל |הצלחה |דורכפאַל
    /// -------- | ------- | -------
    /// רילאַקסט |רילאַקסט |רילאַקסעד קריגן |קריגן |קריגן מעלדונג |מעלדונג |רילאַקסט אַקקרעל |AcqRel |קריגן SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` איז ערלויבט צו פאַרלאָזן ספּיוריאַסלי אפילו ווען דער פאַרגלייַך סאַקסידז, וואָס אַלאַוז די קאַמפּיילער צו דזשענערייט בעסער פֿאַרזאַמלונג קאָד ווען די פאַרגלייכן און ויסבייַטן איז געניצט אין אַ שלייף.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// סטאָרז אַ ווערט אין די [`bool`] אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
    ///
    /// דער צוריקקער ווערט איז אַ רעזולטאַט וואָס ינדיקייץ צי די נייַע ווערט איז געשריבן און כּולל די פריערדיקע ווערט.
    /// אויף הצלחה דעם ווערט איז געראַנטיד צו זיין גלייַך צו קס 00 קס.
    ///
    /// `compare_exchange` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
    /// `success` באשרייבט די פארלאנגט אָרדערינג פֿאַר די לייענען-מאָדיפיצירן-שרייַבן אָפּעראַציע וואָס קומט אויב די פאַרגלייַך מיט קס 00 קס סאַקסידז.
    /// `failure` באשרייבט די פארלאנגט אָרדערינג פֿאַר די מאַסע אָפּעראַציע וואָס קומט ווען די פאַרגלייַך פיילז.
    /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Relaxed`] איז די הצלחה [`Relaxed`].
    ///
    /// די דורכפאַל אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// סטאָרז אַ ווערט אין די [`bool`] אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
    ///
    /// ניט ענלעך קס 00 קס, די פונקציע איז ערלויבט צו ספּיוזאַסלי פאַרלאָזן אפילו ווען דער פאַרגלייַך סאַקסידאַד, וואָס קענען רעזולטאַט אין מער עפעקטיוו קאָד אויף עטלעכע פּלאַטפאָרמס.
    ///
    /// דער צוריקקער ווערט איז אַ רעזולטאַט וואָס ינדיקייץ צי די נייַע ווערט איז געשריבן און כּולל די פריערדיקע ווערט.
    ///
    /// `compare_exchange_weak` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
    /// `success` באשרייבט די פארלאנגט אָרדערינג פֿאַר די לייענען-מאָדיפיצירן-שרייַבן אָפּעראַציע וואָס קומט אויב די פאַרגלייַך מיט קס 00 קס סאַקסידז.
    /// `failure` באשרייבט די פארלאנגט אָרדערינג פֿאַר די מאַסע אָפּעראַציע וואָס קומט ווען די פאַרגלייַך פיילז.
    /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Relaxed`] איז די הצלחה [`Relaxed`].
    /// די דורכפאַל אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// לאַדזשיקאַל קס 00 קס מיט אַ באָאָלעאַן ווערט.
    ///
    /// פּערפאָרמז אַ לאַדזשיקאַל "and" אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און שטעלן די נייַע ווערט צו דער רעזולטאַט.
    ///
    /// רעטורנס די פריערדיקע ווערט.
    ///
    /// `fetch_and` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
    /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
    ///
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// לאַדזשיקאַל קס 00 קס מיט אַ באָאָלעאַן ווערט.
    ///
    /// פּערפאָרמז אַ לאַדזשיקאַל "nand" אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און שטעלן די נייַע ווערט צו דער רעזולטאַט.
    ///
    /// רעטורנס די פריערדיקע ווערט.
    ///
    /// `fetch_nand` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
    /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
    ///
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // מיר קענען נישט נוצן atomic_nand דאָ ווייַל עס קען רעזולטאַט אין אַ bool מיט אַ פאַרקריפּלט ווערט.
        // דעם כאַפּאַנז ווייַל די אַטאָמישע אָפּעראַציע איז דורכגעקאָכט מיט אַן ינטערנער 8-ביסל ינטאַדזשער, וואָס וואָלט שטעלן די אויבערשטער 7 ביטן.
        //
        // אַזוי מיר נאָר נוצן פעטש_קסאָר אָדער ויסבייַטן אַנשטאָט.
        if val {
            // ! (x&true)== !x מיר מוזן יבערקערן די bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==אמת מיר מוזן שטעלן די bool צו אמת.
            //
            self.swap(true, order)
        }
    }

    /// לאַדזשיקאַל קס 00 קס מיט אַ באָאָלעאַן ווערט.
    ///
    /// פּערפאָרמז אַ לאַדזשיקאַל "or" אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און שטעלן די נייַע ווערט צו דער רעזולטאַט.
    ///
    /// רעטורנס די פריערדיקע ווערט.
    ///
    /// `fetch_or` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
    /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
    ///
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// לאַדזשיקאַל קס 00 קס מיט אַ באָאָלעאַן ווערט.
    ///
    /// פּערפאָרמז אַ לאַדזשיקאַל "xor" אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און שטעלן די נייַע ווערט צו דער רעזולטאַט.
    ///
    /// רעטורנס די פריערדיקע ווערט.
    ///
    /// `fetch_xor` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
    /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
    ///
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// קערט אַ מיוטאַבאַל טייַטל צו די אַנדערלייינג [`bool`].
    ///
    /// טאן ניט-אַטאָמישע לייענט און שרייבט אויף די ריזאַלטינג ינטאַדזשער קענען זיין אַ דאַטן ראַסע.
    /// דער אופֿן איז מערסטנס נוציק פֿאַר FFI, וווּ די פונקציע סיגנאַטורע קען נוצן `*mut bool` אַנשטאָט פון `&AtomicBool`.
    ///
    /// אומקערן אַ קס 00 קס טייַטל פֿון אַ שערד רעפֿערענץ צו דעם אַטאָמישע איז זיכער ווייַל די אַטאָמישע טייפּס אַרבעט מיט ינלענדיש מיוטאַביליטי.
    /// אַלע מאָדיפיקאַטיאָנס פון אַן אַטאָמישע ענדערונג די ווערט דורך אַ שערד רעפֿערענץ און קענען זיין בעשאָלעם אַזוי לאַנג ווי זיי נוצן אַטאָמישע אַפּעריישאַנז.
    /// קיין נוצן פון די אומגעקערט רוי טייַטל ריקווייערז אַן `unsafe` בלאָק און נאָך מוזן האַלטן די זעלבע ריסטריקשאַן: די אָפּעראַציע אויף עס מוזן זיין אַטאָמישע.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// פעטשעס די ווערט, און אַפּלייז אַ פֿונקציע צו עס וואָס קערט אַן אַפּשאַנאַל נייַ ווערט.קערט אַ קס 02 קס פון קס 03 קס אויב די פֿונקציע אומגעקערט קס 01 קס, אַנדערש קס 00 קס.
    ///
    /// Note: דאָס קען רופן די פונקציע קייפל מאָל אויב די ווערט איז געביטן פון אנדערע פֿעדעם אין די דערווייל, ווי לאַנג ווי די פונקציע קערט `Some(_)`, אָבער די פונקציע וועט זיין געווענדט בלויז איין מאָל צו די סטאָרד ווערט.
    ///
    ///
    /// `fetch_update` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
    /// דער ערשטער באשרייבט די פארלאנגט אָרדערינג פֿאַר ווען די אָפּעראַציע לעסאָף סאַקסידאַד בשעת די רגע באשרייבט די פארלאנגט אָרדערינג פֿאַר לאָודז.
    /// די קאָראַספּאַנדז צו די הצלחה און דורכפאַל אָרדערינגז פון [`AtomicBool::compare_exchange`] ריספּעקטיוולי.
    ///
    /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די לעצט מצליח מאַסע [`Relaxed`].
    /// די (failed) מאַסע אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// קרעאַטעס אַ נייַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו די אַנדערלייינג טייַטל.
    ///
    /// דאָס איז זיכער ווייַל די מיוטאַבאַל רעפֿערענץ געראַנטיז אַז קיין אנדערע פֿעדעם זענען קאַנקעראַנטלי אַקסעס די אַטאָמישע דאַטן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// באַקומען אַטאָמישע אַקסעס צו אַ טייַטל.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - די מיוטאַבאַל דערמאָנען געראַנטיז יינציק אָונערשיפּ.
        //  - די אַליינמאַנט פון `*mut T` און `Self` איז די זעלבע אויף אַלע פּלאַטפאָרמס געשטיצט דורך rust, ווי וועראַפייד אויבן.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// קאַנסומז די אַטאָמישע און קערט די קאַנטיינד ווערט.
    ///
    /// דאָס איז זיכער ווייַל אַקסעס `self` דורך ווערט געראַנטיז אַז קיין אנדערע פֿעדעם זענען קאַנקעראַנטלי אַקסעס די אַטאָמישע דאַטן.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// לאָודז אַ ווערט פון די טייַטל.
    ///
    /// `load` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
    /// מעגלעך וואַלועס זענען קס 01 קס, קס 02 קס און קס 00 קס.
    ///
    /// # Panics
    ///
    /// Panics אויב `order` איז [`Release`] אָדער [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// סטאָרז אַ ווערט אין די טייַטל.
    ///
    /// `store` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
    /// מעגלעך וואַלועס זענען קס 01 קס, קס 02 קס און קס 00 קס.
    ///
    /// # Panics
    ///
    /// Panics אויב `order` איז [`Acquire`] אָדער [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// סטאָרז אַ ווערט אין די טייַטל, צוריקקומען די פריערדיקע ווערט.
    ///
    /// `swap` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
    /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
    ///
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף פּוינטערז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// סטאָרז אַ ווערט אין די טייַטל אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
    ///
    /// די צוריקקער ווערט איז שטענדיק די פריערדיקע ווערט.אויב עס איז גלייַך צו `current`, די ווערט איז דערהייַנטיקט.
    ///
    /// `compare_and_swap` אויך נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
    /// באמערקט אַז אפילו ווען איר נוצן [`AcqRel`], די אָפּעראַציע קען פאַרלאָזן און דעריבער פּונקט דורכפירן אַן `Acquire` מאַסע, אָבער נישט האָבן `Release` סעמאַנטיקס.
    /// ניצן קס 01 קס מאכט די קראָם טייל פון דעם אָפּעראַציע קס 02 קס אויב עס כאַפּאַנז, און ניצן קס 03 קס מאכט די מאַסע טייל קס 00 קס.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף פּוינטערז.
    ///
    /// # מייגרייטינג צו קס 01 קס און קס 00 קס
    ///
    /// `compare_and_swap` איז עקוויוואַלענט צו קס 00 קס מיט די פאלגענדע מאַפּינג פֿאַר זכּרון אָרדערס:
    ///
    /// אָריגינעל |הצלחה |דורכפאַל
    /// -------- | ------- | -------
    /// רילאַקסט |רילאַקסט |רילאַקסעד קריגן |קריגן |קריגן מעלדונג |מעלדונג |רילאַקסט אַקקרעל |AcqRel |קריגן SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` איז ערלויבט צו פאַרלאָזן ספּיוריאַסלי אפילו ווען דער פאַרגלייַך סאַקסידז, וואָס אַלאַוז די קאַמפּיילער צו דזשענערייט בעסער פֿאַרזאַמלונג קאָד ווען די פאַרגלייכן און ויסבייַטן איז געניצט אין אַ שלייף.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// סטאָרז אַ ווערט אין די טייַטל אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
    ///
    /// דער צוריקקער ווערט איז אַ רעזולטאַט וואָס ינדיקייץ צי די נייַע ווערט איז געשריבן און כּולל די פריערדיקע ווערט.
    /// אויף הצלחה דעם ווערט איז געראַנטיד צו זיין גלייַך צו קס 00 קס.
    ///
    /// `compare_exchange` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
    /// `success` באשרייבט די פארלאנגט אָרדערינג פֿאַר די לייענען-מאָדיפיצירן-שרייַבן אָפּעראַציע וואָס קומט אויב די פאַרגלייַך מיט קס 00 קס סאַקסידז.
    /// `failure` באשרייבט די פארלאנגט אָרדערינג פֿאַר די מאַסע אָפּעראַציע וואָס קומט ווען די פאַרגלייַך פיילז.
    /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Relaxed`] איז די הצלחה [`Relaxed`].
    ///
    /// די דורכפאַל אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף פּוינטערז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// סטאָרז אַ ווערט אין די טייַטל אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
    ///
    /// ניט ענלעך קס 00 קס, די פונקציע איז ערלויבט צו ספּיוזאַסלי פאַרלאָזן אפילו ווען דער פאַרגלייַך סאַקסידאַד, וואָס קענען רעזולטאַט אין מער עפעקטיוו קאָד אויף עטלעכע פּלאַטפאָרמס.
    ///
    /// דער צוריקקער ווערט איז אַ רעזולטאַט וואָס ינדיקייץ צי די נייַע ווערט איז געשריבן און כּולל די פריערדיקע ווערט.
    ///
    /// `compare_exchange_weak` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
    /// `success` באשרייבט די פארלאנגט אָרדערינג פֿאַר די לייענען-מאָדיפיצירן-שרייַבן אָפּעראַציע וואָס קומט אויב די פאַרגלייַך מיט קס 00 קס סאַקסידז.
    /// `failure` באשרייבט די פארלאנגט אָרדערינג פֿאַר די מאַסע אָפּעראַציע וואָס קומט ווען די פאַרגלייַך פיילז.
    /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Relaxed`] איז די הצלחה [`Relaxed`].
    /// די דורכפאַל אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף פּוינטערז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // זיכערקייט: דעם ינטרינסיק איז אַנסייף ווייַל עס אַפּערייץ אויף אַ רוי טייַטל
        // אָבער מיר וויסן פֿאַר זיכער אַז דער טייַטל איז גילטיק (מיר נאָר האָבן עס פֿון אַן `UnsafeCell` אַז מיר האָבן דורך דערמאָנען) און די אַטאָמישע אָפּעראַציע זיך אַלאַוז אונדז צו בעשאָלעם מיוטייט די `UnsafeCell` אינהאַלט.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// פעטשעס די ווערט, און אַפּלייז אַ פֿונקציע צו עס וואָס קערט אַן אַפּשאַנאַל נייַ ווערט.קערט אַ קס 02 קס פון קס 03 קס אויב די פֿונקציע אומגעקערט קס 01 קס, אַנדערש קס 00 קס.
    ///
    /// Note: דאָס קען רופן די פונקציע קייפל מאָל אויב די ווערט איז געביטן פון אנדערע פֿעדעם אין די דערווייל, ווי לאַנג ווי די פונקציע קערט `Some(_)`, אָבער די פונקציע וועט זיין געווענדט בלויז איין מאָל צו די סטאָרד ווערט.
    ///
    ///
    /// `fetch_update` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
    /// דער ערשטער באשרייבט די פארלאנגט אָרדערינג פֿאַר ווען די אָפּעראַציע לעסאָף סאַקסידאַד בשעת די רגע באשרייבט די פארלאנגט אָרדערינג פֿאַר לאָודז.
    /// די קאָראַספּאַנדז צו די הצלחה און דורכפאַל אָרדערינגז פון [`AtomicPtr::compare_exchange`] ריספּעקטיוולי.
    ///
    /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די לעצט מצליח מאַסע [`Relaxed`].
    /// די (failed) מאַסע אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
    ///
    /// **Note:** דער אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף פּוינטערז.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// קאָנווערט אַ קס 01 קס אין אַ קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // דער מאַקראָו איז ענדלעך צו זיין אַניוזד אין עטלעכע אַרקאַטעקטשערז.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// א ינטאַדזשער טיפּ וואָס קענען זיין בעשאָלעם שערד צווישן פֿעדעם.
        ///
        /// דער טיפּ איז דער זעלביקער אין-זכּרון פאַרטרעטונג ווי די אַנדערלייינג ינטאַדזשער טיפּ, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// פֿאַר מער וועגן די דיפעראַנסיז צווישן אַטאָמישע טייפּס און ניט-אַטאָמישע טייפּס און אינפֿאָרמאַציע וועגן די טראַנספּאָרטאַביליטי פון דעם טיפּ, ביטע זען די [module-level documentation].
        ///
        ///
        /// **Note:** דער טיפּ איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע לאָודז און סטאָרז פון [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// אַן אַטאָמישע ינטאַדזשער יניטיאַליזעד צו קס 00 קס.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // שיקן איז ימפּליסאַטלי ימפּלאַמענאַד.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// קרעאַטעס אַ נייַ אַטאָמישע ינטאַדזשער.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו די אַנדערלייינג ינטאַדזשער.
            ///
            /// דאָס איז זיכער ווייַל די מיוטאַבאַל רעפֿערענץ געראַנטיז אַז קיין אנדערע פֿעדעם זענען קאַנקעראַנטלי אַקסעס די אַטאָמישע דאַטן.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// לאָזן מוט סאָמע_ינט=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// אַססערט_עק! (עטלעכע_ינט, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - די מיוטאַבאַל דערמאָנען געראַנטיז יינציק אָונערשיפּ.
                //  - די אַליינמאַנט פון קס 00 קס און קס 01 קס איז דער זעלביקער, ווי צוגעזאגט דורך קס 02 קס און וועראַפייד אויבן.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// קאַנסומז די אַטאָמישע און קערט די קאַנטיינד ווערט.
            ///
            /// דאָס איז זיכער ווייַל אַקסעס `self` דורך ווערט געראַנטיז אַז קיין אנדערע פֿעדעם זענען קאַנקעראַנטלי אַקסעס די אַטאָמישע דאַטן.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// לאָודז אַ ווערט פון די אַטאָמישע גאַנץ נומער.
            ///
            /// `load` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
            /// מעגלעך וואַלועס זענען קס 01 קס, קס 02 קס און קס 00 קס.
            ///
            /// # Panics
            ///
            /// Panics אויב `order` איז [`Release`] אָדער [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// סטאָרז אַ ווערט אין די אַטאָמישע גאַנץ נומער.
            ///
            /// `store` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
            ///  מעגלעך וואַלועס זענען קס 01 קס, קס 02 קס און קס 00 קס.
            ///
            /// # Panics
            ///
            /// Panics אויב `order` איז [`Acquire`] אָדער [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// סטאָרז אַ ווערט אין די אַטאָמישע ינטאַדזשער, ריטערנינג די פריערדיקע ווערט.
            ///
            /// `swap` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// סטאָרז אַ ווערט אין די אַטאָמישע גאַנץ נומער אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
            ///
            /// די צוריקקער ווערט איז שטענדיק די פריערדיקע ווערט.אויב עס איז גלייַך צו `current`, די ווערט איז דערהייַנטיקט.
            ///
            /// `compare_and_swap` אויך נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.
            /// באמערקט אַז אפילו ווען איר נוצן [`AcqRel`], די אָפּעראַציע קען פאַרלאָזן און דעריבער פּונקט דורכפירן אַן `Acquire` מאַסע, אָבער נישט האָבן `Release` סעמאַנטיקס.
            ///
            /// ניצן קס 01 קס מאכט די קראָם טייל פון דעם אָפּעראַציע קס 02 קס אויב עס כאַפּאַנז, און ניצן קס 03 קס מאכט די מאַסע טייל קס 00 קס.
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # מייגרייטינג צו קס 01 קס און קס 00 קס
            ///
            /// `compare_and_swap` איז עקוויוואַלענט צו קס 00 קס מיט די פאלגענדע מאַפּינג פֿאַר זכּרון אָרדערס:
            ///
            /// אָריגינעל |הצלחה |דורכפאַל
            /// -------- | ------- | -------
            /// רילאַקסט |רילאַקסט |רילאַקסעד קריגן |קריגן |קריגן מעלדונג |מעלדונג |רילאַקסט אַקקרעל |AcqRel |קריגן SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` איז ערלויבט צו פאַרלאָזן ספּיוריאַסלי אפילו ווען דער פאַרגלייַך סאַקסידז, וואָס אַלאַוז די קאַמפּיילער צו דזשענערייט בעסער פֿאַרזאַמלונג קאָד ווען די פאַרגלייכן און ויסבייַטן איז געניצט אין אַ שלייף.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// סטאָרז אַ ווערט אין די אַטאָמישע גאַנץ נומער אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
            ///
            /// דער צוריקקער ווערט איז אַ רעזולטאַט וואָס ינדיקייץ צי די נייַע ווערט איז געשריבן און כּולל די פריערדיקע ווערט.
            /// אויף הצלחה דעם ווערט איז געראַנטיד צו זיין גלייַך צו קס 00 קס.
            ///
            /// `compare_exchange` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
            /// `success` באשרייבט די פארלאנגט אָרדערינג פֿאַר די לייענען-מאָדיפיצירן-שרייַבן אָפּעראַציע וואָס קומט אויב די פאַרגלייַך מיט קס 00 קס סאַקסידז.
            /// `failure` באשרייבט די פארלאנגט אָרדערינג פֿאַר די מאַסע אָפּעראַציע וואָס קומט ווען די פאַרגלייַך פיילז.
            /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Relaxed`] איז די הצלחה [`Relaxed`].
            ///
            /// די דורכפאַל אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// סטאָרז אַ ווערט אין די אַטאָמישע גאַנץ נומער אויב די קראַנט ווערט איז די זעלבע ווי די `current` ווערט.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// דער פונקציע איז ערלויבט צו ספּיוזאַסלי פאַרלאָזן אפילו ווען דער פאַרגלייַך סאַקסידז, וואָס קענען רעזולטאַט אין מער עפעקטיוו קאָד אויף עטלעכע פּלאַטפאָרמס.
            /// דער צוריקקער ווערט איז אַ רעזולטאַט וואָס ינדיקייץ צי די נייַע ווערט איז געשריבן און כּולל די פריערדיקע ווערט.
            ///
            /// `compare_exchange_weak` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
            /// `success` באשרייבט די פארלאנגט אָרדערינג פֿאַר די לייענען-מאָדיפיצירן-שרייַבן אָפּעראַציע וואָס קומט אויב די פאַרגלייַך מיט קס 00 קס סאַקסידז.
            /// `failure` באשרייבט די פארלאנגט אָרדערינג פֿאַר די מאַסע אָפּעראַציע וואָס קומט ווען די פאַרגלייַך פיילז.
            /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Relaxed`] איז די הצלחה [`Relaxed`].
            ///
            /// די דורכפאַל אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// לאָזן מוט אַלט=קס 00 קס;
            /// שלייף {לאָזן נייַ=אַלט * 2;
            ///     גלייַכן קס 01 קס קס 02 קס}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// לייגט צו די קראַנט ווערט, צוריקקומען די פריערדיקע ווערט.
            ///
            /// די אָפּעראַציע ראַפּט אַרום אויף לויפן.
            ///
            /// `fetch_add` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// סאַבטראַקץ פון די קראַנט ווערט, צוריקקומען די פריערדיקע ווערט.
            ///
            /// די אָפּעראַציע ראַפּט אַרום אויף לויפן.
            ///
            /// `fetch_sub` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// ביטוויסע קס 00 קס מיט די קראַנט ווערט.
            ///
            /// דורכפירן אַ ביטווייז קס 01 קס אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און באַשטעטיקט די נייַע ווערט צו דער רעזולטאַט.
            ///
            /// רעטורנס די פריערדיקע ווערט.
            ///
            /// `fetch_and` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// ביטוויסע קס 00 קס מיט די קראַנט ווערט.
            ///
            /// דורכפירן אַ ביטווייז קס 01 קס אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און באַשטעטיקט די נייַע ווערט צו דער רעזולטאַט.
            ///
            /// רעטורנס די פריערדיקע ווערט.
            ///
            /// `fetch_nand` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (קס 00 קס&קס 01 קס));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// ביטוויסע קס 00 קס מיט די קראַנט ווערט.
            ///
            /// דורכפירן אַ ביטווייז קס 01 קס אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און באַשטעטיקט די נייַע ווערט צו דער רעזולטאַט.
            ///
            /// רעטורנס די פריערדיקע ווערט.
            ///
            /// `fetch_or` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// ביטוויסע קס 00 קס מיט די קראַנט ווערט.
            ///
            /// דורכפירן אַ ביטווייז קס 01 קס אָפּעראַציע אויף דעם קראַנט ווערט און די אַרגומענט קס 00 קס, און באַשטעטיקט די נייַע ווערט צו דער רעזולטאַט.
            ///
            /// רעטורנס די פריערדיקע ווערט.
            ///
            /// `fetch_xor` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// פעטשעס די ווערט, און אַפּלייז אַ פֿונקציע צו עס וואָס קערט אַן אַפּשאַנאַל נייַ ווערט.קערט אַ קס 02 קס פון קס 03 קס אויב די פֿונקציע אומגעקערט קס 01 קס, אַנדערש קס 00 קס.
            ///
            /// Note: דאָס קען רופן די פונקציע קייפל מאָל אויב די ווערט איז געביטן פון אנדערע פֿעדעם אין די דערווייל, ווי לאַנג ווי די פונקציע קערט `Some(_)`, אָבער די פונקציע וועט זיין געווענדט בלויז איין מאָל צו די סטאָרד ווערט.
            ///
            ///
            /// `fetch_update` נעמט צוויי קס 00 קס אַרגומענטן צו באַשרייבן דעם זכּרון אָרדערינג פון דעם אָפּעראַציע.
            /// דער ערשטער באשרייבט די פארלאנגט אָרדערינג פֿאַר ווען די אָפּעראַציע לעסאָף סאַקסידיד בשעת די רגע באשרייבט די פארלאנגט אָרדערינג פֿאַר לאָודז.די קאָראַספּאַנדז צו די אָרדערז פון הצלחה און דורכפאַל
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// ניצן [`Acquire`] ווי אָרדערינג הצלחה, די קראָם איז טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די לעצט מצליח מאַסע [`Relaxed`].
            /// די (failed) מאַסע אָרדערינג קען זיין בלויז [`SeqCst`], [`Acquire`] אָדער [`Relaxed`] און מוזן זיין עקוויוואַלענט צו אָדער שוואַך ווי די הצלחה אָרדערינג.
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (אָרדערינג: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (אָרדערינג: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// מאַקסימום מיט דעם קראַנט ווערט.
            ///
            /// געפֿינען די מאַקסימום פון די קראַנט ווערט און די אַרגומענט קקסנומקסקס, און שטעלן די נייַע ווערט צו די רעזולטאַט.
            ///
            /// רעטורנס די פריערדיקע ווערט.
            ///
            /// `fetch_max` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// לאָזן באַר=42;
            /// לאָזן max_foo=foo.fetch_max (באַר, Ordering::SeqCst).max(bar);
            /// באַשטעטיקן! (מאַקס_פאָאָ==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// מינימום מיט דעם קראַנט ווערט.
            ///
            /// געפֿינען די מינימום פון די קראַנט ווערט און די אַרגומענט `val`, און באַשטעטיקט די נייַע ווערט צו דער רעזולטאַט.
            ///
            /// רעטורנס די פריערדיקע ווערט.
            ///
            /// `fetch_min` נעמט אַן [`Ordering`] אַרגומענט וואָס באשרייבט די זכּרון אָרדערינג פון די אָפּעראַציע.כל אָרדערינג מאָדעס זענען מעגלעך.
            /// באַמערקונג אַז ניצן [`Acquire`] מאַכן די קראָם טייל פון די אָפּעראַציע [`Relaxed`], און ניצן [`Release`] מאכט די מאַסע טייל [`Relaxed`].
            ///
            ///
            /// **באַמערקונג**: דעם אופֿן איז בלויז בנימצא אויף פּלאַטפאָרמס וואָס שטיצן אַטאָמישע אַפּעריישאַנז אויף
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// לאָזן באַר=12;
            /// לאָזן min_foo=foo.fetch_min (באַר, Ordering::SeqCst).min(bar);
            /// אַססערט_עק! (מינ_פאָ, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // זיכערקייט: דאַטן ראַסעס זענען פּריווענטיד דורך אַטאָמישע ינטרינסיקס.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// רעטורנס אַ מיוטאַבאַל טייַטל צו די אַנדערלייינג ינטאַדזשער.
            ///
            /// טאן ניט-אַטאָמישע לייענט און שרייבט אויף די ריזאַלטינג ינטאַדזשער קענען זיין אַ דאַטן ראַסע.
            /// דער אופֿן איז מערסטנס נוציק פֿאַר FFI, וווּ די פונקציע סיגנאַטורע קען נוצן
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// אומקערן אַ קס 00 קס טייַטל פֿון אַ שערד רעפֿערענץ צו דעם אַטאָמישע איז זיכער ווייַל די אַטאָמישע טייפּס אַרבעט מיט ינלענדיש מיוטאַביליטי.
            /// אַלע מאָדיפיקאַטיאָנס פון אַן אַטאָמישע ענדערונג די ווערט דורך אַ שערד רעפֿערענץ און קענען זיין בעשאָלעם אַזוי לאַנג ווי זיי נוצן אַטאָמישע אַפּעריישאַנז.
            /// קיין נוצן פון די אומגעקערט רוי טייַטל ריקווייערז אַן `unsafe` בלאָק און נאָך מוזן האַלטן די זעלבע ריסטריקשאַן: די אָפּעראַציע אויף עס מוזן זיין אַטאָמישע.
            ///
            ///
            /// # Examples
            ///
            /// "איגנאָרירן (extern-declaration)
            ///
            /// # פֿון main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // זיכערקייט: זיכער ווי לאַנג ווי `my_atomic_op` איז אַטאָמישע.
            /// אומזיכער {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// רעטורנס די פריערדיקע ווערט (ווי __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// רעטורנס די פריערדיקע ווערט (ווי __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// קערט די מאַקס ווערט (געחתמעט פאַרגלייַך)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// קערט די מין ווערט (געחתמעט פאַרגלייַך)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// קערט די מאַקס ווערט (ונסיגנעד פאַרגלייַך)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// רעטורנס די מינימום ווערט (אַנסיינד פאַרגלייַך)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// אַן אַטאָמישע פּלויט.
///
/// דעפּענדינג אויף די ספּעסאַפייד סדר, אַ פּלויט פּריווענץ די קאַמפּיילער און קפּו צו ריאָרדז עטלעכע טייפּס פון זכּרון אַפּעריישאַנז אַרום אים.
/// אַז קריייץ סינגקראַנייזיז מיט שייכות צווישן עס און אַטאָמישע אַפּעריישאַנז אָדער פענסעס אין אנדערע פֿעדעם.
///
/// א פּלויט 'A' וואָס האט (בייַ מינדסטער) [`Release`] אָרדערינג סעמאַנטיקס, סינגקראַנייזיז מיט אַ פּלויט 'B' מיט (לפּחות) [`Acquire`] סעמאַנטיקס, אויב און נאָר אויב עס עקסיסטירן אָפּעראַטיאָנס X און Y, ביידע אַפּערייטינג אויף עטלעכע אַטאָמישע כייפעץ 'M' אַזוי אַז A איז סיקוואַנסיד איידער X, Y איז סינגקראַנייזד איידער B און Y באמערקט די ענדערונג צו M.
/// דעם גיט אַ כאַפּאַנז איידער אָפענגיקייַט צווישן א און בי.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// אַטאָמישע אָפּעראַטיאָנס מיט [`Release`] אָדער [`Acquire`] סעמאַנטיקס קענען אויך סינגקראַנייז מיט אַ פּלויט.
///
/// א פּלויט מיט [`SeqCst`] אָרדערינג, אין אַדישאַן צו האָבן סיי [`Acquire`] און [`Release`] סעמאַנטיקס, איז פּאַרטיסאַפּייץ אין די גלאבאלע פּראָגראַם סדר פון די אנדערע [`SeqCst`] אַפּעריישאַנז און/אָדער פענסעס.
///
/// אַקסעפּץ אָרדערינגז [`Acquire`], [`Release`], [`AcqRel`] און [`SeqCst`].
///
/// # Panics
///
/// Panics אויב קס 01 קס איז קס 00 קס.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // אַ קעגנצייַטיק ויסשליסיק פּרימיטיוו באזירט אויף ספּינלאָקק.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // וואַרטן ביז די אַלט ווערט איז קס 00 קס.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // דעם פּלויט סינגקראַנייזיז מיט `unlock` קראָם.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // זיכערקייט: ניצן אַ אַטאָמישע פּלויט איז זיכער.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// א קאַמפּיילער זכּרון פּלויט.
///
/// `compiler_fence` טוט נישט אַרויסלאָזן קיין מאַשין קאָד, אָבער ריסטריקץ די מינים פון זכּרון אַז די קאַמפּיילער קענען זיין רי-אָרדערינג.אין באַזונדער, די קאַמפּיילער, דיפּענדינג אויף די געגעבן קס 01 קס סעמאַנטיקס, קען זיין דיסלאָודיד פון מאָווינג לייענט אָדער שרייבט פון איידער אָדער נאָך די רופן צו די אנדערע זייַט פון די רופן צו קס 00 קס.באַמערקונג אַז עס **קען נישט פאַרמייַדן די* ייַזנוואַרג * צו מאַכן אַזאַ שייַעך-אָרדערינג.
///
/// דאָס איז נישט אַ פּראָבלעם אין אַ איין-טרעדיד דורכפירונג קאָנטעקסט, אָבער ווען אנדערע פֿעדעם קענען מאָדיפיצירן זכּרון אין דער זעלביקער צייט, עס איז פארלאנגט צו שטארקער סינגקראַנאַזיישאַן פּרימיטיווז אַזאַ ווי [`fence`].
///
/// די אָרדערינג אָרדערינג פּריווענטיד דורך די פאַרשידענע אָרדערס סעמאַנטיקס זענען:
///
///  - מיט קס 00 קס, קיין ריאָרדוינג פון לייענט און שרייבט איבער דעם פונט איז ערלויבט.
///  - מיט [`Release`], פּריסידינג לייענט און שרייבן קענען ניט זיין אריבערגעפארן נאָך סאַבסאַקוואַנט שרייבן.
///  - מיט קס 00 קס, סאַבסאַקוואַנט לייענט און שרייבט קענען ניט זיין אריבערגעפארן פאָרויס פון פּריסידינג לייענט.
///  - מיט קס 00 קס, ביידע פון די אויבן כּללים זענען ענפאָרסט.
///
/// `compiler_fence` איז בכלל בלויז נוציק פֿאַר פּרעווענטינג אַ פאָדעם פון ראַסינג *מיט זיך*.דאָס איז, אויב אַ געגעבן פאָדעם איז עקסאַקיוטינג איין שטיק פון קאָד, און איז ינטעראַפּטיד, און סטאַרץ עקסאַקיוטינג קאָד אַנדערש ווו (בשעת נאָך אין דער זעלביקער פאָדעם, און קאַנסעפּטשואַלי נאָך אויף דער זעלביקער האַרץ).אין טראדיציאנעלן מגילה, דאָס קען נאָר פּאַסירן ווען אַ סיגנאַל האַנדלער איז רעגיסטרירט.
/// אין מער נידעריק-קאָד קאָד, אַזאַ סיטואַטיאָנס קענען אויך שטיי אויף ווען האַנדלינג ינטעראַפּץ, ווען ימפּלאַמענינג גרין פֿעדעם מיט פּרעעמפּטיאָן, אאז"ו ו.
/// טשיקאַווע לייענער זענען ינקעראַדזשד צו לייענען די Linux קערנעל 'ס דיסקוסיע פון [memory barriers].
///
/// # Panics
///
/// Panics אויב קס 01 קס איז קס 00 קס.
///
/// # Examples
///
/// אָן `compiler_fence`, די `assert_eq!` אין די פאלגענדע קאָד איז נישט געראַנטיד צו זיין געראָטן, טראָץ אַלץ וואָס פּאַסירן אין אַ איין פאָדעם.
/// צו זען וואָס, געדענקען אַז דער קאַמפּיילער איז פריי צו ויסבייַטן די סטאָרז צו קס 03 קס און קס 04 קס זינט זיי זענען ביידע קס 01 קס.אויב דאָס איז, און די סיגנאַל האַנדלער איז ינוואָוקאַד רעכט נאָך די דערהייַנטיקן פון קס 05 קס, דער סיגנאַל האַנדלער וועט זען קס 02 קס, אָבער קס 00 קס.
/// ניצן אַ `compiler_fence` רעמאַדיז דעם סיטואַציע.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // פאַרמייַדן פריער שרייבט צו זיין אריבערגעפארן ווייַטער פון דעם פונט
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // זיכערקייט: ניצן אַ אַטאָמישע פּלויט איז זיכער.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// סיגנאַלס דער פּראַסעסער אַז עס איז ין אַ פאַרנומען-וואַרטן ומדריי-שלייף ("ומדריי שלאָס").
///
/// די פֿונקציע איז דעפּרעסאַטעד לטובת [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}