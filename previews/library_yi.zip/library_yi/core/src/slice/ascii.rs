//! אָפּעראַטיאָנס אויף ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// טשעקס אויב אַלע ביטעס אין דעם רעפטל זענען אין די ASCII קייט.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// טשעקס אַז צוויי סלייסיז זענען אַן ASCII פאַל-ינסענסיטיוו גלייַכן.
    ///
    /// די זעלבע ווי `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, אָבער אָן אַלאַקייטינג און קאַפּיינג טעמפּערעריז.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// קאַנווערץ דעם רעפטל צו זיין ASCII אויבערשטער פאַל עקוויוואַלענט אין-אָרט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`to_ascii_uppercase`] צו צוריקקריגן אַ נייַע אויבערשטער ווערט אָן מאַדאַפייינג די יגזיסטינג.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// קאַנווערץ דעם רעפטל צו זיין ASCII עקוויוואַלענט אין קליין אָרט.
    ///
    /// ASCII אותיות קס 01 קס צו קס 02 קס זענען מאַפּט צו קס 03 קס צו קס 00 קס, אָבער ניט-אַסקי אותיות זענען אַנטשיינדזשד.
    ///
    /// ניצן [`to_ascii_lowercase`] צו צוריקקריגן אַ נייַע ווערט מיט נידעריק נידעריקער קאַסעס אָן מאַדאַפאַקיישאַן.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// קערט `true` אויב קיין ביטע אין די וואָרט `true` איז nonascii (>=128).
/// סנאַרפעד פֿון קס 00 קס, וואָס טוט עפּעס ענלעך פֿאַר קס 01 קס וואַלאַדיישאַן.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// אָפּטימיזעד ASCII פּרובירן וואָס וועט נוצן וסיזע-אין-אַ-צייט אַפּעריישאַנז אַנשטאָט פון בייט-אין-אַ-צייט אַפּעריישאַנז (ווען מעגלעך).
///
/// די אַלגערידאַם מיר נוצן דאָ איז שיין פּשוט.אויב `s` איז צו קורץ, מיר נאָר קאָנטראָלירן יעדער בייט און זיין געטאן מיט אים.אַנדערש:
///
/// - לייענען די ערשטער וואָרט מיט אַנאַליינד מאַסע.
/// - אַליינ די טייַטל, לייענען סאַבסאַקוואַנט ווערטער ביז די סוף מיט אַליינד לאָודז.
/// - לייענען די לעצטע `usize` פֿון `s` מיט אַנאַליינד מאַסע.
///
/// אויב איינער פון די לאָודז פּראָדוצירן עפּעס פֿאַר וואָס `contains_nonascii` (above) קערט אמת, מיר וויסן אַז די ענטפער איז פאַלש.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // אויב מיר טאָן ניט געווינען עפּעס פון די וואָרט-אין-אַ-צייט ימפּלאַמענטיישאַן, פאַלן צוריק צו אַ סקאַלאַר שלייף.
    //
    // מיר טאָן דאָס אויך פֿאַר אַרקאַטעקטשערז ווו קס 01 קס איז ניט גענוגיק אַליינמאַנט פֿאַר קס 00 קס, ווייַל דאָס איז אַ טשודנע ז 0 עדגע 0 ז פאַל.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // מיר שטענדיק לייענען די ערשטער וואָרט אַנאַליינד, וואָס מיטל `align_offset` איז
    // 0, מיר'ד לייענען די זעלבע ווערט ווידער פֿאַר די אַליינד לייענען.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // זיכערקייט: מיר באַשטעטיקן `len < USIZE_SIZE` אויבן.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // מיר אָפּגעשטעלט דעם אויבן, עפּעס ימפּליסאַטלי.
    // באַמערקונג אַז קס 01 קס איז אָדער קס 02 קס אָדער קס 00 קס, ביידע זענען בישליימעס אָפּגעשטעלט אויבן.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFEETY: word_ptr איז די (רעכט אַליינד) וסייז פּטר וואָס מיר נוצן צו לייענען די
    // מיטל פּייַדע פון די רעפטל.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` איז די בייט אינדעקס פון קס 00 קס, געוויינט פֿאַר שלייף טשעקס.
    let mut byte_pos = offset_to_aligned;

    // פּאַראַנאָיאַ טשעק וועגן אַליינמאַנט, ווייַל מיר וועלן צו דורכפירן אַ בינטל אַנאַליינד לאָודז.
    // אין פיר, דאָס זאָל זיין אוממעגלעך צו ויסשליסן אַ זשוק אין `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // לייענען סאַבסאַקוואַנט ווערטער ביז די לעצטע אַליינד וואָרט, עקסקלודינג די לעצטע אַליינד וואָרט זיך צו זיין דורכגעקאָכט אין עק קאָנטראָל שפּעטער, צו ענשור אַז עק איז שטענדיק איין `usize` בייַ רובֿ צו עקסטרע branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // מייושעוודיקייט קאָנטראָל אַז די לייענען איז אין גווול
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // און אַז אונדזער אַסאַמפּשאַנז וועגן קס 00 קס האַלטן.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // זיכערקייט: מיר וויסן `word_ptr` איז רעכט אַליינד (ווייַל פון
        // 'align_offset'), און מיר וויסן אַז מיר האָבן גענוג ביטעס צווישן `word_ptr` און די סוף
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // זיכערקייט: מיר וויסן אַז `byte_pos <= len - USIZE_SIZE`, וואָס מיטל אַז
        // נאָך דעם `add`, `word_ptr` וועט זיין רובֿ-פאַרגאַנגענהייט-דעם-סוף.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // סאַניטי טשעק צו ענשור אַז עס טאַקע איז בלויז איין `usize` לינקס.
    // דאָס זאָל זיין געראַנטיד דורך אונדזער שלייף צושטאַנד.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // זיכערקייט: דאָס רילייז אויף `len >= USIZE_SIZE`, וואָס מיר קאָנטראָלירן אין די אָנהייב.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}