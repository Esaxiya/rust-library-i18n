// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ראָוטייץ די קייט X00 קס אַזוי אַז די `mid` עלעמענט איז דער ערשטער עלעמענט.עקוויוואַלענטלי, ראָוטייץ די קייט קס 02 קס עלעמענטן צו די לינקס אָדער קס 03 קס עלעמענטן צו די רעכט.
///
/// # Safety
///
/// די ספּעציפֿיש קייט זאָל זיין גילטיק פֿאַר לייענען און שרייבן.
///
/// # Algorithm
///
/// אַלגערידאַם 1 איז געניצט פֿאַר קליין וואַלועס פון קס 01 קס אָדער פֿאַר גרויס קס 00 קס.
/// די עלעמענטן זענען אריבערגעפארן אין זייער לעצט שטעלעס יעדער אין אַ צייַט סטאַרטינג בייַ קס 01 קס און אַדוואַנסינג דורך קס 02 קס טריט מאָדולאָ קס 00 קס, אַזוי אַז בלויז איין צייַטווייַליק איז דארף.
/// יווענטשאַוואַלי מיר קומען צוריק צו `mid - left`.
/// אָבער, אויב `gcd(left + right, right)` איז נישט 1, די אויבן טריט סקיפּט איבער עלעמענטן.
/// צום ביישפיל:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// צומ גליק, די נומער פון סקיפּט איבער עלעמענטן צווישן פיינאַלייזד עלעמענטן איז שטענדיק גלייַך, אַזוי מיר קענען פּונקט אָפסעט אונדזער סטאַרטינג שטעלע און טאָן מער ראָונדס (די גאַנץ נומער פון ראָונדס איז די `gcd(left + right, right)` value).
///
/// דער סוף רעזולטאַט איז אַז אַלע עלעמענטן זענען פיינאַלייזד אַמאָל און בלויז אַמאָל.
///
/// אַלגערידאַם 2 איז געניצט אויב `left + right` איז גרויס אָבער `min(left, right)` איז קליין גענוג צו פּאַסיק אויף אַ אָנלייגן באַפער.
/// די `min(left, right)` עלעמענטן זענען קאַפּיד אויף די באַפער, `memmove` איז געווענדט צו די אנדערע, און די אָנעס אויף די באַפער זענען אריבערגעפארן צוריק אין די לאָך אויף די פאַרקערט זייַט פון די אָרט.
///
/// אַלגערידאַמז וואָס קענען זיין וועקטאָריזעד אַוטפּערפאָרם די אויבן אויב `left + right` ווערט גענוג גרויס.
/// אַלגערידאַם 1 קענען זיין וועקטאָריזעד דורך טשאַנגקינג און פּערפאָרמינג פילע ראָונדס אין אַמאָל, אָבער עס זענען אויך ווייניק ראָונדס אין דורכשניטלעך ביז `left + right` איז ריזיק, און די ערגסט פאַל פון איין ראָונד איז שטענדיק דאָרט.
/// אַנשטאָט, אַלגערידאַם 3 ניצט ריפּיטיד סוואַפּינג פון קס 00 קס עלעמענטן ביז אַ קלענערער דרייען פּראָבלעם איז לינקס.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// ווען קס 00 קס די סוואַפּינג כאַפּאַנז פֿון די לינקס אַנשטאָט.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. די אונטן אַלגערידאַמז קענען פאַרלאָזן אויב די קאַסעס זענען נישט אָפּגעשטעלט
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // אַלגערידאַם 1 מיקראָבענטשמאַרקס אָנווייַזן אַז די דורכשניטלעך פאָרשטעלונג פֿאַר טראַפ שיפץ איז בעסער אַלע די וועג ביז וועגן קס X קס, אָבער די ערגסט פאַל פאָרשטעלונג ברייקס אפילו אַרום 16.
            // 24 איז אויסדערוויילט ווי מיטל ערד.
            // אויב די גרייס פון `T` איז גרעסער ווי 4 `usize`s, די אַלגערידאַם אויך יקסיד אנדערע אַלגערידאַמז.
            //
            //
            let x = unsafe { mid.sub(left) };
            // אָנהייב פון ערשטער קייַלעכיק
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` קענען זיין געפֿונען איידער האַנט דורך `gcd(left + right, right)` קאַלקיאַלייטינג, אָבער עס איז פאַסטער צו מאַכן איין שלייף וואָס קאַלקיאַלייץ די גקד ווי אַ זייַט ווירקונג און דאַן די מנוחה פון דעם פּייַדע
            //
            //
            let mut gcd = right;
            // בענטשמאַרקס אַנטדעקן אַז עס איז פאַסטער צו ויסבייַטן טעמפּאָראַריעס אַלע די וועג אַנשטאָט פון לייענען איין צייַטווייַליק אַמאָל, קאַפּיינג קאַפּויער און דאַן שרייבן דעם צייַטווייַליק אין די סוף.
            // דאָס קען זיין רעכט צו דעם פאַקט אַז סוואַפּינג אָדער ריפּלייסינג טעמפּערעראַלי ניצט בלויז איין זכּרון אַדרעס אין די שלייף אַנשטאָט פון דאַרפֿן צו פירן צוויי.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // אַנשטאָט פון ינקראַמענטינג קס 00 קס און טשעק אויב עס איז אַרויס די גווול, מיר קאָנטראָלירן צי קס 01 קס וועט גיין אַרויס די גווול ביי דער ווייַטער ינקראַמאַנט.
                // דעם פּריווענץ קיין ראַפּינג פון פּוינטערז אָדער `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // סוף פון דער ערשטער קייַלעכיק
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // די קאַנדישאַנאַל מוזן זיין דאָ אויב `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ענדיקן דעם פּייַדע מיט מער ראָונדס
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` איז ניט אַ נול-סייזד טיפּ, אַזוי עס איז גוט צו טיילן דורך די גרייס.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // אַלגערידאַם 2 די `[T; 0]` דאָ איז צו ענשור אַז דאָס איז אַפּראָופּרייטלי אַליינד פֿאַר ט
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // אַלגאָריטהם 3 עס איז אַן אָלטערנאַטיוו וועג פון סוואַפּינג אַז ינוואַלווז דערגייונג ווו די לעצטע ויסבייַטן פון דעם אַלגערידאַם וואָלט זיין, און סוואַפּינג מיט די לעצטע פּייַדע אַנשטאָט פון סוואַפּינג שכייניש טשאַנגקס ווי די אַלגערידאַם איז טאן, אָבער דעם וועג איז נאָך פאַסטער.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // אַלגערידאַם 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}