//! מאַקראָס געניצט דורך יטעראַטאָרס פון רעפטל.

// ינליינינג יס_עמפּטי און לען מאכט אַ ריזיק פאָרשטעלונג חילוק
macro_rules! is_empty {
    // די וועג ווי מיר קאָד די לענג פון אַ ZST יטעראַטאָר, דאָס אַרבעט ביידע פֿאַר ZST און ניט-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// צו באַקומען באַפרייַען פון עטלעכע גווול טשעקס (זען קס 00 קס), מיר רעכענען די לענג אין אַ ביסל אומגעריכט וועג.
// (טעסטעד דורך `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // מיר ווערן מאל געניצט אין אַ אַנסייף בלאָק

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // דעם קס 00 קס נוצן קס 01 קס ווייַל מיר אָפענגען אויף ראַפּינג צו רעפּראַזענץ די לענג פון לאַנג זסט רעפטל יטעראַטאָרס.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // מיר וויסן אַז קס 00 קס, אַזוי קענען טאָן בעסער ווי קס 01 קס, וואָס דאַרף צו האַנדלען אין געחתמעט.
            // דורך באַשטעטיקן צונעמען פלאַגס דאָ, מיר קענען זאָגן LLVM דאָס, וואָס העלפּס עס צו באַזייַטיקן גווול טשעקס.
            // זיכערקייט: לויט די טיפּ ינוועראַנט, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // דורך אויך זאָגן LLVM אַז די פּוינטערז זענען באַזונדער דורך אַ פּינטלעך קייפל פון די טיפּ גרייס, עס קענען אַפּטאַמייז `len() == 0` אַראָפּ צו `start == end` אַנשטאָט פון `(end - start) < size`.
            //
            // זיכערקייט: לויט די טיפּ ינוועראַנט, די פּוינטערז זענען אַליינד אַזוי די
            //         די ווייַטקייט צווישן זיי מוזן זיין אַ קייפל פון פּאָינטעע גרייס
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// די שערד דעפֿיניציע פון די `Iter` און `IterMut` יטעראַטאָרס
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // קערט דער ערשטער עלעמענט און מאָווינג די אָנהייב פון יטעראַטאָר פאָרויס 1.
        // ימפּרוווז זייער פאָרשטעלונג קאַמפּערד מיט אַן ינליינד פונקציע.
        // דער איטעראטאר טאר נישט זיין ליידיק.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // רעטורנס די לעצטע עלעמענט און מאָווינג די סוף פון יטעראַטאָר קאַפּויער 1.
        // ימפּרוווז זייער פאָרשטעלונג קאַמפּערד מיט אַן ינליינד פונקציע.
        // דער איטעראטאר טאר נישט זיין ליידיק.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // שרינקס די יטעראַטאָר ווען T איז אַ זסט, דורך מאָווינג די סוף פון יטעראַטאָר קאַפּויער דורך `n`.
        // `n` מוזן נישט יקסיד `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // העלפער פונקציע פֿאַר שאפן אַ רעפטל פון יטעראַטאָר.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // זיכערקייט: די יטעראַטאָר איז באשאפן פֿון אַ רעפטל מיט טייַטל
                // `self.ptr` און לענג קס 00 קס.
                // דאָס געראַנטיז אַז אַלע די פּרירעקוואַזאַץ פֿאַר `from_raw_parts` זענען מקיים.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // העלפער פונקציע צו אַריבערפירן די אָנהייב פון די יטעראַטאָר פאָרווערדז דורך `offset` עלעמענטן, צוריקקומען די אַלט אָנהייב.
            //
            // אַנסייף ווייַל די פאָטאָ זאָל נישט יקסיד `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // זיכערקייט: די קאָלער געראַנטיז אַז קס 01 קס קען נישט יקסיד קס 00 קס,
                    // אַזוי דעם נייַ טייַטל איז ין `self` און אַזוי געראַנטיד צו זיין ניט-נאַל.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // העלפער פונקציאָנירן צו אַריבערפירן די סוף פון די יטעראַטאָר קאַפּויער דורך `offset` עלעמענטן און צוריקקומען די נייַע סוף.
            //
            // אַנסייף ווייַל די פאָטאָ זאָל נישט יקסיד `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // זיכערקייט: די קאָלער געראַנטיז אַז קס 01 קס קען נישט יקסיד קס 00 קס,
                    // וואָס איז געראַנטיד צו נישט לויפן אַ `isize`.
                    // די ריזאַלטינג טייַטל איז אויך אין גרענעץ פון קס 01 קס, וואָס מקיים די אנדערע רעקווירעמענץ פֿאַר קס 00 קס.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // קען זיין ימפּלאַמענאַד מיט סלייסאַז, אָבער דאָס אַוווידז גווול טשעקס

                // זיכערקייט: קס 00 קס קאַללס זענען זיכער זינט די אָנהייב טייַטל פון אַ רעפטל
                // מוזן זיין ניט-נאַל, און סלייסאַז איבער ניט-זסטס מוזן אויך האָבן אַ ניט-נאַל סוף טייַטל.
                // די רופן צו `next_unchecked!` איז זיכער ווייַל מיר קאָנטראָלירן אויב די יטעראַטאָר איז ליידיק ערשטער.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // דער איטעראַטאָר איז איצט ליידיק.
                    if mem::size_of::<T>() == 0 {
                        // מיר מוזן טאָן דאָס אַזוי ווי `ptr` קען קיינמאָל זיין 0, אָבער `end` קען זיין (רעכט צו ראַפּינג).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // זיכערקייט: סוף קען נישט זיין 0 אויב T איז נישט ZST ווייַל PTR איז נישט 0 און סוף>=PTR
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // זיכערקייט: מיר זענען אין גווול.`post_inc_start` טוט די רעכט זאַך אפילו פֿאַר זסטס.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // מיר אָווועררייד די פעליקייַט ימפּלאַמענטיישאַן, וואָס ניצט `try_fold`, ווייַל דעם פּשוט ימפּלאַמענטיישאַן דזשענערייץ ווייניקער LLVM IR און איז פאַסטער צו זאַמלען.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // מיר אָווועררייד די פעליקייַט ימפּלאַמענטיישאַן, וואָס ניצט `try_fold`, ווייַל דעם פּשוט ימפּלאַמענטיישאַן דזשענערייץ ווייניקער LLVM IR און איז פאַסטער צו זאַמלען.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // מיר אָווועררייד די פעליקייַט ימפּלאַמענטיישאַן, וואָס ניצט `try_fold`, ווייַל דעם פּשוט ימפּלאַמענטיישאַן דזשענערייץ ווייניקער LLVM IR און איז פאַסטער צו זאַמלען.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // מיר אָווועררייד די פעליקייַט ימפּלאַמענטיישאַן, וואָס ניצט `try_fold`, ווייַל דעם פּשוט ימפּלאַמענטיישאַן דזשענערייץ ווייניקער LLVM IR און איז פאַסטער צו זאַמלען.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // מיר אָווועררייד די פעליקייַט ימפּלאַמענטיישאַן, וואָס ניצט `try_fold`, ווייַל דעם פּשוט ימפּלאַמענטיישאַן דזשענערייץ ווייניקער LLVM IR און איז פאַסטער צו זאַמלען.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // מיר אָווועררייד די פעליקייַט ימפּלאַמענטיישאַן, וואָס ניצט `try_fold`, ווייַל דעם פּשוט ימפּלאַמענטיישאַן דזשענערייץ ווייניקער LLVM IR און איז פאַסטער צו זאַמלען.
            // די `assume` אַוווידז אַ גווול טשעק.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // זיכערקייט: מיר זענען געראַנטיד צו זיין אין גווול דורך די שלייף ינוועראַנט:
                        // ווען קס 00 קס, קס 01 קס קערט קס 02 קס און די שלייף ברייקס.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // מיר אָווועררייד די פעליקייַט ימפּלאַמענטיישאַן, וואָס ניצט `try_fold`, ווייַל דעם פּשוט ימפּלאַמענטיישאַן דזשענערייץ ווייניקער LLVM IR און איז פאַסטער צו זאַמלען.
            // די `assume` אַוווידז אַ גווול טשעק.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // זיכערהייט: `i` מוזן זיין נידעריקער ווי `n` זינט עס סטאַרץ ביי `n`
                        // און איז בלויז דיקריסינג.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // זיכערקייט: די קאַללער מוזן גאַראַנטירן אַז `i` איז אין גווול פון
                // די אַנדערלייינג רעפטל, אַזוי קס 01 קס קען נישט לויפן אַ קס 00 קס, און די אומגעקערט באַווייַזן איז געראַנטיד צו אָפּשיקן צו אַן עלעמענט פון דער רעפטל און אַזוי געראַנטיד צו זיין גילטיק.
                //
                // אויך טאָן אַז די קאָלער אויך געראַנטיז אַז מיר קיינמאָל ווערן גערופן מיט די זעלבע אינדעקס, און אַז קיין אנדערע מעטהאָדס אַז אַקסעס דעם סובסליסע זענען גערופֿן, אַזוי עס איז גילטיק פֿאַר די אומגעקערט דערמאָנען צו זיין מיוטאַבאַל אין דעם פאַל פון
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // קען זיין ימפּלאַמענאַד מיט סלייסאַז, אָבער דאָס אַוווידז גווול טשעקס

                // זיכערקייט: קס 00 קס קאַללס זענען זיכער זינט די אָנהייב טייַטל פון אַ רעפטל מוזן זיין ניט-נאַל,
                // און סלייסאַז איבער ניט-זסטס מוזן אויך האָבן אַ ניט-נאַל סוף טייַטל.
                // די רופן צו `next_back_unchecked!` איז זיכער ווייַל מיר קאָנטראָלירן אויב די יטעראַטאָר איז ליידיק ערשטער.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // דער איטעראַטאָר איז איצט ליידיק.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // זיכערקייט: מיר זענען אין גווול.`pre_dec_end` טוט די רעכט זאַך אפילו פֿאַר זסטס.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}