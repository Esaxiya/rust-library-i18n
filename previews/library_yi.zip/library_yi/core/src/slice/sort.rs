//! סלייסט סאָרטינג
//!
//! דער מאָדולע כּולל אַ סאָרטינג אַלגערידאַם באזירט אויף אָרסאָן פּעטערס 'מוסטער-דיפיטינג קוויקסאָרט, ארויס ביי: <https://github.com/orlp/pdqsort>
//!
//!
//! אַנסטייבאַל סאָרטינג איז קאַמפּאַטאַבאַל מיט ליבקאָרע ווייַל עס קען נישט אַלאַקייט זיקאָרן, ניט ענלעך אונדזער סטאַביל סאָרטינג ימפּלאַמענטיישאַן.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ווען דראַפּט, קאַפּיז פון קס 01 קס צו קס 00 קס.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // זיכערהייט: דאָס איז אַ העלפער קלאַס.
        //          ביטע אָפּשיקן צו די נוצן פֿאַר ריכטיק.
        //          מען דאַרף זיין זיכער אַז `src` און `dst` טאָן ניט אָוווערלאַפּ ווי `ptr::copy_nonoverlapping` פארלאנגט.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// שיפט דער ערשטער עלעמענט צו די רעכט ביז עס ינקאַונטערז אַ גרעסערע אָדער גלייַך עלעמענט.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // זיכערקייט: די אַנסייף אַפּעריישאַנז ונטער ינוואַלווז ינדעקסינג אָן אַ געבונדן טשעק (קס 00 קס און קס 01 קס)
    // און קאַפּיינג זיקאָרן קס 00 קס.
    //
    // אַ.ינדעקסינג:
    //  1. מיר אָפּגעשטעלט די גרייס פון דעם מענגע צו>=2.
    //  2. כל די ינדעקסינג וואָס מיר וועלן טאָן איז שטענדיק צווישן קקסנומקס קס.
    //
    // ב.זכּרון קאַפּיינג
    //  1. מיר באַקומען אָנצוהערעניש צו באַווייַזן וואָס זענען געראַנטיד צו זיין גילטיק.
    //  2. זיי קענען נישט אָוווערלאַפּ ווייַל מיר באַקומען ינדאַקייטערז צו די חילוק ינדאַסיז פון די רעפטל.
    //     ניימלי, `i` און `i-1`.
    //  3. אויב די רעפטל איז רעכט אַליינד, די עלעמענטן זענען רעכט אַליינד.
    //     עס איז די פֿאַראַנטוואָרטלעכקייט פון די קאַללער צו מאַכן זיכער אַז די רעפטל איז רעכט אַליינד.
    //
    // פֿאַר ווייטער פּרטים זען די באַמערקונגען אונטן.
    unsafe {
        // אויב די ערשטע צוויי עלעמענטן זענען אויס פון סדר ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // לייענען די ערשטער עלעמענט אין אַ סטאַק-אַלאַקייטיד בייַטעוודיק.
            // אויב אַ ווייַטערדיקע פאַרגלייַך אָפּעראַציע panics, `hole` וועט פאַלן און אויטאָמאַטיש שרייַבן די עלעמענט צוריק אין דער רעפטל.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // מאַך `i`-th עלעמענט איין אָרט צו די לינקס, אַזוי שיפטינג די לאָך צו די רעכט.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` געץ דראַפּט און אַזוי קאפיעס קס 01 קס אין די רוען לאָך אין קס 00 קס.
        }
    }
}

/// שיפט די לעצטע עלעמענט צו די לינקס ביז עס ינקאַונערז אַ קלענערער אָדער גלייַך עלעמענט.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // זיכערקייט: די אַנסייף אַפּעריישאַנז ונטער ינוואַלווז ינדעקסינג אָן אַ געבונדן טשעק (קס 00 קס און קס 01 קס)
    // און קאַפּיינג זיקאָרן קס 00 קס.
    //
    // אַ.ינדעקסינג:
    //  1. מיר אָפּגעשטעלט די גרייס פון דעם מענגע צו>=2.
    //  2. כל די ינדעקסינג וואָס מיר וועלן טאָן איז שטענדיק צווישן קקסנומקס קס.
    //
    // ב.זכּרון קאַפּיינג
    //  1. מיר באַקומען אָנצוהערעניש צו באַווייַזן וואָס זענען געראַנטיד צו זיין גילטיק.
    //  2. זיי קענען נישט אָוווערלאַפּ ווייַל מיר באַקומען ינדאַקייטערז צו די חילוק ינדאַסיז פון די רעפטל.
    //     ניימלי, `i` און `i+1`.
    //  3. אויב די רעפטל איז רעכט אַליינד, די עלעמענטן זענען רעכט אַליינד.
    //     עס איז די פֿאַראַנטוואָרטלעכקייט פון די קאַללער צו מאַכן זיכער אַז די רעפטל איז רעכט אַליינד.
    //
    // פֿאַר ווייטער פּרטים זען די באַמערקונגען אונטן.
    unsafe {
        // אויב די לעצטע צוויי יסודות זענען אויס פון סדר ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // לייענען די לעצטע עלעמענט אין אַ סטאַק-אַלאַקייטיד בייַטעוודיק.
            // אויב אַ ווייַטערדיקע פאַרגלייַך אָפּעראַציע panics, `hole` וועט פאַלן און אויטאָמאַטיש שרייַבן די עלעמענט צוריק אין דער רעפטל.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // מאַך `i`-th עלעמענט איין אָרט צו די רעכט, אַזוי שיפטינג די לאָך צו די לינקס.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` געץ דראַפּט און אַזוי קאפיעס קס 01 קס אין די רוען לאָך אין קס 00 קס.
        }
    }
}

/// טייל סאָרץ אַ רעפטל דורך יבעררוק עטלעכע עלעמענטן אויס פון סדר.
///
/// קערט `true` אויב די רעפטל איז אויסגעשטעלט אין די סוף.די פֿונקציע איז ערגסט פאַל *O*(*N*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // מאַקסימום נומער פון שכייניש אַוט-פון-סדר פּערז וואָס וועט יבעררוק.
    const MAX_STEPS: usize = 5;
    // אויב די רעפטל איז קירצער ווי דעם, טאָן ניט יבעררוק קיין עלעמענטן.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // זיכערקייט: מיר האָבן שוין עקספּרעסלי דורכגעקאָכט די געבונדן קאָנטראָלירונג מיט קס 00 קס.
        // אַלע אונדזער סאַבסאַקוואַנט ינדעקסינג איז בלויז אין די קייט `0 <= index < len`
        unsafe {
            // געפֿינען די ווייַטער פּאָר פון שכייניש עלעמענטן אויס פון סדר.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // זענען מיר פאַרטיק?
        if i == len {
            return true;
        }

        // צי ניט יבעררוק עלעמענטן אויף קורץ ערייז, וואָס האט אַ פאָרשטעלונג קאָסטן.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // ויסבייַטן די געפֿונען פּאָר פון עלעמענטן.דאָס לייגט זיי אין ריכטיק סדר.
        v.swap(i - 1, i);

        // יבעררוק די קלענערער עלעמענט צו די לינקס.
        shift_tail(&mut v[..i], is_less);
        // יבעררוק די גרעסערע עלעמענט צו די רעכט.
        shift_head(&mut v[i..], is_less);
    }

    // ניט געראטן צו סאָרט די רעפטל אין די לימיטעד נומער פון טריט.
    false
}

/// סאָרץ אַ רעפטל ניצן ינסערשאַן סאָרט, וואָס איז *O*(*N*^ 2) ערגסט פאַל.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// סאָרץ קס 00 קס ניצן העאַפּסאָרט, וואָס געראַנטיז *אָ*(*ן*\* קס 01 קס ערגסט פאַל.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // די ביינערי קופּע רעספּעקט די ינוועראַנט `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // קינדער פון קס 00 קס:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // קלייַבן די גרעסערע קינד.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // האַלטן אויב די ינוועריאַנט האלט `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // ויסבייַטן `node` מיט די גרעסערע קינד, מאַך איין שריט אַראָפּ און פאָרזעצן סיפטינג.
            v.swap(node, greater);
            node = greater;
        }
    };

    // בויען די קופּע אין לינעאַר צייט.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // פּאָפּ מאַקסימום עלעמענטן פֿון דער קופּע.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// פּאַרטישאַנז קס 02 קס אין עלעמענטן קלענערער ווי קס 01 קס, נאכגעגאנגען דורך יסודות גרעסער ווי אָדער גלייַך צו קס 00 קס.
///
///
/// קערט די נומער פון עלעמענטן קלענערער ווי `pivot`.
///
/// פּאַרטישאַנינג איז דורכגעקאָכט בלאָק דורך בלאָק אין סדר צו מינאַמייז די קאָס פון בראַנטשינג אַפּעריישאַנז.
/// דער געדאַנק איז דערלאנגט אין די [BlockQuicksort][pdf] פּאַפּיר.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // נומער פון עלעמענטן אין אַ טיפּיש בלאָק.
    const BLOCK: usize = 128;

    // די פּאַרטישאַנינג אַלגערידאַם ריפּיץ די פאלגענדע טריט ביז קאַמפּלישאַן:
    //
    // 1. שפּור אַ בלאָק פון די לינקס זייַט צו ידענטיפיצירן עלעמענטן גרעסער ווי אָדער גלייַך צו די דרייפּונקט.
    // 2. שפּור אַ בלאָק פון די רעכט זייַט צו ידענטיפיצירן עלעמענטן קלענערער ווי די דרייפּונקט.
    // 3. וועקסל די יידענאַפייד עלעמענטן צווישן די לינקס און די רעכט זייַט.
    //
    // מיר האַלטן די פאלגענדע וועריאַבאַלז פֿאַר אַ בלאָק פון עלעמענטן:
    //
    // 1. `block` - נומער פון עלעמענטן אין דער בלאָק.
    // 2. `start` - אָנהייב טייַטל אין די `offsets` מענגע.
    // 3. `end` - סוף טייַטל אין די `offsets` מענגע.
    // 4. `אָפסעץ, ינדיסעס פון ניט-פון-סדר עלעמענטן אין דעם בלאָק.

    // די קראַנט בלאָק אויף די לינקס זייַט (פֿון `l` צו `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // די קראַנט בלאָק אויף די רעכט זייַט (פֿון `r.sub(block_r)` to `r`).
    // זיכערקייט: די דאַקיומענטיישאַן פֿאַר קס 00 קס ספּאַסיפיקלי דערמאָנען אַז קס 01 קס איז שטענדיק זיכער
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: אויב מיר באַקומען VLAs, פּרוּווט צו מאַכן איין מענגע פון די `min(v.len() לענג, 2 * BLOCK)
    // ווי צוויי פאַרפעסטיקט גרייס ערייז פון די `BLOCK` לענג.VLAs קען זיין מער קאַש-עפעקטיוו.

    // קערט די נומער פון עלעמענטן צווישן פּוינטערז `l` (inclusive) און `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // מיר זענען דורכגעקאָכט מיט פּאַרטישאַנינג בלאָק-דורך-בלאָק ווען קס 00 קס און קס 01 קס באַקומען זייער נאָענט.
        // דערנאָך מיר טאָן עטלעכע לאַטע-אַרויף אַרבעט צו צעטיילן די רוען עלעמענטן אין צווישן.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // נומער פון רוען עלעמענטן (נאָך ניט קאַמפּערד צו די דרייפּונקט).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // סטרויערן די בלאָק סיזעס אַזוי אַז די לינקס און די רעכט בלאָק טאָן ניט אָוווערלאַפּ, אָבער באַקומען בישליימעס אַליינד צו דעקן די גאנצע רוען ריס.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // שפּור `block_l` עלעמענטן פֿון די לינקס זייַט.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // זיכערקייט: די ונסאַפעטי אַפּעריישאַנז ונטער אַרייַן די נוצן פון די `offset`.
                //         לויט די באדינגונגען פארלאנגט דורך די פונקציע, מיר באַפרידיקן זיי ווייַל:
                //         1. `offsets_l` איז סטאַק-אַלאַקייטיד, און אַזוי באַטראַכטן באַזונדער אַלאַקייטיד כייפעץ.
                //         2. די פונקציע קס 01 קס קערט אַ קס 00 קס.
                //            קאַסטינג אַ קס 01 קס וועט קיינמאָל לויפן `isize`.
                //         3. מיר האָבן געראַנטיד אַז `block_l` וועט זיין `<= BLOCK`.
                //            פּלוס, קס 00 קס איז טכילעס באַשטימט צו די אָנהייב טייַטל פון קס 01 קס וואָס איז געווען דערקלערט אויף דעם אָנלייגן.
                //            אזוי, מיר וויסן אַז אפילו אין די ערגסט פאַל (אַלע ינוואַקיישאַנז פון קסקסנומקס קס קערט פאַלש), מיר וועלן בלויז העכסטן 1 בייט דורכגיין דעם סוף.
                //        אן אנדער ונסאַפעטי אָפּעראַציע דאָ איז דערפערענסינג קקסנומקס.
                //        `elem` איז געווען טכילעס די אָנהייב טייַטל צו די רעפטל וואָס איז שטענדיק גילטיק.
                unsafe {
                    // בראַנטשלעסס פאַרגלייַך.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // שפּור `block_r` עלעמענטן פֿון די רעכט זייַט.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // זיכערקייט: די ונסאַפעטי אַפּעריישאַנז ונטער אַרייַן די נוצן פון די `offset`.
                //         לויט די באדינגונגען פארלאנגט דורך די פונקציע, מיר באַפרידיקן זיי ווייַל:
                //         1. `offsets_r` איז סטאַק-אַלאַקייטיד, און אַזוי באַטראַכטן באַזונדער אַלאַקייטיד כייפעץ.
                //         2. די פונקציע קס 01 קס קערט אַ קס 00 קס.
                //            קאַסטינג אַ קס 01 קס וועט קיינמאָל לויפן `isize`.
                //         3. מיר האָבן געראַנטיד אַז `block_r` וועט זיין `<= BLOCK`.
                //            פּלוס, קס 00 קס איז טכילעס באַשטימט צו די אָנהייב טייַטל פון קס 01 קס וואָס איז געווען דערקלערט אויף דעם אָנלייגן.
                //            אזוי, מיר וויסן אַז אפילו אין די ערגסט פאַל (אַלע ינוואַקיישאַנז פון קס 00 קס קערט אמת), מיר וועלן בלויז זיין ביי 1 בייט דורכגיין דעם סוף.
                //        אן אנדער ונסאַפעטי אָפּעראַציע דאָ איז דערפערענסינג קקסנומקס.
                //        `elem` איז געווען טכילעס `1 *sizeof(T)` נאָך דעם סוף, און `1* sizeof(T)` מיר דיסקלאָוזד איידער אַקסעס עס.
                //        פּלוס, `block_r` איז געזאגט אַז עס איז ווייניקער ווי `BLOCK` און `elem` וועט דעריבער בייַ רובֿ ווייַזן צו די אָנהייב פון די רעפטל.
                unsafe {
                    // בראַנטשלעסס פאַרגלייַך.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // נומער פון ניט-אָרדערד עלעמענטן צו ויסבייַטן צווישן די לינקס און די רעכט זייַט.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // אַנשטאָט צו ויסבייַטן איין פּאָר אין דער צייט, עס איז מער עפעקטיוו צו דורכפירן אַ סייקליק פּערמיוטיישאַן.
            // דאָס איז נישט שטרענג עקוויוואַלענט צו סוואַפּינג, אָבער טראגט אַ ענלעך רעזולטאַט ניצן ווייניקער זכּרון אַפּעריישאַנז.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // אַלע עלעמענטן אין אָרדענונג אין די לינקס בלאָק זענען אריבערגעפארן.מאַך צו די ווייַטער בלאָק.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // כל עלעמענטן אויס פון סדר אין די רעכט בלאָק זענען אריבערגעפארן.מאַך צו די פֿריִערדיקע בלאָק.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // כל וואָס בלייבט איצט איז מאַקסימום איין בלאָק (אָדער די לינקס אָדער די רעכט) מיט עלעמענטן אין סדר וואָס דאַרפֿן צו זיין אריבערגעפארן.
    // אַזאַ רוען עלעמענטן קענען זיין פּונקט שיפטעד צו די סוף אין זייער בלאָק.
    //

    if start_l < end_l {
        // די לינקס בלאָק בלייבט.
        // מאַך די רוען עלעמענטן אין סדר צו די רעכט רעכט.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // די רעכט בלאָק בלייבט.
        // מאַך די רוען עלעמענטן אין סדר צו די לינקס לינקס.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // גאָרנישט אַנדערש צו טאָן, מיר זענען פאַרטיק.
        width(v.as_mut_ptr(), l)
    }
}

/// פּאַרטישאַנז קס 02 קס אין עלעמענטן קלענערער ווי קס 01 קס, נאכגעגאנגען דורך יסודות גרעסער ווי אָדער גלייַך צו קס 00 קס.
///
///
/// רעטורנס אַ טופּלע פון:
///
/// 1. נומער פון עלעמענטן קלענערער ווי קס 00 קס.
/// 2. אמת אויב `v` איז שוין פּאַרטישאַנד.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // שטעלן די דרייפּונקט אין די אָנהייב פון די רעפטל.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // לייענען די דרייפּונקט אין אַ סטאַק-אַלאַקייטיד בייַטעוודיק פֿאַר עפעקטיווקייַט.
        // אויב אַ ווייַטערדיקע פאַרגלייַך אָפּעראַציע ז 0 פּאַניקס 0 ז, די דרייפּונקט וועט ווערן אויטאָמאַטיש געשריבן צוריק אין דער רעפטל.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // געפֿינען די ערשטע פּאָר פון עלעמענטן אין סדר.
        let mut l = 0;
        let mut r = v.len();

        // זיכערקייט: די ונסאַפעטי אונטן ינוואַלווז ינדעקסינג אַ מענגע.
        // פֿאַר דער ערשטער: מיר שוין קאָנטראָלירן די גווול דאָ מיט `l < r`.
        // פֿאַר די רגע: מיר טכילעס האָבן `l == 0` און `r == v.len()` און מיר אָפּגעשטעלט `l < r` ביי יעדער ינדעקסינג אָפּעראַציע.
        //                     פֿון דאָ מיר וויסן אַז `r` מוזן זיין לפּחות `r == l`, וואָס איז געוויזן צו זיין גילטיק פֿון דער ערשטער.
        unsafe {
            // געפֿינען די ערשטער עלעמענט גרעסער ווי אָדער גלייַך צו די דרייפּונקט.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // געפֿינען די לעצטע עלעמענט קלענערער ווי די דרייפּונקט.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` גייט אויס פון פאַרנעם און שרייבט די דרייפּונקט (וואָס איז אַ סטאַק-אַלאַקייטיד בייַטעוודיק) צוריק אין דער רעפטל ווו עס ערידזשנאַלי איז געווען.
        // דער שריט איז קריטיש אין ינשורינג זיכערקייַט!
        //
    };

    // שטעלן די דרייפּונקט צווישן די צוויי פּאַרטישאַנז.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// פּאַרטישאַנז קס 01 קס אין עלעמענטן גלייַך צו קס 02 קס, נאכגעגאנגען דורך יסודות גרעסער ווי קס 00 קס.
///
/// רעטורנס די נומער פון עלעמענטן גלייַך צו די דרייפּונקט.
/// עס איז אנגענומען אַז `v` כּולל נישט עלעמענטן קלענערער ווי די דרייפּונקט.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // שטעלן די דרייפּונקט אין די אָנהייב פון די רעפטל.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // לייענען די דרייפּונקט אין אַ סטאַק-אַלאַקייטיד בייַטעוודיק פֿאַר עפעקטיווקייַט.
    // אויב אַ ווייַטערדיקע פאַרגלייַך אָפּעראַציע ז 0 פּאַניקס 0 ז, די דרייפּונקט וועט ווערן אויטאָמאַטיש געשריבן צוריק אין דער רעפטל.
    // זיכערקייט: דער טייַטל דאָ איז גילטיק ווייַל עס איז באקומען פון אַ רעפֿערענץ צו אַ רעפטל.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // איצט צעטיילונג די רעפטל.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // זיכערקייט: די ונסאַפעטי אונטן ינוואַלווז ינדעקסינג אַ מענגע.
        // פֿאַר דער ערשטער: מיר שוין קאָנטראָלירן די גווול דאָ מיט `l < r`.
        // פֿאַר די רגע: מיר טכילעס האָבן `l == 0` און `r == v.len()` און מיר אָפּגעשטעלט `l < r` ביי יעדער ינדעקסינג אָפּעראַציע.
        //                     פֿון דאָ מיר וויסן אַז `r` מוזן זיין לפּחות `r == l`, וואָס איז געוויזן צו זיין גילטיק פֿון דער ערשטער.
        unsafe {
            // געפֿינען די ערשטער עלעמענט גרעסער ווי די דרייפּונקט.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // געפֿינען די לעצטע עלעמענט גלייַך צו די דרייפּונקט.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // זענען מיר פאַרטיק?
            if l >= r {
                break;
            }

            // ויסבייַטן די געפֿונען פּאָר פון ניט-אָרדערד עלעמענטן.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // מיר געפֿונען `l` עלעמענטן גלייַך צו די דרייפּונקט.לייג 1 צו אַקאַונט פֿאַר די דרייפּונקט זיך.
    l + 1

    // `_pivot_guard` גייט אויס פון פאַרנעם און שרייבט די דרייפּונקט (וואָס איז אַ סטאַק-אַלאַקייטיד בייַטעוודיק) צוריק אין דער רעפטל ווו עס ערידזשנאַלי איז געווען.
    // דער שריט איז קריטיש אין ינשורינג זיכערקייַט!
}

/// צעוואָרפן עטלעכע יסודות אין אַן פּרווון צו ברעכן פּאַטערנז וואָס קען פאַרשאַפן ימבאַלאַנסט פּאַרטישאַנז אין קוויקקסאָרט.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // פּסעוודאָראַנדאָם נומער גענעראַטאָר פֿון די "Xorshift RNGs" פּאַפּיר פון George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // נעמען טראַפ-נומערן מאָדולאָ דעם נומער.
        // די נומער פיץ אין קס 01 קס ווייַל קס 02 קס איז נישט גרעסער ווי קס 00 קס.
        let modulus = len.next_power_of_two();

        // עטלעכע דרייפּונקט קאַנדאַדייץ וועט זיין אין די נירביי פון דעם אינדעקס.זאל ס ראַנדאַמייז זיי.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // דזשענערייט טראַפ-נומער מאָדולאָ קס 00 קס.
            // אָבער, אין סדר צו ויסמייַדן טייַער אַפּעריישאַנז, מיר ערשטער נעמען עס אַ מאַכט פון צוויי, און דאַן אַראָפּגיין דורך קס 01 קס ביז עס פיץ אין די קייט קס 00 קס.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` איז געראַנטיד צו זיין ווייניקער ווי קס 00 קס.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// טשוזיז אַ דרייפּונקט אין קס 00 קס און קערט דער אינדעקס און קס 01 קס אויב די רעפטל איז מסתּמא שוין אויסגעשטעלט.
///
/// עלעמענטן אין קס 00 קס קען זיין ריאָרדערד אין דעם פּראָצעס.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // מינימום לענג צו קלייַבן די מידיאַן-פון-מעדיאַנס אופֿן.
    // קירצער סלייסאַז נוצן די פּשוט מיטל-פון-דריי אופֿן.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // מאַקסימום נומער פון סוואַפּס וואָס קענען זיין דורכגעקאָכט אין דעם פֿונקציע.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // דריי ינדיסיז וואָס מיר וועלן קלייַבן אַ דרייפּונקט.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // קאַונץ די גאַנץ נומער פון סוואַפּס וואָס מיר וועלן דורכפירן בשעת סאָרטינג ינדיסעס.
    let mut swaps = 0;

    if len >= 8 {
        // סוואַפּס ינדאַסיז אַזוי אַז `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // סוואַפּס ינדאַסיז אַזוי אַז קס 00 קס.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // טרעפט די מידיאַן פון קס 02 קס און סטאָרז די אינדעקס אין קס 00 קס.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // געפֿינען מעדיאַנס אין די קוואַרטאַל פון קס 01 קס, קס 02 קס און קס 00 קס.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // געפֿינען די מידיאַן צווישן `a`, `b` און `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // די מאַקסימום נומער פון סוואַפּס איז דורכגעקאָכט.
        // די גיכער זענען אַז די רעפטל איז אַראָפּגיין אָדער מערסטנס אַראָפּגיין, אַזוי ריווערסינג וועט מיסטאָמע העלפֿן צו סאָרט עס פאַסטער.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// סאָרט `v` רעקורסיוועלי.
///
/// אויב די רעפטל האט אַ פאָרויסגייער אין דער אָריגינעל מענגע, עס איז ספּעסאַפייד ווי קס 00 קס.
///
/// `limit` איז די נומער פון ערלויבט ימבאַלאַנסט פּאַרטישאַנז איידער סוויטטשינג צו `heapsort`.
/// אויב נול, די פֿונקציע וועט גלייך באַשטימען צו העאַפּסאָרט.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // סלייסיז אַרויף צו די לענג זענען סאָרטירט מיט ינסערשאַן סאָרט.
    const MAX_INSERTION: usize = 20;

    // אמת אויב די לעצטע צעטיילונג איז געווען גלייַך באַלאַנסט.
    let mut was_balanced = true;
    // אמת אויב די לעצטע צעטיילונג האט נישט שאַרן עלעמענטן (די רעפטל איז שוין צעטיילט).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // זייער קורץ סלייסיז זענען סאָרטירט מיט ינסערשאַן סאָרט.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // אויב מען האָט געמאכט פילע שלעכט דרייפּונקט ברירות, פשוט פאַלן צוריק צו העאַפּסאָרט צו גאַראַנטירן די קס 00 קס ערגסט פאַל.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // אויב די לעצטע פּאַרטישאַנינג איז געווען ימבאַלאַנסט, פּרוּווט ברייקינג פּאַטערנז אין דער רעפטל דורך שאַפלינג עטלעכע עלעמענטן אַרום.
        // אַלעווייַ מיר וועלן קלייַבן אַ בעסער דרייפּונקט דעם מאָל.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // קלייַבן אַ דרייפּונקט און פּרובירן צו טרעפן צי די רעפטל איז שוין אויסגעשטעלט.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // אויב די לעצטע צעטיילונג איז געווען דיסאַנטלי באַלאַנסט און האט נישט שאַרן עלעמענטן, און אויב דרייפּונקט סעלעקציע פּרידיקס די רעפטל איז מסתּמא שוין אויסגעשטעלט ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // פּרוּווט ידענטיפיצירן עטלעכע עלעמענטן אין סדר און יבעררוק זיי צו ריכטיק שטעלעס.
            // אויב די רעפטל ענדס אַרויף גאָר סאָרטירט, מיר זענען פאַרטיק.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // אויב די אויסדערוויילטע דרייפּונקט איז גלייַך צו די פאָרויסגייער, דאָס איז דער קלענסטער עלעמענט אין דער רעפטל.
        // צעטיילן די רעפטל אין עלעמענטן גלייַך צו און עלעמענטן גרעסער ווי די דרייפּונקט.
        // דער פאַל איז יוזשאַוואַלי שלאָגן ווען די רעפטל כּולל פילע דופּליקאַט עלעמענטן.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // פאָרזעצן סאָרטינג עלעמענטן גרעסער ווי די דרייפּונקט.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // צעטיילונג די רעפטל.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // שפּאַלטן די רעפטל אין קס 01 קס, קס 02 קס און קס 00 קס.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // רעקורסע אין די קירצער זייַט בלויז צו מינאַמייז די גאַנץ נומער פון רעקורסיווע קאַללס און פאַרנוצן ווייניקער אָנלייגן פּלאַץ.
        // דערנאָך נאָר פאָרזעצן מיט די לאָנגער זייַט (דאָס איז ענלעך צו עק רעקורסיאָן).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// סאָרט `v` ניצן מוסטער-דיפיטינג קוויקקסאָרט, וואָס איז *O*(*n*\*log(* n*)) ערגסט פאַל.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // סאָרטינג האט קיין מינינגפאַל נאַטור אויף נול-סייזד טייפּס.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // באַגרענעצן די נומער פון ימבאַלאַנסט פּאַרטישאַנז צו `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // פֿאַר סלייסיז אַרויף צו דעם לענג, עס מיסטאָמע פאַסטער צו נאָר סאָרט זיי.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // קלייַבן אַ דרייפּונקט
        let (pivot, _) = choose_pivot(v, is_less);

        // אויב די אויסדערוויילטע דרייפּונקט איז גלייַך צו די פאָרויסגייער, דאָס איז דער קלענסטער עלעמענט אין דער רעפטל.
        // צעטיילן די רעפטל אין עלעמענטן גלייַך צו און עלעמענטן גרעסער ווי די דרייפּונקט.
        // דער פאַל איז יוזשאַוואַלי שלאָגן ווען די רעפטל כּולל פילע דופּליקאַט עלעמענטן.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // אויב מיר האָבן דורכגעגאנגען אונדזער אינדעקס, מיר זענען גוט.
                if mid > index {
                    return;
                }

                // אַנדערש, פאָרזעצן סאָרטינג עלעמענטן גרעסער ווי די דרייפּונקט.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // שפּאַלטן די רעפטל אין קס 01 קס, קס 02 קס און קס 00 קס.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // אויב מיטן==אינדעקס, מיר זענען פאַרטיק, ווייַל partition() געראַנטיד אַז אַלע יסודות נאָך מיטן זענען גרעסער ווי אָדער גלייַך צו מיטן.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // סאָרטינג האט קיין מינינגפאַל נאַטור אויף נול-סייזד טייפּס.טו גארנישט.
    } else if index == v.len() - 1 {
        // געפֿינען מאַקס עלעמענט און שטעלן עס אין די לעצטע שטעלע פון די מענגע.
        // מיר קענען נוצן `unwrap()` דאָ ווייַל מיר וויסן אַז V דאַרף ניט זיין ליידיק.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // געפֿינען מיין עלעמענט און שטעלן אים אין דער ערשטער שטעלע פון די מענגע.
        // מיר קענען נוצן `unwrap()` דאָ ווייַל מיר וויסן אַז V דאַרף ניט זיין ליידיק.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}