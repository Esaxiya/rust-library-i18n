// ignore-tidy-filelength

//! רעפטל פאַרוואַלטונג און מאַניפּיאַליישאַן.
//!
//! פֿאַר מער דעטאַילס זען [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// ריין rust memchr ימפּלאַמענטיישאַן, גענומען פֿון rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// די פֿונקציע איז עפנטלעך בלויז ווייַל עס איז קיין אנדערע וועג צו פּרובירן טעאַפּס.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// קערט די נומער פון עלעמענטן אין דער רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // זיכערקייט: קאָנסט געזונט ווייַל מיר יבערמאַכן די לענג פעלד ווי אַ נוצן (וואָס עס מוזן זיין)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // זיכערקייט: דאָס איז זיכער ווייַל קס 00 קס און קס 01 קס האָבן די זעלבע אויסלייג.
            // בלויז `std` קענען מאַכן דעם גאַראַנטירן.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: פאַרבייַטן די `crate::ptr::metadata(self)` ווען דאָס איז קאָנסטאַבלע.
            // אין דעם שרייבן דאָס אַ "Const-stable functions can only call other const-stable functions" טעות.
            //

            // זיכערהייט: אַקסעס די ווערט פון די קס 00 קס פאַרבאַנד איז זיכער זינט * קאָנסט ט
            // און פּטרקאָמפּאָנענץ<T>האָבן די זעלבע זכּרון לייאַוץ.
            // בלויז ז 0 סטד 0 ז קענען מאַכן דעם גאַראַנטירן.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// קערט `true` אויב די סלייס האט אַ לענג פון 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// קערט דער ערשטער עלעמענט פון דער רעפטל, אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// קערט אַ מיוטאַבאַל טייַטל צו דער ערשטער עלעמענט פון דער רעפטל, אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// קערט דער ערשטער און אַלע די רעשט פון די עלעמענטן פון דער רעפטל, אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// קערט דער ערשטער און אַלע די רעשט פון די עלעמענטן פון דער רעפטל, אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// קערט די לעצטע און אַלע די מנוחה פון די עלעמענטן פון דער רעפטל, אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// קערט די לעצטע און אַלע די מנוחה פון די עלעמענטן פון דער רעפטל, אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// רעטורנס די לעצטע עלעמענט פון דער רעפטל אָדער `None` אויב עס איז ליידיק.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// רעטורנס אַ מיוטאַבאַל טייַטל צו די לעצטע נומער אין דער רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// קערט אַ רעפֿערענץ צו אַן עלעמענט אָדער סובסליסע דיפּענדינג אויף די טיפּ פון אינדעקס.
    ///
    /// - אויב עס איז באַשטימט אַ שטעלע, קערט אַ רעפֿערענץ צו די עלעמענט אין דער שטעלע אָדער `None` אויב עס איז אַרויס פון גווול.
    ///
    /// - אויב עס איז אַ קייט, קערט די סובסליסע קאָראַספּאַנדינג צו די קייט, אָדער `None` אויב עס איז ניט באַונד.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו אַן עלעמענט אָדער סובסליסע דיפּענדינג אויף די טיפּ פון אינדעקס (זען קס 01 קס) אָדער קס 00 קס אויב דער אינדעקס איז אויס פון גווול.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// רעטורנס אַ רעפֿערענץ צו אַן עלעמענט אָדער סובסליסע, אָן דורכקוקן גווול.
    ///
    /// פֿאַר אַ זיכער אנדער ברירה, זען [`get`].
    ///
    /// # Safety
    ///
    /// רופן דעם אופֿן מיט אַ ויסבייג אינדעקס איז *[ונדעפינעד נאַטור]* אפילו אויב די ריזאַלטינג דערמאָנען איז נישט געניצט.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // זיכערקייט: די קאַללער מוזן אַפּכאָולד רובֿ פון די זיכערקייַט באדערפענישן פֿאַר קס 00 קס;
        // די רעפטל איז דערעפערענסאַבלע ווייַל קס 00 קס איז אַ זיכער רעפֿערענץ.
        // די אומגעקערט טייַטל איז זיכער ווייַל `SliceIndex` ימפּלייז האָבן צו גאַראַנטירן אַז עס איז.
        unsafe { &*index.get_unchecked(self) }
    }

    /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו אַן עלעמענט אָדער סובסליסע, אָן דורכקוקן גווול.
    ///
    /// פֿאַר אַ זיכער אנדער ברירה, זען [`get_mut`].
    ///
    /// # Safety
    ///
    /// רופן דעם אופֿן מיט אַ ויסבייג אינדעקס איז *[ונדעפינעד נאַטור]* אפילו אויב די ריזאַלטינג דערמאָנען איז נישט געניצט.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // זיכערקייט: די קאַללער מוזן אַפּכאָולד די זיכערקייַט באדערפענישן פֿאַר קס 00 קס;
        // די רעפטל איז דערעפערענסאַבלע ווייַל קס 00 קס איז אַ זיכער רעפֿערענץ.
        // די אומגעקערט טייַטל איז זיכער ווייַל `SliceIndex` ימפּלייז האָבן צו גאַראַנטירן אַז עס איז.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// קערט אַ רוי טייַטל צו די באַפער פון די רעפטל.
    ///
    /// די קאַללער מוזן ענשור אַז די רעפטל אַוטלייווז די טייַטל די פֿונקציע קערט, אָדער אַנדערש עס וועט אָנווייַזן מיסט.
    ///
    /// דער קאָלער דאַרף אויך ענשור אַז די זכּרון צו וואָס דער טייַטל קס 00 קס ווייזט צו איז קיינמאָל געשריבן צו (אַחוץ אין אַ קס 01 קס) ניצן דעם טייַטל אָדער קיין טייַטל דערייווד פון אים.
    /// אויב איר דאַרפֿן צו מיוטייט די אינהאַלט פון די רעפטל, נוצן [`as_mut_ptr`].
    ///
    /// אויב איר מאַדאַפייינג דעם קאַנטיינער וואָס די רעפטל איז ריפערד צו, עס קען זיין ריאַלאָוקייטיד זיין באַפער, וואָס קען אויך מאַכן קיין פּוינטערז פאַרקריפּלט.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// קערט אַ אַנסייף מיוטאַבאַל טייַטל צו די באַפער פון די רעפטל.
    ///
    /// די קאַללער מוזן ענשור אַז די רעפטל אַוטלייווז די טייַטל די פֿונקציע קערט, אָדער אַנדערש עס וועט אָנווייַזן מיסט.
    ///
    /// אויב איר מאַדאַפייינג דעם קאַנטיינער וואָס די רעפטל איז ריפערד צו, עס קען זיין ריאַלאָוקייטיד זיין באַפער, וואָס קען אויך מאַכן קיין פּוינטערז פאַרקריפּלט.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// רעטורנס די צוויי רוי פּוינטערז ספּאַנינג די רעפטל.
    ///
    /// די אומגעקערט קייט איז האַלב-עפענען, וואָס מיטל אַז דער סוף טייַטל ווייזט *איינער פאַרגאַנגענהייט* די לעצטע עלעמענט פון דער רעפטל.
    /// אויף דעם וועג, אַ ליידיק רעפטל איז רעפּריזענטיד דורך צוויי גלייַך פּוינטערז, און די חילוק צווישן די צוויי פּוינטערז רעפּראַזענץ די גרייס פון דער רעפטל.
    ///
    /// וואָרענען וועגן קס 00 קס פֿאַר וואָרנינגז וועגן ניצן די פּוינטערז.דער סוף טייַטל ריקווייערז עקסטרע וואָרענען, ווייַל עס קען נישט ווייַזן אַ גילטיק עלעמענט אין דער רעפטל.
    ///
    /// די פֿונקציע איז נוציק פֿאַר ינטעראַקטינג מיט פרעמד ינטערפייסיז וואָס נוצן צוויי פּוינטערז צו אָפּשיקן צו אַ נומער פון עלעמענטן אין זכּרון, ווי געוויינטלעך אין C++ .
    ///
    ///
    /// עס קען אויך זיין נוציק צו קאָנטראָלירן אויב אַ טייַטל צו אַן עלעמענט רעפערס צו אַן עלעמענט פון דעם רעפטל:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // זיכערקייט: די `add` דאָ איז זיכער ווייַל:
        //
        //   - ביידע פּוינטערז זענען טייל פון דער זעלביקער כייפעץ, ווייַל ווייזט גלייַך צו די כייפעץ אויך קאַונץ.
        //
        //   - די גרייס פון דער רעפטל איז קיינמאָל גרעסער ווי isize::MAX ביטעס, ווי דאָ:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - עס איז ניט ראַפּינג ינוואַלווד, ווייַל סלייסאַז טאָן ניט פאַרלייגן די סוף פון די אַדרעס פּלאַץ.
        //
        // זען די דאַקיומענטיישאַן פון קס 00 קס.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// רעטורנס די צוויי אַנסייף מיוטאַבאַל פּוינטערז ספּאַנינג די רעפטל.
    ///
    /// די אומגעקערט קייט איז האַלב-עפענען, וואָס מיטל אַז דער סוף טייַטל ווייזט *איינער פאַרגאַנגענהייט* די לעצטע עלעמענט פון דער רעפטל.
    /// אויף דעם וועג, אַ ליידיק רעפטל איז רעפּריזענטיד דורך צוויי גלייַך פּוינטערז, און די חילוק צווישן די צוויי פּוינטערז רעפּראַזענץ די גרייס פון דער רעפטל.
    ///
    /// וואָרענען וועגן קס 00 קס פֿאַר וואָרנינגז וועגן ניצן די פּוינטערז.
    /// דער סוף טייַטל ריקווייערז עקסטרע וואָרענען, ווייַל עס קען נישט ווייַזן אַ גילטיק עלעמענט אין דער רעפטל.
    ///
    /// די פֿונקציע איז נוציק פֿאַר ינטעראַקטינג מיט פרעמד ינטערפייסיז וואָס נוצן צוויי פּוינטערז צו אָפּשיקן צו אַ נומער פון עלעמענטן אין זכּרון, ווי געוויינטלעך אין C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // זיכערקייט: זען as_ptr_range() אויבן פֿאַר וואָס `add` דאָ איז זיכער.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// סוואַפּס צוויי עלעמענטן אין דער רעפטל.
    ///
    /// # Arguments
    ///
    /// * אַ, דער אינדעקס פון דער ערשטער עלעמענט
    /// * ב, דער אינדעקס פון די רגע עלעמענט
    ///
    /// # Panics
    ///
    /// Panics אויב קס 00 קס אָדער קס 01 קס זענען אויס פון גווול.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // איר קענט נישט נעמען צוויי מיוטאַבאַל לאָונז פון איין ז 0 וועקטאָר 0 ז, אַזוי אַנשטאָט נוצן רוי פּוינטערז.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // זיכערקייט: קס 00 קס און קס 01 קס זענען באשאפן פֿון זיכער מיוטאַבאַל באַווייַזן און אָפּשיקן
        // צו עלעמענטן אין דער רעפטל און דעריבער זענען געראַנטיד צו זיין גילטיק און אַליינד.
        // באַמערקונג אַז אַקסעס צו די עלעמענטן הינטער קס 00 קס און קס 01 קס איז אָפּגעשטעלט און וועט ז 0 פּאַניק 0 ז ווען אויס פון גווול.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// ריווערסאַז די סדר פון עלעמענטן אין דער רעפטל, אין פּלאַץ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // פֿאַר זייער קליין טייפּס, אַלע מענטשן לייענען די נאָרמאַל וועג דורכפירן שוואַך.
        // מיר קענען טאָן בעסער, מיט עפעקטיוו אַנאַליינד קס 00 קס, דורך לאָודינג אַ גרעסערע פּייַדע און ריווערסינג אַ רעגיסטרירן.
        //

        // ידעאַללי LLVM וואָלט טאָן דאָס פֿאַר אונדז, ווייַל עס ווייסט בעסער ווי מיר טאָן צי אַנאַליינד לייז זענען עפעקטיוו (ווייַל דאָס ענדערונגען צווישן פאַרשידענע אָרעם ווערסיעס, פֿאַר בייַשפּיל) און וואָס דער בעסטער פּייַדע גרייס וואָלט זיין.
        // צום באַדויערן, פֿון LLVM 4.0 (2017-05), עס נאָר אַנראָללס די שלייף, אַזוי מיר דאַרפֿן צו טאָן דאָס זיך.
        // (היפּאָטהעסיס: פאַרקערט איז טראַבאַלסאַם ווייַל די זייטן קענען זיין אַליינד אַנדערש-עס וועט זיין ווען די לענג איז מאָדנע-אַזוי עס איז קיין וועג צו אַרויסלאָזן פאַר-און פּאָסטולוז צו נוצן סימד אין די מיטל.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // ניצן די llvm.bswap ינטרינסיק צו פאַרקערט u8s אין אַ נוצן
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // זיכערקייט: עס זענען עטלעכע טינגז צו קאָנטראָלירן דאָ:
                //
                // - באַמערקונג אַז `chunk` איז 4 אָדער 8 רעכט צו די CFG טשעק אויבן.`chunk - 1` איז אַזוי positive.
                // - ינדעקסינג מיט אינדעקס `i` איז פייַן ווי די לופּ טשעק געראַנטיז
                //   `i + chunk - 1 < ln / 2`
                //   <=> קס 00 קס.
                // - ינדעקסינג מיט אינדעקס קס 00 קס איז פייַן:
                //   - `i + chunk > 0` איז טריוויאַללי אמת.
                //   - די שלייף טשעק געראַנטיז:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, אַזוי כיסער קען נישט אַנדערפלאָו.
                // - די `read_unaligned` און `write_unaligned` קאַללס זענען פייַן:
                //   - `pa` ווייזט צו אינדעקס קס 02 קס ווו קס 03 קס (זען אויבן) און קס 04 קס ווייזט אויף אינדעקס קס 01 קס, אַזוי ביידע זענען לפּחות קס 05 קס פילע ביטעס אַוועק פון די סוף פון קס 00 קס.
                //
                //   - ינישאַלייזד זכּרון איז גילטיק `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // ניצן דרייען ביי 16 צו פאַרקערט U16s אין אַ u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // זיכערהייט: `i` קענען זיין אַנליינד פֿון `i` אויב `i + 1 < ln`
                // (און דאָך `i < ln`), ווייַל יעדער עלעמענט איז 2 ביטעס און מיר לייענען 4.
                //
                // `i + chunk - 1 < ln / 2` # בשעת צושטאַנד
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // זינט עס איז ווייניקער ווי די לענג צעטיילט דורך 2, עס מוזן זיין אין גווול.
                //
                // דאָס אויך מיינט אַז דער צושטאַנד `0 < i + chunk <= ln` איז שטענדיק רעספּעקטעד, ינשורינג די `pb` טייַטל קענען זיין געוויינט בעשאָלעם.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // זיכערקייט: קס 00 קס איז ערגער צו האַלב די לענג פון די רעפטל אַזוי
            // אַקסעס `i` און `ln - i - 1` איז זיכער (`i` סטאַרץ ביי 0 און וועט ניט גיין ווייַטער ווי `ln / 2 - 1`).
            // די ריזאַלטינג פּוינטערז קס 00 קס און קס 01 קס זענען דעריבער גילטיק און אַליינד, און קענען זיין לייענען פֿון און געשריבן צו.
            //
            //
            unsafe {
                // אַנסייף ויסבייַטן צו ויסמיידן די גווול טשעק אין זיכער ויסבייַטן.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// קערט אַ יטעראַטאָר איבער די רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// קערט אַ יטעראַטאָר אַז אַלאַוז מאַדאַפייינג יעדער ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// קערט אַ יטעראַטאָר איבער אַלע קאַנטיגיואַס קס 01 קס לענג קס 00 קס.
    /// די קס 00 קס אָוווערלאַפּ.
    /// אויב די רעפטל איז קירצער ווי קס 00 קס, די יטעראַטאָר קערט קיין וואַלועס.
    ///
    /// # Panics
    ///
    /// Panics אויב `size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אויב די רעפטל איז קירצער ווי `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// קערט אַ יטעראַטאָר איבער קס 00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    /// די טשאַנגקס זענען סלייסיז און טאָן ניט אָוווערלאַפּ.אויב קס 01 קס נישט צעטיילן די לענג פון די רעפטל, די לעצטע פּייַדע וועט נישט האָבן די לענג קס 00 קס.
    ///
    /// זען קס 00 קס פֿאַר אַ ווערייישאַן פון דעם יטעראַטאָר אַז קערט טשאַנגקס פון שטענדיק פּונקט X 01 קס עלעמענטן, און קס 02 קס פֿאַר די זעלבע יטעראַטאָר, אָבער סטאַרטינג אין די סוף פון די רעפטל.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// קערט אַ יטעראַטאָר איבער קס 00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    /// די טשאַנגקס זענען מיוטאַבאַל סלייסאַז און טאָן ניט אָוווערלאַפּ.אויב קס 01 קס נישט צעטיילן די לענג פון די רעפטל, די לעצטע פּייַדע וועט נישט האָבן די לענג קס 00 קס.
    ///
    /// זען קס 00 קס פֿאַר אַ ווערייישאַן פון דעם יטעראַטאָר אַז קערט טשאַנגקס פון שטענדיק פּונקט X 01 קס עלעמענטן, און קס 02 קס פֿאַר די זעלבע יטעראַטאָר, אָבער סטאַרטינג אין די סוף פון די רעפטל.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// קערט אַ יטעראַטאָר איבער קס 00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    /// די טשאַנגקס זענען סלייסיז און טאָן ניט אָוווערלאַפּ.
    /// אויב `chunk_size` צעטיילט נישט די לענג פון די רעפטל, די לעצטע אַרויף צו `chunk_size-1` עלעמענטן וועט זיין איבערגעהיפּערט און קענען זיין ריטריווד פֿון די `remainder` פונקציע פון יטעראַטאָר.
    ///
    ///
    /// ווייַל יעדער פּייַדע האט פּונקט X01 קס עלעמענטן, די קאַמפּיילער קענען אָפט אַפּטאַמייז די ריזאַלטינג קאָד בעסער ווי אין די פאַל פון [`chunks`].
    ///
    /// זען קס 00 קס פֿאַר אַ ווערייישאַן פון דעם יטעראַטאָר וואָס אויך קערט די רעשט ווי אַ קלענערער פּייַדע, און קס 01 קס פֿאַר דער זעלביקער יטעראַטאָר, אָבער סטאַרטינג אין די סוף פון די רעפטל.
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// קערט אַ יטעראַטאָר איבער קס 00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    /// די טשאַנגקס זענען מיוטאַבאַל סלייסאַז און טאָן ניט אָוווערלאַפּ.
    /// אויב `chunk_size` צעטיילט נישט די לענג פון די רעפטל, די לעצטע אַרויף צו `chunk_size-1` עלעמענטן וועט זיין איבערגעהיפּערט און קענען זיין ריטריווד פֿון די `into_remainder` פונקציע פון יטעראַטאָר.
    ///
    ///
    /// ווייַל יעדער פּייַדע האט פּונקט X01 קס עלעמענטן, די קאַמפּיילער קענען אָפט אַפּטאַמייז די ריזאַלטינג קאָד בעסער ווי אין די פאַל פון [`chunks_mut`].
    ///
    /// זען קס 00 קס פֿאַר אַ ווערייישאַן פון דעם יטעראַטאָר אַז אויך קערט די רעשט ווי אַ קלענערער פּייַדע, און קס 01 קס פֿאַר די זעלבע יטעראַטאָר, אָבער סטאַרטינג אין די סוף פון די רעפטל.
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// ספּליץ די רעפטל אין אַ רעפטל פון `N`-עלעמענט ערייז, אַסומינג אַז עס איז קיין רעשט.
    ///
    ///
    /// # Safety
    ///
    /// דאָס קען נאָר זיין גערופן ווען
    /// - די רעפטל ספּליץ פּונקט אין `N`-עלעמענט טשאַנגקס (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // זיכערקייט: 1-עלעמענט טשאַנגקס קיינמאָל האָבן רעשט
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // זיכערקייט: די סלייס לענג קס 00 קס איז אַ קייפל פון 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // די וואָלט זיין ומבאַקוועם:
    /// // לאָזן טשאַנגקס: &[[_;5]]= slice.as_chunks_unchecked()//די סלייס לענג איז נישט אַ קייפל פון 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked()//נול-לענג טשאַנגקס זענען קיינמאָל ערלויבט
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // זיכערקייט: אונדזער פּריקאַנדישאַן איז פּונקט וואָס איז דארף צו רופן דעם
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // זיכערהייט: מיר וואַרפן אַ רעפטל פון `new_len * N` עלעמענטן
        // אַ רעפטל פון קס 00 קס פילע קס 01 קס עלעמענטן טשאַנגקס.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// ספּליץ די רעפטל אין אַ רעפטל פון `N`-עלעמענט ערייז, סטאַרטינג אין די אָנהייב פון די רעפטל, און אַ רעשט רעפטל מיט לענג שטרענג ווייניקער ווי קס 00 קס.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `N` איז 0. דעם טשעק וועט מיסטאָמע ווערן געביטן צו אַ צונויפנעמען צייט טעות איידער דעם אופֿן איז סטייבאַלייזד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // זיכערקייט: מיר האָבן שוין פּאַניק פֿאַר נול און ינשורד דורך קאַנסטראַקשאַן
        // אַז די לענג פון די סובסליסע איז אַ קייפל פון N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// ספּליץ די רעפטל אין אַ רעפטל פון `N`-עלעמענט ערייז, סטאַרטינג אין די סוף פון די רעפטל, און אַ רעשט רעפטל מיט לענג שטרענג ווייניקער ווי קס 00 קס.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `N` איז 0. דעם טשעק וועט מיסטאָמע ווערן געביטן צו אַ צונויפנעמען צייט טעות איידער דעם אופֿן איז סטייבאַלייזד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // זיכערקייט: מיר האָבן שוין פּאַניק פֿאַר נול און ינשורד דורך קאַנסטראַקשאַן
        // אַז די לענג פון די סובסליסע איז אַ קייפל פון N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// קערט אַ יטעראַטאָר איבער קס 00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    /// די טשאַנגקס זענען מענגע באַווייַזן און טאָן ניט אָוווערלאַפּ.
    /// אויב `N` צעטיילט נישט די לענג פון די רעפטל, די לעצטע אַרויף צו `N-1` עלעמענטן וועט זיין איבערגעהיפּערט און קענען זיין ריטריווד פֿון די `remainder` פונקציע פון יטעראַטאָר.
    ///
    ///
    /// די מעטהאָדס איז די קאַנסטריישאַן פון די [`chunks_exact`] X קס.
    ///
    /// # Panics
    ///
    /// Panics אויב `N` איז 0. דעם טשעק וועט מיסטאָמע ווערן געביטן צו אַ צונויפנעמען צייט טעות איידער דעם אופֿן איז סטייבאַלייזד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// ספּליץ די רעפטל אין אַ רעפטל פון `N`-עלעמענט ערייז, אַסומינג אַז עס איז קיין רעשט.
    ///
    ///
    /// # Safety
    ///
    /// דאָס קען נאָר זיין גערופן ווען
    /// - די רעפטל ספּליץ פּונקט אין `N`-עלעמענט טשאַנגקס (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // זיכערקייט: 1-עלעמענט טשאַנגקס קיינמאָל האָבן רעשט
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // זיכערקייט: די סלייס לענג קס 00 קס איז אַ קייפל פון 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // די וואָלט זיין ומבאַקוועם:
    /// // לאָזן טשאַנגקס: &[[_;5]]= slice.as_chunks_unchecked_mut()//די סלייס לענג איז נישט אַ קייפל פון 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//נול-לענג טשאַנגקס זענען קיינמאָל ערלויבט
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // זיכערקייט: אונדזער פּריקאַנדישאַן איז פּונקט וואָס איז דארף צו רופן דעם
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // זיכערהייט: מיר וואַרפן אַ רעפטל פון `new_len * N` עלעמענטן
        // אַ רעפטל פון קס 00 קס פילע קס 01 קס עלעמענטן טשאַנגקס.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// ספּליץ די רעפטל אין אַ רעפטל פון `N`-עלעמענט ערייז, סטאַרטינג אין די אָנהייב פון די רעפטל, און אַ רעשט רעפטל מיט לענג שטרענג ווייניקער ווי קס 00 קס.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `N` איז 0. דעם טשעק וועט מיסטאָמע ווערן געביטן צו אַ צונויפנעמען צייט טעות איידער דעם אופֿן איז סטייבאַלייזד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // זיכערקייט: מיר האָבן שוין פּאַניק פֿאַר נול און ינשורד דורך קאַנסטראַקשאַן
        // אַז די לענג פון די סובסליסע איז אַ קייפל פון N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// ספּליץ די רעפטל אין אַ רעפטל פון `N`-עלעמענט ערייז, סטאַרטינג אין די סוף פון די רעפטל, און אַ רעשט רעפטל מיט לענג שטרענג ווייניקער ווי קס 00 קס.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `N` איז 0. דעם טשעק וועט מיסטאָמע ווערן געביטן צו אַ צונויפנעמען צייט טעות איידער דעם אופֿן איז סטייבאַלייזד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // זיכערקייט: מיר האָבן שוין פּאַניק פֿאַר נול און ינשורד דורך קאַנסטראַקשאַן
        // אַז די לענג פון די סובסליסע איז אַ קייפל פון N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// קערט אַ יטעראַטאָר איבער קס 00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    /// די טשאַנגקס זענען מיוטאַבאַל מענגע באַווייַזן און טאָן ניט אָוווערלאַפּ.
    /// אויב `N` צעטיילט נישט די לענג פון די רעפטל, די לעצטע אַרויף צו `N-1` עלעמענטן וועט זיין איבערגעהיפּערט און קענען זיין ריטריווד פֿון די `into_remainder` פונקציע פון יטעראַטאָר.
    ///
    ///
    /// די מעטהאָדס איז די קאַנסטריישאַן פון די [`chunks_exact_mut`] X קס.
    ///
    /// # Panics
    ///
    /// Panics אויב `N` איז 0. דעם טשעק וועט מיסטאָמע ווערן געביטן צו אַ צונויפנעמען צייט טעות איידער דעם אופֿן איז סטייבאַלייזד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// קערט אַ יטעראַטאָר איבער אָוווערלאַפּינג קס 00 קס פון קס 01 קס עלעמענטן פון אַ רעפטל, סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    ///
    /// דאָס איז דער קאַנסטרידזשיוואַנסט עקסטענסיוו פון [`windows`].
    ///
    /// אויב קס 01 קס איז גרעסער ווי די גרייס פון דער רעפטל, עס וועט ניט צוריקקומען קיין קס 00 קס.
    ///
    /// # Panics
    ///
    /// Panics אויב `N` איז 0.
    /// דער טשעק וועט מיסטאָמע טוישן צו אַ קאָמפּילע צייט טעות איידער דעם אופֿן איז סטייבאַלייזד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// קערט אַ יטעראַטאָר איבער X00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די סוף פון די רעפטל.
    ///
    /// די טשאַנגקס זענען סלייסיז און טאָן ניט אָוווערלאַפּ.אויב קס 01 קס נישט צעטיילן די לענג פון די רעפטל, די לעצטע פּייַדע וועט נישט האָבן די לענג קס 00 קס.
    ///
    /// זען קס 00 קס פֿאַר אַ וואַריאַנט פון דעם יטעראַטאָר אַז קערט טשאַנגקס פון שטענדיק פּונקט X 01 קס עלעמענטן, און קס 02 קס פֿאַר דער זעלביקער יטעראַטאָר אָבער סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// קערט אַ יטעראַטאָר איבער X00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די סוף פון די רעפטל.
    ///
    /// די טשאַנגקס זענען מיוטאַבאַל סלייסאַז און טאָן ניט אָוווערלאַפּ.אויב קס 01 קס נישט צעטיילן די לענג פון די רעפטל, די לעצטע פּייַדע וועט נישט האָבן די לענג קס 00 קס.
    ///
    /// זען קס 00 קס פֿאַר אַ וואַריאַנט פון דעם יטעראַטאָר אַז קערט טשאַנגקס פון שטענדיק פּונקט X 01 קס עלעמענטן, און קס 02 קס פֿאַר דער זעלביקער יטעראַטאָר אָבער סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// קערט אַ יטעראַטאָר איבער X00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די סוף פון די רעפטל.
    ///
    /// די טשאַנגקס זענען סלייסיז און טאָן ניט אָוווערלאַפּ.
    /// אויב `chunk_size` צעטיילט נישט די לענג פון די רעפטל, די לעצטע אַרויף צו `chunk_size-1` עלעמענטן וועט זיין איבערגעהיפּערט און קענען זיין ריטריווד פֿון די `remainder` פונקציע פון יטעראַטאָר.
    ///
    /// ווייַל יעדער פּייַדע האט פּונקט X01 קס עלעמענטן, די קאַמפּיילער קענען אָפט אַפּטאַמייז די ריזאַלטינג קאָד בעסער ווי אין די פאַל פון [`chunks`].
    ///
    /// זען קס 00 קס פֿאַר אַ ווערייישאַן פון דעם יטעראַטאָר וואָס אויך קערט די רעשט ווי אַ קלענערער פּייַדע, און קס 01 קס פֿאַר דער זעלביקער יטעראַטאָר, אָבער סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// קערט אַ יטעראַטאָר איבער X00 קס עלעמענטן פון דער רעפטל אין אַ צייט, סטאַרטינג אין די סוף פון די רעפטל.
    ///
    /// די טשאַנגקס זענען מיוטאַבאַל סלייסאַז און טאָן ניט אָוווערלאַפּ.
    /// אויב `chunk_size` צעטיילט נישט די לענג פון די רעפטל, די לעצטע אַרויף צו `chunk_size-1` עלעמענטן וועט זיין איבערגעהיפּערט און קענען זיין ריטריווד פֿון די `into_remainder` פונקציע פון יטעראַטאָר.
    ///
    /// ווייַל יעדער פּייַדע האט פּונקט X01 קס עלעמענטן, די קאַמפּיילער קענען אָפט אַפּטאַמייז די ריזאַלטינג קאָד בעסער ווי אין די פאַל פון [`chunks_mut`].
    ///
    /// זען קס 00 קס פֿאַר אַ ווערייישאַן פון דעם יטעראַטאָר אַז אויך קערט די רעשט ווי אַ קלענערער פּייַדע, און קס 01 קס פֿאַר דער זעלביקער יטעראַטאָר, אָבער סטאַרטינג אין די אָנהייב פון די רעפטל.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב `chunk_size` איז 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// רעטורנס אַ יטעראַטאָר איבער די רעפטל וואָס פּראָדוצירן ניט-אָוווערלאַפּינג ראַנז פון עלעמענטן מיט די פּרעדיקאַט צו צעטיילן זיי.
    ///
    /// די פּרעדיקאַט איז גערופֿן אויף צוויי עלעמענטן ווייַטערדיק זיך, עס מיטל אַז די פּרעדיקאַט איז גערופֿן אויף קס 00 קס און קס 01 קס דעמאָלט אויף קס 02 קס און קס 03 קס און אַזוי אויף.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// דעם אופֿן קענען ווערן גענוצט צו עקסטראַקט די סאָרטעד סאַבסלייזיז:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// קערט אַ יטעראַטאָר איבער די רעפטל, און פּראָדוצירן ניט-אָוווערלאַפּינג מיוטאַבאַל ראַנז פון עלעמענטן מיט די פּרעדיקאַט צו צעטיילן זיי.
    ///
    /// די פּרעדיקאַט איז גערופֿן אויף צוויי עלעמענטן ווייַטערדיק זיך, עס מיטל אַז די פּרעדיקאַט איז גערופֿן אויף קס 00 קס און קס 01 קס דעמאָלט אויף קס 02 קס און קס 03 קס און אַזוי אויף.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// דעם אופֿן קענען ווערן גענוצט צו עקסטראַקט די סאָרטעד סאַבסלייזיז:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// צעטיילט איין רעפטל אין צוויי ביי אַן אינדעקס.
    ///
    /// דער ערשטער כּולל אַלע ינדיסיז פון קס 00 קס (עקסקלודינג די אינדעקס קס 01 קס זיך) און די רגע וועט אַנטהאַלטן אַלע ינדיסיז פון קס 02 קס (עקסקלודינג דער אינדעקס קס 03 קס זיך).
    ///
    ///
    /// # Panics
    ///
    /// ז 0 פּאַניקס 0 ז אויב קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // זיכערקייט: קס 01 קס און קס 02 קס זענען ין קס 00 קס, וואָס
        // פולפילז די רעקווירעמענץ פון קס 00 קס.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// צעטיילט איין מוטאַבלע רעפטל אין צוויי אויף אַן אינדעקס.
    ///
    /// דער ערשטער כּולל אַלע ינדיסיז פון קס 00 קס (עקסקלודינג די אינדעקס קס 01 קס זיך) און די רגע וועט אַנטהאַלטן אַלע ינדיסיז פון קס 02 קס (עקסקלודינג דער אינדעקס קס 03 קס זיך).
    ///
    ///
    /// # Panics
    ///
    /// ז 0 פּאַניקס 0 ז אויב קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // זיכערקייט: קס 01 קס און קס 02 קס זענען ין קס 00 קס, וואָס
        // פולפילז די רעקווירעמענץ פון קס 00 קס.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// צעטיילט איין רעפטל אין צוויי אין אַן אינדעקס, אָן דורכקוקן גווול.
    ///
    /// דער ערשטער כּולל אַלע ינדיסיז פון קס 00 קס (עקסקלודינג די אינדעקס קס 01 קס זיך) און די רגע וועט אַנטהאַלטן אַלע ינדיסיז פון קס 02 קס (עקסקלודינג דער אינדעקס קס 03 קס זיך).
    ///
    ///
    /// פֿאַר אַ זיכער אנדער ברירה, זען [`split_at`].
    ///
    /// # Safety
    ///
    /// רופן דעם אופֿן מיט אַ ויסבייג אינדעקס איז *[ונדעפינעד נאַטור]* אפילו אויב די ריזאַלטינג דערמאָנען איז נישט געניצט.די קאַללער האט צו ענשור אַז `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // זיכערהייט: קאַללער מוזן קאָנטראָלירן אַז `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// צעטיילט איין מיוטאַבאַל רעפטל אין צוויי אין אַן אינדעקס אָן קאָנטראָלירונג פון גווול.
    ///
    /// דער ערשטער כּולל אַלע ינדיסיז פון קס 00 קס (עקסקלודינג די אינדעקס קס 01 קס זיך) און די רגע וועט אַנטהאַלטן אַלע ינדיסיז פון קס 02 קס (עקסקלודינג דער אינדעקס קס 03 קס זיך).
    ///
    ///
    /// פֿאַר אַ זיכער אנדער ברירה, זען [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// רופן דעם אופֿן מיט אַ ויסבייג אינדעקס איז *[ונדעפינעד נאַטור]* אפילו אויב די ריזאַלטינג דערמאָנען איז נישט געניצט.די קאַללער האט צו ענשור אַז `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // זיכערהייט: קאַללער מוזן קאָנטראָלירן אַז `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` און `[mid; len]` זענען נישט אָוווערלאַפּינג, אַזוי צוריקקומען פון אַ מיוטאַבאַל רעפֿערענץ איז פייַן.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// קערט אַ יטעראַטאָר איבער סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן `pred`.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אויב דער ערשטער עלעמענט איז גלייַכן, אַ ליידיק רעפטל איז דער ערשטער יטעמס פֿון יטעראַטאָר.
    /// סימילאַרלי, אויב די לעצטע עלעמענט אין די רעפטל איז גלייַכן, אַ ליידיק רעפטל איז די לעצטע נומער פֿון יטעראַטאָר:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אויב צוויי מאַטשט עלעמענטן זענען גלייַך שכייניש, עס וועט זיין אַ ליידיק רעפטל צווישן זיי:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// קערט אַ יטעראַטאָר איבער מיוטאַבאַל סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן `pred`.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// קערט אַ יטעראַטאָר איבער סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן `pred`.
    /// די מאַטשט עלעמענט איז קאַנטיינד אין די סוף פון די פריערדיקע סובסליסע ווי אַ טערמינאַטאָר.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// אויב די לעצטע עלעמענט פון דער רעפטל איז גלייַכן, דער עלעמענט וועט ווערן באטראכט ווי דער טערמינאַטאָר פון די פריערדיקע רעפטל.
    ///
    /// די רעפטל איז די לעצטע נומער פֿון יטעראַטאָר.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// קערט אַ יטעראַטאָר איבער מיוטאַבאַל סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן `pred`.
    /// די מאַטשט עלעמענט איז קאַנטיינד אין די פריערדיקע סובסליסע ווי אַ טערמינאַטאָר.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// קערט אַ יטעראַטאָר איבער סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן `pred`, סטאַרטינג אין די סוף פון די רעפטל און אַרבעט קאַפּויער.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ווי מיט `split()`, אויב דער ערשטער אָדער לעצט עלעמענט איז גלייַכן, אַ ליידיק רעפטל איז דער ערשטער (אָדער לעצט) נומער וואָס איז יטעראַטאָר אומגעקערט.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// קערט אַ יטעראַטאָר איבער מיוטאַבאַל סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן `pred`, סטאַרטינג אין די סוף פון די רעפטל און אַרבעט קאַפּויער.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// קערט אַ יטעראַטאָר איבער סובסליקעס אפגעשיידט דורך עלעמענטן וואָס גלייַכן קס 00 קס, לימיטעד צו צוריקקומען צו רובֿ קס 01 קס ייטאַמז.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// די לעצטע עלעמענט אומגעקערט, אויב עס איז, וועט אַנטהאַלטן די רעשט פון די רעפטל.
    ///
    /// # Examples
    ///
    /// דרוקן די רעפטל שפּאַלטן איין מאָל מיט נומערן דיטיילאַבאַל דורך 3 (ד"ה, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// קערט אַ יטעראַטאָר איבער סובסליקעס אפגעשיידט דורך עלעמענטן וואָס גלייַכן קס 00 קס, לימיטעד צו צוריקקומען צו רובֿ קס 01 קס ייטאַמז.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// די לעצטע עלעמענט אומגעקערט, אויב עס איז, וועט אַנטהאַלטן די רעשט פון די רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// קערט אַ יטעראַטאָר איבער סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן קס 00 קס לימיטעד צו צוריקקומען צו רובֿ קס 01 קס ייטאַמז.
    /// דעם סטאַרץ אין די סוף פון די רעפטל און אַרבעט קאַפּויער.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// די לעצטע עלעמענט אומגעקערט, אויב עס איז, וועט אַנטהאַלטן די רעשט פון די רעפטל.
    ///
    /// # Examples
    ///
    /// פּרינט די רעפטל שפּאַלטן אַמאָל, סטאַרטינג פון די סוף, דורך נומערן דיווייזאַבאַל דורך 3 (ד"ה, קס 00 קס, קס 01 קס):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// קערט אַ יטעראַטאָר איבער סאַבסלייזיז אפגעשיידט דורך עלעמענטן וואָס גלייַכן קס 00 קס לימיטעד צו צוריקקומען צו רובֿ קס 01 קס ייטאַמז.
    /// דעם סטאַרץ אין די סוף פון די רעפטל און אַרבעט קאַפּויער.
    /// די מאַטשט עלעמענט איז ניט קאַנטיינד אין די סאַבסלייזיז.
    ///
    /// די לעצטע עלעמענט אומגעקערט, אויב עס איז, וועט אַנטהאַלטן די רעשט פון די רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// קערט `true` אויב די רעפטל כּולל אַן עלעמענט מיט די געגעבן ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// אויב איר טאָן ניט האָבן אַ קס 00 קס, אָבער נאָר אַ קס 01 קס אַזאַ ווי קס 02 קס (למשל
    /// שטריקל: באָרגן<str>'), איר קענען נוצן `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // רעפטל פון קס 00 קס
    /// assert!(v.iter().any(|e| e == "hello")); // זוכן מיט `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// קערט `true` אויב `needle` איז אַ פּרעפיקס פון די רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// שטענדיק קערט `true` אויב `needle` איז אַ ליידיק רעפטל:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// קערט `true` אויב `needle` איז אַ סאַפיקס פון דער רעפטל.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// שטענדיק קערט `true` אויב `needle` איז אַ ליידיק רעפטל:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// קערט אַ סובסליסע מיט די פּרעפיקס אַוועקגענומען.
    ///
    /// אויב די רעפטל סטאַרץ מיט `prefix`, קערט די סובסליסע נאָך די פּרעפיקס, אלנגעוויקלט אין `Some`.
    /// אויב `prefix` איז ליידיק, נאָר קערט דער אָריגינעל רעפטל.
    ///
    /// אויב די רעפטל טוט נישט אָנהייבן מיט `prefix`, קערט `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // די פֿונקציע וועט דאַרפֿן רירייטינג אויב און ווען SlicePattern ווערט מער סאַפיסטאַקייטיד.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// קערט אַ סובסליסע מיט די סאַפיקס אַוועקגענומען.
    ///
    /// אויב די רעפטל ענדס מיט `suffix`, קערט די סובסליסע איידער די סאַפיקס, אלנגעוויקלט אין `Some`.
    /// אויב `suffix` איז ליידיק, נאָר קערט דער אָריגינעל רעפטל.
    ///
    /// אויב די רעפטל ענדיקן נישט מיט `suffix`, קערט `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // די פֿונקציע וועט דאַרפֿן רירייטינג אויב און ווען SlicePattern ווערט מער סאַפיסטאַקייטיד.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// ביינערי אָנפֿרעגן דעם סאָרטעד רעפטל פֿאַר אַ געגעבן עלעמענט.
    ///
    /// אויב די ווערט איז געפֿונען, [`Result::Ok`] איז אומגעקערט מיט די אינדעקס פון די ריכטן עלעמענט.
    /// אויב עס זענען קייפל שוועבעלעך, יעדער פון די שוועבעלעך קען זיין אומגעקערט.
    /// אויב די ווערט איז ניט געפֿונען, [`Result::Err`] איז אומגעקערט מיט די אינדעקס וווּ אַ ריכטן עלעמענט קען זיין ינסערטאַד בשעת די סדר סדר.
    ///
    ///
    /// זען אויך קס 01 קס, קס 02 קס, און קס 00 קס.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// קוקט אַרויף אַ סעריע פון פיר עלעמענטן.
    /// דער ערשטער איז געפֿונען מיט אַ יינציק באשלאסן שטעלע;די רגע און דריט זענען נישט געפֿונען;די פערטע קען גלייַכן קיין שטעלע אין קס 00 קס.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// אויב איר ווילט צו שטעלן אַ נומער צו אַ סאָרטעד ז 0 וועקטאָר 0 ז, מיט די סאָרט סדר:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ביינערי אָנפֿרעגן דעם סאָרטיד רעפטל מיט אַ קאָמפּאַראַטאָר פונקציע.
    ///
    /// דער קאָמפּאַראַטאָר פונקציע זאָל ינסטרומענט אַ סדר קאָנסיסטענט מיט די סאָרט סדר פון די אַנדערלייינג רעפטל, און צוריקקומען אַ סדר קאָד וואָס ינדיקייץ צי די אַרגומענט איז `Less`, `Equal` אָדער `Greater` דער געוואלט ציל.
    ///
    ///
    /// אויב די ווערט איז געפֿונען, [`Result::Ok`] איז אומגעקערט מיט די אינדעקס פון די ריכטן עלעמענט.אויב עס זענען קייפל שוועבעלעך, יעדער פון די שוועבעלעך קען זיין אומגעקערט.
    /// אויב די ווערט איז ניט געפֿונען, [`Result::Err`] איז אומגעקערט מיט די אינדעקס וווּ אַ ריכטן עלעמענט קען זיין ינסערטאַד בשעת די סדר סדר.
    ///
    /// זען אויך קס 01 קס, קס 02 קס, און קס 00 קס.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// קוקט אַרויף אַ סעריע פון פיר עלעמענטן.דער ערשטער איז געפֿונען מיט אַ יינציק באשלאסן שטעלע;די רגע און דריט זענען נישט געפֿונען;די פערטע קען גלייַכן קיין שטעלע אין קס 00 קס.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // זיכערקייט: די רופן איז זיכער דורך די פאלגענדע ינוואַריאַנץ:
            // - `mid >= 0`
            // - `mid < size`: `mid` איז לימיטעד דורך `[left; right)` געבונדן.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // די סיבה וואָס מיר נוצן if/else קאָנטראָל לויפן אלא ווי צופּאַסן איז ווייַל גלייַכן ריאָרדערז די פאַרגלייַך אָפּעראַטיאָנס, וואָס איז פּערפעקט שפּירעוודיק.
            //
            // דאָס איז x86 אַסם פֿאַר u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// ביינערי אָנפֿרעגן דעם סאָרטעד רעפטל מיט אַ שליסל יקסטראַקשאַן פונקציע.
    ///
    /// אַסומז אַז די רעפטל איז סאָרטירט דורך די שליסל, פֿאַר בייַשפּיל מיט [`sort_by_key`] ניצן די זעלבע שליסל יקסטראַקשאַן פונקציאָנירן.
    ///
    /// אויב די ווערט איז געפֿונען, [`Result::Ok`] איז אומגעקערט מיט די אינדעקס פון די ריכטן עלעמענט.
    /// אויב עס זענען קייפל שוועבעלעך, יעדער פון די שוועבעלעך קען זיין אומגעקערט.
    /// אויב די ווערט איז ניט געפֿונען, [`Result::Err`] איז אומגעקערט מיט די אינדעקס וווּ אַ ריכטן עלעמענט קען זיין ינסערטאַד בשעת די סדר סדר.
    ///
    ///
    /// זען אויך קס 01 קס, קס 02 קס, און קס 00 קס.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// קוקט אַרויף אַ סעריע פון פיר עלעמענטן אין אַ רעפטל פון פּערז סאָרטירט דורך זייער רגע עלעמענטן.
    /// דער ערשטער איז געפֿונען מיט אַ יינציק באשלאסן שטעלע;די רגע און דריט זענען נישט געפֿונען;די פערטע קען גלייַכן קיין שטעלע אין קס 00 קס.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links איז ערלויבט ווייַל `slice::sort_by_key` איז אין crate `alloc`, און ווי אַזאַ קען עס נאָך נישט עקסיסטירן ווען איר בויען `core`.
    //
    // לינקס צו דאַונסטרים crate: #74481.זינט פּרימיטיוועס זענען בלויז דאַקיאַמענטאַד אין ליבסטד קס 01 קס, דאָס קיינמאָל פירט צו צעבראכן לינקס אין פיר.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// סאָרץ די רעפטל, אָבער קען נישט האַלטן די סדר פון גלייַך עלעמענטן.
    ///
    /// דער סאָרט איז אַנסטייבאַל (ד"ה, קען ריאָרדערינג גלייַך עלעמענטן), אין-אָרט (ד"ה קען נישט אַלאַקייט) און *O*(*N*\*log(* n*)) ערגסט פאַל.
    ///
    /// # קראַנט ימפּלאַמענטיישאַן
    ///
    /// די קראַנט אַלגערידאַם איז באזירט אויף [pattern-defeating quicksort][pdqsort] פון Orson Peters, וואָס קאַמביינז די שנעל דורכשניטלעך פאַל פון ראַנדאַמייזד קוויקסאָרט מיט די פאַסט ערגסט פאַל פון העאַפּסאָרט, בשעת דערגרייכן לינעאַר צייט אויף סלייסאַז מיט זיכער פּאַטערנז.
    /// עס ניצט עטלעכע ראַנדאַמאַזיישאַן צו ויסמיידן דידזשענערייטיד קאַסעס, אָבער מיט אַ פאַרפעסטיקט ז 0 סעעד 0 ז צו שטענדיק צושטעלן דיטערמאַניסטיק נאַטור.
    ///
    /// עס איז טיפּיקלי פאַסטער ווי סטאַביל סאָרטינג, אַחוץ אין אַ ביסל ספּעציעל קאַסעס, למשל, ווען די רעפטל באשטייט פון עטלעכע קאַנקאַטאַנייטיד סאָרטעד סיקוואַנסיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// סאָרץ די רעפטל מיט אַ קאָמפּאַראַטאָר פונקציע, אָבער קען נישט האַלטן די סדר פון גלייַך עלעמענטן.
    ///
    /// דער סאָרט איז אַנסטייבאַל (ד"ה, קען ריאָרדערינג גלייַך עלעמענטן), אין-אָרט (ד"ה קען נישט אַלאַקייט) און *O*(*N*\*log(* n*)) ערגסט פאַל.
    ///
    /// די קאָמפּאַראַטאָר פונקציע מוזן דעפינירן אַ גאַנץ אָרדערינג פֿאַר די עלעמענטן אין דער רעפטל.אויב די אָרדערינג איז נישט גאַנץ, די סדר פון די עלעמענטן איז נישט ספּעסאַפייד.א סדר איז אַ גאַנץ סדר אויב עס איז (פֿאַר אַלע קס 00 קס, קס 01 קס און קס 02 קס):
    ///
    /// * גאַנץ און אַנטיסיממעטריק: פּונקט איינער פון קס 00 קס, קס 01 קס אָדער קס 02 קס איז אמת, און
    /// * טראַנזיטיוו, `a < b` און `b < c` ימפּלייז `a < c`.דער זעלביקער מוזן האַלטן ביי `==` און `>`.
    ///
    /// למשל, בשעת קס 02 קס טוט נישט ינסטרומענט קס 03 קס ווייַל קס 01 קס, מיר קענען נוצן קס 04 קס ווי אונדזער סאָרט פונקציע ווען מיר וויסן אַז די רעפטל כּולל נישט אַ קס 00 קס.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # קראַנט ימפּלאַמענטיישאַן
    ///
    /// די קראַנט אַלגערידאַם איז באזירט אויף [pattern-defeating quicksort][pdqsort] פון Orson Peters, וואָס קאַמביינז די שנעל דורכשניטלעך פאַל פון ראַנדאַמייזד קוויקסאָרט מיט די פאַסט ערגסט פאַל פון העאַפּסאָרט, בשעת דערגרייכן לינעאַר צייט אויף סלייסאַז מיט זיכער פּאַטערנז.
    /// עס ניצט עטלעכע ראַנדאַמאַזיישאַן צו ויסמיידן דידזשענערייטיד קאַסעס, אָבער מיט אַ פאַרפעסטיקט ז 0 סעעד 0 ז צו שטענדיק צושטעלן דיטערמאַניסטיק נאַטור.
    ///
    /// עס איז טיפּיקלי פאַסטער ווי סטאַביל סאָרטינג, אַחוץ אין אַ ביסל ספּעציעל קאַסעס, למשל, ווען די רעפטל באשטייט פון עטלעכע קאַנקאַטאַנייטיד סאָרטעד סיקוואַנסיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // פאַרקערט סאָרטינג
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// סאָרץ די רעפטל מיט אַ שליסל יקסטראַקשאַן פונקציע, אָבער קען נישט האַלטן די סדר פון גלייַך עלעמענטן.
    ///
    /// דער סאָרט איז אַנסטייבאַל (ד"ה קען ריאָרדערינג גלייַך עלעמענטן), אין-אָרט (ד"ה קען נישט אַלאַקייט), און *O*(m\* * n *\* log(*n*)) ערגסט פאַל, ווו די שליסל פונקציע איז *O*(*עם*).
    ///
    /// # קראַנט ימפּלאַמענטיישאַן
    ///
    /// די קראַנט אַלגערידאַם איז באזירט אויף [pattern-defeating quicksort][pdqsort] פון Orson Peters, וואָס קאַמביינז די שנעל דורכשניטלעך פאַל פון ראַנדאַמייזד קוויקסאָרט מיט די פאַסט ערגסט פאַל פון העאַפּסאָרט, בשעת דערגרייכן לינעאַר צייט אויף סלייסאַז מיט זיכער פּאַטערנז.
    /// עס ניצט עטלעכע ראַנדאַמאַזיישאַן צו ויסמיידן דידזשענערייטיד קאַסעס, אָבער מיט אַ פאַרפעסטיקט ז 0 סעעד 0 ז צו שטענדיק צושטעלן דיטערמאַניסטיק נאַטור.
    ///
    /// רעכט צו דער שליסל פאַך סטראַטעגיע, [`sort_unstable_by_key`](#method.sort_unstable_by_key) איז מיסטאָמע סלאָוער ווי [`sort_by_cached_key`](#method.sort_by_cached_key) אין קאַסעס וואָס די שליסל פונקציע איז טייַער.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ריאָרדער די רעפטל אַזוי אַז די `index` עלעמענט איז אין די לעצט סאָרטעד שטעלע.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// ריאָרדער די רעפטל מיט אַ קאָמפּאַראַטאָר פונקציאָנירן אַזוי אַז די X00 עלעמענט איז אין זיין לעצט סאָרטעד שטעלע.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// ריאָרדער די רעפטל מיט אַ שליסל יקסטראַקשאַן פונקציאָנירן אַזוי אַז די `index` עלעמענט איז אין זיין לעצט סאָרטעד שטעלע.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// ריאָרדער די רעפטל אַזוי אַז די `index` עלעמענט איז אין די לעצט סאָרטעד שטעלע.
    ///
    /// די ריאָרדערינג האט די נאָך פאַרמאָג אַז קיין ווערט אין די שטעלע `i < index` וועט זיין ווייניקער ווי אָדער גלייַך צו קיין ווערט אין אַ X00 קס שטעלע.
    /// אין אַדישאַן, די ריאָרדערינג איז אַנסטייבאַל (י.ע.
    /// קיין נומער פון גלייַך עלעמענטן קען ענדיקן זיך אין די שטעלע `index`), אין-אָרט (י.ע.
    /// טוט נישט אַלאַקייט), און *אָ*(*ן*) ערגסט פאַל.
    /// די פֿונקציע איז אויך באַוווסט ווי "kth element" אין אנדערע לייברעריז.
    /// עס קערט אַ טריפּליט פון די פאלגענדע וואַלועס: אַלע עלעמענטן ווייניקער ווי די אין די געגעבן אינדעקס, די ווערט אין די געגעבן אינדעקס, און אַלע עלעמענטן גרעסער ווי די אין די געגעבן אינדעקס.
    ///
    ///
    /// # קראַנט ימפּלאַמענטיישאַן
    ///
    /// די קראַנט אַלגערידאַם איז באזירט אויף די קוויקקסעלעקט חלק פון דער זעלביקער קוויקקסאָרט אַלגערידאַם געניצט פֿאַר [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ווען `index >= len()`, דאָס איז שטענדיק panics אויף ליידיק סלייסיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // געפֿינען די מידיאַן
    /// v.select_nth_unstable(2);
    ///
    /// // מיר זענען בלויז געראַנטיד אַז די רעפטל איז איינער פון די פאלגענדע, באזירט אויף די וועג מיר סאָרט וועגן די ספּעסאַפייד אינדעקס.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// ריאָרדער די רעפטל מיט אַ קאָמפּאַראַטאָר פונקציאָנירן אַזוי אַז די X00 עלעמענט איז אין זיין לעצט סאָרטעד שטעלע.
    ///
    /// די ריאָרדערינג האט די נאָך פאַרמאָג אַז קיין ווערט אין די שטעלע `i < index` וועט זיין ווייניקער ווי אָדער גלייַך צו קיין ווערט אין אַ X1X שטעלע מיט די קאָמפּאַראַטאָר פונקציע.
    /// אין אַדישאַן, די ריאָרדערינג איז אַנסטייבאַל (ד"ה קיין נומער פון גלייַך עלעמענטן קען ענדיקן זיך אין די שטעלע קס 00 קס), אין-אָרט (י.ע. אַלאַקייט נישט) און *אָ*(*ן*) ערגסט פאַל.
    /// די פֿונקציע איז אויך באַוווסט ווי "kth element" אין אנדערע לייברעריז.
    /// עס קערט אַ טריפּליט פון די פאלגענדע וואַלועס: אַלע יסודות ווייניקער ווי די אין די געגעבן אינדעקס, די ווערט אין די געגעבן אינדעקס, און אַלע יסודות גרעסער ווי די אין די געגעבן אינדעקס, ניצן די צוגעשטעלט קאָמפּאַראַטאָר פונקציע.
    ///
    ///
    /// # קראַנט ימפּלאַמענטיישאַן
    ///
    /// די קראַנט אַלגערידאַם איז באזירט אויף די קוויקקסעלעקט חלק פון דער זעלביקער קוויקקסאָרט אַלגערידאַם געניצט פֿאַר [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ווען `index >= len()`, דאָס איז שטענדיק panics אויף ליידיק סלייסיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // געפֿינען די מידיאַן ווי אויב די רעפטל איז געווען סאָרטירט אין אַראָפּגיין סדר.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // מיר זענען בלויז געראַנטיד אַז די רעפטל איז איינער פון די פאלגענדע, באזירט אויף די וועג מיר סאָרט וועגן די ספּעסאַפייד אינדעקס.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// ריאָרדער די רעפטל מיט אַ שליסל יקסטראַקשאַן פונקציאָנירן אַזוי אַז די `index` עלעמענט איז אין זיין לעצט סאָרטעד שטעלע.
    ///
    /// די ריאָרדערינג האט די נאָך פאַרמאָג אַז קיין ווערט אין שטעלע `i < index` וועט זיין ווייניקער ווי אָדער גלייַך צו קיין ווערט אין אַ שטעלע `j > index` מיט די שליסל יקסטראַקשאַן פונקציע.
    /// אין אַדישאַן, די ריאָרדערינג איז אַנסטייבאַל (ד"ה קיין נומער פון גלייַך עלעמענטן קען ענדיקן זיך אין די שטעלע קס 00 קס), אין-אָרט (י.ע. אַלאַקייט נישט) און *אָ*(*ן*) ערגסט פאַל.
    /// די פֿונקציע איז אויך באַוווסט ווי "kth element" אין אנדערע לייברעריז.
    /// עס קערט אַ טריפּליט פון די פאלגענדע וואַלועס: אַלע עלעמענטן ווייניקער ווי די אין די געגעבן אינדעקס, די ווערט אין די געגעבן אינדעקס, און אַלע עלעמענטן גרעסער ווי די אין די געגעבן אינדעקס, ניצן די צוגעשטעלט שליסל יקסטראַקשאַן פונקציע.
    ///
    ///
    /// # קראַנט ימפּלאַמענטיישאַן
    ///
    /// די קראַנט אַלגערידאַם איז באזירט אויף די קוויקקסעלעקט חלק פון דער זעלביקער קוויקקסאָרט אַלגערידאַם געניצט פֿאַר [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ווען `index >= len()`, דאָס איז שטענדיק panics אויף ליידיק סלייסיז.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ווייַזן די מידיאַן ווי אויב די מענגע איז געווען סאָרטירט לויט די אַבסאָלוט ווערט.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // מיר זענען בלויז געראַנטיד אַז די רעפטל איז איינער פון די פאלגענדע, באזירט אויף די וועג מיר סאָרט וועגן די ספּעסאַפייד אינדעקס.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// מאָווינג אַלע קאָנסעקוטיווע ריפּיטיד עלעמענטן צו די סוף פון די רעפטל לויט די [`PartialEq`] ז 0 טראַט 0 ז ימפּלאַמענטיישאַן.
    ///
    ///
    /// קערט צוויי סלייסיז.דער ערשטער כּולל קיין קאָנסעקוטיווע ריפּיטיד עלעמענטן.
    /// די רגע כּולל אַלע די דופּליקאַטן אין קיין ספּעסאַפייד סדר.
    ///
    /// אויב די רעפטל איז אויסגעשטעלט, דער ערשטער אומגעקערט רעפטל כּולל קיין דופּליקאַטן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// באוועגט אַלע די ערשטע פון די קאָנסעקוטיווע עלעמענטן צו די סוף פון די רעפטל וואָס באַפרידיקן אַ געגעבן יקוואַלאַטי שייכות
    ///
    /// קערט צוויי סלייסיז.דער ערשטער כּולל קיין קאָנסעקוטיווע ריפּיטיד עלעמענטן.
    /// די רגע כּולל אַלע די דופּליקאַטן אין קיין ספּעסאַפייד סדר.
    ///
    /// די `same_bucket` פונקציע איז דורכגעגאנגען באַווייַזן צו צוויי עלעמענטן פֿון דער רעפטל און מוזן באַשליסן אויב די עלעמענטן זענען גלייך גלייך.
    /// די עלעמענטן זענען דורכגעגאנגען אין פאַרקערט סדר פון זייער סדר אין די רעפטל, אַזוי אויב `same_bucket(a, b)` קערט `true`, `a` איז אריבערגעפארן אין די סוף פון די רעפטל.
    ///
    ///
    /// אויב די רעפטל איז אויסגעשטעלט, דער ערשטער אומגעקערט רעפטל כּולל קיין דופּליקאַטן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // כאָטש מיר האָבן אַ מיוטאַבאַל דערמאָנען צו קס 00 קס, מיר קענען נישט מאַכן *אַרביטראַריש* ענדערונגען.די `same_bucket` רופט קען panic, אַזוי מיר מוזן ענשור אַז די רעפטל איז אין אַ גילטיק שטאַט צו אַלע מאָל.
        //
        // די וועג וואָס מיר האַנדלען מיט דאָס איז דורך ניצן סוואַפּס;מיר יבערקוקן איבער אַלע עלעמענטן, סוואַפּינג ווי מיר גיין אַזוי אַז אין די סוף, די עלעמענטן וואָס מיר וועלן צו האַלטן זענען אין די פראָנט, און די וואָס מיר וועלן צו אָפּוואַרפן זענען אין די צוריק.
        // מיר קענען דאַן שפּאַלטן די רעפטל.
        // די אָפּעראַציע איז נאָך X00 קס.
        //
        // בייַשפּיל: מיר אָנהייבן אין דעם שטאַט, ווו `r` רעפּראַזענץ "ווייַטער
        // לייענען "און `w` רעפּראַזענץ" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // קאַמפּערינג קס 00 קס קעגן זיך [w-1], דאָס איז נישט אַ דופּליקאַט, אַזוי מיר ויסבייַטן קס 01 קס און קס 02 קס (קיין ווירקונג ווי ר==וו) און דעמאָלט ינקראַמאַנט ביידע ר און וו, לאָזן אונדז מיט:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // קאַמפּערינג קס 00 קס קעגן זיך [w-1], דעם ווערט איז אַ דופּליקאַט, אַזוי מיר ינקראַמענט קס 01 קס אָבער לאָזן אַלץ אַנדערש אַנטשיינדזשד:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // קאַמפּערינג קס 00 קס קעגן זיך [w-1], דאָס איז נישט אַ דופּליקאַט, אַזוי ויסבייַטן קס 01 קס און קס 02 קס און שטייַגן ר און וו:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ניט אַ דופּליקאַט, איבערחזרן:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // דופּליקאַט, advance r. End פון רעפטל.שפּאַלטן אין וו.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // זיכערקייט: די `while` צושטאַנד געראַנטיז `next_read` און `next_write`
        // זענען ווייניקער ווי קס 01 קס, אַזוי זענען ין קס 00 קס.
        // `prev_ptr_write` ווייזט צו איין עלעמענט איידער קס 00 קס, אָבער קס 01 קס סטאַרץ בייַ 1, אַזוי קס 02 קס איז קיינמאָל ווייניקער ווי 0 און איז ין דער רעפטל.
        // דעם פולפילז די רעקווירעמענץ פֿאַר דערפערענסינג קס 01 קס, קס 04 קס און קס 02 קס, און פֿאַר ניצן קס 03 קס, קס 05 קס און קס 00 קס.
        //
        //
        // `next_write` איז אויך ינקראַמענאַד בייַ רובֿ אַמאָל פּער שלייף אין רובֿ טייַטש קיין עלעמענט איז סקיפּט ווען עס קען דאַרפֿן צו זיין סוואַפּט.
        //
        // `ptr_read` און קס 02 קס קיינמאָל פונט צו דער זעלביקער עלעמענט.דאָס איז פארלאנגט פֿאַר `&mut *ptr_read`, `&mut* prev_ptr_write` צו זיין זיכער.
        // די דערקלערונג איז פשוט אַז `next_read >= next_write` איז שטענדיק אמת, אַזוי `next_read >= next_write` איז אויך.
        //
        //
        //
        //
        //
        unsafe {
            // ויסמיידן גווול טשעקס מיט רוי פּוינטערז.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// מאָוועס אַלע אָבער די ערשטע פון קאָנסעקוטיווע עלעמענטן צו די סוף פון דער רעפטל אַז סאָלווע די זעלבע שליסל.
    ///
    ///
    /// קערט צוויי סלייסיז.דער ערשטער כּולל קיין קאָנסעקוטיווע ריפּיטיד עלעמענטן.
    /// די רגע כּולל אַלע די דופּליקאַטן אין קיין ספּעסאַפייד סדר.
    ///
    /// אויב די רעפטל איז אויסגעשטעלט, דער ערשטער אומגעקערט רעפטל כּולל קיין דופּליקאַטן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// ראָוטייץ די רעפטל אין-אָרט אַזוי אַז די ערשטער קס 00 קס עלעמענטן פון דער רעפטל מאַך צו די סוף בשעת די לעצטע קס 01 קס עלעמענטן מאַך צו די פראָנט.
    /// נאָך פאַך `rotate_left`, דער עלעמענט ביז אַהער ביי אינדעקס `rotate_left` וועט ווערן דער ערשטער עלעמענט אין דער רעפטל.
    ///
    /// # Panics
    ///
    /// די פֿונקציע וועט panic אויב `mid` איז גרעסער ווי די לענג פון די רעפטל.באַמערקונג אַז קס 01 קס טוט קס 02 קס ז 0 פּאַניק 0 ז און איז אַ ניט-אָפּ ראָוטיישאַן.
    ///
    /// # Complexity
    ///
    /// נעמט לינעאַר (אין קס 00 קס צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// ראָוטייטינג אַ סובסליסע:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // זיכערהייט: די קייט קס 01 קס איז נישטיק
        // גילטיק פֿאַר לייענען און שרייבן, ווי פארלאנגט דורך קס 00 קס.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ראָוטייץ די רעפטל אין-אָרט אַזוי אַז די ערשטער קס 00 קס עלעמענטן פון דער רעפטל מאַך צו די סוף בשעת די לעצטע קס 01 קס עלעמענטן מאַך צו די פראָנט.
    /// נאָך פאַך `rotate_right`, דער עלעמענט ביז אַהער ביי אינדעקס `rotate_right` וועט ווערן דער ערשטער עלעמענט אין דער רעפטל.
    ///
    /// # Panics
    ///
    /// די פֿונקציע וועט panic אויב `k` איז גרעסער ווי די לענג פון די רעפטל.באַמערקונג אַז קס 01 קס איז קס 02 קס ז 0 פּאַניק 0 ז און איז אַ ניט-אָפּ ראָוטיישאַן.
    ///
    /// # Complexity
    ///
    /// נעמט לינעאַר (אין קס 00 קס צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// דרייען אַ סובסליסע:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // זיכערהייט: די קייט קס 01 קס איז נישטיק
        // גילטיק פֿאַר לייענען און שרייבן, ווי פארלאנגט דורך קס 00 קס.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// פילז קס 01 קס מיט עלעמענטן דורך קלאָונינג קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// פילז קקסנומקסקס מיט עלעמענטן אומגעקערט דורך ריפּיטינג אַ קלאָוזשער ריפּיטידלי.
    ///
    /// דער אופֿן ניצט אַ קלאָוזשער צו שאַפֿן נייַע וואַלועס.אויב איר בעסער וועלן [`Clone`] אַ געגעבן ווערט, נוצן [`fill`].
    /// אויב איר ווילן צו נוצן די [`Default`] ז 0 טראַט 0 ז צו דזשענערייט וואַלועס, איר קענען פאָרן [`Default::default`] ווי די אַרגומענט.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// קאפיעס די עלעמענטן פֿון קס 01 קס אין קס 00 קס.
    ///
    /// די לענג פון קס 01 קס מוזן זיין די זעלבע ווי קס 00 קס.
    ///
    /// אויב קס 02 קס ימפּלאַמאַנץ קס 01 קס, עס קענען זיין מער פּערפאָרמאַנט צו נוצן קס 00 קס.
    ///
    /// # Panics
    ///
    /// די פֿונקציע וועט panic אויב די צוויי סלייסאַז האָבן פאַרשידענע לענגקטס.
    ///
    /// # Examples
    ///
    /// קלאָונינג צוויי עלעמענטן פֿון אַ רעפטל אין אנדערן:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ווייַל די סלייסאַז האָבן צו זיין די זעלבע לענג, מיר סלייסט די מקור סלייס פון פיר עלעמענטן צו צוויי.
    /// // עס וועט ז 0 פּאַניק 0 ז אויב מיר טאָן ניט טאָן דאָס.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Z0 רוסט 0 ז ענפאָרסיז אַז עס קען זיין בלויז איין מיוטאַבאַל רעפֿערענץ אָן ימיוטאַבאַל באַווייַזן צו אַ באַזונדער שטיק פון דאַטן אין אַ באַזונדער פאַרנעם.
    /// צוליב דעם, פּרווון צו נוצן `clone_from_slice` אויף אַ איין רעפטל וועט רעזולטאַט אין אַ צונויפנעמען דורכפאַל:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// צו אַרומרינגלען דעם, מיר קענען נוצן [`split_at_mut`] צו שאַפֿן צוויי באַזונדער סאַב-סלייסיז פון אַ רעפטל:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// קאפיעס אַלע עלעמענטן פֿון קס 01 קס אין קס 00 קס, ניצן אַ מעמקפּי.
    ///
    /// די לענג פון קס 01 קס מוזן זיין די זעלבע ווי קס 00 קס.
    ///
    /// אויב קס 02 קס טוט נישט ינסטרומענט קס 01 קס, נוצן קס 00 קס.
    ///
    /// # Panics
    ///
    /// די פֿונקציע וועט panic אויב די צוויי סלייסאַז האָבן פאַרשידענע לענגקטס.
    ///
    /// # Examples
    ///
    /// קאַפּיינג צוויי עלעמענטן פֿון אַ רעפטל אין אנדערן:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ווייַל די סלייסאַז האָבן צו זיין די זעלבע לענג, מיר סלייסט די מקור סלייס פון פיר עלעמענטן צו צוויי.
    /// // עס וועט ז 0 פּאַניק 0 ז אויב מיר טאָן ניט טאָן דאָס.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Z0 רוסט 0 ז ענפאָרסיז אַז עס קען זיין בלויז איין מיוטאַבאַל רעפֿערענץ אָן ימיוטאַבאַל באַווייַזן צו אַ באַזונדער שטיק פון דאַטן אין אַ באַזונדער פאַרנעם.
    /// צוליב דעם, פּרווון צו נוצן `copy_from_slice` אויף אַ איין רעפטל וועט רעזולטאַט אין אַ צונויפנעמען דורכפאַל:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// צו אַרומרינגלען דעם, מיר קענען נוצן [`split_at_mut`] צו שאַפֿן צוויי באַזונדער סאַב-סלייסיז פון אַ רעפטל:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // די panic קאָד דרך איז געווען שטעלן אין אַ קאַלט פונקציע צו נישט בלאָוט די רופן פּלאַץ.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // זיכערקייט: קס 00 קס איז גילטיק פֿאַר קס 01 קס עלעמענטן דורך דעפֿיניציע, און קס 02 קס איז געווען
        // אָפּגעשטעלט צו האָבן די זעלבע לענג.
        // די סלייסאַז קענען נישט אָוווערלאַפּ ווייַל מיוטאַבאַל באַווייַזן זענען ויסשליסיק.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// קאפיעס עלעמענטן פון איין טייל פון דער רעפטל צו אן אנדער טייל פון זיך, ניצן אַ מאַממאָווע.
    ///
    /// `src` איז די קייט ין `self` צו צייכענען פון.
    /// `dest` איז די סטאַרטינג אינדעקס פון די קייט אין `self` צו צייכענען צו, וואָס וועט האָבן די זעלבע לענג ווי `src`.
    /// די צוויי ריינדזשאַז קען אָוווערלאַפּ.
    /// די ענדס פון די צוויי ריינדזשאַז מוזן זיין ווייניקער ווי אָדער גלייַך צו `self.len()`.
    ///
    /// # Panics
    ///
    /// די פֿונקציע וועט ז 0 פּאַניק 0 ז אויב יעדער קייט יקסידז די סוף פון די רעפטל, אָדער אויב די סוף פון `src` איז איידער די אָנהייב.
    ///
    ///
    /// # Examples
    ///
    /// קאַפּיינג פיר ביטעס ין אַ רעפטל:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // זיכערקייט: די באדינגונגען פֿאַר קס 00 קס האָבן שוין אָפּגעשטעלט אויבן,
        // ווי די פֿאַר `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// ויסבייַטן אַלע עלעמענטן אין קס 01 קס מיט יענע אין קס 00 קס.
    ///
    /// די לענג פון קס 01 קס מוזן זיין די זעלבע ווי קס 00 קס.
    ///
    /// # Panics
    ///
    /// די פֿונקציע וועט panic אויב די צוויי סלייסאַז האָבן פאַרשידענע לענגקטס.
    ///
    /// # Example
    ///
    /// ויסבייַטן צוויי עלעמענטן איבער סלייסיז:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Z0 רוסט 0 ז ענפאָרסיז אַז עס קען נאָר זיין איין מיוטאַבאַל דערמאָנען צו אַ באַזונדער שטיק פון דאַטן אין אַ באַזונדער פאַרנעם.
    ///
    /// צוליב דעם, פּרווון צו נוצן `swap_with_slice` אויף אַ איין רעפטל וועט רעזולטאַט אין אַ קאָמפּילע דורכפאַל:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// צו אַרומרינגלען דעם, מיר קענען נוצן [`split_at_mut`] צו שאַפֿן צוויי באַזונדער מיוטאַבאַל סאַב-סלייסיז פֿון אַ רעפטל:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // זיכערקייט: קס 00 קס איז גילטיק פֿאַר קס 01 קס עלעמענטן דורך דעפֿיניציע, און קס 02 קס איז געווען
        // אָפּגעשטעלט צו האָבן די זעלבע לענג.
        // די סלייסאַז קענען נישט אָוווערלאַפּ ווייַל מיוטאַבאַל באַווייַזן זענען ויסשליסיק.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// פונקציאָנירן צו רעכענען די לענג פון די מיטל און טריילינג רעפטל פֿאַר קס 00 קס.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // וואָס מיר וועלן טאָן וועגן קס 00 קס איז צו געפֿינען אויס וואָס קייפל פון U`s מיר קענען שטעלן אין די לאָואַסט נומער פון T.
        //
        // און ווי פילע `ה`ס מיר דאַרפֿן פֿאַר יעדער אַזאַ "multiple".
        //
        // באַטראַכטן פֿאַר בייַשפּיל T=u8 U=u16.דערנאָך מיר קענען שטעלן 1 ו אין 2 צ.פּשוט.
        // איצט, למשל, באַטראַכטן אַ פאַל וווּ גרייס_אָף: :<T>=16, גרייס_אָף::<U>=24.</u>
        // מיר קענען שטעלן 2 Us אין פּלאַץ פון יעדער 3 Ts אין די `rest` רעפטל.
        // א ביסל מער קאָמפּליצירט.
        //
        // פאָרמולע צו רעכענען דאָס איז:
        //
        // אונדז= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // יקספּאַנדיד און סימפּלאַפייד:
        //
        // אונדז=גרייס_אָף: :<T>/קס 01 קס ץ=גרייס_אָף::<U>/קס 00 קס</u>
        //
        // צומ גליק זינט אַלע דעם איז קעסיידערדיק עוואַלואַטעד ... פאָרשטעלונג דאָ איז נישט וויכטיק!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative Stein's אַלגערידאַם מיר זאָל נאָך מאַכן דעם קס 00 קס (און צוריקקומען צו רעקורסיווע אַלגערידאַם אויב מיר טאָן דאָס) ווייַל רילייינג אויף ללוום צו קאָנסטעוואַל אַלע דעם איז ... נו, עס מאכט מיר ומבאַקוועם.
            //
            //

            // זיכערקייט: קס 00 קס און קס 01 קס זענען אָפּגעשטעלט צו זיין ניט-נול וואַלועס.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // אַראָפּנעמען אַלע סיבות פון 2 פֿון b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // זיכערקייט: קס 00 קס איז אָפּגעשטעלט צו זיין ניט-נול.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // אַרמד מיט דעם וויסן, מיר קענען געפֿינען ווי פילע `U`s מיר קענען פּאַסיק!
        let us_len = self.len() / ts * us;
        // און ווי פילע `ה` ס וועט זיין אין די טריילינג רעפטל!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// יבערמאַכן די רעפטל צו אַ רעפטל פון אן אנדער טיפּ, ינשורינג די אַליינמאַנט פון די טייפּס איז מיינטיינד.
    ///
    /// דעם אופֿן ספּליץ די רעפטל אין דריי בוילעט סלייסאַז: פּרעפיקס, ריכטיק אַליינד מיטל רעפטל פון אַ נייַ טיפּ און די סופפיקס רעפטל.
    /// דער אופֿן קען מאַכן די מיטל סלייס די גרעסטע לענג מעגלעך פֿאַר אַ געגעבן טיפּ און ינפּוט סלייס, אָבער בלויז די פאָרשטעלונג פון דיין אַלגערידאַם זאָל זיין אָפענגיק אויף דעם, נישט אויף די ריכטיק.
    ///
    /// אַלע די ינפּוט דאַטן קענען זיין אומגעקערט ווי די פּרעפיקס אָדער סאַפיקס רעפטל.
    ///
    /// דער אופֿן האט קיין ציל ווען דער ינפּוט עלעמענט קס 00 קס אָדער רעזולטאַט עלעמענט קס 01 קס זענען נול-סייזד און וועט צוריקקומען דער אָריגינעל רעפטל אָן ספּליטינג עפּעס.
    ///
    /// # Safety
    ///
    /// דער אופֿן איז בייסיקלי אַ קסקסנומקסקסקס פֿאַר די עלעמענטן אין די אומגעקערט מיטל רעפטל, אַזוי אַלע די געוויינטלעך קאַוועץ פֿאַר קסקסנומקסקס אויך אַפּלייז דאָ.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // באַמערקונג אַז רובֿ פון די פֿונקציע וועט זיין קעסיידער עוואַלואַטעד,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // שעפּן זסטס ספּעשאַלי, וואָס איז-טאָן ניט שעפּן זיי אין אַלע.
            return (self, &[], &[]);
        }

        // ערשטער, אין וואָס פונט טאָן מיר צעטיילן צווישן דער ערשטער און 2 רעפטל.
        // גרינג מיט קס 00 קס.
        let ptr = self.as_ptr();
        // זיכערהייט: זען די `align_to_mut` אופֿן פֿאַר די דיטיילד זיכערהייט באַמערקונג.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // זיכערקייט: איצט `rest` איז באשטימט אַליינד, אַזוי `from_raw_parts` ונטער איז אָוקיי,
            // זינט די קאָלער געראַנטיז אַז מיר קענען בעשאָלעם אַריבערפירן קס 00 קס צו קס 01 קס.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// יבערמאַכן די רעפטל צו אַ רעפטל פון אן אנדער טיפּ, ינשורינג די אַליינמאַנט פון די טייפּס איז מיינטיינד.
    ///
    /// דעם אופֿן ספּליץ די רעפטל אין דריי בוילעט סלייסאַז: פּרעפיקס, ריכטיק אַליינד מיטל רעפטל פון אַ נייַ טיפּ און די סופפיקס רעפטל.
    /// דער אופֿן קען מאַכן די מיטל סלייס די גרעסטע לענג מעגלעך פֿאַר אַ געגעבן טיפּ און ינפּוט סלייס, אָבער בלויז די פאָרשטעלונג פון דיין אַלגערידאַם זאָל זיין אָפענגיק אויף דעם, נישט אויף די ריכטיק.
    ///
    /// אַלע די ינפּוט דאַטן קענען זיין אומגעקערט ווי די פּרעפיקס אָדער סאַפיקס רעפטל.
    ///
    /// דער אופֿן האט קיין ציל ווען דער ינפּוט עלעמענט קס 00 קס אָדער רעזולטאַט עלעמענט קס 01 קס זענען נול-סייזד און וועט צוריקקומען דער אָריגינעל רעפטל אָן ספּליטינג עפּעס.
    ///
    /// # Safety
    ///
    /// דער אופֿן איז בייסיקלי אַ קסקסנומקסקסקס פֿאַר די עלעמענטן אין די אומגעקערט מיטל רעפטל, אַזוי אַלע די געוויינטלעך קאַוועץ פֿאַר קסקסנומקסקס אויך אַפּלייז דאָ.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // באַמערקונג אַז רובֿ פון די פֿונקציע וועט זיין קעסיידער עוואַלואַטעד,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // שעפּן זסטס ספּעשאַלי, וואָס איז-טאָן ניט שעפּן זיי אין אַלע.
            return (self, &mut [], &mut []);
        }

        // ערשטער, אין וואָס פונט טאָן מיר צעטיילן צווישן דער ערשטער און 2 רעפטל.
        // גרינג מיט קס 00 קס.
        let ptr = self.as_ptr();
        // זיכערקייט: דאָ מיר ינשור אַז מיר וועלן נוצן אַליינד פּוינטערז פֿאַר יו פֿאַר די
        // מנוחה פון דעם אופֿן.דאָס איז דורכגעקאָכט דורך פאָרן אַ טייַטל צו&[T] מיט אַ אַליינמאַנט טאַרגעטעד פֿאַר יו.
        // `crate::ptr::align_offset` איז גערופֿן מיט אַ ריכטיק אַליינד און גילטיק טייַטל קס 00 קס (עס קומט פֿון אַ רעפֿערענץ צו קס 01 קס) און מיט אַ גרייס וואָס איז אַ מאַכט פון צוויי (זינט עס קומט פֿון די אַליינמאַנט פֿאַר יו), סאַטיספייינג זייַן זיכערקייט קאַנסטריינץ.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // מיר קענען נישט נוצן `rest` נאָך דעם, דאָס וואָלט פאַרקריפּלט די אַליאַס `mut_ptr`!זיכערקייט: זען באַמערקונגען פֿאַר קס 00 קס.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// טשעקס אויב די יסודות פון דעם רעפטל זענען אויסגעשטעלט.
    ///
    /// אַז איז, פֿאַר יעדער עלעמענט קס 03 קס און זייַן ווייַטערדיק עלעמענט קס 00 קס, קס 01 קס מוזן האַלטן.אויב די רעפטל ייעלדס פּונקט נול אָדער איין עלעמענט, `true` איז אומגעקערט.
    ///
    /// באַמערקונג אַז אויב `Self::Item` איז בלויז `PartialOrd`, אָבער נישט `PartialOrd`, די אויבן דעפֿיניציע ימפּלייז אַז די פֿונקציע קערט `false` אויב קיין צוויי קאָנסעקוטיווע ייטאַמז זענען ניט פאַרגלייַכלעך.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// טשעקס אויב די יסודות פון דעם רעפטל זענען אויסגעשטעלט מיט די געגעבן קאָמפּאַראַטאָר פונקציע.
    ///
    /// אַנשטאָט ניצן `PartialOrd::partial_cmp`, די פונקציע ניצט די געגעבן `compare` פונקציע צו באַשליסן די אָרדערינג פון צוויי עלעמענטן.
    /// חוץ דעם, עס ס עקוויוואַלענט צו קס 00 קס;זען דאַקיומענטיישאַן פֿאַר מער אינפֿאָרמאַציע.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// טשעקס אויב די יסודות פון דעם רעפטל זענען אויסגעשטעלט מיט די געגעבן שליסל יקסטראַקשאַן פונקציאָנירן.
    ///
    /// אַנשטאָט צו פאַרגלייכן די עלעמענטן פון די רעפטל גלייך, די פונקציע קאַמפּערז די שליסלען פון די עלעמענטן ווי X00 קס.
    /// חוץ דעם, עס ס עקוויוואַלענט צו קס 00 קס;זען דאַקיומענטיישאַן פֿאַר מער אינפֿאָרמאַציע.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// קערט דער אינדעקס פון דער צעטיילונג פונט לויט די געגעבן פּרעדיקאַט (דער אינדעקס פון דער ערשטער עלעמענט פון דער רגע צעטיילונג).
    ///
    /// די רעפטל איז געמיינט צו זיין פּאַרטישאַנד לויט די געגעבן פּרעדיקאַט.
    /// דעם מיטל אַז אַלע עלעמענטן פֿאַר וואָס די פּרעדיקאַט קערט אמת זענען אין די אָנהייב פון די רעפטל און אַלע עלעמענטן פֿאַר וואָס די פּרעדיקאַט קערט פאַלש זענען אין די סוף.
    ///
    /// פֿאַר בייַשפּיל, [7, 15, 3, 5, 4, 12, 6] איז צעטיילט אונטער דעם פּרעדיקאַט X% 2!=0 (אַלע מאָדנע נומערן זענען אין די אָנהייב, אַלע אפילו אין די סוף).
    ///
    /// אויב די רעפטל איז נישט צעטיילט, די אומגעקערט רעזולטאַט איז ונספּעסיפיעד און מינינגלאַס, ווייַל דעם אופֿן דורכפירן אַ מין פון ביינערי זוכן.
    ///
    /// זען אויך [`binary_search`], [`binary_search_by`] און [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // זיכערקייט: ווען `left < right`, `left <= mid < right`.
            // דעריבער `left` שטענדיק ינקריסיז און `right` שטענדיק דיקריסאַז, און איינער פון זיי איז אויסגעקליבן.אין ביידע פאלן, קס 03 קס איז צופֿרידן.דעריבער אויב קס 04 קס אין אַ שריט, קס 00 קס איז צופֿרידן אין דער ווייַטער שריט.
            //
            // דעריבער, ווי לאַנג ווי `left != right`, `0 <= left < right <= len` איז צופֿרידן, און אויב `0 <= mid < len` איז אויך צופֿרידן.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: מיר דאַרפֿן צו זיין בישליימעס סלייסט צו די זעלבע לענג
        // צו מאַכן די אָפּטימיזער גרינגער צו קאָנטראָלירן די גווול.
        // אָבער ווייַל עס קען נישט זיין רילייד, מיר אויך האָבן אַ יקספּליסאַט ספּעשאַלאַזיישאַן פֿאַר ה: קאָפּיע.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// קרעאַטעס אַ ליידיק רעפטל.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// קרעאַטעס אַ מיוטאַבאַל ליידיק רעפטל.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// פּאַטערנז אין סלייסאַז, דערווייַל, בלויז געניצט דורך קס 01 קס און קס 00 קס.
/// אין אַ פונט פון future, מיר האָפן צו גענעראַליזירן `core::str::Pattern` (וואָס אין דער צייט פון שרייבן איז לימיטעד צו `str`) צו סלייסאַז, און דערנאָך די trait וועט זיין ריפּלייסט אָדער אַבאַלישט.
///
pub trait SlicePattern {
    /// דער עלעמענט טיפּ פון דער רעפטל איז מאַטשט אויף.
    type Item;

    /// דערווייַל, די `SlicePattern` קאָנסומערס דאַרפֿן אַ רעפטל.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}