// אָריגינעל ימפּלאַמענטיישאַן גענומען פֿון rust-memchr.
// דרוקרעכט 2015 Andrew Gallant, bluss און Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// ניצן טראַנגקיישאַן.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// קערט `true` אויב `true` כּולל קיין נול בייט.
///
/// פֿון *Matters Computational*, J. Arndt:
///
/// "דער געדאַנק איז צו אַראָפּרעכענען איינער פון יעדער פון די ביטעס און דערנאָך זוכן פֿאַר ביטעס ווו די באָרגן פּראַפּאַגייטיד אַלע די וועג צו די מערסט באַטייטיק
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// קערט דער ערשטער אינדעקס וואָס ריכטן די בייט קס 01 קס אין קס 00 קס.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // שנעל וועג פֿאַר קליין סלייסיז
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // יבערקוקן איין ווערט פון איין בייט דורך לייענען צוויי `usize` ווערטער אין אַ צייט.
    //
    // שפּאַלטן קס 00 קס אין דריי פּאַרץ
    // - אַנאַליינד ערשט טייל איידער דער ערשטער וואָרט אַליינד אַדרעס אין טעקסט
    // - גוף, יבערקוקן דורך 2 ווערטער אין אַ צייַט
    // - די לעצטע רוען טייל, <2 וואָרט גרייס

    // זוכן אַרויף צו אַ אַליינד גרענעץ
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // זוכן דעם גוף פון דעם טעקסט
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // זיכערהייט: די בשעת ס פּרידיקאַט געראַנטיז אַ ווייַטקייט פון לפּחות 2 * וסיזע_ביטעס
        // צווישן די אָפסעט און די סוף פון די רעפטל.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ברעכן אויב עס איז אַ ריכטן בייט
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // געפֿינען די בייט נאָך די פונט די גוף שלייף סטאַפּט.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// רעטורנס די לעצטע אינדעקס וואָס ריכטן די בייט קס 01 קס אין קס 00 קס.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // יבערקוקן איין ווערט פון איין בייט דורך לייענען צוויי `usize` ווערטער אין אַ צייט.
    //
    // שפּאַלטן קס 00 קס אין דריי פּאַרץ:
    // - אַנאַליינד עק, נאָך די לעצטע וואָרט אַליינד אַדרעס אין טעקסט,
    // - גוף, סקאַנד דורך 2 ווערטער אין אַ צייט,
    // - דער ערשטער רוען ביטעס, <2 וואָרט גרייס.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // מיר רופן דאָס נאָר צו באַקומען די לענג פון די פּרעפיקס און סאַפיקס.
        // אין דער מיטן, מיר שטענדיק פּראַסעסינג צוויי טשאַנגקס אין אַמאָל.
        // זיכערקייט: טראַנסמוטטינג קס 01 קס צו קס 02 קס איז זיכער אַחוץ פֿאַר גרייס דיפעראַנסיז וואָס זענען כאַנדאַלד דורך קס 00 קס.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // זוך אין דעם גוף פון דעם טעקסט, מאַכן זיכער אַז מיר טאָן ניט אַריבערגיין מיין_אַליינד_אָפסעט.
    // פאָטאָ איז שטענדיק אַליינד, אַזוי פּונקט טעסטינג קס 00 קס איז גענוג און אַוווידז מעגלעך לויפן.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // זיכערקייט: אָפסעט סטאַרץ ביי לענ, קס 00 קס, ווי לאַנג ווי עס איז גרעסער ווי
        // min_aligned_offset (prefix.len()) די רוען ווייַטקייט איז לפּחות 2 * טשונק_ביטעס.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // ברעכן אויב עס איז אַ ריכטן בייט.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // געפֿינען די בייט איידער די פונט די גוף שלייף סטאַפּט.
    text[..offset].iter().rposition(|elt| *elt == x)
}