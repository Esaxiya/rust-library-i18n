//! פאַרגלייַך ז 0 טראַיצ 0 ז פֿאַר קס 00 קס.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// רופט ימפּלאַמענטיישאַן צוגעשטעלט מעמקמפּ.
    ///
    /// ינטערפּראַץ די דאַטן ווי u8.
    ///
    /// קערט 0 פֿאַר גלייַך, <0 פֿאַר ווייניקער ווי און> 0 פֿאַר גרעסער ווי.
    ///
    // FIXME(#32610): צוריקקער טיפּ זאָל זיין ק_ינט
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// ימפּלאַמאַנץ פאַרגלייַך פון ז 0 וועקטאָרס 0 ז קס 00 קס.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// ימפּלאַמאַנץ פאַרגלייַך פון ז 0 וועקטאָרס 0 ז קס 00 קס.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// ינטערמידייט ז 0 טראַיט 0 ז פֿאַר ספּעשאַלאַזיישאַן פון פּאַרטייעק פון סלייס
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// דזשאַנעריק רעפטל יקוואַלאַטי
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// ניצן מעמקמפּ פֿאַר בייטווייז יקוואַלאַטי ווען די טייפּס לאָזן
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // זיכערקייט: קס 00 קס און קס 01 קס זענען באַווייַזן און זענען געראַנטיד צו זיין גילטיק.
        // די צוויי סלייסיז זענען אָפּגעשטעלט צו האָבן די זעלבע גרייס אויבן.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// ינטערמידייט ז 0 טראַיט 0 ז פֿאַר ספּעשאַלאַזיישאַן פון פּאַרטיי אָרד פון די רעפטל
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // צעטל צו די שלייף יטעראַטיאָן קייט צו געבן געבונדן טשעק ילימאַניישאַן אין די קאַמפּיילער
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// דאָס איז די ימפּ אַז מיר וואָלט ווי צו האָבן.צום באַדויערן עס איז נישט געזונט.
// זען קס 00 קס.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// ינטערמידייט ז 0 טראַיט 0 ז פֿאַר ספּעשאַלאַזיישאַן פון סלייס ס אָרד
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // צעטל צו די שלייף יטעראַטיאָן קייט צו געבן געבונדן טשעק ילימאַניישאַן אין די קאַמפּיילער
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// מעמקמפּ קאַמפּערז אַ סיקוואַנס פון ונסיגנעד ביטעס לעקסיקאָגראַפיקלי.
// דעם גלייַכן די סדר מיר וועלן פֿאַר [u8], אָבער קיין אנדערע (נישט אפילו [i8]).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // זיכערקייט: קס 00 קס און קס 01 קס זענען באַווייַזן און זענען געראַנטיד צו זיין גילטיק.
            // מיר נוצן די מינימום פון ביידע לענגז וואָס געראַנטיז אַז ביידע געגנטן זענען גילטיק פֿאַר רידינגז אין דעם מעהאַלעך.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// כאַק צו לאָזן ספּעשאַלייזינג אויף קס 00 קס, כאָטש קס 01 קס האט אַ מעטאָד.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait ימפּלאַמענאַד פֿאַר טייפּס וואָס קענען זיין קאַמפּערד פֿאַר יקוואַלאַטי מיט זייער ביטווייז פאַרטרעטונג
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // זיכערקייט: קס 01 קס און קס 02 קס האָבן די זעלבע זכּרון אויסלייג, אַזוי קאַסטינג קס 00 קס
        // ווי `*const u8` איז זיכער.
        // די `x.as_ptr()` קומט פֿון אַ רעפֿערענץ און איז אַזוי געראַנטיד צו זיין גילטיק פֿאַר די לענג פון די רעפטל `x.len()`, וואָס קען נישט זיין גרעסער ווי `isize::MAX`.
        // די אומגעקערט רעפטל איז קיינמאָל מיוטייטיד.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}