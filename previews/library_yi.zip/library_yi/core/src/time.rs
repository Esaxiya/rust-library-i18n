#![stable(feature = "duration_core", since = "1.25.0")]

//! טעמפּעראַל קוואַנטיפאַקיישאַן.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ביידע דעקלעריישאַנז זענען עקוויוואַלענט
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// א קס 00 קס טיפּ צו פאָרשטעלן אַ שפּאַן פון צייַט, טיפּיקלי געניצט פֿאַר סיסטעם טיימאַוץ.
///
/// יעדער `Duration` איז קאַמפּאָוזד פון אַ גאַנץ נומער פון סעקונדעס און אַ פראַקשאַנאַל טייל רעפּריזענטיד אין נאַנאָסעקאַנדז.
/// אויב די אַנדערלייינג סיסטעם קען נישט שטיצן נאַנאָסעקאָנד-פּינטלעכקייַט, אַפּיס ביינדינג אַ סיסטעם טיימאַוט וועט טיפּיקלי קייַלעכיק די נומער פון נאַנאָסעקאַנדז.
///
/// [`געדויער`] s ינסטרומענט פילע פּראָסט ז 0 טראַיצ 0 ז, כולל קס 01 קס, קס 02 קס, און אנדערע קס 03 קס ז 0 טראַיצ 0 ז.עס ימפּלאַמאַנץ קס 04 קס דורך צוריקקומען אַ נול-לענג קס 00 קס.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # פאָרמאַטטינג `Duration` וואַלועס
///
/// `Duration` בעקיוון האט נישט אַ `Display` ימפּלייז, ווייַל עס זענען פאַרשידן וועגן צו פֿאָרמאַט ספּאַנס פון צייט פֿאַר מענטשלעך רידאַביליטי.
/// `Duration` פּראָווידעס אַ `Debug` ימפּ וואָס ווייזט די פול פּינטלעכקייַט פון די ווערט.
///
/// די `Debug` רעזולטאַט ניצט די ניט-ASCII קס 01 קס סופפיקס פֿאַר מיקראָסעקאַנדז.
/// אויב דיין פּראָגראַם רעזולטאַט קען זיין געוויזן אין קאַנטעקסץ וואָס קענען ניט פאַרלאָזנ זיך פול אוניקאָד קאַמפּאַטאַבילאַטי, איר ווילט צו פֿאָרמאַטירן `Duration` אַבדזשעקץ אָדער נוצן אַ crate צו טאָן דאָס.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // שטענדיק 0 <=נאַנאָס <NANOS_PER_SEC
}

impl Duration {
    /// דער געדויער פון איין סעקונדע.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// די געדויער פון איין מיליסעקאַנד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// דער געדויער פון איין מיקראָסעקאַנד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// דער געדויער פון איין נאַנאָסעקאַנד.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// א געדויער פון נול צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// די מאַקסימום געדויער.
    ///
    /// עס איז בעערעך גלייַך צו אַ געדויער פון 584,942,417,355 יאָר.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// קרעאַטעס אַ נייַע קס 00 קס פֿון די ספּעסאַפייד נומער פון גאַנץ סעקונדעס און נאָך נאַנאָסעקאַנדז.
    ///
    /// אויב די נומער פון נאַנאָסעקאַנדז איז גרעסער ווי 1 ביליאָן (די נומער פון נאַנאָסעקאַנדז אין אַ רגע), עס וועט אַריבערפירן אין די צוגעשטעלט סעקונדעס.
    ///
    ///
    /// # Panics
    ///
    /// דער קאָנסטרוקטאָר וועט ז 0 פּאַניק 0 ז אויב די פירן פון די נאַנאָסעקאַנדז אָוווערפלאָוז די סעקונדעס טאָמבאַנק.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// קרעאַטעס אַ נייַע קס 00 קס פֿון די ספּעסאַפייד נומער פון גאַנץ סעקונדעס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// קרעאַטעס אַ נייַ קס 00 קס פֿון די ספּעסאַפייד נומער פון מיליסעקאַנדז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// קרעאַטעס אַ נייַע `Duration` פֿון די ספּעסאַפייד נומער פון מיקראָסעקאַנדז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// קרעאַטעס אַ נייַע קס 00 קס פֿון די ספּעסאַפייד נומער פון נאַנאָסעקאַנדז.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// קערט אמת אויב דעם `Duration` ספּאַנס קיין צייט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// קערט די נומער פון _whole_ סעקונדעס קאַנטיינד דורך דעם `Duration`.
    ///
    /// די אומגעקערט ווערט כולל נישט די פראַקשאַנאַל (nanosecond) טייל פון דער געדויער, וואָס קענען זיין באקומען מיט [`subsec_nanos`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// צו באַשליסן די גאַנץ נומער פון סעקונדעס רעפּריזענטיד דורך די `Duration`, נוצן `as_secs` אין קאָמבינאַציע מיט [`subsec_nanos`]:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// קערט די פראַקשאַנאַל טייל פון דעם `Duration`, אין גאַנץ מיליסעקאַנדז.
    ///
    /// דער אופֿן **ניט** קערט די לענג פון די געדויער ווען עס איז רעפּריזענטיד דורך מיליסעקאַנדז.
    /// די אומגעקערט נומער רעפּראַזענץ שטענדיק אַ בראָכצאָל פון אַ רגע (הייסט עס איז ווייניקער ווי טויזנט).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// קערט דער פראַקשאַנאַל טייל פון דעם `Duration`, אין גאַנץ מיקראָסעקאַנדז.
    ///
    /// דער אופֿן קען נישט ** צוריקקומען די לענג פון די געדויער ווען עס איז רעפּריזענטיד דורך מיקראָסעקאַנדז.
    /// די אומגעקערט נומער רעפּראַזענץ שטענדיק אַ בראָכצאָל פון אַ רגע (י.ע. עס איז ווייניקער ווי איין מיליאָן).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// קערט דער פראַקשאַנאַל טייל פון דעם `Duration` אין נאַנאָסעקאַנדז.
    ///
    /// דער אופֿן קען **ניט** ווייַזן די לענג פון די געדויער ווען עס איז רעפּריזענטיד דורך נאַנאָסעקאַנדז.
    /// די אומגעקערט נומער רעפּראַזענץ שטענדיק אַ בראָכצאָל פון אַ רגע (י.ע. עס איז ווייניקער ווי 1000000000).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// קערט די גאַנץ נומער פון גאַנץ מיליסעקאַנדז קאַנטיינד דורך דעם `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// קערט די גאַנץ נומער פון גאַנץ מיקראָסעקאַנדז קאַנטיינד דורך דעם `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// קערט די גאַנץ נומער פון נאַנאָסעקאַנדז קאַנטיינד דורך דעם `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// אָפּגעשטעלט `Duration` דערצו.
    /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// סאַטוראַטינג קס 00 קס דערצו.
    /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// אָפּגעשטעלט `Duration` כיסער.
    /// קאַמפּיוץ קס 00 קס, רענטגענ קס 01 קס אויב דער רעזולטאַט וואָלט זיין נעגאַטיוו אָדער אויב לויפן איז פארגעקומען.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// סאַטוראַטינג קס 00 קס כיסער.
    /// קאַמפּיוץ קס 00 קס, רענטגענ קס 01 קס אויב דער רעזולטאַט וואָלט זיין נעגאַטיוו אָדער אויב לויפן איז פארגעקומען.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// אָפּגעשטעלט קס 00 קס קייפל.
    /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // מערן נאַנאָסעקאַנדז ווי u64, ווייַל עס קען נישט לויפן אַז וועג.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// סאַטוראַטינג קס 00 קס קייפל.
    /// קאַמפּיוץ קס 00 קס, אומגעקערט קס 01 קס אויב לויפן לויפן.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// אָפּגעשטעלט `Duration` אָפּטייל.
    /// קאַמפּיוץ קס 01 קס, אומגעקערט קס 02 קס אויב קס 00 קס.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// קערט די נומער פון סעקונדעס קאַנטיינד דורך דעם `Duration` ווי `f64`.
    /// די אומגעקערט ווערט אַרייננעמען די פראַקשאַנאַל (nanosecond) טייל פון דער געדויער.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// קערט די נומער פון סעקונדעס קאַנטיינד דורך דעם `Duration` ווי `f32`.
    /// די אומגעקערט ווערט אַרייננעמען די פראַקשאַנאַל (nanosecond) טייל פון דער געדויער.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// קרעאַטעס אַ נייַ קס 01 קס פֿון די ספּעסאַפייד נומער פון סעקונדעס רעפּריזענטיד ווי קס 00 קס.
    ///
    /// # Panics
    /// דער קאָנסטרוקטאָר וועט panic אויב `secs` איז נישט ענדלעך, נעגאַטיוו אָדער אָוווערפלאָוז `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// קרעאַטעס אַ נייַ קס 01 קס פֿון די ספּעסאַפייד נומער פון סעקונדעס רעפּריזענטיד ווי קס 00 קס.
    ///
    /// # Panics
    /// דער קאָנסטרוקטאָר וועט panic אויב `secs` איז נישט ענדלעך, נעגאַטיוו אָדער אָוווערפלאָוז `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// מאַלטאַפּלייס קס 01 קס דורך קס 00 קס.
    /// # Panics
    /// דעם אופֿן וועט ז 0 פּאַניק 0 ז אויב די רעזולטאַט איז נישט ענדלעך, נעגאַטיוו אָדער אָוווערפלאָוז קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// מאַלטאַפּלייס קס 01 קס דורך קס 00 קס.
    /// # Panics
    /// דעם אופֿן וועט ז 0 פּאַניק 0 ז אויב די רעזולטאַט איז נישט ענדלעך, נעגאַטיוו אָדער אָוווערפלאָוז קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // טאָן אַז רעכט צו ראַונדינג ערראָרס רעזולטאַט איז אַ ביסל אַנדערש פון קס 01 קס און קס 00 קס
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// טיילן `Duration` דורך `f64`.
    /// # Panics
    /// דעם אופֿן וועט ז 0 פּאַניק 0 ז אויב די רעזולטאַט איז נישט ענדלעך, נעגאַטיוו אָדער אָוווערפלאָוז קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // טאָן אַז טרונקאַטיאָן איז געניצט, נישט ראַונדינג
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// טיילן `Duration` דורך `f32`.
    /// # Panics
    /// דעם אופֿן וועט ז 0 פּאַניק 0 ז אויב די רעזולטאַט איז נישט ענדלעך, נעגאַטיוו אָדער אָוווערפלאָוז קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // טאָן אַז רעכט צו ראַונדינג ערראָרס רעזולטאַט איז אַ ביסל אַנדערש פון קס 00 קס
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // טאָן אַז טרונקאַטיאָן איז געניצט, נישט ראַונדינג
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// טיילן `Duration` דורך `Duration` און צוריקקומען `f64`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// טיילן `Duration` דורך `Duration` און צוריקקומען `f32`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// פאָרמאַץ אַ פלאָוטינג פונט נומער אין דעצימאַל נאָוטיישאַן.
        ///
        /// די נומער איז געוויזן ווי די `integer_part` און אַ פראַקשאַנאַל טייל.
        /// די ווערט פון די פראַקשאַנאַל טייל איז `fractional_part / divisor`.
        /// אַזוי `integer_part` =3, `fractional_part` =12 און `divisor` =100 רעפּראַזענץ די נומער `3.012`.
        /// טריילינג זעראָס זענען איבערגעהיפּערט.
        ///
        /// `divisor` מוזן נישט זיין אויבן 100_000_000.
        /// עס זאָל אויך זיין אַ מאַכט פון 10, אַלץ אַנדערש טוט נישט מאַכן זינען.
        /// `fractional_part` מוזן זיין ווייניקער ווי קס 00 קס!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // ענקאָוד די פראַקשאַנאַל טייל אין אַ צייַטווייַליק באַפער.
            // די באַפער נאָר דאַרפֿן צו האַלטן 9 עלעמענטן ווייַל `fractional_part` מוזן זיין קלענערער ווי 10 ^ 9.
            //
            // די באַפער איז פּרעפיללעד מיט קס 00 קס דידזשאַץ צו פאַרפּאָשעטערן די קאָד אונטן.
            let mut buf = [b'0'; 9];

            // דער ווייַטער ציפֿער איז געשריבן אין דעם שטעלע
            let mut pos = 0;

            // מיר האַלטן שרייבן דידזשאַץ אין די באַפער בשעת עס זענען ניט-נול דידזשאַץ לינקס און מיר האָבן נישט געשריבן גענוג דידזשאַץ נאָך.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // שרייב נייַע ציפֿער אין די באַפער
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // אויב אַ פּינטלעכקייַט <9 איז געווען ספּעסיפיעד, עס קען זיין עטלעכע ניט-נול דידזשאַץ וואָס זענען נישט געשריבן אין די באַפער.
            // אין דעם פאַל, מיר דאַרפֿן צו דורכפירן ראָונדינג צו גלייַכן די סעמאַנטיקס פון דרוקן נאָרמאַל פלאָוטינג נומערן.
            // אָבער, מיר נאָר דאַרפֿן צו טאָן אַרבעט ווען ראַונדינג אַרויף.
            // דאָס כאַפּאַנז אויב די ערשטע ציפֿער פון די רוען איז>=5.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // ראָונד אַרויף די נומער קאַנטיינד אין די באַפער.
                // מיר גיין דורך די באַפער קאַפּויער און האַלטן שפּור פון די פירן.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // אויב די ציפֿער אין די באַפער איז נישט '9', מיר נאָר דאַרפֿן צו ינקרעמענט עס און קענען האַלטן עס (ווייַל מיר האָבן ניט מער).
                    // אַנדערש מיר שטעלן עס צו קס 00 קס קס 01 קס און פאָרזעצן.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // אויב מיר נאָך האָבן די טראָגן ביסל שטעלן, אַז מיטל אַז מיר שטעלן די גאַנץ באַפער צו '0 ס' און מיר דאַרפֿן צו ינקראַמאַנט די ינטאַדזשער טייל.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // באַשטימען די סוף פון די באַפער: אויב פּינטלעכקייַט איז באַשטימט, מיר נאָר נוצן ווי פילע דידזשאַץ פון די באַפער (קאַפּט צו 9).
            // אויב עס איז נישט באַשטימט, מיר נוצן בלויז אַלע דידזשאַץ ביז די לעצטע ניט-נול.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // אויב מיר האָבן נישט אַרויסגעגעבן קיין איין בראָכצאָל ציפֿער און די פּינטלעכקייט איז נישט באַשטימט צו אַ ניט-נול ווערט, מיר דרוקן נישט די דעצימאַל פונט.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // זיכערקייט: מיר שרייבן בלויז די ASCII דידזשאַץ אין די באַפער און דאָס איז געווען
                // יניטיאַלייזד מיט '0 ס, אַזוי עס כּולל גילטיק קס 00 קס.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // אויב דער באַניצער ריקווייערז אַ פּינטלעכקייַט> 9, מיר פּלאַד '0 ס אין די סוף.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // דרוק לידינג '+' צייכן אויב געבעטן
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}