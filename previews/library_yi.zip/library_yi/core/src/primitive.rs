//! דער מאָדולע רעעקספּאָרץ די פּרימיטיוו טייפּס צו לאָזן די נוצן וואָס איז ניט שיידיד דורך אנדערע דערקלערט טייפּס.
//!
//! דאָס איז נאָרמאַלי בלויז נוציק אין מאַקראָו דזשענערייטאַד קאָד.
//!
//! אַ ביישפּיל פון דעם איז ווען דזשענערייטינג אַ נייַ סטרוקטור און אַ ימפּ פֿאַר אים:
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! באַמערקונג אַז די `SOME_PROPERTY` פֿאַרבונדן קעסיידערדיק וואָלט נישט צונויפנעמען, ווייַל די טיפּ `bool` רעפערס צו די סטרוקטור, אלא ווי די פּרימיטיוו bool טיפּ.
//!
//!
//! א ריכטיק ימפּלאַמענטיישאַן קען זיין ווי:
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;