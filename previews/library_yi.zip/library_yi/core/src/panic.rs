//! ז 0 פּאַניק 0 ז שטיצן אין דער נאָרמאַל ביבליאָטעק.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// א סטרוקטור וואָס גיט אינפֿאָרמאַציע וועגן אַ panic.
///
/// `PanicInfo` סטרוקטור איז דורכגעגאנגען צו אַ panic hook באַשטימט דורך די [`set_hook`] פונקציע.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// רעטורנס די פּיילאָוד פֿאַרבונדן מיט די panic.
    ///
    /// דאָס וועט אָפט זיין אַ `&'static str` אָדער [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// אויב די `panic!` מאַקראָו פון די `core` crate (נישט פֿון `std`) איז געוויינט מיט אַ פאָרמאַטטינג שטריקל און עטלעכע נאָך אַרגומענטן, קערט דער אָנזאָג גרייט צו זיין געניצט פֿאַר ביישפּיל מיט [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// קערט אינפֿאָרמאַציע וועגן דעם אָרט פֿון וואָס די panic ערידזשנייטיד, אויב עס איז בארעכטיגט.
    ///
    /// דער אופֿן וועט דערווייַל שטענדיק צוריקקומען [`Some`], אָבער דאָס קען טוישן אין future ווערסיעס.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: אויב דאָס איז טשיינדזשד צו מאל צוריקקומען קיינער,
        // האַנדלען מיט דעם פאַל אין קס 01 קס און קס 00 קס.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: מיר קענען נישט נוצן downcast_ref: :<String>() דאָ
        // זינט סטרינג איז ניט בנימצא אין ליבקאָרע!
        // די פּיילאָוד איז אַ שטריקל ווען `std::panic!` איז גערופֿן מיט קייפל אַרגומענטן, אָבער אין דעם פאַל, דער אָנזאָג איז אויך בנימצא.
        //

        self.location.fmt(formatter)
    }
}

/// א סטרוקטור מיט אינפֿאָרמאַציע וועגן דעם אָרט פון אַ panic.
///
/// די סטרוקטור איז באשאפן דורך קס 00 קס.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// קאָמפּאַריסאָנס פֿאַר יקוואַלאַטי און אָרדערינג זענען געמאכט אין טעקע, שורה און דער זייַל בילכערקייַט.
/// טעקעס זענען קאַמפּערד ווי סטרינגס, נישט `Path`, וואָס קען זיין אומגעריכט.
/// פֿאַר מער דיסקוסיע זען די דאָקומענטאַטיאָן פון ["אָרט: : טעקע"].
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// קערט דער מקור אָרט פון די קאַללער פון דעם פֿונקציע.
    /// אויב די קאַללער פון די פאַנגקשאַנז איז אַנאַטייטיד, זיין רופן אָרט וועט זיין אומגעקערט, און אַזוי אויף דעם אָנלייגן צו דער ערשטער רוף אין אַ ניט-טראַקט פונקציאָנירן גוף.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// קערט די [`Location`] ביי וואָס עס איז גערופן.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// קערט אַ [`Location`] פֿון דעם פונקציע 'ס דעפֿיניציע.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // אויב איר לויפן די זעלבע ונטראַקקעד פונקציע אין אַ אַנדערש אָרט, מיר געבן די זעלבע רעזולטאַט
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // פליסנדיק די טראַקט פונקציע אין אַ אַנדערש אָרט טראגט אַ אַנדערש ווערט
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// רעטורנס די נאָמען פון די מקור טעקע פֿון וואָס די panic ערידזשנייטיד.
    ///
    /// # `&str`, ניט קס 00 קס
    ///
    /// די אומגעקערט נאָמען רעפערס צו אַ מקור דרך אויף די קאַמפּיילינג סיסטעם, אָבער עס איז נישט גילטיק צו פאָרשטעלן דאָס גלייַך ווי אַ קס 00 קס.
    /// די קאַמפּיילד קאָד קען לויפן אויף אַ אַנדערש סיסטעם מיט אַ אַנדערש קס 00 קס ימפּלאַמענטיישאַן ווי די סיסטעם צוגעשטעלט די אינהאַלט, און די ביבליאָטעק האט דערווייַל נישט אַ אַנדערש קס 01 קס טיפּ.
    ///
    /// די מערסט חידוש אָפּפירונג אַקערז ווען "the same" טעקע איז ריטשאַבאַל דורך קייפל פּאַטס אין די מאָדולע סיסטעם (יוזשאַוואַלי ניצן די `#[path = "..."]` אַטריביוט אָדער ענלעך), וואָס קען פאַרשאַפן וואָס די סימפּלי קאָד איז די זעלבע פונקציאָנירן.
    ///
    ///
    /// # Cross-compilation
    ///
    /// די ווערט איז ניט פּאַסיק פֿאַר פאָרן צו `Path::new` אָדער ענלעך קאַנסטראַקטערז ווען די באַלעבאָס פּלאַטפאָרמע און ציל פּלאַטפאָרמע זענען אַנדערש.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// רעטורנס די שורה נומער פֿון וואָס די panic ערידזשנייטיד.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// קערט דער זייַל פֿון וואָס די panic איז אָריגינעל.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// אַן ינערלעך trait געניצט דורך libstd צו פאָרן דאַטן פון libstd צו `panic_unwind` און אנדערע panic runtime.
/// ניט בדעה צו זיין סטייבאַלייזד באַלד, טאָן ניט נוצן.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// נעמען פול אָונערשיפּ פון די אינהאַלט.
    /// די צוריקקער טיפּ איז אַקשלי קס 00 קס, אָבער מיר קענען נישט נוצן קס 01 קס אין ליבקאָרע.
    ///
    /// נאָך די גערופֿן דעם אופֿן, `self` איז בלויז לינקס עטלעכע פעליק פעליקייַט ווערט.
    /// רופן דעם אופֿן צוויי מאָל, אָדער רופן `get` נאָך פאַך דעם אופֿן, איז אַ טעות.
    ///
    /// די אַרגומענט איז באַראָוד ווייַל די panic רונטימע (`__rust_start_panic`) בלויז געץ אַ באַראָוד `dyn BoxMeUp`.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// נאָר באָרגן די אינהאַלט.
    fn get(&mut self) -> &(dyn Any + Send);
}