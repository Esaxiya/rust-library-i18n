use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// די ז 0 טראַיט 0 ז פּראָווידעס טראַנזיטיוו אַקסעס צו מקור בינע אין אַן ינטעראַטאָר אַדאַפּטער רערנ-ליניע אונטער די באדינגונגען
/// * די יטעראַטאָר מקור קס 01 קס זיך ימפּלאַמאַנץ קס 00 קס
/// * עס איז אַ דעלאַגייטינג ימפּלאַמענטיישאַן פון דעם ז 0 טראַיט 0 ז פֿאַר יעדער אַדאַפּטער אין די רערנ-ליניע צווישן די מקור און די רערנ-ליניע קאַנסומער.
///
/// ווען דער מקור איז אַן אָונער יטעראַטאָר סטרוקטור (קאַמאַנלי גערופן קס 01 קס), דאָס קען זיין נוציק פֿאַר ספּעשאַלייזינג קס 00 קס ימפּלאַמענטיישאַנז אָדער צו צוריקקריגן די רוען עלעמענטן נאָך אַ ויסמאַטערן יטעראַטאָר.
///
///
/// באַמערקונג אַז ימפּלעמענטאַטיאָנס טאָן ניט דאַווקע האָבן צו צושטעלן אַקסעס צו די ינער מערסט מקור פון אַ רערנ-ליניע.א סטאַטעפול ינטערמידייט אַדאַפּטער קען יגערלי אָפּשאַצן אַ טייל פון די רערנ-ליניע און ויסשטעלן זייַן ינערלעך סטאָרידזש ווי מקור.
///
/// די trait איז אַנסייף ווייַל ימפּלעמענטאָרס מוזן האַלטן נאָך זיכערקייַט פּראָפּערטיעס.
/// זען [`as_inner`] פֿאַר דעטאַילס.
///
/// # Examples
///
/// צוריקקריגן אַ טייל קאַנסומד מקור:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// א מקור בינע אין אַ יטעראַטאָר רערנ-ליניע.
    type Source: Iterator;

    /// צוריקקריגן די מקור פון אַ יטעראַטאָר רערנ-ליניע.
    ///
    /// # Safety
    ///
    /// ימפּלעמענטאַטיאָנס פון מוזן צוריקקומען דער זעלביקער מיוטאַבאַל דערמאָנען פֿאַר זייער לעבן, סייַדן ריפּלייסט דורך אַ קאָלער.
    /// קאַללערס קען פאַרבייַטן די רעפֿערענץ בלויז ווען זיי סטאַפּט יטעראַטיאָן און פאַלן די יטעראַטאָר רערנ-ליניע נאָך יקסטראַקטינג די מקור.
    ///
    /// דעם מיטל יטעראַטאָר אַדאַפּטערז קענען פאַרלאָזנ זיך אַז דער מקור איז נישט טשאַנגינג בעשאַס יטעראַטיאָן, אָבער זיי קענען נישט פאַרלאָזנ אויף אים אין זייער דראָפּ ימפּלעמענטאַטיאָנס.
    ///
    /// ימפּלעמענטינג דעם אופֿן מיטל אַדאַפּטערז אָפּזאָגן פּריוואַט-בלויז אַקסעס צו זייער מקור און קענען בלויז פאַרלאָזנ אויף געראַנטיז געמאכט באזירט אויף מעטהאָדס ופנעמער טייפּס.
    /// דער מאַנגל פון ריסטריקטיד אַקסעס אויך ריקווייערז אַז אַדאַפּטערז מוזן ונטערהאַלטן די מקור אַפּי פון די מקור אפילו ווען זיי האָבן אַקסעס צו די ינערלעך.
    ///
    /// קאַללערס אין דרייען מוזן דערוואַרטן אַז די מקור איז אין קיין שטאַט וואָס איז קאָנסיסטענט מיט זייַן עפנטלעך אַפּי זינט אַדאַפּטערז וואָס זיצן צווישן אים און די מקור האָבן די זעלבע אַקסעס.
    /// אין באַזונדער, אַ אַדאַפּטער קען האָבן קאַנסומד מער עלעמענטן ווי שטרענג נייטיק.
    ///
    /// די קוילעלדיק ציל פון די באדערפענישן איז צו לאָזן די קאַנסומער פון אַ רערנ-ליניע נוצן
    /// * וועלכער בלייבט אין די מקור נאָך יטעראַטיאָן סטאַפּט
    /// * דער זכּרון וואָס האט ווערן אַניוזד דורך אַדוואַנסינג אַ קאַנסומינג יטעראַטאָר
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// אַ יטעראַטאָר אַדאַפּטער וואָס פּראָדוצירן פּראָדוקציע ווי לאַנג ווי די אַנדערלייינג יטעראַטאָר טראגט `Result::Ok` וואַלועס.
///
///
/// אויב איר טרעפן אַ טעות, די יטעראַטאָר סטאַפּס און דער טעות איז סטאָרד.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// פּראַסעס די געגעבן יטעראַטאָר ווי אויב עס יילד אַ קס 01 קס אַנשטאָט פון אַ קס 00 קס.
/// קיין ערראָרס וועט האַלטן די ינער יטעראַטאָר און די קוילעלדיק רעזולטאַט איז אַ טעות.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}