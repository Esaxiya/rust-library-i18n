use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// אַ יטעראַטאָר וואָס יטעראַטעס צוויי אנדערע יטעראַטאָרס סיימאַלטייניאַסלי.
///
/// דעם קס 01 קס איז באשאפן דורך קס 00 קס.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // אינדעקס, len און a_len ווערן נאר גענוצט דורך די ספעציאליזירטע ווערסיע פון זיפ
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // זיכערקייט: קס 00 קס האט זעלביקער זיכערקייַט
        // באדערפענישן ווי קס 00 קס.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// זיפּ ספּעשאַלאַזיישאַן trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // דעם האט דער זעלביקער זיכערקייַט רעקווירעמענץ ווי קס 00 קס
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// אַלגעמיינע זיפּ ימפּ
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // סטרויערן a, b צו גלייַך לענג
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // זיכערקייט: קס 02 קס איז קלענערער ווי קס 01 קס, אַזוי קלענערער ווי קס 03 קס און קס 00 קס
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // זיכערהייט: מיר פּונקט אָפּגעשטעלט אַז קס 01 קס <קס 00 קס
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // זיכערקייט: די באַניץ פון קס 01 קס צו רעכענען קס 00 קס
                // ינשורז אַז קס 02 קס איז קלענערער ווי אָדער גלייַך צו קס 01 קס, אַזוי קס 03 קס איז אויך קלענערער ווי קס 00 קס.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // זיכערקייט: זעלביקער ווי אויבן.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // סטרויערן a, b צו גלייַך לענג, מאַכן זיכער אַז בלויז דער ערשטער רוף פון קס 01 קס טוט דאָס, אַנדערש מיר וועלן ברעכן די ריסטריקשאַן צו רופן צו קס 02 קס נאָך רופן קס 00 קס.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // זיכערקייט: קס 01 קס איז קלענערער ווי די פריערדיקע ווערט פון קס 00 קס,
            // וואָס איז אויך קלענערער ווי אָדער גלייַך צו קס 01 קס און קס 00 קס
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // זיכערקייט: די קאַללער מוזן האַלטן די אָפּמאַך פֿאַר קס 00 קס.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// אַרביטרעראַלי סאַלעקץ די לינקס זייַט פון די פאַרשלעסלען יטעראַטיאָן ווי יקסטראַקטאַבאַל קס 00 קס, עס וואָלט דאַרפן נעגאַטיוו ז 0 טראט 0 ז ז 0 באָונדס 0 ז צו קענען צו פּרובירן ביידע
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // זיכערקייט: אַנסייף פונקציאָנירן פאָרווערדינג צו אַנסייף פונקציאָנירן מיט דער זעלביקער באדערפענישן
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// לימיטעד צו יטעמס: קאָפּיע זינט ינטעראַקשאַן צווישן די נוצן פון Zip פון TrustedRandomAccess און Drop ימפּלאַמענטיישאַן פון די מקור איז ומקלאָר.
//
// אַן נאָך אופֿן וואָס קערט די נומער פון מאָל די מקור איז לאַדזשיקלי אַוואַנסירטע (אָן רופן next()) וואָלט זיין דארף צו רעכט פאַלן די רעשט פון די מקור.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // עס איז *נישט זיכער* צו רופן פמט אויף די קאַנטיינד יטעראַטאָרס, ווייַל אַמאָל מיר אָנהייבן יטעראַטינג, זיי זענען אין מאָדנע, פּאַטענטשאַלי אַנסייף, שטאַטן.
        //
        f.debug_struct("Zip").finish()
    }
}

/// אַ יטעראַטאָר וועמענס זאכן זענען ראַנדאַמלי צוטריטלעך יפישאַנטלי
///
/// # Safety
///
/// די `size_hint` פון די יטעראַטאָר מוזן זיין פּינטלעך און ביליק צו רופן.
///
/// `size` קען נישט זיין אָווועררייד.
///
/// `<Self as Iterator>::__iterator_get_unchecked` מוזן זיין זיכער צו רופן צוגעשטעלט די פאלגענדע באדינגונגען.
///
/// 1. `0 <= idx` און קס 00 קס.
/// 2. אויב `self: !Clone`, `get_unchecked` איז קיינמאָל גערופן די זעלבע אינדעקס אויף `self` מער ווי אַמאָל.
/// 3. נאָך `self.get_unchecked(idx)` איז גערופֿן, `next_back` וועט זיין גערופֿן בלויז `self.size() - idx - 1` מאל.
/// 4. נאָך די רוף פון `get_unchecked`, `self` וועט זיין גערופֿן בלויז די פאלגענדע מעטהאָדס:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// ווייַל די באדינגונגען זענען מקיים, עס מוזן גאַראַנטירן אַז:
///
/// * עס קען נישט טוישן די ווערט פֿון `size_hint` וואָס איז אומגעקערט
/// * עס מוזן זיין זיכער צו רופן די אויבן `self` מעטהאָדס נאָך רופן `get_unchecked`, אַסומינג אַז די פארלאנגט ז 0 טראַיצ 0 ז זענען ימפּלאַמענאַד.
///
/// * עס דאַרף אויך זיין זיכער צו פאַלן `self` נאָך רופן `get_unchecked`.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // קאַנוויניאַנס אופֿן.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` אויב איר באַקומען אַן יטעראַטאָר עלעמענט קען האָבן זייַט יפעקס.
    /// געדענקט צו נעמען ינער יטעראַטאָרס אין חשבון.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// ווי קס 01 קס, אָבער טוט נישט דאַרפן די קאַמפּיילער צו וויסן אַז קס 00 קס.
///
///
/// ## Safety
///
/// די זעלבע באדערפענישן פאַך קס 00 קס גלייַך.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // זיכערקייט: די קאַללער מוזן האַלטן די אָפּמאַך פֿאַר קס 00 קס.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// אויב קס 01 קס, עס מוזן זיין זיכער צו רופן אַ קס 00 קס.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // זיכערקייט: די קאַללער מוזן האַלטן די אָפּמאַך פֿאַר קס 00 קס.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}