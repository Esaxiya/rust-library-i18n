// ignore-tidy-filelength די טעקע באשטייט כּמעט אויסשליסלעך פֿון דער דעפֿיניציע פון קס 00 קס.
// מיר קענען נישט שפּאַלטן דאָס אין קייפל טעקעס.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// אַ צובינד פֿאַר האַנדלינג מיט יטעראַטאָרס.
///
/// דאָס איז די הויפּט יטעראַטאָר ז 0 טראַיט 0 ז.
/// פֿאַר מער אינפֿאָרמאַציע וועגן די באַגריף פון יטעראַטאָרס בכלל, ביטע זען די [module-level documentation].
/// אין באַזונדער, איר קען וועלן צו וויסן ווי צו [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// דער טיפּ פון עלעמענטן וואָס זענען יטעראַטעד איבער.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// אַדוואַנסאַז די יטעראַטאָר און קערט דער ווייַטער ווערט.
    ///
    /// קערט [`None`] ווען יטעראַטיאָן איז פאַרטיק.
    /// ינדיווידואַל יטעראַטאָר ימפּלאַמענטיישאַנז קענען קלייַבן צו נעמענ זיכ ווידער יטעראַטיאָן, און אַזוי רופן `next()` ווידער קען אָדער קען נישט יווענטשאַוואַלי אָנהייבן צוריקקומען [`Some(Item)`] ווידער אין עטלעכע פונט.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // א רוף צו next() קערט דער ווייַטער ווערט ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... און גאָרניט אַמאָל עס איז איבער.
    /// assert_eq!(None, iter.next());
    ///
    /// // מער רופט קען `None` צוריקקומען אָדער ניט.דאָ, זיי שטענדיק וועלן.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// רעטורנס די גווול אויף די רוען לענג פון יטעראַטאָר.
    ///
    /// ספּאַסיפיקלי, `size_hint()` קערט אַ טופּאַל וווּ דער ערשטער עלעמענט איז דער נידעריקער גרענעץ, און די רגע עלעמענט איז דער אויבערשטער גרענעץ.
    ///
    /// די רגע האַלב פון די טופּלע וואָס איז אומגעקערט איז אַן [`אָפּציע`] <`[`נוצן גרייס`]`> `.
    /// א קס 01 קס דאָ מיטל אַז עס איז קיין באַוווסט אויבערשטער באַונד, אָדער דער אויבערשטער באַונד איז גרעסער ווי קס 00 קס.
    ///
    /// # ימפּלאַמענטיישאַן הערות
    ///
    /// עס איז נישט ענפאָרסט אַז אַ יטעראַטאָר ימפּלאַמענטיישאַן גיט די דערקלערט נומער פון עלעמענטן.א וואָגן יטעראַטאָר קען טראָגן ווייניקער ווי דער נידעריקער גרענעץ אָדער מער ווי דער אויבערשטער גרענעץ פון עלעמענטן.
    ///
    /// `size_hint()` איז בפֿרט בדעה צו ווערן גענוצט פֿאַר אָפּטימיזאַטיאָנס אַזאַ ווי רעזערווירן פּלאַץ פֿאַר די יסודות פון יטעראַטאָר, אָבער עס קען ניט זיין טראַסטיד צו למשל דורכשליסן גווול טשעקס אין אַנסייף קאָד.
    /// אַ פאַלש ימפּלאַמענטיישאַן פון קס 00 קס זאָל נישט פירן צו ווייאַליישאַנז פון זכּרון זיכערקייַט.
    ///
    /// ווי געזאָגט, די ימפּלאַמענטיישאַן זאָל צושטעלן אַ ריכטיק אָפּשאַצונג ווייַל אַנדערש עס וואָלט זיין אַ הילעל פון די פּראָטאָקאָל פון trait.
    ///
    /// די פעליקייַט ימפּלאַמענטיישאַן קערט `(0,` [`קיינער`]`)`וואָס איז ריכטיק פֿאַר קיין יטעראַטאָר.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// א מער קאָמפּליצירט בייַשפּיל:
    ///
    /// ```
    /// // די אפילו נומערן פון נול צו צען.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // מיר קען יבערקערן פון נול צו צען מאל.
    /// // די וויסן אַז עס ס 'פינף איז פּונקט ניט מעגלעך אָן עקסאַקיוטינג filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // זאל ס לייגן פינף מער נומערן מיט chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // איצט ביידע גווולז זענען געוואקסן דורך פינף
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// צוריקקומען קס 00 קס פֿאַר אַ אויבערשטער גרענעץ:
    ///
    /// ```
    /// // אַ ינפאַנאַט יטעראַטאָר האט קיין אויבערשטער גרענעץ און די מאַקסימום מעגלעך נידעריקער גרענעץ
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// קאַנסומז די יטעראַטאָר, קאַונטינג די נומער פון יטעראַטיאָנס און אומגעקערט עס.
    ///
    /// דעם אופֿן וועט רוף [`next`] ריפּיטידלי ביז [`None`] איז געפּלאָנטערט, און די נומער פון מאָל עס האָט געזען [`Some`].
    /// באַמערקונג אַז קס 00 קס דאַרף זיין רופן בייַ מינדסטער אַמאָל, אפילו אויב די יטעראַטאָר האט קיין עלעמענטן.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # אָוווערפלאָו נאַטור
    ///
    /// דער אופֿן קען נישט היטן קעגן אָוווערפלאָוז, אַזוי קאַונטינג עלעמענטן פון אַ יטעראַטאָר מיט מער ווי X00 קס עלעמענטן, אָדער טראגט דעם אומרעכט רעזולטאַט אָדער ז 0 פּאַניקס 0 ז.
    ///
    /// אויב דיבאַג באַשטעטיקן זענען ענייבאַלד, אַ panic איז געראַנטיד.
    ///
    /// # Panics
    ///
    /// די פונקציע קען ז 0 פּאַניק 0 ז אויב די יטעראַטאָר האט מער ווי X00 קס עלעמענטן.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// קאַנסומז די יטעראַטאָר, צוריקקומען די לעצטע עלעמענט.
    ///
    /// דער אופֿן וועט אָפּשאַצן די יטעראַטאָר ביז ער קערט [`None`].
    /// בשעת טאן עס, עס האלט שפּור פון די קראַנט עלעמענט.
    /// נאָך די צוריקקומען פון [`None`], `last()` וועט צוריקקומען די לעצטע עלעמענט עס איז געווען.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// אַדוואַנסאַז יטעראַטאָר דורך `n` עלעמענטן.
    ///
    /// דעם אופֿן וועט יגערלי האָפּקען `n` עלעמענטן דורך רופן [`next`] אַרויף צו `n` מאָל ביז [`None`] איז געפּלאָנטערט.
    ///
    /// `advance_by(n)` וועט צוריקקומען [`Ok(())`][Ok] אויב די יטעראַטאָר הצלחה אַדוואַנסאַז דורך `n` עלעמענטן, אָדער [`Err(k)`][Err] אויב [`None`] איז געפּלאָנטערט, וווּ `k` איז די נומער פון עלעמענטן וואָס יטעראַטאָר איז אַוואַנסירטע דורך איידער עס לויפן אויס פון די עלעמענטן (ד"ה
    /// די לענג פון יטעראַטאָר).
    /// באַמערקונג אַז קס 01 קס איז שטענדיק ווייניקער ווי קס 00 קס.
    ///
    /// פאַך קס 01 קס טוט ניט פאַרנוצן קיין עלעמענטן און שטענדיק קערט קס 00 קס.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // בלויז `&4` איז סקיפּט
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// קערט דער `n` טה עלעמענט פון יטעראַטאָר.
    ///
    /// ווי רובֿ ינדעקסינג אַפּעריישאַנז, די ציילן סטאַרץ פון נול, אַזוי קס 01 קס קערט דער ערשטער ווערט, קס 00 קס די רגע, און אַזוי אויף.
    ///
    /// באַמערקונג אַז אַלע פריערדיקע עלעמענטן, ווי געזונט ווי די אומגעקערט עלעמענט, וועט זיין קאַנסומד פֿון יטעראַטאָר.
    /// אַז מיטל אַז די פריערדיקע עלעמענטן וועט זיין דיסקאַרדיד, און אַז די רוף `nth(0)` קייפל מאָל אויף דער זעלביקער יטעראַטאָר וועט צוריקקומען פאַרשידענע עלעמענטן.
    ///
    ///
    /// `nth()` וועט צוריקקומען [`None`] אויב `n` איז גרעסער ווי אָדער גלייַך צו די יטעראַטאָר לענג.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// רופן `nth()` קייפל מאָל קען נישט ריוויינד די יטעראַטאָר:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// אומגעקערט קס 00 קס אויב עס זענען ווייניקער ווי קס 01 קס עלעמענטן:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// קרעאַטעס אַ יטעראַטאָר סטאַרטינג אויף דער זעלביקער פונט, אָבער סטעפּינג די סומע אין יעדער יטעראַטיאָן.
    ///
    /// באַמערקונג 1: דער ערשטער עלעמענט פון יטעראַטאָר וועט שטענדיק זיין אומגעקערט, ראַגאַרדלאַס פון די שריט געגעבן.
    ///
    /// באַמערקונג 2: די צייט אין וואָס איגנאָרירט עלעמענטן זענען פּולד איז נישט פאַרפעסטיקט.
    /// `StepBy` ביכייווז ווי די סיקוואַנס קס 00 קס, אָבער איז אויך פריי צו ביכייוו ווי די סיקוואַנס
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// וואָס וועג איז געניצט קען טוישן פֿאַר עטלעכע יטעראַטאָרס פֿאַר פאָרשטעלונג סיבות.
    /// די צווייטע וועג וועט ברענגען דעם יטעראַטאָר פריער און קען פאַרנוצן מער זאכן.
    ///
    /// `advance_n_and_return_first` איז דער עקוויוואַלענט פון:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// דער אופֿן וועט panic אויב די געגעבן שריט איז `0`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// נעמט צוויי יטעראַטאָרס און קריייץ אַ נייַ יטעראַטאָר איבער ביידע אין סיקוואַנס.
    ///
    /// `chain()` וועט צוריקקומען אַ נייַ יטעראַטאָר וואָס ערשטער יטעראַט איבער די וואַלועס פון דער ערשטער יטעראַטאָר און דאַן איבער די וואַלועס פון די רגע יטעראַטאָר.
    ///
    /// אין אנדערע ווערטער, עס פֿאַרבינדט צוויי יטעראַטאָרס צוזאַמען אין אַ קייט.🔗
    ///
    /// [`once`] איז אָפט געניצט צו אַדאַפּט אַ איין ווערט אין אַ קייט פון אנדערע מינים פון יטעראַטיאָן.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// זינט די אַרגומענט צו קס 02 קס ניצט קס 00 קס, מיר קענען פאָרן עפּעס וואָס קענען זיין קאָנווערטעד אין אַ קס 01 קס, ניט נאָר אַ קס 03 קס זיך.
    /// פֿאַר בייַשפּיל, סלייסאַז קס 01 קס ינסטרומענט קס 00 קס, און אַזוי קענען זיין דורכגעגאנגען צו קס 02 קס גלייַך:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// אויב איר אַרבעט מיט Windows API, איר ווילט צו קאָנווערט [`OsStr`] צו `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'זיפּס אַרויף' צוויי יטעראַטאָרס אין אַ איין יטעראַטאָר פון פּערז.
    ///
    /// `zip()` קערט א נייע איטעראטאר וועלכער וועט איטערירן איבער צוויי אנדערע איטעראטארן, צוריקברענגענדיג א טופלע וואו דער ערשטער עלעמענט קומט פונעם ערשטן איטעראטאר, און דער צווייטער עלעמענט קומט פונעם צווייטן איטעראטאר.
    ///
    ///
    /// אין אנדערע ווערטער, עס זיפּס צוויי יטעראַטאָרס צוזאַמען, אין אַ איין.
    ///
    /// אויב יעדער יטעראַטאָר קערט קס 01 קס, קס 02 קס פון די זיפּט יטעראַטאָר וועט צוריקקומען קס 00 קס.
    /// אויב דער ערשטער יטעראַטאָר קערט [`None`], `zip` וועט קורץ-קרייַז און `next` וועט נישט זיין גערופן אויף די רגע יטעראַטאָר.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// זינט די אַרגומענט צו קס 02 קס ניצט קס 00 קס, מיר קענען פאָרן עפּעס וואָס קענען זיין קאָנווערטעד אין אַ קס 01 קס, ניט נאָר אַ קס 03 קס זיך.
    /// פֿאַר בייַשפּיל, סלייסאַז קס 01 קס ינסטרומענט קס 00 קס, און אַזוי קענען זיין דורכגעגאנגען צו קס 02 קס גלייַך:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` איז אָפט געניצט צו פאַרשלעסלען אַן ינפאַנאַט יטעראַטאָר צו אַ ענדלעך.
    /// דאָס אַרבעט ווייַל די ענדלעך יטעראַטאָר וועט יווענטשאַוואַלי צוריקקומען קס 01 קס און ענדיקן די זיפּפּער.פאַרשלעסלען מיט `(0..)` קענען זיין פיל ווי [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// קרעאַטעס אַ נייַ יטעראַטאָר וואָס לייגט אַ קאָפּיע פון קס 00 קס צווישן שכייניש ייטאַמז פון דער אָריגינעל יטעראַטאָר.
    ///
    /// אין פאַל [`intersperse_with`] איז נישט ימפּלאַמענטאַד [`Clone`] אָדער עס דאַרף צו זיין קאַמפּיוטיד יעדער מאָל, נוצן [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // דער ערשטער עלעמענט פון קס 00 קס.
    /// assert_eq!(a.next(), Some(&100)); // די סעפּאַראַטאָר.
    /// assert_eq!(a.next(), Some(&1));   // די ווייַטער עלעמענט פון קס 00 קס.
    /// assert_eq!(a.next(), Some(&100)); // די סעפּאַראַטאָר.
    /// assert_eq!(a.next(), Some(&2));   // די לעצטע עלעמענט פֿון `a`.
    /// assert_eq!(a.next(), None);       // די יטעראַטאָר איז פאַרטיק.
    /// ```
    ///
    /// `intersperse` קענען זיין זייער נוציק צו פאַרבינדן אַן יטעראַטאָר 'ס זאכן מיט אַ פּראָסט עלעמענט:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// קרעאַטעס אַ נייַ יטעראַטאָר וואָס אָרט אַן נומער דזשענערייטאַד דורך קס 00 קס צווישן שכייניש ייטאַמז פון דער אָריגינעל יטעראַטאָר.
    ///
    /// די קלאָוזשער וועט זיין גערופֿן פּונקט אַמאָל יעדער מאָל אַ נומער איז שטעלן צווישן צוויי שכייניש ייטאַמז פֿון די אַנדערלייינג יטעראַטאָר.
    /// ספּאַסיפיקלי, די קלאָוזשער איז נישט גערופן אויב די אַנדערלייינג יטעראַטאָר ייעלדס ווייניקער ווי צוויי זאכן און נאָך די לעצטע נומער איז יילדאַד.
    ///
    ///
    /// אויב די נומער פון יטעראַטאָר ימפּלאַמאַנץ [`Clone`], עס קען זיין גרינגער צו נוצן [`intersperse`].
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // דער ערשטער עלעמענט פון קס 00 קס.
    /// assert_eq!(it.next(), Some(NotClone(99))); // די סעפּאַראַטאָר.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // די ווייַטער עלעמענט פון קס 00 קס.
    /// assert_eq!(it.next(), Some(NotClone(99))); // די סעפּאַראַטאָר.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // די לעצטע עלעמענט פֿון `v`.
    /// assert_eq!(it.next(), None);               // די יטעראַטאָר איז פאַרטיק.
    /// ```
    ///
    /// `intersperse_with` קענען ווערן גענוצט אין סיטואַטיאָנס וווּ די סעפּאַראַטאָר דאַרף זיין קאַמפּיוטאַד:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // די קלאָוזשער באַראָוד מוטאַבלי זיין קאָנטעקסט צו דזשענערייט אַ נומער.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// נעמט אַ קלאָוזשער און קריייץ אַ יטעראַטאָר וואָס רופט די קלאָוזשער אויף יעדער עלעמענט.
    ///
    /// `map()` פארוואנדלט איין יטעראַטאָר אין אנדערן דורך זיין אַרגומענט:
    /// עפּעס אַז ימפּלאַמאַנץ קס 00 קס.עס טראגט אַ נייַ יטעראַטאָר וואָס רופט דעם קלאָוזשער אויף יעדער עלעמענט פון דער אָריגינעל יטעראַטאָר.
    ///
    /// אויב איר זענט גוט צו טראַכטן וועגן טייפּס, איר קענען טראַכטן וועגן `map()` ווי דאָס:
    /// אויב איר האָט אַ יטעראַטאָר וואָס גיט איר עלעמענטן פון עטלעכע טיפּ קס 01 קס, און איר ווילט אַ יטעראַטאָר פון עטלעכע אנדערע טיפּ קס 02 קס, איר קענען נוצן קס 03 קס, פּאַסינג אַ קלאָוזשער אַז נעמט אַן קס 04 קס און קערט אַ קס 00 קס.
    ///
    ///
    /// `map()` איז קאַנסעפּטשואַלי ענלעך צו אַ קס 00 קס שלייף.ווייַל `map()` איז פויל, דאָס איז בעסטער געניצט ווען איר שוין ארבעטן מיט אנדערע יטעראַטאָרס.
    /// אויב איר טאָן אַ סאָרט פון לופּינג פֿאַר אַ זייַט ווירקונג, עס איז באטראכט ווי מער ידיאָמאַטיק צו נוצן [`for`] ווי `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// אויב איר טאָן עטלעכע זייַט זייַט ווירקונג, בעסער [`for`] צו `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // טאָן ניט טאָן דאָס:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // עס וועט נישט אפילו דורכפירן ווייַל עס איז פויל.Rust וועט וואָרענען איר וועגן דעם.
    ///
    /// // אַנשטאָט, נוצן פֿאַר:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// רופט אַ קלאָוזשער אויף יעדער עלעמענט פון אַ יטעראַטאָר.
    ///
    /// דאָס איז עקוויוואַלענט צו נוצן אַ [`for`] שלייף אויף די יטעראַטאָר, כאָטש `break` און `continue` זענען ניט מעגלעך פֿון אַ קלאָוזשער.
    /// עס איז בכלל מער ידיאַמאַטיק צו נוצן אַ `for` שלייף, אָבער `for_each` קען זיין מער ליינעוודיק ווען פּראַסעסינג ייטאַמז אין די סוף פון מער יטעראַטאָר קייטן.
    ///
    /// אין עטלעכע פאלן, קס 01 קס קען אויך זיין פאַסטער ווי אַ שלייף ווייַל עס וועט נוצן ינערלעך יטעראַטיאָן אויף אַדאַפּטערז ווי קס 00 קס.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// פֿאַר אַזאַ אַ קליין בייַשפּיל, אַ `for` שלייף קען זיין קלינער, אָבער `for_each` קען זיין בילכער צו האַלטן אַ פאַנגקשאַנאַל סטיל מיט מער יטעראַטאָרס:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// קריייץ אַן יטעראַטאָר וואָס ניצט אַ קלאָוזשער צו באַשליסן אויב אַן עלעמענט זאָל זיין יילדאַד.
    ///
    /// מיט אַן עלעמענט, די קלאָוזשער מוזן צוריקקומען קס 01 קס אָדער קס 00 קס.די אומגעקערט יטעראַטאָר וועט בלויז טראָגן די עלעמענטן פֿאַר וואָס די קלאָוזשער קערט אמת.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ווייַל די קלאָוזשער איבערגעגעבן צו `filter()` נעמט אַ רעפֿערענץ, און פילע יטעראַטאָרס יטערייט איבער באַווייַזן, דאָס פירט צו אַ עפשער קאַנפיוזינג סיטואַציע, וווּ די טיפּ פון די קלאָוזשער איז אַ טאָפּל דערמאָנען:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // דאַרפֿן צוויי * ס!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// עס איז פּראָסט צו אַנשטאָט נוצן דיסטראַקטשערינג אין דעם אַרגומענט צו פּאַסירן איינער:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ביידע און און *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// אָדער ביידע:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // צוויי קס 00 קס
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// פון די לייַערס.
    ///
    /// באַמערקונג אַז קס 01 קס איז עקוויוואַלענט צו קס 00 קס.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// קרעאַטעס אַ יטעראַטאָר אַז ביידע פילטערס און מאַפּס.
    ///
    /// די אומגעקערט יטעראַטאָר גיט בלויז די 'ווערט' ס פֿאַר וואָס די סאַפּלייד קלאָוזשער קערט `Some(value)`.
    ///
    /// `filter_map` קענען זיין געניצט צו מאַכן קייטן פון קס 00 קס און קס 01 קס מער קאַנסייס.
    /// די ביישפּיל אונטן ווייזט ווי אַ `map().filter().map()` קענען זיין פאַרקירצט צו אַ איין רוף צו `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// דאָ ס דער זעלביקער בייַשפּיל, אָבער מיט [`filter`] און [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// קרעאַטעס אַ יטעראַטאָר וואָס גיט די קראַנט יטעראַטיאָן ציילן און די ווייַטער ווערט.
    ///
    /// די יטעראַטאָר אומגעקערט ייעלדס פּערז `(i, val)`, ווו `i` איז די קראַנט אינדעקס פון יטעראַטיאָן און `val` איז די ווערט פון די יטעראַטאָר.
    ///
    ///
    /// `enumerate()` האלט זייַן רעכענען ווי אַ קס 00 קס.
    /// אויב איר ווילט צו ציילן דורך אַ גאַנץ סומע, די [`zip`] פונקציע אָפפערס ענלעך פאַנגקשאַנאַליטי.
    ///
    /// # אָוווערפלאָו נאַטור
    ///
    /// דער אופֿן קען נישט היטן קעגן אָוווערפלאָוז, אַזוי אַז מער ווי X00 קס עלעמענטן קענען אויך מאַכן דעם אומרעכט רעזולטאַט אָדער ז 0 פּאַניקס 0 ז.
    /// אויב דיבאַג באַשטעטיקן זענען ענייבאַלד, אַ panic איז געראַנטיד.
    ///
    /// # Panics
    ///
    /// די אומגעקערט יטעראַטאָר קען ז 0 פּאַניק 0 ז אויב די צו-זיין-אומגעקערט אינדעקס וואָלט לויפן אַ קס 00 קס.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// קרעאַטעס אַ יטעראַטאָר וואָס קענען נוצן [`peek`] צו קוקן אויף די ווייַטער עלעמענט פון יטעראַטאָר אָן קאַנסומינג.
    ///
    /// לייגט אַ [`peek`] אופֿן צו אַ יטעראַטאָר.פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
    ///
    /// באַמערקונג אַז די אַנדערלייינג יטעראַטאָר איז נאָך אַוואַנסירטע ווען [`peek`] איז גערופֿן פֿאַר די ערשטער מאָל: אין סדר צו צוריקקריגן דעם ווייַטער עלעמענט, [`next`] איז גערופֿן אויף די אַנדערלייינג יטעראַטאָר, דערפאר קיין זייַט יפעקס (י.ע.
    ///
    /// עפּעס אַנדערש ווי פעטשינג די ווייַטער ווערט) פון די [`next`] אופֿן וועט פּאַסירן.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() לאָזן אונדז זען די future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // מיר קענען קקסנומקס קס קייפל מאָל, די יטעראַטאָר וועט נישט שטייַגן
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // נאָך די יטעראַטאָר איז פאַרטיק, אַזוי איז peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// קרעאַטעס אַ יטעראַטאָר אַז [`האָפּקען`] ס עלעמענטן באזירט אויף אַ פּרעדיקאַט.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` נעמט אַ קלאָוזשער ווי אַן אַרגומענט.דער קלאָוזשער וועט זיין רופן אויף יעדער עלעמענט פון יטעראַטאָר און איגנאָרירן עלעמענטן ביז עס קערט `false`.
    ///
    /// נאָך די צוריקקומען פון קס 01 קס, קס 00 קס אַרבעט איז איבער, און די רעשט פון די עלעמענטן זענען יילדאַד.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ווייַל די קלאָוזשער איז דורכגעקאָכט צו קסקסנומקסקס נעמט אַ רעפֿערענץ, און פילע יטעראַטאָרס יטערייט איבער באַווייַזן, דאָס פירט צו אַ עפשער קאַנפיוזינג סיטואַציע, וווּ דער טיפּ פון קלאָוזשער אַרגומענט איז אַ טאָפּל דערמאָנען:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // דאַרפֿן צוויי * ס!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// סטאָפּפּינג נאָך אַן ערשט `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // בשעת דאָס וואָלט האָבן שוין פאַלש, זינט מיר שוין גאַט אַ פאַלש, קס 00 קס איז ניט געוויינט קיין מער
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// קרעאַטעס אַ יטעראַטאָר אַז ייעלדס עלעמענטן באזירט אויף אַ פּרעדיקאַט.
    ///
    /// `take_while()` נעמט אַ קלאָוזשער ווי אַן אַרגומענט.די קלאָוזשער וועט זיין גערופֿן אויף יעדער עלעמענט פון יטעראַטאָר און טראָגן עלעמענטן בשעת עס קערט `true`.
    ///
    /// נאָך די צוריקקומען פון קס 01 קס, קס 00 קס אַרבעט איז איבער, און די מנוחה פון די עלעמענטן זענען איגנאָרירט.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ווייַל די קלאָוזשער איבערגעגעבן צו `take_while()` נעמט אַ רעפֿערענץ, און פילע יטעראַטאָרס יטערייט איבער באַווייַזן, דאָס פירט צו אַ עפשער קאַנפיוזינג סיטואַציע, וווּ די טיפּ פון די קלאָוזשער איז אַ טאָפּל דערמאָנען:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // דאַרפֿן צוויי * ס!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// סטאָפּפּינג נאָך אַן ערשט `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // מיר האָבן מער עלעמענטן וואָס זענען ווייניקער ווי נול, אָבער זינט מיר האָבן שוין פאַלש, take_while() איז נישט געניצט מער
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ווייַל `take_while()` דאַרף קוקן אויף די ווערט צו זען אויב עס זאָל זיין אַרייַנגערעכנט אָדער נישט, קאַנסומינג יטעראַטאָרס וועט זען אַז עס איז אַוועקגענומען:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// די `3` איז ניט מער דאָרט ווייַל עס איז קאַנסומד צו זען אויב די יטעראַטיאָן זאָל האַלטן, אָבער עס איז נישט געשטעלט צוריק אין די יטעראַטאָר.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// קרעאַטעס אַ יטעראַטאָר אַז ביידע ייעלדס עלעמענטן באזירט אויף אַ פּרעדיקאַט און מאַפּס.
    ///
    /// `map_while()` נעמט אַ קלאָוזשער ווי אַן אַרגומענט.
    /// דער קלאָוזשער וועט זיין רופן אויף יעדער עלעמענט פון יטעראַטאָר און טראָגן עלעמענטן בשעת עס קערט [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// דאָ ס דער זעלביקער בייַשפּיל, אָבער מיט [`take_while`] און [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// סטאָפּפּינג נאָך אַן ערשט [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // מיר האָבן מער עלעמענטן וואָס קענען פּאַסיק אין u32 (4, 5), אָבער `map_while` אומגעקערט `None` פֿאַר `-3` (ווי `predicate` אומגעקערט `None`) און `collect` סטאַפּס אין דער ערשטער `None` געפּלאָנטערט.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// ווייַל `map_while()` דאַרף קוקן אויף די ווערט צו זען אויב עס זאָל זיין אַרייַנגערעכנט אָדער נישט, קאַנסומינג יטעראַטאָרס וועט זען אַז עס איז אַוועקגענומען:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// די `-3` איז ניט מער דאָרט ווייַל עס איז קאַנסומד צו זען אויב די יטעראַטיאָן זאָל האַלטן, אָבער עס איז נישט געשטעלט צוריק אין די יטעראַטאָר.
    ///
    /// באַמערקונג אַז ניט ענלעך קס 00 קס דעם יטעראַטאָר איז **נישט** פיוזד.
    /// עס איז אויך נישט ספּעציפיצירט וואָס דעם יטעראַטאָר קערט נאָך די ערשטע [`None`] איז אומגעקערט.
    /// אויב איר דאַרפֿן פיוזד יטעראַטאָר, נוצן [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// קרעאַטעס אַ יטעראַטאָר וואָס סקיפּס די ערשטער `n` עלעמענטן.
    ///
    /// נאָך קאַנסומד, די רעשט פון די עלעמענטן זענען יילדאַד.
    /// אלא ווי אָוווערריידינג דעם אופֿן גלייַך, אַנשטאָט אָווועררייד די `nth` אופֿן.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// קרעאַטעס אַ יטעראַטאָר אַז ייעלדס זיין ערשטער `n` עלעמענטן.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` איז אָפט געניצט מיט אַ ינפאַנאַט יטעראַטאָר צו מאַכן עס ענדלעך:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// אויב ווייניקער ווי `n` עלעמענטן זענען פאַראַנען, `take` וועט באַגרענעצן זיך צו די גרייס פון די אַנדערלייינג יטעראַטאָר:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// אַ יטעראַטאָר אַדאַפּטער ענלעך צו קסקסנומקס קס וואָס האלט ינערלעך שטאַט און טראגט אַ נייַ יטעראַטאָר.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` נעמט צוויי אַרגומענטן: אַן ערשט ווערט וואָס זאמען די ינערלעך שטאַט, און אַ קלאָוזשער מיט צוויי אַרגומענטן, דער ערשטער איז אַ מיוטאַבאַל רעפֿערענץ צו די ינערלעך שטאַט און די רגע אַן יטעראַטאָר עלעמענט.
    ///
    /// די קלאָוזשער קענען באַשטימען צו די ינערלעך שטאַט צו טיילן שטאַט צווישן יטעראַטיאָנס.
    ///
    /// אויף יטעראַטיאָן, די קלאָוזשער וועט זיין געווענדט צו יעדער יטעראַטאָר עלעמענט, און די יטעראַטאָר גיט די צוריקקער ווערט פון די קלאָוזשער, אַן [`Option`].
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // יעדער יטעראַטיאָן, מיר מערן די שטאַט דורך דעם עלעמענט
    ///     *state = *state * x;
    ///
    ///     // דערנאָך, מיר וועט געבן די נעגאַטיוו פון די שטאַט
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// קרעאַטעס אַ יטעראַטאָר וואָס אַרבעט ווי מאַפּע, אָבער פלאַטאַנז נעסטעד סטרוקטור.
    ///
    /// די [`map`] אַדאַפּטער איז זייער נוציק, אָבער בלויז ווען די קלאָוזשער אַרגומענט טראגט וואַלועס.
    /// אויב עס אַנשטאָט אַ יטעראַטאָר, עס איז אַן עקסטרע שיכטע פון ינדירעקטיאָן.
    /// `flat_map()` וועט אַראָפּנעמען דעם עקסטרע פּלאַסט אויף זיך.
    ///
    /// איר קענען טראַכטן פון `flat_map(f)` ווי די סעמאַנטיק עקוויוואַלענט פון [`מאַפּע`] פּינג, און דערנאָך [`פלאַטאַן`] ינג ווי אין `map(f).flatten()`.
    ///
    /// אן אנדער וועג צו טראַכטן וועגן `flat_map()`: די קלאָוזשער פון [`מאַפּע`] קערט איין נומער פֿאַר יעדער עלעמענט, און `flat_map()`'s קלאָוזשער קערט אַ יטעראַטאָר פֿאַר יעדער עלעמענט.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() קערט אַ יטעראַטאָר
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// קריייץ אַן יטעראַטאָר וואָס פלאַטאַנז נעסטעד סטרוקטור.
    ///
    /// דאָס איז נוציק ווען איר האָבן אַ יטעראַטאָר פון יטעראַטאָרס אָדער אַ יטיראַטאָר פון טינגז וואָס קענען ווערן פארוואנדלען אין יטעראַטאָרס און איר ווילן צו באַזייַטיקן איין מדרגה פון ינדירעקטיאָן.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// מאַפּפּינג און דאַן פלאַטנינג:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() קערט אַ יטעראַטאָר
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// איר קענט אויך רירייט דאָס אין טערמינען פון [`flat_map()`], וואָס איז בילכער אין דעם פאַל ווייַל עס קאַנווייז קלאר קלאר:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() קערט אַ יטעראַטאָר
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// פלאַטנינג רימוווז בלויז אַ מדרגה פון נעסטינג אין יעדער צייט:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// דאָ מיר זען אַז קס 00 קס טוט נישט דורכפירן אַ קס 01 קס פלאַטאַן.
    /// אַנשטאָט, בלויז איין מדרגה פון נעסטינג איז אַוועקגענומען.דאָס איז, אויב איר `flatten()` אַ דריי-דימענשאַנאַל מענגע, דער רעזולטאַט וועט זיין צוויי-דימענשאַנאַל און ניט איין-דימענשאַנאַל.
    /// צו באַקומען אַן איין-דימענשאַנאַל סטרוקטור, איר מוזן קקסנומקס קס ווידער.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// קריייץ אַ יטעראַטאָר וואָס ענדס נאָך דער ערשטער [`None`].
    ///
    /// נאָך אַ יטעראַטאָר קערט [`None`], future קאַללס קען זיין [`Some(T)`] ווידער.
    /// `fuse()` אַדאַפּט אַן יטעראַטאָר, ינשורינג אַז נאָך אַ קס 00 קס איז שטענדיק געגעבן X01 קס אויף אייביק.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// // אַ יטעראַטאָר וואָס אָלטערנייץ צווישן עטלעכע און קיינער
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // אויב עס איז אפילו, קס 00 קס, אַנדערש קיינער
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // מיר קענען זען אונדזער יטעראַטאָר גייט צוריק און צוריק
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // אַמאָל מיר פיוז עס אָבער ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // עס וועט שטענדיק צוריקקומען `None` נאָך די ערשטער מאָל.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// טוט עפּעס מיט יעדער עלעמענט פון אַ יטעראַטאָר, און די ווערט צו פאָרן.
    ///
    /// ווען איר נוצן יטעראַטאָרס, איר אָפט מאַכן עטלעכע פון זיי צוזאַמען.
    /// בשעת ארבעטן אויף אַזאַ קאָד, איר זאל וועלן צו קאָנטראָלירן וואָס ס געשעעניש אין פאַרשידענע פּאַרץ אין דער רערנ-ליניע.צו טאָן דאָס, שטעלן אַ רוף צו `inspect()`.
    ///
    /// עס איז מער געוויינטלעך אַז `inspect()` איז גענוצט ווי אַ דיבאַגינג געצייַג ווי אין דיין לעצט קאָד, אָבער אַפּלאַקיישאַנז קען זיין נוציק אין זיכער סיטואַטיאָנס ווען ערראָרס דאַרפֿן צו זיין לאָגד איידער זיי ווערן אַוועק.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // דעם יטעראַטאָר סיקוואַנס איז קאָמפּלעקס.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // לאָמיר לייגן עטלעכע קס 00 קס קאַללס צו פאָרשן וואָס ס געשעעניש
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// דער וועט דרוקן:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// לאָגינג ערראָרס איידער זיי אַוועקוואַרפן זיי:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// דער וועט דרוקן:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// באָרז אַן יטעראַטאָר, אלא ווי עס קאַנסומינג.
    ///
    /// דאָס איז נוציק צו דערלויבן אַפּלייינג יטעראַטאָר אַדאַפּטערז און נאָך האַלטן אָונערשיפּ פון דער אָריגינעל יטעראַטאָר.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // אויב מיר פּרובירן צו נוצן יטער ווידער, עס וועט נישט אַרבעטן.
    /// // די פאלגענדע שורה גיט "טעות: נוצן פון אריבערגעפארן ווערט: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // לאָמיר פּרובירן דאָס ווידער
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // אַנשטאָט, מיר לייגן אין אַ .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // איצט דאָס איז פּונקט פייַן:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// טראַנספאָרמז אַ יטעראַטאָר אין אַ זאַמלונג.
    ///
    /// `collect()` איר קענען נעמען עפּעס יטעראַבאַל און מאַכן עס אַ באַטייטיק זאַמלונג.
    /// דאָס איז איינער פון די מער שטאַרק מעטהאָדס אין דער נאָרמאַל ביבליאָטעק, געוויינט אין אַ פאַרשיידנקייַט פון קאַנטעקסץ.
    ///
    /// די מערסט יקערדיק מוסטער אין וואָס `collect()` איז געניצט איז צו מאַכן איין זאַמלונג אין אנדערן.
    /// איר נעמען אַ זאַמלונג, רופן די [`iter`], מאַכן אַ בינטל פון טראַנספערמיישאַנז און X11X אין די סוף.
    ///
    /// `collect()` קענען אויך מאַכן ינסטאַנסיז פון טייפּס וואָס זענען נישט טיפּיש זאַמלונגען.
    /// למשל, אַ [`String`] קענען זיין געבויט פֿון [`טשאַר`] s, און אַ יטעראַטאָר פון [`Result<T, E>`][`Result`] ייטאַמז קענען זיין קאַלעקטאַד אין `Result<Collection<T>, E>`.
    ///
    /// זען די ביישפילן אונטן פֿאַר מער.
    ///
    /// ווייַל `collect()` איז אַזוי גענעראַל, עס קען אָנמאַכן פּראָבלעמס מיט טיפּ ינפעראַנס.
    /// ווי אַזאַ, `collect()` איז איינער פון די ווייניק מאָל איר וועט זען די סינטאַקס, מיט די באַרימט 'turbofish': `::<>`.
    /// דאָס העלפּס די ינפעראַנס אַלגערידאַם צו פֿאַרשטיין ספּאַסיפיקלי אין וואָס זאַמלונג איר פּרובירן צו זאַמלען.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// באַמערקונג אַז מיר דאַרפֿן די `: Vec<i32>` אויף די לינקס זייַט.דאָס איז ווייַל מיר קען קלייַבן אין אַ [`VecDeque<T>`] אַנשטאָט:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// ניצן די 'turbofish' אַנשטאָט פון אַנאָטייטינג `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ווייַל `collect()` נאָר זאָרגן וועגן וואָס איר קלייַבן, איר קענט נאָך נוצן אַ פּאַרטיייש אָנצוהערעניש, `_`, מיט די טערבאָופיש:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ניצן `collect()` צו מאַכן אַ [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// אויב איר האָט אַ רשימה פון [`רעזולטאַט<T, E>'][`רעזולטאַט`] s, איר קענען נוצן `collect()` צו זען אויב איינער פון זיי אַנדערש:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // גיט אונדז דער ערשטער טעות
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // גיט אונדז די רשימה פון ענטפֿערס
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// קאַנסומז אַ יטעראַטאָר, קריייטינג צוויי זאַמלונגען פֿון אים.
    ///
    /// די פּרעדיקאַט דורכגעגאנגען צו קס 02 קס קענען צוריקקומען קס 01 קס, אָדער קס 00 קס.
    /// `partition()` קערט אַ פּאָר, אַלע די עלעמענטן פֿאַר וואָס עס אומגעקערט קס 01 קס, און אַלע די עלעמענטן פֿאַר וואָס עס אומגעקערט קס 00 קס.
    ///
    ///
    /// זען אויך קס 01 קס און קס 00 קס.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// ריאָרדערז די עלעמענטן פון דעם יטעראַטאָר *אין-אָרט* לויט די געגעבן פּרעדיקאַט, אַזוי אַז אַלע יענע וואָס צוריקקומען קס 01 קס פאָרויס אַלע יענע וואָס צוריקקומען קס 00 קס.
    ///
    /// קערט די נומער פון געפֿונען `true` עלעמענטן.
    ///
    /// די קאָרעוו סדר פון צעטיילט זאכן איז נישט מיינטיינד.
    ///
    /// זען אויך קס 01 קס און קס 00 קס.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // צעטיילונג אין-אָרט צווישן יוואַנז און שאַנסן
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: זאָל מיר זאָרג וועגן דעם ציילן אָוווערפלאָוינג?דער בלויז וועג צו האָבן מער ווי
        // `usize::MAX` מיוטאַבאַל באַווייַזן זענען מיט ZSTs, וואָס זענען נישט נוציק צו צעטיילונג ...

        // די "factory" פאַנגקשאַנז זענען קלאָוזד צו ויסמיידן דזשאַנעריסיטי אין `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // געפֿינען די ערשטער קס 01 קס ריפּיטידלי און ויסבייַטן עס מיט די לעצטע קס 00 קס.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// טשעקס אויב די יסודות פון דעם יטעראַטאָר זענען צעטיילט לויט דעם פּרידיקאַט, אַזוי אַז אַלע וואָס צוריקקומען קס 01 קס גיינ פריער אַלע יענע וואָס צוריקקומען קס 00 קס.
    ///
    ///
    /// זען אויך קס 01 קס און קס 00 קס.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // אָדער אַלע זאכן זענען טעסטעד צו `true`, אָדער דער ערשטער פּונקט סטאַפּס ביי `false` און מיר קאָנטראָלירן אַז עס זענען ניט מער `true` זאכן נאָך.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// אַ יטעראַטאָר מעטאָד וואָס אַפּלייז אַ פונקציע ווי לאַנג ווי עס קערט הצלחה און פּראָדוצירן אַ איין, לעצט ווערט.
    ///
    /// `try_fold()` נעמט צוויי אַרגומענטן: אַן ערשט ווערט, און אַ קלאָוזשער מיט צוויי אַרגומענטן: אַן 'accumulator', און אַן עלעמענט.
    /// די קלאָוזשער אָדער קערט הצלחה, מיט די ווערט אַז די אַקיומיאַלייטער זאָל האָבן פֿאַר דער ווייַטער יטעראַטיאָן, אָדער ער קערט דורכפאַל, מיט אַ טעות ווערט וואָס איז פּראַפּאַגייטיד צוריק צו די קאָלער גלייך (short-circuiting).
    ///
    ///
    /// די ערשטע ווערט איז די ווערט וואָס די אַקיומיאַלייטער וועט האָבן פֿאַר די ערשטער רופן.אויב אַפּלייינג די קלאָוזשער איז געראָטן קעגן יעדער עלעמענט פון יטעראַטאָר, `try_fold()` קערט די לעצט אַקיומיאַלייטער ווי הצלחה.
    ///
    /// פאָלדינג איז נוצלעך ווען איר האָבן אַ זאַמלונג פון עפּעס און איר ווילן צו פּראָדוצירן איין ווערט פון אים.
    ///
    /// # באַמערקונג צו ימפּלעמענטאָרס
    ///
    /// עטלעכע פון די אנדערע קס 00 קס מעטהאָדס האָבן ניט ויסצאָלן ימפּלאַמענטיישאַנז אין טערמינען פון דעם, אַזוי פּרובירן צו ינסטרומענט דעם בפירוש אויב עס קען טאָן עפּעס בעסער ווי די פעליקייַט קס 01 קס שלייף ימפּלאַמענטיישאַן.
    ///
    /// אין באַזונדער, פּרוּווט צו האָבן דעם רוף `try_fold()` אויף די ינערלעך פּאַרץ פון וואָס די יטעראַטאָר איז קאַמפּאָוזד.
    /// אויב קייפל רופט זענען נידז, די `?` אָפּעראַטאָר קען זיין באַקוועם צו קייטן די אַקיומיאַלייטער ווערט, אָבער היט אייך קיין ינוועריאַנץ וואָס דאַרפֿן צו זיין אַפּכעלד איידער די פרי קערט.
    /// דאָס איז אַ `&mut self` אופֿן, אַזוי עס זאָל זיין ריזומאַבאַל נאָך יטעראַטיאָן נאָך שלאָגן אַ טעות דאָ.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // די אָפּגעשטעלט סומע פון אַלע עלעמענטן פון די מענגע
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // די סומע איז אָוווערפלאָוז ווען אַדינג די 100 עלעמענט
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ווייַל עס איז קורץ-סערקאַטאַד, די רוען עלעמענטן זענען נאָך בנימצא דורך די יטעראַטאָר.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// אַ יטעראַטאָר מעטהאָדס אַז אַפּלייז אַ פאַלאַבאַל פונקציע צו יעדער נומער אין יטעראַטאָר, סטאָפּפּינג אין דער ערשטער טעות און אומגעקערט דעם טעות.
    ///
    ///
    /// דאָס קען אויך זיין געדאַנק ווי די פאַלאַבאַל פאָרעם פון [`for_each()`] אָדער ווי די סטאַטעלעסס ווערסיע פון [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // עס איז קורץ-סערקאַטאַד, אַזוי די רוען זאכן זענען נאָך אין די יטעראַטאָר:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// פאָולדז יעדער עלעמענט אין אַ אַקיומיאַלייטער דורך אַפּלייינג אַן אָפּעראַציע, צוריקקומען די לעצט רעזולטאַט.
    ///
    /// `fold()` נעמט צוויי אַרגומענטן: אַן ערשט ווערט, און אַ קלאָוזשער מיט צוויי אַרגומענטן: אַן 'accumulator', און אַן עלעמענט.
    /// די קלאָוזשער קערט די ווערט אַז די אַקיומיאַלייטער זאָל האָבן פֿאַר די ווייַטער יטעראַטיאָן.
    ///
    /// די ערשטע ווערט איז די ווערט וואָס די אַקיומיאַלייטער וועט האָבן פֿאַר די ערשטער רופן.
    ///
    /// נאָך אַפּלייינג דעם קלאָוזשער צו יעדער עלעמענט פון יטעראַטאָר, קקסנומקס קס קערט די אַקיומיאַלייטער.
    ///
    /// די אָפּעראַציע איז מאל גערופֿן קס 01 קס אָדער קס 00 קס.
    ///
    /// פאָלדינג איז נוצלעך ווען איר האָבן אַ זאַמלונג פון עפּעס און איר ווילן צו פּראָדוצירן איין ווערט פון אים.
    ///
    /// Note: `fold()`, און ענלעך מעטהאָדס אַז דורכפאָר די גאנצע יטעראַטאָר, קען נישט פאַרענדיקן פֿאַר ינפאַנאַט יטעראַטאָרס, אפילו אויף traits, פֿאַר וואָס אַ רעזולטאַט איז דיטערמאַנאַבאַל אין ענדלעך צייט.
    ///
    /// Note: קס 00 קס קענען זיין געוויינט צו נוצן די ערשטע עלעמענט ווי די ערשט ווערט אויב די אַקיומיאַלייטער טיפּ און נומער טיפּ איז די זעלבע.
    ///
    /// # באַמערקונג צו ימפּלעמענטאָרס
    ///
    /// עטלעכע פון די אנדערע קס 00 קס מעטהאָדס האָבן ניט ויסצאָלן ימפּלאַמענטיישאַנז אין טערמינען פון דעם, אַזוי פּרובירן צו ינסטרומענט דעם בפירוש אויב עס קען טאָן עפּעס בעסער ווי די פעליקייַט קס 01 קס שלייף ימפּלאַמענטיישאַן.
    ///
    ///
    /// אין באַזונדער, פּרובירן צו האָבן דעם רוף `fold()` אויף די ינערלעך פּאַרץ פון וואָס די יטעראַטאָר איז קאַמפּאָוזד.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // די סומע פון אַלע די יסודות פון די מענגע
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// זאל ס גיין דורך יעדער שריט פון די יטעראַטיאָן דאָ:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// און אַזוי, אונדזער לעצט רעזולטאַט, `6`.
    ///
    /// עס איז פּראָסט פֿאַר מענטשן וואָס האָבן נישט געניצט יטעראַטאָרס פיל צו נוצן אַ `for` שלייף מיט אַ רשימה פון טינגז צו בויען אַ רעזולטאַט.די קענען זיין פארקערט אין קס 00 קס:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // פֿאַר שלייף:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // זיי זענען די זעלבע
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// ראַדוסאַז די עלעמענטן צו איין, דורך ריפּיטידלי צולייגן אַ רידוסינג אָפּעראַציע.
    ///
    /// אויב די יטעראַטאָר איז ליידיק, קערט [`None`];אַנדערש, קערט דער רעזולטאַט פון די רעדוקציע.
    ///
    /// פֿאַר יטעראַטאָרס מיט לפּחות איין עלעמענט, דאָס איז די זעלבע ווי [`fold()`] מיט די ערשטע עלעמענט פון יטעראַטאָר ווי די ערשט ווערט, און פאָלדינג יעדער סאַבסאַקוואַנט עלעמענט אין עס.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// געפֿינען די מאַקסימום ווערט:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// טעסץ אויב יעדער עלעמענט פון יטעראַטאָר גלייַכן אַ פּרעדיקאַט.
    ///
    /// `all()` נעמט אַ קלאָוזשער אַז קערט קס 03 קס אָדער קס 01 קס.די אַפּלאַקיישאַן איז גילטיק פֿאַר יעדער עלעמענט פון יטעראַטאָר, און אויב זיי אַלע צוריקקומען קס 02 קס, דאָס אויך קס 00 קס.
    /// אויב איינער פון זיי צוריקקומען `false`, עס קערט `false`.
    ///
    /// `all()` איז קורץ-קרייזינג;אין אנדערע ווערטער, עס וועט האַלטן פּראַסעסינג ווי באַלד ווי עס טרעפט אַ קס 01 קס, ווייַל קיין ענין וואָס אַנדערש כאַפּאַנז, דער רעזולטאַט וועט אויך זיין קס 00 קס.
    ///
    ///
    /// א ליידיק יטעראַטאָר קערט `true`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// סטאַפּינג אין דער ערשטער `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // מיר קענען נאָך נוצן `iter`, ווייַל עס זענען מער עלעמענטן.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// טעסץ אויב קיין עלעמענט פון יטעראַטאָר גלייַכן אַ פּרעדיקאַט.
    ///
    /// `any()` נעמט אַ קלאָוזשער אַז קערט קס 03 קס אָדער קס 01 קס.דאָס איז אַפּלייז צו יעדער עלעמענט פון יטעראַטאָר, און אויב עמעצער פון זיי קערט קס 02 קס, דאָס אויך קס 00 קס.
    /// אויב זיי אַלע צוריקקומען קס 01 קס, עס קערט קס 00 קס.
    ///
    /// `any()` איז קורץ-קרייזינג;אין אנדערע ווערטער, עס וועט האַלטן פּראַסעסינג ווי באַלד ווי עס טרעפט אַ קס 01 קס, ווייַל קיין ענין וואָס אַנדערש כאַפּאַנז, דער רעזולטאַט וועט אויך זיין קס 00 קס.
    ///
    ///
    /// א ליידיק יטעראַטאָר קערט `false`.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// סטאַפּינג אין דער ערשטער `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // מיר קענען נאָך נוצן `iter`, ווייַל עס זענען מער עלעמענטן.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// זוך פֿאַר אַן עלעמענט פון אַ יטעראַטאָר וואָס סאַטיספייז אַ פּרעדיקאַט.
    ///
    /// `find()` נעמט אַ קלאָוזשער אַז קערט קס 01 קס אָדער קס 00 קס.
    /// עס איז אַפּלייז צו יעדער עלעמענט פון יטעראַטאָר, און אויב עמעצער פון זיי צוריקקומען `true`, `find()` קערט [`Some(element)`].
    /// אויב זיי אַלע צוריקקומען קס 01 קס, עס קערט קס 00 קס.
    ///
    /// `find()` איז קורץ-קרייזינג;אין אנדערע ווערטער, עס וועט האַלטן פּראַסעסינג ווי באַלד ווי די קלאָוזשער קערט `true`.
    ///
    /// ווייַל `find()` נעמט אַ רעפֿערענץ, און פילע יטעראַטאָרס יטעראַטע איבער באַווייַזן, דאָס פירט צו אַ עפשער קאַנפיוזינג סיטואַציע ווו די אַרגומענט איז אַ טאָפּל דערמאָנען.
    ///
    /// איר קענען זען דעם ווירקונג אין די ביישפילן אונטן מיט `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// סטאַפּינג אין דער ערשטער `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // מיר קענען נאָך נוצן `iter`, ווייַל עס זענען מער עלעמענטן.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// באַמערקונג אַז קס 01 קס איז עקוויוואַלענט צו קס 00 קס.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// אַפּלייז פונקציאָנירן צו די יסודות פון יטעראַטאָר און קערט דער ערשטער ניט-גאָרניט רעזולטאַט.
    ///
    ///
    /// `iter.find_map(f)` איז עקוויוואַלענט צו קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// אַפּלייז פונקציאָנירן צו די יטעראַטאָר עלעמענטן און קערט דער ערשטער אמת רעזולטאַט אָדער דער ערשטער טעות.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// זוך פֿאַר אַן עלעמענט אין אַ יטעראַטאָר, צוריק צו זיין אינדעקס.
    ///
    /// `position()` נעמט אַ קלאָוזשער אַז קערט קס 01 קס אָדער קס 00 קס.
    /// דאָס איז אַפּלייז צו יעדער עלעמענט פון יטעראַטאָר, און אויב איינער פון זיי קערט `true`, `position()` קערט [`Some(index)`].
    /// אויב אַלע פון זיי צוריקקומען קס 01 קס, עס קערט קס 00 קס.
    ///
    /// `position()` איז קורץ-קרייזינג;אין אנדערע ווערטער, עס וועט האַלטן פּראַסעסינג ווי באַלד ווי עס טרעפט אַ קס 00 קס.
    ///
    /// # אָוווערפלאָו נאַטור
    ///
    /// דער אופֿן קען נישט באַשיצן קעגן אָוווערפלאָוז, אַזוי אויב עס זענען מער ווי [`usize::MAX`] ניט-ריכטן עלעמענטן, עס אָדער טראגט דעם אומרעכט רעזולטאַט אָדער panics.
    ///
    /// אויב דיבאַג באַשטעטיקן זענען ענייבאַלד, אַ panic איז געראַנטיד.
    ///
    /// # Panics
    ///
    /// די פונקציע קען ז 0 פּאַניק 0 ז אויב די יטעראַטאָר האט מער ווי `usize::MAX` ניט-ריכטן עלעמענטן.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// סטאַפּינג אין דער ערשטער `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // מיר קענען נאָך נוצן `iter`, ווייַל עס זענען מער עלעמענטן.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // די אומגעקערט אינדעקס דעפּענדס אויף יטעראַטאָר שטאַט
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// זוכט אַן עלעמענט אין אַ יטעראַטאָר פֿון רעכטס און צוריקקומען זיין אינדעקס.
    ///
    /// `rposition()` נעמט אַ קלאָוזשער אַז קערט קס 01 קס אָדער קס 00 קס.
    /// די קלאָוזשער איז אַפּלייז צו יעדער עלעמענט פון יטעראַטאָר, אָנהייב פון דעם סוף, און אויב איינער פון זיי קערט `true`, `rposition()` קערט [`Some(index)`].
    ///
    /// אויב אַלע פון זיי צוריקקומען קס 01 קס, עס קערט קס 00 קס.
    ///
    /// `rposition()` איז קורץ-קרייזינג;אין אנדערע ווערטער, עס וועט האַלטן פּראַסעסינג ווי באַלד ווי עס טרעפט אַ קס 00 קס.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// סטאַפּינג אין דער ערשטער `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // מיר קענען נאָך נוצן `iter`, ווייַל עס זענען מער עלעמענטן.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // איר טאָן ניט דאַרפֿן אַ אָוווערפלאָו טשעק ווייַל `ExactSizeIterator` ימפּלייז אַז די נומער פון עלעמענטן פּאַסיק אין אַ `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// רעטורנס די מאַקסימום עלעמענט פון אַ יטעראַטאָר.
    ///
    /// אויב עטלעכע עלעמענטן זענען גלייַך מאַקסימום, די לעצטע עלעמענט איז אומגעקערט.
    /// אויב די יטעראַטאָר איז ליידיק, [`None`] איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// רעטורנס די מינימום עלעמענט פון אַ יטעראַטאָר.
    ///
    /// אויב עטלעכע עלעמענטן זענען מינימום, דער ערשטער עלעמענט איז אומגעקערט.
    /// אויב די יטעראַטאָר איז ליידיק, [`None`] איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// קערט דער עלעמענט וואָס גיט די מאַקסימום ווערט פון די ספּעסאַפייד פונקציע.
    ///
    ///
    /// אויב עטלעכע עלעמענטן זענען גלייַך מאַקסימום, די לעצטע עלעמענט איז אומגעקערט.
    /// אויב די יטעראַטאָר איז ליידיק, [`None`] איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// קערט דער עלעמענט וואָס גיט די מאַקסימום ווערט פֿאַר די ספּעסאַפייד פאַרגלייַך פונקציאָנירן.
    ///
    ///
    /// אויב עטלעכע עלעמענטן זענען גלייַך מאַקסימום, די לעצטע עלעמענט איז אומגעקערט.
    /// אויב די יטעראַטאָר איז ליידיק, [`None`] איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// קערט דער עלעמענט וואָס גיט די מינימום ווערט פון די ספּעסאַפייד פונקציע.
    ///
    ///
    /// אויב עטלעכע עלעמענטן זענען מינימום, דער ערשטער עלעמענט איז אומגעקערט.
    /// אויב די יטעראַטאָר איז ליידיק, [`None`] איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// רעטורנס דעם עלעמענט וואָס גיט די מינימום ווערט מיט אַ ספּעציפֿיש פאַרגלייַך פונקציאָנירן.
    ///
    ///
    /// אויב עטלעכע עלעמענטן זענען מינימום, דער ערשטער עלעמענט איז אומגעקערט.
    /// אויב די יטעראַטאָר איז ליידיק, [`None`] איז אומגעקערט.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ריווערסיז די ריכטונג פון יטעראַטאָר.
    ///
    /// יוזשאַוואַלי יטעראַטאָרס יטעראַטע פֿון לינקס צו רעכטס.
    /// נאָך ניצן `rev()`, אַ יטעראַטאָר יטעראַטעד פֿון רעכט צו לינקס.
    ///
    /// דאָס איז נאָר מעגלעך אויב די יטעראַטאָר האט אַ סוף, אַזוי `rev()` אַרבעט בלויז אויף [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// קאַנווערץ אַ יטעראַטאָר פון פּערז אין אַ פּאָר פון קאַנטיינערז.
    ///
    /// `unzip()` קאַנסומז אַ גאַנץ יטעראַטאָר פון פּערז, פּראַדוסינג צוויי זאַמלונגען: איינער פון די לינקס עלעמענטן פון דער פּערז און איינער פֿון די רעכט עלעמענטן.
    ///
    ///
    /// די פונקציע איז, אין עטלעכע זינען, די פאַרקערט פון קס 00 קס.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// קרעאַטעס אַ יטעראַטאָר וואָס קאַפּיז אַלע עלעמענטן.
    ///
    /// דאָס איז נוציק ווען איר האָבן אַ יטעראַטאָר איבער קס 01 קס, אָבער איר דאַרפֿן אַ יטעראַטאָר איבער קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // קאַפּיד איז די זעלבע ווי .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// קרעאַטעס אַ יטיראַטאָר וואָס [`קלאָון`] איז אַלע פון זיין עלעמענטן.
    ///
    /// דאָס איז נוציק ווען איר האָבן אַ יטעראַטאָר איבער קס 01 קס, אָבער איר דאַרפֿן אַ יטעראַטאָר איבער קס 00 קס.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // קלאָונד איז די זעלבע ווי קס 00 קס, פֿאַר ינטאַדזשערז
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ריפּיץ אַן יטעראַטאָר ענדלאַסלי.
    ///
    /// אַנשטאָט צו האַלטן [`None`], די יטעראַטאָר אַנשטאָט אָנהייבן פֿון די אָנהייב.נאָך יטעראַטינג ווידער, עס וועט אָנהייבן ווידער אין די אָנהייב.און נאכאמאל.
    /// און נאכאמאל.
    /// Forever.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// סאַמז די יסודות פון אַ יטעראַטאָר.
    ///
    /// נעמט יעדער עלעמענט, מוסיף זיי צוזאַמען און קערט דער רעזולטאַט.
    ///
    /// א ליידיק יטעראַטאָר קערט דער נול ווערט פון דעם טיפּ.
    ///
    /// # Panics
    ///
    /// ווען מען קערט צו `sum()` און אַ פּרימיטיוו ינטאַדזשער טיפּ איז אומגעקערט, דעם אופֿן וועט panic אויב די קאַמפּיאַטיישאַן אָוווערפלאָוז און דיבאַג באַשטעטיקן זענען ענייבאַלד.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// יטעראַטעס איבער די גאנצע יטעראַטאָר, מאַלטאַפּלייינג אַלע עלעמענטן
    ///
    /// א ליידיק יטעראַטאָר קערט דער איין ווערט פון דעם טיפּ.
    ///
    /// # Panics
    ///
    /// ווען מען רופט `product()` און אַ פּרימיטיוו ינטאַדזשער טיפּ איז אומגעקערט, די מעטאָד וועט panic אויב די קאַמפּיאַטיישאַן אָוווערפלאָוז און דיבאַג באַשטעטיקן זענען ענייבאַלד.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) קאַמפּערז די עלעמענטן פון דעם [`Iterator`] מיט די פון די אנדערע.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) קאַמפּערז די עלעמענטן פון דעם [`Iterator`] מיט יענע פון אן אנדערן וועגן די ספּעסיפיעד פאַרגלייַך פונקציאָנירן.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) קאַמפּערז די עלעמענטן פון דעם [`Iterator`] מיט די פון די אנדערע.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) קאַמפּערז די עלעמענטן פון דעם [`Iterator`] מיט יענע פון אן אנדערן וועגן די ספּעסיפיעד פאַרגלייַך פונקציאָנירן.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// דאַטערמאַנז אויב די עלעמענטן פון דעם [`Iterator`] זענען גלייַך צו די פון די אנדערע.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// דאַטערמאַנז אויב די עלעמענטן פון דעם [`Iterator`] זענען גלייַך צו די פון די אנדערע מיט די ספּעציפיצעד יקוואַלאַטי פונקציע.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// דאַטערמאַנז אויב די עלעמענטן פון דעם [`Iterator`] זענען ניט גלייך צו די אנדערע.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// דאַטערמאַנז אויב די [`Iterator`] יסודות זענען [lexicographically](Ord#lexicographical-comparison) ווייניקער ווי די אנדערע.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// דיטערמאַנז אויב די [`Iterator`] עלעמענטן זענען [lexicographically](Ord#lexicographical-comparison) ווייניקער אָדער גלייַך צו די פון די [`Iterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// דאַטערמאַנז אויב די [`Iterator`] עלעמענטן זענען [lexicographically](Ord#lexicographical-comparison) גרעסער ווי די פון די [`Iterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// דאַטערמאַנז אויב די [`Iterator`] עלעמענטן זענען [lexicographically](Ord#lexicographical-comparison) גרעסער ווי אָדער גלייַך צו די פון די [`Iterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// טשעקס אויב די יסודות פון דעם יטעראַטאָר זענען אויסגעשטעלט.
    ///
    /// אַז איז, פֿאַר יעדער עלעמענט קס 03 קס און זייַן ווייַטערדיק עלעמענט קס 00 קס, קס 01 קס מוזן האַלטן.אויב יטעראַטאָר ייעלדס פּונקט נול אָדער איין עלעמענט, `true` איז אומגעקערט.
    ///
    /// באַמערקונג אַז אויב `Self::Item` איז בלויז `PartialOrd`, אָבער נישט `PartialOrd`, די אויבן דעפֿיניציע ימפּלייז אַז די פֿונקציע קערט `false` אויב קיין צוויי קאָנסעקוטיווע ייטאַמז זענען ניט פאַרגלייַכלעך.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// טשעקס אויב די יסודות פון דעם יטעראַטאָר זענען אויסגעשטעלט מיט די געגעבן קאָמפּאַראַטאָר פונקציע.
    ///
    /// אַנשטאָט ניצן `PartialOrd::partial_cmp`, די פונקציע ניצט די געגעבן `compare` פונקציע צו באַשליסן די אָרדערינג פון צוויי עלעמענטן.
    /// חוץ דעם, עס ס עקוויוואַלענט צו קס 00 קס;זען דאַקיומענטיישאַן פֿאַר מער אינפֿאָרמאַציע.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// טשעקס אויב די יסודות פון דעם יטעראַטאָר זענען אויסגעשטעלט מיט די געגעבן שליסל יקסטראַקשאַן פונקציע.
    ///
    /// אַנשטאָט צו פאַרגלייכן די יטעראַטאָר עלעמענטן גלייַך, די פונקציע קאַמפּערז די שליסלען פון די עלעמענטן ווי X00 קס.
    /// חוץ דעם, עס ס עקוויוואַלענט צו קס 00 קס;זען דאַקיומענטיישאַן פֿאַר מער אינפֿאָרמאַציע.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// זען קס 00 קס
    // די ומגעוויינטלעך נאָמען איז צו ויסמייַדן נאָמען קאַליזשאַנז אין די האַכלאָטע פון מעטהאָדס, זען #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}