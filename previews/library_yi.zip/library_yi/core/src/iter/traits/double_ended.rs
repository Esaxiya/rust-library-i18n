use crate::ops::{ControlFlow, Try};

/// אַ יטעראַטאָר וואָס קענען געבן עלעמענטן פֿון ביידע ענדס.
///
/// עפּעס וואָס ימפּלאַמאַנץ קס 01 קס האט אַן עקסטרע פיייקייט איבער עפּעס וואָס ימפּלאַמאַנץ קס 00 קס: די פיייקייט צו נעמען `יטעמס פֿון די צוריק, ווי געזונט ווי די פראָנט.
///
///
/// עס איז וויכטיק צו באַמערקן אַז ביידע צוריק און אַרויס אַרבעט אויף דער זעלביקער קייט און טאָן ניט קרייַז: יטעראַטיאָן איז איבער ווען זיי טרעפן אין די מיטל.
///
/// אין אַ ענלעך שטייגער צו די [`Iterator`] פּראָטאָקאָל, אַמאָל `DoubleEndedIterator` קערט [`None`] פֿון אַ [`next_back()`], און רופן עס ווידער, אָדער קען ניט אלץ צוריקקומען [`Some`] ווידער.
/// [`next()`] און קס 00 קס זענען ינטערטשיינדזשאַבאַל פֿאַר דעם צוועק.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// רימוווז און קערט אַן עלעמענט פֿון די יטעראַטאָר.
    ///
    /// קערט `None` ווען עס זענען ניט מער עלעמענטן.
    ///
    /// די [trait-level] דאָקס אַנטהאַלטן מער דעטאַילס.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// די עלעמענטן יילדאַד דורך די מעטהאָדס פון "DoubleEndedIterator" קען זיין אַנדערש פון די מעטהאָדס פון ["Iterator"]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// אַדוואַנטידזשיז די יטעראַטאָר פֿון די `n` עלעמענטן פֿון די צוריק.
    ///
    /// `advance_back_by` איז די פאַרקערט ווערסיע פון קס 00 קס.דעם אופֿן וועט יגערלי האָפּקען `n` עלעמענטן סטאַרטינג פון די צוריק דורך רופן [`next_back`] אַרויף צו `n` מאָל ביז [`None`] איז געפּלאָנטערט.
    ///
    /// `advance_back_by(n)` וועט צוריקקומען [`Ok(())`] אויב די יטעראַטאָר הצלחה אַדוואַנסאַז דורך `n` עלעמענטן, אָדער [`Err(k)`] אויב [`None`] איז געפּלאָנטערט, וווּ `k` איז די נומער פון עלעמענטן וואָס יטעראַטאָר איז אַוואַנסירטע דורך איידער עס לויפן אויס פון די עלעמענטן (ד"ה
    /// די לענג פון יטעראַטאָר).
    /// באַמערקונג אַז קס 01 קס איז שטענדיק ווייניקער ווי קס 00 קס.
    ///
    /// פאַך קס 01 קס טוט ניט פאַרנוצן קיין עלעמענטן און שטענדיק קערט קס 00 קס.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // בלויז `&3` איז סקיפּט
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// רעטורנס די `n` טה עלעמענט פֿון די סוף פון יטעראַטאָר.
    ///
    /// דאָס איז יסענשאַלי די ריווערסט ווערסיע פון [`Iterator::nth()`].
    /// כאָטש ווי רובֿ ינדעקסינג אַפּעריישאַנז, די ציילן סטאַרץ פון נול, אַזוי `nth_back(0)` קערט דער ערשטער ווערט פון די סוף, `nth_back(1)` די רגע, און אַזוי אויף.
    ///
    ///
    /// באַמערקונג אַז אַלע עלעמענטן צווישן די סוף און די אומגעקערט עלעמענט וועט זיין קאַנסומד, אַרייַנגערעכנט די אומגעקערט עלעמענט.
    /// דאָס אויך מיטל אַז פאַך `nth_back(0)` קייפל מאָל אויף דער זעלביקער יטעראַטאָר וועט צוריקקומען פאַרשידענע עלעמענטן.
    ///
    /// `nth_back()` וועט צוריקקומען [`None`] אויב `n` איז גרעסער ווי אָדער גלייַך צו די יטעראַטאָר לענג.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// רופן `nth_back()` קייפל מאָל קען נישט ריוויינד די יטעראַטאָר:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// אומגעקערט קס 00 קס אויב עס זענען ווייניקער ווי קס 01 קס עלעמענטן:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// דאָס איז די פאַרקערט ווערסיע פון [`Iterator::try_fold()`]: עס נעמט עלעמענטן סטאַרטינג פֿון די צוריק פון יטעראַטאָר.
    ///
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ווייַל עס איז קורץ-סערקאַטאַד, די רוען עלעמענטן זענען נאָך בנימצא דורך די יטעראַטאָר.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// אַ יטעראַטאָר אופֿן אַז ראַדוסאַז די יטעראַטאָר ס עלעמענטן צו אַ איין, לעצט ווערט, סטאַרטינג פֿון די צוריק.
    ///
    /// דאָס איז די פאַרקערט ווערסיע פון [`Iterator::fold()`]: עס נעמט עלעמענטן סטאַרטינג פֿון די צוריק פון יטעראַטאָר.
    ///
    /// `rfold()` נעמט צוויי אַרגומענטן: אַן ערשט ווערט, און אַ קלאָוזשער מיט צוויי אַרגומענטן: אַן 'accumulator', און אַן עלעמענט.
    /// די קלאָוזשער קערט די ווערט אַז די אַקיומיאַלייטער זאָל האָבן פֿאַר די ווייַטער יטעראַטיאָן.
    ///
    /// די ערשטע ווערט איז די ווערט וואָס די אַקיומיאַלייטער וועט האָבן פֿאַר די ערשטער רופן.
    ///
    /// נאָך אַפּלייינג דעם קלאָוזשער צו יעדער עלעמענט פון יטעראַטאָר, קקסנומקסקס קערט די אַקיומיאַלייטער.
    ///
    /// די אָפּעראַציע איז מאל גערופֿן קס 01 קס אָדער קס 00 קס.
    ///
    /// פאָלדינג איז נוצלעך ווען איר האָבן אַ זאַמלונג פון עפּעס און איר ווילן צו פּראָדוצירן איין ווערט פון אים.
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // די סומע פון אַלע עלעמענטן פון a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// דעם בייַשפּיל בויען אַ שטריקל, סטאַרטינג מיט אַן ערשט ווערט און פאָרזעצן מיט יעדער עלעמענט פון די צוריק ביז די פראָנט:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// זוך פֿאַר אַן עלעמענט פון אַ יטעראַטאָר פֿון די צוריק אַז סאַטיספייז אַ פּרעדיקאַט.
    ///
    /// `rfind()` נעמט אַ קלאָוזשער אַז קערט קס 01 קס אָדער קס 00 קס.
    /// דער אַפּלאַקיישאַן איז אַפּלייז צו יעדער עלעמענט פון יטעראַטאָר, סטאַרטינג אין די סוף, און אויב עמעצער פון זיי צוריקקומען `true`, `rfind()` קערט [`Some(element)`].
    /// אויב זיי אַלע צוריקקומען קס 01 קס, עס קערט קס 00 קס.
    ///
    /// `rfind()` איז קורץ-קרייזינג;אין אנדערע ווערטער, עס וועט האַלטן פּראַסעסינג ווי באַלד ווי די קלאָוזשער קערט `true`.
    ///
    /// ווייַל `rfind()` נעמט אַ רעפֿערענץ, און פילע יטעראַטאָרס יטעראַטע איבער באַווייַזן, דאָס פירט צו אַ עפשער קאַנפיוזינג סיטואַציע ווו די אַרגומענט איז אַ טאָפּל דערמאָנען.
    ///
    /// איר קענען זען דעם ווירקונג אין די ביישפילן אונטן מיט `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// באַסיק באַניץ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// סטאַפּינג אין דער ערשטער `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // מיר קענען נאָך נוצן `iter`, ווייַל עס זענען מער עלעמענטן.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}