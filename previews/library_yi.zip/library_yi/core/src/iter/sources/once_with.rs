use crate::iter::{FusedIterator, TrustedLen};

/// קריייץ אַ יטעראַטאָר וואָס פויל דזשענערייץ אַ ווערט פּונקט איין מאָל דורך ינוואָוקינג די צוגעשטעלט קלאָוזשער.
///
/// דעם איז יוזשאַוואַלי געניצט צו אַדאַפּט אַ איין ווערט גענעראַטאָר אין אַ [`chain()`] פון אנדערע מינים פון יטעראַטיאָן.
/// אפֿשר איר האָבן אַ יטעראַטאָר וואָס קאַווערד כּמעט אַלץ, אָבער איר דאַרפֿן אַן עקסטרע ספּעציעל פאַל.
/// אפֿשר איר האָבן אַ פֿונקציע וואָס אַרבעט אויף יטעראַטאָרס, אָבער איר נאָר דאַרפֿן צו פּראָצעס איין ווערט.
///
/// ניט ענלעך [`once()`], די פֿונקציע וועט דזשענערייט די ווערט אויף בעטן.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::iter;
///
/// // איינער איז די לאָונליאַסט נומער
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // נאָר איינער, דאָס איז אַלע מיר באַקומען
/// assert_eq!(None, one.next());
/// ```
///
/// טשאַינינג צוזאַמען מיט אן אנדער יטעראַטאָר.
/// זאל ס זאָגן אַז מיר וועלן צו איבערחזרן יעדער טעקע פון די `.foo` וועגווייַזער, אָבער אויך אַ קאַנפיגיעריישאַן טעקע,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // מיר דאַרפֿן צו בייַטן פֿון אַ יטעראַטאָר פון דירענטרי-s צו אַ יטעראַטאָר פון פּאַטהבופס, אַזוי מיר נוצן מאַפּע
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // איצט, אונדזער יטעראַטאָר נאָר פֿאַר אונדזער קאָנפיג טעקע
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // קייט די צוויי יטעראַטאָרס צוזאַמען אין איין גרויס יטעראַטאָר
/// let files = dirs.chain(config);
///
/// // דאָס וועט געבן אונדז אַלע די טעקעס אין קס 01 קס און קס 00 קס
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// אַ יטעראַטאָר אַז ייעלדס אַ איין עלעמענט פון טיפּ קס 01 קס דורך אַפּלייינג די צוגעשטעלט קלאָוזשער קס 00 קס.
///
///
/// די `struct` איז באשאפן דורך די [`once_with()`] פונקציע.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}