use crate::fmt;

/// קריייץ אַ נייַ יטעראַטאָר וווּ יעדער יטעראַטיאָן רופט די צוגעשטעלט קלאָוזשער קס 00 קס.
///
/// דאָס אַלאַוז קריייטינג אַ מנהג יטעראַטאָר מיט קיין נאַטור אָן ניצן די מער ווערבאָוס סינטאַקס פון קריייטינג אַ דעדאַקייטאַד טיפּ און ימפּלאַמענינג די קס 00 קס ז 0 טראַיט 0 ז פֿאַר אים.
///
/// באַמערקונג אַז די `FromFn` יטעראַטאָר טוט נישט מאַכן אַסאַמפּשאַנז וועגן די נאַטור פון די קלאָוזשער, און דעריבער קאַנסערוואַטיוולי טוט נישט ינסטרומענט [`FusedIterator`], אָדער אָווועררייד [`Iterator::size_hint()`] פֿון די פעליקייַט `(0, None)`.
///
///
/// די קלאָוזשער קענען נוצן קאַפּטשערז און זיין סוויווע צו שפּור שטאַט איבער יטעריישאַנז.דעפּענדינג אויף די נוצן פון יטעראַטאָר, דאָס קען דאַרפן אַ ספּעציפיצירן די [`move`] קיווערד אין די קלאָוזשער.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// לאָמיר ימפּלאַמענאַד די טאָמבאַנק יטעראַטאָר פֿון קס 00 קס:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // ינקרעמענט אונדזער ציילן.דאָס איז וואָס מיר סטאַרטעד ביי נול.
///     count += 1;
///
///     // קוק צי מיר האָבן שוין פאַרטיק קאַונטינג.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// אַ יטעראַטאָר וווּ יעדער יטעראַטיאָן רופט די צוגעשטעלט קלאָוזשער קס 00 קס.
///
/// די `struct` איז באשאפן דורך די [`iter::from_fn()`] פונקציע.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}