use crate::iter::{FusedIterator, TrustedLen};

/// קריייץ אַ נייַ יטעראַטאָר אַז ענדלאַסלי ריפּיץ אַ איין עלעמענט.
///
/// די `repeat()` פונקציע ריפּיץ אַ איין ווערט איבער און איבער ווידער.
///
/// Infinite יטעראַטאָרס ווי קס 01 קס זענען אָפט געניצט מיט אַדאַפּטערז ווי קס 00 קס, צו מאַכן זיי ענדלעך.
///
/// אויב דער עלעמענט טיפּ פון די יטעראַטאָר איר דאַרפֿן נישט ימפּלאַמענט `Clone`, אָדער אויב איר טאָן נישט וועלן צו האַלטן די ריפּיטיד עלעמענט אין זכּרון, איר קענען אַנשטאָט נוצן די [`repeat_with()`] פונקציע.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::iter;
///
/// // די נומער פיר 4 עווער:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // יאָ, נאָך פיר
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// גיין ענדלעך מיט [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // אַז לעצטע בייַשפּיל איז געווען צו פילע פאָרז.זאל ס נאָר האָבן פיר פאָרז.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... און איצט מיר זענען פאַרטיק
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// אַ יטעראַטאָר וואָס ריפּיץ אַן עלעמענט ענדלאַסלי.
///
/// די `struct` איז באשאפן דורך די [`repeat()`] פונקציע.פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}