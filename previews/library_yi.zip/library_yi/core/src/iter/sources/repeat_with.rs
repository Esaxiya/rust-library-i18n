use crate::iter::{FusedIterator, TrustedLen};

/// קריייץ אַ נייַ יטעראַטאָר וואָס ריפּיץ ענדלאַסלי עלעמענטן פון טיפּ קסקסנומקס דורך אַפּלייינג די צוגעשטעלט קלאָוזשער, די רעפּעאַטער, `F: FnMut() -> A`.
///
/// די `repeat_with()` פונקציע רופט די רעפּעאַטער איבער און איבער ווידער.
///
/// Infinite יטעראַטאָרס ווי קס 01 קס זענען אָפט געניצט מיט אַדאַפּטערז ווי קס 00 קס, צו מאַכן זיי ענדלעך.
///
/// אויב די עלעמענט טיפּ פון יטעראַטאָר איר דאַרפֿן ימפּלאַמאַנץ [`Clone`], און עס איז גוט צו האַלטן די מקור עלעמענט אין זכּרון, איר זאָל אָנשטאָט נוצן די [`repeat()`] פונקציע.
///
///
/// אַ יטיראַטאָר געשאפן דורך קס 01 קס איז ניט אַ קס 00 קס.
/// אויב איר דאַרפֿן `repeat_with()` צו צוריקקומען אַ [`DoubleEndedIterator`], ביטע עפענען אַ גיטהוב אַרויסגעבן וואָס דערקלערט דיין נוצן פאַל.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::iter;
///
/// // לאָמיר יבערנעמען אַז מיר האָבן עטלעכע ווערט פון אַ טיפּ וואָס איז נישט קס 00 קס אָדער וואָס טאָן נישט וועלן צו געדענקען נאָך ווייַל עס איז טייַער:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // אַ באַזונדער ווערט אויף אייביק:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// ניצן מיוטיישאַן און גיין ענדלעך:
///
/// ```rust
/// use std::iter;
///
/// // פֿון די זעראָט צו די דריט מאַכט פון צוויי:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... און איצט מיר זענען פאַרטיק
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// אַ יטעראַטאָר וואָס ריפּיץ עלעמענטן פון טיפּ קס 01 קס ענדלאַסלי דורך אַפּלייינג די צוגעשטעלט קלאָוזשער קס 00 קס.
///
///
/// די `struct` איז באשאפן דורך די [`repeat_with()`] פונקציע.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}