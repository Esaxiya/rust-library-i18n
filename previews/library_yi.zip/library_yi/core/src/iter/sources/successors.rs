use crate::{fmt, iter::FusedIterator};

/// קרעאַטעס אַ נייַ יטעראַטאָר וווּ יעדער סאַקסעסיוו נומער איז קאַמפּיוטאַד באזירט אויף די פריערדיקע.
///
/// די יטעראַטאָר סטאַרץ מיט די געגעבן ערשטער נומער (אויב קיין) און רופט די געגעבן `FnMut(&T) -> Option<T>` קלאָוזשער צו רעכענען די סאַקסעסער פון יעדער נומער.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // אויב די פֿונקציע האָט אומגעקערט קס 00 קס, עס קען זיין באזירט אויף קס 01 קס און ניט דאַרפֿן אַ דעדאַקייטאַד טיפּ.
    //
    // אָבער מיט אַ געהייסן קס 00 קס טיפּ, עס קען זיין קס 01 קס ווען קס 02 קס און קס 03 קס זענען.
    Successors { next: first, succ }
}

/// א נייַ יטעראַטאָר וואָס יעדער סאַקסעסיוו נומער איז קאַמפּיוטאַד באזירט אויף די פריערדיקע.
///
/// די `struct` איז באשאפן דורך די [`iter::successors()`] פונקציע.
/// פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}