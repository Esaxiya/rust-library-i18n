use crate::iter::{FusedIterator, TrustedLen};

/// קרעאַטעס אַ יטעראַטאָר וואָס ייעלדס אַן עלעמענט פּונקט אַמאָל.
///
/// דאָס איז אָפט געניצט צו אַדאַפּט אַ איין ווערט אין אַ [`chain()`] פון אנדערע מינים פון יטעראַטיאָן.
/// אפֿשר איר האָבן אַ יטעראַטאָר וואָס קאַווערד כּמעט אַלץ, אָבער איר דאַרפֿן אַן עקסטרע ספּעציעל פאַל.
/// אפֿשר איר האָבן אַ פֿונקציע וואָס אַרבעט אויף יטעראַטאָרס, אָבער איר נאָר דאַרפֿן צו פּראָצעס איין ווערט.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// באַסיק באַניץ:
///
/// ```
/// use std::iter;
///
/// // איינער איז די לאָונליאַסט נומער
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // נאָר איינער, דאָס איז אַלע מיר באַקומען
/// assert_eq!(None, one.next());
/// ```
///
/// טשאַינינג צוזאַמען מיט אן אנדער יטעראַטאָר.
/// זאל ס זאָגן אַז מיר וועלן צו איבערחזרן יעדער טעקע פון די `.foo` וועגווייַזער, אָבער אויך אַ קאַנפיגיעריישאַן טעקע,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // מיר דאַרפֿן צו בייַטן פֿון אַ יטעראַטאָר פון דירענטרי-s צו אַ יטעראַטאָר פון פּאַטהבופס, אַזוי מיר נוצן מאַפּע
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // איצט, אונדזער יטעראַטאָר נאָר פֿאַר אונדזער קאָנפיג טעקע
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // קייט די צוויי יטעראַטאָרס צוזאַמען אין איין גרויס יטעראַטאָר
/// let files = dirs.chain(config);
///
/// // דאָס וועט געבן אונדז אַלע די טעקעס אין קס 01 קס און קס 00 קס
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// אַ יטעראַטאָר וואָס ייעלדס אַן עלעמענט פּונקט אַמאָל.
///
/// די `struct` איז באשאפן דורך די [`once()`] פונקציע.פֿאַר מער אינפֿאָרמאַציע אין זיין דאַקיומענטיישאַן.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}