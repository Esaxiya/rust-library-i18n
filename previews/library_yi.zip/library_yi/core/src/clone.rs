//! די `Clone` ז 0 טראט 0 ז פֿאַר טייפּס וואָס קענען ניט זיין 'ימפּליסאַטלי קאַפּיד'.
//!
//! אין Rust, עטלעכע פּשוט טייפּס זענען "implicitly copyable", און ווען איר באַשטימען זיי אָדער פאָרן זיי ווי אַרגומענטן, די ופנעמער וועט באַקומען אַ קאָפּיע און די אָריגינעל ווערט איז געלאזן.
//! די טייפּס טאָן ניט דאַרפן אַלאַקיישאַן צו צייכענען און טאָן ניט האָבן פינאַליזערס (י.ע. זיי טאָן ניט אַנטהאַלטן אָונד באָקסעס אָדער ינסטרומענט קס 00 קס), אַזוי דער קאַמפּיילער האלט זיי ווי ביליק און זיכער צו צייכענען.
//!
//! פֿאַר אנדערע טייפּס, קאפיעס מוזן זיין געמאכט בפירוש, דורך קאַנווענשאַן ימפּלאַמענינג די [`Clone`] trait און רופן די [`clone`] אופֿן.
//!
//! [`clone`]: Clone::clone
//!
//! באַסיק באַניץ ביישפּיל:
//!
//! ```
//! let s = String::new(); // שטריקל טיפּ ימפּלאַמאַנץ קלאָון
//! let copy = s.clone(); // אַזוי מיר קענען קלאָון עס
//! ```
//!
//! צו לייכט ינסטרומענט די קלאָון ז 0 טראַיט 0 ז, איר קענען אויך נוצן קס 00 קס.בייַשפּיל:
//!
//! ```
//! #[derive(Clone)] // מיר לייגן די קלאָון ז 0 טראַיט 0 ז צו מאָרפעוס סטרוקטור
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // און איצט מיר קענען קלאָון עס!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// א פּראָסט ז 0 טראַיט 0 ז פֿאַר די פיייקייט צו בישליימעס דופּליקאַט אַ כייפעץ.
///
/// די [`Copy`] איז אַנדערש אין וואָס [`Copy`] איז ימפּליסאַט און גאָר ביליק, בשעת `Clone` איז שטענדיק יקספּליסאַט און קען אָדער קען נישט זיין טייַער.
/// אין סדר צו דורכפירן די קעראַקטעריסטיקס, Rust קען נישט ריפּלייסט די [`Copy`], אָבער איר קען ריפּלייסט `Clone` און לויפן אַרביטראַריש קאָד.
///
/// זינט `Clone` איז מער גענעראַל ווי [`Copy`], איר קענען אויטאָמאַטיש מאַכן עפּעס [`Copy`] ווי `Clone`.
///
/// ## Derivable
///
/// די trait קענען זיין געוויינט מיט `#[derive]` אויב אַלע פעלדער זענען `Clone`.די 'אַרויספירן' די ימפּלאַמענטיישאַן פון קס 02 קס רופט קס 03 קס אויף יעדער פעלד.
///
/// [`clone`]: Clone::clone
///
/// פֿאַר אַ דזשאַנעריק סטראַקט, `#[derive]` ימפּלאַמענאַד `Clone` קאַנדישנאַלי דורך אַדינג געבונדן `Clone` אויף דזשאַנעריק פּאַראַמעטערס.
///
/// ```
/// // `derive` ימפּלאַמאַנץ קלאָון פֿאַר רידינג<T>ווען ה איז קלאָון.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## ווי קען איך ינסטרומענט `Clone`?
///
/// קס 01 קס טייפּס זאָל האָבן אַ נישטיק ימפּלאַמענטיישאַן פון קס 00 קס.מער פאָרמאַללי:
/// אויב `T: Copy`, `x: T` און `y: &T`, `let x = y.clone();` איז עקוויוואַלענט צו `let x = *y;`.
/// מאַנואַל ימפּלאַמענטיישאַנז זאָל זיין אָפּגעהיט צו ונטערהאַלטן דעם ינוועראַנט.אָבער, אַנסייף קאָד מוזן נישט פאַרלאָזנ זיך עס צו ענשור זכּרון זיכערקייַט.
///
/// אַ ביישפּיל, איז אַ דזשאַנעריק סטרוקטור מיט אַ פונקציע טייַטל.אין דעם פאַל, די ימפּלאַמענטיישאַן פון קס 00 קס קען נישט זיין `דעריווד` ד, אָבער קענען זיין ימפּלאַמענאַד ווי:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## נאָך ימפּלעמענטאָרס
///
/// אין אַדישאַן צו די קס 01 קס, די פאלגענדע טייפּס אויך ימפּלאַמענטאַד קס 00 קס:
///
/// * פונקציע נומער טייפּס (י.ע. די פאַרשידענע טייפּס דיפיינד פֿאַר יעדער פונקציע)
/// * פונקציע טייַטל (למשל, `fn() -> i32`)
/// * עריי טייפּס, פֿאַר אַלע סיזעס, אויב די נומער טיפּ אויך ימפּלאַמאַנץ קס 00 קס (למשל, קס 01 קס)
/// * טייפּאַל טייפּס, אויב יעדער קאָמפּאָנענט אויך ימפּלאַמאַנץ קס 01 קס (למשל, קס 00 קס, קס 02 קס)
/// * קלאָוזינג טייפּס, אויב זיי כאַפּן קיין ווערט פון די סוויווע אָדער אויב אַלע אַזאַ קאַפּטשערד וואַלועס ינסטרומענט קקסנומקסקס זיך.
///   באַמערקונג אַז וועריאַבאַלז קאַפּטשערד דורך שערד דערמאָנען שטענדיק ינסטרומענט קס 01 קס (אפילו אויב דער רעפערענט טוט נישט), בשעת וועריאַבאַלז קאַפּטשערד דורך מיוטאַבאַל דערמאָנען קיינמאָל ינסטרומענט קס 00 קס.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// רעטורנס אַ קאָפּיע פון די ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ימפּלאַמאַנץ קלאָון
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// פּערפאָרמז קאָפּיע-אַסיינמאַנט פון קס 00 קס.
    ///
    /// `a.clone_from(&b)` איז עקוויוואַלענט צו קס 00 קס אין פאַנגקשאַנאַליטי, אָבער קענען זיין אָווועררייד צו רייוז די ריסאָרסיז פון קס 01 קס צו ויסמיידן ומנייטיק אַלאַקיישאַנז.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// אַרויספירן מאַקראָו דזשענערייטינג אַ ימפּ פון די trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): די סטראַקטשערז זענען סאָוללי געניצט דורך#[אַרויספירן] צו באַשטעטיקן אַז יעדער קאָמפּאָנענט פון אַ טיפּ ימפּלאַמאַנץ קלאָון אָדער קאָפּי.
//
//
// די סטראַקץ זאָל קיינמאָל דערשייַנען אין באַניצער קאָד.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ימפּלאַמענטיישאַנז פון קס 00 קס פֿאַר פּרימיטיוו טייפּס.
///
/// ימפּלאַמענטיישאַנז וואָס קענען ניט זיין דיסקרייבד אין ז 0 רוסט 0 זענען ימפּלאַמענאַד אין קס 01 קס אין קס 00 קס.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// שערד באַווייַזן קענען זיין קלאָונד, אָבער מיוטאַבאַל באַווייַזן קענען ניט זיין *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// שערד באַווייַזן קענען זיין קלאָונד, אָבער מיוטאַבאַל באַווייַזן קענען ניט זיין *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}