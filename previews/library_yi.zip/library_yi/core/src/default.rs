//! די `Default` ז 0 טראט 0 ז פֿאַר טייפּס וואָס קען האָבן מינינגפאַל פעליקייַט וואַלועס.

#![stable(feature = "rust1", since = "1.0.0")]

/// א ז 0 טראַט 0 ז פֿאַר געבן אַ טיפּ אַ נוציק פעליקייַט ווערט.
///
/// ווענ עס יז איר ווילן צו פאַלן צוריק צו אַ סאָרט פון פעליקייַט ווערט און טאָן ניט דער הויפּט זאָרגן וואָס עס איז.
/// דאָס קומט אָפט מיט `סטרוקט`ס וואָס דעפינירן אַ סכום פון אָפּציעס:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// ווי קענען מיר דעפינירן עטלעכע פעליקייַט וואַלועס?איר קענען נוצן `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// איצט איר באַקומען אַלע פעליקייַט וואַלועס.ז 0 רוסט 0 ז ימפּלאַמאַנץ קס 00 קס פֿאַר פאַרשידן טייפּס פון פּרימיטיוו.
///
/// אויב איר ווילן צו אָווועררייד אַ באַזונדער אָפּציע, אָבער נאָך האַלטן די אנדערע דיפאָלץ:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// די ז 0 טראַיט 0 ז קענען זיין געוויינט מיט קס 01 קס אויב אַלע די פעלדער פון דעם טיפּ ינסטרומענט קס 00 קס.
/// ווען `דעריווד` ד, עס וועט נוצן די פעליקייַט ווערט פֿאַר יעדער טיפּ פון די פעלד.
///
/// ## ווי קען איך ינסטרומענט `Default`?
///
/// צושטעלן אַן ימפּלאַמענטיישאַן פֿאַר די `default()` אופֿן אַז קערט די ווערט פון דיין טיפּ וואָס זאָל זיין די פעליקייַט:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// קערט "default value" פֿאַר אַ טיפּ.
    ///
    /// פעליקייַט וואַלועס זענען אָפט אַ סאָרט פון ערשט ווערט, אידענטיטעט ווערט אָדער עפּעס אַנדערש וואָס קען זיין זינען ווי אַ פעליקייַט.
    ///
    ///
    /// # Examples
    ///
    /// ניצן געבויט-אין פעליקייַט וואַלועס:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// מאַכן דיין אייגן:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// ווייַזן די פעליקייַט ווערט פון אַ טיפּ לויט די `Default` trait.
///
/// די טיפּ צו צוריקקומען איז ינפערמד פֿון קאָנטעקסט;דאָס איז עקוויוואַלענט צו קס 00 קס אָבער קירצער צו טיפּ.
///
/// צום ביישפיל:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// אַרויספירן מאַקראָו דזשענערייטינג אַ ימפּ פון די trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }