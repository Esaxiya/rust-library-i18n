//! שאַרעאַבלע מיוטאַבאַל קאַנטיינערז.
//!
//! Z0 רוסט 0 ז זכּרון זיכערקייַט איז באזירט אויף דעם הערשן: אויב אַ כייפעץ קס 00 קס, עס איז נאָר מעגלעך צו האָבן איינער פון די פאלגענדע:
//!
//! - מיט עטלעכע ימיוטאַבאַל באַווייַזן (`&T`) צו די כייפעץ (אויך באקאנט ווי **אַליאַסינג**).
//! - מיט איין מיוטאַבאַל דערמאָנען (`&מוט ה ') צו די כייפעץ (אויך באַוווסט ווי **מיוטאַביליטי**).
//!
//! דאָס איז ענפאָרסט דורך די קאַמפּיילער Rust.אָבער, עס זענען סיטואַטיאָנס וואָס די הערשן איז נישט גענוג פלעקסאַבאַל.מאל עס איז פארלאנגט צו האָבן קייפל באַווייַזן צו אַ כייפעץ און נאָך מיוטייט עס.
//!
//! שאַרעאַבלע מיוטאַבאַל קאַנטיינערז עקסיסטירן צו דערלויבן מיוטאַביליטי אין אַ קאַנטראָולד שטייגער, אפילו אין דעם בייַזייַן פון אַליאַסינג.ביידע [`Cell<T>`] און [`RefCell<T>`] לאָזן דאָס אויף אַ איין-טרעדיד וועג.
//! אָבער, `Cell<T>` אדער `RefCell<T>` זענען פֿאָדעם זיכער (זיי טאָן ניט ינסטרומענט קס 02 קס).
//! אויב איר דאַרפֿן אַליאַסינג און מיוטיישאַן צווישן קייפל פֿעדעם, איר קענען נוצן קס 00 קס, קס 01 קס אָדער קס 02 קס טייפּס.
//!
//! וואַלועס פון די קס 00 קס און קס 01 קס טייפּס קען זיין מיוטייטיד דורך שערד באַווייַזן (י.ע.
//! דער פּראָסט `&T` טיפּ), כאָטש רובֿ Rust טייפּס קענען בלויז זיין מיוטייטיד דורך יינציק (`&מוט T`) באַווייַזן.
//! מיר זאָגן אַז קס 00 קס און קס 01 קס צושטעלן 'ינלענדיש מיוטאַביליטי', אין קאַנטראַסט מיט טיפּיש ז 0 רוסט 0 ז טייפּס אַז ויסשטעלונג 'ינכעראַטיד מיוטאַביליטי'.
//!
//! צעל טייפּס זענען אין צוויי פלייווערז: קס 02 קס און קס 01 קס.קס 03 קס ימפּלאַמאַנץ ינלענדיש מיוטאַביליטי דורך מאָווינג וואַלועס אין און אויס פון די קס 00 קס.
//! צו נוצן באַווייַזן אַנשטאָט פון וואַלועס, מען דאַרף נוצן די `RefCell<T>` טיפּ, צו קריגן אַ שרייבן שלאָס איידער מיוטייטינג.`Cell<T>` גיט מעטהאָדס צו צוריקקריגן און טוישן די קראַנט ינלענדיש ווערט:
//!
//!  - פֿאַר טייפּס וואָס ינסטרומענט קס 00 קס, די X01 קס אופֿן ריטריווז די קראַנט ינלענדיש ווערט.
//!  - פֿאַר טייפּס וואָס ינסטרומענט [`Default`], די [`take`](Cell::take) אופֿן ריפּלייסיז די קראַנט ינלענדיש ווערט מיט [`Default::default()`] און קערט די ריפּלייסט ווערט.
//!  - פֿאַר אַלע טייפּס, די [`replace`](Cell::replace) אופֿן ריפּלייסיז די קראַנט ינלענדיש ווערט און קערט די ריפּלייסט ווערט און די [`into_inner`](Cell::into_inner) אופֿן קאַנסומז די `Cell<T>` און קערט די ינלענדיש ווערט.
//!  די [`set`](Cell::set) אופֿן ריפּלייסיז די ינלענדיש ווערט און דראַפּט די ריפּלייסט ווערט.
//!
//! `RefCell<T>` ניצט די צייט פון Rust צו ינסטרומענט 'דינאַמיש באַראָוינג', אַ פּראָצעס וואָס מען קען פאָדערן צייַטווייַליק, ויסשליסיק, מיוטאַבאַל אַקסעס צו די ינער ווערט.
//! באָראָוז פֿאַר `RefCell<T>זיי זענען טראַקט 'ביי רונטימע', ניט ענלעך די געבוירן רעפערענץ טייפּס פון Rust וואָס זענען לעגאַמרע טראַקט סטאַטיקלי אין קאַמפּיילד צייט.
//! ווייַל `RefCell<T>` באַראָוז זענען דינאַמיש, עס איז מעגלעך צו באָרגן אַ באַראָוד ווערט וואָס איז שוין מיוטאַדלי באַראָוד;ווען דעם כאַפּאַנז, עס רעזולטאַטן אין פאָדעם ז 0 פּאַניק 0 ז.
//!
//! # ווען צו קלייַבן ינלענדיש מיוטאַביליטי
//!
//! די מער געוויינטלעך ינכעראַטיד מיוטאַביליטי, וווּ איינער דאַרף האָבן יינציק אַקסעס צו מיוטייט אַ ווערט, איז איינער פון די שליסל שפּראַך עלעמענטן וואָס ינייבאַלז Rust צו סיבה שטארק וועגן טייַטל אַליאַסינג, סטאַטיקלי פּרעווענטינג קראַך באַגז.
//! דעריבער, בילכער ינכעראַטיד מיוטאַביליטי, און ינלענדיש מיוטאַביליטי איז עפּעס פון אַ לעצט ריזאָרט.
//! זינט צעל טייפּס געבן מיוטיישאַן ווו עס אַנדערש וואָלט זיין דיסלאָוטיד, עס זענען מאל אַז ינלענדיש מיוטאַביליטי קען זיין צונעמען, אָדער אפילו *מוזן* זיין געוויינט, למשל
//!
//! * ינטראַדוסינג מיוטאַביליטי 'inside' פון עפּעס ימיוטאַבאַל
//! * ימפּלעמענטאַטיאָן פרטים פון לאַדזשיקלי-ימיוטאַבאַל מעטהאָדס.
//! * מיוטייטינג ימפּלאַמענטיישאַנז פון קס 00 קס.
//!
//! ## ינטראַדוסינג מיוטאַביליטי 'inside' פון עפּעס ימיוטאַבאַל
//!
//! פילע שערד סמאַרט טייַטל טייפּס, אַרייַנגערעכנט [`Rc<T>`] און [`Arc<T>`], צושטעלן קאַנטיינערז וואָס קענען זיין קלאָונד און שערד צווישן קייפל פּאַרטיעס.
//! ווייַל די קאַנטיינד וואַלועס קענען זיין געמערט-אַליאַסעד, זיי קענען נאָר זיין באַראָוד מיט קס 01 קס, ניט קס 00 קס.
//! אָן סעלז, עס וואָלט זיין אוממעגלעך צו מיוטייט דאַטן אין די קלוג פּוינטערז.
//!
//! עס איז זייער אָפט צו שטעלן אַ `RefCell<T>` ין שערד טייַטל טייפּס צו ריינפאָרסט מיוטאַביליטי:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // שאַפֿן אַ נייַ בלאָק צו באַגרענעצן די פאַרנעם פון די דינאַמיש באָרגן
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // באַמערקונג אַז אויב מיר טאָן ניט לאָזן דעם פריערדיקן באָרגן פון דער קאַש פאַלן אויס פון פאַרנעם, די סאַבסאַקוואַנט באָרגן וואָלט פאַרשאַפן אַ דינאַמיש פאָדעם ז 0 פּאַניק 0 ז.
//!     //
//!     // דאָס איז די הויפּט ריזיקירן פון ניצן `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! באַמערקונג אַז דעם בייַשפּיל ניצט קס 01 קס און ניט קס 00 קס.`RefCell<T>`s זענען פֿאַר איין-טרעדיד סינעריאָוז.באַטראַכטן ניצן [`RwLock<T>`] אָדער [`Mutex<T>`] אויב איר דאַרפֿן שערד מיוטאַביליטי אין אַ מולטי-טרעדיד סיטואַציע.
//!
//! ## ימפּלעמענטאַטיאָן פרטים פון לאַדזשיקלי-ימיוטאַבאַל מעטהאָדס
//!
//! טייל מאָל עס קען זיין דיזייראַבאַל נישט צו ויסשטעלן אין אַ אַפּי אַז עס איז אַ מיוטיישאַן קסקסנומקס קס.
//! דאָס קען זיין ווייַל לאַדזשיקאַללי די אָפּעראַציע איז ימיוטאַבאַל, אָבער למשל, קאַטשינג פאָרסעס די ימפּלאַמענטיישאַן צו דורכפירן מיוטיישאַן;אָדער ווייַל איר מוזן נוצן מיוטיישאַן צו ינסטרומענט אַ ז 0 טראַיט 0 ז אופֿן אַז ערידזשנאַלי איז געווען דיפיינד צו נעמען קס 00 קס.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // טייַער קאַמפּיאַטיישאַן גייט דאָ
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## מיוטייטינג ימפּלאַמענטיישאַנז פון קס 00 קס
//!
//! דאָס איז פשוט אַ ספּעציעל, אָבער פּראָסט, פאַל פון די פריערדיקע: כיידינג מיוטאַביליטי פֿאַר אַפּעריישאַנז וואָס ויסקומען צו זיין ימיוטאַבאַל.
//! די [`clone`](Clone::clone) אופֿן איז געריכט צו נישט טוישן די מקור ווערט, און איז דערקלערט צו נעמען `&self`, נישט `&mut self`.
//! דעריבער, קיין מיוטיישאַן וואָס כאַפּאַנז אין די `clone` אופֿן מוזן נוצן סעלז טייפּס.
//! פֿאַר בייַשפּיל, קס 01 קס מיינטיינז זיין רעפֿערענץ קאַונץ אין אַ קס 00 קס.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// א מיוטאַבאַל זכּרון אָרט.
///
/// # Examples
///
/// אין דעם בייַשפּיל, איר קענט זען `Cell<T>` ינייבאַלז מיוטיישאַן אין אַן ימיוטאַבאַל סטרוקטור.
/// אין אנדערע ווערטער, עס ינייבאַלז "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // טעות: קס 00 קס איז ימיוטאַבאַל
/// // my_struct.regular_field =נייַ_וואַליו;
///
/// // מעשים: כאָטש `my_struct` איז ימיוטאַבאַל, `special_field` איז אַ `Cell`,
/// // וואָס קענען שטענדיק זיין מיוטייטיד
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// זען די [module-level documentation](self) פֿאַר מער.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// קרעאַטעס אַ `Cell<T>`, מיט די `Default` ווערט פֿאַר T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// קרעאַטעס אַ נייַע `Cell` מיט די געגעבן ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// סעץ די קאַנטיינד ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// סוואַפּס די וואַלועס פון צוויי סעלז.
    /// די חילוק מיט קס 00 קס איז אַז די פֿונקציע דאַרף נישט דערמאָנען קס 01 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // זיכערקייט: דאָס קען זיין ריזיקאַליש אויב עס איז גערופן פֿון באַזונדער פֿעדעם, אָבער `Cell`
        // איז קס 00 קס אַזוי דאָס וועט נישט פּאַסירן.
        // דאָס קען נישט פאַרקריפּלט קיין פּוינטערז ווייַל `Cell` מאכט זיכער אַז גאָרנישט אַנדערש וועט זיין געוויזן אין איינער פון די `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// ריפּלייסיז די קאַנטיינד ווערט מיט `val`, און קערט דער אַלט קאַנטיינד ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // זיכערקייט: דאָס קען פאַרשאַפן דאַטן ראַסעס אויב זיי זענען גערופן פֿון אַ באַזונדער פאָדעם,
        // אָבער קס 00 קס איז קס 01 קס אַזוי דאָס וועט נישט פּאַסירן.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// ונראַפּפּעס די ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// קערט אַ קאָפּיע פון דעם קאַנטיינד ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // זיכערקייט: דאָס קען פאַרשאַפן דאַטן ראַסעס אויב זיי זענען גערופן פֿון אַ באַזונדער פאָדעם,
        // אָבער קס 00 קס איז קס 01 קס אַזוי דאָס וועט נישט פּאַסירן.
        unsafe { *self.value.get() }
    }

    /// אַפּדייץ די קאַנטיינד ווערט ניצן אַ פונקציע און קערט דער נייַ ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// קערט אַ רוי טייַטל צו די אַנדערלייינג דאַטן אין דעם צעל.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו די אַנדערלייינג דאַטן.
    ///
    /// דעם רוף באַראָוערז `Cell` מיוטאַבאַל (אין קאַמפּייל-צייט) וואָס געראַנטיז אַז מיר האָבן די בלויז דערמאָנען.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// קערט אַ קס 01 קס פֿון אַ קס 00 קס
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // זיכערקייט: קס 00 קס ינשורז יינציק אַקסעס.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// נעמט די צעל ווערט און געלאזן `Default::default()` אויף זיין אָרט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// קערט אַ קס 01 קס פֿון אַ קס 00 קס
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // זיכערקייט: קס 01 קס האט דער זעלביקער זכּרון אויסלייג ווי קס 00 קס.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// א מיוטאַבאַל זכּרון אָרט מיט דינאַמיקאַללי אָפּגעשטעלט באַראָוד כּללים
///
/// זען די [module-level documentation](self) פֿאַר מער.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// אַ טעות אומגעקערט דורך [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// אַ טעות אומגעקערט דורך [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positive וואַלועס רעפּראַזענץ די נומער פון `Ref` אַקטיוו.נעגאַטיוו וואַלועס רעפּראַזענץ די נומער פון `RefMut` אַקטיוו.
// קייפל `רעפמוט`ס קענען נאָר זיין אַקטיוו אין אַ צייט אויב זיי אָפּשיקן צו פאַרשידענע, ניט-אָוווערלאַפּינג קאַמפּאָונאַנץ פון אַ קס 00 קס (למשל, פאַרשידענע ריינדזשאַז פון אַ רעפטל).
//
// `Ref` און קס 00 קס זענען ביידע צוויי ווערטער אין גרייס, און אַזוי עס וועט מיסטאָמע קיינמאָל זיין גענוג `Ref`s אָדער`RefMut`s צו לויפן איבער האַלב פון די `usize` קייט.
// אזוי, אַ `BorrowFlag` וועט מיסטאָמע קיינמאָל לויפן אָדער אַנדערפלאָו.
// אָבער, דאָס איז נישט אַ גאַראַנטירן, ווייַל אַ פּאַטאַלאַדזשיקאַל פּראָגראַם קען ריפּיטידלי מאַכן mem::forget `Ref`s אָדער`RefMut`s.
// אַזוי, אַלע קאָד מוזן עקספּרעסלי קאָנטראָלירן פֿאַר לויפן און אַנדערפלאָו אין סדר צו ויסמיידן אַנסאַפעטי, אָדער לפּחות ביכייוו ריכטיק אין די געשעעניש אַז לויפן אָדער אַנדערפלאָו כאַפּאַנז (למשל, זען קס 00 קס).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// קרעאַטעס אַ נייַ קס 01 קס מיט קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// קאַנסומז די `RefCell`, און צוריקקומען די אלנגעוויקלט ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // זינט דעם פֿונקציע נעמט `self` (די `RefCell`) דורך ווערט, די קאַמפּיילער סטאַטיקלי וועראַפייז אַז עס איז נישט דערווייַל באַראָוד.
        //
        self.value.into_inner()
    }

    /// ריפּלייסיז די אלנגעוויקלט ווערט מיט אַ נייַע, צוריקקומען די אַלט ווערט אָן דעיניטיאַליזינג קיין איינער.
    ///
    ///
    /// די פֿונקציע קאָראַספּאַנדז צו [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics אויב די ווערט איז איצט באַראָוד.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// ריפּלייסיז די אלנגעוויקלט ווערט מיט אַ נייַע קאַמפּיוטאַד פֿון `f`, צוריקקומען די אַלט ווערט אָן דעיניטיאַליזינג קיין איינער.
    ///
    ///
    /// # Panics
    ///
    /// Panics אויב די ווערט איז איצט באַראָוד.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// ויסבייַטן די אלנגעוויקלט ווערט פון קס 01 קס מיט די אלנגעוויקלט ווערט פון קס 00 קס, אָן דעיניטיאַליזינג קיין איינער.
    ///
    ///
    /// די פֿונקציע קאָראַספּאַנדז צו [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// יממוטאַבלי באַראָוז די אלנגעוויקלט ווערט.
    ///
    /// די באָרגן לאַסץ ביז די אומגעקערט קסקסנומקס קס יגזיץ פאַרנעם.
    /// קייפל ימיוטאַבאַל באַראָוז קענען זיין גענומען אין דער זעלביקער צייט.
    ///
    /// # Panics
    ///
    /// Panics אויב די ווערט איז דערווייַל באַראָוד.
    /// פֿאַר אַ ניט-פּאַניקינג וואַריאַנט, נוצן [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// אַ ביישפּיל פון panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// יממוטאַבלי באַראָוינג די אלנגעוויקלט ווערט, און אומגעקערט אַ טעות אויב די ווערט איז דערווייַל באַראָוד.
    ///
    ///
    /// די באָרגן לאַסץ ביז די אומגעקערט קסקסנומקס קס יגזיץ פאַרנעם.
    /// קייפל ימיוטאַבאַל באַראָוז קענען זיין גענומען אין דער זעלביקער צייט.
    ///
    /// דאָס איז די ניט-פּאַניקינג וואַריאַנט פון [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // זיכערקייט: קס 00 קס ינשורז אַז עס איז בלויז ימיוטאַבאַל אַקסעס
            // צו די ווערט בשעת באַראָוד.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// מיוטאַבאַל באַראָוז די אלנגעוויקלט ווערט.
    ///
    /// די באָרגן לאַסץ ביז די אומגעקערט קסקסנומקס קס אָדער אַלע 'רעפמוט' ס דערייווד פון עס אַרויסגאַנג פאַרנעם.
    ///
    /// די ווערט קענען ניט זיין באַראָוד בשעת די באָרגן איז אַקטיוו.
    ///
    /// # Panics
    ///
    /// Panics אויב די ווערט איז איצט באַראָוד.
    /// פֿאַר אַ ניט-פּאַניקינג וואַריאַנט, נוצן [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// אַ ביישפּיל פון panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// מוטאַבלי באַראָוז די אלנגעוויקלט ווערט, און קערט אַ טעות אויב די ווערט דערווייַל באַראָוד.
    ///
    ///
    /// די באָרגן לאַסץ ביז די אומגעקערט קסקסנומקס קס אָדער אַלע 'רעפמוט' ס דערייווד פון עס אַרויסגאַנג פאַרנעם.
    /// די ווערט קענען ניט זיין באַראָוד בשעת די באָרגן איז אַקטיוו.
    ///
    /// דאָס איז די ניט-פּאַניקינג וואַריאַנט פון [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // זיכערקייט: קס 00 קס געראַנטיז יינציק אַקסעס.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// קערט אַ רוי טייַטל צו די אַנדערלייינג דאַטן אין דעם צעל.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו די אַנדערלייינג דאַטן.
    ///
    /// דעם רוף באַראָוערז `RefCell` מיוטאַבאַל (אין קאַמפּייל-צייט), אַזוי עס איז ניט נויט פֿאַר דינאַמיש טשעקס.
    ///
    /// אָבער זיין אָפּגעהיט: דעם אופֿן יקספּעקץ `self` צו זיין מיוטאַבאַל, וואָס איז בכלל נישט דער פאַל ווען איר נוצן אַ `RefCell`.
    ///
    /// אָנקוקן די [`borrow_mut`] אופֿן אַנשטאָט אויב `self` איז ניט מיוטאַבאַל.
    ///
    /// איר זאָל אויך וויסן אַז דער אופֿן איז בלויז פֿאַר ספּעציעל צושטאנדן און איז יוזשאַוואַלי נישט וואָס איר ווילט.
    /// אין פאַל פון צווייפל, נוצן [`borrow_mut`] אַנשטאָט.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// ופמאַכן די ווירקונג פון ליקט גאַרדז אויף די באַראָוינג שטאַט פון די `RefCell`.
    ///
    /// די רופן איז ענלעך צו [`get_mut`] אָבער מער ספּעשאַלייזד.
    /// עס באַראָוז קקסנומקסקס מיוטאַבאַל צו ענשור אַז עס זענען קיין באַראָוז און דערנאָך ריסעץ די שטאַט טראַקינג שערד באַראָוז.
    /// דאָס איז באַטייטיק אויב עטלעכע `Ref` אָדער `RefMut` באַראָוז האָבן ליקט.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// יממוטאַבלי באַראָוינג די אלנגעוויקלט ווערט, און אומגעקערט אַ טעות אויב די ווערט איז דערווייַל באַראָוד.
    ///
    /// # Safety
    ///
    /// ניט ענלעך קס 00 קס, דעם אופֿן איז אַנסייף ווייַל עס טוט נישט צוריקקומען אַ קס 01 קס, אַזוי די אַנטלייַען פאָן איז נישט גערירט.
    /// מוטיינג באַראָוינג די `RefCell` בשעת די רעפֿערענץ אומגעקערט דורך דעם אופֿן איז לעבעדיק איז ניט דיפיינד נאַטור.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // זיכערקייט: מיר קאָנטראָלירן אַז קיינער שרייבט ניט אַקטיוולי איצט, אָבער עס איז
            // די פֿאַראַנטוואָרטלעכקייט פון די קאַללער צו ענשור אַז קיינער שרייבט ביז די אומגעקערט רעפֿערענץ איז ניט מער אין נוצן.
            // `self.value.get()` רעפערס צו די `self` ווערט, און דאָס איז געראַנטיד צו זיין גילטיק פֿאַר די לעבן פון `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// נעמט די אלנגעוויקלט ווערט און לאָזן `Default::default()` אויף זיין אָרט.
    ///
    /// # Panics
    ///
    /// Panics אויב די ווערט איז איצט באַראָוד.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics אויב די ווערט איז דערווייַל באַראָוד.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// קרעאַטעס אַ `RefCell<T>`, מיט די `Default` ווערט פֿאַר T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics אויב די ווערט פון `RefCell` איז דערווייַל באַראָוד.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // ינקרעמענטינג באָרגן קענען רעזולטאַט אין אַ ניט-לייענען ווערט (<=0) אין די קאַסעס:
            // 1. עס איז געווען <0, ד"ה עס זענען שרייבן באַראָוערז, אַזוי מיר קענען נישט לאָזן אַ לייענען באָרגן רעכט צו Rust ס רעפערענץ אַליאַסינג כּללים
            // 2.
            // עס איז געווען isize::MAX (די מאַקסימום סומע פון לייענען באַראָוערז) און עס אָוווערפלאָוד אין isize::MIN (די מאַקסימום סומע פון שרייבן באַראָוז) אַזוי מיר קענען נישט לאָזן אַן נאָך לייענען באָרגן ווייַל יסיזע קען נישט רעפּראַזענץ אַזוי פילע לייענען באַראָוז (דאָס קען נאָר פּאַסירן אויב איר קס 02 קס מער ווי אַ קליין קעסיידערדיק סומע פון `Ref`s, וואָס איז נישט גוט פיר)
            //
            //
            //
            //
            None
        } else {
            // ינקרעמענטינג באָרגן קענען רעזולטאַט אין אַ לייענען ווערט (> 0) אין די קאַסעס:
            // 1. עס איז געווען=0, דאס הייסט אַז עס איז נישט באַראָוד, און מיר נעמען די ערשטער לייענען באָרגן
            // 2. עס איז געווען> 0 און <קס 00 קס, י.ע.
            // עס זענען לייענען באַראָוערז, און יסיזע איז גרויס גענוג צו רעפּראַזענץ ווייל איינער מער לייענען באָרגן
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // זינט דעם רעפ יגזיסץ, מיר וויסן די באָרגן פאָן איז אַ לייענען באָרגן.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // פאַרמייַדן די באָרגן טאָמבאַנק פון אָוווערפלאָוינג אין אַ שרייבן באָרגן.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// ראַפּט אַ באַראָוד דערמאָנען צו אַ ווערט אין אַ `RefCell` קעסטל.
/// א ראַפּער טיפּ פֿאַר אַ יממוטאַבלי באַראָוד ווערט פון אַ קס 00 קס.
///
/// זען די [module-level documentation](self) פֿאַר מער.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// קאפיעס אַ קס 00 קס.
    ///
    /// די `RefCell` איז שוין יממאַטאַבלי באַראָוד, אַזוי דאָס קען נישט פאַרלאָזן.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `Ref::clone(...)`.
    /// א קס 01 קס ימפּלאַמענטיישאַן אָדער אַ מעטאָד וואָלט אַרייַנמישנ זיך מיט די וויידספּרעד נוצן פון קס 02 קס צו קלאָון די אינהאַלט פון אַ קס 00 קס.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// מאכט אַ נייַ קס 00 קס פֿאַר אַ קאָמפּאָנענט פון די באַראָוד דאַטן.
    ///
    /// די `RefCell` איז שוין יממאַטאַבלי באַראָוד, אַזוי דאָס קען נישט פאַרלאָזן.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `Ref::map(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// מאכט אַ נייַ `Ref` פֿאַר אַן אָפּטיאָנאַל קאָמפּאָנענט פון די באַראָוד דאַטן.
    /// דער אָריגינעל היטן איז אומגעקערט ווי אַ קס 01 קס אויב די קלאָוזשער קערט קס 00 קס.
    ///
    /// די `RefCell` איז שוין יממאַטאַבלי באַראָוד, אַזוי דאָס קען נישט פאַרלאָזן.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `Ref::filter_map(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// ספּליץ אַ `Ref` אין קייפל `Ref`s פֿאַר פאַרשידענע קאַמפּאָונאַנץ פון די באַראָוד דאַטן.
    ///
    /// די `RefCell` איז שוין יממאַטאַבלי באַראָוד, אַזוי דאָס קען נישט פאַרלאָזן.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `Ref::map_split(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// גער אין אַ רעפֿערענץ צו די אַנדערלייינג דאַטן.
    ///
    /// די אַנדערלייינג קקסנומקס קס קענען קיינמאָל זיין באַראָוד פון ווידער און וועט שטענדיק זיין שוין יממוטאַבלי באַראָוד.
    ///
    /// עס איז נישט אַ גוטע געדאַנק צו רינען מער ווי אַ קעסיידערדיק נומער פון באַווייַזן.
    /// די קס 00 קס קענען זיין ימאַטאַבלי באַראָוד אויב בלויז אַ קלענערער נומער פון ליקס האָבן שוין פארגעקומען.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `Ref::leak(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // דורך פערגעטינג דעם רעף, מיר ינשור אַז די באָרגן טאָמבאַנק אין די רעפעלל קענען נישט צוריקקומען צו אַניוזד אין די `'b` לעבן.
        // באַשטעטיק די רעפֿערענץ טראַקינג שטאַט וואָלט דאַרפן אַ יינציק דערמאָנען צו די באַראָוד רעפעלל.
        // ניט קיין מער מיוטאַבאַל באַווייַזן קענען זיין באשאפן פֿון דער אָריגינעל צעל.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// מאכט אַ נייַ קס 00 קס פֿאַר אַ קאָמפּאָנענט פון די באַראָוד דאַטן, למשל, אַן Enum וואַריאַנט.
    ///
    /// די `RefCell` איז שוין מיוטאַבאַל באַראָוד, אַזוי דאָס קען נישט פאַרלאָזן.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `RefMut::map(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): פאַרריכטן באָרגן-טשעק
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// מאכט אַ נייַ `RefMut` פֿאַר אַן אָפּטיאָנאַל קאָמפּאָנענט פון די באַראָוד דאַטן.
    /// דער אָריגינעל היטן איז אומגעקערט ווי אַ קס 01 קס אויב די קלאָוזשער קערט קס 00 קס.
    ///
    /// די `RefCell` איז שוין מיוטאַבאַל באַראָוד, אַזוי דאָס קען נישט פאַרלאָזן.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `RefMut::filter_map(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): פאַרריכטן באָרגן-טשעק
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // זיכערקייט: פונקציאָנירן האלט אַן ויסשליסיק דערמאָנען פֿאַר דער געדויער
        // פון זיין רוף דורך קס 00 קס, און דער טייַטל איז בלויז די-רעפערענסט ין די פונקציע רופן קיינמאָל אַלאַוינג די ויסשליסיק דערמאָנען צו אַנטלויפן.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // זיכערקייט: זעלביקער ווי אויבן.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// ספּליץ אַ `RefMut` אין קייפל `RefMut`s פֿאַר פאַרשידענע קאַמפּאָונאַנץ פון די באַראָוד דאַטן.
    ///
    /// די אַנדערלייינג `RefCell` וועט בלייבן מיוטאַבאַל באַראָוד ביז ביידע ריפערד 'RefMut`s גיין אויס פון פאַרנעם.
    ///
    /// די `RefCell` איז שוין מיוטאַבאַל באַראָוד, אַזוי דאָס קען נישט פאַרלאָזן.
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `RefMut::map_split(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// גער אין אַ מיוטאַבאַל דערמאָנען צו די אַנדערלייינג דאַטן.
    ///
    /// די אַנדערלייינג קקסנומקסקס קענען ניט זיין באַראָוד פֿון ווידער און וועט שטענדיק זיין באַראָוד מיט מיוטאַבלי, אַזוי די אומגעקערט דערמאָנען איז בלויז די ינלענדיש.
    ///
    ///
    /// דאָס איז אַ פארבונדן פֿונקציע וואָס דאַרף זיין געוויינט ווי `RefMut::leak(...)`.
    /// א אופֿן קען אַרייַנמישנ זיך מיט מעטהאָדס פון די זעלבע נאָמען אויף די אינהאַלט פון אַ קס 01 קס געוויינט דורך קס 00 קס.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // דורך פערגעטינג דעם BorrowRefMut, מיר ענשור אַז די באַראָוינג טאָמבאַנק אין די RefCell קען נישט צוריקקומען צו UNUSED אין די `'b` לעבן.
        // באַשטעטיק די רעפֿערענץ טראַקינג שטאַט וואָלט דאַרפן אַ יינציק דערמאָנען צו די באַראָוד רעפעלל.
        // ניט קיין ווייַטער באַווייַזן קענען זיין באשאפן פֿון דער אָריגינעל צעל אין דעם לעבן, אַזוי די קראַנט באָרגן איז דער בלויז דערמאָנען פֿאַר די רוען לעבן.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: ניט ענלעך קס 00 קס, נייַ איז גערופֿן צו שאַפֿן די ערשט
        // מיוטאַבאַל דערמאָנען, און אַזוי עס מוזן איצט זיין קיין יגזיסטינג באַווייַזן.
        // אַזוי, בשעת קלאָון ינקראַמאַנץ די מיוטאַבאַל רעפאָונט, דאָ מיר עקספּרעסלי בלויז לאָזן גיין פון UNUSED צו UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // קלאָונז אַ קס 00 קס.
    //
    // דאָס איז בלויז גילטיק אויב יעדער `BorrowRefMut` איז געניצט צו שפּור אַ מיוטאַבאַל רעפֿערענץ צו אַ באַזונדער, נאָנאָווערלאַפּינג קייט פון דער אָריגינעל כייפעץ.
    //
    // דאָס איז נישט אין אַ קלאָון ימפּלייז אַזוי אַז קאָד קען נישט רופן דעם ימפּליסאַטלי.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // פאַרמייַדן די באָרגן טאָמבאַנק פון אַנדערפלאָוינג.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// א ראַפּער טיפּ פֿאַר אַ מיוטאַבאַל באַראָוד ווערט פון אַ `RefCell<T>`.
///
/// זען די [module-level documentation](self) פֿאַר מער.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// די האַרץ פּרימיטיוו פֿאַר ינלענדיש מיוטאַביליטי אין ז 0 רוסט 0 ז.
///
/// אויב איר האָבן אַ רעפֿערענץ `&T`, די קאַמפּיילער אין Rust נאָרמאַלי דורכפירן אָפּטימיזאַטיאָנס באזירט אויף די וויסן אַז `&T` ווייזט צו ימיוטאַבאַל דאַטן.מוטיינינג אַז דאַטן, למשל דורך אַ אַליאַס אָדער דורך טראַנסמוטטינג אַ קס 03 קס אין אַ קס 01 קס, איז באטראכט ווי אַנדיפיינד נאַטור.
/// `UnsafeCell<T>` אָפּט-אויס פון די ימיוטאַביליטי גאַראַנטירן פֿאַר קס 01 קס: אַ שערד רעפֿערענץ קס 02 קס קען פונט צו דאַטן וואָס זענען מיוטייטיד.דעם איז גערופֿן קס 00 קס.
///
/// אַלע אנדערע טייפּס וואָס לאָזן ינערלעך מיוטאַביליטי, אַזאַ ווי קס 01 קס און קס 00 קס, ינערלעך נוצן קס 02 קס צו ייַנוויקלען זייער דאַטן.
///
/// באַמערקונג אַז בלויז די ימיוטאַביליטי גאַראַנטירן פֿאַר שערד באַווייַזן איז אַפעקטאַד דורך קס 01 קס.די יינציק גאַראַנטירן פֿאַר מיוטאַבאַל באַווייַזן איז אַנאַפעקטיד.עס איז *קיין* לעגאַל וועג צו קריגן אַליאַסינג קס 02 קס, ניט אפילו מיט קס 00 קס.
///
/// די קס 01 קס אַפּי זיך איז טעקניקלי זייער פּשוט: קס 00 קס גיט איר אַ רוי טייַטל קס 02 קס צו זייַן אינהאַלט.עס איז אַרויף צו קס 03 קס ווי דער אַבסטראַקציע דיזיינער צו נוצן די רוי טייַטל ריכטיק.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// די פּינטלעך כּללים פון Rust אַליאַסינג זענען עפּעס אין פלאַקס, אָבער די הויפּט פונקטן זענען נישט קריגעריש:
///
/// - אויב איר מאַכן אַ זיכער רעפֿערענץ מיט `'a` (אַ `&T` אָדער `&mut T` רעפֿערענץ) וואָס איז בארעכטיגט דורך זיכער קאָד (פֿאַר בייַשפּיל ווייַל איר אומגעקערט עס), איר מוזן נישט אַקסעס די דאַטן אין קיין וועג וואָס איז קאַנטראַדיקץ די רעפֿערענץ פֿאַר די רעשט פון קס 00 קס.
/// פֿאַר בייַשפּיל, דעם מיטל אַז אויב איר נעמען די `*mut T` פֿון אַן `UnsafeCell<T>` און וואַרפן עס צו אַ `&T`, די דאַטן אין `T` מוזן בלייבן ימיוטאַבאַל (מאָדולאָ קיין `UnsafeCell` דאַטן געפֿונען אין `T`, דאָך) ביז די לעבן פון די רעפֿערענץ יקספּייערז.
/// סימילאַרלי, אויב איר מאַכן אַ `&mut T` רעפֿערענץ וואָס איז רעלעאַסעד צו זיכער קאָד, איר מוזן נישט אַקסעס די דאַטן אין די `UnsafeCell` ביז די רעפערענץ יקספּייערז.
///
/// - איר מוזן ויסמיידן דאַטן ראַסעס אין אַלע צייט.אויב קייפל פֿעדעם האָבן אַקסעס צו די זעלבע X00 קס, יעדער שרייבן מוזן האָבן אַ געהעריק כאַפּאַנז איידער שייכות צו אַלע אנדערע אַקסעס (אָדער נוצן אַטאָמיקס).
///
/// צו שטיצן די געהעריק פּלאַן, די פאלגענדע סינעריאָוז זענען בישליימעס דערקלערט לעגאַל פֿאַר איין-טרעדיד קאָד:
///
/// 1. א `&T` דערמאָנען קענען זיין רעלעאַסעד צו זיכער קאָד און עס קען זיין גלייך מיט אנדערע `&T` באַווייַזן, אָבער נישט מיט אַ `&mut T`
///
/// 2. א `&mut T` דערמאָנען קען זיין רעלעאַסעד צו זיכער קאָד צוגעשטעלט קיין אנדערע `&mut T` אדער `&T` גלייך עקסיסטירן מיט אים.א קס 03 קס מוזן שטענדיק זיין יינציק.
///
/// באַמערקונג אַז בשעת מיוטינג די אינהאַלט פון אַן `&UnsafeCell<T>` (אפילו בשעת אנדערע `&UnsafeCell<T>` רעפערענץ אַליאַס די צעל) איז גוט (אויב איר דורכפירן די אויבן ינוועריאַנץ אויף אן אנדער וועג), עס איז נאָך אַנדיפיינד נאַטור צו האָבן קייפל `&mut UnsafeCell<T>` ייליאַסיז.
/// אַז איז, `UnsafeCell` איז אַ ראַפּער דיזיינד צו האָבן אַ ספּעציעל ינטעראַקשאַן מיט _shared_ accesses (_i.e._, דורך אַן `&UnsafeCell<_>` רעפֿערענץ);עס איז קיין מאַגיש וואָס קען האַנדלען מיט _exclusive_ accesses (_e.g._, דורך אַ `&mut UnsafeCell<_>`): ניט דער צעל און ניט די אלנגעוויקלט ווערט קען זיין אַליאַסעד פֿאַר די צייט פון די `&mut` באָרגן.
///
/// דעם איז געוויזן דורך די [`.get_mut()`] אַקסעססאָר, וואָס איז אַ _safe_ getter וואָס גיט אַ `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// דאָ איז אַ ביישפּיל צו ווייַזן ווי אַזוי צו מיוטירן די אינהאַלט פון אַ `UnsafeCell<_>` טראָץ אַז עס זענען קייפל רעפֿערענצן אַליאַסינג די צעל:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // באַקומען קייפל/קאַנקעראַנט/שערד באַווייַזן צו די זעלבע `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // זיכערקייט: אין דעם פאַרנעם, עס זענען קיין אנדערע באַווייַזן צו די אינהאַלט פון 'x',
///     // אַזוי ונדזערער איז יפעקטיוולי יינציק.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- באָרגן-+
///     *p1_exclusive += 27; // |
/// } // <---------- קענען ניט גיין ווייַטער פון דעם פונט -------------------+
///
/// unsafe {
///     // זיכערקייט: אין דעם פאַרנעם, קיינער יקספּעקץ אַ ויסשליסיק אַקסעס צו די אינהאַלט פון 'x',
///     // אַזוי מיר קענען האָבן קייפל שערד אַקסעס קאַנקעראַנטלי.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// די פאלגענדע בייַשפּיל ווייַזן די פאַקט אַז ויסשליסיק אַקסעס צו אַ קס 01 קס ימפּלייז ויסשליסיק אַקסעס צו זיין קס 00 קס:
///
/// ```rust
/// #![forbid(unsafe_code)] // מיט ויסשליסיק אַקסעס
///                         // `UnsafeCell` איז אַ טראַנספּעראַנט ניט-אָפּ ראַפּער, אַזוי ניט דאַרפֿן פֿאַר `unsafe` דאָ.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // באַקומען אַ יינציק דערמאָנען צו די `x` קאַמפּייל-צייט-אָפּגעשטעלט.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // מיט אַ ויסשליסיק דערמאָנען, מיר קענען מיוטייט די אינהאַלט פֿאַר פריי.
/// *p_unique.get_mut() = 0;
/// // אָדער, יקוויוואַלאַנטלי:
/// x = UnsafeCell::new(0);
///
/// // אויב מיר האָבן די ווערט, מיר קענען עקסטראַקט די אינהאַלט פֿאַר פריי.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// קאָנסטרוקץ אַ נייַע בייַשפּיל פון `UnsafeCell` וואָס וועט ייַנוויקלען די ספּעסאַפייד ווערט.
    ///
    ///
    /// אַלע אַקסעס צו די ינער ווערט דורך מעטהאָדס זענען `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// ונראַפּפּעס די ווערט.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// געץ אַ מיוטאַבאַל טייַטל צו די אלנגעוויקלט ווערט.
    ///
    /// דעם קענען זיין וואַרפן צו אַ טייַטל פון קיין מין.
    /// פאַרזיכערן אַז דער אַקסעס איז יינציק (ניט אַקטיוו באַווייַזן, מיוטאַבאַל אָדער ניט) ווען קאַסטינג צו קס 01 קס, און ענשור אַז עס זענען קיין מיוטיישאַנז אָדער מיוטאַבאַל ייליאַסיז ווען קאַסטינג צו קס 00 קס
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // מיר קענען נאָר וואַרפן די טייַטל פֿון `UnsafeCell<T>` צו `T` ווייַל פון #[repr(transparent)].
        // דאָס עקספּלויץ די ספּעציעלע סטאַטוס פון ליבסטד, עס איז קיין גאַראַנטירן פֿאַר באַניצער קאָד אַז דאָס וועט אַרבעטן אין future ווערסיעס פון די קאַמפּיילער!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// רעטורנס אַ מיוטאַבאַל דערמאָנען צו די אַנדערלייינג דאַטן.
    ///
    /// דעם רוף באַראָוינג די `UnsafeCell` מיוטאַבלי (אין קאַמפּייל-צייט) וואָס געראַנטיז אַז מיר האָבן די בלויז דערמאָנען.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// געץ אַ מיוטאַבאַל טייַטל צו די אלנגעוויקלט ווערט.
    /// די חילוק צו [`get`] איז אַז די פֿונקציע אַקסעפּץ אַ רוי טייַטל, וואָס איז נוצלעך צו ויסמיידן די שאַפונג פון צייַטווייַליק באַווייַזן.
    ///
    /// דער רעזולטאַט קענען זיין וואַרפן צו אַ טייַטל פון קיין מין.
    /// פאַרזיכערן אַז דער אַקסעס איז יינציק (ניט אַקטיוו באַווייַזן, מיוטאַבאַל אָדער ניט) ווען קאַסטינג צו קס 01 קס, און ענשור אַז עס זענען קיין מיוטיישאַנז אָדער מיוטאַבאַל ייליאַסיז ווען קאַסטינג צו קס 00 קס.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// גראַדזשואַל יניטיאַליזיישאַן פון אַ קס 01 קס ריקווייערז קס 00 קס, ווי רופן קס 02 קס וואָלט דאַרפן קריייטינג אַ רעפֿערענץ צו אַנינישיייטיד דאַטן:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // מיר קענען נאָר וואַרפן די טייַטל פֿון `UnsafeCell<T>` צו `T` ווייַל פון #[repr(transparent)].
        // דאָס עקספּלויץ די ספּעציעלע סטאַטוס פון ליבסטד, עס איז קיין גאַראַנטירן פֿאַר באַניצער קאָד אַז דאָס וועט אַרבעטן אין future ווערסיעס פון די קאַמפּיילער!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// קריייץ אַן `UnsafeCell` מיט די `Default` ווערט פֿאַר T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}