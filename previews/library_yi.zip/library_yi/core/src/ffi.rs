#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Utilities שייך צו פרעמד פונקציע צובינד קס 00 קס בינדינגס.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// עקוויוואַלענט צו די קס 01 קס טיפּ ווען געוויינט ווי אַ קס 00 קס.
///
/// אין עסאַנס, `*const c_void` איז עקוויוואַלענט צו C's `const void*` און `*mut c_void` איז עקוויוואַלענט צו C's `void*`.
/// ווי געזאָגט, דאָס איז *נישט* די זעלבע ווי C's `void` קריק טיפּ, וואָס איז Rust ס `()` טיפּ.
///
/// צו מאָדעל פּוינטערז צו אָופּייק טייפּס אין FFI, ביז `extern type` איז סטייבאַלייזד, עס איז רעקאַמענדיד צו נוצן אַ Z0 נעווטיפּע 0 Z ראַפּער אַרום אַ ליידיק בייט מענגע.
///
/// זען די [Nomicon] פֿאַר פּרטים.
///
/// מען קען נוצן `std::os::raw::c_void` אויב זיי ווילן צו שטיצן די אַלט Rust קאַמפּיילער אַראָפּ צו 1.1.0.
/// נאָך Rust 1.30.0, עס איז געווען רעפּאָרטעד דורך דעם דעפֿיניציע.
/// פֿאַר מער אינפֿאָרמאַציע, ביטע לייענען [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// נ.ב., פֿאַר LLVM צו דערקענען די פּאָסל טייַטל טיפּ און דורך פאַרלענגערונג פאַנגקשאַנז ווי malloc(), מיר דאַרפֿן צו זיין רעפּריזענטיד ווי i8 * אין LLVM ביטקאָדע.
// די ענום ענומס ינשורז דאָס און פּריווענץ די מיסיוז פון די "raw" טיפּ בלויז דורך פּריוואַט וועריאַנץ.
// מיר דאַרפֿן צוויי וועריאַנץ, ווייַל דער קאַמפּיילער קאַמפּליינז וועגן די רעפּר אַטריביוט אַנדערש און מיר דאַרפֿן לפּחות איין וואַריאַנט, ווייַל אַנדערש די ענום וואָלט זיין אַנינכאַבאַטיד און ביי מינדסטער דערפערענסינג אַזאַ פּוינטערז וואָלט זיין UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// באַסיק ימפּלאַמענטיישאַן פון אַ קס 00 קס.
// דער נאָמען איז WIP, ניצן `VaListImpl` פֿאַר איצט.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // ינוואַריאַנט איבער קס 00 קס, אַזוי יעדער קס 01 קס כייפעץ איז טייד צו די געגנט פון די פונקציע אין וואָס עס איז דיפיינד
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 אַבי ימפּלאַמענטיישאַן פון אַ `va_list`.
/// זען די [AArch64 Procedure Call Standard] פֿאַר מער דעטאַילס.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC אַבי ימפּלאַמענטיישאַן פון אַ `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 אַבי ימפּלאַמענטיישאַן פון אַ `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// א ראַפּער פֿאַר אַ `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// קאָנווערט אַ `VaListImpl` אין אַ `VaList` וואָס איז ביינערי קאַמפּאַטאַבאַל מיט C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// קאָנווערט אַ `VaListImpl` אין אַ `VaList` וואָס איז ביינערי קאַמפּאַטאַבאַל מיט C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// די VaArgSafe trait דאַרף זיין גענוצט אין עפֿנטלעכע ינטערפייסיז, אָבער די trait זיך דאַרף נישט זיין ערלויבט צו נוצן אַרויס דעם מאָדולע.
// אַלאַוינג וסערס צו ינסטרומענט די ז 0 טראַיט 0 ז פֿאַר אַ נייַ טיפּ (דערמיט אַלאַוינג די וואַ_אַרג ינטרינסיק צו ווערן גענוצט אויף אַ נייַ טיפּ) איז מסתּמא צו גרונט ונדעפינייטיד נאַטור.
//
// FIXME(dlrobertson): כּדי צו נוצן די VaArgSafe trait אין א פובליק צובינד, אָבער אויך צו ענשור אַז ער קען נישט ווערן גענוצט אנדערש, די trait דאַרף זיין עפנטלעך אין אַ פּריוואַט מאָדולע.
// אַמאָל RFC 2145 איז ימפּלאַמענאַד, קוק צו פֿאַרבעסערן דעם.
//
//
//
//
mod sealed_trait {
    /// Trait וואָס אַלאַוז די ערלויבט טייפּס צו נוצן מיט [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// שטייַגן צו דער ווייַטער אַרג.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // זיכערהייט: די קאַללער מוזן האַלטן די זיכערקייַט אָפּמאַך פֿאַר קס 00 קס.
        unsafe { va_arg(self) }
    }

    /// קאַפּיז די `va_list` אויף דעם קראַנט אָרט.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // זיכערקייט: די קאַללער מוזן האַלטן די זיכערקייט קאָנטראַקט פֿאַר קס 00 קס.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // זיכערקייט: מיר שרייבן צו די `MaybeUninit`, אַזוי עס איז ינישיייטיד און `assume_init` איז לעגאַל
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: דעם זאָל רופן קס 00 קס, אָבער עס ס ניט קיין ריין וועג צו
        // גאַראַנטירן אַז קס 01 קס איז שטענדיק ינליינד אין זיין קאַללער, אַזוי די קס 02 קס וואָלט זיין גערופֿן גלייַך פֿון דער זעלביקער פֿונקציע ווי די קאָראַספּאַנדינג קס 00 קס.
        // `man va_end` שטאַטן אַז C ריקווייערז דעם, און LLVM בייסיקלי גייט די C סעמאַנטיקס, אַזוי מיר דאַרפֿן צו מאַכן זיכער אַז `va_end` איז שטענדיק גערופֿן פֿון דער זעלביקער פונקציע ווי `va_copy`.
        //
        // פֿאַר מער פּרטים, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // דאָס אַרבעט איצט, ווייַל `va_end` איז ניט-אָפּ אויף אַלע קראַנט LLVM טאַרגאַץ.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// צעשטערן די אַרגליסט קס 01 קס נאָך יניטיאַליזאַטיאָן מיט קס 02 קס אָדער קס 00 קס.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// קאַפּיז די קראַנט אָרט פון אַרגליסט קס 01 קס צו די אַרגליסט קס 00 קס.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// לייגט אַן אַרגומענט פון טיפּ קס 00 קס פון די קס 01 קס קס 02 קס און ינקראַמאַנט דער אַרגומענט קס 03 קס ווייזט צו.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}