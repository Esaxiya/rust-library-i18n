// rsbegin.o און קס 01 קס זענען די אַזוי גערופענע קס 00 קס.
// זיי אַנטהאַלטן קאָד פֿאַר קאָראַספּאַנדינג די קאַמפּיילער רונטימע ריכטיק.
//
// ווען אַן עקסעקוטאַבלע אָדער דיליב בילד איז לינגקט, אַלע באַניצער קאָד און לייברעריז זענען "sandwiched" צווישן די צוויי כייפעץ טעקעס, אַזוי קאָד אָדער דאַטן פון rsbegin.o ווערן ערשטער אין די ריספּעקטיוו סעקשאַנז פון די בילד, כוועראַז קאָד און דאַטן פון rsend.o ווערן די לעצטע.
// דער ווירקונג קענען ווערן גענוצט צו שטעלן סימבאָלס אין די אָנהייב אָדער אין די סוף פון אַ אָפּטיילונג, ווי געזונט ווי צו שטעלן די פארלאנגט כעדערז אָדער פוס.
//
// באַמערקונג אַז די פאַקטיש מאָדולע פּאָזיציע פונט איז לאָוקייטאַד אין די C רונטימע סטאַרטאַפּ כייפעץ (יוזשאַוואַלי גערופן קס 00 קס), וואָס ינוואָוקס יניטיאַליזאַטיאָן קאַללבאַקקס פון אנדערע רונטימע קאַמפּאָונאַנץ (רעגיסטרירט דורך אן אנדער ספּעציעל בילד אָפּטיילונג).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // מאַרקס אָנהייב פון דעם אָנלייגן ראַם אָפּרוען אינפֿאָרמאַציע אָפּטיילונג
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // קראַצן פּלאַץ פֿאַר ינערלעך ביכער-בעכעסקעם.
    // דעם איז דיפיינד ווי קס 00 קס אין $ ז 0 גקק 0 ז/ליבגקק/אַנוויינד-דוו 2-פדע.ה.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // אָפּרוען אינפֿאָרמאַציע קס 00 קס רוטינז.
    // זען די דאָקומענטן פון libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // פאַרשרייַבן אָפּרוען אינפֿאָרמאַציע אויף מאָדולע סטאַרטאַפּ
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // אַנרעדזשיסטער אויף שאַטדאַון
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // מינגוו-ספּעציפיש קס 00 קס רוטין רעגיסטראַציע
    pub mod mingw_init {
        // די סטאַרטאַפּ אַבדזשעקץ פון MinGW (crt0.o/dllcrt0.o) וועט אָנרופן גלאבאלע קאַנסטראַקטערז אין די .ctors און .dtors סעקשאַנז אויף סטאַרטאַפּ און אַרויסגאַנג.
        // אין פאַל פון דללס, דאָס איז געטאן ווען די דלל איז לאָודיד און אַנלאָודאַד.
        //
        // די לינקער וועט סאָרט די סעקשאַנז, וואָס ינשורז אַז אונדזער קאַללבאַקקס זענען געפֿונען אין די סוף פון די רשימה.
        // זינט קאַנסטראַקטערז לויפן אין פאַרקערט סדר, דאָס ינשורז אַז אונדזער קאַללבאַקקס זענען דער ערשטער און לעצט אָנפירן.
        //
        //

        #[link_section = ".ctors.65535"] // .קטאָרס. *: C יניטיאַליזאַטיאָן קאַללבאַקקס
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .דטאָרס. *: C טערמאַניישאַן קאַללבאַקקס
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}