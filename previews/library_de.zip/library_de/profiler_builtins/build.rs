//! Kompiliert den Profilerteil der `compiler-rt`-Bibliothek.
//!
//! Weitere Informationen finden Sie im build.rs für libcompiler_builtins crate.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed`-Anweisungen werden derzeit nicht ausgegeben und das Build-Skript
    // Änderungen an diesen Quelldateien oder den darin enthaltenen Headern werden nicht erneut ausgeführt.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // Diese Datei wurde in LLVM 10 umbenannt.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // Diese Dateien wurden in LLVM 11 hinzugefügt.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // Ziehen Sie keine zusätzlichen Bibliotheken in MSVC ein
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // Deaktivieren Sie verschiedene Funktionen von gcc und dergleichen, und kopieren Sie das Build-System von compiler-rt meistens bereits
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // Angenommen, die Unixe, für die wir dies erstellen, verfügen über fnctl()
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // Dies sollte eine ziemlich gute Heuristik sein, wenn COMPILER_RT_HAS_ATOMICS festgelegt werden soll
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // Beachten Sie, dass dies vorhanden sein sollte, wenn wir es ausführen möchten (andernfalls erstellen wir überhaupt keine eingebauten Profiler).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}