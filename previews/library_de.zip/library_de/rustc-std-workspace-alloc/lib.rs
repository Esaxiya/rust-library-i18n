#![feature(no_core)]
#![no_core]

// Unter rustc-std-workspace-core erfahren Sie, warum dieses crate benötigt wird.

// Benennen Sie crate um, um Konflikte mit dem Alloc-Modul in liballoc zu vermeiden.
extern crate alloc as foo;

pub use foo::*;