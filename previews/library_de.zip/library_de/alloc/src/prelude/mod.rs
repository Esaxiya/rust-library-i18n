//! Die Zuordnung Prelude
//!
//! Der Zweck dieses Moduls besteht darin, den Import häufig verwendeter Elemente des `alloc` crate zu erleichtern, indem oben in den Modulen ein Glob-Import hinzugefügt wird:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;