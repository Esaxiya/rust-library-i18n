use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Hängt alle Schlüssel-Wert-Paare aus der Vereinigung zweier aufsteigender Iteratoren an und erhöht dabei eine `length`-Variable.Letzteres erleichtert es dem Anrufer, ein Leck zu vermeiden, wenn ein Drop-Handler in Panik gerät.
    ///
    /// Wenn beide Iteratoren denselben Schlüssel erzeugen, löscht diese Methode das Paar vom linken Iterator und hängt das Paar vom rechten Iterator an.
    ///
    /// Wenn Sie möchten, dass der Baum in einer streng aufsteigenden Reihenfolge endet, wie bei einem `BTreeMap`, sollten beide Iteratoren Schlüssel in streng aufsteigender Reihenfolge erzeugen, die jeweils größer sind als alle Schlüssel im Baum, einschließlich aller Schlüssel, die sich bereits bei der Eingabe im Baum befinden.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Wir bereiten uns darauf vor, `left` und `right` in linearer Zeit zu einer sortierten Sequenz zusammenzuführen.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // In der Zwischenzeit bauen wir in linearer Zeit einen Baum aus der sortierten Reihenfolge.
        self.bulk_push(iter, length)
    }

    /// Schiebt alle Schlüssel-Wert-Paare an das Ende des Baums und erhöht dabei eine `length`-Variable.
    /// Letzteres erleichtert es dem Anrufer, ein Leck zu vermeiden, wenn der Iterator in Panik gerät.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Durchlaufen Sie alle Schlüssel-Wert-Paare und verschieben Sie sie in Knoten auf der richtigen Ebene.
        for (key, value) in iter {
            // Versuchen Sie, das Schlüssel-Wert-Paar in den aktuellen Blattknoten zu verschieben.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Kein Platz mehr, geh rauf und schieb dich dorthin.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Haben Sie einen Knoten mit freiem Platz gefunden, klicken Sie hier.
                                open_node = parent;
                                break;
                            } else {
                                // Geh wieder hoch.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Wir sind oben, erstellen einen neuen Wurzelknoten und pushen dort.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Drücken Sie das Schlüssel-Wert-Paar und den neuen rechten Teilbaum.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Gehe wieder zum Blatt ganz rechts.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Erhöhen Sie die Länge bei jeder Iteration, um sicherzustellen, dass die angehängten Elemente auf der Karte gelöscht werden, auch wenn der Iterator in Panik gerät.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ein Iterator zum Zusammenführen von zwei sortierten Sequenzen zu einer
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Wenn zwei Schlüssel gleich sind, wird das Schlüssel-Wert-Paar von der richtigen Quelle zurückgegeben.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}