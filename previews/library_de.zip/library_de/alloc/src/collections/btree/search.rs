use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Ein integratives Angebot, nach dem man suchen muss, genau wie bei `Bound::Included(T)`.
    Included(T),
    /// Eine exklusive Suche, genau wie `Bound::Excluded(T)`.
    Excluded(T),
    /// Eine bedingungslose Inklusivbindung, genau wie `Bound::Unbounded`.
    AllIncluded,
    /// Eine bedingungslose Exklusivbindung.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Sucht rekursiv nach einem bestimmten Schlüssel in einem (Unter-) Baum, der vom Knoten geleitet wird.
    /// Gibt einen `Found` mit dem Handle des passenden KV zurück, falls vorhanden.
    /// Andernfalls wird ein `GoDown` mit dem Handle des Blattes edge zurückgegeben, zu dem der Schlüssel gehört.
    ///
    /// Das Ergebnis ist nur dann von Bedeutung, wenn der Baum nach Schlüssel geordnet ist, wie es der Baum in einem `BTreeMap` ist.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Steigt zum nächsten Knoten ab, an dem sich das edge, das der unteren Grenze des Bereichs entspricht, von dem edge unterscheidet, das der oberen Grenze entspricht, dh dem nächsten Knoten, der mindestens einen Schlüssel im Bereich enthält.
    ///
    ///
    /// Wenn gefunden, wird ein `Ok` mit diesem Knoten zurückgegeben, wobei das Paar von edge-Indizes den Bereich begrenzt und das entsprechende Paar von Grenzen, um die Suche in den untergeordneten Knoten fortzusetzen, falls der Knoten intern ist.
    ///
    /// Wenn nicht gefunden, wird ein `Err` mit dem Blatt edge zurückgegeben, das dem gesamten Bereich entspricht.
    ///
    /// Das Ergebnis ist nur dann aussagekräftig, wenn der Baum nach Schlüssel geordnet ist.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Das Inlinen dieser Variablen sollte vermieden werden.
        // Wir gehen davon aus, dass die von `range` gemeldeten Grenzen gleich bleiben, aber eine kontroverse Implementierung kann sich zwischen den Aufrufen von (#81138) ändern.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Findet ein edge im Knoten, der die Untergrenze eines Bereichs begrenzt.
    /// Gibt auch die Untergrenze zurück, die zum Fortsetzen der Suche im übereinstimmenden untergeordneten Knoten verwendet werden soll, wenn `self` ein interner Knoten ist.
    ///
    ///
    /// Das Ergebnis ist nur dann aussagekräftig, wenn der Baum nach Schlüssel geordnet ist.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon von `find_lower_bound_edge` für die Obergrenze.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Sucht einen bestimmten Schlüssel im Knoten ohne Rekursion.
    /// Gibt einen `Found` mit dem Handle des passenden KV zurück, falls vorhanden.
    /// Andernfalls wird ein `GoDown` mit dem Handle des edge zurückgegeben, in dem der Schlüssel möglicherweise gefunden wird (wenn der Knoten intern ist) oder in dem der Schlüssel eingefügt werden kann.
    ///
    ///
    /// Das Ergebnis ist nur dann von Bedeutung, wenn der Baum nach Schlüssel geordnet ist, wie es der Baum in einem `BTreeMap` ist.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Gibt entweder den KV-Index in dem Knoten zurück, an dem der Schlüssel (oder ein Äquivalent) vorhanden ist, oder den edge-Index, zu dem der Schlüssel gehört.
    ///
    ///
    /// Das Ergebnis ist nur dann von Bedeutung, wenn der Baum nach Schlüssel geordnet ist, wie es der Baum in einem `BTreeMap` ist.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Findet einen edge-Index im Knoten, der die Untergrenze eines Bereichs begrenzt.
    /// Gibt auch die Untergrenze zurück, die zum Fortsetzen der Suche im übereinstimmenden untergeordneten Knoten verwendet werden soll, wenn `self` ein interner Knoten ist.
    ///
    ///
    /// Das Ergebnis ist nur dann aussagekräftig, wenn der Baum nach Schlüssel geordnet ist.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon von `find_lower_bound_index` für die Obergrenze.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}