use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelliert ein erneutes Ausleihen einer eindeutigen Referenz, wenn Sie wissen, dass das erneute Ausleihen und alle seine Nachkommen (dh alle daraus abgeleiteten Zeiger und Referenzen) irgendwann nicht mehr verwendet werden. Danach möchten Sie die ursprüngliche eindeutige Referenz erneut verwenden .
///
///
/// Der Leihprüfer übernimmt normalerweise das Stapeln von Krediten für Sie, aber einige Kontrollabläufe, die dieses Stapeln durchführen, sind zu kompliziert, als dass der Compiler sie befolgen könnte.
/// Mit einem `DormantMutRef` können Sie die Ausleihe selbst überprüfen, während Sie dennoch die Stapelung ausdrücken und den dafür erforderlichen Rohzeigercode ohne undefiniertes Verhalten kapseln.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Erfassen Sie eine einmalige Ausleihe und leihen Sie sie sofort wieder aus.
    /// Für den Compiler entspricht die Lebensdauer der neuen Referenz der Lebensdauer der ursprünglichen Referenz, Sie können sie jedoch für einen kürzeren Zeitraum verwenden.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SICHERHEIT: Wir halten die Ausleihe während 'a via `_marker`, und wir legen offen
        // nur diese Referenz, so ist es einzigartig.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Kehren Sie zu dem ursprünglich erfassten einmaligen Kredit zurück.
    ///
    /// # Safety
    ///
    /// Die erneute Ausleihe muss beendet sein, dh die von `new` zurückgegebene Referenz und alle daraus abgeleiteten Zeiger und Referenzen dürfen nicht mehr verwendet werden.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SICHERHEIT: Unsere eigenen Sicherheitsbedingungen implizieren, dass diese Referenz wieder einzigartig ist.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;