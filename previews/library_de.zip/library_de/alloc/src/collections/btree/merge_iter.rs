use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Kern eines Iterators, der die Ausgabe von zwei streng aufsteigenden Iteratoren zusammenführt, beispielsweise eine Vereinigung oder eine symmetrische Differenz.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Benchmarks sind schneller als das Umschließen beider Iteratoren in ein Peekable, wahrscheinlich weil wir es uns leisten können, eine FusedIterator-Bindung festzulegen.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Erstellt einen neuen Kern für einen Iterator, der zwei Quellen zusammenführt.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Gibt das nächste Elementpaar zurück, das aus dem zusammengeführten Quellenpaar stammt.
    /// Wenn beide zurückgegebenen Optionen einen Wert enthalten, ist dieser Wert gleich und tritt in beiden Quellen auf.
    /// Wenn eine der zurückgegebenen Optionen einen Wert enthält, tritt dieser Wert in der anderen Quelle nicht auf (oder die Quellen sind nicht streng aufsteigend).
    ///
    /// Wenn keine der zurückgegebenen Optionen einen Wert enthält, ist die Iteration beendet und nachfolgende Aufrufe geben dasselbe leere Paar zurück.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Gibt ein Paar Obergrenzen für das `size_hint` des letzten Iterators zurück.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}