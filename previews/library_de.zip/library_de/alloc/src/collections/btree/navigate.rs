use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Nimmt vorübergehend ein anderes, unveränderliches Äquivalent des gleichen Bereichs heraus.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Findet die unterschiedlichen Blattränder, die einen bestimmten Bereich in einem Baum begrenzen.
    /// Gibt entweder ein Paar verschiedener Handles in denselben Baum oder ein Paar leerer Optionen zurück.
    ///
    /// # Safety
    ///
    /// Verwenden Sie die doppelten Handles nicht, um dieselbe KV zweimal aufzurufen, es sei denn, `BorrowType` ist `Immut`.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Entspricht `(root1.first_leaf_edge(), root2.last_leaf_edge())`, ist jedoch effizienter.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Findet das Paar von Blatträndern, die einen bestimmten Bereich in einem Baum begrenzen.
    ///
    /// Das Ergebnis ist nur dann von Bedeutung, wenn der Baum nach Schlüssel geordnet ist, wie es der Baum in einem `BTreeMap` ist.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SICHERHEIT: Unser Ausleihtyp ist unveränderlich.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Findet das Blattkantenpaar, das einen ganzen Baum begrenzt.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Teilt eine eindeutige Referenz in ein Paar Blattränder auf, die einen bestimmten Bereich begrenzen.
    /// Das Ergebnis sind nicht eindeutige Referenzen, die eine (some)-Mutation ermöglichen, die sorgfältig verwendet werden muss.
    ///
    /// Das Ergebnis ist nur dann von Bedeutung, wenn der Baum nach Schlüssel geordnet ist, wie es der Baum in einem `BTreeMap` ist.
    ///
    ///
    /// # Safety
    /// Verwenden Sie die doppelten Handles nicht, um dieselbe KV zweimal zu besuchen.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Teilt eine eindeutige Referenz in zwei Blattränder auf, die den gesamten Bereich des Baums begrenzen.
    /// Die Ergebnisse sind nicht eindeutige Referenzen, die eine Mutation (nur von Werten) ermöglichen. Sie müssen daher mit Vorsicht verwendet werden.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Wir duplizieren hier das Root-NodeRef-wir werden niemals dieselbe KV zweimal besuchen und niemals überlappende Wertreferenzen erhalten.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Teilt eine eindeutige Referenz in zwei Blattränder auf, die den gesamten Bereich des Baums begrenzen.
    /// Die Ergebnisse sind nicht eindeutige Referenzen, die eine massiv destruktive Mutation ermöglichen, und müssen daher mit größter Sorgfalt verwendet werden.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Wir duplizieren hier das Root-NodeRef-wir werden niemals so darauf zugreifen, dass sich die vom Root erhaltenen Referenzen überschneiden.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Bei einem Blatt-edge-Handle wird [`Result::Ok`] mit einem Handle an das benachbarte KV auf der rechten Seite zurückgegeben, das sich entweder im selben Blattknoten oder in einem Vorfahrknoten befindet.
    ///
    /// Wenn das Blatt edge das letzte im Baum ist, wird [`Result::Err`] mit dem Stammknoten zurückgegeben.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Bei einem Blatt-edge-Handle wird [`Result::Ok`] mit einem Handle an das benachbarte KV auf der linken Seite zurückgegeben, das sich entweder im selben Blattknoten oder in einem Vorfahrknoten befindet.
    ///
    /// Wenn das Blatt edge das erste im Baum ist, wird [`Result::Err`] mit dem Stammknoten zurückgegeben.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Bei einem internen edge-Handle wird [`Result::Ok`] mit einem Handle an die benachbarte KV auf der rechten Seite zurückgegeben, die sich entweder im selben internen Knoten oder in einem Vorgängerknoten befindet.
    ///
    /// Wenn das interne edge das letzte im Baum ist, wird [`Result::Err`] mit dem Stammknoten zurückgegeben.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Wenn ein Blatt-edge-Handle in einen sterbenden Baum gegeben wird, wird das nächste Blatt edge auf der rechten Seite und das dazwischen liegende Schlüssel-Wert-Paar zurückgegeben, das sich entweder im selben Blattknoten, in einem Vorfahrenknoten oder nicht vorhanden befindet.
    ///
    ///
    /// Diese Methode gibt auch alle node(s) frei, deren Ende erreicht ist.
    /// Dies bedeutet, dass, wenn kein Schlüssel-Wert-Paar mehr vorhanden ist, der gesamte Rest des Baums freigegeben wurde und nichts mehr zurückzugeben ist.
    ///
    /// # Safety
    /// Das angegebene edge darf zuvor nicht vom Gegenstück `deallocating_next_back` zurückgegeben worden sein.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Wenn ein Blatt-edge-Handle in einen sterbenden Baum gegeben wird, wird das nächste Blatt edge auf der linken Seite und das dazwischen liegende Schlüssel-Wert-Paar zurückgegeben, das sich entweder im selben Blattknoten, in einem Vorfahrenknoten oder nicht vorhanden befindet.
    ///
    ///
    /// Diese Methode gibt auch alle node(s) frei, deren Ende erreicht ist.
    /// Dies bedeutet, dass, wenn kein Schlüssel-Wert-Paar mehr vorhanden ist, der gesamte Rest des Baums freigegeben wurde und nichts mehr zurückzugeben ist.
    ///
    /// # Safety
    /// Das angegebene edge darf zuvor nicht vom Gegenstück `deallocating_next` zurückgegeben worden sein.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Legt einen Knotenhaufen vom Blatt bis zur Wurzel frei.
    /// Dies ist die einzige Möglichkeit, den Rest eines Baums freizugeben, nachdem `deallocating_next` und `deallocating_next_back` an beiden Seiten des Baums geknabbert und dasselbe edge getroffen haben.
    /// Da es nur aufgerufen werden soll, wenn alle Schlüssel und Werte zurückgegeben wurden, wird keiner der Schlüssel oder Werte bereinigt.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Verschiebt das Blatt-edge-Handle zum nächsten Blatt edge und gibt Verweise auf den Schlüssel und den Wert dazwischen zurück.
    ///
    ///
    /// # Safety
    /// In der Fahrtrichtung muss ein weiterer KV vorhanden sein.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Verschiebt das Blatt-edge-Handle zum vorherigen Blatt edge und gibt Verweise auf den Schlüssel und den Wert dazwischen zurück.
    ///
    ///
    /// # Safety
    /// In der Fahrtrichtung muss ein weiterer KV vorhanden sein.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Verschiebt das Blatt-edge-Handle zum nächsten Blatt edge und gibt Verweise auf den Schlüssel und den Wert dazwischen zurück.
    ///
    ///
    /// # Safety
    /// In der Fahrtrichtung muss ein weiterer KV vorhanden sein.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Letzteres ist laut Benchmarks schneller.
        kv.into_kv_valmut()
    }

    /// Verschiebt das Blatt-edge-Handle zum vorherigen Blatt und gibt Verweise auf den Schlüssel und den Wert dazwischen zurück.
    ///
    ///
    /// # Safety
    /// In der Fahrtrichtung muss ein weiterer KV vorhanden sein.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Letzteres ist laut Benchmarks schneller.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Verschiebt das Blatt-edge-Handle zum nächsten Blatt edge und gibt den Schlüssel und den Wert dazwischen zurück, wobei die Zuordnung aller zurückgelassenen Knoten aufgehoben wird, während das entsprechende edge im übergeordneten Knoten baumelt.
    ///
    /// # Safety
    /// - In der Fahrtrichtung muss ein weiterer KV vorhanden sein.
    /// - Diese KV wurde zuvor vom Gegenstück `next_back_unchecked` auf keiner Kopie der Handles zurückgegeben, die zum Durchlaufen des Baums verwendet wurden.
    ///
    /// Die einzige sichere Möglichkeit, mit dem aktualisierten Handle fortzufahren, besteht darin, es zu vergleichen, zu löschen, diese Methode unter den Sicherheitsbedingungen erneut aufzurufen oder das Gegenstück `next_back_unchecked` unter den Sicherheitsbedingungen aufzurufen.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Verschiebt das Blatt-edge-Handle auf das vorherige Blatt edge und gibt den Schlüssel und den Wert dazwischen zurück, wobei die Zuordnung aller zurückgelassenen Knoten aufgehoben wird, während das entsprechende edge im übergeordneten Knoten baumelt.
    ///
    /// # Safety
    /// - In der Fahrtrichtung muss ein weiterer KV vorhanden sein.
    /// - Dieses Blatt edge wurde zuvor vom Gegenstück `next_unchecked` auf keiner Kopie der Ziehpunkte zurückgegeben, die zum Durchlaufen des Baums verwendet wurden.
    ///
    /// Die einzige sichere Möglichkeit, mit dem aktualisierten Handle fortzufahren, besteht darin, es zu vergleichen, zu löschen, diese Methode unter den Sicherheitsbedingungen erneut aufzurufen oder das Gegenstück `next_unchecked` unter den Sicherheitsbedingungen aufzurufen.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Gibt das am weitesten links stehende Blatt edge in oder unter einem Knoten zurück, dh das edge, das Sie zuerst benötigen, wenn Sie vorwärts navigieren (oder zuletzt, wenn Sie rückwärts navigieren).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Gibt das am weitesten rechts stehende Blatt edge in oder unter einem Knoten zurück, dh das edge, das Sie zuletzt benötigen, wenn Sie vorwärts navigieren (oder zuerst, wenn Sie rückwärts navigieren).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Besuche Blattknoten und interne KVs in aufsteigender Reihenfolge der Schlüssel und besuche auch interne Knoten als Ganzes in einer tiefen ersten Reihenfolge, was bedeutet, dass interne Knoten ihren einzelnen KVs und ihren untergeordneten Knoten vorausgehen.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Berechnet die Anzahl der Elemente in einem (Unter-) Baum.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Gibt das Blatt edge zurück, das einem KV für die Vorwärtsnavigation am nächsten liegt.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Gibt das Blatt edge zurück, das einem KV für die Rückwärtsnavigation am nächsten liegt.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}