use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Eine Blaupause für Crashtest-Dummy-Instanzen, die bestimmte Ereignisse überwachen.
/// Einige Instanzen können irgendwann auf panic konfiguriert sein.
/// Ereignisse sind `clone`, `drop` oder ein anonymes `query`.
///
/// Crashtest-Dummies werden anhand einer ID identifiziert und sortiert, sodass sie als Schlüssel in einer BTreeMap verwendet werden können.
/// Die absichtlich verwendete Implementierung basiert auf nichts, was im crate definiert ist, außer dem `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Erstellt ein Crashtest-Dummy-Design.Der `id` bestimmt die Reihenfolge und Gleichheit der Instanzen.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Erstellt eine Instanz eines Crashtest-Dummys, der aufzeichnet, welche Ereignisse auftreten, und optional panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Gibt zurück, wie oft Instanzen des Dummys geklont wurden.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Gibt zurück, wie oft Instanzen des Dummys gelöscht wurden.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Gibt zurück, wie oft Instanzen des Dummys ihr `query`-Mitglied aufgerufen haben.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Eine anonyme Abfrage, deren Ergebnis bereits angegeben ist.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}