use core::intrinsics;
use core::mem;
use core::ptr;

/// Dies ersetzt den Wert hinter der eindeutigen `v`-Referenz durch Aufrufen der entsprechenden Funktion.
///
///
/// Wenn beim Schließen von `change` ein panic auftritt, wird der gesamte Vorgang abgebrochen.
#[allow(dead_code)] // Zur Veranschaulichung aufbewahren und für future verwenden
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Dies ersetzt den Wert hinter der eindeutigen `v`-Referenz durch Aufrufen der entsprechenden Funktion und gibt ein Ergebnis zurück, das auf dem Weg erhalten wurde.
///
///
/// Wenn beim Schließen von `change` ein panic auftritt, wird der gesamte Vorgang abgebrochen.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}