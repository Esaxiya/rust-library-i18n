// Dies ist ein Versuch einer Implementierung, die dem Ideal folgt
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Da Rust eigentlich keine abhängigen Typen und keine polymorphe Rekursion hat, kommen wir mit viel Unsicherheit aus.
//

// Ein Hauptziel dieses Moduls ist es, Komplexität zu vermeiden, indem der Baum als generischer (wenn auch seltsam geformter) Container behandelt wird und der Umgang mit den meisten B-Tree-Invarianten vermieden wird.
//
// Daher ist es diesem Modul egal, ob die Einträge sortiert sind, welche Knoten unterfüllt sein können oder was unterfüllt bedeutet.Wir stützen uns jedoch auf einige Invarianten:
//
// - Bäume müssen einheitlich depth/height haben.Dies bedeutet, dass jeder Pfad von einem bestimmten Knoten zu einem Blatt genau dieselbe Länge hat.
// - Ein Knoten der Länge `n` verfügt über `n`-Schlüssel, `n`-Werte und `n + 1`-Kanten.
//   Dies impliziert, dass sogar ein leerer Knoten mindestens ein edge hat.
//   Für einen Blattknoten bedeutet "having an edge" nur, dass wir eine Position im Knoten identifizieren können, da die Blattränder leer sind und keine Datendarstellung benötigen.
// In einem internen Knoten identifiziert ein edge sowohl eine Position als auch einen Zeiger auf einen untergeordneten Knoten.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Die zugrunde liegende Darstellung von Blattknoten und ein Teil der Darstellung von internen Knoten.
struct LeafNode<K, V> {
    /// Wir wollen in `K` und `V` kovariant sein.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Der Index dieses Knotens in das `edges`-Array des übergeordneten Knotens.
    /// `*node.parent.edges[node.parent_idx]` sollte das gleiche sein wie `node`.
    /// Dies wird garantiert nur initialisiert, wenn `parent` nicht null ist.
    parent_idx: MaybeUninit<u16>,

    /// Die Anzahl der Schlüssel und Werte, die dieser Knoten speichert.
    len: u16,

    /// Die Arrays speichern die tatsächlichen Daten des Knotens.
    /// Nur die ersten `len`-Elemente jedes Arrays werden initialisiert und sind gültig.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initialisiert einen neuen `LeafNode` an Ort und Stelle.
    unsafe fn init(this: *mut Self) {
        // Grundsätzlich lassen wir Felder nicht initialisiert, wenn dies möglich ist, da dies in Valgrind sowohl etwas schneller als auch einfacher zu verfolgen sein sollte.
        //
        unsafe {
            // parent_idx, keys und vals sind alle MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Erstellt eine neue Box `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Die zugrunde liegende Darstellung interner Knoten.Wie bei "LeafNode" sollten diese hinter "BoxedNode" versteckt sein, um zu verhindern, dass nicht initialisierte Schlüssel und Werte gelöscht werden.
/// Jeder Zeiger auf einen `InternalNode` kann direkt in einen Zeiger auf den zugrunde liegenden `LeafNode`-Teil des Knotens umgewandelt werden, sodass Code generisch auf Blatt-und interne Knoten einwirken kann, ohne dass überprüft werden muss, auf welchen der beiden Zeiger ein Zeiger zeigt.
///
/// Diese Eigenschaft wird durch die Verwendung von `repr(C)` aktiviert.
///
#[repr(C)]
// gdb_providers.py verwendet diesen Typnamen zur Selbstbeobachtung.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Die Zeiger auf die untergeordneten Elemente dieses Knotens.
    /// `len + 1` Von diesen gelten sie als initialisiert und gültig, mit der Ausnahme, dass gegen Ende einige dieser Zeiger baumeln, während der Baum durch den Ausleihtyp `Dying` gehalten wird.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Erstellt eine neue Box `InternalNode`.
    ///
    /// # Safety
    /// Eine Invariante interner Knoten besteht darin, dass sie mindestens einen initialisierten und gültigen edge haben.
    /// Diese Funktion richtet ein solches edge nicht ein.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Wir müssen nur die Daten initialisieren;Die Kanten sind MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Ein verwalteter Zeiger ungleich Null auf einen Knoten.Dies ist entweder ein eigener Zeiger auf `LeafNode<K, V>` oder ein eigener Zeiger auf `InternalNode<K, V>`.
///
/// `BoxedNode` enthält jedoch keine Informationen darüber, welcher der beiden Knotentypen tatsächlich enthalten ist, und ist teilweise aufgrund dieses Informationsmangels kein separater Typ und hat keinen Destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Der Wurzelknoten eines eigenen Baums.
///
/// Beachten Sie, dass dies keinen Destruktor hat und manuell bereinigt werden muss.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Gibt einen neuen eigenen Baum mit einem eigenen Stammknoten zurück, der anfangs leer ist.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` darf nicht Null sein.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Leiht den eigenen Wurzelknoten veränderlich aus.
    /// Im Gegensatz zu `reborrow_mut` ist dies sicher, da der Rückgabewert nicht zum Zerstören des Stamms verwendet werden kann und keine anderen Verweise auf den Baum vorhanden sein können.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Leiht den eigenen Wurzelknoten leicht veränderlich aus.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Irreversibel Übergänge zu einer Referenz, die das Durchqueren erlaubt und destruktive Methoden und wenig anderes bietet.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Fügt einen neuen internen Knoten mit einem einzelnen edge hinzu, der auf den vorherigen Stammknoten zeigt, machen Sie diesen neuen Knoten zum Stammknoten und geben Sie ihn zurück.
    /// Dies erhöht die Höhe um 1 und ist das Gegenteil von `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, außer dass wir nur vergessen haben, dass wir jetzt intern sind:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Entfernt den internen Stammknoten und verwendet sein erstes untergeordnetes Element als neuen Stammknoten.
    /// Da es nur aufgerufen werden soll, wenn der Stammknoten nur ein untergeordnetes Element hat, werden keine der Schlüssel, Werte und anderen untergeordneten Elemente bereinigt.
    ///
    /// Dies verringert die Höhe um 1 und ist das Gegenteil von `push_internal_level`.
    ///
    /// Erfordert exklusiven Zugriff auf das `Root`-Objekt, jedoch nicht auf den Stammknoten.
    /// Andere Handles oder Verweise auf den Stammknoten werden dadurch nicht ungültig.
    ///
    /// Panics, wenn es keine interne Ebene gibt, dh wenn der Wurzelknoten ein Blatt ist.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SICHERHEIT: Wir haben behauptet, intern zu sein.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SICHERHEIT: Wir haben `self` exklusiv ausgeliehen und der Ausleihtyp ist exklusiv.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SICHERHEIT: Das erste edge wird immer initialisiert.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` ist in `K` und `V` immer kovariant, selbst wenn `BorrowType` `Mut` ist.
// Dies ist technisch falsch, kann jedoch aufgrund der internen Verwendung von `NodeRef` nicht zu Unsicherheiten führen, da wir gegenüber `K` und `V` vollständig generisch bleiben.
//
// Wenn jedoch ein öffentlicher Typ `NodeRef` umschließt, stellen Sie sicher, dass er die richtige Varianz aufweist.
//
/// Ein Verweis auf einen Knoten.
///
/// Dieser Typ verfügt über eine Reihe von Parametern, die die Funktionsweise steuern:
/// - `BorrowType`: Ein Dummy-Typ, der die Art der Ausleihe beschreibt und ein Leben lang trägt.
///    - Wenn dies `Immut<'a>` ist, verhält sich der `NodeRef` ungefähr wie `&'a Node`.
///    - Wenn dies `ValMut<'a>` ist, verhält sich `NodeRef` in Bezug auf Schlüssel und Baumstruktur ungefähr wie `&'a Node`, ermöglicht jedoch auch die Koexistenz vieler veränderbarer Verweise auf Werte im gesamten Baum.
///    - Wenn dies `Mut<'a>` ist, verhält sich `NodeRef` ungefähr wie `&'a mut Node`, obwohl Einfügemethoden die Koexistenz eines veränderlichen Zeigers auf einen Wert ermöglichen.
///    - Wenn dies `Owned` ist, verhält sich der `NodeRef` ungefähr wie `Box<Node>`, hat jedoch keinen Destruktor und muss manuell bereinigt werden.
///    - Wenn dies `Dying` ist, verhält sich `NodeRef` immer noch ungefähr wie `Box<Node>`, verfügt jedoch über Methoden, um den Baum Stück für Stück zu zerstören, und gewöhnliche Methoden können UB aufrufen, wenn sie falsch aufgerufen werden, obwohl sie nicht als unsicher für den Aufruf markiert sind.
///
///   Da jeder `NodeRef` das Navigieren durch den Baum ermöglicht, gilt `BorrowType` effektiv für den gesamten Baum, nicht nur für den Knoten selbst.
/// - `K` und `V`: Dies sind die Arten von Schlüsseln und Werten, die in den Knoten gespeichert sind.
/// - `Type`: Dies kann `Leaf`, `Internal` oder `LeafOrInternal` sein.
/// Wenn dies `Leaf` ist, zeigt der `NodeRef` auf einen Blattknoten, wenn dies `Internal` ist, zeigt der `NodeRef` auf einen internen Knoten, und wenn dies `LeafOrInternal` ist, kann der `NodeRef` auf einen der beiden Knotentypen zeigen.
///   `Type` heißt `NodeType`, wenn es außerhalb von `NodeRef` verwendet wird.
///
/// Sowohl `BorrowType` als auch `NodeType` beschränken die von uns implementierten Methoden, um die Sicherheit statischer Typen auszunutzen.Es gibt Einschränkungen in der Art und Weise, wie wir solche Einschränkungen anwenden können:
/// - Für jeden Typparameter können wir eine Methode entweder generisch oder für einen bestimmten Typ definieren.
/// Beispielsweise können wir eine Methode wie `into_kv` nicht generisch für alle `BorrowType` oder einmal für alle Typen definieren, die eine Lebensdauer haben, da sie `&'a`-Referenzen zurückgeben soll.
///   Daher definieren wir es nur für den am wenigsten leistungsstarken Typ `Immut<'a>`.
/// - Wir können keinen impliziten Zwang von beispielsweise `Mut<'a>` zu `Immut<'a>` bekommen.
///   Daher müssen wir `reborrow` explizit auf einem leistungsstärkeren `NodeRef` aufrufen, um eine Methode wie `into_kv` zu erreichen.
///
/// Alle Methoden unter `NodeRef`, die eine Referenz zurückgeben, entweder:
/// - Nehmen Sie `self` als Wert und geben Sie die von `BorrowType` übertragene Lebensdauer zurück.
///   Manchmal müssen wir `reborrow_mut` aufrufen, um eine solche Methode aufzurufen.
/// - Nehmen Sie `self` als Referenz, und (implicitly) gibt die Lebensdauer dieser Referenz anstelle der von `BorrowType` übertragenen Lebensdauer zurück.
/// Auf diese Weise garantiert der Leihprüfer, dass der `NodeRef` ausgeliehen bleibt, solange die zurückgegebene Referenz verwendet wird.
///   Die Methoden, die das Einfügen unterstützen, biegen diese Regel, indem sie einen Rohzeiger zurückgeben, dh eine Referenz ohne Lebensdauer.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Die Anzahl der Ebenen, die der Knoten und die Ebene der Blätter voneinander trennen, eine Konstante des Knotens, die von `Type` nicht vollständig beschrieben werden kann und die der Knoten selbst nicht speichert.
    /// Wir müssen nur die Höhe des Wurzelknotens speichern und die Höhe jedes anderen Knotens daraus ableiten.
    /// Muss Null sein, wenn `Type` `Leaf` ist, und ungleich Null, wenn `Type` `Internal` ist.
    ///
    ///
    height: usize,
    /// Der Zeiger auf das Blatt oder den internen Knoten.
    /// Die Definition von `InternalNode` stellt sicher, dass der Zeiger in beiden Fällen gültig ist.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Entpacken Sie eine Knotenreferenz, die als `NodeRef::parent` gepackt wurde.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Macht die Daten eines internen Knotens verfügbar.
    ///
    /// Gibt einen unformatierten ptr zurück, um zu vermeiden, dass andere Verweise auf diesen Knoten ungültig werden.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SICHERHEIT: Der statische Knotentyp ist `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leiht exklusiven Zugriff auf die Daten eines internen Knotens aus.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Findet die Länge des Knotens.Dies ist die Anzahl der Schlüssel oder Werte.
    /// Die Anzahl der Kanten beträgt `len() + 1`.
    /// Beachten Sie, dass das Aufrufen dieser Funktion, obwohl sie sicher ist, den Nebeneffekt haben kann, dass veränderbare Verweise, die durch unsicheren Code erstellt wurden, ungültig werden.
    ///
    pub fn len(&self) -> usize {
        // Entscheidend ist, dass wir hier nur auf das `len`-Feld zugreifen.
        // Wenn BorrowType marker::ValMut ist, gibt es möglicherweise ausstehende veränderbare Verweise auf Werte, die nicht ungültig gemacht werden dürfen.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Gibt die Anzahl der Ebenen zurück, die der Knoten und die Blätter voneinander entfernt sind.
    /// Nullhöhe bedeutet, dass der Knoten selbst ein Blatt ist.
    /// Wenn Sie sich Bäume mit der Wurzel oben vorstellen, gibt die Zahl an, auf welcher Höhe der Knoten angezeigt wird.
    /// Wenn Sie sich Bäume mit Blättern oben vorstellen, gibt die Zahl an, wie hoch sich der Baum über dem Knoten erstreckt.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Entfernt vorübergehend einen weiteren unveränderlichen Verweis auf denselben Knoten.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Belichtet den Blattteil eines Blattes oder eines internen Knotens.
    ///
    /// Gibt einen unformatierten ptr zurück, um zu vermeiden, dass andere Verweise auf diesen Knoten ungültig werden.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Der Knoten muss mindestens für den LeafNode-Teil gültig sein.
        // Dies ist keine Referenz im NodeRef-Typ, da wir nicht wissen, ob sie eindeutig oder gemeinsam genutzt werden soll.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Findet das übergeordnete Element des aktuellen Knotens.
    /// Gibt `Ok(handle)` zurück, wenn der aktuelle Knoten tatsächlich einen übergeordneten Knoten hat, wobei `handle` auf das edge des übergeordneten Knotens zeigt, der auf den aktuellen Knoten zeigt.
    ///
    /// Gibt `Err(self)` zurück, wenn der aktuelle Knoten kein übergeordnetes Element hat, und gibt das ursprüngliche `NodeRef` zurück.
    ///
    /// Der Methodenname setzt voraus, dass Sie Bildbäume mit dem Stammknoten oben haben.
    ///
    /// `edge.descend().ascend().unwrap()` und `node.ascend().unwrap().descend()` sollten beide nach Erfolg nichts tun.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Wir müssen Rohzeiger auf Knoten verwenden, da bei BorrowType marker::ValMut möglicherweise ausstehende veränderbare Verweise auf Werte vorhanden sind, die nicht ungültig gemacht werden dürfen.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Beachten Sie, dass `self` nicht leer sein darf.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Beachten Sie, dass `self` nicht leer sein darf.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Belichtet den Blattteil eines Blattes oder internen Knotens in einem unveränderlichen Baum.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SICHERHEIT: Es können keine veränderlichen Referenzen in diesem Baum vorhanden sein, die als `Immut` ausgeliehen wurden.
        unsafe { &*ptr }
    }

    /// Leiht eine Ansicht in die im Knoten gespeicherten Schlüssel aus.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Ruft ähnlich wie `ascend` einen Verweis auf den übergeordneten Knoten eines Knotens ab, gibt jedoch auch die Zuordnung des aktuellen Knotens im Prozess frei.
    /// Dies ist nicht sicher, da auf den aktuellen Knoten trotz Freigabe weiterhin zugegriffen werden kann.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Versichert dem Compiler unsicher die statische Information, dass dieser Knoten ein `Leaf` ist.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Versichert dem Compiler unsicher die statische Information, dass dieser Knoten ein `Internal` ist.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Entfernt vorübergehend einen weiteren veränderlichen Verweis auf denselben Knoten.Beachten Sie, dass diese Methode doppelt sehr gefährlich ist, da sie möglicherweise nicht sofort gefährlich erscheint.
    ///
    /// Da veränderbare Zeiger überall im Baum herumlaufen können, kann der zurückgegebene Zeiger leicht verwendet werden, um den ursprünglichen Zeiger nach gestapelten Ausleihregeln baumeln zu lassen, außerhalb der Grenzen zu halten oder ungültig zu machen.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) Erwägen Sie, `NodeRef` einen weiteren Typparameter hinzuzufügen, der die Verwendung von Navigationsmethoden für neu entliehene Zeiger einschränkt und diese Unsicherheit verhindert.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Leiht exklusiven Zugriff auf den Blattteil eines Blattes oder internen Knotens aus.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SICHERHEIT: Wir haben exklusiven Zugriff auf den gesamten Knoten.
        unsafe { &mut *ptr }
    }

    /// Bietet exklusiven Zugriff auf den Blattteil eines Blattes oder eines internen Knotens.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SICHERHEIT: Wir haben exklusiven Zugriff auf den gesamten Knoten.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leiht exklusiven Zugriff auf ein Element des Schlüsselspeicherbereichs aus.
    ///
    /// # Safety
    /// `index` ist in Grenzen von 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SICHERHEIT: Der Anrufer kann keine weiteren Methoden für sich selbst aufrufen
        // bis die Key-Slice-Referenz gelöscht wird, da wir während der gesamten Laufzeit des Ausleihens einen eindeutigen Zugriff haben.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Leiht exklusiven Zugriff auf ein Element oder einen Teil des Wertspeicherbereichs des Knotens aus.
    ///
    /// # Safety
    /// `index` ist in Grenzen von 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SICHERHEIT: Der Anrufer kann keine weiteren Methoden für sich selbst aufrufen
        // bis die Value-Slice-Referenz gelöscht wird, da wir für die Laufzeit des Ausleihens einen eindeutigen Zugriff haben.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leiht exklusiven Zugriff auf ein Element oder Slice des Speicherbereichs des Knotens für edge-Inhalte aus.
    ///
    /// # Safety
    /// `index` ist in Grenzen von 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SICHERHEIT: Der Anrufer kann keine weiteren Methoden für sich selbst aufrufen
        // bis die edge-Slice-Referenz gelöscht wird, da wir für die Laufzeit des Ausleihens einen eindeutigen Zugriff haben.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Der Knoten verfügt über mehr als `idx`-initialisierte Elemente.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Wir erstellen nur einen Verweis auf das eine Element, an dem wir interessiert sind, um ein Aliasing mit ausstehenden Verweisen auf andere Elemente zu vermeiden, insbesondere auf diejenigen, die in früheren Iterationen an den Aufrufer zurückgegeben wurden.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Wir müssen uns wegen des Rust-Problems #74679 auf nicht dimensionierte Array-Zeiger zwingen.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leiht exklusiven Zugriff auf die Länge des Knotens aus.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Legt die Verknüpfung des Knotens zu seinem übergeordneten edge fest, ohne andere Verweise auf den Knoten ungültig zu machen.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Löscht den Link des Roots zu seinem übergeordneten edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Fügt am Ende des Knotens ein Schlüssel-Wert-Paar hinzu.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Jedes von `range` zurückgegebene Element ist ein gültiger edge-Index für den Knoten.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Fügt ein Schlüssel-Wert-Paar und ein edge rechts neben diesem Paar am Ende des Knotens hinzu.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Überprüft, ob ein Knoten ein `Internal`-Knoten oder ein `Leaf`-Knoten ist.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Ein Verweis auf ein bestimmtes Schlüssel-Wert-Paar oder edge innerhalb eines Knotens.
/// Der `Node`-Parameter muss ein `NodeRef` sein, während der `Type` entweder `KV` (ein Handle für ein Schlüssel-Wert-Paar) oder `Edge` (ein Handle für ein edge) sein kann.
///
/// Beachten Sie, dass auch `Leaf`-Knoten `Edge`-Handles haben können.
/// Anstatt einen Zeiger auf einen untergeordneten Knoten darzustellen, stellen diese die Leerzeichen dar, in denen untergeordnete Zeiger zwischen den Schlüssel-Wert-Paaren stehen würden.
/// In einem Knoten mit der Länge 2 gibt es beispielsweise 3 mögliche edge-Positionen, eine links vom Knoten, eine zwischen den beiden Paaren und eine rechts vom Knoten.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Wir brauchen nicht die vollständige Allgemeinheit von `#[derive(Clone)]`, da `Node` nur dann "klonbar" ist, wenn es sich um eine unveränderliche Referenz und damit um `Copy` handelt.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Ruft den Knoten ab, der das edge-oder Schlüssel-Wert-Paar enthält, auf das dieses Handle verweist.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Gibt die Position dieses Handles im Knoten zurück.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Erstellt ein neues Handle für ein Schlüssel-Wert-Paar in `node`.
    /// Unsicher, da der Anrufer sicherstellen muss, dass `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Könnte eine öffentliche Implementierung von PartialEq sein, wird aber nur in diesem Modul verwendet.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Entfernt vorübergehend einen anderen, unveränderlichen Griff an derselben Stelle.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Wir können Handle::new_kv oder Handle::new_edge nicht verwenden, da wir unseren Typ nicht kennen
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Versichert dem Compiler unsicher die statische Information, dass der Knoten des Handles ein `Leaf` ist.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Entfernt vorübergehend einen anderen veränderlichen Griff an derselben Stelle.
    /// Beachten Sie, dass diese Methode doppelt sehr gefährlich ist, da sie möglicherweise nicht sofort gefährlich erscheint.
    ///
    ///
    /// Einzelheiten finden Sie unter `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Wir können Handle::new_kv oder Handle::new_edge nicht verwenden, da wir unseren Typ nicht kennen
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Erstellt ein neues Handle für ein edge in `node`.
    /// Unsicher, da der Anrufer sicherstellen muss, dass `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Berechnet bei einem edge-Index, in den wir in einen bis zur Kapazität gefüllten Knoten einfügen möchten, einen sinnvollen KV-Index eines Teilungspunkts und wo die Einfügung durchgeführt werden soll.
///
/// Das Ziel des Teilungspunkts besteht darin, dass sein Schlüssel und sein Wert in einem übergeordneten Knoten landen.
/// Die Tasten, Werte und Kanten links vom Teilungspunkt werden zum linken untergeordneten Element.
/// Die Tasten, Werte und Kanten rechts vom Teilungspunkt werden zum richtigen untergeordneten Element.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust-Problem #74834 versucht, diese symmetrischen Regeln zu erklären.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Fügt ein neues Schlüssel-Wert-Paar zwischen den Schlüssel-Wert-Paaren rechts und links von diesem edge ein.
    /// Bei dieser Methode wird davon ausgegangen, dass im Knoten genügend Speicherplatz für das neue Paar vorhanden ist.
    ///
    /// Der zurückgegebene Zeiger zeigt auf den eingefügten Wert.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Fügt ein neues Schlüssel-Wert-Paar zwischen den Schlüssel-Wert-Paaren rechts und links von diesem edge ein.
    /// Diese Methode teilt den Knoten auf, wenn nicht genügend Platz vorhanden ist.
    ///
    /// Der zurückgegebene Zeiger zeigt auf den eingefügten Wert.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Korrigiert den übergeordneten Zeiger und Index im untergeordneten Knoten, mit dem dieser edge verknüpft ist.
    /// Dies ist nützlich, wenn die Reihenfolge der Kanten geändert wurde.
    fn correct_parent_link(self) {
        // Erstellen Sie einen Backpointer, ohne andere Verweise auf den Knoten ungültig zu machen.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fügt ein neues Schlüssel-Wert-Paar und ein edge ein, die rechts von diesem neuen Paar zwischen diesem edge und dem Schlüssel-Wert-Paar rechts von diesem edge stehen.
    /// Bei dieser Methode wird davon ausgegangen, dass im Knoten genügend Speicherplatz für das neue Paar vorhanden ist.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Fügt ein neues Schlüssel-Wert-Paar und ein edge ein, die rechts von diesem neuen Paar zwischen diesem edge und dem Schlüssel-Wert-Paar rechts von diesem edge stehen.
    /// Diese Methode teilt den Knoten auf, wenn nicht genügend Platz vorhanden ist.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Fügt ein neues Schlüssel-Wert-Paar zwischen den Schlüssel-Wert-Paaren rechts und links von diesem edge ein.
    /// Diese Methode teilt den Knoten auf, wenn nicht genügend Platz vorhanden ist, und versucht, den abgespaltenen Teil rekursiv in den übergeordneten Knoten einzufügen, bis die Wurzel erreicht ist.
    ///
    ///
    /// Wenn das zurückgegebene Ergebnis ein `Fit` ist, kann der Knoten seines Handles der Knoten dieses edge oder ein Vorfahr sein.
    /// Wenn das zurückgegebene Ergebnis ein `Split` ist, ist das `left`-Feld der Stammknoten.
    /// Der zurückgegebene Zeiger zeigt auf den eingefügten Wert.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Findet den Knoten, auf den dieser edge zeigt.
    ///
    /// Der Methodenname setzt voraus, dass Sie Bildbäume mit dem Stammknoten oben haben.
    ///
    /// `edge.descend().ascend().unwrap()` und `node.ascend().unwrap().descend()` sollten beide nach Erfolg nichts tun.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Wir müssen Rohzeiger auf Knoten verwenden, da bei BorrowType marker::ValMut möglicherweise ausstehende veränderbare Verweise auf Werte vorhanden sind, die nicht ungültig gemacht werden dürfen.
        // Sie müssen nicht auf das Höhenfeld zugreifen, da dieser Wert kopiert wird.
        // Beachten Sie, dass wir nach der Dereferenzierung des Knotenzeigers mit einer Referenz auf das Kantenarray zugreifen (Rust-Problem #73987) und alle anderen Verweise auf oder innerhalb des Arrays ungültig machen, falls es welche gibt.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Wir können keine separaten Schlüssel-und Wertmethoden aufrufen, da der Aufruf der zweiten die von der ersten zurückgegebene Referenz ungültig macht.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ersetzen Sie den Schlüssel und den Wert, auf den sich das KV-Handle bezieht.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Hilft bei der Implementierung von `split` für ein bestimmtes `NodeType`, indem Blattdaten berücksichtigt werden.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Teilt den zugrunde liegenden Knoten in drei Teile:
    ///
    /// - Der Knoten wird abgeschnitten, um nur die Schlüssel-Wert-Paare links von diesem Handle zu enthalten.
    /// - Der Schlüssel und der Wert, auf die dieses Handle zeigt, werden extrahiert.
    /// - Alle Schlüssel-Wert-Paare rechts von diesem Handle werden in einen neu zugewiesenen Knoten eingefügt.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Entfernt das Schlüssel-Wert-Paar, auf das dieses Handle zeigt, und gibt es zusammen mit dem edge zurück, in das das Schlüssel-Wert-Paar eingebrochen ist.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Teilt den zugrunde liegenden Knoten in drei Teile:
    ///
    /// - Der Knoten wird abgeschnitten, um nur die Kanten und Schlüssel-Wert-Paare links von diesem Handle zu enthalten.
    /// - Der Schlüssel und der Wert, auf die dieses Handle zeigt, werden extrahiert.
    /// - Alle Kanten und Schlüssel-Wert-Paare rechts von diesem Handle werden in einen neu zugewiesenen Knoten eingefügt.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Stellt eine Sitzung zum Bewerten und Ausführen einer Ausgleichsoperation um ein internes Schlüssel-Wert-Paar dar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Wählt einen Ausgleichskontext, an dem der Knoten als untergeordnetes Element beteiligt ist, also zwischen der KV unmittelbar links oder rechts im übergeordneten Knoten.
    /// Gibt ein `Err` zurück, wenn kein übergeordnetes Element vorhanden ist.
    /// Panics, wenn das übergeordnete Element leer ist.
    ///
    /// Bevorzugt die linke Seite, um optimal zu sein, wenn der angegebene Knoten irgendwie unterfüllt ist, was hier nur bedeutet, dass er weniger Elemente als sein linkes Geschwister und als sein rechtes Geschwister hat, falls vorhanden.
    /// In diesem Fall ist das Zusammenführen mit dem linken Geschwister schneller, da wir nur die N Elemente des Knotens verschieben müssen, anstatt sie nach rechts zu verschieben und mehr als N Elemente vor uns zu verschieben.
    /// Das Stehlen vom linken Geschwister ist normalerweise auch schneller, da wir nur die N Elemente des Knotens nach rechts verschieben müssen, anstatt mindestens N der Elemente des Geschwisters nach links zu verschieben.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Gibt zurück, ob eine Zusammenführung möglich ist, dh ob in einem Knoten genügend Platz vorhanden ist, um die zentrale KV mit beiden benachbarten untergeordneten Knoten zu kombinieren.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Führt eine Zusammenführung durch und lässt einen Abschluss entscheiden, was zurückgegeben werden soll.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SICHERHEIT: Die Höhe der zusammengeführten Knoten liegt unter der Höhe
                // des Knotens dieses edge, also über Null, also sind sie intern.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Fügt das Schlüssel-Wert-Paar des übergeordneten Elements und beide benachbarten untergeordneten Knoten zum linken untergeordneten Knoten zusammen und gibt den verkleinerten übergeordneten Knoten zurück.
    ///
    ///
    /// Panics es sei denn wir `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Fügt das Schlüssel-Wert-Paar des übergeordneten Elements und beide benachbarten untergeordneten Knoten zum linken untergeordneten Knoten zusammen und gibt diesen untergeordneten Knoten zurück.
    ///
    ///
    /// Panics es sei denn wir `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Fügt das Schlüssel-Wert-Paar des übergeordneten Elements und beide benachbarten untergeordneten Knoten mit dem linken untergeordneten Knoten zusammen und gibt das edge-Handle in dem untergeordneten Knoten zurück, in dem das verfolgte untergeordnete edge gelandet ist.
    ///
    ///
    /// Panics es sei denn wir `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Entfernt ein Schlüssel-Wert-Paar aus dem linken untergeordneten Element und legt es im Schlüsselwert-Speicher des übergeordneten Elements ab, während das alte übergeordnete Schlüssel-Wert-Paar in das rechte untergeordnete Element verschoben wird.
    ///
    /// Gibt ein Handle an das edge im rechten untergeordneten Element zurück, das dem Ort entspricht, an dem das von `track_right_edge_idx` angegebene ursprüngliche edge gelandet ist.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Entfernt ein Schlüssel-Wert-Paar aus dem rechten untergeordneten Element und legt es im Schlüsselwert-Speicher des übergeordneten Elements ab, während das alte übergeordnete Schlüssel-Wert-Paar auf das linke untergeordnete Element verschoben wird.
    ///
    /// Gibt ein Handle an edge im linken untergeordneten Element zurück, das von `track_left_edge_idx` angegeben wurde und sich nicht verschoben hat.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Dies stiehlt ähnlich wie `steal_left`, stiehlt jedoch mehrere Elemente gleichzeitig.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Stellen Sie sicher, dass wir sicher stehlen können.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Blattdaten verschieben.
            {
                // Machen Sie Platz für gestohlene Elemente im richtigen Kind.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Verschieben Sie Elemente vom linken zum rechten untergeordneten Element.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Verschieben Sie das am weitesten links gestohlene Paar zum Elternteil.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Verschieben Sie das Schlüssel-Wert-Paar des übergeordneten Elements in das richtige untergeordnete Element.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Machen Sie Platz für gestohlene Kanten.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Kanten stehlen.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Der symmetrische Klon von `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Stellen Sie sicher, dass wir sicher stehlen können.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Blattdaten verschieben.
            {
                // Verschieben Sie das am weitesten rechts gestohlene Paar zum Elternteil.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Verschieben Sie das Schlüssel-Wert-Paar des Elternteils zum linken Kind.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Verschieben Sie Elemente vom rechten zum linken Kind.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Füllen Sie die Lücke, in der sich gestohlene Elemente befanden.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Kanten stehlen.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Füllen Sie die Lücke an der Stelle, an der sich gestohlene Kanten befanden.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Entfernt alle statischen Informationen, die behaupten, dass dieser Knoten ein `Leaf`-Knoten ist.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Entfernt alle statischen Informationen, die behaupten, dass dieser Knoten ein `Internal`-Knoten ist.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Überprüft, ob der zugrunde liegende Knoten ein `Internal`-Knoten oder ein `Leaf`-Knoten ist.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Verschieben Sie das Suffix nach `self` von einem Knoten auf einen anderen.`right` muss leer sein.
    /// Das erste edge von `right` bleibt unverändert.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Ergebnis der Einfügung, wenn ein Knoten über seine Kapazität hinaus erweitert werden musste.
pub struct SplitResult<'a, K, V, NodeType> {
    // Geänderter Knoten im vorhandenen Baum mit Elementen und Kanten, die links von `kv` liegen.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Einige Schlüssel und Werte werden abgespalten, um an anderer Stelle eingefügt zu werden.
    pub kv: (K, V),
    // Eigener, nicht verbundener, neuer Knoten mit Elementen und Kanten, die rechts von `kv` liegen.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Gibt an, ob Knotenreferenzen dieses Ausleihtyps das Durchlaufen zu anderen Knoten in der Baumstruktur ermöglichen.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal wird nicht benötigt, sondern mit dem Ergebnis von `borrow_mut`.
        // Durch Deaktivieren der Durchquerung und Erstellen neuer Verweise auf Roots wissen wir, dass sich jeder Verweis vom Typ `Owned` auf einen Root-Knoten bezieht.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Fügt einen Wert in eine Schicht initialisierter Elemente ein, gefolgt von einem nicht initialisierten Element.
///
/// # Safety
/// Das Slice enthält mehr als `idx`-Elemente.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Entfernt einen Wert aus einem Slice aller initialisierten Elemente und gibt ihn zurück, wobei ein nachfolgendes nicht initialisiertes Element zurückbleibt.
///
///
/// # Safety
/// Das Slice enthält mehr als `idx`-Elemente.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Verschiebt die Elemente in einer Slice `distance`-Position nach links.
///
/// # Safety
/// Das Slice enthält mindestens `distance`-Elemente.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Verschiebt die Elemente in einer Slice `distance`-Position nach rechts.
///
/// # Safety
/// Das Slice enthält mindestens `distance`-Elemente.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Verschiebt alle Werte von einem Slice initialisierter Elemente in einen Slice nicht initialisierter Elemente, wobei `src` als alle nicht initialisierten Elemente zurückbleibt.
///
/// Funktioniert wie `dst.copy_from_slice(src)`, erfordert jedoch nicht, dass `T` `Copy` ist.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;