//! Eine doppelendige Warteschlange, die mit einem wachsenden Ringpuffer implementiert ist.
//!
//! Diese Warteschlange hat *O*(1) amortisierte Einsätze und Entfernungen von beiden Enden des Containers.
//! Es hat auch *O*(1) Indizierung wie ein vector.
//! Die enthaltenen Elemente müssen nicht kopierbar sein, und die Warteschlange kann gesendet werden, wenn der enthaltene Typ sendbar ist.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Größte mögliche Zweierpotenz

/// Eine doppelendige Warteschlange, die mit einem wachsenden Ringpuffer implementiert ist.
///
/// Die "default"-Verwendung dieses Typs als Warteschlange besteht darin, [`push_back`] zum Hinzufügen zur Warteschlange und [`pop_front`] zum Entfernen aus der Warteschlange zu verwenden.
///
/// [`extend`] und [`append`] werden auf diese Weise auf den Rücken gedrückt, und das Iterieren über `VecDeque` erfolgt von vorne nach hinten.
///
/// Da `VecDeque` ein Ringpuffer ist, sind seine Elemente im Speicher nicht unbedingt zusammenhängend.
/// Wenn Sie als einzelnes Slice auf die Elemente zugreifen möchten, z. B. zum effizienten Sortieren, können Sie [`make_contiguous`] verwenden.
/// Es dreht den `VecDeque` so, dass seine Elemente nicht umbrochen werden, und gibt ein veränderbares Slice an die jetzt zusammenhängende Elementsequenz zurück.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // Schwanz und Kopf sind Zeiger in den Puffer.
    // Tail zeigt immer auf das erste Element, das gelesen werden konnte. Head zeigt immer darauf, wo Daten geschrieben werden sollen.
    //
    // Wenn tail==head, ist der Puffer leer.Die Länge des Ringpuffers ist definiert als der Abstand zwischen den beiden.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Führt den Destruktor für alle Elemente im Slice aus, wenn er fallen gelassen wird (normalerweise oder beim Abwickeln).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // Verwenden Sie drop für [T]
            ptr::drop_in_place(front);
        }
        // RawVec übernimmt die Freigabe
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Erstellt ein leeres `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Etwas bequemer
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Etwas bequemer
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Bei Typen mit der Größe Null haben wir immer die maximale Kapazität
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Ptr in eine Scheibe verwandeln
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Verwandle ptr in eine mut-Scheibe
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Verschiebt ein Element aus dem Puffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Schreibt ein Element in den Puffer und verschiebt es.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Gibt `true` zurück, wenn der Puffer voll ausgelastet ist.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Gibt den Index im zugrunde liegenden Puffer für einen bestimmten logischen Elementindex zurück.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Gibt den Index im zugrunde liegenden Puffer für einen bestimmten logischen Elementindex + Addend zurück.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Gibt den Index im zugrunde liegenden Puffer für einen bestimmten logischen Elementindex (subtrahend) zurück.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kopiert einen zusammenhängenden Speicherblock von src nach dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopiert einen zusammenhängenden Speicherblock von src nach dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopiert einen potenziell umgebenden Speicherblock von src nach dest.
    /// (abs(dst - src) + len) darf nicht größer als cap() sein (es darf höchstens einen kontinuierlichen Überlappungsbereich zwischen src und dest geben).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src wird nicht umbrochen, dst wird nicht umbrochen
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst vor src wird src nicht umgebrochen, dst umbrochen
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src vor dst, src wird nicht umbrochen, dst wird umbrochen
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst vor src, src wird umbrochen, dst wird nicht umbrochen
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src vor dst, src wird umbrochen, dst wird nicht umbrochen
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst vor src, src wird umbrochen, dst wird umbrochen
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src vor dst, src wird umbrochen, dst wird umbrochen
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Stirnrunzelt die Kopf-und Schwanzabschnitte, um die Tatsache zu bewältigen, dass wir sie gerade neu zugewiesen haben.
    /// Unsicher, weil es old_capacity vertraut.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Bewegen Sie den kürzesten zusammenhängenden Abschnitt des Ringpuffers TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Ein Nein
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Erstellt ein leeres `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Erstellt ein leeres `VecDeque` mit Platz für mindestens `capacity`-Elemente.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1, da der Ringpuffer immer ein Leerzeichen leer lässt
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Bietet einen Verweis auf das Element am angegebenen Index.
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Bietet einen veränderlichen Verweis auf das Element am angegebenen Index.
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Vertauscht Elemente an den Indizes `i` und `j`.
    ///
    /// `i` und `j` können gleich sein.
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Panics
    ///
    /// Panics, wenn einer der Indizes außerhalb der Grenzen liegt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Gibt die Anzahl der Elemente zurück, die der `VecDeque` ohne Neuzuweisung aufnehmen kann.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Reserviert die Mindestkapazität für genau `additional` mehr Elemente, die in das angegebene `VecDeque` eingefügt werden sollen.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// Beachten Sie, dass der Allokator der Sammlung möglicherweise mehr Speicherplatz zur Verfügung stellt, als er anfordert.
    /// Daher kann nicht davon ausgegangen werden, dass die Kapazität genau minimal ist.
    /// Bevorzugen Sie [`reserve`], wenn future-Insertionen erwartet werden.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `usize` überläuft.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Reserviert Kapazität für mindestens `additional` mehr Elemente, die in das angegebene `VecDeque` eingefügt werden sollen.
    /// Die Sammlung kann mehr Platz reservieren, um häufige Neuzuweisungen zu vermeiden.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `usize` überläuft.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Versucht, die Mindestkapazität für genau `additional` mehr Elemente zu reservieren, die in das angegebene `VecDeque<T>` eingefügt werden sollen.
    ///
    /// Nach dem Aufruf von `try_reserve_exact` ist die Kapazität größer oder gleich `self.len() + additional`.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// Beachten Sie, dass der Allokator der Sammlung möglicherweise mehr Speicherplatz zur Verfügung stellt, als er anfordert.
    /// Daher kann nicht davon ausgegangen werden, dass die Kapazität genau minimal ist.
    /// Bevorzugen Sie `reserve`, wenn future-Insertionen erwartet werden.
    ///
    /// # Errors
    ///
    /// Wenn die Kapazität `usize` überläuft oder der Allokator einen Fehler meldet, wird ein Fehler zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reservieren Sie den Speicher vorab und beenden Sie ihn, wenn wir nicht können
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Jetzt wissen wir, dass dies mitten in unserer komplexen Arbeit nicht OOM(Out-Of-Memory) sein kann
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sehr kompliziert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Versucht, Kapazität für mindestens `additional` mehr Elemente zu reservieren, die in das angegebene `VecDeque<T>` eingefügt werden sollen.
    /// Die Sammlung kann mehr Platz reservieren, um häufige Neuzuweisungen zu vermeiden.
    /// Nach dem Aufruf von `try_reserve` ist die Kapazität größer oder gleich `self.len() + additional`.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// # Errors
    ///
    /// Wenn die Kapazität `usize` überläuft oder der Allokator einen Fehler meldet, wird ein Fehler zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reservieren Sie den Speicher vorab und beenden Sie ihn, wenn wir nicht können
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Jetzt wissen wir, dass dies mitten in unserer komplexen Arbeit nicht OOM sein kann
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sehr kompliziert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Verkleinert die Kapazität des `VecDeque` so weit wie möglich.
    ///
    /// Es wird so nah wie möglich an der Länge herunterfallen, aber der Allokator kann den `VecDeque` dennoch darüber informieren, dass Platz für ein paar weitere Elemente vorhanden ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Verkleinert die Kapazität des `VecDeque` mit einer Untergrenze.
    ///
    /// Die Kapazität bleibt mindestens so groß wie die Länge und der gelieferte Wert.
    ///
    ///
    /// Wenn die aktuelle Kapazität unter der Untergrenze liegt, ist dies ein No-Op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Wir müssen uns keine Sorgen um einen Überlauf machen, da weder `self.len()` noch `self.capacity()` jemals `usize::MAX` sein können.
        // +1, da der Ringpuffer immer ein Leerzeichen leer lässt.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Es gibt drei Fälle von Interesse:
            //   Alle Elemente liegen außerhalb der gewünschten Grenzen. Elemente sind zusammenhängend und der Kopf liegt außerhalb der gewünschten Grenzen. Elemente sind nicht zusammenhängend und der Schwanz liegt außerhalb der gewünschten Grenzen
            //
            //
            // Zu allen anderen Zeiten bleiben die Elementpositionen unberührt.
            //
            // Gibt an, dass Elemente am Kopf verschoben werden sollen.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Verschieben Sie Elemente aus den gewünschten Grenzen (Positionen nach target_cap).
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Verkürzt den `VecDeque`, behält die ersten `len`-Elemente bei und lässt den Rest fallen.
    ///
    ///
    /// Wenn `len` größer als die aktuelle Länge des `VecDeque` ist, hat dies keine Auswirkung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Führt den Destruktor für alle Elemente im Slice aus, wenn er fallen gelassen wird (normalerweise oder beim Abwickeln).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Sicher, weil:
        //
        // * Jedes an `drop_in_place` übergebene Slice ist gültig.Der zweite Fall hat `len <= front.len()` und die Rückkehr auf `len > self.len()` stellt im ersten Fall `begin <= back.len()` sicher
        //
        // * Der Kopf des VecDeque wird vor dem Aufruf von `drop_in_place` verschoben, sodass bei `drop_in_place` panics kein Wert zweimal gelöscht wird
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Stellen Sie sicher, dass die zweite Hälfte auch dann fallen gelassen wird, wenn sich ein Destruktor in der ersten panics befindet.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Gibt einen Front-to-Back-Iterator zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Gibt einen Front-to-Back-Iterator zurück, der veränderbare Referenzen zurückgibt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SICHERHEIT: Die interne `IterMut`-Sicherheitsinvariante wird festgelegt, weil die
        // `ring` Wir erstellen ist eine dereferencable Scheibe für die Lebensdauer '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Gibt ein Paar Slices zurück, die der Reihe nach den Inhalt des `VecDeque` enthalten.
    ///
    /// Wenn [`make_contiguous`] zuvor aufgerufen wurde, befinden sich alle Elemente des `VecDeque` im ersten Slice und das zweite Slice ist leer.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Gibt ein Paar Slices zurück, die der Reihe nach den Inhalt des `VecDeque` enthalten.
    ///
    /// Wenn [`make_contiguous`] zuvor aufgerufen wurde, befinden sich alle Elemente des `VecDeque` im ersten Slice und das zweite Slice ist leer.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Gibt die Anzahl der Elemente im `VecDeque` zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Gibt `true` zurück, wenn `VecDeque` leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Erstellt einen Iterator, der den angegebenen Bereich im `VecDeque` abdeckt.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Startpunkt größer als der Endpunkt ist oder wenn der Endpunkt größer als die Länge des vector ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ein vollständiges Sortiment deckt alle Inhalte ab
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Die gemeinsame Referenz, die wir in &self haben, wird im '_ von Iter gepflegt.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Erstellt einen Iterator, der den angegebenen veränderlichen Bereich im `VecDeque` abdeckt.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Startpunkt größer als der Endpunkt ist oder wenn der Endpunkt größer als die Länge des vector ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ein vollständiges Sortiment deckt alle Inhalte ab
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SICHERHEIT: Die interne `IterMut`-Sicherheitsinvariante wird festgelegt, weil die
        // `ring` Wir erstellen ist eine dereferencable Scheibe für die Lebensdauer '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Erstellt einen Drainage-Iterator, der den angegebenen Bereich im `VecDeque` entfernt und die entfernten Elemente liefert.
    ///
    /// Hinweis 1: Der Elementbereich wird entfernt, auch wenn der Iterator erst am Ende verbraucht wird.
    ///
    /// Hinweis 2: Es ist nicht angegeben, wie viele Elemente aus der Deque entfernt werden, wenn der `Drain`-Wert nicht gelöscht wird, der darin enthaltene Kredit jedoch abläuft (z. B. aufgrund von `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn der Startpunkt größer als der Endpunkt ist oder wenn der Endpunkt größer als die Länge des vector ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ein vollständiger Bereich löscht alle Inhalte
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Speichersicherheit
        //
        // Wenn der Drain zum ersten Mal erstellt wird, wird die Quelldeque gekürzt, um sicherzustellen, dass überhaupt keine nicht initialisierten oder verschobenen Elemente verfügbar sind, wenn der Destruktor des Drain nie ausgeführt werden kann.
        //
        //
        // Drain gibt die zu entfernenden Werte ptr::read aus.
        // Wenn Sie fertig sind, werden die verbleibenden Daten zurückkopiert, um das Loch abzudecken, und die head/tail-Werte werden korrekt wiederhergestellt.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Die Elemente der Deque sind in drei Segmente unterteilt:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Wir speichern drain_tail als self.head und drain_head und self.head als after_tail bzw. after_head auf dem Drain.
        // Dadurch wird auch das effektive Array abgeschnitten, sodass wir bei einem Leck des Drain die möglicherweise verschobenen Werte nach dem Start des drain vergessen haben.
        //
        //
        //        T th H.
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" über die Werte nach dem Start von drain bis nach Abschluss von drain und Ausführung des Drain-Destruktors.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Entscheidend ist, dass wir hier nur gemeinsame Referenzen von `self` erstellen und daraus lesen.
                // Wir schreiben weder in `self` noch leihen wir uns eine veränderbare Referenz aus.
                // Daher bleibt der oben für `deque` erstellte Rohzeiger gültig.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Löscht den `VecDeque` und entfernt alle Werte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Gibt `true` zurück, wenn `VecDeque` ein Element enthält, das dem angegebenen Wert entspricht.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Bietet einen Verweis auf das vordere Element oder `None`, wenn `VecDeque` leer ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Bietet einen veränderlichen Verweis auf das vordere Element oder `None`, wenn `VecDeque` leer ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Bietet einen Verweis auf das hintere Element oder `None`, wenn `VecDeque` leer ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Bietet einen veränderlichen Verweis auf das hintere Element oder `None`, wenn `VecDeque` leer ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Entfernt das erste Element und gibt es zurück oder `None`, wenn `VecDeque` leer ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Entfernt das letzte Element aus dem `VecDeque` und gibt es zurück, oder `None`, wenn es leer ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Stellt dem `VecDeque` ein Element voran.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Hängt ein Element an die Rückseite des `VecDeque` an.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Sollten wir `head == 0` als gemeint betrachten?
        // dass `self` zusammenhängend ist?
        self.tail <= self.head
    }

    /// Entfernt ein Element von einer beliebigen Stelle im `VecDeque` und gibt es zurück, wobei es durch das erste Element ersetzt wird.
    ///
    ///
    /// Die Reihenfolge bleibt nicht erhalten, sondern *O*(1).
    ///
    /// Gibt `None` zurück, wenn `index` außerhalb der Grenzen liegt.
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Entfernt ein Element von einer beliebigen Stelle im `VecDeque` und gibt es zurück, wobei es durch das letzte Element ersetzt wird.
    ///
    ///
    /// Die Reihenfolge bleibt nicht erhalten, sondern *O*(1).
    ///
    /// Gibt `None` zurück, wenn `index` außerhalb der Grenzen liegt.
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Fügt ein Element an `index` in `VecDeque` ein und verschiebt alle Elemente mit Indizes größer oder gleich `index` nach hinten.
    ///
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Panics
    ///
    /// Panics, wenn `index` größer als die Länge von `VecDeque` ist
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Verschieben Sie die geringste Anzahl von Elementen in den Ringpuffer und fügen Sie das angegebene Objekt ein
        //
        // Höchstens len/2 werden 1 Elemente verschoben. O(min(n, n-i))
        //
        // Es gibt drei Hauptfälle:
        //  Elemente sind zusammenhängend
        //      - Sonderfall, wenn Schwanz 0 ist Elemente sind nicht zusammenhängend und der Einsatz befindet sich im Schwanzbereich Elemente sind nicht zusammenhängend und der Einsatz befindet sich im Kopfbereich
        //
        //
        // Für jeden dieser Fälle gibt es zwei weitere Fälle:
        //  Insert ist näher am Schwanz Insert ist näher am Kopf
        //
        // Taste: H, self.head
        //      T, self.tail o, Gültiges Element I, Einfügeelement A, Das Element, das nach der Einfügemarke M liegen soll. Zeigt an, dass das Element verschoben wurde
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // zusammenhängend, näher am Schwanz einfügen:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // zusammenhängend, näher am Schwanz einfügen und Schwanz ist 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Der Schwanz wurde bereits verschoben, daher kopieren wir nur `index - 1`-Elemente.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // zusammenhängend, näher am Kopf einfügen:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // nicht zusammenhängend, näher am Schwanz einsetzen, Schwanzabschnitt:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // nicht zusammenhängend, näher am Kopf, Schwanzteil einführen:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // Kopieren Sie Elemente auf einen neuen Kopf
                    self.copy(1, 0, self.head);

                    // Kopieren Sie das letzte Element an eine leere Stelle am unteren Rand des Puffers
                    self.copy(0, self.cap() - 1, 1);

                    // Verschieben Sie Elemente von idx nach end vorwärts, ohne ^ element einzuschließen
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // Nicht zusammenhängend, Insert ist näher am Schwanz, Kopfabschnitt und befindet sich im internen Puffer auf Index Null:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // Kopieren Sie die Elemente bis zum neuen Schwanz
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // Kopieren Sie das letzte Element an eine leere Stelle am unteren Rand des Puffers
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // nicht zusammenhängend, näher am Schwanz einsetzen, Kopfteil:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // Kopieren Sie die Elemente bis zum neuen Schwanz
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // Kopieren Sie das letzte Element an eine leere Stelle am unteren Rand des Puffers
                    self.copy(self.cap() - 1, 0, 1);

                    // Verschieben Sie Elemente von idx-1 nach vorne, ohne das Element ^ einzuschließen
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // nicht zusammenhängend, näher am Kopf einsetzen, Kopfteil:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // Der Schwanz wurde möglicherweise geändert, sodass wir ihn neu berechnen müssen
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Entfernt das Element bei `index` und gibt es vom `VecDeque` zurück.
    /// Welches Ende näher am Entfernungspunkt liegt, wird verschoben, um Platz zu schaffen, und alle betroffenen Elemente werden an neue Positionen verschoben.
    ///
    /// Gibt `None` zurück, wenn `index` außerhalb der Grenzen liegt.
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Es gibt drei Hauptfälle:
        //  Elemente sind zusammenhängend Elemente sind nicht zusammenhängend und die Entfernung erfolgt im hinteren Bereich. Elemente sind nicht zusammenhängend und die Entfernung erfolgt im Kopfbereich
        //
        //      - Sonderfall, wenn Elemente technisch zusammenhängend sind, aber self.head =0
        //
        // Für jeden dieser Fälle gibt es zwei weitere Fälle:
        //  Insert ist näher am Schwanz Insert ist näher am Kopf
        //
        // Taste: H, self.head
        //      T, self.tail o, Gültiges Element x, Zum Entfernen markiertes Element R, Zeigt an, dass das Element entfernt wird M, Zeigt an, dass das Element verschoben wurde
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // zusammenhängend, näher am Schwanz entfernen:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // zusammenhängend, näher am Kopf entfernen:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // nicht zusammenhängend, näher am Schwanz entfernen, Schwanzabschnitt:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // nicht zusammenhängend, näher am Kopf entfernen, Kopfteil:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // nicht zusammenhängend, näher an Kopf, Schwanz entfernen:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // oder quasi nicht zusammenhängend, neben Kopf, Schwanz entfernen:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // Zeichnen Sie Elemente im Heckbereich ein
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Verhindert Unterlauf.
                    if self.head != 0 {
                        // Kopieren Sie das erste Element an eine leere Stelle
                        self.copy(self.cap() - 1, 0, 1);

                        // Bewegen Sie die Elemente im Kopfbereich nach hinten
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // nicht zusammenhängend, näher am Schwanz entfernen, Kopfteil:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // Zeichnen Sie Elemente bis zu idx ein
                    self.copy(1, 0, idx);

                    // Kopieren Sie das letzte Element an eine leere Stelle
                    self.copy(0, self.cap() - 1, 1);

                    // Bewegen Sie die Elemente vom Schwanz bis zum Ende nach vorne, mit Ausnahme des letzten
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Teilt den `VecDeque` am angegebenen Index in zwei Teile.
    ///
    /// Gibt einen neu zugewiesenen `VecDeque` zurück.
    /// `self` enthält Elemente `[0, at)` und das zurückgegebene `VecDeque` enthält Elemente `[at, len)`.
    ///
    /// Beachten Sie, dass sich die Kapazität von `self` nicht ändert.
    ///
    /// Das Element am Index 0 ist die Vorderseite der Warteschlange.
    ///
    /// # Panics
    ///
    /// Panics wenn `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` liegt in der ersten Hälfte.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // Nehmen Sie einfach die ganze zweite Hälfte.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` liegt in der zweiten Hälfte, müssen die Elemente berücksichtigen, die wir in der ersten Hälfte übersprungen haben.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Bereinigen Sie dort, wo sich die Enden der Puffer befinden
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Verschiebt alle Elemente von `other` in `self` und lässt `other` leer.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Anzahl von Elementen in self einen `usize` überläuft.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naiv impl
        self.extend(other.drain(..));
    }

    /// Behält nur die vom Prädikat angegebenen Elemente bei.
    ///
    /// Mit anderen Worten, entfernen Sie alle Elemente `e` so, dass `f(&e)` false zurückgibt.
    /// Diese Methode funktioniert an Ort und Stelle und besucht jedes Element genau einmal in der ursprünglichen Reihenfolge und behält die Reihenfolge der beibehaltenen Elemente bei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Die genaue Reihenfolge kann nützlich sein, um den externen Status wie einen Index zu verfolgen.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Dies kann panic oder abbrechen
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Verdoppeln Sie die Puffergröße.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Ändert das `VecDeque` an Ort und Stelle so, dass `len()` gleich `new_len` ist, indem entweder überschüssige Elemente von der Rückseite entfernt oder Elemente angehängt werden, die durch Aufrufen von `generator` an der Rückseite generiert wurden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Ordnet den internen Speicher dieser Deque neu, sodass es sich um eine zusammenhängende Scheibe handelt, die dann zurückgegeben wird.
    ///
    /// Diese Methode ordnet die Reihenfolge der eingefügten Elemente nicht zu und ändert sie nicht.Da ein veränderbares Slice zurückgegeben wird, kann dies zum Sortieren einer Deque verwendet werden.
    ///
    /// Sobald der interne Speicher zusammenhängend ist, geben die Methoden [`as_slices`] und [`as_mut_slices`] den gesamten Inhalt des `VecDeque` in einem einzigen Slice zurück.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Sortieren des Inhalts einer Deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // Sortieren der Deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // in umgekehrter Reihenfolge sortieren
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Unveränderlichen Zugriff auf das zusammenhängende Slice erhalten.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // Wir können jetzt sicher sein, dass `slice` alle Elemente der Deque enthält und dennoch unveränderlichen Zugriff auf `buf` hat.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // Es gibt genügend freien Speicherplatz, um den Schwanz auf einmal zu kopieren. Dies bedeutet, dass wir zuerst den Kopf nach hinten verschieben und dann den Schwanz in die richtige Position kopieren.
            //
            //
            // von: DEFGH .... ABC
            // an: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Wir berücksichtigen derzeit nicht .... ABCDEFGH
            // zusammenhängend sein, weil `head` in diesem Fall `0` wäre.
            // Obwohl wir dies wahrscheinlich ändern möchten, ist dies nicht trivial, da einige Stellen erwarten, dass `is_contiguous` bedeutet, dass wir nur mit `buf[tail..head]` schneiden können.
            //
            //

            // Es gibt genügend freien Speicherplatz, um den Kopf auf einmal zu kopieren. Dies bedeutet, dass wir zuerst den Schwanz nach vorne verschieben und dann den Kopf in die richtige Position kopieren.
            //
            //
            // von: FGH .... ABCDE
            // zu: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // frei ist kleiner als Kopf und Schwanz, das heißt, wir müssen den Schwanz und den Kopf langsam "swap".
            //
            //
            // von: EFGHI ... ABCD oder HIJK.ABCDEFG
            // an: ABCDEFGHI ... oder ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Das allgemeine Problem sieht so aus: GHIJKLM ... ABCDEF, vor jedem Swap ABCDEFM ... GHIJKL, nach 1 Durchgang der Swaps ABCDEFGHIJM ... KL, tauschen, bis das linke edge den temporären Speicher erreicht
                //                  - Starten Sie dann den Algorithmus mit einem neuen (smaller)-Speicher neu. Manchmal ist der temporäre Speicher erreicht, wenn sich das richtige edge am Ende des Puffers befindet. Dies bedeutet, dass wir mit weniger Swaps die richtige Reihenfolge erreicht haben!
                //
                // E.g
                // EF..ABCD ABCDEF .., nach vier einzigen Swaps sind wir fertig
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Dreht die `mid`-Positionen der doppelseitigen Warteschlange nach links.
    ///
    /// Equivalently,
    /// - Dreht den Gegenstand `mid` in die erste Position.
    /// - Pops die ersten `mid`-Elemente und schiebt sie bis zum Ende.
    /// - Dreht die `len() - mid`-Stellen nach rechts.
    ///
    /// # Panics
    ///
    /// Wenn `mid` größer als `len()` ist.
    /// Beachten Sie, dass `mid == len()` _not_ panic ausführt und eine No-Op-Drehung ist.
    ///
    /// # Complexity
    ///
    /// Benötigt `*O*(min(mid, len() - mid))` Zeit und keinen zusätzlichen Speicherplatz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Dreht die `k`-Positionen der doppelseitigen Warteschlange nach rechts.
    ///
    /// Equivalently,
    /// - Dreht das erste Element in Position `k`.
    /// - Öffnet die letzten `k`-Gegenstände und schiebt sie nach vorne.
    /// - Dreht die `len() - k`-Stellen nach links.
    ///
    /// # Panics
    ///
    /// Wenn `k` größer als `len()` ist.
    /// Beachten Sie, dass `k == len()` _not_ panic ausführt und eine No-Op-Drehung ist.
    ///
    /// # Complexity
    ///
    /// Benötigt `*O*(min(k, len() - k))` Zeit und keinen zusätzlichen Speicherplatz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SICHERHEIT: Die folgenden zwei Methoden erfordern den Rotationsbetrag
    // weniger als die halbe Länge der Deque sein.
    //
    // `wrap_copy` erfordert, dass `min(x, cap() - x) + copy_len <= cap()`, aber als `min` nie mehr als die Hälfte der Kapazität ist, unabhängig von x, daher ist es sinnvoll, hier anzurufen, da wir mit etwas weniger als der halben Länge anrufen, was niemals über der Hälfte der Kapazität liegt.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary durchsucht dieses sortierte `VecDeque` nach einem bestimmten Element.
    ///
    /// Wenn der Wert gefunden wird, wird [`Result::Ok`] zurückgegeben, das den Index des übereinstimmenden Elements enthält.
    /// Wenn es mehrere Übereinstimmungen gibt, kann eine der Übereinstimmungen zurückgegeben werden.
    /// Wenn der Wert nicht gefunden wird, wird [`Result::Err`] zurückgegeben, das den Index enthält, in den ein übereinstimmendes Element eingefügt werden kann, während die sortierte Reihenfolge beibehalten wird.
    ///
    ///
    /// # Examples
    ///
    /// Schlägt eine Reihe von vier Elementen nach.
    /// Die erste wird mit einer eindeutig bestimmten Position gefunden;der zweite und dritte werden nicht gefunden;Der vierte könnte mit jeder Position in `[1, 4]` übereinstimmen.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Wenn Sie ein Element in ein sortiertes `VecDeque` einfügen möchten, während Sie die Sortierreihenfolge beibehalten:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binär durchsucht diesen sortierten `VecDeque` mit einer Komparatorfunktion.
    ///
    /// Die Komparatorfunktion sollte eine Reihenfolge implementieren, die mit der Sortierreihenfolge des zugrunde liegenden `VecDeque` übereinstimmt, und einen Bestellcode zurückgeben, der angibt, ob das Argument `Less`, `Equal` oder `Greater` als das gewünschte Ziel ist.
    ///
    ///
    /// Wenn der Wert gefunden wird, wird [`Result::Ok`] zurückgegeben, das den Index des übereinstimmenden Elements enthält.Wenn es mehrere Übereinstimmungen gibt, kann eine der Übereinstimmungen zurückgegeben werden.
    /// Wenn der Wert nicht gefunden wird, wird [`Result::Err`] zurückgegeben, das den Index enthält, in den ein übereinstimmendes Element eingefügt werden kann, während die sortierte Reihenfolge beibehalten wird.
    ///
    /// # Examples
    ///
    /// Schlägt eine Reihe von vier Elementen nach.Die erste wird mit einer eindeutig bestimmten Position gefunden;der zweite und dritte werden nicht gefunden;Der vierte könnte mit jeder Position in `[1, 4]` übereinstimmen.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binär durchsucht dieses sortierte `VecDeque` mit einer Schlüsselextraktionsfunktion.
    ///
    /// Angenommen, der `VecDeque` ist nach dem Schlüssel sortiert, z. B. mit [`make_contiguous().sort_by_key()`](#method.make_contiguous), der dieselbe Schlüsselextraktionsfunktion verwendet.
    ///
    ///
    /// Wenn der Wert gefunden wird, wird [`Result::Ok`] zurückgegeben, das den Index des übereinstimmenden Elements enthält.
    /// Wenn es mehrere Übereinstimmungen gibt, kann eine der Übereinstimmungen zurückgegeben werden.
    /// Wenn der Wert nicht gefunden wird, wird [`Result::Err`] zurückgegeben, das den Index enthält, in den ein übereinstimmendes Element eingefügt werden kann, während die sortierte Reihenfolge beibehalten wird.
    ///
    /// # Examples
    ///
    /// Sucht eine Reihe von vier Elementen in einer Gruppe von Paaren, die nach ihren zweiten Elementen sortiert sind.
    /// Die erste wird mit einer eindeutig bestimmten Position gefunden;der zweite und dritte werden nicht gefunden;Der vierte könnte mit jeder Position in `[1, 4]` übereinstimmen.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Ändert das `VecDeque` an Ort und Stelle so, dass `len()` gleich new_len ist, indem entweder überschüssige Elemente von der Rückseite entfernt oder Klone von `value` an die Rückseite angehängt werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Gibt den Index im zugrunde liegenden Puffer für einen bestimmten logischen Elementindex zurück.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // Größe ist immer eine Potenz von 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Berechnen Sie die Anzahl der Elemente, die noch im Puffer gelesen werden müssen
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // Größe ist immer eine Potenz von 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Immer in drei Abschnitte teilbar, zum Beispiel: self: [a b c|d e f] other: [0 1 2 3|4 5] front=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Es ist nicht möglich, Hash::hash_slice für Slices zu verwenden, die von der as_slices-Methode zurückgegeben werden, da deren Länge in ansonsten identischen Deques variieren kann.
        //
        //
        // Hasher garantiert nur die Äquivalenz für genau die gleichen Aufrufe seiner Methoden.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Verbraucht den `VecDeque` in einen Front-to-Back-Iterator, der Elemente nach Wert liefert.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Diese Funktion sollte das moralische Äquivalent sein von:
        //
        //      für Artikel in iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Verwandeln Sie einen [`Vec<T>`] in einen [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dies vermeidet nach Möglichkeit eine Neuzuweisung, aber die Bedingungen hierfür sind streng und können sich ändern. Daher sollte nicht darauf vertraut werden, es sei denn, der `Vec<T>` stammt von `From<VecDeque<T>>` und wurde nicht neu zugewiesen.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Es gibt keine tatsächliche Zuordnung für ZSTs, um sich über die Kapazität Gedanken zu machen, aber `VecDeque` kann nicht so viel Länge verarbeiten wie `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Wir müssen die Größe ändern, wenn die Kapazität keine Zweierpotenz ist, zu klein oder nicht mindestens ein freier Speicherplatz vorhanden ist.
            // Wir tun dies, solange es sich noch im `Vec` befindet, damit die Elemente auf panic abgelegt werden.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Verwandeln Sie einen [`VecDeque<T>`] in einen [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dies muss nie neu zugeordnet werden, sondern muss *O*(*n*) Daten verschieben, wenn sich der Ringpuffer nicht zu Beginn der Zuweisung befindet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Dieser ist *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Dieser muss neu angeordnet werden.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}