//! Unicode-String-Slices.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Der `&str`-Typ ist einer der beiden Hauptzeichenfolgentypen, der andere ist `String`.
//! Im Gegensatz zum `String`-Gegenstück werden die Inhalte ausgeliehen.
//!
//! # Grundlegende Verwendung
//!
//! Eine grundlegende Zeichenfolgendeklaration vom Typ `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Hier haben wir ein String-Literal deklariert, das auch als String-Slice bezeichnet wird.
//! String-Literale haben eine statische Lebensdauer, was bedeutet, dass der String `hello_world` garantiert für die Dauer des gesamten Programms gültig ist.
//!
//! Wir können auch die Lebensdauer von "hello_world" explizit angeben:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Viele der Verwendungen in diesem Modul werden nur in der Testkonfiguration verwendet.
// Es ist sauberer, die Warnung "unused_imports" einfach auszuschalten, als sie zu beheben.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` in `Concat<str>` ist hier nicht aussagekräftig.
/// Dieser Typparameter des trait ist nur vorhanden, um ein anderes Impl zu aktivieren.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // Schleifen mit fest codierten Größen laufen viel schneller. Spezialisieren Sie die Gehäuse mit kleinen Trennlängen
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // beliebiger Fallback ungleich Null
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Optimierte Join-Implementierung, die für beide Vec funktioniert<T>(T: Copy) und String's inner vec Derzeit gibt es bei (2018-05-13) einen Fehler mit Typinferenz und Spezialisierung (siehe Ausgabe #36262). Aus diesem Grund SliceConcat<T>ist nicht auf T: Copy und SliceConcat spezialisiert<str>ist der einzige Benutzer dieser Funktion.
// Es bleibt für die Zeit an Ort und Stelle, wenn dies behoben ist.
//
// Die Grenzen für String-Join sind S: Borrow<str>und für Vec-join Borrow <[T]> [T] und str implizieren beide AsRef <[T]> für einige T.
// => s.borrow().as_ref() und wir haben immer Scheiben
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // Die erste Scheibe ist die einzige ohne Trennzeichen
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // Berechnen Sie die genaue Gesamtlänge des verbundenen Vec, wenn die `len`-Berechnung überläuft. Wir haben ohnehin keinen Speicher mehr und der Rest der Funktion erfordert den gesamten Vec, der aus Sicherheitsgründen vorab zugewiesen wurde
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // Bereiten Sie einen nicht initialisierten Puffer vor
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // Kopiertrennzeichen und Slices ohne Begrenzungsprüfungen erzeugen Schleifen mit fest codierten Offsets für kleine Trennzeichen. Massive Verbesserungen möglich (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Eine seltsame Ausleihimplementierung kann unterschiedliche Slices für die Längenberechnung und die tatsächliche Kopie zurückgeben.
        //
        // Stellen Sie sicher, dass wir dem Anrufer keine nicht initialisierten Bytes zur Verfügung stellen.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Methoden für String-Slices.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Konvertiert einen `Box<str>` in einen `Box<[u8]>`, ohne ihn zu kopieren oder zuzuweisen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Ersetzt alle Übereinstimmungen eines Musters durch eine andere Zeichenfolge.
    ///
    /// `replace` Erstellt einen neuen [`String`] und kopiert die Daten aus diesem String-Slice in diesen.
    /// Dabei wird versucht, Übereinstimmungen eines Musters zu finden.
    /// Wenn es welche findet, werden sie durch das Ersatz-String-Slice ersetzt.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Wenn das Muster nicht übereinstimmt:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ersetzt die ersten N Übereinstimmungen eines Musters durch eine andere Zeichenfolge.
    ///
    /// `replacen` Erstellt einen neuen [`String`] und kopiert die Daten aus diesem String-Slice in diesen.
    /// Dabei wird versucht, Übereinstimmungen eines Musters zu finden.
    /// Wenn es welche findet, werden sie höchstens `count`-mal durch das Ersatz-String-Slice ersetzt.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Wenn das Muster nicht übereinstimmt:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Wir hoffen, die Zeiten für die Neuzuweisung zu verkürzen
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Gibt das Kleinbuchstabenäquivalent dieses String-Slice als neues [`String`] zurück.
    ///
    /// 'Lowercase' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `Lowercase` definiert.
    ///
    /// Da einige Zeichen beim Ändern der Groß-und Kleinschreibung in mehrere Zeichen erweitert werden können, gibt diese Funktion ein [`String`] zurück, anstatt den Parameter direkt zu ändern.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Ein kniffliges Beispiel mit Sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // aber am Ende eines Wortes ist es ς, nicht σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Sprachen ohne Groß-und Kleinschreibung werden nicht geändert:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ ist auf σ abgebildet, außer am Ende eines Wortes, wo es auf ς abgebildet ist.
                // Dies ist die einzige bedingte (contextual)-Zuordnung, die jedoch sprachunabhängig in `SpecialCasing.txt` ist. Codieren Sie sie daher hart, anstatt über einen generischen "condition"-Mechanismus zu verfügen.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // für die Definition von `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Gibt das Großbuchstabenäquivalent dieses String-Slice als neues [`String`] zurück.
    ///
    /// 'Uppercase' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `Uppercase` definiert.
    ///
    /// Da einige Zeichen beim Ändern der Groß-und Kleinschreibung in mehrere Zeichen erweitert werden können, gibt diese Funktion ein [`String`] zurück, anstatt den Parameter direkt zu ändern.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Skripte ohne Groß-und Kleinschreibung werden nicht geändert:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ein Charakter kann mehrere werden:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Konvertiert einen [`Box<str>`] in einen [`String`], ohne ihn zu kopieren oder zuzuweisen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Erstellt ein neues [`String`], indem eine Zeichenfolge `n`-mal wiederholt wird.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn die Kapazität überlaufen würde.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Ein panic bei Überlauf:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Gibt eine Kopie dieser Zeichenfolge zurück, bei der jedes Zeichen seinem ASCII-Großbuchstaben zugeordnet ist.
    ///
    ///
    /// ASCII-Buchstaben 'a' bis 'z' werden 'A' bis 'Z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`make_ascii_uppercase`], um den Wert direkt in Großbuchstaben zu setzen.
    ///
    /// Verwenden Sie [`to_uppercase`], um ASCII-Zeichen zusätzlich zu Nicht-ASCII-Zeichen in Großbuchstaben zu schreiben.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() behält die UTF-8-Invariante bei.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Gibt eine Kopie dieser Zeichenfolge zurück, bei der jedes Zeichen seinem ASCII-Kleinbuchstabenäquivalent zugeordnet ist.
    ///
    ///
    /// ASCII-Buchstaben 'A' bis 'Z' werden 'a' bis 'z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`make_ascii_lowercase`], um den Wert an Ort und Stelle in Kleinbuchstaben zu schreiben.
    ///
    /// Verwenden Sie [`to_lowercase`], um ASCII-Zeichen zusätzlich zu Nicht-ASCII-Zeichen in Kleinbuchstaben zu schreiben.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() behält die UTF-8-Invariante bei.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Konvertiert ein Boxed-Slice von Bytes in ein Boxed-String-Slice, ohne zu überprüfen, ob die Zeichenfolge gültiges UTF-8 enthält.
///
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}