//! Ein UTF-8-codierter, erweiterbarer String.
//!
//! Dieses Modul enthält den [`String`]-Typ, den [`ToString`] trait zum Konvertieren in Zeichenfolgen und verschiedene Fehlertypen, die sich aus der Arbeit mit [`String`] ergeben können.
//!
//!
//! # Examples
//!
//! Es gibt mehrere Möglichkeiten, ein neues [`String`] aus einem Zeichenfolgenliteral zu erstellen:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Sie können ein neues [`String`] aus einem vorhandenen erstellen, indem Sie es verketten
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Wenn Sie einen vector mit gültigen UTF-8-Bytes haben, können Sie daraus einen [`String`] machen.Sie können auch das Gegenteil tun.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Wir wissen, dass diese Bytes gültig sind, daher verwenden wir `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Ein UTF-8-codierter, erweiterbarer String.
///
/// Der `String`-Typ ist der am häufigsten verwendete Zeichenfolgentyp, der Eigentümer des Inhalts der Zeichenfolge ist.Es hat eine enge Beziehung zu seinem geliehenen Gegenstück, dem primitiven [`str`].
///
/// # Examples
///
/// Sie können mit [`String::from`] einen `String` aus [a literal string][`str`] erstellen:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Sie können einen [`char`] mit der [`push`]-Methode an einen `String` anhängen und einen [`&str`] mit der [`push_str`]-Methode anhängen:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Wenn Sie einen vector mit UTF-8-Bytes haben, können Sie mit der [`from_utf8`]-Methode einen `String` daraus erstellen:
///
/// ```
/// // einige Bytes in einem vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Wir wissen, dass diese Bytes gültig sind, daher verwenden wir `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s sind immer gültig UTF-8.Dies hat einige Auswirkungen. Die erste besteht darin, dass Sie [`OsString`] in Betracht ziehen, wenn Sie eine Nicht-UTF-8-Zeichenfolge benötigen.Es ist ähnlich, aber ohne die UTF-8-Einschränkung.Die zweite Implikation ist, dass Sie nicht in einen `String` indizieren können:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Die Indizierung soll eine Operation mit konstanter Zeit sein, aber die UTF-8-Codierung erlaubt uns dies nicht.Außerdem ist nicht klar, was der Index zurückgeben soll: ein Byte, ein Codepunkt oder ein Graphemcluster.
/// Die Methoden [`bytes`] und [`chars`] geben Iteratoren über die ersten beiden zurück.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implementieren [`Deref`] `<Target=str>`und erben so alle Methoden von [`str`].Dies bedeutet außerdem, dass Sie einen `String` an eine Funktion übergeben können, die einen [`&str`] verwendet, indem Sie ein kaufmännisches Und (`&`) verwenden:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Dadurch wird ein [`&str`] aus dem `String` erstellt und übergeben. Diese Konvertierung ist sehr kostengünstig. Daher akzeptieren Funktionen im Allgemeinen [`&str`] als Argumente, es sei denn, sie benötigen aus einem bestimmten Grund einen `String`.
///
/// In bestimmten Fällen verfügt Rust nicht über genügend Informationen, um diese Konvertierung durchzuführen, die als [`Deref`]-Zwang bezeichnet wird.Im folgenden Beispiel implementiert ein String-Slice [`&'a str`][`&str`] den trait `TraitExample`, und die Funktion `example_func` übernimmt alles, was den trait implementiert.
/// In diesem Fall müsste Rust zwei implizite Konvertierungen durchführen, für die Rust nicht die Mittel hat.
/// Aus diesem Grund wird das folgende Beispiel nicht kompiliert.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Es gibt zwei Optionen, die stattdessen funktionieren würden.Die erste besteht darin, die Zeile `example_func(&example_string);` in `example_func(example_string.as_str());` zu ändern und dabei die Methode [`as_str()`] zu verwenden, um das Zeichenfolgen-Slice, das die Zeichenfolge enthält, explizit zu extrahieren.
/// Der zweite Weg ändert `example_func(&example_string);` in `example_func(&*example_string);`.
/// In diesem Fall dereferenzieren wir einen `String` auf einen [`str`][`&str`] und verweisen dann den [`str`][`&str`] zurück auf [`&str`].
/// Der zweite Weg ist idiomatischer, jedoch arbeiten beide daran, die Konvertierung explizit durchzuführen, anstatt sich auf die implizite Konvertierung zu verlassen.
///
/// # Representation
///
/// Ein `String` besteht aus drei Komponenten: einem Zeiger auf einige Bytes, einer Länge und einer Kapazität.Der Zeiger zeigt auf einen internen Puffer, den `String` zum Speichern seiner Daten verwendet.Die Länge ist die Anzahl der aktuell im Puffer gespeicherten Bytes, und die Kapazität ist die Größe des Puffers in Bytes.
///
/// Daher ist die Länge immer kleiner oder gleich der Kapazität.
///
/// Dieser Puffer wird immer auf dem Heap gespeichert.
///
/// Sie können diese mit den Methoden [`as_ptr`], [`len`] und [`capacity`] anzeigen:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Aktualisieren Sie dies, wenn vec_into_raw_parts stabilisiert ist.
/// // Verhindern Sie, dass die Daten des Strings automatisch gelöscht werden
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // Die Geschichte hat neunzehn Bytes
/// assert_eq!(19, len);
///
/// // Wir können einen String aus ptr, len und Kapazität neu erstellen.
/// // Dies ist alles unsicher, da wir dafür verantwortlich sind, dass die Komponenten gültig sind:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Wenn ein `String` über genügend Kapazität verfügt, wird das Hinzufügen von Elementen nicht neu zugewiesen.Betrachten Sie zum Beispiel dieses Programm:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Dies gibt Folgendes aus:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Zunächst ist uns überhaupt kein Speicher zugewiesen, aber wenn wir an die Zeichenfolge anhängen, wird die Kapazität entsprechend erhöht.Wenn wir stattdessen die [`with_capacity`]-Methode verwenden, um zunächst die richtige Kapazität zuzuweisen:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Am Ende haben wir eine andere Ausgabe:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Hier muss nicht mehr Speicher innerhalb der Schleife zugewiesen werden.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Ein möglicher Fehlerwert beim Konvertieren eines `String` aus einem UTF-8-Byte vector.
///
/// Dieser Typ ist der Fehlertyp für die [`from_utf8`]-Methode unter [`String`].
/// Es ist so konzipiert, dass Neuzuweisungen sorgfältig vermieden werden: Die [`into_bytes`]-Methode gibt das Byte vector zurück, das beim Konvertierungsversuch verwendet wurde.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Der von [`std::str`] bereitgestellte [`Utf8Error`]-Typ stellt einen Fehler dar, der beim Konvertieren eines Slice von [`u8`] s in einen [`&str`] auftreten kann.
/// In diesem Sinne ist es ein Analogon zu `FromUtf8Error`, und Sie können eines von einem `FromUtf8Error` über die [`utf8_error`]-Methode erhalten.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// // einige ungültige Bytes in einem vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Ein möglicher Fehlerwert beim Konvertieren eines `String` aus einem UTF-16-Byte-Slice.
///
/// Dieser Typ ist der Fehlertyp für die [`from_utf16`]-Methode unter [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Erstellt ein neues leeres `String`.
    ///
    /// Da der `String` leer ist, wird kein anfänglicher Puffer zugewiesen.Dies bedeutet zwar, dass diese anfängliche Operation sehr kostengünstig ist, sie kann jedoch später beim Hinzufügen von Daten zu einer übermäßigen Zuordnung führen.
    ///
    /// Wenn Sie eine Vorstellung davon haben, wie viele Daten der `String` enthalten wird, ziehen Sie die [`with_capacity`]-Methode in Betracht, um eine übermäßige Neuzuweisung zu verhindern.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Erstellt einen neuen leeren `String` mit einer bestimmten Kapazität.
    ///
    /// `String`s haben einen internen Puffer, um ihre Daten zu speichern.
    /// Die Kapazität ist die Länge dieses Puffers und kann mit der [`capacity`]-Methode abgefragt werden.
    /// Diese Methode erstellt ein leeres `String`, jedoch eines mit einem Anfangspuffer, der `capacity`-Bytes enthalten kann.
    /// Dies ist nützlich, wenn Sie möglicherweise eine Reihe von Daten an den `String` anhängen, um die Anzahl der erforderlichen Neuzuweisungen zu verringern.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Wenn die angegebene Kapazität `0` ist, erfolgt keine Zuordnung, und diese Methode ist mit der [`new`]-Methode identisch.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Der String enthält keine Zeichen, obwohl er Platz für mehr bietet
    /// assert_eq!(s.len(), 0);
    ///
    /// // Diese werden alle ohne Neuzuweisung durchgeführt ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... aber dies kann dazu führen, dass der String neu zugewiesen wird
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): Bei cfg(test) ist die für diese Methodendefinition erforderliche inhärente `[T]::to_vec`-Methode nicht verfügbar.
    // Da wir diese Methode nicht zu Testzwecken benötigen, werde ich sie nur stummschalten. Weitere Informationen finden Sie im slice::hack-Modul in slice.rs
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Konvertiert einen vector von Bytes in einen `String`.
    ///
    /// Ein String ([`String`]) besteht aus Bytes ([`u8`]), und ein vector aus Bytes ([`Vec<u8>`]) besteht aus Bytes, sodass diese Funktion zwischen den beiden konvertiert.
    /// Es sind jedoch nicht alle Byte-Slices gültige `String`s: `String` setzt voraus, dass UTF-8 gültig ist.
    /// `from_utf8()` prüft, ob die Bytes UTF-8 gültig sind, und führt dann die Konvertierung durch.
    ///
    /// Wenn Sie sicher sind, dass das Byte-Slice UTF-8 gültig ist und Sie den Overhead der Gültigkeitsprüfung nicht verursachen möchten, gibt es eine unsichere Version dieser Funktion, [`from_utf8_unchecked`], die dasselbe Verhalten aufweist, die Prüfung jedoch überspringt.
    ///
    ///
    /// Bei dieser Methode wird aus Effizienzgründen darauf geachtet, den vector nicht zu kopieren.
    ///
    /// Wenn Sie einen [`&str`] anstelle eines `String` benötigen, ziehen Sie [`str::from_utf8`] in Betracht.
    ///
    /// Die Umkehrung dieser Methode ist [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Gibt [`Err`] zurück, wenn das Slice nicht UTF-8 ist, mit einer Beschreibung, warum die bereitgestellten Bytes nicht UTF-8 sind.Der vector, in den Sie eingezogen sind, ist ebenfalls enthalten.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // einige Bytes in einem vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Wir wissen, dass diese Bytes gültig sind, daher verwenden wir `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Falsche Bytes:
    ///
    /// ```
    /// // einige ungültige Bytes in einem vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Weitere Informationen dazu, wie Sie mit diesem Fehler umgehen können, finden Sie in den Dokumenten für [`FromUtf8Error`].
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Konvertiert ein Byte-Slice in eine Zeichenfolge, einschließlich ungültiger Zeichen.
    ///
    /// Zeichenfolgen bestehen aus Bytes ([`u8`]), und eine Schicht von Bytes ([`&[u8]`][byteslice]) besteht aus Bytes, sodass diese Funktion zwischen den beiden konvertiert.Nicht alle Byte-Slices sind jedoch gültige Zeichenfolgen: Zeichenfolgen müssen UTF-8-gültig sein.
    /// Während dieser Konvertierung ersetzt `from_utf8_lossy()` alle ungültigen UTF-8-Sequenzen durch [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]. Dies sieht folgendermaßen aus:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Wenn Sie sicher sind, dass das Byte-Slice UTF-8 gültig ist und Sie keinen Overhead für die Konvertierung verursachen möchten, gibt es eine unsichere Version dieser Funktion, [`from_utf8_unchecked`], die dasselbe Verhalten aufweist, jedoch die Überprüfungen überspringt.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Diese Funktion gibt einen [`Cow<'a, str>`] zurück.Wenn unser Byte-Slice UTF-8 ungültig ist, müssen wir die Ersatzzeichen einfügen, wodurch sich die Größe der Zeichenfolge ändert und daher ein `String` erforderlich ist.
    /// Wenn es jedoch bereits UTF-8 gültig ist, benötigen wir keine neue Zuordnung.
    /// Dieser Rückgabetyp ermöglicht es uns, beide Fälle zu behandeln.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // einige Bytes in einem vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Falsche Bytes:
    ///
    /// ```
    /// // einige ungültige Bytes
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekodieren Sie einen UTF-16-codierten vector `v` in einen `String` und geben Sie [`Err`] zurück, wenn `v` ungültige Daten enthält.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Dies erfolgt nicht über collect: : <Result<_, _>> () aus Leistungsgründen.
        // FIXME: Die Funktion kann beim Schließen von #48994 wieder vereinfacht werden.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dekodieren Sie ein UTF-16-codiertes Slice `v` in ein `String` und ersetzen Sie ungültige Daten durch [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Im Gegensatz zu [`from_utf8_lossy`], das ein [`Cow<'a, str>`] zurückgibt, gibt `from_utf16_lossy` ein `String` zurück, da für die Konvertierung von UTF-16 in UTF-8 eine Speicherzuweisung erforderlich ist.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Zerlegt einen `String` in seine Rohkomponenten.
    ///
    /// Gibt den Rohzeiger auf die zugrunde liegenden Daten, die Länge der Zeichenfolge (in Byte) und die zugewiesene Kapazität der Daten (in Byte) zurück.
    /// Dies sind dieselben Argumente in derselben Reihenfolge wie die Argumente für [`from_raw_parts`].
    ///
    /// Nach dem Aufruf dieser Funktion ist der Anrufer für den zuvor vom `String` verwalteten Speicher verantwortlich.
    /// Die einzige Möglichkeit, dies zu tun, besteht darin, den Rohzeiger, die Länge und die Kapazität mit der [`from_raw_parts`]-Funktion wieder in einen `String` zu konvertieren, sodass der Destruktor die Bereinigung durchführen kann.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Erstellt einen neuen `String` aus Länge, Kapazität und Zeiger.
    ///
    /// # Safety
    ///
    /// Dies ist aufgrund der Anzahl der nicht überprüften Invarianten sehr unsicher:
    ///
    /// * Der Speicher bei `buf` muss zuvor von demselben Allokator zugewiesen worden sein, den die Standardbibliothek verwendet, mit einer erforderlichen Ausrichtung von genau 1.
    /// * `length` muss kleiner oder gleich `capacity` sein.
    /// * `capacity` muss der richtige Wert sein.
    /// * Die ersten `length`-Bytes bei `buf` müssen UTF-8-gültig sein.
    ///
    /// Ein Verstoß gegen diese kann zu Problemen wie der Beschädigung der internen Datenstrukturen des Allokators führen.
    ///
    /// Das Eigentum an `buf` wird effektiv auf den `String` übertragen, der dann den Speicherinhalt, auf den der Zeiger nach Belieben zeigt, freigeben, neu zuweisen oder ändern kann.
    /// Stellen Sie sicher, dass nach dem Aufrufen dieser Funktion nichts anderes den Zeiger verwendet.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Aktualisieren Sie dies, wenn vec_into_raw_parts stabilisiert ist.
    ///     // Verhindern Sie, dass die Daten des Strings automatisch gelöscht werden
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Konvertiert einen vector von Bytes in einen `String`, ohne zu überprüfen, ob die Zeichenfolge gültiges UTF-8 enthält.
    ///
    /// Weitere Informationen finden Sie in der sicheren Version [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher, da nicht überprüft wird, ob die an sie übergebenen Bytes UTF-8 gültig sind.
    /// Wenn diese Einschränkung verletzt wird, kann dies zu Problemen mit der Speichersicherheit bei future-Benutzern des `String` führen, da der Rest der Standardbibliothek davon ausgeht, dass "String" für UTF-8 gültig sind.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // einige Bytes in einem vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Konvertiert einen `String` in ein Byte vector.
    ///
    /// Dies verbraucht den `String`, sodass wir seinen Inhalt nicht kopieren müssen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extrahiert ein String-Slice, das das gesamte `String` enthält.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Konvertiert ein `String` in ein veränderbares String-Slice.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Hängt ein bestimmtes String-Slice an das Ende dieses `String` an.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Gibt die Kapazität dieses Strings in Bytes zurück.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Stellt sicher, dass die Kapazität dieses "Strings" mindestens `additional` Bytes größer als seine Länge ist.
    ///
    /// Die Kapazität kann bei Bedarf um mehr als `additional` Byte erhöht werden, um häufige Neuzuweisungen zu verhindern.
    ///
    ///
    /// Wenn Sie dieses "at least"-Verhalten nicht möchten, lesen Sie die [`reserve_exact`]-Methode.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität [`usize`] überläuft.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dies erhöht möglicherweise nicht die Kapazität:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hat jetzt eine Länge von 2 und eine Kapazität von 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Da wir bereits eine zusätzliche Kapazität von 8 haben, nennen wir dies ...
    /// s.reserve(8);
    ///
    /// // ... nimmt eigentlich nicht zu.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Stellt sicher, dass die Kapazität dieses "Strings" `additional` Bytes größer als seine Länge ist.
    ///
    /// Erwägen Sie die Verwendung der [`reserve`]-Methode, es sei denn, Sie wissen es absolut besser als der Allokator.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `usize` überläuft.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dies erhöht möglicherweise nicht die Kapazität:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hat jetzt eine Länge von 2 und eine Kapazität von 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Da wir bereits eine zusätzliche Kapazität von 8 haben, nennen wir dies ...
    /// s.reserve_exact(8);
    ///
    /// // ... nimmt eigentlich nicht zu.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Versucht, Kapazität für mindestens `additional` mehr Elemente zu reservieren, die in das angegebene `String` eingefügt werden sollen.
    /// Die Sammlung kann mehr Platz reservieren, um häufige Neuzuweisungen zu vermeiden.
    /// Nach dem Aufruf von `reserve` ist die Kapazität größer oder gleich `self.len() + additional`.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// # Errors
    ///
    /// Wenn die Kapazität überläuft oder der Allokator einen Fehler meldet, wird ein Fehler zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reservieren Sie den Speicher vorab und beenden Sie ihn, wenn wir nicht können
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Jetzt wissen wir, dass dies mitten in unserer komplexen Arbeit nicht OOM sein kann
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Versucht, die Mindestkapazität für genau `additional` mehr Elemente zu reservieren, die in das angegebene `String` eingefügt werden sollen.
    ///
    /// Nach dem Aufruf von `reserve_exact` ist die Kapazität größer oder gleich `self.len() + additional`.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// Beachten Sie, dass der Allokator der Sammlung möglicherweise mehr Speicherplatz zur Verfügung stellt, als er anfordert.
    /// Daher kann nicht davon ausgegangen werden, dass die Kapazität genau minimal ist.
    /// Bevorzugen Sie `reserve`, wenn future-Insertionen erwartet werden.
    ///
    /// # Errors
    ///
    /// Wenn die Kapazität überläuft oder der Allokator einen Fehler meldet, wird ein Fehler zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reservieren Sie den Speicher vorab und beenden Sie ihn, wenn wir nicht können
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Jetzt wissen wir, dass dies mitten in unserer komplexen Arbeit nicht OOM sein kann
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Verkleinert die Kapazität dieses `String` entsprechend seiner Länge.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Verkleinert die Kapazität dieses `String` mit einer Untergrenze.
    ///
    /// Die Kapazität bleibt mindestens so groß wie die Länge und der gelieferte Wert.
    ///
    ///
    /// Wenn die aktuelle Kapazität unter der Untergrenze liegt, ist dies ein No-Op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Hängt das angegebene [`char`] an das Ende dieses `String` an.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Gibt ein Byte-Slice des Inhalts dieses String zurück.
    ///
    /// Die Umkehrung dieser Methode ist [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Verkürzt diesen `String` auf die angegebene Länge.
    ///
    /// Wenn `new_len` größer als die aktuelle Länge der Zeichenfolge ist, hat dies keine Auswirkung.
    ///
    ///
    /// Beachten Sie, dass diese Methode keine Auswirkungen auf die zugewiesene Kapazität der Zeichenfolge hat
    ///
    /// # Panics
    ///
    /// Panics, wenn `new_len` nicht an einer [`char`]-Grenze liegt.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Entfernt das letzte Zeichen aus dem Zeichenfolgenpuffer und gibt es zurück.
    ///
    /// Gibt [`None`] zurück, wenn dieses `String` leer ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Entfernt einen [`char`] von diesem `String` an einer Byteposition und gibt ihn zurück.
    ///
    /// Dies ist eine *O*(*n*)-Operation, da jedes Element im Puffer kopiert werden muss.
    ///
    /// # Panics
    ///
    /// Panics, wenn `idx` größer oder gleich der Länge des Strings ist oder wenn es nicht an einer [`char`]-Grenze liegt.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Entfernen Sie alle Übereinstimmungen des Musters `pat` im `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Übereinstimmungen werden iterativ erkannt und entfernt. In Fällen, in denen sich Muster überlappen, wird nur das erste Muster entfernt:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SICHERHEIT: Start und Ende befinden sich an den utf8-Bytegrenzen pro
        // die Searcher-Dokumente
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Behält nur die vom Prädikat angegebenen Zeichen bei.
    ///
    /// Mit anderen Worten, entfernen Sie alle Zeichen `c`, sodass `f(c)` `false` zurückgibt.
    /// Diese Methode funktioniert an Ort und Stelle und besucht jedes Zeichen genau einmal in der ursprünglichen Reihenfolge und behält die Reihenfolge der beibehaltenen Zeichen bei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Die genaue Reihenfolge kann nützlich sein, um den externen Status wie einen Index zu verfolgen.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Zeigen Sie mit idx auf das nächste Zeichen
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Fügt an einer Byteposition ein Zeichen in dieses `String` ein.
    ///
    /// Dies ist eine *O*(*n*)-Operation, da jedes Element im Puffer kopiert werden muss.
    ///
    /// # Panics
    ///
    /// Panics, wenn `idx` größer als die Länge des Strings ist oder wenn es nicht an einer [`char`]-Grenze liegt.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Fügt an einer Byteposition ein String-Slice in dieses `String` ein.
    ///
    /// Dies ist eine *O*(*n*)-Operation, da jedes Element im Puffer kopiert werden muss.
    ///
    /// # Panics
    ///
    /// Panics, wenn `idx` größer als die Länge des Strings ist oder wenn es nicht an einer [`char`]-Grenze liegt.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Gibt einen veränderlichen Verweis auf den Inhalt dieses `String` zurück.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher, da nicht überprüft wird, ob die an sie übergebenen Bytes UTF-8 gültig sind.
    /// Wenn diese Einschränkung verletzt wird, kann dies zu Problemen mit der Speichersicherheit bei future-Benutzern des `String` führen, da der Rest der Standardbibliothek davon ausgeht, dass "String" für UTF-8 gültig sind.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Gibt die Länge dieses `String` in Bytes zurück, nicht in [`char`] oder Graphemen.
    /// Mit anderen Worten, es ist möglicherweise nicht das, was ein Mensch für die Länge der Zeichenfolge hält.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Gibt `true` zurück, wenn dieser `String` eine Länge von Null hat, andernfalls `false`.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Teilt die Zeichenfolge am angegebenen Byte-Index in zwei Teile.
    ///
    /// Gibt einen neu zugewiesenen `String` zurück.
    /// `self` enthält Bytes `[0, at)` und das zurückgegebene `String` enthält Bytes `[at, len)`.
    /// `at` muss sich an der Grenze eines UTF-8-Codepunkts befinden.
    ///
    /// Beachten Sie, dass sich die Kapazität von `self` nicht ändert.
    ///
    /// # Panics
    ///
    /// Panics, wenn sich `at` nicht an einer `UTF-8`-Codepunktgrenze befindet oder jenseits des letzten Codepunkts der Zeichenfolge liegt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Schneidet diesen `String` ab und entfernt alle Inhalte.
    ///
    /// Dies bedeutet zwar, dass der `String` eine Länge von Null hat, seine Kapazität jedoch nicht berührt.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Erstellt einen Drainage-Iterator, der den angegebenen Bereich im `String` entfernt und den entfernten `chars` ergibt.
    ///
    ///
    /// Note: Der Elementbereich wird entfernt, auch wenn der Iterator erst am Ende verbraucht wird.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Start-oder Endpunkt nicht auf einer [`char`]-Grenze liegt oder wenn sie außerhalb der Grenzen liegen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Entfernen Sie den Bereich bis zum β aus der Zeichenfolge
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ein voller Bereich löscht die Zeichenfolge
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Speichersicherheit
        //
        // Die String-Version von Drain weist nicht die Speichersicherheitsprobleme der vector-Version auf.
        // Die Daten sind nur einfache Bytes.
        // Da die Entfernungsentfernung in Drop erfolgt, erfolgt die Entfernung nicht, wenn der Drain-Iterator durchgesickert ist.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Nehmen Sie zwei gleichzeitige Ausleihen heraus.
        // Auf den &mut-String wird erst zugegriffen, wenn die Iteration in Drop beendet ist.
        let self_ptr = self as *mut _;
        // SICHERHEIT: `slice::range` und `is_char_boundary` führen die entsprechenden Grenzwertprüfungen durch.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Entfernt den angegebenen Bereich in der Zeichenfolge und ersetzt ihn durch die angegebene Zeichenfolge.
    /// Die angegebene Zeichenfolge muss nicht dieselbe Länge wie der Bereich haben.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Start-oder Endpunkt nicht auf einer [`char`]-Grenze liegt oder wenn sie außerhalb der Grenzen liegen.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ersetzen Sie den Bereich bis zum β von der Zeichenfolge
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Speichersicherheit
        //
        // Replace_range weist nicht die Speichersicherheitsprobleme eines vector-Spleißes auf.
        // der vector-Version.Die Daten sind nur einfache Bytes.

        // WARNUNG: Das Inlinen dieser Variablen wäre (#81138) nicht einwandfrei
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // WARNUNG: Das Inlinen dieser Variablen wäre (#81138) nicht einwandfrei
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Die erneute Verwendung von `range` wäre nicht sinnvoll. (#81138) Wir gehen davon aus, dass die von `range` gemeldeten Grenzen gleich bleiben, aber eine kontroverse Implementierung kann sich zwischen den Aufrufen ändern
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konvertiert diesen `String` in eine [`Box`]`<`[`str`] `>`.
    ///
    /// Dadurch wird die überschüssige Kapazität verringert.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Gibt einen Teil der Bytes von [`u8`] zurück, die versucht wurden, in einen `String` zu konvertieren.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // einige ungültige Bytes in einem vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Gibt die Bytes zurück, die versucht wurden, in ein `String` zu konvertieren.
    ///
    /// Diese Methode wurde sorgfältig konstruiert, um eine Zuordnung zu vermeiden.
    /// Der Fehler wird verbraucht, indem die Bytes verschoben werden, sodass keine Kopie der Bytes erstellt werden muss.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // einige ungültige Bytes in einem vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Rufen Sie einen `Utf8Error` ab, um weitere Informationen zum Konvertierungsfehler zu erhalten.
    ///
    /// Der von [`std::str`] bereitgestellte [`Utf8Error`]-Typ stellt einen Fehler dar, der beim Konvertieren eines Slice von [`u8`] s in einen [`&str`] auftreten kann.
    /// In diesem Sinne ist es ein Analogon zu `FromUtf8Error`.
    /// Weitere Informationen zur Verwendung finden Sie in der Dokumentation.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // einige ungültige Bytes in einem vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // Das erste Byte ist hier ungültig
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Da wir über `String`s iterieren, können wir mindestens eine Zuordnung vermeiden, indem wir den ersten String vom Iterator abrufen und alle nachfolgenden Strings an ihn anhängen.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Da wir über CoWs iterieren, können wir (potentially) mindestens eine Zuordnung vermeiden, indem wir das erste Element abrufen und alle nachfolgenden Elemente an dieses anhängen.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Ein praktisches Gerät, das an das Gerät für `&str` delegiert.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Erstellt ein leeres `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementiert den `+`-Operator zum Verketten von zwei Zeichenfolgen.
///
/// Dadurch wird der `String` auf der linken Seite verbraucht und sein Puffer wird wiederverwendet (ggf. vergrößert).
/// Dies geschieht, um zu vermeiden, dass bei jedem Vorgang ein neues `String` zugewiesen und der gesamte Inhalt kopiert wird. Dies würde zu einer Laufzeit von *O*(*n*^ 2) führen, wenn eine *n*-Byte-Zeichenfolge durch wiederholte Verkettung erstellt wird.
///
///
/// Die Saite auf der rechten Seite ist nur ausgeliehen;Der Inhalt wird in das zurückgegebene `String` kopiert.
///
/// # Examples
///
/// Das Verketten von zwei `Strings` nimmt den ersten nach Wert und leiht den zweiten aus:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` wird verschoben und kann hier nicht mehr verwendet werden.
/// ```
///
/// Wenn Sie das erste `String` weiterhin verwenden möchten, können Sie es klonen und stattdessen an den Klon anhängen:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ist hier noch gültig.
/// ```
///
/// Das Verketten von `&str`-Slices kann durch Konvertieren des ersten in einen `String` erfolgen:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementiert den `+=`-Operator zum Anhängen an einen `String`.
///
/// Dies hat das gleiche Verhalten wie die [`push_str`][String::push_str]-Methode.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Ein Typalias für [`Infallible`].
///
/// Dieser Alias ist aus Gründen der Abwärtskompatibilität vorhanden und wird möglicherweise nicht mehr unterstützt.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Ein trait zum Konvertieren eines Werts in einen `String`.
///
/// Dieser trait wird automatisch für jeden Typ implementiert, der den [`Display`] trait implementiert.
/// Daher sollte `ToString` nicht direkt implementiert werden:
/// [`Display`] sollte stattdessen implementiert werden, und Sie erhalten die `ToString`-Implementierung kostenlos.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konvertiert den angegebenen Wert in einen `String`.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// In dieser Implementierung gibt die `to_string`-Methode panics einen Fehler zurück, wenn die `Display`-Implementierung einen Fehler zurückgibt.
/// Dies weist auf eine falsche `Display`-Implementierung hin, da `fmt::Write for String` selbst niemals einen Fehler zurückgibt.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Eine gängige Richtlinie besteht darin, generische Funktionen nicht zu integrieren.
    // Das Entfernen von `#[inline]` aus dieser Methode führt jedoch zu nicht zu vernachlässigenden Regressionen.
    // Siehe <https://github.com/rust-lang/rust/pull/74852>, den letzten Versuch, es zu entfernen.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Konvertiert einen `&mut str` in einen `String`.
    ///
    /// Das Ergebnis wird auf dem Heap zugeordnet.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: Test zieht in libstd, was hier Fehler verursacht
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konvertiert das angegebene Boxed `str`-Slice in ein `String`.
    /// Es ist bemerkenswert, dass das `str`-Slice im Besitz ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konvertiert das angegebene `String` in ein `str`-Slice mit Box, dessen Eigentümer es ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Konvertiert ein String-Slice in eine geliehene Variante.
    /// Es wird keine Heap-Zuordnung durchgeführt und die Zeichenfolge wird nicht kopiert.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konvertiert einen String in eine eigene Variante.
    /// Es wird keine Heap-Zuordnung durchgeführt und die Zeichenfolge wird nicht kopiert.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konvertiert eine String-Referenz in eine geliehene Variante.
    /// Es wird keine Heap-Zuordnung durchgeführt und die Zeichenfolge wird nicht kopiert.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konvertiert das angegebene `String` in ein vector `Vec`, das Werte vom Typ `u8` enthält.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Ein leerer Iterator für `String`.
///
/// Diese Struktur wird von der [`drain`]-Methode unter [`String`] erstellt.
/// Weitere Informationen finden Sie in der Dokumentation.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Wird im Destruktor als&'mut mut String verwendet
    string: *mut String,
    /// Beginn des zu entfernenden Teils
    start: usize,
    /// Ende des zu entfernenden Teils
    end: usize,
    /// Aktueller verbleibender Bereich zum Entfernen
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Verwenden Sie Vec::drain.
            // "Reaffirm" Die Grenzen werden überprüft, um zu verhindern, dass der panic-Code erneut eingefügt wird.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Gibt die verbleibende (Unter-) Zeichenfolge dieses Iterators als Slice zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: Kommentar AsRef impliziert unten bei der Stabilisierung.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Kommentar bei der Stabilisierung von `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>für Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> für Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}