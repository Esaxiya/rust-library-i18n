#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Der Inhalt des neuen Speichers ist nicht initialisiert.
    Uninitialized,
    /// Der neue Speicher wird garantiert auf Null gesetzt.
    Zeroed,
}

/// Ein Low-Level-Dienstprogramm zum ergonomischeren Zuweisen, Neuzuweisen und Freigeben eines Speicherpuffers auf dem Heap, ohne sich um alle Eckfälle kümmern zu müssen.
///
/// Dieser Typ eignet sich hervorragend zum Erstellen eigener Datenstrukturen wie Vec und VecDeque.
/// Bestimmtes:
///
/// * Produziert `Unique::dangling()` auf Typen mit der Größe Null.
/// * Erzeugt `Unique::dangling()` bei Zuweisungen mit der Länge Null.
/// * Vermeidet das Freigeben von `Unique::dangling()`.
/// * Fängt alle Überläufe bei Kapazitätsberechnungen ab (befördert sie zu "capacity overflow" panics).
/// * Schützt vor 32-Bit-Systemen, die mehr als isize::MAX-Bytes zuweisen.
/// * Schützt vor Überlaufen Ihrer Länge.
/// * Ruft `handle_alloc_error` für fehlbare Zuordnungen auf.
/// * Enthält einen `ptr::Unique` und bietet dem Benutzer somit alle damit verbundenen Vorteile.
/// * Verwendet den vom Allokator zurückgegebenen Überschuss, um die größte verfügbare Kapazität zu nutzen.
///
/// Dieser Typ überprüft den von ihm verwalteten Speicher ohnehin nicht.Wenn es gelöscht wird, wird es seinen Speicher freigeben, aber es wird nicht versuchen, seinen Inhalt zu löschen.
/// Es ist Sache des Benutzers von `RawVec`, die tatsächlichen Dinge zu handhaben, die in einem `RawVec`*gespeichert* sind.
///
/// Beachten Sie, dass der Überschuss eines Typs mit der Größe Null immer unendlich ist, sodass `capacity()` immer `usize::MAX` zurückgibt.
/// Dies bedeutet, dass Sie vorsichtig sein müssen, wenn Sie diesen Typ mit einem `Box<[T]>` umrunden, da `capacity()` die Länge nicht liefert.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dies liegt daran, dass `#[unstable]` `const fn`s nicht mit `min_const_fn` übereinstimmen müssen und daher auch nicht in`min_const_fn`s aufgerufen werden können.
    ///
    /// Wenn Sie `RawVec<T>::new` oder Abhängigkeiten ändern, achten Sie darauf, dass Sie nichts einführen, was `min_const_fn` wirklich verletzen würde.
    ///
    /// NOTE: Wir könnten diesen Hack vermeiden und die Konformität mit einem `#[rustc_force_min_const_fn]`-Attribut überprüfen, das die Konformität mit `min_const_fn` erfordert, aber nicht unbedingt den Aufruf in `stable(...) const fn`/Benutzercode zulässt, der `foo` nicht aktiviert, wenn `#[rustc_const_unstable(feature = "foo", issue = "01234")]` vorhanden ist.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Erstellt das größtmögliche `RawVec` (auf dem Systemheap) ohne Zuordnung.
    /// Wenn `T` eine positive Größe hat, ergibt dies einen `RawVec` mit einer Kapazität von `0`.
    /// Wenn `T` die Größe Null hat, wird ein `RawVec` mit einer Kapazität von `usize::MAX` erstellt.
    /// Nützlich für die Implementierung einer verzögerten Zuweisung.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Erstellt einen `RawVec` (auf dem Systemheap) mit genau den Kapazitäts-und Ausrichtungsanforderungen für einen `[T; capacity]`.
    /// Dies entspricht dem Aufruf von `RawVec::new`, wenn `capacity` `0` oder `T` die Größe Null hat.
    /// Beachten Sie, dass wenn `T` die Größe Null hat, dies bedeutet, dass Sie *nicht* einen `RawVec` mit der angeforderten Kapazität erhalten.
    ///
    /// # Panics
    ///
    /// Panics, wenn die angeforderte Kapazität `isize::MAX` Bytes überschreitet.
    ///
    /// # Aborts
    ///
    /// Abbruch bei OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Wie `with_capacity`, garantiert jedoch, dass der Puffer auf Null gesetzt ist.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstituiert einen `RawVec` aus einem Zeiger und einer Kapazität.
    ///
    /// # Safety
    ///
    /// Der `ptr` muss (auf dem Systemheap) und mit dem angegebenen `capacity` zugewiesen werden.
    /// Der `capacity` darf `isize::MAX` für Größentypen nicht überschreiten.(nur ein Problem bei 32-Bit-Systemen).
    /// ZST vectors kann eine Kapazität von bis zu `usize::MAX` haben.
    /// Wenn der `ptr` und der `capacity` von einem `RawVec` stammen, ist dies garantiert.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Winzige Vecs sind dumm.Überspringen zu:
    // - 8, wenn die Elementgröße 1 ist, da Heap-Allokatoren wahrscheinlich eine Anforderung von weniger als 8 Bytes auf mindestens 8 Bytes aufrunden.
    //
    // - 4, wenn die Elemente mittelgroß sind (<=1 KiB).
    // - Andernfalls vermeiden Sie zu viel Platz für sehr kurze Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Wie `new`, jedoch über die Auswahl des Allokators für den zurückgegebenen `RawVec` parametrisiert.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` bedeutet "unallocated".Typen mit der Größe Null werden ignoriert.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Wie `with_capacity`, jedoch über die Auswahl des Allokators für den zurückgegebenen `RawVec` parametrisiert.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Wie `with_capacity_zeroed`, jedoch über die Auswahl des Allokators für den zurückgegebenen `RawVec` parametrisiert.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konvertiert einen `Box<[T]>` in einen `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konvertiert den gesamten Puffer mit dem angegebenen `len` in `Box<[MaybeUninit<T>]>`.
    ///
    /// Beachten Sie, dass dadurch alle möglicherweise vorgenommenen `cap`-Änderungen korrekt wiederhergestellt werden.(Einzelheiten finden Sie in der Beschreibung des Typs.)
    ///
    /// # Safety
    ///
    /// * `len` muss größer oder gleich der zuletzt angeforderten Kapazität sein, und
    /// * `len` muss kleiner oder gleich `self.capacity()` sein.
    ///
    /// Beachten Sie, dass die angeforderte Kapazität und `self.capacity()` unterschiedlich sein können, da ein Allokator einen größeren Speicherblock als angefordert insgesamt zuordnen und zurückgeben kann.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Überprüfen Sie die Hälfte der Sicherheitsanforderungen (wir können die andere Hälfte nicht überprüfen).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Wir vermeiden hier `unwrap_or_else`, weil es die Menge des erzeugten LLVM-IR aufbläht.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstituiert einen `RawVec` aus einem Zeiger, einer Kapazität und einem Allokator.
    ///
    /// # Safety
    ///
    /// Der `ptr` muss (über den angegebenen Allokator `alloc`) und mit dem angegebenen `capacity` zugewiesen werden.
    /// Der `capacity` darf `isize::MAX` für Größentypen nicht überschreiten.
    /// (nur ein Problem bei 32-Bit-Systemen).
    /// ZST vectors kann eine Kapazität von bis zu `usize::MAX` haben.
    /// Wenn `ptr` und `capacity` von einem über `alloc` erstellten `RawVec` stammen, ist dies garantiert.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ruft einen Rohzeiger auf den Beginn der Zuordnung ab.
    /// Beachten Sie, dass dies `Unique::dangling()` ist, wenn `capacity == 0` oder `T` die Größe Null hat.
    /// Im ersteren Fall müssen Sie vorsichtig sein.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ruft die Kapazität der Zuordnung ab.
    ///
    /// Dies ist immer `usize::MAX`, wenn `T` die Größe Null hat.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Gibt einen gemeinsamen Verweis auf den Allokator zurück, der diesen `RawVec` unterstützt.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Wir haben einen zugewiesenen Speicherblock, sodass wir Laufzeitprüfungen umgehen können, um unser aktuelles Layout zu erhalten.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Stellt sicher, dass der Puffer mindestens genügend Speicherplatz für `len + additional`-Elemente enthält.
    /// Wenn es nicht bereits über genügend Kapazität verfügt, wird genügend Speicherplatz sowie komfortabler Speicherplatz neu zugewiesen, um ein amortisiertes *O*(1)-Verhalten zu erzielen.
    ///
    /// Wird dieses Verhalten einschränken, wenn es sich unnötig zu panic führen würde.
    ///
    /// Wenn `len` `self.capacity()` überschreitet, kann dies möglicherweise nicht dazu führen, dass der angeforderte Speicherplatz tatsächlich zugewiesen wird.
    /// Dies ist nicht wirklich unsicher, aber der unsichere Code, den *Sie* schreiben und der sich auf das Verhalten dieser Funktion stützt, kann fehlerhaft sein.
    ///
    /// Dies ist ideal für die Implementierung eines Bulk-Push-Vorgangs wie `extend`.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `isize::MAX` Bytes überschreitet.
    ///
    /// # Aborts
    ///
    /// Abbruch bei OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Die Reserve wäre abgebrochen oder in Panik geraten, wenn die Länge `isize::MAX` überschritten hätte, sodass dies jetzt sicher deaktiviert werden kann.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Entspricht `reserve`, gibt jedoch Fehler zurück, anstatt in Panik zu geraten oder abzubrechen.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Stellt sicher, dass der Puffer mindestens genügend Speicherplatz für `len + additional`-Elemente enthält.
    /// Wenn dies noch nicht geschehen ist, wird die minimal erforderliche Speichermenge neu zugewiesen.
    /// Im Allgemeinen ist dies genau die erforderliche Speichermenge, aber im Prinzip kann der Allokator mehr zurückgeben, als wir verlangt haben.
    ///
    ///
    /// Wenn `len` `self.capacity()` überschreitet, kann dies möglicherweise nicht dazu führen, dass der angeforderte Speicherplatz tatsächlich zugewiesen wird.
    /// Dies ist nicht wirklich unsicher, aber der unsichere Code, den *Sie* schreiben und der sich auf das Verhalten dieser Funktion stützt, kann fehlerhaft sein.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `isize::MAX` Bytes überschreitet.
    ///
    /// # Aborts
    ///
    /// Abbruch bei OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Entspricht `reserve_exact`, gibt jedoch Fehler zurück, anstatt in Panik zu geraten oder abzubrechen.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Verkleinert die Zuordnung auf den angegebenen Betrag.
    /// Wenn der angegebene Betrag 0 ist, wird die Zuordnung tatsächlich vollständig aufgehoben.
    ///
    /// # Panics
    ///
    /// Panics, wenn die angegebene Menge *größer* als die aktuelle Kapazität ist.
    ///
    /// # Aborts
    ///
    /// Abbruch bei OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Gibt zurück, wenn der Puffer wachsen muss, um die erforderliche zusätzliche Kapazität zu erfüllen.
    /// Wird hauptsächlich verwendet, um Inlining-Reserveaufrufe ohne Inlining `grow` zu ermöglichen.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Diese Methode wird normalerweise viele Male instanziiert.Wir möchten, dass es so klein wie möglich ist, um die Kompilierungszeiten zu verbessern.
    // Wir möchten aber auch, dass möglichst viele Inhalte statisch berechenbar sind, damit der generierte Code schneller ausgeführt wird.
    // Daher wurde diese Methode sorgfältig geschrieben, damit sich der gesamte Code, der von `T` abhängt, darin befindet, während sich so viel Code wie möglich, der nicht von `T` abhängt, in Funktionen befindet, die über `T` nicht generisch sind.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Dies wird durch die aufrufenden Kontexte sichergestellt.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Da wir eine Kapazität von `usize::MAX` zurückgeben, wenn `elem_size` ist
            // 0, hierher zu kommen bedeutet zwangsläufig, dass der `RawVec` überfüllt ist.
            return Err(CapacityOverflow);
        }

        // Leider können wir nichts gegen diese Überprüfungen unternehmen.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Dies garantiert ein exponentielles Wachstum.
        // Die Verdoppelung kann nicht überlaufen, da `cap <= isize::MAX` und der Typ von `cap` `usize` ist.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ist nicht generisch über `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Die Einschränkungen für diese Methode sind ähnlich wie für `grow_amortized`, aber diese Methode wird normalerweise seltener instanziiert, sodass sie weniger kritisch ist.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Da wir eine Kapazität von `usize::MAX` zurückgeben, wenn die Typgröße ist
            // 0, hierher zu kommen bedeutet zwangsläufig, dass der `RawVec` überfüllt ist.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ist nicht generisch über `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Diese Funktion befindet sich außerhalb von `RawVec`, um die Kompilierungszeiten zu minimieren.Siehe den Kommentar über `RawVec::grow_amortized` für Details.
// (Der `A`-Parameter ist nicht signifikant, da die Anzahl der verschiedenen `A`-Typen in der Praxis viel geringer ist als die Anzahl der `T`-Typen.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Suchen Sie hier nach dem Fehler, um die Größe von `RawVec::grow_*` zu minimieren.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Der Allokator prüft die Ausrichtungsgleichheit
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Gibt den Speicher des `RawVec` frei *, ohne* zu versuchen, seinen Inhalt zu löschen.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Zentrale Funktion zur Behandlung von Reservefehlern.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Wir müssen Folgendes garantieren:
// * Wir weisen niemals Objekte mit `> isize::MAX`-Byte-Größe zu.
// * Wir überlaufen `usize::MAX` nicht und weisen tatsächlich zu wenig zu.
//
// Bei 64-Bit müssen wir nur auf Überlauf prüfen, da der Versuch, `> isize::MAX`-Bytes zuzuweisen, sicherlich fehlschlägt.
// Bei 32-Bit und 16-Bit müssen wir hierfür einen zusätzlichen Schutz hinzufügen, falls wir auf einer Plattform laufen, die alle 4 GB im Benutzerraum nutzen kann, z. B. PAE oder x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Eine zentrale Funktion, die für die Meldung von Kapazitätsüberläufen verantwortlich ist.
// Dadurch wird sichergestellt, dass die Codegenerierung für diese panics minimal ist, da es nur einen Speicherort gibt, an dem panics und nicht ein Bündel im gesamten Modul vorhanden ist.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}