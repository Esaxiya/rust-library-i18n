//! Ein Zeigertyp für die Heap-Zuordnung.
//!
//! [`Box<T>`], Wird gelegentlich als 'box' bezeichnet und bietet die einfachste Form der Heap-Zuweisung in Rust.Boxen stellen das Eigentum für diese Zuordnung bereit und löschen ihren Inhalt, wenn sie den Gültigkeitsbereich verlassen.Boxen stellen außerdem sicher, dass sie niemals mehr als `isize::MAX`-Bytes zuweisen.
//!
//! # Examples
//!
//! Verschieben Sie einen Wert vom Stapel auf den Heap, indem Sie ein [`Box`] erstellen:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Verschieben Sie einen Wert von einem [`Box`] um [dereferencing] zurück auf den Stapel:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Erstellen einer rekursiven Datenstruktur:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Dies druckt `Cons (1, Cons(2, Nil))`.
//!
//! Rekursive Strukturen müssen eingerahmt werden, denn wenn die Definition von `Cons` folgendermaßen aussieht:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Es würde nicht funktionieren.Dies liegt daran, dass die Größe eines `List` davon abhängt, wie viele Elemente in der Liste enthalten sind. Daher wissen wir nicht, wie viel Speicher für einen `Cons` reserviert werden soll.Durch die Einführung eines [`Box<T>`] mit einer definierten Größe wissen wir, wie groß `Cons` sein muss.
//!
//! # Speicherlayout
//!
//! Bei Werten ungleich Null verwendet ein [`Box`] den [`Global`]-Allokator für seine Zuordnung.Es ist gültig, beide Wege zwischen einem [`Box`] und einem mit dem [`Global`]-Allokator zugewiesenen Rohzeiger zu konvertieren, da der mit dem Allokator verwendete [`Layout`] für den Typ korrekt ist.
//!
//! Genauer gesagt kann ein `value:*mut T`, der mit dem [`Global`]-Allokator mit `Layout::for_value(&* value)` zugewiesen wurde, mit [`Box::<T>::from_raw(value)`] in eine Box konvertiert werden.
//! Umgekehrt kann der Speicher, der einen von [`Box::<T>::into_raw`] erhaltenen `value:*mut T` unterstützt, unter Verwendung des [`Global`]-Allokators mit [`Layout::for_value(&* value)`] freigegeben werden.
//!
//! Für Werte mit der Größe Null muss der `Box`-Zeiger für Lese-und Schreibvorgänge immer noch [valid] sein und ausreichend ausgerichtet sein.
//! Insbesondere das Umwandeln eines ausgerichteten Ganzzahlliteral ungleich Null in einen Rohzeiger erzeugt einen gültigen Zeiger, aber ein Zeiger, der auf einen zuvor zugewiesenen Speicher zeigt, der seitdem freigegeben wurde, ist ungültig.
//! Die empfohlene Methode zum Erstellen einer Box für eine ZST, wenn `Box::new` nicht verwendet werden kann, ist die Verwendung von [`ptr::NonNull::dangling`].
//!
//! Solange `T: Sized` vorhanden ist, wird ein `Box<T>` garantiert als einzelner Zeiger dargestellt und ist auch ABI-kompatibel mit C-Zeigern (dh dem C-Typ `T*`).
//! Dies bedeutet, dass Sie, wenn Sie externe "C" Rust-Funktionen haben, die von C aufgerufen werden, diese Rust-Funktionen mithilfe von `Box<T>`-Typen definieren und `T*` als entsprechenden Typ auf der C-Seite verwenden können.
//! Betrachten Sie als Beispiel diesen C-Header, der Funktionen deklariert, die eine Art `Foo`-Wert erstellen und zerstören:
//!
//! ```c
//! /* C Header */
//!
//! /* Gibt das Eigentum an den Anrufer zurück */
//! struct Foo* foo_new(void);
//!
//! /* Übernimmt dem Anrufer das Eigentum;no-op beim Aufruf mit NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Diese beiden Funktionen können in Rust wie folgt implementiert werden.Hier wird der `struct Foo*`-Typ von C in `Box<Foo>` übersetzt, wodurch die Eigentumsbeschränkungen erfasst werden.
//! Beachten Sie auch, dass das nullfähige Argument für `foo_delete` in Rust als `Option<Box<Foo>>` dargestellt wird, da `Box<Foo>` nicht null sein kann.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Obwohl `Box<T>` dieselbe Darstellung und denselben C ABI wie ein C-Zeiger hat, bedeutet dies nicht, dass Sie einen beliebigen `T*` in einen `Box<T>` konvertieren können und erwarten, dass die Dinge funktionieren.
//! `Box<T>` Werte sind immer vollständig ausgerichtete Zeiger ungleich Null.Darüber hinaus versucht der Destruktor für `Box<T>`, den Wert mit dem globalen Allokator freizugeben.Im Allgemeinen wird empfohlen, `Box<T>` nur für Zeiger zu verwenden, die vom globalen Allokator stammen.
//!
//! **Wichtig.** Zumindest derzeit sollten Sie die Verwendung von `Box<T>`-Typen für Funktionen vermeiden, die in C definiert, aber von Rust aufgerufen werden.In diesen Fällen sollten Sie die C-Typen so genau wie möglich direkt spiegeln.
//! Die Verwendung von Typen wie `Box<T>`, bei denen die C-Definition nur `T*` verwendet, kann zu undefiniertem Verhalten führen, wie in [rust-lang/unsafe-code-guidelines#198][ucg#198] beschrieben.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Ein Zeigertyp für die Heap-Zuordnung.
///
/// Weitere Informationen finden Sie im [module-level documentation](../../std/boxed/index.html).
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Ordnet Speicher auf dem Heap zu und platziert dann `x` darin.
    ///
    /// Dies wird nicht zugeordnet, wenn `T` die Größe Null hat.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Erstellt eine neue Box mit nicht initialisiertem Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Erstellt ein neues `Box` mit nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Erstellt einen neuen `Pin<Box<T>>`.
    /// Wenn `T` `Unpin` nicht implementiert, wird `x` im Speicher fixiert und kann nicht verschoben werden.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Weist dem Heap Speicher zu, platziert `x` darin und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt
    ///
    ///
    /// Dies wird nicht zugeordnet, wenn `T` die Größe Null hat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Erstellt eine neue Box mit nicht initialisiertem Inhalt auf dem Heap und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Erstellt ein neues `Box` mit nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes auf dem Heap gefüllt ist
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Ordnet Speicher im angegebenen Allokator zu und platziert dann `x` darin.
    ///
    /// Dies wird nicht zugeordnet, wenn `T` die Größe Null hat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Weist dem angegebenen Allokator Speicher zu, platziert `x` darin und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt
    ///
    ///
    /// Dies wird nicht zugeordnet, wenn `T` die Größe Null hat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Erstellt eine neue Box mit nicht initialisiertem Inhalt im bereitgestellten Allokator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Bevorzugen Sie die Übereinstimmung gegenüber unwrap_or_else, da das Schließen manchmal nicht inlinierbar ist.
        // Das würde die Codegröße vergrößern.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Erstellt eine neue Box mit nicht initialisiertem Inhalt im bereitgestellten Allokator und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Erstellt ein neues `Box` mit nicht initialisiertem Inhalt, wobei der Speicher im bereitgestellten Allokator mit `0`-Bytes gefüllt wird.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Bevorzugen Sie die Übereinstimmung gegenüber unwrap_or_else, da das Schließen manchmal nicht inlinierbar ist.
        // Das würde die Codegröße vergrößern.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Erstellt ein neues `Box` mit nicht initialisiertem Inhalt, wobei der Speicher im bereitgestellten Allokator mit `0`-Bytes gefüllt ist und einen Fehler zurückgibt, wenn die Zuordnung fehlschlägt.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Erstellt einen neuen `Pin<Box<T, A>>`.
    /// Wenn `T` `Unpin` nicht implementiert, wird `x` im Speicher fixiert und kann nicht verschoben werden.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Konvertiert einen `Box<T>` in einen `Box<[T]>`
    ///
    /// Diese Konvertierung wird nicht auf dem Heap zugeordnet und erfolgt an Ort und Stelle.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Verbraucht den `Box` und gibt den umschlossenen Wert zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Erstellt ein neues Boxed Slice mit nicht initialisiertem Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Erstellt ein neues Boxed Slice mit nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Erstellt ein neues Box-Slice mit nicht initialisiertem Inhalt im bereitgestellten Allokator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Erstellt ein neues Boxed Slice mit nicht initialisiertem Inhalt im bereitgestellten Allokator, wobei der Speicher mit `0`-Bytes gefüllt ist.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Konvertiert in `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Wie bei [`MaybeUninit::assume_init`] muss der Anrufer sicherstellen, dass sich der Wert tatsächlich in einem initialisierten Zustand befindet.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, tritt sofort undefiniertes Verhalten auf.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Konvertiert in `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Wie bei [`MaybeUninit::assume_init`] muss der Aufrufer sicherstellen, dass sich die Werte tatsächlich in einem initialisierten Zustand befinden.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, tritt sofort undefiniertes Verhalten auf.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Konstruiert eine Box aus einem Rohzeiger.
    ///
    /// Nach dem Aufrufen dieser Funktion gehört der Rohzeiger dem resultierenden `Box`.
    /// Insbesondere ruft der `Box`-Destruktor den Destruktor von `T` auf und gibt den zugewiesenen Speicher frei.
    /// Damit dies sicher ist, muss der Speicher gemäß dem von `Box` verwendeten [memory layout] zugewiesen worden sein.
    ///
    ///
    /// # Safety
    ///
    /// Diese Funktion ist nicht sicher, da eine unsachgemäße Verwendung zu Speicherproblemen führen kann.
    /// Beispielsweise kann ein Double-Free auftreten, wenn die Funktion zweimal auf demselben Rohzeiger aufgerufen wird.
    ///
    /// Die Sicherheitsbedingungen sind im Abschnitt [memory layout] beschrieben.
    ///
    /// # Examples
    ///
    /// Erstellen Sie ein `Box` neu, das zuvor mit [`Box::into_raw`] in einen Rohzeiger konvertiert wurde:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Erstellen Sie manuell einen `Box` von Grund auf neu, indem Sie den globalen Allokator verwenden:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Im Allgemeinen ist .write erforderlich, um zu vermeiden, dass versucht wird, den vorherigen (uninitialized)-Inhalt von `ptr` zu zerstören, obwohl für dieses einfache Beispiel auch `*ptr = 5` funktioniert hätte.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Konstruiert eine Box aus einem Rohzeiger im angegebenen Allokator.
    ///
    /// Nach dem Aufrufen dieser Funktion gehört der Rohzeiger dem resultierenden `Box`.
    /// Insbesondere ruft der `Box`-Destruktor den Destruktor von `T` auf und gibt den zugewiesenen Speicher frei.
    /// Damit dies sicher ist, muss der Speicher gemäß dem von `Box` verwendeten [memory layout] zugewiesen worden sein.
    ///
    ///
    /// # Safety
    ///
    /// Diese Funktion ist nicht sicher, da eine unsachgemäße Verwendung zu Speicherproblemen führen kann.
    /// Beispielsweise kann ein Double-Free auftreten, wenn die Funktion zweimal auf demselben Rohzeiger aufgerufen wird.
    ///
    /// # Examples
    ///
    /// Erstellen Sie ein `Box` neu, das zuvor mit [`Box::into_raw_with_allocator`] in einen Rohzeiger konvertiert wurde:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Erstellen Sie manuell einen `Box` von Grund auf neu, indem Sie den Systemzuweiser verwenden:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Im Allgemeinen ist .write erforderlich, um zu vermeiden, dass versucht wird, den vorherigen (uninitialized)-Inhalt von `ptr` zu zerstören, obwohl für dieses einfache Beispiel auch `*ptr = 5` funktioniert hätte.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Verbraucht den `Box` und gibt einen umschlossenen Rohzeiger zurück.
    ///
    /// Der Zeiger ist richtig ausgerichtet und nicht null.
    ///
    /// Nach dem Aufruf dieser Funktion ist der Anrufer für den zuvor vom `Box` verwalteten Speicher verantwortlich.
    /// Insbesondere sollte der Anrufer `T` ordnungsgemäß zerstören und den Speicher freigeben, wobei der von `Box` verwendete [memory layout] zu berücksichtigen ist.
    /// Der einfachste Weg, dies zu tun, besteht darin, den Rohzeiger mit der [`Box::from_raw`]-Funktion wieder in einen `Box` zu konvertieren, damit der `Box`-Destruktor die Bereinigung durchführen kann.
    ///
    ///
    /// Note: Dies ist eine zugehörige Funktion, dh Sie müssen sie als `Box::into_raw(b)` anstelle von `b.into_raw()` aufrufen.
    /// Dies ist so, dass es keinen Konflikt mit einer Methode für den inneren Typ gibt.
    ///
    /// # Examples
    /// Konvertieren des Rohzeigers zurück in einen `Box` mit [`Box::from_raw`] zur automatischen Bereinigung:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Manuelle Bereinigung durch explizites Ausführen des Destruktors und Freigeben des Speichers:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Verbraucht den `Box` und gibt einen umschlossenen Rohzeiger und den Allokator zurück.
    ///
    /// Der Zeiger ist richtig ausgerichtet und nicht null.
    ///
    /// Nach dem Aufruf dieser Funktion ist der Anrufer für den zuvor vom `Box` verwalteten Speicher verantwortlich.
    /// Insbesondere sollte der Anrufer `T` ordnungsgemäß zerstören und den Speicher freigeben, wobei der von `Box` verwendete [memory layout] zu berücksichtigen ist.
    /// Der einfachste Weg, dies zu tun, besteht darin, den Rohzeiger mit der [`Box::from_raw_in`]-Funktion wieder in einen `Box` zu konvertieren, damit der `Box`-Destruktor die Bereinigung durchführen kann.
    ///
    ///
    /// Note: Dies ist eine zugehörige Funktion, dh Sie müssen sie als `Box::into_raw_with_allocator(b)` anstelle von `b.into_raw_with_allocator()` aufrufen.
    /// Dies ist so, dass es keinen Konflikt mit einer Methode für den inneren Typ gibt.
    ///
    /// # Examples
    /// Konvertieren des Rohzeigers zurück in einen `Box` mit [`Box::from_raw_in`] zur automatischen Bereinigung:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Manuelle Bereinigung durch explizites Ausführen des Destruktors und Freigeben des Speichers:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box wird von Stacked Borrows als "unique pointer" erkannt, ist jedoch intern ein Rohzeiger für das Typsystem.
        // Wenn Sie es direkt in einen Rohzeiger verwandeln, wird "releasing" nicht als eindeutiger Zeiger erkannt, um Alias-Rohzugriffe zu ermöglichen. Daher müssen alle Rohzeigermethoden `Box::leak` durchlaufen.
        //
        // Wenn Sie *das* in einen rohen Zeiger verwandeln, verhält es sich korrekt.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Gibt einen Verweis auf den zugrunde liegenden Allokator zurück.
    ///
    /// Note: Dies ist eine zugehörige Funktion, dh Sie müssen sie als `Box::allocator(&b)` anstelle von `b.allocator()` aufrufen.
    /// Dies ist so, dass es keinen Konflikt mit einer Methode für den inneren Typ gibt.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Verbraucht und leckt den `Box` und gibt eine veränderbare Referenz zurück. `&'a mut T`.
    /// Beachten Sie, dass der Typ `T` die gewählte Lebensdauer `'a` überleben muss.
    /// Wenn der Typ nur statische oder gar keine Referenzen enthält, kann dies als `'static` gewählt werden.
    ///
    /// Diese Funktion ist hauptsächlich für Daten nützlich, die für den Rest des Programmlebens gültig sind.
    /// Das Löschen der zurückgegebenen Referenz führt zu einem Speicherverlust.
    /// Wenn dies nicht akzeptabel ist, sollte die Referenz zuerst mit der [`Box::from_raw`]-Funktion umbrochen werden, die einen `Box` erzeugt.
    ///
    /// Dieser `Box` kann dann gelöscht werden, wodurch `T` ordnungsgemäß zerstört und der zugewiesene Speicher freigegeben wird.
    ///
    /// Note: Dies ist eine zugehörige Funktion, dh Sie müssen sie als `Box::leak(b)` anstelle von `b.leak()` aufrufen.
    /// Dies ist so, dass es keinen Konflikt mit einer Methode für den inneren Typ gibt.
    ///
    /// # Examples
    ///
    /// Einfache Verwendung:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Nicht dimensionierte Daten:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Konvertiert einen `Box<T>` in einen `Pin<Box<T>>`
    ///
    /// Diese Konvertierung wird nicht auf dem Heap zugeordnet und erfolgt an Ort und Stelle.
    ///
    /// Dies ist auch über [`From`] verfügbar.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Es ist nicht möglich, die Innenseiten eines `Pin<Box<T>>` zu verschieben oder zu ersetzen, wenn `T: !Unpin` vorhanden ist. Daher ist es sicher, ihn ohne zusätzliche Anforderungen direkt zu befestigen.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Nichts tun, Drop wird derzeit vom Compiler ausgeführt.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Erstellt ein `Box<T>` mit dem `Default`-Wert für T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Gibt eine neue Box mit einem `clone()` des Inhalts dieser Box zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Der Wert ist der gleiche
    /// assert_eq!(x, y);
    ///
    /// // Aber sie sind einzigartige Objekte
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Ordnen Sie den Speicher vorab zu, damit der geklonte Wert direkt geschrieben werden kann.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Kopiert den Inhalt der Quelle in `self`, ohne eine neue Zuordnung zu erstellen.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Der Wert ist der gleiche
    /// assert_eq!(x, y);
    ///
    /// // Und es erfolgte keine Zuordnung
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // Dadurch wird eine Kopie der Daten erstellt
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Konvertiert einen generischen Typ `T` in einen `Box<T>`
    ///
    /// Die Konvertierung wird auf dem Heap zugewiesen und `t` vom Stapel in diesen verschoben.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Konvertiert einen `Box<T>` in einen `Pin<Box<T>>`
    ///
    /// Diese Konvertierung wird nicht auf dem Heap zugeordnet und erfolgt an Ort und Stelle.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Konvertiert einen `&[T]` in einen `Box<[T]>`
    ///
    /// Diese Konvertierung wird auf dem Heap zugewiesen und führt eine Kopie von `slice` durch.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // Erstellen Sie ein&[u8], mit dem eine Box <[u8]> erstellt wird
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Konvertiert einen `&str` in einen `Box<str>`
    ///
    /// Diese Konvertierung wird auf dem Heap zugewiesen und führt eine Kopie von `s` durch.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Konvertiert einen `Box<str>` in einen `Box<[u8]>`
    /// Diese Konvertierung wird nicht auf dem Heap zugeordnet und erfolgt an Ort und Stelle.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // Erstellen Sie eine Box<str>Hiermit wird eine Box <[u8]> erstellt
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // Erstellen Sie ein&[u8], mit dem eine Box <[u8]> erstellt wird
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Konvertiert einen `[T; N]` in einen `Box<[T]>`
    /// Diese Konvertierung verschiebt das Array in einen neu Heap-zugewiesenen Speicher.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Versuchen Sie, die Box auf einen konkreten Typ herunterzuspielen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Versuchen Sie, die Box auf einen konkreten Typ herunterzuspielen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Versuchen Sie, die Box auf einen konkreten Typ herunterzuspielen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Es ist nicht möglich, das innere Uniq direkt aus der Box zu extrahieren, sondern wir wandeln es in eine * const um, die das Unique aliasisiert
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Spezialisierung für "I" der Größe, bei der anstelle der Standardeinstellung die I-Implementierung von `last()` verwendet wird.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}