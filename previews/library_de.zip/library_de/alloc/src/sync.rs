#![stable(feature = "rust1", since = "1.0.0")]

//! Thread-sichere Referenzzählzeiger.
//!
//! Weitere Informationen finden Sie in der [`Arc<T>`][Arc]-Dokumentation.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Eine weiche Begrenzung der Anzahl von Verweisen, die auf einen `Arc` vorgenommen werden können.
///
/// Wenn Sie dieses Limit überschreiten, wird Ihr Programm (wenn auch nicht unbedingt) bei _exactly_ `MAX_REFCOUNT + 1`-Referenzen abgebrochen.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer unterstützt keine Speicherzäune.
// Um falsch positive Berichte in der Arc/Weak-Implementierung zu vermeiden, verwenden Sie stattdessen atomare Lasten für die Synchronisation.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Ein thread-sicherer Referenzzählzeiger.'Arc' steht für "Atomically Reference Counted".
///
/// Der Typ `Arc<T>` bietet das gemeinsame Eigentum an einem Wert vom Typ `T`, der im Heap zugewiesen ist.Durch Aufrufen von [`clone`][clone] unter `Arc` wird eine neue `Arc`-Instanz erstellt, die auf dieselbe Zuordnung auf dem Heap wie die Quelle `Arc` verweist und gleichzeitig die Referenzanzahl erhöht.
/// Wenn der letzte `Arc`-Zeiger auf eine bestimmte Zuordnung zerstört wird, wird auch der in dieser Zuordnung gespeicherte Wert (häufig als "inner value" bezeichnet) gelöscht.
///
/// Freigegebene Referenzen in Rust verbieten standardmäßig die Mutation, und `Arc` ist keine Ausnahme: Sie können im Allgemeinen keine veränderbare Referenz auf etwas in einem `Arc` erhalten.Wenn Sie über einen `Arc` mutieren müssen, verwenden Sie [`Mutex`][mutex], [`RwLock`][rwlock] oder einen der [`Atomic`][atomic]-Typen.
///
/// ## Gewindesicherheit
///
/// Im Gegensatz zu [`Rc<T>`] verwendet `Arc<T>` atomare Operationen für die Referenzzählung.Dies bedeutet, dass es threadsicher ist.Der Nachteil ist, dass atomare Operationen teurer sind als gewöhnliche Speicherzugriffe.Wenn Sie keine Zuordnungen mit Referenzzählung zwischen Threads freigeben, sollten Sie [`Rc<T>`] für einen geringeren Overhead verwenden.
/// [`Rc<T>`] ist eine sichere Standardeinstellung, da der Compiler jeden Versuch abfängt, ein [`Rc<T>`] zwischen Threads zu senden.
/// Eine Bibliothek kann sich jedoch für `Arc<T>` entscheiden, um den Bibliothekskonsumenten mehr Flexibilität zu bieten.
///
/// `Arc<T>` implementiert [`Send`] und [`Sync`], solange `T` [`Send`] und [`Sync`] implementiert.
/// Warum können Sie einen nicht threadsicheren Typ `T` nicht in einen `Arc<T>` einfügen, um ihn threadsicher zu machen?Dies mag zunächst etwas kontraintuitiv sein: Geht es nicht um die Sicherheit von `Arc<T>`-Threads?Der Schlüssel ist folgender: `Arc<T>` macht es threadsicher, mehrere Eigentümer derselben Daten zu haben, aber es fügt seinen Daten keine Thread-Sicherheit hinzu.
///
/// Betrachten Sie `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ist nicht [`Sync`], und wenn `Arc<T>` immer [`Send`] war, `Arc <` [`RefCell<T>`]`>`wäre auch so.
/// Aber dann hätten wir ein Problem:
/// [`RefCell<T>`] ist nicht threadsicher;Es verfolgt die Anzahl der Kredite mit nichtatomaren Operationen.
///
/// Am Ende bedeutet dies, dass Sie möglicherweise `Arc<T>` mit einem [`std::sync`]-Typ koppeln müssen, normalerweise [`Mutex<T>`][mutex].
///
/// ## Zyklen mit `Weak` unterbrechen
///
/// Mit der [`downgrade`][downgrade]-Methode kann ein nicht besitzender [`Weak`]-Zeiger erstellt werden.Ein [`Weak`]-Zeiger kann [`upgrade`][upgrade] d auf einen `Arc` sein, dies gibt jedoch [`None`] zurück, wenn der in der Zuordnung gespeicherte Wert bereits gelöscht wurde.
/// Mit anderen Worten, `Weak`-Zeiger halten den Wert innerhalb der Zuordnung nicht am Leben.Sie *halten* jedoch die Zuordnung (den Hintergrundspeicher für den Wert) am Leben.
///
/// Ein Zyklus zwischen `Arc`-Zeigern wird niemals freigegeben.
/// Aus diesem Grund wird [`Weak`] verwendet, um Zyklen zu unterbrechen.Beispielsweise könnte ein Baum starke `Arc`-Zeiger von übergeordneten Knoten zu untergeordneten Knoten und [`Weak`]-Zeiger von untergeordneten Knoten zu ihren übergeordneten Knoten aufweisen.
///
/// # Klonen von Referenzen
///
/// Das Erstellen einer neuen Referenz aus einem vorhandenen Zeiger mit Referenzzählung erfolgt mit dem für [`Arc<T>`][Arc] und [`Weak<T>`][Weak] implementierten `Clone` trait.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Die beiden folgenden Syntaxen sind äquivalent.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b und foo sind alle Bögen, die auf denselben Speicherort verweisen
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` Automatische Dereferenzen zu `T` (über [`Deref`][deref] trait), sodass Sie die Methoden von `T` für einen Wert vom Typ `Arc<T>` aufrufen können.Um Namenskonflikte mit den Methoden von `T` zu vermeiden, sind die Methoden von `Arc<T>` selbst zugeordnete Funktionen, die mit [fully qualified syntax] aufgerufen werden:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Die Implementierungen von traits wie `Clone` können auch mit vollständig qualifizierter Syntax aufgerufen werden.
/// Einige Leute bevorzugen die Verwendung einer vollständig qualifizierten Syntax, während andere die Syntax des Methodenaufrufs bevorzugen.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntax für Methodenaufrufe
/// let arc2 = arc.clone();
/// // Vollqualifizierte Syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] führt keine automatische Dereferenzierung zu `T` durch, da der innere Wert möglicherweise bereits gelöscht wurde.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Teilen einiger unveränderlicher Daten zwischen Threads:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Beachten Sie, dass wir diese Tests hier nicht durchführen.
// Die windows-Builder werden sehr unglücklich, wenn ein Thread den Hauptthread überlebt und dann gleichzeitig beendet wird (etwas Deadlocks). Wir vermeiden dies also vollständig, indem wir diese Tests nicht ausführen.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Teilen eines veränderlichen [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Weitere Beispiele für die Referenzzählung im Allgemeinen finden Sie im [`rc` documentation][rc_examples].
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ist eine Version von [`Arc`], die einen nicht besitzenden Verweis auf die verwaltete Zuordnung enthält.
/// Auf die Zuordnung wird zugegriffen, indem [`upgrade`] auf dem `Weak`-Zeiger aufgerufen wird, der eine [`Option`]`<`[`Arc`] `zurückgibt<T>>`.
///
/// Da eine `Weak`-Referenz nicht für den Besitz angerechnet wird, wird nicht verhindert, dass der in der Zuordnung gespeicherte Wert gelöscht wird, und `Weak` selbst übernimmt keine Garantie dafür, dass der Wert noch vorhanden ist.
///
/// Daher kann es [`None`] zurückgeben, wenn [`upgrade`] d.
/// Beachten Sie jedoch, dass eine `Weak`-Referenz *verhindert*, dass die Zuordnung selbst (der Sicherungsspeicher) aufgehoben wird.
///
/// Ein `Weak`-Zeiger ist nützlich, um einen temporären Verweis auf die von [`Arc`] verwaltete Zuordnung beizubehalten, ohne zu verhindern, dass sein innerer Wert gelöscht wird.
/// Es wird auch verwendet, um Zirkelverweise zwischen [`Arc`]-Zeigern zu verhindern, da gegenseitige Besitzverweise niemals zulassen würden, dass [`Arc`] gelöscht wird.
/// Beispielsweise könnte ein Baum starke [`Arc`]-Zeiger von übergeordneten Knoten zu untergeordneten Knoten und `Weak`-Zeiger von untergeordneten Knoten zu ihren übergeordneten Knoten aufweisen.
///
/// Der typische Weg, um einen `Weak`-Zeiger zu erhalten, besteht darin, [`Arc::downgrade`] aufzurufen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dies ist ein `NonNull`, um die Größe dieses Typs in Aufzählungen zu optimieren, aber es ist nicht unbedingt ein gültiger Zeiger.
    //
    // `Weak::new` setzt dies auf `usize::MAX`, damit kein Speicherplatz auf dem Heap zugewiesen werden muss.
    // Dies ist kein Wert, den ein echter Zeiger jemals haben wird, da die Ausrichtung der RcBox mindestens 2 beträgt.
    // Dies ist nur möglich, wenn `T: Sized`;`T` ohne Größe baumelt nie.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Dies ist repr(C) bis future-sicher gegen mögliche Feldumordnungen, die das ansonsten sichere [into|from]_raw() transmutierbarer innerer Typen beeinträchtigen würden.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // Der Wert usize::MAX fungiert als Sentinel für "locking", um vorübergehend schwache oder starke Zeiger zu aktualisieren.Dies wird verwendet, um Rennen in `make_mut` und `get_mut` zu vermeiden.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Erstellt einen neuen `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Starten Sie die Anzahl der schwachen Zeiger als 1. Dies ist der schwache Zeiger, der von allen starken Zeigern (kinda) gehalten wird. Weitere Informationen finden Sie unter std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruiert einen neuen `Arc<T>` unter Verwendung eines schwachen Verweises auf sich selbst.
    /// Der Versuch, die schwache Referenz zu aktualisieren, bevor diese Funktion zurückkehrt, führt zu einem `None`-Wert.
    /// Die schwache Referenz kann jedoch frei geklont und zur späteren Verwendung gespeichert werden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstruieren Sie das Innere im "uninitialized"-Zustand mit einer einzigen schwachen Referenz.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Es ist wichtig, dass wir den Besitz des schwachen Zeigers nicht aufgeben, da sonst der Speicher bei der Rückkehr von `data_fn` möglicherweise freigegeben wird.
        // Wenn wir wirklich das Eigentum übergeben wollten, könnten wir einen zusätzlichen schwachen Zeiger für uns selbst erstellen, aber dies würde zu zusätzlichen Aktualisierungen des schwachen Referenzzählers führen, die sonst möglicherweise nicht notwendig wären.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Jetzt können wir den inneren Wert richtig initialisieren und unsere schwache Referenz in eine starke Referenz verwandeln.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Das obige Schreiben in das Datenfeld muss für alle Threads sichtbar sein, die eine starke Zählung ungleich Null beobachten.
            // Daher benötigen wir mindestens eine "Release"-Bestellung, um mit dem `compare_exchange_weak` in `Weak::upgrade` zu synchronisieren.
            //
            // "Acquire" Bestellung ist nicht erforderlich.
            // Wenn wir das mögliche Verhalten von `data_fn` betrachten, müssen wir uns nur ansehen, was es mit einem Verweis auf ein nicht aktualisierbares `Weak` tun könnte:
            //
            // - Es kann den `Weak`*klonen* und so die Anzahl der schwachen Referenzen erhöhen.
            // - Diese Klone können fallen gelassen werden, wodurch die Anzahl der schwachen Referenzen verringert wird (jedoch niemals auf Null).
            //
            // Diese Nebenwirkungen wirken sich in keiner Weise auf uns aus, und mit sicherem Code allein sind keine anderen Nebenwirkungen möglich.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Starke Referenzen sollten zusammen eine gemeinsame schwache Referenz besitzen. Führen Sie daher den Destruktor für unsere alte schwache Referenz nicht aus.
        //
        mem::forget(weak);
        strong
    }

    /// Erstellt einen neuen `Arc` mit nicht initialisierten Inhalten.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Erstellt ein neues `Arc` mit nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Erstellt einen neuen `Pin<Arc<T>>`.
    /// Wenn `T` `Unpin` nicht implementiert, wird `data` im Speicher fixiert und kann nicht verschoben werden.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Erstellt einen neuen `Arc<T>` und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Starten Sie die Anzahl der schwachen Zeiger als 1. Dies ist der schwache Zeiger, der von allen starken Zeigern (kinda) gehalten wird. Weitere Informationen finden Sie unter std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Erstellt einen neuen `Arc` mit nicht initialisiertem Inhalt und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Erstellt ein neues `Arc` mit nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist, und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Gibt den inneren Wert zurück, wenn der `Arc` genau eine starke Referenz hat.
    ///
    /// Andernfalls wird ein [`Err`] mit demselben `Arc` zurückgegeben, der übergeben wurde.
    ///
    ///
    /// Dies wird auch dann erfolgreich sein, wenn herausragende schwache Referenzen vorliegen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Machen Sie einen schwachen Zeiger, um die implizite stark-schwache Referenz zu bereinigen
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruiert eine neue atomar referenzgezählte Schicht mit nicht initialisiertem Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Erstellt ein neues Slice mit atomarer Referenzzählung und nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konvertiert in `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Wie bei [`MaybeUninit::assume_init`] muss der Anrufer sicherstellen, dass sich der innere Wert tatsächlich in einem initialisierten Zustand befindet.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, tritt sofort undefiniertes Verhalten auf.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konvertiert in `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Wie bei [`MaybeUninit::assume_init`] muss der Anrufer sicherstellen, dass sich der innere Wert tatsächlich in einem initialisierten Zustand befindet.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, tritt sofort undefiniertes Verhalten auf.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Verbraucht den `Arc` und gibt den umgebrochenen Zeiger zurück.
    ///
    /// Um einen Speicherverlust zu vermeiden, muss der Zeiger mit [`Arc::from_raw`] wieder in einen `Arc` konvertiert werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Stellt einen Rohzeiger auf die Daten bereit.
    ///
    /// Die Anzahl wird in keiner Weise beeinflusst und der `Arc` wird nicht verbraucht.
    /// Der Zeiger ist so lange gültig, wie der `Arc` stark zählt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SICHERHEIT: Dies kann nicht über Deref::deref oder RcBoxPtr::inner gehen, weil
        // Dies ist erforderlich, um die raw/mut-Herkunft so zu erhalten, dass z
        // `get_mut` kann durch den Zeiger schreiben, nachdem der Rc durch `from_raw` wiederhergestellt wurde.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstruiert ein `Arc<T>` aus einem Rohzeiger.
    ///
    /// Der Rohzeiger muss zuvor durch einen Aufruf von [`Arc<U>::into_raw`][into_raw] zurückgegeben worden sein, wobei `U` dieselbe Größe und Ausrichtung wie `T` haben muss.
    /// Dies ist trivial wahr, wenn `U` `T` ist.
    /// Beachten Sie, dass wenn `U` nicht `T` ist, aber dieselbe Größe und Ausrichtung hat, dies im Grunde wie das Umwandeln von Referenzen verschiedener Typen ist.
    /// Weitere Informationen zu den in diesem Fall geltenden Einschränkungen finden Sie unter [`mem::transmute`][transmute].
    ///
    /// Der Benutzer von `from_raw` muss sicherstellen, dass ein bestimmter Wert von `T` nur einmal gelöscht wird.
    ///
    /// Diese Funktion ist unsicher, da eine unsachgemäße Verwendung zu einer Unsicherheit des Speichers führen kann, selbst wenn auf den zurückgegebenen `Arc<T>` nie zugegriffen wird.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertieren Sie zurück zu einem `Arc`, um Leckagen zu vermeiden.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Weitere Aufrufe von `Arc::from_raw(x_ptr)` wären speichersicher.
    /// }
    ///
    /// // Der Speicher wurde freigegeben, als `x` den oben genannten Bereich verlassen hat, sodass `x_ptr` jetzt baumelt!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Kehren Sie den Versatz um, um den ursprünglichen ArcInner zu finden.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Erstellt einen neuen [`Weak`]-Zeiger auf diese Zuordnung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Diese Entspannung ist in Ordnung, da wir den Wert im CAS unten überprüfen.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // Überprüfen Sie, ob der schwache Zähler derzeit "locked" ist.Wenn ja, drehen.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: Dieser Code ignoriert derzeit die Möglichkeit eines Überlaufs
            // in usize::MAX;Im Allgemeinen müssen sowohl Rc als auch Arc angepasst werden, um den Überlauf zu bewältigen.
            //

            // Anders als bei Clone() muss dies ein Acquire-Lesevorgang sein, um mit dem von `is_unique` kommenden Schreibvorgang zu synchronisieren, damit die Ereignisse vor diesem Schreibvorgang vor diesem Lesevorgang stattfinden.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Stellen Sie sicher, dass wir keine baumelnden Schwachen schaffen
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ruft die Anzahl der [`Weak`]-Zeiger auf diese Zuordnung ab.
    ///
    /// # Safety
    ///
    /// Diese Methode ist an sich sicher, erfordert jedoch besondere Sorgfalt.
    /// Ein anderer Thread kann die Anzahl der Schwachstellen jederzeit ändern, einschließlich möglicherweise zwischen dem Aufrufen dieser Methode und dem Eingreifen in das Ergebnis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Diese Behauptung ist deterministisch, da wir `Arc` oder `Weak` nicht zwischen Threads geteilt haben.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Wenn die schwache Zählung derzeit gesperrt ist, war der Wert der Zählung unmittelbar vor dem Aufheben der Sperre 0.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ruft die Anzahl der starken (`Arc`)-Zeiger auf diese Zuordnung ab.
    ///
    /// # Safety
    ///
    /// Diese Methode ist an sich sicher, erfordert jedoch besondere Sorgfalt.
    /// Ein anderer Thread kann die Anzahl der starken Daten jederzeit ändern, einschließlich möglicherweise zwischen dem Aufrufen dieser Methode und dem Eingreifen in das Ergebnis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Diese Behauptung ist deterministisch, da wir den `Arc` nicht zwischen Threads geteilt haben.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Erhöht den starken Referenzzähler auf dem `Arc<T>`, der dem bereitgestellten Zeiger zugeordnet ist, um eins.
    ///
    /// # Safety
    ///
    /// Der Zeiger muss über `Arc::into_raw` abgerufen worden sein und die zugehörige `Arc`-Instanz muss gültig sein (dh
    /// Die starke Anzahl muss für die Dauer dieser Methode mindestens 1) betragen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Diese Behauptung ist deterministisch, da wir den `Arc` nicht zwischen Threads geteilt haben.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Behalten Sie Arc bei, aber berühren Sie refcount nicht, indem Sie ManuallyDrop einschließen
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Erhöhen Sie jetzt den Refcount, aber lassen Sie auch keinen neuen Refcount fallen
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Verringert den starken Referenzzähler auf dem `Arc<T>`, der dem bereitgestellten Zeiger zugeordnet ist, um eins.
    ///
    /// # Safety
    ///
    /// Der Zeiger muss über `Arc::into_raw` abgerufen worden sein und die zugehörige `Arc`-Instanz muss gültig sein (dh
    /// Die starke Anzahl muss mindestens 1) betragen, wenn diese Methode aufgerufen wird.
    /// Diese Methode kann verwendet werden, um den endgültigen `Arc`-und Backing-Speicher freizugeben, sollte jedoch **nicht** aufgerufen werden, nachdem der endgültige `Arc` freigegeben wurde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Diese Behauptungen sind deterministisch, da wir den `Arc` nicht zwischen Threads geteilt haben.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Diese Unsicherheit ist in Ordnung, denn während dieser Bogen lebt, ist garantiert, dass der innere Zeiger gültig ist.
        // Darüber hinaus wissen wir, dass die `ArcInner`-Struktur selbst `Sync` ist, da die inneren Daten ebenfalls `Sync` sind. Daher können wir einen unveränderlichen Zeiger auf diese Inhalte ausleihen.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Nicht inline Teil von `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Zerstören Sie die Daten zu diesem Zeitpunkt, auch wenn wir die Box-Zuordnung selbst möglicherweise nicht freigeben (möglicherweise liegen noch schwache Zeiger herum).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Lassen Sie den schwachen Schiedsrichter fallen, der gemeinsam von allen starken Referenzen gehalten wird
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Gibt `true` zurück, wenn die beiden "Arc" auf dieselbe Zuordnung zeigen (ähnlich wie bei [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Weist einen `ArcInner<T>` mit ausreichend Platz für einen möglicherweise nicht dimensionierten inneren Wert zu, für den der Wert das bereitgestellte Layout enthält.
    ///
    /// Die Funktion `mem_to_arcinner` wird mit dem Datenzeiger aufgerufen und muss einen (möglicherweise fetten) Zeiger für den `ArcInner<T>` zurückgeben.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Berechnen Sie das Layout mit dem angegebenen Wertelayout.
        // Bisher wurde das Layout für den Ausdruck `&*(ptr as* const ArcInner<T>)` berechnet, dies führte jedoch zu einer falsch ausgerichteten Referenz (siehe #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Weist einem `ArcInner<T>` ausreichend Speicherplatz für einen möglicherweise nicht dimensionierten inneren Wert zu, für den das Layout des Layouts bereitgestellt wurde, und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt.
    ///
    ///
    /// Die Funktion `mem_to_arcinner` wird mit dem Datenzeiger aufgerufen und muss einen (möglicherweise fetten) Zeiger für den `ArcInner<T>` zurückgeben.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Berechnen Sie das Layout mit dem angegebenen Wertelayout.
        // Bisher wurde das Layout für den Ausdruck `&*(ptr as* const ArcInner<T>)` berechnet, dies führte jedoch zu einer falsch ausgerichteten Referenz (siehe #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialisieren Sie den ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Weist einem `ArcInner<T>` ausreichend Platz für einen nicht dimensionierten inneren Wert zu.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Ordnen Sie dem `ArcInner<T>` den angegebenen Wert zu.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Wert als Bytes kopieren
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Geben Sie die Zuordnung frei, ohne den Inhalt zu löschen
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Weist einen `ArcInner<[T]>` mit der angegebenen Länge zu.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopieren Sie Elemente aus dem Slice in den neu zugewiesenen Arc <\[T\]>
    ///
    /// Unsicher, da der Anrufer entweder das Eigentum übernehmen oder `T: Copy` binden muss.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruiert einen `Arc<[T]>` aus einem Iterator, von dem bekannt ist, dass er eine bestimmte Größe hat.
    ///
    /// Das Verhalten ist undefiniert, sollte die Größe falsch sein.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic-Schutz beim Klonen von T-Elementen.
        // Bei einem panic werden Elemente, die in den neuen ArcInner geschrieben wurden, gelöscht und der Speicher freigegeben.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Zeiger auf erstes Element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles klar.Vergessen Sie die Wache, damit der neue ArcInner nicht freigegeben wird.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spezialisierung trait für `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Erstellt einen Klon des `Arc`-Zeigers.
    ///
    /// Dadurch wird ein weiterer Zeiger auf dieselbe Zuordnung erstellt, wodurch die Anzahl der starken Referenzen erhöht wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Die Verwendung einer entspannten Reihenfolge ist hier in Ordnung, da die Kenntnis der ursprünglichen Referenz verhindert, dass andere Threads das Objekt fälschlicherweise löschen.
        //
        // Wie im [Boost documentation][1] erläutert, kann das Erhöhen des Referenzzählers immer mit memory_order_relaxed erfolgen: Neue Verweise auf ein Objekt können nur aus einer vorhandenen Referenz gebildet werden, und das Übergeben einer vorhandenen Referenz von einem Thread an einen anderen muss bereits die erforderliche Synchronisierung bereitstellen.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Wir müssen uns jedoch vor massiven Nachzählungen schützen, falls jemand die Bögen "mem: : vergessen" hat.
        // Wenn wir dies nicht tun, kann die Anzahl überlaufen und die Benutzer werden nachträglich kostenlos verwendet.
        // Wir sättigen schnell auf `isize::MAX`, unter der Annahme, dass es keine ~2-Milliarden-Threads gibt, die den Referenzzähler gleichzeitig erhöhen.
        //
        // Diese branch wird niemals in ein realistisches Programm aufgenommen.
        //
        // Wir brechen ab, weil ein solches Programm unglaublich entartet ist und wir es nicht unterstützen möchten.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Macht eine veränderbare Referenz in das gegebene `Arc`.
    ///
    /// Wenn andere `Arc`-oder [`Weak`]-Zeiger auf dieselbe Zuordnung vorhanden sind, erstellt `make_mut` eine neue Zuordnung und ruft [`clone`][clone] für den inneren Wert auf, um eine eindeutige Eigentümerschaft sicherzustellen.
    /// Dies wird auch als Clone-on-Write bezeichnet.
    ///
    /// Beachten Sie, dass dies vom Verhalten von [`Rc::make_mut`] abweicht, bei dem alle verbleibenden `Weak`-Zeiger getrennt werden.
    ///
    /// Siehe auch [`get_mut`][get_mut], das fehlschlägt und nicht klont.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Klont nichts
    /// let mut other_data = Arc::clone(&data); // Klont keine inneren Daten
    /// *Arc::make_mut(&mut data) += 1;         // Klont innere Daten
    /// *Arc::make_mut(&mut data) += 1;         // Klont nichts
    /// *Arc::make_mut(&mut other_data) *= 2;   // Klont nichts
    ///
    /// // Jetzt zeigen `data` und `other_data` auf unterschiedliche Zuordnungen.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Beachten Sie, dass wir sowohl eine starke als auch eine schwache Referenz haben.
        // Wenn Sie also nur unsere starke Referenz freigeben, wird die Speicherung des Speichers nicht von selbst aufgehoben.
        //
        // Verwenden Sie Acquire, um sicherzustellen, dass alle Schreibvorgänge in `weak` angezeigt werden, die vor dem Release-Schreibvorgang (dh Dekrementen) in `strong` erfolgen.
        // Da wir eine schwache Anzahl haben, besteht keine Chance, dass der ArcInner selbst freigegeben wird.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Ein weiterer starker Zeiger existiert, also müssen wir klonen.
            // Ordnen Sie den Speicher vorab zu, damit der geklonte Wert direkt geschrieben werden kann.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Entspanntes genügt oben, da dies im Grunde genommen eine Optimierung ist: Wir fahren immer mit schwachen Zeigern, die fallen gelassen werden.
            // Im schlimmsten Fall wird uns unnötigerweise ein neuer Bogen zugewiesen.
            //

            // Wir haben den letzten starken Schiedsrichter entfernt, aber es sind noch weitere schwache Schiedsrichter übrig.
            // Wir werden den Inhalt in einen neuen Bogen verschieben und die anderen schwachen Refs ungültig machen.
            //

            // Beachten Sie, dass das Lesen von `weak` nicht zu usize::MAX (dh gesperrt) führen kann, da die schwache Anzahl nur von einem Thread mit einer starken Referenz gesperrt werden kann.
            //
            //

            // Materialisieren Sie unseren eigenen impliziten schwachen Zeiger, damit er den ArcInner nach Bedarf bereinigen kann.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kann nur die Daten stehlen, alles was übrig bleibt ist Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Wir waren die einzige Referenz beider Art;Erhöhen Sie die Anzahl der starken Schiedsrichter.
            //
            this.inner().strong.store(1, Release);
        }

        // Wie bei `get_mut()` ist die Unsicherheit in Ordnung, da unsere Referenz entweder von Anfang an eindeutig war oder beim Klonen des Inhalts eins wurde.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Gibt eine veränderbare Referenz in das angegebene `Arc` zurück, wenn keine anderen `Arc`-oder [`Weak`]-Zeiger auf dieselbe Zuordnung vorhanden sind.
    ///
    ///
    /// Gibt ansonsten [`None`] zurück, da es nicht sicher ist, einen gemeinsam genutzten Wert zu mutieren.
    ///
    /// Siehe auch [`make_mut`][make_mut], wodurch der innere Wert [`clone`][clone] wird, wenn andere Zeiger vorhanden sind.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Diese Unsicherheit ist in Ordnung, da wir garantiert haben, dass der zurückgegebene Zeiger der *einzige* Zeiger ist, der jemals an T zurückgegeben wird.
            // Zu diesem Zeitpunkt ist unser Referenzzähler garantiert 1, und wir haben verlangt, dass der Bogen selbst `mut` ist, sodass wir den einzig möglichen Verweis auf die inneren Daten zurückgeben.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Gibt ohne Änderung eine veränderbare Referenz in das angegebene `Arc` zurück.
    ///
    /// Siehe auch [`get_mut`], das sicher ist und entsprechende Überprüfungen durchführt.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Alle anderen `Arc`-oder [`Weak`]-Zeiger auf dieselbe Zuordnung dürfen für die Dauer der zurückgegebenen Ausleihe nicht dereferenziert werden.
    ///
    /// Dies ist trivial der Fall, wenn solche Zeiger beispielsweise unmittelbar nach `Arc::new` nicht vorhanden sind.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Wir achten darauf,*keine* Referenz zu erstellen, die die "count"-Felder abdeckt, da dies einen Alias bei gleichzeitigem Zugriff auf die Referenzzählungen darstellen würde (z
        // von `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bestimmen Sie, ob dies die eindeutige Referenz (einschließlich schwacher Verweise) auf die zugrunde liegenden Daten ist.
    ///
    ///
    /// Beachten Sie, dass hierfür die schwache Ref-Anzahl gesperrt werden muss.
    fn is_unique(&mut self) -> bool {
        // Sperren Sie die Anzahl der schwachen Zeiger, wenn wir der einzige schwache Zeigerhalter zu sein scheinen.
        //
        // Das Erfassungsetikett stellt hier sicher, dass eine Beziehung zu Schreibvorgängen in `strong` (insbesondere in `Weak::upgrade`) vor dem Verringern der `weak`-Anzahl (über `Weak::drop`, das Release verwendet) besteht.
        // Wenn der aktualisierte schwache Ref nie gelöscht wurde, schlägt der CAS hier fehl, sodass wir uns nicht um die Synchronisierung kümmern.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Dies muss ein `Acquire` sein, um mit dem Dekrement des `strong`-Zählers in `drop` synchronisiert zu werden-der einzige Zugriff, der erfolgt, wenn eine andere als die letzte Referenz gelöscht wird.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Der hier veröffentlichte Release-Schreibvorgang wird mit einem Lesevorgang in `downgrade` synchronisiert, wodurch effektiv verhindert wird, dass der obige Lesevorgang von `strong` nach dem Schreibvorgang erfolgt.
            //
            //
            self.inner().weak.store(1, Release); // Lassen Sie das Schloss los
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Lässt den `Arc` fallen.
    ///
    /// Dies verringert den starken Referenzzähler.
    /// Wenn der starke Referenzzähler Null erreicht, sind die einzigen anderen Referenzen (falls vorhanden) [`Weak`], also `drop` der innere Wert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Druckt nichts
    /// drop(foo2);   // Druckt "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Da `fetch_sub` bereits atomar ist, müssen wir nicht mit anderen Threads synchronisieren, es sei denn, wir werden das Objekt löschen.
        // Dieselbe Logik gilt für das unten stehende `fetch_sub` für die `weak`-Anzahl.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Dieser Zaun wird benötigt, um eine Neuordnung der Datennutzung und das Löschen der Daten zu verhindern.
        // Da es mit `Release` markiert ist, wird die Verringerung des Referenzzählers mit diesem `Acquire`-Zaun synchronisiert.
        // Dies bedeutet, dass die Verwendung der Daten vor dem Verringern der Referenzanzahl erfolgt, was vor diesem Zaun geschieht, was vor dem Löschen der Daten geschieht.
        //
        // Wie im [Boost documentation][1] erklärt,
        //
        // > Es ist wichtig, einen möglichen Zugriff auf das Objekt in einem zu erzwingen
        // > Thread (durch eine vorhandene Referenz) soll *vor* dem Löschen geschehen
        // > das Objekt in einem anderen Thread.Dies wird durch einen "release" erreicht
        // > Operation nach dem Löschen einer Referenz (jeder Zugriff auf das Objekt
        // > durch diesen Verweis muss offensichtlich vorher passiert sein), und ein
        // > "acquire" Operation vor dem Löschen des Objekts.
        //
        // Während der Inhalt eines Bogens normalerweise unveränderlich ist, ist es insbesondere möglich, dass innere Schreibvorgänge in so etwas wie einen Mutex ausgeführt werden<T>.
        // Da ein Mutex beim Löschen nicht erfasst wird, können wir uns nicht auf seine Synchronisationslogik verlassen, um Schreibvorgänge in Thread A für einen in Thread B ausgeführten Destruktor sichtbar zu machen.
        //
        //
        // Beachten Sie auch, dass der Acquire-Zaun hier wahrscheinlich durch eine Acquire-Last ersetzt werden könnte, was die Leistung in hart umkämpften Situationen verbessern könnte.Siehe [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Versuchen Sie, den `Arc<dyn Any + Send + Sync>` auf einen konkreten Typ herunterzuspielen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Erstellt einen neuen `Weak<T>`, ohne Speicher zuzuweisen.
    /// Wenn Sie [`upgrade`] für den Rückgabewert aufrufen, erhalten Sie immer [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Hilfstyp, um den Zugriff auf die Referenzzählungen zu ermöglichen, ohne Aussagen über das Datenfeld zu machen.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Gibt einen Rohzeiger auf das Objekt `T` zurück, auf das dieses `Weak<T>` zeigt.
    ///
    /// Der Zeiger ist nur gültig, wenn starke Referenzen vorhanden sind.
    /// Der Zeiger kann baumeln, nicht ausgerichtet sein oder andernfalls sogar [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Beide zeigen auf dasselbe Objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Das Starke hier hält es am Leben, so dass wir immer noch auf das Objekt zugreifen können.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Aber nicht mehr.
    /// // Wir können weak.as_ptr() ausführen, aber der Zugriff auf den Zeiger würde zu undefiniertem Verhalten führen.
    /// // assert_eq! ("Hallo", unsicher {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Wenn der Zeiger baumelt, geben wir den Sentinel direkt zurück.
            // Dies kann keine gültige Nutzdatenadresse sein, da die Nutzdaten mindestens so ausgerichtet sind wie ArcInner (usize).
            ptr as *const T
        } else {
            // SICHERHEIT: Wenn is_dangling false zurückgibt, ist der Zeiger dereferenzierbar.
            // Die Nutzlast kann zu diesem Zeitpunkt gelöscht werden, und wir müssen die Herkunft beibehalten. Verwenden Sie daher die Manipulation des Rohzeigers.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Verbraucht den `Weak<T>` und verwandelt ihn in einen Rohzeiger.
    ///
    /// Dadurch wird der schwache Zeiger in einen Rohzeiger konvertiert, wobei der Besitz einer schwachen Referenz erhalten bleibt (die schwache Anzahl wird durch diese Operation nicht geändert).
    /// Es kann mit [`from_raw`] wieder in den `Weak<T>` verwandelt werden.
    ///
    /// Es gelten die gleichen Einschränkungen für den Zugriff auf das Ziel des Zeigers wie bei [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konvertiert einen zuvor von [`into_raw`] erstellten Rohzeiger zurück in `Weak<T>`.
    ///
    /// Dies kann verwendet werden, um sicher eine starke Referenz zu erhalten (indem Sie später [`upgrade`] aufrufen) oder um die Zuweisung der schwachen Anzahl durch Löschen des `Weak<T>` aufzuheben.
    ///
    /// Es übernimmt den Besitz einer schwachen Referenz (mit Ausnahme der von [`new`] erstellten Zeiger, da diese nichts besitzen; die Methode funktioniert weiterhin mit ihnen).
    ///
    /// # Safety
    ///
    /// Der Zeiger muss vom [`into_raw`] stammen und seine potenzielle schwache Referenz besitzen.
    ///
    /// Es ist zulässig, dass die starke Anzahl zum Zeitpunkt des Aufrufs 0 ist.
    /// Dies übernimmt jedoch den Besitz einer schwachen Referenz, die derzeit als Rohzeiger dargestellt wird (die schwache Anzahl wird durch diese Operation nicht geändert), und muss daher mit einem vorherigen Aufruf von [`into_raw`] gepaart werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Verringern Sie die letzte schwache Zählung.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // In Weak::as_ptr finden Sie einen Kontext zur Ableitung des Eingabezeigers.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dies ist eine baumelnde Schwäche.
            ptr as *mut ArcInner<T>
        } else {
            // Ansonsten ist garantiert, dass der Zeiger von einem nicht baumelnden Schwachen stammt.
            // SICHERHEIT: data_offset kann sicher aufgerufen werden, da ptr auf ein reales (möglicherweise verworfenes) T verweist.
            let offset = unsafe { data_offset(ptr) };
            // Daher kehren wir den Offset um, um die gesamte RcBox zu erhalten.
            // SICHERHEIT: Der Zeiger stammt von einem Schwachen, daher ist dieser Versatz sicher.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SICHERHEIT: Wir haben jetzt den ursprünglichen schwachen Zeiger wiederhergestellt, können also den schwachen Zeiger erstellen.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Versuche, den `Weak`-Zeiger auf einen [`Arc`] zu aktualisieren, verzögern bei Erfolg das Löschen des inneren Werts.
    ///
    ///
    /// Gibt [`None`] zurück, wenn der innere Wert inzwischen gelöscht wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zerstöre alle starken Zeiger.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Wir verwenden eine CAS-Schleife, um die starke Anzahl anstelle eines fetch_add zu erhöhen, da diese Funktion den Referenzzähler niemals von null auf eins bringen sollte.
        //
        //
        let inner = self.inner()?;

        // Entspannte Belastung, da jedes Schreiben von 0, das wir beobachten können, das Feld in einem permanenten Nullzustand belässt (ein "stale"-Lesevorgang von 0 ist also in Ordnung) und jeder andere Wert über das unten stehende CAS bestätigt wird.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // In den Kommentaren in `Arc::clone` erfahren Sie, warum wir dies tun (für `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Entspannt ist in Ordnung für den Fehlerfall, da wir keine Erwartungen an den neuen Zustand haben.
            // Die Erfassung ist erforderlich, damit der Erfolgsfall mit `Arc::new_cyclic` synchronisiert werden kann, wenn der innere Wert initialisiert werden kann, nachdem bereits `Weak`-Referenzen erstellt wurden.
            // In diesem Fall erwarten wir, dass der vollständig initialisierte Wert eingehalten wird.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null oben geprüft
                Err(old) => n = old,
            }
        }
    }

    /// Ruft die Anzahl der starken (`Arc`)-Zeiger ab, die auf diese Zuordnung verweisen.
    ///
    /// Wenn `self` mit [`Weak::new`] erstellt wurde, wird 0 zurückgegeben.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ruft eine Annäherung an die Anzahl der `Weak`-Zeiger ab, die auf diese Zuordnung verweisen.
    ///
    /// Wenn `self` mit [`Weak::new`] erstellt wurde oder keine starken Zeiger mehr vorhanden sind, wird 0 zurückgegeben.
    ///
    /// # Accuracy
    ///
    /// Aufgrund von Implementierungsdetails kann der zurückgegebene Wert in beiden Richtungen um 1 abweichen, wenn andere Threads "Arc" oder "Weak" manipulieren, die auf dieselbe Zuordnung verweisen.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Da wir beobachtet haben, dass es nach dem Lesen der schwachen Zählung mindestens einen starken Zeiger gab, wissen wir, dass die implizite schwache Referenz (die vorhanden ist, wenn starke Referenzen vorhanden sind) noch vorhanden war, als wir die schwache Zählung beobachteten, und sie daher sicher subtrahieren kann.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Gibt `None` zurück, wenn der Zeiger baumelt und kein `ArcInner` zugewiesen ist (dh wenn dieses `Weak` von `Weak::new` erstellt wurde).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Wir achten darauf, keine Referenz für das "data"-Feld zu erstellen, da das Feld möglicherweise gleichzeitig mutiert wird (wenn beispielsweise das letzte `Arc` gelöscht wird, wird das Datenfeld an Ort und Stelle gelöscht).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Gibt `true` zurück, wenn die beiden Schwachen auf dieselbe Zuordnung zeigen (ähnlich wie [`ptr::eq`]) oder wenn beide nicht auf eine Zuordnung zeigen (weil sie mit `Weak::new()`) erstellt wurden.
    ///
    ///
    /// # Notes
    ///
    /// Da dies Zeiger vergleicht, bedeutet dies, dass `Weak::new()` einander gleich ist, obwohl sie nicht auf eine Zuordnung verweisen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` vergleichen.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Erstellt einen Klon des `Weak`-Zeigers, der auf dieselbe Zuordnung verweist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // In den Kommentaren in Arc::clone() erfahren Sie, warum dies entspannt ist.
        // Dies kann ein fetch_add verwenden (die Sperre wird ignoriert), da die schwache Anzahl nur dort gesperrt ist, wo *keine anderen* schwachen Zeiger vorhanden sind.
        //
        // (In diesem Fall können wir diesen Code also nicht ausführen.)
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // In den Kommentaren in Arc::clone() erfahren Sie, warum wir dies tun (für mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Erstellt einen neuen `Weak<T>`, ohne Speicher zuzuweisen.
    /// Wenn Sie [`upgrade`] für den Rückgabewert aufrufen, erhalten Sie immer [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Lässt den `Weak`-Zeiger fallen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Druckt nichts
    /// drop(foo);        // Druckt "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Wenn wir herausfinden, dass wir der letzte schwache Zeiger waren, ist es an der Zeit, die Daten vollständig freizugeben.Siehe die Diskussion in Arc::drop() über die Speicherreihenfolge
        //
        // Es ist hier nicht erforderlich, nach dem gesperrten Zustand zu suchen, da die schwache Anzahl nur gesperrt werden kann, wenn genau eine schwache Referenz vorhanden ist. Dies bedeutet, dass der Drop nur anschließend auf der verbleibenden schwachen Referenz ausgeführt werden kann, was erst nach dem Aufheben der Sperre erfolgen kann.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Wir machen diese Spezialisierung hier und nicht als allgemeinere Optimierung für `&T`, da dies sonst alle Gleichheitsprüfungen für Refs kosten würde.
/// Wir gehen davon aus, dass "Arc" verwendet werden, um große Werte zu speichern, die nur langsam geklont werden können, aber auch schwer auf Gleichheit zu prüfen sind, wodurch sich diese Kosten leichter auszahlen.
///
/// Es ist auch wahrscheinlicher, dass zwei `Arc`-Klone auf denselben Wert verweisen als zwei `&T`s.
///
/// Wir können dies nur tun, wenn `T: Eq` als `PartialEq` absichtlich irreflexiv ist.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Gleichheit für zwei `Arc`s.
    ///
    /// Zwei `Arc`s sind gleich, wenn ihre inneren Werte gleich sind, auch wenn sie in unterschiedlicher Zuordnung gespeichert sind.
    ///
    /// Wenn `T` auch `Eq` implementiert (was Reflexivität der Gleichheit impliziert), sind zwei "Bögen", die auf dieselbe Zuordnung zeigen, immer gleich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ungleichung für zwei `Arc`s.
    ///
    /// Zwei `Arc`s sind ungleich, wenn ihre inneren Werte ungleich sind.
    ///
    /// Wenn `T` auch `Eq` implementiert (was Reflexivität der Gleichheit impliziert), sind zwei "Arc", die auf denselben Wert zeigen, niemals ungleich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Teilvergleich für zwei `Arc`s.
    ///
    /// Die beiden werden verglichen, indem `partial_cmp()` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Weniger als Vergleich für zwei `Arc`s.
    ///
    /// Die beiden werden verglichen, indem `<` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Vergleich 'kleiner oder gleich' für zwei 'Bögen'.
    ///
    /// Die beiden werden verglichen, indem `<=` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Größer als der Vergleich für zwei `Arc`s.
    ///
    /// Die beiden werden verglichen, indem `>` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Vergleich 'größer oder gleich' für zwei 'Bögen'.
    ///
    /// Die beiden werden verglichen, indem `>=` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Vergleich für zwei `Arc`s.
    ///
    /// Die beiden werden verglichen, indem `cmp()` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Erstellt einen neuen `Arc<T>` mit dem `Default`-Wert für `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Ordnen Sie ein Slice mit Referenzzählung zu und füllen Sie es, indem Sie die Elemente von "v" klonen.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Ordnen Sie ein `str` mit Referenzzählung zu und kopieren Sie `v` hinein.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Ordnen Sie ein `str` mit Referenzzählung zu und kopieren Sie `v` hinein.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Verschieben Sie ein Boxobjekt in eine neue Zuordnung mit Referenzzählung.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Ordnen Sie ein Slice mit Referenzzählung zu und verschieben Sie die Elemente von "v" hinein.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Lassen Sie den Vec seinen Speicher freigeben, aber zerstören Sie nicht seinen Inhalt
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Nimmt jedes Element im `Iterator` und sammelt es in einem `Arc<[T]>`.
    ///
    /// # Leistungsmerkmale
    ///
    /// ## Der allgemeine Fall
    ///
    /// Im allgemeinen Fall erfolgt das Sammeln in `Arc<[T]>`, indem zuerst in einem `Vec<T>` gesammelt wird.Das heißt, wenn Sie Folgendes schreiben:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// das verhält sich so, als hätten wir geschrieben:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Der erste Satz von Zuordnungen erfolgt hier.
    ///     .into(); // Hier erfolgt eine zweite Zuordnung für `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dadurch wird so oft wie nötig für die Erstellung des `Vec<T>` und dann einmal für die Umwandlung des `Vec<T>` in den `Arc<[T]>` zugewiesen.
    ///
    ///
    /// ## Iteratoren bekannter Länge
    ///
    /// Wenn Ihr `Iterator` `TrustedLen` implementiert und eine exakte Größe hat, wird eine einzelne Zuordnung für den `Arc<[T]>` vorgenommen.Beispielsweise:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Hier erfolgt nur eine einzige Zuordnung.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spezialisierung trait zum Sammeln in `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Dies ist bei einem `TrustedLen`-Iterator der Fall.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SICHERHEIT: Wir müssen sicherstellen, dass der Iterator eine exakte Länge hat und wir haben.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Auf die normale Implementierung zurückgreifen.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Holen Sie sich den Offset innerhalb eines `ArcInner` für die Nutzlast hinter einem Zeiger.
///
/// # Safety
///
/// Der Zeiger muss auf eine zuvor gültige Instanz von T zeigen (und gültige Metadaten für diese haben), aber das T darf gelöscht werden.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Richten Sie den Wert ohne Größe am Ende von ArcInner aus.
    // Da RcBox repr(C) ist, ist es immer das letzte Feld im Speicher.
    // SICHERHEIT: Da die einzigen möglichen Typen ohne Größe Slices, trait-Objekte,
    // Bei externen Typen reicht die Sicherheitsanforderung für die Eingabe derzeit aus, um die Anforderungen von align_of_val_raw zu erfüllen.Dies ist ein Implementierungsdetail der Sprache, auf das außerhalb von std möglicherweise nicht vertraut wird.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}