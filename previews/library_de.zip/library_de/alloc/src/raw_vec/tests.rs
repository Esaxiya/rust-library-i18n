use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Das Schreiben eines Integrationstests zwischen Allokatoren von Drittanbietern und `RawVec` ist etwas schwierig, da die `RawVec`-API keine fehlbaren Zuweisungsmethoden verfügbar macht. Daher können wir nicht überprüfen, was passiert, wenn der Allokator erschöpft ist (über das Erkennen eines panic hinaus).
    //
    //
    // Stattdessen wird nur überprüft, ob die `RawVec`-Methoden mindestens die Allocator-API durchlaufen, wenn sie Speicher reservieren.
    //
    //
    //
    //
    //

    // Ein dummer Allokator, der eine feste Menge Kraftstoff verbraucht, bevor die Allokationsversuche fehlschlagen.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (bewirkt eine Neuzuweisung, wodurch 50 + 150=200 Einheiten Kraftstoff verwendet werden)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Erstens weist `reserve` wie `reserve_exact` zu.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 ist mehr als das Doppelte von 7, daher sollte `reserve` wie `reserve_exact` funktionieren.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ist weniger als die Hälfte von 12, daher muss `reserve` exponentiell wachsen.
        // Zum Zeitpunkt des Schreibens beträgt dieser Testwachstumsfaktor 2, sodass die neue Kapazität 24 beträgt. Der Wachstumsfaktor von 1.5 ist jedoch ebenfalls in Ordnung.
        //
        // Daher `>= 18` in Assert.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}