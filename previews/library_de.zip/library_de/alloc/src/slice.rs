//! Eine dynamisch dimensionierte Ansicht in eine zusammenhängende Sequenz, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Slices sind eine Ansicht in einen Speicherblock, der als Zeiger und Länge dargestellt wird.
//!
//! ```
//! // Schneiden eines Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // Erzwingen eines Arrays zu einem Slice
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Slices sind entweder veränderlich oder werden gemeinsam genutzt.
//! Der gemeinsam genutzte Slice-Typ ist `&[T]`, während der veränderbare Slice-Typ `&mut [T]` ist, wobei `T` den Elementtyp darstellt.
//! Sie können beispielsweise den Speicherblock mutieren, auf den ein veränderbares Slice verweist:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hier sind einige der Dinge, die dieses Modul enthält:
//!
//! ## Structs
//!
//! Es gibt verschiedene Strukturen, die für Slices nützlich sind, z. B. [`Iter`], das die Iteration über ein Slice darstellt.
//!
//! ## Trait-Implementierungen
//!
//! Es gibt verschiedene Implementierungen von gemeinsamen traits für Slices.Einige Beispiele sind:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] für Slices, deren Elementtyp [`Eq`] oder [`Ord`] ist.
//! * [`Hash`] - für Slices, deren Elementtyp [`Hash`] ist.
//!
//! ## Iteration
//!
//! Die Slices implementieren `IntoIterator`.Der Iterator liefert Verweise auf die Slice-Elemente.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Die veränderbare Schicht liefert veränderbare Verweise auf die Elemente:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Dieser Iterator liefert veränderbare Verweise auf die Elemente des Slice. Während der Elementtyp des Slice `i32` ist, ist der Elementtyp des Iterators `&mut i32`.
//!
//!
//! * [`.iter`] und [`.iter_mut`] sind die expliziten Methoden zum Zurückgeben der Standarditeratoren.
//! * Weitere Methoden, die Iteratoren zurückgeben, sind [`.split`], [`.splitn`], [`.chunks`], [`.windows`] und mehr.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Viele der Verwendungen in diesem Modul werden nur in der Testkonfiguration verwendet.
// Es ist sauberer, die Warnung "unused_imports" einfach auszuschalten, als sie zu beheben.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Grundlegende Slice-Erweiterungsmethoden
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) Wird für die Implementierung des `vec!`-Makros während des Testens benötigt. Weitere Informationen finden Sie im `hack`-Modul in dieser Datei.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) Wird für die Implementierung von `Vec::clone` während des Testens benötigt. Weitere Informationen finden Sie im `hack`-Modul in dieser Datei.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Da cfg(test) `impl [T]` nicht verfügbar ist, sind diese drei Funktionen tatsächlich Methoden, die in `impl [T]`, aber nicht in `core::slice::SliceExt` enthalten sind. Wir müssen diese Funktionen für den `test_permutations`-Test bereitstellen
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Wir sollten dem kein Inline-Attribut hinzufügen, da dies hauptsächlich im `vec!`-Makro verwendet wird und eine Perf-Regression verursacht.
    // Siehe #71204 für Diskussion und Perf-Ergebnisse.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Elemente wurden in der folgenden Schleife als initialisiert markiert
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ist für LLVM erforderlich, um Grenzprüfungen zu entfernen, und hat einen besseren Codegen als zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // Der VEC wurde oben auf mindestens diese Länge zugewiesen und initialisiert.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // oben mit der Kapazität von `s` zugewiesen und in ptr::copy_to_non_overlapping unten auf `s.len()` initialisiert.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sortiert die Scheibe.
    ///
    /// Diese Sortierung ist stabil (dh ordnet nicht gleiche Elemente neu an) und *O*(*n*\*log(* n*)) Worst-Case).
    ///
    /// Falls zutreffend, wird eine instabile Sortierung bevorzugt, da sie im Allgemeinen schneller als eine stabile Sortierung ist und keinen zusätzlichen Speicher zuweist.
    /// Siehe [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus ist eine adaptive, iterative Zusammenführungssortierung, die von [timsort](https://en.wikipedia.org/wiki/Timsort) inspiriert ist.
    /// Es ist so konzipiert, dass es in Fällen, in denen das Slice fast sortiert ist oder aus zwei oder mehr nacheinander verketteten sortierten Sequenzen besteht, sehr schnell ist.
    ///
    ///
    /// Außerdem wird temporärer Speicher zugewiesen, der halb so groß wie `self` ist. Für kurze Slices wird jedoch stattdessen eine nicht zugeordnete Einfügungssortierung verwendet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sortiert das Slice mit einer Komparatorfunktion.
    ///
    /// Diese Sortierung ist stabil (dh ordnet nicht gleiche Elemente neu an) und *O*(*n*\*log(* n*)) Worst-Case).
    ///
    /// Die Komparatorfunktion muss eine Gesamtreihenfolge für die Elemente im Slice definieren.Wenn die Reihenfolge nicht vollständig ist, ist die Reihenfolge der Elemente nicht angegeben.
    /// Eine Bestellung ist eine Gesamtbestellung, wenn dies der Fall ist (für alle `a`, `b` und `c`):
    ///
    /// * total und antisymmetrisch: genau eines von `a < b`, `a == b` oder `a > b` ist wahr, und
    /// * transitiv, `a < b` und `b < c` implizieren `a < c`.Das Gleiche muss für `==` und `>` gelten.
    ///
    /// Während [`f64`] beispielsweise [`Ord`] aufgrund von `NaN != NaN` nicht implementiert, können wir `partial_cmp` als Sortierfunktion verwenden, wenn wir wissen, dass das Slice kein `NaN` enthält.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Falls zutreffend, wird eine instabile Sortierung bevorzugt, da sie im Allgemeinen schneller als eine stabile Sortierung ist und keinen zusätzlichen Speicher zuweist.
    /// Siehe [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus ist eine adaptive, iterative Zusammenführungssortierung, die von [timsort](https://en.wikipedia.org/wiki/Timsort) inspiriert ist.
    /// Es ist so konzipiert, dass es in Fällen, in denen das Slice fast sortiert ist oder aus zwei oder mehr nacheinander verketteten sortierten Sequenzen besteht, sehr schnell ist.
    ///
    /// Außerdem wird temporärer Speicher zugewiesen, der halb so groß wie `self` ist. Für kurze Slices wird jedoch stattdessen eine nicht zugeordnete Einfügungssortierung verwendet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // umgekehrte Sortierung
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sortiert das Slice mit einer Schlüsselextraktionsfunktion.
    ///
    /// Diese Sortierung ist stabil (dh ordnet nicht gleiche Elemente neu an) und *O*(*m*\* * n *\* log(*n*)) Worst-Case, wobei die Schlüsselfunktion *O*(*m*) ist.
    ///
    /// Für teure Tastenfunktionen (z
    /// Funktionen, bei denen es sich nicht um einfache Eigenschaftszugriffe oder grundlegende Operationen handelt, ist [`sort_by_cached_key`](slice::sort_by_cached_key) wahrscheinlich erheblich schneller, da Elementschlüssel nicht neu berechnet werden.
    ///
    ///
    /// Falls zutreffend, wird eine instabile Sortierung bevorzugt, da sie im Allgemeinen schneller als eine stabile Sortierung ist und keinen zusätzlichen Speicher zuweist.
    /// Siehe [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus ist eine adaptive, iterative Zusammenführungssortierung, die von [timsort](https://en.wikipedia.org/wiki/Timsort) inspiriert ist.
    /// Es ist so konzipiert, dass es in Fällen, in denen das Slice fast sortiert ist oder aus zwei oder mehr nacheinander verketteten sortierten Sequenzen besteht, sehr schnell ist.
    ///
    /// Außerdem wird temporärer Speicher zugewiesen, der halb so groß wie `self` ist. Für kurze Slices wird jedoch stattdessen eine nicht zugeordnete Einfügungssortierung verwendet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sortiert das Slice mit einer Schlüsselextraktionsfunktion.
    ///
    /// Während des Sortierens wird die Schlüsselfunktion nur einmal pro Element aufgerufen.
    ///
    /// Diese Sortierung ist stabil (dh ordnet nicht gleiche Elemente neu an) und *O*(*m*\* * n *+* n *\* log(*n*)) Worst-Case, wobei die Schlüsselfunktion *O*(*m*) ist. .
    ///
    /// Bei einfachen Schlüsselfunktionen (z. B. Funktionen, bei denen es sich um Eigenschaftszugriffe oder grundlegende Vorgänge handelt) ist [`sort_by_key`](slice::sort_by_key) wahrscheinlich schneller.
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus basiert auf [pattern-defeating quicksort][pdqsort] von Orson Peters, der den schnellen Durchschnittsfall von randomisiertem Quicksort mit dem schnellsten Worst-Fall von Heapsort kombiniert und gleichzeitig eine lineare Zeit für Slices mit bestimmten Mustern erreicht.
    /// Es verwendet eine Randomisierung, um entartete Fälle zu vermeiden, aber mit einem festen seed, um immer deterministisches Verhalten bereitzustellen.
    ///
    /// Im schlimmsten Fall weist der Algorithmus einen temporären Speicher in einem `Vec<(K, usize)>` der Länge des Slice zu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Hilfsmakro zum Indizieren unseres vector nach dem kleinstmöglichen Typ, um die Zuordnung zu reduzieren.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Die Elemente von `indices` sind eindeutig, da sie indiziert sind, sodass jede Sortierung in Bezug auf das ursprüngliche Slice stabil ist.
                // Wir verwenden hier `sort_unstable`, weil es weniger Speicherzuweisung erfordert.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopiert `self` in ein neues `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hier können `s` und `x` unabhängig voneinander geändert werden.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopiert `self` in einen neuen `Vec` mit einem Allokator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hier können `s` und `x` unabhängig voneinander geändert werden.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Hinweis: Weitere Informationen finden Sie im `hack`-Modul in dieser Datei.
        hack::to_vec(self, alloc)
    }

    /// Konvertiert `self` in einen vector ohne Klone oder Zuordnung.
    ///
    /// Der resultierende vector kann über `Vec wieder in eine Box umgewandelt werden<T>`into_boxed_slice`-Methode von`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kann nicht mehr verwendet werden, da es in `x` konvertiert wurde.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Hinweis: Weitere Informationen finden Sie im `hack`-Modul in dieser Datei.
        hack::into_vec(self)
    }

    /// Erstellt einen vector, indem ein Slice `n`-mal wiederholt wird.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn die Kapazität überlaufen würde.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Ein panic bei Überlauf:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Wenn `n` größer als Null ist, kann es als `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` aufgeteilt werden.
        // `2^expn` ist die Zahl, die durch das am weitesten links stehende '1'-Bit von `n` dargestellt wird, und `rem` ist der verbleibende Teil von `n`.
        //
        //

        // Verwenden von `Vec` für den Zugriff auf `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` Die Wiederholung erfolgt durch Verdoppeln der `buf`-Expn-Zeiten.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Bei `m > 0` verbleiben Bits bis zum '1' ganz links.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` hat eine Kapazität von `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) Wiederholung erfolgt durch Kopieren der ersten `rem`-Wiederholungen von `buf` selbst.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Dies ist seit `2^expn > rem` nicht überlappend.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` entspricht `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Glättet eine Scheibe von `T` in einen einzelnen Wert `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Glättet eine Scheibe von `T` in einen einzelnen Wert `Self::Output`, wobei jeweils ein bestimmtes Trennzeichen eingefügt wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Glättet eine Scheibe von `T` in einen einzelnen Wert `Self::Output`, wobei jeweils ein bestimmtes Trennzeichen eingefügt wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Gibt einen vector zurück, der eine Kopie dieses Slice enthält, wobei jedes Byte seinem ASCII-Großbuchstabenäquivalent zugeordnet ist.
    ///
    ///
    /// ASCII-Buchstaben 'a' bis 'z' werden 'A' bis 'Z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`make_ascii_uppercase`], um den Wert direkt in Großbuchstaben zu setzen.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Gibt einen vector zurück, der eine Kopie dieses Slice enthält, wobei jedes Byte seinem ASCII-Kleinbuchstabenäquivalent zugeordnet ist.
    ///
    ///
    /// ASCII-Buchstaben 'A' bis 'Z' werden 'a' bis 'z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`make_ascii_lowercase`], um den Wert an Ort und Stelle in Kleinbuchstaben zu schreiben.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Erweiterung traits für Slices über bestimmte Arten von Daten
////////////////////////////////////////////////////////////////////////////////

/// Helfer trait für [`[T]: : concat`](Slice::Concat).
///
/// Note: Der `Item`-Typparameter wird in diesem trait nicht verwendet, ermöglicht jedoch, dass Impls allgemeiner sind.
/// Ohne sie erhalten wir diesen Fehler:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Dies liegt daran, dass `V`-Typen mit mehreren `Borrow<[_]>`-Impls vorhanden sein können, sodass mehrere `T`-Typen zutreffen:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Der resultierende Typ nach der Verkettung
    type Output;

    /// Implementierung von [`[T]: : concat`](Slice::Concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helfer trait für [`[T]: : join`](Slice::Join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Der resultierende Typ nach der Verkettung
    type Output;

    /// Implementierung von [`[T]: : join`](Slice::Join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standard-trait-Implementierungen für Slices
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // Lassen Sie alles im Ziel fallen, das nicht überschrieben wird
        target.truncate(self.len());

        // target.len <= self.len aufgrund der obigen Kürzung, daher sind die Slices hier immer in Grenzen.
        //
        let (init, tail) = self.split_at(target.len());

        // Verwenden Sie die enthaltenen Werte allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Fügt `v[0]` in die vorsortierte Sequenz `v[1..]` ein, sodass das gesamte `v[..]` sortiert wird.
///
/// Dies ist das integrale Unterprogramm der Einfügesortierung.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Hier gibt es drei Möglichkeiten, das Einfügen zu implementieren:
            //
            // 1. Tauschen Sie benachbarte Elemente aus, bis das erste Ziel erreicht ist.
            //    Auf diese Weise kopieren wir jedoch mehr Daten als nötig.
            //    Wenn Elemente große Strukturen sind (das Kopieren ist teuer), ist diese Methode langsam.
            //
            // 2. Iterieren Sie, bis die richtige Stelle für das erste Element gefunden ist.
            // Verschieben Sie dann die nachfolgenden Elemente, um Platz dafür zu schaffen, und platzieren Sie sie schließlich in dem verbleibenden Loch.
            // Dies ist eine gute Methode.
            //
            // 3. Kopieren Sie das erste Element in eine temporäre Variable.Iterieren Sie, bis der richtige Ort dafür gefunden ist.
            // Kopieren Sie im weiteren Verlauf jedes durchquerte Element in den vorhergehenden Slot.
            // Kopieren Sie abschließend Daten aus der temporären Variablen in das verbleibende Loch.
            // Diese Methode ist sehr gut.
            // Benchmarks zeigten eine etwas bessere Leistung als bei der 2. Methode.
            //
            // Alle Methoden wurden verglichen und die dritte zeigte die besten Ergebnisse.Also haben wir uns für diesen entschieden.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Der Zwischenzustand des Einfügevorgangs wird immer von `hole` verfolgt, was zwei Zwecken dient:
            // 1. Schützt die Integrität von `v` vor panics in `is_less`.
            // 2. Füllt am Ende das verbleibende Loch in `v`.
            //
            // Panic Sicherheit:
            //
            // Wenn `is_less` panics zu irgendeinem Zeitpunkt während des Vorgangs gelöscht wird, wird `hole` fallen gelassen und das Loch in `v` mit `tmp` gefüllt, wodurch sichergestellt wird, dass `v` immer noch jedes Objekt enthält, das es ursprünglich genau einmal gehalten hat.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` wird fallen gelassen und kopiert somit `tmp` in das verbleibende Loch in `v`.
        }
    }

    // Nach dem Löschen werden Kopien von `src` in `dest` kopiert.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Führt nicht abnehmende Läufe `v[..mid]` und `v[mid..]` unter Verwendung von `buf` als temporären Speicher zusammen und speichert das Ergebnis in `v[..]`.
///
/// # Safety
///
/// Die beiden Slices dürfen nicht leer sein und `mid` muss begrenzt sein.
/// Der Puffer `buf` muss lang genug sein, um eine Kopie des kürzeren Slice aufzunehmen.
/// Außerdem darf `T` kein Typ mit der Größe Null sein.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Der Zusammenführungsprozess kopiert zuerst die kürzere Auflage in `buf`.
    // Anschließend werden der neu kopierte Lauf und der längere Lauf vorwärts (oder rückwärts) verfolgt, die nächsten nicht verbrauchten Elemente verglichen und das kleinere (oder größere) in `v` kopiert.
    //
    // Sobald der kürzere Lauf vollständig verbraucht ist, ist der Vorgang abgeschlossen.Wenn der längere Lauf zuerst verbraucht wird, müssen wir alles, was vom kürzeren Lauf übrig ist, in das verbleibende Loch in `v` kopieren.
    //
    // Der Zwischenzustand des Prozesses wird immer von `hole` verfolgt, was zwei Zwecken dient:
    // 1. Schützt die Integrität von `v` vor panics in `is_less`.
    // 2. Füllt das verbleibende Loch in `v`, wenn der längere Lauf zuerst verbraucht wird.
    //
    // Panic Sicherheit:
    //
    // Wenn `is_less` panics zu irgendeinem Zeitpunkt während des Prozesses fallen gelassen wird, füllt `hole` das Loch in `v` mit dem nicht verbrauchten Bereich in `buf` und stellt so sicher, dass `v` immer noch jedes Objekt enthält, das es ursprünglich genau einmal gehalten hat.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Der linke Lauf ist kürzer.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Anfangs zeigen diese Zeiger auf die Anfänge ihrer Arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Verbrauchen Sie die kleinere Seite.
            // Wenn gleich, bevorzugen Sie den linken Lauf, um die Stabilität aufrechtzuerhalten.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Der richtige Lauf ist kürzer.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Anfangs zeigen diese Zeiger über die Enden ihrer Arrays hinaus.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Verbrauchen Sie die größere Seite.
            // Wenn gleich, bevorzugen Sie den richtigen Lauf, um die Stabilität aufrechtzuerhalten.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Schließlich wird `hole` fallen gelassen.
    // Wenn der kürzere Lauf nicht vollständig verbraucht wurde, wird alles, was davon übrig bleibt, jetzt in das Loch in `v` kopiert.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Wenn es gelöscht wird, kopiert es den Bereich `start..end` in `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ist kein Typ mit der Größe Null, daher ist es in Ordnung, durch seine Größe zu teilen.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Diese Zusammenführungssortierung leiht einige (aber nicht alle) Ideen von TimSort aus, das ausführlich in [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) beschrieben wird.
///
///
/// Der Algorithmus identifiziert streng absteigende und nicht absteigende Teilsequenzen, die als natürliche Läufe bezeichnet werden.Es gibt einen Stapel ausstehender Läufe, die noch zusammengeführt werden müssen.
/// Jeder neu gefundene Lauf wird auf den Stapel geschoben, und dann werden einige Paare benachbarter Läufe zusammengeführt, bis diese beiden Invarianten erfüllt sind:
///
/// 1. für jeden `i` in `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. für jeden `i` in `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Die Invarianten stellen sicher, dass die Gesamtlaufzeit *O*(*n*\*log(* n*)) Worst-Case) beträgt.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Scheiben bis zu dieser Länge werden mithilfe der Einfügesortierung sortiert.
    const MAX_INSERTION: usize = 20;
    // Sehr kurze Auflagen werden mithilfe der Einfügesortierung erweitert, um mindestens so viele Elemente zu überspannen.
    const MIN_RUN: usize = 10;

    // Das Sortieren hat bei Typen mit der Größe Null kein aussagekräftiges Verhalten.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Kurze Arrays werden über die Einfügesortierung an Ort und Stelle sortiert, um Zuordnungen zu vermeiden.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Weisen Sie einen Puffer zu, der als Arbeitsspeicher verwendet werden soll.Wir behalten die Länge 0 bei, damit wir flache Kopien des Inhalts von `v` darin behalten können, ohne zu riskieren, dass die dtors auf Kopien laufen, wenn `is_less` panics.
    //
    // Beim Zusammenführen von zwei sortierten Läufen enthält dieser Puffer eine Kopie des kürzeren Laufs, der immer höchstens `len / 2` lang ist.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Um natürliche Läufe in `v` zu identifizieren, durchlaufen wir sie rückwärts.
    // Das mag seltsam erscheinen, aber bedenken Sie, dass Zusammenführungen häufiger in die entgegengesetzte Richtung (forwards) gehen.
    // Laut Benchmarks ist das Vorwärtsverschmelzen etwas schneller als das Rückwärtsschmelzen.
    // Zusammenfassend lässt sich sagen, dass das Identifizieren von Läufen durch Rückwärtsfahren die Leistung verbessert.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Finden Sie den nächsten natürlichen Lauf und kehren Sie ihn um, wenn er streng absteigend ist.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Fügen Sie weitere Elemente in den Lauf ein, wenn dieser zu kurz ist.
        // Die Einfügesortierung ist bei kurzen Sequenzen schneller als die Zusammenführungssortierung, wodurch die Leistung erheblich verbessert wird.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Schieben Sie diesen Lauf auf den Stapel.
        runs.push(Run { start, len: end - start });
        end = start;

        // Füge einige Paare benachbarter Läufe zusammen, um die Invarianten zu befriedigen.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Schließlich muss genau ein Lauf im Stapel verbleiben.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Untersucht den Stapel von Läufen und identifiziert das nächste Paar von Läufen, die zusammengeführt werden sollen.
    // Wenn `Some(r)` zurückgegeben wird, bedeutet dies, dass `runs[r]` und `runs[r + 1]` als Nächstes zusammengeführt werden müssen.
    // Wenn der Algorithmus stattdessen weiterhin einen neuen Lauf erstellen soll, wird `None` zurückgegeben.
    //
    // TimSort ist berüchtigt für seine fehlerhaften Implementierungen, wie hier beschrieben:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Der Kern der Geschichte lautet: Wir müssen die Invarianten in den ersten vier Läufen des Stapels erzwingen.
    // Es reicht nicht aus, sie nur unter die ersten drei zu bringen, um sicherzustellen, dass die Invarianten weiterhin für *alle* Läufe im Stapel gelten.
    //
    // Diese Funktion überprüft die Invarianten korrekt für die ersten vier Läufe.
    // Wenn der oberste Lauf bei Index 0 beginnt, wird immer eine Zusammenführungsoperation angefordert, bis der Stapel vollständig reduziert ist, um die Sortierung abzuschließen.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}