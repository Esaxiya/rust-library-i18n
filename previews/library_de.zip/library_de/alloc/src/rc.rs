//! Single-Threaded-Referenzzählzeiger.'Rc' steht für 'Reference
//! Counted'.
//!
//! Der Typ [`Rc<T>`][`Rc`] bietet das gemeinsame Eigentum an einem Wert vom Typ `T`, der im Heap zugewiesen ist.
//! Wenn Sie [`clone`][clone] unter [`Rc`] aufrufen, wird ein neuer Zeiger auf dieselbe Zuordnung im Heap erstellt.
//! Wenn der letzte [`Rc`]-Zeiger auf eine bestimmte Zuordnung zerstört wird, wird auch der in dieser Zuordnung gespeicherte Wert (häufig als "inner value" bezeichnet) gelöscht.
//!
//! Freigegebene Referenzen in Rust verbieten standardmäßig die Mutation, und [`Rc`] ist keine Ausnahme: Sie können im Allgemeinen keine veränderbare Referenz auf etwas in einem [`Rc`] erhalten.
//! Wenn Sie Veränderlichkeit benötigen, setzen Sie einen [`Cell`] oder [`RefCell`] in den [`Rc`] ein.siehe [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] verwendet nichtatomare Referenzzählung.
//! Dies bedeutet, dass der Overhead sehr gering ist, aber ein [`Rc`] nicht zwischen Threads gesendet werden kann und folglich [`Rc`] [`Send`][send] nicht implementiert.
//! Infolgedessen überprüft der Rust-Compiler *zur Kompilierungszeit*, ob Sie keine [`Rc`] zwischen Threads senden.
//! Wenn Sie eine atomare Referenzzählung mit mehreren Threads benötigen, verwenden Sie [`sync::Arc`][arc].
//!
//! Mit der [`downgrade`][downgrade]-Methode kann ein nicht besitzender [`Weak`]-Zeiger erstellt werden.
//! Ein [`Weak`]-Zeiger kann [`upgrade`][upgrade] d auf einen [`Rc`] sein, dies gibt jedoch [`None`] zurück, wenn der in der Zuordnung gespeicherte Wert bereits gelöscht wurde.
//! Mit anderen Worten, `Weak`-Zeiger halten den Wert innerhalb der Zuordnung nicht am Leben.Sie *halten* jedoch die Zuordnung (den Hintergrundspeicher für den inneren Wert) am Leben.
//!
//! Ein Zyklus zwischen [`Rc`]-Zeigern wird niemals freigegeben.
//! Aus diesem Grund wird [`Weak`] verwendet, um Zyklen zu unterbrechen.
//! Beispielsweise könnte ein Baum starke [`Rc`]-Zeiger von übergeordneten Knoten zu untergeordneten Knoten und [`Weak`]-Zeiger von untergeordneten Knoten zu ihren übergeordneten Knoten aufweisen.
//!
//! `Rc<T>` Automatische Dereferenzen zu `T` (über [`Deref`] trait), sodass Sie die Methoden von `T` für einen Wert vom Typ [`Rc<T>`][`Rc`] aufrufen können.
//! Um Namenskonflikte mit den Methoden von `T` zu vermeiden, sind die Methoden von [`Rc<T>`][`Rc`] selbst zugeordnete Funktionen, die mit [fully qualified syntax] aufgerufen werden:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Die Implementierungen von traits wie `Clone` können auch mit vollständig qualifizierter Syntax aufgerufen werden.
//! Einige Leute bevorzugen die Verwendung einer vollständig qualifizierten Syntax, während andere die Syntax des Methodenaufrufs bevorzugen.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntax für Methodenaufrufe
//! let rc2 = rc.clone();
//! // Vollqualifizierte Syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] führt keine automatische Dereferenzierung zu `T` durch, da der innere Wert möglicherweise bereits gelöscht wurde.
//!
//! # Klonen von Referenzen
//!
//! Das Erstellen einer neuen Referenz auf dieselbe Zuordnung wie ein vorhandener Referenzzählzeiger erfolgt mit dem für [`Rc<T>`][`Rc`] und [`Weak<T>`][`Weak`] implementierten `Clone` trait.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Die beiden folgenden Syntaxen sind äquivalent.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a und b zeigen beide auf den gleichen Speicherort wie foo.
//! ```
//!
//! Die `Rc::clone(&from)`-Syntax ist die idiomatischste, da sie die Bedeutung des Codes expliziter vermittelt.
//! Im obigen Beispiel erleichtert diese Syntax das Erkennen, dass dieser Code eine neue Referenz erstellt, anstatt den gesamten Inhalt von foo zu kopieren.
//!
//! # Examples
//!
//! Stellen Sie sich ein Szenario vor, in dem eine Reihe von Gadgets einem bestimmten `Owner` gehören.
//! Wir möchten, dass unser "Gadget" auf das `Owner` zeigt.Wir können dies nicht mit einem eindeutigen Besitz tun, da möglicherweise mehr als ein Gadget zum selben `Owner` gehört.
//! [`Rc`] Ermöglicht es uns, ein `Owner` für mehrere Gadgets freizugeben und das `Owner` so lange zuzuweisen, wie `Gadget` darauf zeigt.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ...andere Felder
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...andere Felder
//! }
//!
//! fn main() {
//!     // Erstellen Sie einen `Owner` mit Referenzzählung.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Erstellen Sie Gadgets, die zu `gadget_owner` gehören.
//!     // Durch das Klonen des `Rc<Owner>` erhalten wir einen neuen Zeiger auf dieselbe `Owner`-Zuordnung, wodurch der Referenzzähler erhöht wird.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Entsorgen Sie unsere lokale Variable `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Obwohl wir `gadget_owner` fallen lassen, können wir den Namen des `Owner` des Gadgets immer noch ausdrucken.
//!     // Dies liegt daran, dass wir nur ein einziges `Rc<Owner>` gelöscht haben, nicht das `Owner`, auf das es zeigt.
//!     // Solange andere `Rc<Owner>` auf dieselbe `Owner`-Zuordnung zeigen, bleibt sie aktiv.
//!     // Die Feldprojektion `gadget1.owner.name` funktioniert, da `Rc<Owner>` automatisch auf `Owner` dereferenziert.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Am Ende der Funktion werden `gadget1` und `gadget2` zerstört und mit ihnen die zuletzt gezählten Verweise auf unser `Owner`.
//!     // Gadget Man wird jetzt ebenfalls zerstört.
//!     //
//! }
//! ```
//!
//! Wenn sich unsere Anforderungen ändern und wir auch in der Lage sein müssen, von `Owner` zu `Gadget` zu wechseln, werden wir auf Probleme stoßen.
//! Ein [`Rc`]-Zeiger von `Owner` auf `Gadget` führt einen Zyklus ein.
//! Dies bedeutet, dass ihre Referenzzählungen niemals 0 erreichen können und die Zuordnung niemals zerstört wird:
//! ein Speicherverlust.Um dies zu umgehen, können wir [`Weak`]-Zeiger verwenden.
//!
//! Rust macht es tatsächlich etwas schwierig, diese Schleife überhaupt zu erzeugen.Um zwei Werte zu erhalten, die aufeinander zeigen, muss einer von ihnen veränderbar sein.
//! Dies ist schwierig, da [`Rc`] die Speichersicherheit erzwingt, indem nur gemeinsame Verweise auf den Wert ausgegeben werden, den es umschließt, und diese keine direkte Mutation zulassen.
//! Wir müssen den Teil des Werts, den wir mutieren möchten, in ein [`RefCell`] einschließen, das *innere Mutabilität* bietet: eine Methode, um Mutabilität durch eine gemeinsame Referenz zu erreichen.
//! [`RefCell`] Erzwingt die Ausleihregeln von Rust zur Laufzeit.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ...andere Felder
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ...andere Felder
//! }
//!
//! fn main() {
//!     // Erstellen Sie einen `Owner` mit Referenzzählung.
//!     // Beachten Sie, dass wir das vector des "Besitzers" von "Gadget" in ein `RefCell` eingefügt haben, damit wir es durch eine gemeinsame Referenz mutieren können.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Erstellen Sie wie zuvor `Gadget`s, die zu `gadget_owner` gehören.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Fügen Sie die "Gadgets" zu ihrem `Owner` hinzu.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` Hier endet die dynamische Ausleihe.
//!     }
//!
//!     // Iterieren Sie über unsere "Gadgets" und drucken Sie deren Details aus.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ist ein `Weak<Gadget>`.
//!         // Da `Weak`-Zeiger nicht garantieren können, dass die Zuordnung noch vorhanden ist, müssen wir `upgrade` aufrufen, das ein `Option<Rc<Gadget>>` zurückgibt.
//!         //
//!         //
//!         // In diesem Fall wissen wir, dass die Zuordnung noch vorhanden ist, also `unwrap` einfach die `Option`.
//!         // In einem komplizierteren Programm benötigen Sie möglicherweise eine ordnungsgemäße Fehlerbehandlung für ein `None`-Ergebnis.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Am Ende der Funktion werden `gadget_owner`, `gadget1` und `gadget2` zerstört.
//!     // Es gibt jetzt keine starken (`Rc`)-Zeiger auf die Gadgets, sodass sie zerstört werden.
//!     // Dadurch wird der Referenzzähler für Gadget Man auf Null gesetzt, sodass er ebenfalls zerstört wird.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Dies ist repr(C) bis future-sicher gegen mögliche Feldumordnungen, die das ansonsten sichere [into|from]_raw() transmutierbarer innerer Typen beeinträchtigen würden.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Ein Single-Threaded-Referenzzählzeiger.'Rc' steht für 'Reference
/// Counted'.
///
/// Weitere Informationen finden Sie im [module-level documentation](./index.html).
///
/// Die inhärenten Methoden von `Rc` sind alle zugeordneten Funktionen, was bedeutet, dass Sie sie als z. B. [`Rc::get_mut(&mut value)`][get_mut] anstelle von `value.get_mut()` aufrufen müssen.
/// Dies vermeidet Konflikte mit Methoden des inneren Typs `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Diese Unsicherheit ist in Ordnung, denn während dieser Rc lebt, ist garantiert, dass der innere Zeiger gültig ist.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Erstellt einen neuen `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Es gibt einen impliziten schwachen Zeiger, der allen starken Zeigern gehört, wodurch sichergestellt wird, dass der schwache Destruktor die Zuordnung niemals freigibt, während der starke Destruktor ausgeführt wird, selbst wenn der schwache Zeiger im starken Zeiger gespeichert ist.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstruiert einen neuen `Rc<T>` unter Verwendung eines schwachen Verweises auf sich selbst.
    /// Der Versuch, die schwache Referenz zu aktualisieren, bevor diese Funktion zurückkehrt, führt zu einem `None`-Wert.
    ///
    /// Die schwache Referenz kann jedoch frei geklont und zur späteren Verwendung gespeichert werden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... mehr Felder
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstruieren Sie das Innere im "uninitialized"-Zustand mit einer einzigen schwachen Referenz.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Es ist wichtig, dass wir den Besitz des schwachen Zeigers nicht aufgeben, da sonst der Speicher bei der Rückkehr von `data_fn` möglicherweise freigegeben wird.
        // Wenn wir wirklich das Eigentum übergeben wollten, könnten wir einen zusätzlichen schwachen Zeiger für uns selbst erstellen, aber dies würde zu zusätzlichen Aktualisierungen des schwachen Referenzzählers führen, die sonst möglicherweise nicht notwendig wären.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Starke Referenzen sollten zusammen eine gemeinsame schwache Referenz besitzen. Führen Sie daher den Destruktor für unsere alte schwache Referenz nicht aus.
        //
        mem::forget(weak);
        strong
    }

    /// Erstellt einen neuen `Rc` mit nicht initialisierten Inhalten.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Erstellt ein neues `Rc` mit nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Erstellt einen neuen `Rc<T>` und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Es gibt einen impliziten schwachen Zeiger, der allen starken Zeigern gehört, wodurch sichergestellt wird, dass der schwache Destruktor die Zuordnung niemals freigibt, während der starke Destruktor ausgeführt wird, selbst wenn der schwache Zeiger im starken Zeiger gespeichert ist.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Erstellt einen neuen `Rc` mit nicht initialisiertem Inhalt und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Erstellt ein neues `Rc` mit nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist, und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Erstellt einen neuen `Pin<Rc<T>>`.
    /// Wenn `T` `Unpin` nicht implementiert, wird `value` im Speicher fixiert und kann nicht verschoben werden.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Gibt den inneren Wert zurück, wenn der `Rc` genau eine starke Referenz hat.
    ///
    /// Andernfalls wird ein [`Err`] mit demselben `Rc` zurückgegeben, der übergeben wurde.
    ///
    ///
    /// Dies wird auch dann erfolgreich sein, wenn herausragende schwache Referenzen vorliegen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // Kopieren Sie das enthaltene Objekt

                // Zeigen Sie Weaks an, dass sie nicht durch Verringern der starken Anzahl befördert werden können, und entfernen Sie dann den impliziten "strong weak"-Zeiger, während Sie gleichzeitig die Drop-Logik behandeln, indem Sie einfach einen gefälschten Weak erstellen.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Erstellt ein neues Slice mit Referenzzählung und nicht initialisiertem Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Erstellt ein neues Slice mit Referenzzählung und nicht initialisiertem Inhalt, wobei der Speicher mit `0`-Bytes gefüllt ist.
    ///
    ///
    /// In [`MaybeUninit::zeroed`][zeroed] finden Sie Beispiele für die korrekte und falsche Verwendung dieser Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konvertiert in `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Wie bei [`MaybeUninit::assume_init`] muss der Anrufer sicherstellen, dass sich der innere Wert tatsächlich in einem initialisierten Zustand befindet.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, tritt sofort undefiniertes Verhalten auf.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konvertiert in `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Wie bei [`MaybeUninit::assume_init`] muss der Anrufer sicherstellen, dass sich der innere Wert tatsächlich in einem initialisierten Zustand befindet.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, tritt sofort undefiniertes Verhalten auf.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Aufgeschobene Initialisierung:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Verbraucht den `Rc` und gibt den umgebrochenen Zeiger zurück.
    ///
    /// Um einen Speicherverlust zu vermeiden, muss der Zeiger mit [`Rc::from_raw`][from_raw] wieder in einen `Rc` konvertiert werden.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Stellt einen Rohzeiger auf die Daten bereit.
    ///
    /// Die Anzahl wird in keiner Weise beeinflusst und der `Rc` wird nicht verbraucht.
    /// Der Zeiger ist so lange gültig, wie es im `Rc` starke Zählungen gibt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SICHERHEIT: Dies kann nicht über Deref::deref oder Rc::inner gehen, weil
        // Dies ist erforderlich, um die raw/mut-Herkunft so zu erhalten, dass z
        // `get_mut` kann durch den Zeiger schreiben, nachdem der Rc durch `from_raw` wiederhergestellt wurde.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstruiert ein `Rc<T>` aus einem Rohzeiger.
    ///
    /// Der Rohzeiger muss zuvor durch einen Aufruf von [`Rc<U>::into_raw`][into_raw] zurückgegeben worden sein, wobei `U` dieselbe Größe und Ausrichtung wie `T` haben muss.
    /// Dies ist trivial wahr, wenn `U` `T` ist.
    /// Beachten Sie, dass wenn `U` nicht `T` ist, aber dieselbe Größe und Ausrichtung hat, dies im Grunde wie das Umwandeln von Referenzen verschiedener Typen ist.
    /// Weitere Informationen zu den in diesem Fall geltenden Einschränkungen finden Sie unter [`mem::transmute`][transmute].
    ///
    /// Der Benutzer von `from_raw` muss sicherstellen, dass ein bestimmter Wert von `T` nur einmal gelöscht wird.
    ///
    /// Diese Funktion ist unsicher, da eine unsachgemäße Verwendung zu einer Unsicherheit des Speichers führen kann, selbst wenn auf den zurückgegebenen `Rc<T>` nie zugegriffen wird.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertieren Sie zurück zu einem `Rc`, um Leckagen zu vermeiden.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Weitere Aufrufe von `Rc::from_raw(x_ptr)` wären speichersicher.
    /// }
    ///
    /// // Der Speicher wurde freigegeben, als `x` den oben genannten Bereich verlassen hat, sodass `x_ptr` jetzt baumelt!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Kehren Sie den Versatz um, um die ursprüngliche RcBox zu finden.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Erstellt einen neuen [`Weak`]-Zeiger auf diese Zuordnung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Stellen Sie sicher, dass wir keine baumelnden Schwachen schaffen
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ruft die Anzahl der [`Weak`]-Zeiger auf diese Zuordnung ab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ruft die Anzahl der starken (`Rc`)-Zeiger auf diese Zuordnung ab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Gibt `true` zurück, wenn keine anderen `Rc`-oder [`Weak`]-Zeiger auf diese Zuordnung vorhanden sind.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Gibt eine veränderbare Referenz in das angegebene `Rc` zurück, wenn keine anderen `Rc`-oder [`Weak`]-Zeiger auf dieselbe Zuordnung vorhanden sind.
    ///
    ///
    /// Gibt ansonsten [`None`] zurück, da es nicht sicher ist, einen gemeinsam genutzten Wert zu mutieren.
    ///
    /// Siehe auch [`make_mut`][make_mut], wodurch der innere Wert [`clone`][clone] wird, wenn andere Zeiger vorhanden sind.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Gibt ohne Änderung eine veränderbare Referenz in das angegebene `Rc` zurück.
    ///
    /// Siehe auch [`get_mut`], das sicher ist und entsprechende Überprüfungen durchführt.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Alle anderen `Rc`-oder [`Weak`]-Zeiger auf dieselbe Zuordnung dürfen für die Dauer der zurückgegebenen Ausleihe nicht dereferenziert werden.
    ///
    /// Dies ist trivial der Fall, wenn solche Zeiger beispielsweise unmittelbar nach `Rc::new` nicht vorhanden sind.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Wir achten darauf,*keine* Referenz zu erstellen, die die "count"-Felder abdeckt, da dies zu Konflikten mit den Zugriffen auf die Referenzzählungen führen würde (z
        // von `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Gibt `true` zurück, wenn die beiden Rc auf dieselbe Zuordnung zeigen (ähnlich wie bei [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Macht eine veränderbare Referenz in das gegebene `Rc`.
    ///
    /// Wenn es andere `Rc`-Zeiger auf dieselbe Zuordnung gibt, wird `make_mut` den inneren Wert für eine neue Zuordnung [`clone`], um eine eindeutige Eigentümerschaft sicherzustellen.
    /// Dies wird auch als Clone-on-Write bezeichnet.
    ///
    /// Wenn es keine anderen `Rc`-Zeiger auf diese Zuordnung gibt, werden [`Weak`]-Zeiger auf diese Zuordnung getrennt.
    ///
    /// Siehe auch [`get_mut`], das fehlschlägt und nicht klont.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Klont nichts
    /// let mut other_data = Rc::clone(&data);    // Klont keine inneren Daten
    /// *Rc::make_mut(&mut data) += 1;        // Klont innere Daten
    /// *Rc::make_mut(&mut data) += 1;        // Klont nichts
    /// *Rc::make_mut(&mut other_data) *= 2;  // Klont nichts
    ///
    /// // Jetzt zeigen `data` und `other_data` auf unterschiedliche Zuordnungen.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] Zeiger werden getrennt:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Muss die Daten klonen, es gibt andere Rcs.
            // Ordnen Sie den Speicher vorab zu, damit der geklonte Wert direkt geschrieben werden kann.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kann nur die Daten stehlen, alles was übrig bleibt ist Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Entfernen Sie implizite stark-schwache Ref (hier müssen Sie keine gefälschten Schwachstellen herstellen-wir wissen, dass andere Schwachstellen für uns aufräumen können)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Diese Unsicherheit ist in Ordnung, da wir garantiert haben, dass der zurückgegebene Zeiger der *einzige* Zeiger ist, der jemals an T zurückgegeben wird.
        // Zu diesem Zeitpunkt ist unser Referenzzähler garantiert 1, und wir haben verlangt, dass der `Rc<T>` selbst `mut` ist, sodass wir den einzig möglichen Verweis auf die Zuordnung zurückgeben.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Versuchen Sie, den `Rc<dyn Any>` auf einen konkreten Typ herunterzuspielen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Weist einen `RcBox<T>` mit ausreichend Platz für einen möglicherweise nicht dimensionierten inneren Wert zu, für den der Wert das bereitgestellte Layout enthält.
    ///
    /// Die Funktion `mem_to_rcbox` wird mit dem Datenzeiger aufgerufen und muss einen (möglicherweise fetten) Zeiger für den `RcBox<T>` zurückgeben.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Berechnen Sie das Layout mit dem angegebenen Wertelayout.
        // Bisher wurde das Layout für den Ausdruck `&*(ptr as* const RcBox<T>)` berechnet, dies führte jedoch zu einer falsch ausgerichteten Referenz (siehe #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Weist einem `RcBox<T>` ausreichend Speicherplatz für einen möglicherweise nicht dimensionierten inneren Wert zu, für den das Layout des Layouts bereitgestellt wurde, und gibt einen Fehler zurück, wenn die Zuordnung fehlschlägt.
    ///
    ///
    /// Die Funktion `mem_to_rcbox` wird mit dem Datenzeiger aufgerufen und muss einen (möglicherweise fetten) Zeiger für den `RcBox<T>` zurückgeben.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Berechnen Sie das Layout mit dem angegebenen Wertelayout.
        // Bisher wurde das Layout für den Ausdruck `&*(ptr as* const RcBox<T>)` berechnet, dies führte jedoch zu einer falsch ausgerichteten Referenz (siehe #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Ordnen Sie das Layout zu.
        let ptr = allocate(layout)?;

        // Initialisieren Sie die RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Weist einem `RcBox<T>` ausreichend Platz für einen nicht dimensionierten inneren Wert zu
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Ordnen Sie dem `RcBox<T>` den angegebenen Wert zu.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Wert als Bytes kopieren
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Geben Sie die Zuordnung frei, ohne den Inhalt zu löschen
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Weist einen `RcBox<[T]>` mit der angegebenen Länge zu.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopieren Sie Elemente aus dem Slice in das neu zugewiesene Rc <\[T\]>
    ///
    /// Unsicher, da der Anrufer entweder das Eigentum übernehmen oder `T: Copy` binden muss
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstruiert einen `Rc<[T]>` aus einem Iterator, von dem bekannt ist, dass er eine bestimmte Größe hat.
    ///
    /// Das Verhalten ist undefiniert, sollte die Größe falsch sein.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic-Schutz beim Klonen von T-Elementen.
        // Bei einem panic werden Elemente, die in die neue RcBox geschrieben wurden, gelöscht und der Speicher freigegeben.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Zeiger auf erstes Element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles klar.Vergiss die Wache, damit die neue RcBox nicht frei wird.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spezialisierung trait für `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Lässt den `Rc` fallen.
    ///
    /// Dies verringert den starken Referenzzähler.
    /// Wenn der starke Referenzzähler Null erreicht, sind die einzigen anderen Referenzen (falls vorhanden) [`Weak`], also `drop` der innere Wert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Druckt nichts
    /// drop(foo2);   // Druckt "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // zerstöre das enthaltene Objekt
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // Entfernen Sie den impliziten "strong weak"-Zeiger, nachdem wir den Inhalt zerstört haben.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Erstellt einen Klon des `Rc`-Zeigers.
    ///
    /// Dadurch wird ein weiterer Zeiger auf dieselbe Zuordnung erstellt, wodurch die Anzahl der starken Referenzen erhöht wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Erstellt einen neuen `Rc<T>` mit dem `Default`-Wert für `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack, um die Spezialisierung auf `Eq` zu ermöglichen, obwohl `Eq` eine Methode hat.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Wir machen diese Spezialisierung hier und nicht als allgemeinere Optimierung für `&T`, da dies sonst alle Gleichheitsprüfungen für Refs kosten würde.
/// Wir gehen davon aus, dass `Rc`s verwendet werden, um große Werte zu speichern, die langsam zu klonen sind, aber auch schwer auf Gleichheit zu prüfen sind, wodurch sich diese Kosten leichter auszahlen.
///
/// Es ist auch wahrscheinlicher, dass zwei `Rc`-Klone auf denselben Wert verweisen als zwei `&T`s.
///
/// Wir können dies nur tun, wenn `T: Eq` als `PartialEq` absichtlich irreflexiv ist.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Gleichheit für zwei `Rc`s.
    ///
    /// Zwei `Rc`s sind gleich, wenn ihre inneren Werte gleich sind, selbst wenn sie in unterschiedlicher Zuordnung gespeichert sind.
    ///
    /// Wenn `T` auch `Eq` implementiert (was Reflexivität der Gleichheit impliziert), sind zwei `Rc`s, die auf dieselbe Zuordnung zeigen, immer gleich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ungleichung für zwei `Rc`s.
    ///
    /// Zwei `Rc`s sind ungleich, wenn ihre inneren Werte ungleich sind.
    ///
    /// Wenn `T` auch `Eq` implementiert (was Reflexivität der Gleichheit impliziert), sind zwei "Rc", die auf dieselbe Zuordnung zeigen, niemals ungleich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Teilvergleich für zwei `Rc`s.
    ///
    /// Die beiden werden verglichen, indem `partial_cmp()` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Weniger als Vergleich für zwei `Rc`s.
    ///
    /// Die beiden werden verglichen, indem `<` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Vergleich 'kleiner oder gleich' für zwei `Rc`s.
    ///
    /// Die beiden werden verglichen, indem `<=` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Größer als der Vergleich für zwei `Rc`s.
    ///
    /// Die beiden werden verglichen, indem `>` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Vergleich 'größer oder gleich' für zwei `Rc`s.
    ///
    /// Die beiden werden verglichen, indem `>=` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Vergleich für zwei `Rc`s.
    ///
    /// Die beiden werden verglichen, indem `cmp()` auf ihre inneren Werte aufgerufen wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Ordnen Sie ein Slice mit Referenzzählung zu und füllen Sie es, indem Sie die Elemente von "v" klonen.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Ordnen Sie ein String-Slice mit Referenzzählung zu und kopieren Sie `v` hinein.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Ordnen Sie ein String-Slice mit Referenzzählung zu und kopieren Sie `v` hinein.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Verschieben Sie ein Boxobjekt in eine neue Zuordnung mit Referenzzählung.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Ordnen Sie ein Slice mit Referenzzählung zu und verschieben Sie die Elemente von "v" hinein.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Lassen Sie den Vec seinen Speicher freigeben, aber zerstören Sie nicht seinen Inhalt
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Nimmt jedes Element im `Iterator` und sammelt es in einem `Rc<[T]>`.
    ///
    /// # Leistungsmerkmale
    ///
    /// ## Der allgemeine Fall
    ///
    /// Im allgemeinen Fall erfolgt das Sammeln in `Rc<[T]>`, indem zuerst in einem `Vec<T>` gesammelt wird.Das heißt, wenn Sie Folgendes schreiben:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// das verhält sich so, als hätten wir geschrieben:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Der erste Satz von Zuordnungen erfolgt hier.
    ///     .into(); // Hier erfolgt eine zweite Zuordnung für `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dadurch wird so oft wie nötig für die Erstellung des `Vec<T>` und dann einmal für die Umwandlung des `Vec<T>` in den `Rc<[T]>` zugewiesen.
    ///
    ///
    /// ## Iteratoren bekannter Länge
    ///
    /// Wenn Ihr `Iterator` `TrustedLen` implementiert und eine exakte Größe hat, wird eine einzelne Zuordnung für den `Rc<[T]>` vorgenommen.Beispielsweise:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Hier erfolgt nur eine einzige Zuordnung.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spezialisierung trait zum Sammeln in `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Dies ist bei einem `TrustedLen`-Iterator der Fall.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SICHERHEIT: Wir müssen sicherstellen, dass der Iterator eine exakte Länge hat und wir haben.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Auf die normale Implementierung zurückgreifen.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ist eine Version von [`Rc`], die einen nicht besitzenden Verweis auf die verwaltete Zuordnung enthält.Auf die Zuordnung wird zugegriffen, indem [`upgrade`] auf dem `Weak`-Zeiger aufgerufen wird, der eine [`Option`]`<`[`Rc`] `zurückgibt<T>>`.
///
/// Da eine `Weak`-Referenz nicht für den Besitz angerechnet wird, wird nicht verhindert, dass der in der Zuordnung gespeicherte Wert gelöscht wird, und `Weak` selbst übernimmt keine Garantie dafür, dass der Wert noch vorhanden ist.
/// Daher kann es [`None`] zurückgeben, wenn [`upgrade`] d.
/// Beachten Sie jedoch, dass eine `Weak`-Referenz *verhindert*, dass die Zuordnung selbst (der Sicherungsspeicher) aufgehoben wird.
///
/// Ein `Weak`-Zeiger ist nützlich, um einen temporären Verweis auf die von [`Rc`] verwaltete Zuordnung beizubehalten, ohne zu verhindern, dass sein innerer Wert gelöscht wird.
/// Es wird auch verwendet, um Zirkelverweise zwischen [`Rc`]-Zeigern zu verhindern, da gegenseitige Besitzverweise niemals zulassen würden, dass [`Rc`] gelöscht wird.
/// Beispielsweise könnte ein Baum starke [`Rc`]-Zeiger von übergeordneten Knoten zu untergeordneten Knoten und `Weak`-Zeiger von untergeordneten Knoten zu ihren übergeordneten Knoten aufweisen.
///
/// Der typische Weg, um einen `Weak`-Zeiger zu erhalten, besteht darin, [`Rc::downgrade`] aufzurufen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dies ist ein `NonNull`, um die Größe dieses Typs in Aufzählungen zu optimieren, aber es ist nicht unbedingt ein gültiger Zeiger.
    //
    // `Weak::new` setzt dies auf `usize::MAX`, damit kein Speicherplatz auf dem Heap zugewiesen werden muss.
    // Dies ist kein Wert, den ein echter Zeiger jemals haben wird, da die Ausrichtung der RcBox mindestens 2 beträgt.
    // Dies ist nur möglich, wenn `T: Sized`;`T` ohne Größe baumelt nie.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Erstellt einen neuen `Weak<T>`, ohne Speicher zuzuweisen.
    /// Wenn Sie [`upgrade`] für den Rückgabewert aufrufen, erhalten Sie immer [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Hilfstyp, um den Zugriff auf die Referenzzählungen zu ermöglichen, ohne Aussagen über das Datenfeld zu machen.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Gibt einen Rohzeiger auf das Objekt `T` zurück, auf das dieses `Weak<T>` zeigt.
    ///
    /// Der Zeiger ist nur gültig, wenn starke Referenzen vorhanden sind.
    /// Der Zeiger kann baumeln, nicht ausgerichtet sein oder andernfalls sogar [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Beide zeigen auf dasselbe Objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Das Starke hier hält es am Leben, so dass wir immer noch auf das Objekt zugreifen können.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Aber nicht mehr.
    /// // Wir können weak.as_ptr() ausführen, aber der Zugriff auf den Zeiger würde zu undefiniertem Verhalten führen.
    /// // assert_eq! ("Hallo", unsicher {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Wenn der Zeiger baumelt, geben wir den Sentinel direkt zurück.
            // Dies kann keine gültige Nutzdatenadresse sein, da die Nutzdaten mindestens so ausgerichtet sind wie die RcBox (usize).
            ptr as *const T
        } else {
            // SICHERHEIT: Wenn is_dangling false zurückgibt, ist der Zeiger dereferenzierbar.
            // Die Nutzlast kann zu diesem Zeitpunkt gelöscht werden, und wir müssen die Herkunft beibehalten. Verwenden Sie daher die Manipulation des Rohzeigers.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Verbraucht den `Weak<T>` und verwandelt ihn in einen Rohzeiger.
    ///
    /// Dadurch wird der schwache Zeiger in einen Rohzeiger konvertiert, wobei der Besitz einer schwachen Referenz erhalten bleibt (die schwache Anzahl wird durch diese Operation nicht geändert).
    /// Es kann mit [`from_raw`] wieder in den `Weak<T>` verwandelt werden.
    ///
    /// Es gelten die gleichen Einschränkungen für den Zugriff auf das Ziel des Zeigers wie bei [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konvertiert einen zuvor von [`into_raw`] erstellten Rohzeiger zurück in `Weak<T>`.
    ///
    /// Dies kann verwendet werden, um sicher eine starke Referenz zu erhalten (indem Sie später [`upgrade`] aufrufen) oder um die Zuweisung der schwachen Anzahl durch Löschen des `Weak<T>` aufzuheben.
    ///
    /// Es übernimmt den Besitz einer schwachen Referenz (mit Ausnahme der von [`new`] erstellten Zeiger, da diese nichts besitzen; die Methode funktioniert weiterhin mit ihnen).
    ///
    /// # Safety
    ///
    /// Der Zeiger muss vom [`into_raw`] stammen und seine potenzielle schwache Referenz besitzen.
    ///
    /// Es ist zulässig, dass die starke Anzahl zum Zeitpunkt des Aufrufs 0 ist.
    /// Dies übernimmt jedoch den Besitz einer schwachen Referenz, die derzeit als Rohzeiger dargestellt wird (die schwache Anzahl wird durch diese Operation nicht geändert), und muss daher mit einem vorherigen Aufruf von [`into_raw`] gepaart werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Verringern Sie die letzte schwache Zählung.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // In Weak::as_ptr finden Sie einen Kontext zur Ableitung des Eingabezeigers.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dies ist eine baumelnde Schwäche.
            ptr as *mut RcBox<T>
        } else {
            // Ansonsten ist garantiert, dass der Zeiger von einem nicht baumelnden Schwachen stammt.
            // SICHERHEIT: data_offset kann sicher aufgerufen werden, da ptr auf ein reales (möglicherweise verworfenes) T verweist.
            let offset = unsafe { data_offset(ptr) };
            // Daher kehren wir den Offset um, um die gesamte RcBox zu erhalten.
            // SICHERHEIT: Der Zeiger stammt von einem Schwachen, daher ist dieser Versatz sicher.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SICHERHEIT: Wir haben jetzt den ursprünglichen schwachen Zeiger wiederhergestellt, können also den schwachen Zeiger erstellen.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Versuche, den `Weak`-Zeiger auf einen [`Rc`] zu aktualisieren, verzögern bei Erfolg das Löschen des inneren Werts.
    ///
    ///
    /// Gibt [`None`] zurück, wenn der innere Wert inzwischen gelöscht wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zerstöre alle starken Zeiger.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ruft die Anzahl der starken (`Rc`)-Zeiger ab, die auf diese Zuordnung verweisen.
    ///
    /// Wenn `self` mit [`Weak::new`] erstellt wurde, wird 0 zurückgegeben.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ruft die Anzahl der `Weak`-Zeiger ab, die auf diese Zuordnung verweisen.
    ///
    /// Wenn keine starken Zeiger mehr vorhanden sind, wird Null zurückgegeben.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // subtrahieren Sie den impliziten schwachen ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Gibt `None` zurück, wenn der Zeiger baumelt und kein `RcBox` zugewiesen ist (dh wenn dieses `Weak` von `Weak::new` erstellt wurde).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Wir achten darauf, keine Referenz für das "data"-Feld zu erstellen, da das Feld möglicherweise gleichzeitig mutiert wird (wenn beispielsweise das letzte `Rc` gelöscht wird, wird das Datenfeld an Ort und Stelle gelöscht).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Gibt `true` zurück, wenn die beiden Schwachen auf dieselbe Zuordnung zeigen (ähnlich wie [`ptr::eq`]) oder wenn beide nicht auf eine Zuordnung zeigen (weil sie mit `Weak::new()`) erstellt wurden.
    ///
    ///
    /// # Notes
    ///
    /// Da dies Zeiger vergleicht, bedeutet dies, dass `Weak::new()` einander gleich ist, obwohl sie nicht auf eine Zuordnung verweisen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` vergleichen.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Lässt den `Weak`-Zeiger fallen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Druckt nichts
    /// drop(foo);        // Druckt "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // Die schwache Zählung beginnt bei 1 und geht nur dann auf Null, wenn alle starken Zeiger verschwunden sind.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Erstellt einen Klon des `Weak`-Zeigers, der auf dieselbe Zuordnung verweist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Erstellt einen neuen `Weak<T>`, der `T` Speicher zuweist, ohne ihn zu initialisieren.
    /// Wenn Sie [`upgrade`] für den Rückgabewert aufrufen, erhalten Sie immer [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Wir haben hier check_add überprüft, um sicher mit mem::forget umzugehen.Bestimmtes
// Wenn Sie mem::forget Rcs (oder Weaks) verwenden, kann die Ref-Anzahl überlaufen, und Sie können die Zuordnung freigeben, solange noch ausstehende Rcs (oder Weaks) vorhanden sind.
//
// Wir brechen ab, weil dies ein so entartetes Szenario ist, dass es uns egal ist, was passiert-kein echtes Programm sollte dies jemals erleben.
//
// Dies sollte einen vernachlässigbaren Overhead haben, da Sie aufgrund von Besitz und Verschiebungssemantik nicht so viel in Rust klonen müssen.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Wir möchten den Überlauf abbrechen, anstatt den Wert zu löschen.
        // Der Referenzzähler wird niemals Null sein, wenn dies aufgerufen wird.
        // Trotzdem fügen wir hier einen Abbruch ein, um LLVM auf eine ansonsten verpasste Optimierung hinzuweisen.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Wir möchten den Überlauf abbrechen, anstatt den Wert zu löschen.
        // Der Referenzzähler wird niemals Null sein, wenn dies aufgerufen wird.
        // Trotzdem fügen wir hier einen Abbruch ein, um LLVM auf eine ansonsten verpasste Optimierung hinzuweisen.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Holen Sie sich den Offset innerhalb eines `RcBox` für die Nutzlast hinter einem Zeiger.
///
/// # Safety
///
/// Der Zeiger muss auf eine zuvor gültige Instanz von T zeigen (und gültige Metadaten für diese haben), aber das T darf gelöscht werden.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Richten Sie den Wert ohne Größe am Ende der RcBox aus.
    // Da RcBox repr(C) ist, ist es immer das letzte Feld im Speicher.
    // SICHERHEIT: Da die einzigen möglichen Typen ohne Größe Slices, trait-Objekte,
    // Bei externen Typen reicht die Sicherheitsanforderung für die Eingabe derzeit aus, um die Anforderungen von align_of_val_raw zu erfüllen.Dies ist ein Implementierungsdetail der Sprache, auf das außerhalb von std möglicherweise nicht vertraut wird.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}