use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Eine weitere Spezialisierung trait für Vec::from_iter, die erforderlich ist, um überlappende Spezialisierungen manuell zu priorisieren, finden Sie in [`SpecFromIter`](super::SpecFromIter) für Details.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Rollen Sie die erste Iteration ab, da der vector in jedem Fall in dieser Iteration erweitert wird, wenn die Iterable nicht leer ist, aber die Schleife in extend_desugared() nicht sieht, dass der vector in den wenigen nachfolgenden Schleifeniterationen voll ist.
        //
        // So erhalten wir eine bessere branch-Vorhersage.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // muss an spec_extend() delegieren, da extend() selbst für leere Vecs an spec_from delegiert
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // muss an spec_extend() delegieren, da extend() selbst für leere Vecs an spec_from delegiert
        //
        vector.spec_extend(iterator);
        vector
    }
}