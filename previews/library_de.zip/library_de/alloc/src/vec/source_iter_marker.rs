use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Spezialisierungsmarker zum Sammeln einer Iterator-Pipeline in einem Vec unter Wiederverwendung der Quellenzuordnung, d. H.
/// Ausführen der Pipeline an Ort und Stelle.
///
/// Das SourceIter-übergeordnete Element trait ist erforderlich, damit die Spezialisierungsfunktion auf die Zuordnung zugreifen kann, die wiederverwendet werden soll.
/// Es reicht jedoch nicht aus, dass die Spezialisierung gültig ist.
/// Siehe zusätzliche Grenzen auf dem Gerät.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Die std-internen SourceIter/InPlaceIterable traits werden nur von Adapterketten implementiert <Adapter<Adapter<IntoIter>>> (alle im Besitz von core/std).
// Zusätzliche Grenzen für die Adapterimplementierungen (über `impl<I: Trait> Trait for Adapter<I>` hinaus) hängen nur von anderen traits ab, die bereits als Spezialisierung traits gekennzeichnet sind (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. Der Marker hängt nicht von der Lebensdauer der vom Benutzer bereitgestellten Typen ab.Modulo das Kopierloch, von dem bereits einige andere Spezialisierungen abhängen.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Zusätzliche Anforderungen, die nicht über trait bounds ausgedrückt werden können.Wir verlassen uns stattdessen auf Konstante:
        // a) Keine ZSTs, da keine Zuordnung zur Wiederverwendung und Zeigerarithmetik vorhanden wäre. panic. b) Größenanpassung gemäß Alloc-Vertrag. c) Ausrichtungen gemäß Alloc-Vertrag
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // Rückgriff auf allgemeinere Implementierungen
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // benutze try-fold da
        // - Für einige Iteratoradapter ist die Vektorisierung besser
        // - Im Gegensatz zu den meisten internen Iterationsmethoden wird nur ein &mut-Self benötigt
        // - Damit können wir den Schreibzeiger durch seine Innereien führen und ihn am Ende zurückbekommen
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // Iteration erfolgreich, Kopf nicht fallen lassen
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // Überprüfen Sie, ob der SourceIter-Vertrag eingehalten wurde. Wenn dies nicht der Fall ist, schaffen wir es möglicherweise nicht einmal bis zu diesem Punkt
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // Überprüfen Sie den InPlaceIterable-Vertrag.Dies ist nur möglich, wenn der Iterator den Quellzeiger überhaupt vorgerückt hat.
        // Wenn der ungeprüfte Zugriff über TrustedRandomAccess verwendet wird, bleibt der Quellzeiger an seiner ursprünglichen Position und kann nicht als Referenz verwendet werden
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // Löschen Sie alle verbleibenden Werte am Ende der Quelle, aber verhindern Sie, dass die Zuordnung selbst gelöscht wird, sobald IntoIter den Gültigkeitsbereich verlässt, wenn panics gelöscht wird. Außerdem verlieren wir alle in dst_buf gesammelten Elemente
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // Der InPlaceIterable-Vertrag kann hier nicht genau überprüft werden, da try_fold einen exklusiven Verweis auf den Quellzeiger enthält. Wir können lediglich prüfen, ob er sich noch im Bereich befindet
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}