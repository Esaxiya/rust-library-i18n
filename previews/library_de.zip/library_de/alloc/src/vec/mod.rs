//! Ein zusammenhängender erweiterbarer Array-Typ mit Heap-zugewiesenem Inhalt, geschrieben `Vec<T>`.
//!
//! Vectors haben `O(1)`-Indizierung, amortisierten `O(1)`-Push (bis zum Ende) und `O(1)`-Pop (vom Ende).
//!
//!
//! Vectors stellen sicher, dass niemals mehr als `isize::MAX` Bytes zugewiesen werden.
//!
//! # Examples
//!
//! Sie können einen [`Vec`] explizit mit [`Vec::new`] erstellen:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... oder mit dem [`vec!`]-Makro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // zehn Nullen
//! ```
//!
//! Sie können [`push`]-Werte an das Ende eines vector anbringen (wodurch der vector nach Bedarf vergrößert wird):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Das Poppen von Werten funktioniert ähnlich:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors unterstützt auch die Indizierung (über [`Index`] und [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Ein zusammenhängender, erweiterbarer Array-Typ, der als `Vec<T>` geschrieben und als 'vector' ausgesprochen wird.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Das [`vec!`]-Makro erleichtert die Initialisierung:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Es kann auch jedes Element eines `Vec<T>` mit einem bestimmten Wert initialisieren.
/// Dies ist möglicherweise effizienter als die Zuweisung und Initialisierung in separaten Schritten, insbesondere beim Initialisieren eines vector mit Nullen:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Folgendes ist äquivalent, aber möglicherweise langsamer:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Weitere Informationen finden Sie unter [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Verwenden Sie einen `Vec<T>` als effizienten Stack:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Druckt 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Der Typ `Vec` ermöglicht den Zugriff auf Werte über den Index, da er den [`Index`] trait implementiert.Ein Beispiel wird expliziter sein:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // Es wird '2' angezeigt
/// ```
///
/// Seien Sie jedoch vorsichtig: Wenn Sie versuchen, auf einen Index zuzugreifen, der nicht im `Vec` enthalten ist, wird Ihre Software panic!Du kannst das nicht machen:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Verwenden Sie [`get`] und [`get_mut`], wenn Sie überprüfen möchten, ob sich der Index im `Vec` befindet.
///
/// # Slicing
///
/// Ein `Vec` kann veränderbar sein.Auf der anderen Seite sind Slices schreibgeschützte Objekte.
/// Verwenden Sie [`&`], um einen [slice][prim@slice] zu erhalten.Beispiel:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... und das ist alles!
/// // Sie können es auch so machen:
/// let u: &[usize] = &v;
/// // oder so:
/// let u: &[_] = &v;
/// ```
///
/// In Rust ist es üblicher, Slices als Argumente zu übergeben, als vectors, wenn Sie nur Lesezugriff gewähren möchten.Gleiches gilt für [`String`] und [`&str`].
///
/// # Kapazität und Neuzuweisung
///
/// Die Kapazität eines vector ist die Menge an Speicherplatz, die für alle future-Elemente zugewiesen wird, die dem vector hinzugefügt werden.Dies ist nicht zu verwechseln mit der *Länge* eines vector, die die Anzahl der tatsächlichen Elemente innerhalb des vector angibt.
/// Wenn die Länge eines vector seine Kapazität überschreitet, wird seine Kapazität automatisch erhöht, aber seine Elemente müssen neu zugewiesen werden.
///
/// Zum Beispiel wäre ein vector mit Kapazität 10 und Länge 0 ein leerer vector mit Platz für 10 weitere Elemente.Wenn Sie 10 oder weniger Elemente auf den vector schieben, ändert sich weder seine Kapazität noch es kommt zu einer Neuzuweisung.
/// Wenn jedoch die Länge des vector auf 11 erhöht wird, muss er neu zugewiesen werden, was langsam sein kann.Aus diesem Grund wird empfohlen, nach Möglichkeit [`Vec::with_capacity`] zu verwenden, um anzugeben, wie groß der vector voraussichtlich werden wird.
///
/// # Guarantees
///
/// Aufgrund seiner unglaublich fundamentalen Natur gibt `Vec` viele Garantien für sein Design.Dies stellt sicher, dass der Overhead im allgemeinen Fall so gering wie möglich ist und durch unsicheren Code auf primitive Weise korrekt manipuliert werden kann.Beachten Sie, dass sich diese Garantien auf einen nicht qualifizierten `Vec<T>` beziehen.
/// Wenn zusätzliche Typparameter hinzugefügt werden (z. B. um benutzerdefinierte Allokatoren zu unterstützen), kann das Überschreiben ihrer Standardeinstellungen das Verhalten ändern.
///
/// Grundsätzlich ist und bleibt `Vec` ein Triplett (Zeiger, Kapazität, Länge).Nicht mehr und nicht weniger.Die Reihenfolge dieser Felder ist völlig unbestimmt, und Sie sollten die entsprechenden Methoden verwenden, um diese zu ändern.
/// Der Zeiger wird niemals null sein, daher ist dieser Typ für Nullzeiger optimiert.
///
/// Der Zeiger zeigt jedoch möglicherweise nicht auf den zugewiesenen Speicher.
/// Insbesondere wenn Sie einen `Vec` mit der Kapazität 0 über [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] oder durch Aufrufen von [`shrink_to_fit`] auf einem leeren Vec erstellen, wird kein Speicher zugewiesen.Wenn Sie Typen mit der Größe Null in einem `Vec` speichern, wird ihnen kein Speicherplatz zugewiesen.
/// *Beachten Sie, dass der `Vec` in diesem Fall möglicherweise keinen [`capacity`] von 0* meldet.
/// `Vec` wird genau dann zuweisen, wenn [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Im Allgemeinen sind die Zuordnungsdetails von `Vec` sehr subtil-wenn Sie beabsichtigen, Speicher mit einem `Vec` zuzuweisen und für etwas anderes zu verwenden (entweder um an unsicheren Code zu übergeben oder um Ihre eigene speichergestützte Sammlung zu erstellen), stellen Sie sicher Freigeben dieses Speichers durch Verwenden von `from_raw_parts` zum Wiederherstellen des `Vec` und anschließendes Löschen.
///
/// Wenn einem `Vec`*Speicher* zugewiesen wurde, befindet sich der Speicher, auf den er verweist, auf dem Heap (wie vom Allokator Rust definiert, ist standardmäßig für die Verwendung konfiguriert), und sein Zeiger zeigt auf [`len`]-initialisierte, zusammenhängende Elemente in der angegebenen Reihenfolge (wie Sie es möchten) sehen Sie, ob Sie es zu einem Slice gezwungen haben), gefolgt von [`Kapazität`]`,`[`len`] logisch nicht initialisierten, zusammenhängenden Elementen.
///
///
/// Ein vector, der die Elemente `'a'` und `'b'` mit Kapazität 4 enthält, kann wie folgt dargestellt werden.Der obere Teil ist die `Vec`-Struktur. Sie enthält einen Zeiger auf den Kopf der Zuordnung in Heap, Länge und Kapazität.
/// Der untere Teil ist die Zuordnung auf dem Heap, einem zusammenhängenden Speicherblock.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** steht für Speicher, der nicht initialisiert ist, siehe [`MaybeUninit`].
/// - Note: Der ABI ist nicht stabil und `Vec` übernimmt keine Garantie für sein Speicherlayout (einschließlich der Reihenfolge der Felder).
///
/// `Vec` führt niemals einen "small optimization" durch, bei dem Elemente aus zwei Gründen tatsächlich auf dem Stapel gespeichert sind:
///
/// * Dies würde es für unsicheren Code schwieriger machen, einen `Vec` korrekt zu manipulieren.Der Inhalt eines `Vec` hätte keine stabile Adresse, wenn er nur verschoben würde, und es wäre schwieriger festzustellen, ob einem `Vec` tatsächlich Speicher zugewiesen wurde.
///
/// * Dies würde den allgemeinen Fall bestrafen und bei jedem Zugriff eine zusätzliche branch verursachen.
///
/// `Vec` wird sich nie automatisch verkleinern, auch wenn es vollständig leer ist.Dies stellt sicher, dass keine unnötigen Zuweisungen oder Freigaben vorgenommen werden.Wenn Sie einen `Vec` leeren und dann wieder auf denselben [`len`] auffüllen, werden keine Anrufe an den Allokator getätigt.Wenn Sie nicht verwendeten Speicher freigeben möchten, verwenden Sie [`shrink_to_fit`] oder [`shrink_to`].
///
/// [`push`] und [`insert`] wird niemals (neu) zuweisen, wenn die gemeldete Kapazität ausreicht.[`push`] und [`insert`]*werden*(neu) zuweisen, wenn [`len`]`==`[`Kapazität`].Das heißt, die gemeldete Kapazität ist vollständig korrekt und kann als zuverlässig angesehen werden.Auf Wunsch kann sogar der von einem `Vec` zugewiesene Speicher manuell freigegeben werden.
/// Masseneinfügemethoden *können* neu zugewiesen werden, auch wenn dies nicht erforderlich ist.
///
/// `Vec` garantiert keine bestimmte Wachstumsstrategie bei der Neuzuweisung, wenn sie voll ist, oder wenn [`reserve`] aufgerufen wird.Die derzeitige Strategie ist grundlegend und es kann sich als wünschenswert erweisen, einen nicht konstanten Wachstumsfaktor zu verwenden.Unabhängig von der verwendeten Strategie wird natürlich *O*(1) amortisiertes [`push`] garantiert.
///
/// `vec![x; n]`, `vec![a, b, c, d]` und [`Vec::with_capacity(n)`][`Vec::with_capacity`] produzieren alle einen `Vec` mit genau der angeforderten Kapazität.
/// Wenn [`len`]`==`[`Kapazität`](wie dies beim [`vec!`]-Makro der Fall ist), kann ein `Vec<T>` zu und von einem [`Box<[T]>`][owned slice] konvertiert werden, ohne die Elemente neu zuzuweisen oder zu verschieben.
///
/// `Vec` überschreibt keine Daten, die daraus entfernt wurden, aber bewahrt sie auch nicht speziell auf.Sein nicht initialisierter Speicher ist ein Arbeitsbereich, den er verwenden kann, wie er will.Es wird im Allgemeinen nur das tun, was am effizientesten oder auf andere Weise einfach zu implementieren ist.Verlassen Sie sich aus Sicherheitsgründen nicht darauf, dass entfernte Daten gelöscht werden.
/// Selbst wenn Sie einen `Vec` löschen, kann sein Puffer einfach von einem anderen `Vec` wiederverwendet werden.
/// Selbst wenn Sie zuerst den Speicher eines Vec auf Null setzen, kann dies möglicherweise nicht der Fall sein, da der Optimierer dies nicht als Nebeneffekt betrachtet, der erhalten bleiben muss.
/// Es gibt jedoch einen Fall, den wir nicht brechen werden: Die Verwendung von `unsafe`-Code zum Schreiben auf die überschüssige Kapazität und das anschließende Erhöhen der entsprechenden Länge ist immer gültig.
///
/// Derzeit garantiert `Vec` nicht die Reihenfolge, in der Elemente gelöscht werden.
/// Die Reihenfolge hat sich in der Vergangenheit geändert und kann sich erneut ändern.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Inhärente Methoden
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Erstellt ein neues, leeres `Vec<T>`.
    ///
    /// Der vector wird erst zugewiesen, wenn Elemente darauf geschoben werden.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Erstellt ein neues, leeres `Vec<T>` mit der angegebenen Kapazität.
    ///
    /// Der vector kann genau `capacity`-Elemente aufnehmen, ohne sie neu zuzuweisen.
    /// Wenn `capacity` 0 ist, wird der vector nicht zugeordnet.
    ///
    /// Es ist wichtig zu beachten, dass der zurückgegebene vector zwar die angegebene *Kapazität* hat, der vector jedoch eine *Länge* von Null hat.
    ///
    /// Eine Erklärung des Unterschieds zwischen Länge und Kapazität finden Sie unter *[Kapazität und Neuzuweisung]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Der vector enthält keine Elemente, obwohl er Platz für mehr bietet
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Diese werden alle ohne Neuzuweisung durchgeführt ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... aber dies kann dazu führen, dass der vector neu zugewiesen wird
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Erstellt einen `Vec<T>` direkt aus den Rohkomponenten eines anderen vector.
    ///
    /// # Safety
    ///
    /// Dies ist aufgrund der Anzahl der nicht überprüften Invarianten sehr unsicher:
    ///
    /// * `ptr` muss zuvor über [`String`]/`Vec zugewiesen worden sein<T>`(zumindest ist es sehr wahrscheinlich falsch, wenn es nicht wäre).
    /// * `T` muss die gleiche Größe und Ausrichtung haben wie `ptr`.
    ///   (`T` mit einer weniger strengen Ausrichtung ist nicht ausreichend. Die Ausrichtung muss wirklich gleich sein, um die [`dealloc`]-Anforderung zu erfüllen, dass Speicher mit demselben Layout zugewiesen und freigegeben werden muss.)
    ///
    /// * `length` muss kleiner oder gleich `capacity` sein.
    /// * `capacity` muss die Kapazität sein, der der Zeiger zugewiesen wurde.
    ///
    /// Ein Verstoß gegen diese kann zu Problemen wie der Beschädigung der internen Datenstrukturen des Allokators führen.Zum Beispiel ist es **nicht** sicher, ein `Vec<u8>` von einem Zeiger auf ein C `char`-Array mit der Länge `size_t` zu erstellen.
    /// Es ist auch nicht sicher, eine aus einem `Vec<u16>` und seiner Länge zu erstellen, da sich der Allokator um die Ausrichtung kümmert und diese beiden Typen unterschiedliche Ausrichtungen haben.
    /// Der Puffer wurde mit Ausrichtung 2 (für `u16`) zugewiesen, aber nachdem er in `Vec<u8>` umgewandelt wurde, wird er mit Ausrichtung 1 freigegeben.
    ///
    /// Das Eigentum an `ptr` wird effektiv auf den `Vec<T>` übertragen, der dann den Speicherinhalt, auf den der Zeiger nach Belieben zeigt, freigeben, neu zuweisen oder ändern kann.
    /// Stellen Sie sicher, dass nach dem Aufrufen dieser Funktion nichts anderes den Zeiger verwendet.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Aktualisieren Sie dies, wenn vec_into_raw_parts stabilisiert ist.
    ///     // Verhindern Sie, dass der Destruktor von `v` ausgeführt wird, damit wir die vollständige Kontrolle über die Zuordnung haben.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Ziehen Sie die verschiedenen wichtigen Informationen zu `v` heraus
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Überschreiben Sie den Speicher mit 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Setze alles wieder zu einem Vec zusammen
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Erstellt ein neues, leeres `Vec<T, A>`.
    ///
    /// Der vector wird erst zugewiesen, wenn Elemente darauf geschoben werden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Erstellt mit dem bereitgestellten Allokator ein neues, leeres `Vec<T, A>` mit der angegebenen Kapazität.
    ///
    /// Der vector kann genau `capacity`-Elemente aufnehmen, ohne sie neu zuzuweisen.
    /// Wenn `capacity` 0 ist, wird der vector nicht zugeordnet.
    ///
    /// Es ist wichtig zu beachten, dass der zurückgegebene vector zwar die angegebene *Kapazität* hat, der vector jedoch eine *Länge* von Null hat.
    ///
    /// Eine Erklärung des Unterschieds zwischen Länge und Kapazität finden Sie unter *[Kapazität und Neuzuweisung]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Der vector enthält keine Elemente, obwohl er Platz für mehr bietet
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Diese werden alle ohne Neuzuweisung durchgeführt ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... aber dies kann dazu führen, dass der vector neu zugewiesen wird
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Erstellt einen `Vec<T, A>` direkt aus den Rohkomponenten eines anderen vector.
    ///
    /// # Safety
    ///
    /// Dies ist aufgrund der Anzahl der nicht überprüften Invarianten sehr unsicher:
    ///
    /// * `ptr` muss zuvor über [`String`]/`Vec zugewiesen worden sein<T>`(zumindest ist es sehr wahrscheinlich falsch, wenn es nicht wäre).
    /// * `T` muss die gleiche Größe und Ausrichtung haben wie `ptr`.
    ///   (`T` mit einer weniger strengen Ausrichtung ist nicht ausreichend. Die Ausrichtung muss wirklich gleich sein, um die [`dealloc`]-Anforderung zu erfüllen, dass Speicher mit demselben Layout zugewiesen und freigegeben werden muss.)
    ///
    /// * `length` muss kleiner oder gleich `capacity` sein.
    /// * `capacity` muss die Kapazität sein, der der Zeiger zugewiesen wurde.
    ///
    /// Ein Verstoß gegen diese kann zu Problemen wie der Beschädigung der internen Datenstrukturen des Allokators führen.Zum Beispiel ist es **nicht** sicher, ein `Vec<u8>` von einem Zeiger auf ein C `char`-Array mit der Länge `size_t` zu erstellen.
    /// Es ist auch nicht sicher, eine aus einem `Vec<u16>` und seiner Länge zu erstellen, da sich der Allokator um die Ausrichtung kümmert und diese beiden Typen unterschiedliche Ausrichtungen haben.
    /// Der Puffer wurde mit Ausrichtung 2 (für `u16`) zugewiesen, aber nachdem er in `Vec<u8>` umgewandelt wurde, wird er mit Ausrichtung 1 freigegeben.
    ///
    /// Das Eigentum an `ptr` wird effektiv auf den `Vec<T>` übertragen, der dann den Speicherinhalt, auf den der Zeiger nach Belieben zeigt, freigeben, neu zuweisen oder ändern kann.
    /// Stellen Sie sicher, dass nach dem Aufrufen dieser Funktion nichts anderes den Zeiger verwendet.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Aktualisieren Sie dies, wenn vec_into_raw_parts stabilisiert ist.
    ///     // Verhindern Sie, dass der Destruktor von `v` ausgeführt wird, damit wir die vollständige Kontrolle über die Zuordnung haben.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Ziehen Sie die verschiedenen wichtigen Informationen zu `v` heraus
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Überschreiben Sie den Speicher mit 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Setze alles wieder zu einem Vec zusammen
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Zerlegt einen `Vec<T>` in seine Rohkomponenten.
    ///
    /// Gibt den Rohzeiger auf die zugrunde liegenden Daten, die Länge des vector (in Elementen) und die zugewiesene Kapazität der Daten (in Elementen) zurück.
    /// Dies sind dieselben Argumente in derselben Reihenfolge wie die Argumente für [`from_raw_parts`].
    ///
    /// Nach dem Aufruf dieser Funktion ist der Anrufer für den zuvor vom `Vec` verwalteten Speicher verantwortlich.
    /// Die einzige Möglichkeit, dies zu tun, besteht darin, den Rohzeiger, die Länge und die Kapazität mit der [`from_raw_parts`]-Funktion wieder in einen `Vec` zu konvertieren, sodass der Destruktor die Bereinigung durchführen kann.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Wir können jetzt Änderungen an den Komponenten vornehmen, z. B. den Rohzeiger in einen kompatiblen Typ umwandeln.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Zerlegt einen `Vec<T>` in seine Rohkomponenten.
    ///
    /// Gibt den Rohzeiger auf die zugrunde liegenden Daten, die Länge des vector (in Elementen), die zugewiesene Kapazität der Daten (in Elementen) und den Allokator zurück.
    /// Dies sind dieselben Argumente in derselben Reihenfolge wie die Argumente für [`from_raw_parts_in`].
    ///
    /// Nach dem Aufruf dieser Funktion ist der Anrufer für den zuvor vom `Vec` verwalteten Speicher verantwortlich.
    /// Die einzige Möglichkeit, dies zu tun, besteht darin, den Rohzeiger, die Länge und die Kapazität mit der [`from_raw_parts_in`]-Funktion wieder in einen `Vec` zu konvertieren, sodass der Destruktor die Bereinigung durchführen kann.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Wir können jetzt Änderungen an den Komponenten vornehmen, z. B. den Rohzeiger in einen kompatiblen Typ umwandeln.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Gibt die Anzahl der Elemente zurück, die der vector ohne Neuzuweisung enthalten kann.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reserviert Kapazität für mindestens `additional` mehr Elemente, die in das angegebene `Vec<T>` eingefügt werden sollen.
    /// Die Sammlung kann mehr Platz reservieren, um häufige Neuzuweisungen zu vermeiden.
    /// Nach dem Aufruf von `reserve` ist die Kapazität größer oder gleich `self.len() + additional`.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `isize::MAX` Bytes überschreitet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reserviert die Mindestkapazität für genau `additional` mehr Elemente, die in das angegebene `Vec<T>` eingefügt werden sollen.
    ///
    /// Nach dem Aufruf von `reserve_exact` ist die Kapazität größer oder gleich `self.len() + additional`.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// Beachten Sie, dass der Allokator der Sammlung möglicherweise mehr Speicherplatz zur Verfügung stellt, als er anfordert.
    /// Daher kann nicht davon ausgegangen werden, dass die Kapazität genau minimal ist.
    /// Bevorzugen Sie `reserve`, wenn future-Insertionen erwartet werden.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `usize` überläuft.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Versucht, Kapazität für mindestens `additional` mehr Elemente zu reservieren, die in das angegebene `Vec<T>` eingefügt werden sollen.
    /// Die Sammlung kann mehr Platz reservieren, um häufige Neuzuweisungen zu vermeiden.
    /// Nach dem Aufruf von `try_reserve` ist die Kapazität größer oder gleich `self.len() + additional`.
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// # Errors
    ///
    /// Wenn die Kapazität überläuft oder der Allokator einen Fehler meldet, wird ein Fehler zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reservieren Sie den Speicher vorab und beenden Sie ihn, wenn wir nicht können
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Jetzt wissen wir, dass dies mitten in unserer komplexen Arbeit nicht OOM sein kann
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sehr kompliziert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Versucht, die Mindestkapazität für genau `additional`-Elemente zu reservieren, die in das angegebene `Vec<T>` eingefügt werden sollen.
    /// Nach dem Aufruf von `try_reserve_exact` ist die Kapazität größer oder gleich `self.len() + additional`, wenn `Ok(())` zurückgegeben wird.
    ///
    /// Tut nichts, wenn die Kapazität bereits ausreicht.
    ///
    /// Beachten Sie, dass der Allokator der Sammlung möglicherweise mehr Speicherplatz zur Verfügung stellt, als er anfordert.
    /// Daher kann nicht davon ausgegangen werden, dass die Kapazität genau minimal ist.
    /// Bevorzugen Sie `reserve`, wenn future-Insertionen erwartet werden.
    ///
    /// # Errors
    ///
    /// Wenn die Kapazität überläuft oder der Allokator einen Fehler meldet, wird ein Fehler zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reservieren Sie den Speicher vorab und beenden Sie ihn, wenn wir nicht können
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Jetzt wissen wir, dass dies mitten in unserer komplexen Arbeit nicht OOM sein kann
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // sehr kompliziert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Verkleinert die Kapazität des vector so weit wie möglich.
    ///
    /// Es wird so nah wie möglich an der Länge herunterfallen, aber der Allokator kann den vector dennoch darüber informieren, dass Platz für ein paar weitere Elemente vorhanden ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Die Kapazität ist nie kleiner als die Länge, und es gibt nichts zu tun, wenn sie gleich sind. Daher können wir den Fall panic in `RawVec::shrink_to_fit` vermeiden, indem wir ihn nur mit einer größeren Kapazität aufrufen.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Verkleinert die Kapazität des vector mit einer Untergrenze.
    ///
    /// Die Kapazität bleibt mindestens so groß wie die Länge und der gelieferte Wert.
    ///
    ///
    /// Wenn die aktuelle Kapazität unter der Untergrenze liegt, ist dies ein No-Op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Konvertiert den vector in [`Box<[T]>`][owned slice].
    ///
    /// Beachten Sie, dass dadurch die überschüssige Kapazität verringert wird.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Überkapazitäten werden entfernt:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Verkürzt den vector, behält die ersten `len`-Elemente bei und lässt den Rest fallen.
    ///
    /// Wenn `len` größer als die aktuelle Länge des vector ist, hat dies keine Auswirkung.
    ///
    /// Die [`drain`]-Methode kann `truncate` emulieren, bewirkt jedoch, dass die überschüssigen Elemente zurückgegeben werden, anstatt gelöscht zu werden.
    ///
    ///
    /// Beachten Sie, dass diese Methode keine Auswirkungen auf die zugewiesene Kapazität des vector hat.
    ///
    /// # Examples
    ///
    /// Abschneiden eines vector mit fünf Elementen auf zwei Elemente:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Wenn `len` größer als die aktuelle Länge des vector ist, tritt keine Kürzung auf:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Abschneiden, wenn `len == 0` dem Aufrufen der [`clear`]-Methode entspricht.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Dies ist sicher, weil:
        //
        // * Das an `drop_in_place` übergebene Slice ist gültig.Der `len > self.len`-Fall vermeidet das Erstellen eines ungültigen Slice
        // * Das `len` des vector wird vor dem Aufruf von `drop_in_place` verkleinert, sodass kein Wert zweimal gelöscht wird, wenn `drop_in_place` einmal auf panic gesetzt wurde (wenn es zweimal panics ist, wird das Programm abgebrochen).
        //
        //
        //
        unsafe {
            // Note: Es ist beabsichtigt, dass dies `>` und nicht `>=` ist.
            //       Das Ändern auf `>=` hat in einigen Fällen negative Auswirkungen auf die Leistung.
            //       Weitere Informationen finden Sie unter #78884.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extrahiert eine Scheibe, die den gesamten vector enthält.
    ///
    /// Entspricht `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extrahiert eine veränderbare Schicht des gesamten vector.
    ///
    /// Entspricht `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Gibt einen Rohzeiger auf den Puffer des vector zurück.
    ///
    /// Der Aufrufer muss sicherstellen, dass der vector den Zeiger überlebt, den diese Funktion zurückgibt. Andernfalls zeigt er auf Müll.
    /// Das Ändern des vector kann dazu führen, dass sein Puffer neu zugewiesen wird, wodurch auch alle Zeiger auf ihn ungültig werden.
    ///
    /// Der Aufrufer muss außerdem sicherstellen, dass der Speicher, auf den der Zeiger (non-transitively) zeigt, niemals mit diesem Zeiger oder einem von ihm abgeleiteten Zeiger in den Speicher geschrieben wird (außer innerhalb eines `UnsafeCell`).
    /// Wenn Sie den Inhalt des Slice mutieren müssen, verwenden Sie [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Wir beschatten die gleichnamige Slice-Methode, um zu vermeiden, dass `deref` durchlaufen wird, wodurch eine Zwischenreferenz erstellt wird.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Gibt einen unsicheren veränderbaren Zeiger auf den Puffer des vector zurück.
    ///
    /// Der Aufrufer muss sicherstellen, dass der vector den Zeiger überlebt, den diese Funktion zurückgibt. Andernfalls zeigt er auf Müll.
    ///
    /// Das Ändern des vector kann dazu führen, dass sein Puffer neu zugewiesen wird, wodurch auch alle Zeiger auf ihn ungültig werden.
    ///
    /// # Examples
    ///
    /// ```
    /// // Ordnen Sie vector groß genug für 4 Elemente zu.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialisieren Sie Elemente über Raw-Zeiger-Schreibvorgänge und legen Sie dann die Länge fest.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Wir beschatten die gleichnamige Slice-Methode, um zu vermeiden, dass `deref_mut` durchlaufen wird, wodurch eine Zwischenreferenz erstellt wird.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Gibt einen Verweis auf den zugrunde liegenden Allokator zurück.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Erzwingt die Länge des vector auf `new_len`.
    ///
    /// Dies ist eine Operation auf niedriger Ebene, bei der keine der normalen Invarianten des Typs beibehalten wird.
    /// Normalerweise wird die Länge eines vector stattdessen mit einer der sicheren Operationen wie [`truncate`], [`resize`], [`extend`] oder [`clear`] geändert.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` muss kleiner oder gleich [`capacity()`] sein.
    /// - Die Elemente bei `old_len..new_len` müssen initialisiert werden.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Diese Methode kann in Situationen nützlich sein, in denen der vector als Puffer für anderen Code dient, insbesondere über FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dies ist nur ein minimales Gerüst für das Dokumentbeispiel.
    /// # // Verwenden Sie dies nicht als Ausgangspunkt für eine echte Bibliothek.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Gemäß den Dokumenten der FFI-Methode "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SICHERHEIT: Wenn `deflateGetDictionary` `Z_OK` zurückgibt, gilt Folgendes:
    ///     // 1. `dict_length` Elemente wurden initialisiert.
    ///     // 2.
    ///     // `dict_length` <=die Kapazität (32_768), mit der `set_len` sicher angerufen werden kann.
    ///     unsafe {
    ///         // FFI anrufen ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... und aktualisieren Sie die Länge auf das, was initialisiert wurde.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Während das folgende Beispiel Sound ist, gibt es einen Speicherverlust, da die inneren vectors vor dem `set_len`-Aufruf nicht freigegeben wurden:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ist leer, sodass keine Elemente initialisiert werden müssen.
    /// // 2. `0 <= capacity` hält immer was auch immer `capacity` ist.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalerweise würde man hier stattdessen [`clear`] verwenden, um den Inhalt korrekt zu löschen und somit keinen Speicher zu verlieren.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Entfernt ein Element aus dem vector und gibt es zurück.
    ///
    /// Das entfernte Element wird durch das letzte Element des vector ersetzt.
    ///
    /// Die Reihenfolge bleibt nicht erhalten, es handelt sich jedoch um O(1).
    ///
    /// # Panics
    ///
    /// Panics, wenn `index` außerhalb der Grenzen liegt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Wir ersetzen self [index] durch das letzte Element.
            // Beachten Sie, dass, wenn die obige Prüfung der Grenzen erfolgreich ist, ein letztes Element vorhanden sein muss (das selbst [Index] sein kann).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Fügt ein Element an Position `index` in den vector ein und verschiebt alle Elemente danach nach rechts.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // Platz für das neue Element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // unfehlbar Der Ort, an dem der neue Wert gesetzt werden soll
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Verschieben Sie alles, um Platz zu schaffen.
                // (Duplizieren des "index"-ten Elements an zwei aufeinander folgenden Stellen.)
                ptr::copy(p, p.offset(1), len - index);
                // Schreiben Sie es ein und überschreiben Sie die erste Kopie des index-ten Elements.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Entfernt das Element und bringt es an Position `index` innerhalb des vector zurück, wobei alle Elemente danach nach links verschoben werden.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn `index` außerhalb der Grenzen liegt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // der Ort, von dem wir nehmen.
                let ptr = self.as_mut_ptr().add(index);
                // Kopieren Sie es aus, ohne gleichzeitig eine Kopie des Werts auf dem Stapel und im vector zu haben.
                //
                ret = ptr::read(ptr);

                // Verschieben Sie alles nach unten, um diese Stelle auszufüllen.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Behält nur die vom Prädikat angegebenen Elemente bei.
    ///
    /// Mit anderen Worten, entfernen Sie alle Elemente `e` so, dass `f(&e)` `false` zurückgibt.
    /// Diese Methode funktioniert an Ort und Stelle und besucht jedes Element genau einmal in der ursprünglichen Reihenfolge und behält die Reihenfolge der beibehaltenen Elemente bei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Da die Elemente in der ursprünglichen Reihenfolge genau einmal besucht werden, kann der externe Status verwendet werden, um zu entscheiden, welche Elemente beibehalten werden sollen.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Vermeiden Sie Double Drop, wenn der Drop Guard nicht ausgeführt wird, da wir während des Vorgangs einige Löcher bohren können.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-verarbeitete Länge-> |^-neben zu überprüfen
        //                  | <-cnt gelöscht-> |
        //      | <-original_len-> |Behalten: Elemente, deren Prädikat true zurückgibt.
        //
        // Loch: Verschobener oder fallengelassener Elementschlitz.
        // Deaktiviert: Deaktivierte gültige Elemente.
        //
        // Dieser Drop Guard wird aufgerufen, wenn das Prädikat oder `drop` des Elements in Panik gerät.
        // Ungeprüfte Elemente werden verschoben, um Löcher und `set_len` auf die richtige Länge abzudecken.
        // In Fällen, in denen Prädikat und `drop` nie in Panik geraten, wird es optimiert.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SICHERHEIT: Nachgestellte ungeprüfte Elemente müssen gültig sein, da wir sie niemals berühren.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SICHERHEIT: Nach dem Füllen der Löcher befinden sich alle Elemente im zusammenhängenden Speicher.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SICHERHEIT: Das nicht aktivierte Element muss gültig sein.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Gehen Sie frühzeitig vor, um einen doppelten Abfall zu vermeiden, wenn `drop_in_place` in Panik gerät.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SICHERHEIT: Wir berühren dieses Element nach dem Fallenlassen nie wieder.
                unsafe { ptr::drop_in_place(cur) };
                // Wir haben den Zähler bereits weiterentwickelt.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SICHERHEIT: `deleted_cnt`> 0, damit sich der Lochschlitz nicht mit dem aktuellen Element überlappt.
                // Wir verwenden die Kopie zum Verschieben und berühren dieses Element nie wieder.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Alle Artikel werden bearbeitet.Dies kann durch LLVM auf `set_len` optimiert werden.
        drop(g);
    }

    /// Entfernt alle bis auf das erste aufeinanderfolgende Element im vector, die in denselben Schlüssel aufgelöst werden.
    ///
    ///
    /// Wenn der vector sortiert ist, werden alle Duplikate entfernt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Entfernt alle bis auf das erste aufeinanderfolgende Element im vector, das eine bestimmte Gleichheitsrelation erfüllt.
    ///
    /// Die `same_bucket`-Funktion erhält Verweise auf zwei Elemente aus dem vector und muss bestimmen, ob die Elemente gleich sind.
    /// Die Elemente werden in entgegengesetzter Reihenfolge zu ihrer Reihenfolge im Slice übergeben. Wenn also `same_bucket(a, b)` `true` zurückgibt, wird `a` entfernt.
    ///
    ///
    /// Wenn der vector sortiert ist, werden alle Duplikate entfernt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Hängt ein Element an die Rückseite einer Sammlung an.
    ///
    /// # Panics
    ///
    /// Panics, wenn die neue Kapazität `isize::MAX` Bytes überschreitet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Dies wird panic oder abbrechen, wenn wir> isize::MAX Bytes zuweisen würden oder wenn das Längeninkrement für Typen mit der Größe Null überlaufen würde.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Entfernt das letzte Element aus einem vector und gibt es zurück oder [`None`], wenn es leer ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Verschiebt alle Elemente von `other` in `Self` und lässt `other` leer.
    ///
    /// # Panics
    ///
    /// Panics, wenn die Anzahl der Elemente im vector einen `usize` überschreitet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Hängt Elemente aus einem anderen Puffer an `Self` an.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Erstellt einen Drainage-Iterator, der den angegebenen Bereich im vector entfernt und die entfernten Elemente liefert.
    ///
    /// Wenn der Iterator ** gelöscht wird, werden alle Elemente im Bereich aus dem vector entfernt, auch wenn der Iterator nicht vollständig verbraucht wurde.
    /// Wenn der Iterator ** nicht gelöscht wird (z. B. mit [`mem::forget`]), ist nicht angegeben, wie viele Elemente entfernt werden.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Startpunkt größer als der Endpunkt ist oder wenn der Endpunkt größer als die Länge des vector ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Ein voller Bereich löscht den vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Speichersicherheit
        //
        // Wenn der Drain zum ersten Mal erstellt wird, verkürzt er die Länge der Quelle vector, um sicherzustellen, dass überhaupt keine nicht initialisierten oder verschobenen Elemente verfügbar sind, wenn der Destruktor des Drain nie ausgeführt werden kann.
        //
        //
        // Drain gibt die zu entfernenden Werte ptr::read aus.
        // Wenn Sie fertig sind, wird der verbleibende Schwanz des VEC zurückkopiert, um das Loch abzudecken, und die Länge von vector wird auf die neue Länge zurückgesetzt.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Stellen Sie die self.vec-Länge so ein, dass sie startet, um sicherzugehen, dass Drain durchgesickert ist
            self.set_len(start);
            // Verwenden Sie das Ausleihen im IterMut, um das Ausleihverhalten des gesamten Drain-Iterators (wie &mut T) anzuzeigen.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Löscht den vector und entfernt alle Werte.
    ///
    /// Beachten Sie, dass diese Methode keine Auswirkungen auf die zugewiesene Kapazität des vector hat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Gibt die Anzahl der Elemente im vector zurück, die auch als 'length' bezeichnet werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Gibt `true` zurück, wenn der vector keine Elemente enthält.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Teilt die Sammlung am angegebenen Index in zwei Teile.
    ///
    /// Gibt einen neu zugewiesenen vector zurück, der die Elemente im Bereich `[at, len)` enthält.
    /// Nach dem Aufruf bleibt der ursprüngliche vector mit den Elementen `[0, at)` mit seiner vorherigen Kapazität unverändert.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // Der neue vector kann den ursprünglichen Puffer übernehmen und das Kopieren vermeiden
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Unsicheres `set_len` und Kopieren von Elementen nach `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ändert die Größe des `Vec` an Ort und Stelle, sodass `len` gleich `new_len` ist.
    ///
    /// Wenn `new_len` größer als `len` ist, wird `Vec` um die Differenz erweitert, wobei jeder zusätzliche Steckplatz mit dem Ergebnis des Aufrufs des Abschlusses `f` gefüllt wird.
    ///
    /// Die Rückgabewerte von `f` landen in der Reihenfolge, in der sie generiert wurden, im `Vec`.
    ///
    /// Wenn `new_len` kleiner als `len` ist, wird `Vec` einfach abgeschnitten.
    ///
    /// Diese Methode verwendet einen Abschluss, um bei jedem Push neue Werte zu erstellen.Wenn Sie lieber einen bestimmten Wert [`Clone`] möchten, verwenden Sie [`Vec::resize`].
    /// Wenn Sie [`Default`] trait zum Generieren von Werten verwenden möchten, können Sie [`Default::default`] als zweites Argument übergeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Verbraucht und leckt den `Vec` und gibt einen veränderlichen Verweis auf den Inhalt zurück. `&'a mut [T]`.
    /// Beachten Sie, dass der Typ `T` die gewählte Lebensdauer `'a` überleben muss.
    /// Wenn der Typ nur statische oder gar keine Referenzen enthält, kann dies als `'static` gewählt werden.
    ///
    /// Diese Funktion ähnelt der [`leak`][Box::leak]-Funktion auf [`Box`], außer dass es keine Möglichkeit gibt, den durchgesickerten Speicher wiederherzustellen.
    ///
    ///
    /// Diese Funktion ist hauptsächlich für Daten nützlich, die für den Rest des Programmlebens gültig sind.
    /// Das Löschen der zurückgegebenen Referenz führt zu einem Speicherverlust.
    ///
    /// # Examples
    ///
    /// Einfache Verwendung:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Gibt die verbleibende freie Kapazität des vector als Slice von `MaybeUninit<T>` zurück.
    ///
    /// Das zurückgegebene Slice kann verwendet werden, um den vector mit Daten zu füllen (z
    /// durch Lesen aus einer Datei), bevor die Daten mit der [`set_len`]-Methode als initialisiert markiert werden.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Ordnen Sie vector groß genug für 10 Elemente zu.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Füllen Sie die ersten 3 Elemente aus.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Markieren Sie die ersten 3 Elemente des vector als initialisiert.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Diese Methode ist in Bezug auf `split_at_spare_mut` nicht implementiert, um die Ungültigmachung von Zeigern auf den Puffer zu verhindern.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Gibt den vector-Inhalt als Slice von `T` zurück, zusammen mit der verbleibenden freien Kapazität des vector als Slice von `MaybeUninit<T>`.
    ///
    /// Das zurückgegebene Slice für freie Kapazität kann verwendet werden, um den vector mit Daten zu füllen (z. B. durch Lesen aus einer Datei), bevor die Daten als mit der [`set_len`]-Methode initialisiert markiert werden.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Beachten Sie, dass dies eine Low-Level-API ist, die zu Optimierungszwecken mit Vorsicht verwendet werden sollte.
    /// Wenn Sie Daten an einen `Vec` anhängen müssen, können Sie je nach Ihren genauen Anforderungen [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] oder [`resize_with`] verwenden.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reservieren Sie zusätzlichen Platz für 10 Elemente.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Füllen Sie die nächsten 4 Elemente aus.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Markieren Sie die 4 Elemente des vector als initialisiert.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len wird ignoriert und daher nie geändert
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sicherheit: Das Ändern der zurückgegebenen .2 (&mut usize) entspricht dem Aufrufen von `.set_len(_)`.
    ///
    /// Diese Methode wird verwendet, um in `extend_from_within` einen eindeutigen Zugriff auf alle VEC-Teile gleichzeitig zu haben.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ist garantiert für `len`-Elemente gültig
        // - `spare_ptr` zeigt ein Element hinter den Puffer, damit es sich nicht mit `initialized` überlappt
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ändert die Größe des `Vec` an Ort und Stelle, sodass `len` gleich `new_len` ist.
    ///
    /// Wenn `new_len` größer als `len` ist, wird `Vec` um die Differenz erweitert, wobei jeder zusätzliche Steckplatz mit `value` gefüllt wird.
    ///
    /// Wenn `new_len` kleiner als `len` ist, wird `Vec` einfach abgeschnitten.
    ///
    /// Für diese Methode muss `T` [`Clone`] implementieren, um den übergebenen Wert klonen zu können.
    /// Wenn Sie mehr Flexibilität benötigen (oder sich auf [`Default`] anstelle von [`Clone`] verlassen möchten), verwenden Sie [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klont und hängt alle Elemente in einem Slice an den `Vec` an.
    ///
    /// Iteriert über das Slice `other`, klont jedes Element und hängt es dann an dieses `Vec` an.
    /// Der `other` vector wird der Reihe nach durchlaufen.
    ///
    /// Beachten Sie, dass diese Funktion mit [`extend`] identisch ist, außer dass sie darauf spezialisiert ist, stattdessen mit Slices zu arbeiten.
    ///
    /// Wenn Rust spezialisiert wird, ist diese Funktion wahrscheinlich veraltet (aber immer noch verfügbar).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopiert Elemente aus dem `src`-Bereich bis zum Ende des vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantiert, dass der angegebene Bereich für die Selbstindizierung gültig ist
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Dieser Code verallgemeinert `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Erweitern Sie den vector mit dem angegebenen Generator um `n`-Werte.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Verwenden Sie SetLenOnDrop, um Fehler zu umgehen, bei denen der Compiler den Speicher möglicherweise nicht über `ptr` bis self.set_len() erkennt.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Schreiben Sie alle Elemente außer dem letzten
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Erhöhen Sie die Länge in jedem Schritt, falls next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Wir können das letzte Element direkt schreiben, ohne unnötig zu klonen
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len von Scope Guard eingestellt
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Entfernt aufeinanderfolgende wiederholte Elemente im vector gemäß der [`PartialEq`] trait-Implementierung.
    ///
    ///
    /// Wenn der vector sortiert ist, werden alle Duplikate entfernt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Interne Methoden und Funktionen
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` muss ein gültiger Index sein
    /// - `self.capacity() - self.len()` muss `>= src.len()` sein
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len wird erst nach dem Initialisieren von Elementen erhöht
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - Der Anrufer garantiert, dass src ein gültiger Index ist
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element wurde gerade mit `MaybeUninit::write` initialisiert, daher ist es in Ordnung, len zu erhöhen
            // - len wird nach jedem Element erhöht, um Undichtigkeiten zu vermeiden (siehe Ausgabe #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - Der Anrufer garantiert, dass `src` ein gültiger Index ist
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Beide Zeiger werden aus eindeutigen Slice-Referenzen (`&mut [_]`) erstellt, sodass sie gültig sind und sich nicht überlappen.
            //
            // - Elemente sind: Kopieren, so dass es in Ordnung ist, sie zu kopieren, ohne etwas mit den ursprünglichen Werten zu tun
            // - `count` ist gleich der Länge von `source`, daher ist die Quelle für `count`-Lesevorgänge gültig
            // - `.reserve(count)` garantiert, dass `spare.len() >= count` so Ersatz für `count`-Schreibvorgänge gültig ist
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Die Elemente wurden gerade von `copy_nonoverlapping` initialisiert
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Gängige trait-Implementierungen für Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): Bei cfg(test) ist die für diese Methodendefinition erforderliche inhärente `[T]::to_vec`-Methode nicht verfügbar.
    // Verwenden Sie stattdessen die `slice::to_vec`-Funktion, die nur mit cfg(test) verfügbar ist. NB Weitere Informationen finden Sie im slice::hack-Modul in slice.rs
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // Lassen Sie alles fallen, was nicht überschrieben wird
        self.truncate(other.len());

        // self.len <= other.len aufgrund der obigen Kürzung, daher sind die Slices hier immer in Grenzen.
        //
        let (init, tail) = other.split_at(self.len());

        // Verwenden Sie die enthaltenen Werte allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Erstellt einen konsumierenden Iterator, dh einen, der jeden Wert aus dem vector verschiebt (von Anfang bis Ende).
    /// Der vector kann nach dem Aufruf nicht mehr verwendet werden.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s hat den Typ String, nicht &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // Blattmethode, an die verschiedene SpecFrom/SpecExtend-Implementierungen delegieren, wenn keine weiteren Optimierungen angewendet werden müssen
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Dies ist bei einem allgemeinen Iterator der Fall.
        //
        // Diese Funktion sollte das moralische Äquivalent sein von:
        //
        //      für Element im Iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB kann nicht überlaufen, da wir den Adressraum hätten zuweisen müssen
                self.set_len(len + 1);
            }
        }
    }

    /// Erstellt einen Spleißiterator, der den angegebenen Bereich im vector durch den angegebenen `replace_with`-Iterator ersetzt und die entfernten Elemente liefert.
    ///
    /// `replace_with` muss nicht die gleiche Länge wie `range` haben.
    ///
    /// `range` wird entfernt, auch wenn der Iterator erst am Ende verbraucht ist.
    ///
    /// Es ist nicht angegeben, wie viele Elemente aus dem vector entfernt werden, wenn der `Splice`-Wert durchgesickert ist.
    ///
    /// Der Eingabe-Iterator `replace_with` wird nur verwendet, wenn der `Splice`-Wert gelöscht wird.
    ///
    /// Dies ist optimal, wenn:
    ///
    /// * Der Schwanz (Elemente im vector nach `range`) ist leer,
    /// * oder `replace_with` liefert weniger oder gleiche Elemente als die Länge des Bereichs
    /// * oder die Untergrenze des `size_hint()` ist genau.
    ///
    /// Andernfalls wird ein temporärer vector zugewiesen und der Schwanz wird zweimal bewegt.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Startpunkt größer als der Endpunkt ist oder wenn der Endpunkt größer als die Länge des vector ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Erstellt einen Iterator, der mithilfe eines Abschlusses bestimmt, ob ein Element entfernt werden soll.
    ///
    /// Wenn der Abschluss true zurückgibt, wird das Element entfernt und ausgegeben.
    /// Wenn der Abschluss false zurückgibt, verbleibt das Element im vector und wird vom Iterator nicht ausgegeben.
    ///
    /// Die Verwendung dieser Methode entspricht dem folgenden Code:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // Ihr Code hier
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// `drain_filter` ist jedoch einfacher zu bedienen.
    /// `drain_filter` ist auch effizienter, da es die Elemente des Arrays in großen Mengen zurückschieben kann.
    ///
    /// Beachten Sie, dass Sie mit `drain_filter` auch jedes Element im Filterschluss mutieren können, unabhängig davon, ob Sie es behalten oder entfernen möchten.
    ///
    ///
    /// # Examples
    ///
    /// Aufteilen eines Arrays in Ereignisse und Gewinnchancen unter Wiederverwendung der ursprünglichen Zuordnung:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Schutz vor Leckagen (Leckverstärkung)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Erweitern Sie die Implementierung, die Elemente aus Referenzen kopiert, bevor Sie sie auf den Vec übertragen.
///
/// Diese Implementierung ist auf Slice-Iteratoren spezialisiert, bei denen [`copy_from_slice`] verwendet wird, um das gesamte Slice auf einmal anzuhängen.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementiert den Vergleich von vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementiert die Bestellung von vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // Verwenden Sie drop für [T]. Verwenden Sie eine Rohscheibe, um die Elemente des vector als schwächsten erforderlichen Typ zu bezeichnen.
            //
            // könnte in bestimmten Fällen Fragen der Gültigkeit vermeiden
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec übernimmt die Freigabe
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Erstellt ein leeres `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: Test zieht in libstd, was hier Fehler verursacht
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: Test zieht in libstd, was hier Fehler verursacht
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Ruft den gesamten Inhalt des `Vec<T>` als Array ab, wenn seine Größe genau mit der des angeforderten Arrays übereinstimmt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Wenn die Länge nicht übereinstimmt, wird die Eingabe in `Err` zurückgegeben:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Wenn Sie nur ein Präfix des `Vec<T>` erhalten möchten, können Sie zuerst [`.truncate(N)`](Vec::truncate) aufrufen.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SICHERHEIT: `.set_len(0)` ist immer einwandfrei.
        unsafe { vec.set_len(0) };

        // SICHERHEIT: Der Zeiger eines Vec ist immer richtig ausgerichtet, und
        // Die Ausrichtung, die das Array benötigt, entspricht den Elementen.
        // Wir haben früher überprüft, ob wir genügend Artikel haben.
        // Die Gegenstände werden nicht doppelt fallen gelassen, da der `set_len` den `Vec` anweist, sie nicht auch fallen zu lassen.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}