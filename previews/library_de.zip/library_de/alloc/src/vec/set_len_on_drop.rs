// Stellen Sie die Länge des VEC ein, wenn der `SetLenOnDrop`-Wert den Gültigkeitsbereich verlässt.
//
// Die Idee ist: Das Längenfeld in SetLenOnDrop ist eine lokale Variable, die der Optimierer sieht und die keinen Alias mit Speichern über den Datenzeiger des Vec hat.
// Dies ist eine Problemumgehung für das Alias-Analyseproblem #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}