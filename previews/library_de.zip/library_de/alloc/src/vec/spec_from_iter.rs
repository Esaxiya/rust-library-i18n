use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spezialisierung trait für Vec::from_iter
///
/// ## Das Delegierungsdiagramm:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ein häufiger Fall besteht darin, einen vector an eine Funktion zu übergeben, die sich sofort wieder in einem vector sammelt.
        // Wir können dies kurzschließen, wenn der IntoIter überhaupt nicht weiterentwickelt wurde.
        // Wenn es erweitert wurde, können wir den Speicher auch wiederverwenden und die Daten nach vorne verschieben.
        // Dies tun wir jedoch nur, wenn der resultierende Vec nicht über mehr ungenutzte Kapazität verfügt, als dies durch die generische FromIterator-Implementierung der Fall wäre.
        //
        // Diese Einschränkung ist nicht unbedingt erforderlich, da das Zuordnungsverhalten von Vec absichtlich nicht spezifiziert ist.
        // Aber es ist eine konservative Wahl.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // muss an spec_extend() delegieren, da extend() selbst für leere Vecs an spec_from delegiert
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Dies verwendet `iterator.as_slice().to_vec()`, da spec_extend mehr Schritte unternehmen muss, um über die endgültige Kapazität + Länge nachzudenken und somit mehr Arbeit zu erledigen.
// `to_vec()` ordnet direkt die richtige Menge zu und füllt sie genau aus.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): Bei cfg(test) ist die für diese Methodendefinition erforderliche inhärente `[T]::to_vec`-Methode nicht verfügbar.
    // Verwenden Sie stattdessen die `slice::to_vec`-Funktion, die nur mit cfg(test) verfügbar ist. NB Weitere Informationen finden Sie im slice::hack-Modul in slice.rs
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}