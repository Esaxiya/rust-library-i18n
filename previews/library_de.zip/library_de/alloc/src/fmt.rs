//! Dienstprogramme zum Formatieren und Drucken von `String`s.
//!
//! Dieses Modul enthält die Laufzeitunterstützung für die [`format!`]-Syntaxerweiterung.
//! Dieses Makro ist im Compiler implementiert, um Aufrufe an dieses Modul zu senden, um Argumente zur Laufzeit in Zeichenfolgen zu formatieren.
//!
//! # Usage
//!
//! Das [`format!`]-Makro soll denjenigen bekannt sein, die aus den `printf`/`fprintf`-Funktionen von C oder der `str.format`-Funktion von Python stammen.
//!
//! Einige Beispiele für die [`format!`]-Erweiterung sind:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" mit führenden Nullen
//! ```
//!
//! Daraus können Sie ersehen, dass das erste Argument eine Formatzeichenfolge ist.Der Compiler muss ein String-Literal sein.Es kann keine übergebene Variable sein (um eine Gültigkeitsprüfung durchzuführen).
//! Der Compiler analysiert dann die Formatzeichenfolge und ermittelt, ob die Liste der bereitgestellten Argumente für die Übergabe an diese Formatzeichenfolge geeignet ist.
//!
//! Verwenden Sie die [`to_string`]-Methode, um einen einzelnen Wert in eine Zeichenfolge zu konvertieren.Dies verwendet die [`Display`]-Formatierung trait.
//!
//! ## Positionsparameter
//!
//! Jedes Formatierungsargument darf angeben, auf welches Wertargument es verweist, und wenn es weggelassen wird, wird angenommen, dass es "the next argument" ist.
//! Beispielsweise würde die Formatzeichenfolge `{} {} {}` drei Parameter annehmen und sie würden in derselben Reihenfolge formatiert, in der sie angegeben sind.
//! Die Formatzeichenfolge `{2} {1} {0}` würde Argumente jedoch in umgekehrter Reihenfolge formatieren.
//!
//! Sobald Sie die beiden Arten von Positionsspezifizierern miteinander vermischen, kann es etwas schwierig werden.Der "next argument"-Bezeichner kann als Iterator über das Argument betrachtet werden.
//! Jedes Mal, wenn ein "next argument"-Spezifizierer angezeigt wird, rückt der Iterator vor.Dies führt zu folgendem Verhalten:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Der interne Iterator über das Argument wurde zum Zeitpunkt der Anzeige des ersten `{}` noch nicht erweitert, sodass das erste Argument gedruckt wird.Beim Erreichen des zweiten `{}` ist der Iterator zum zweiten Argument übergegangen.
//! Im Wesentlichen wirken sich Parameter, die ihr Argument explizit benennen, nicht auf Parameter aus, die kein Argument in Bezug auf Positionsspezifizierer benennen.
//!
//! Eine Formatzeichenfolge ist erforderlich, um alle Argumente zu verwenden. Andernfalls handelt es sich um einen Fehler bei der Kompilierung.Sie können in der Formatzeichenfolge mehrmals auf dasselbe Argument verweisen.
//!
//! ## Benannte Parameter
//!
//! Rust selbst verfügt nicht über ein Python-ähnliches Äquivalent benannter Parameter zu einer Funktion, aber das [`format!`]-Makro ist eine Syntaxerweiterung, mit der benannte Parameter genutzt werden können.
//! Benannte Parameter werden am Ende der Argumentliste aufgelistet und haben folgende Syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Beispielsweise verwenden die folgenden [`format!`]-Ausdrücke alle benannte Argumente:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Es ist nicht gültig, Positionsparameter (solche ohne Namen) nach Argumenten mit Namen einzufügen.Wie bei Positionsparametern ist es nicht gültig, benannte Parameter anzugeben, die von der Formatzeichenfolge nicht verwendet werden.
//!
//! # Formatierungsparameter
//!
//! Jedes zu formatierende Argument kann durch eine Reihe von Formatierungsparametern (entsprechend `format_spec` in [the syntax](#syntax))) transformiert werden. Diese Parameter wirken sich auf die Zeichenfolgendarstellung der zu formatierenden Elemente aus.
//!
//! ## Width
//!
//! ```
//! // Alle diese drucken "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dies ist ein Parameter für den "minimum width", den das Format annehmen soll.
//! Wenn die Zeichenfolge des Werts nicht so viele Zeichen ausfüllt, wird der von fill/alignment angegebene Abstand verwendet, um den erforderlichen Platz einzunehmen (siehe unten).
//!
//! Der Wert für die Breite kann auch als [`usize`] in der Liste der Parameter angegeben werden, indem ein Postfix `$` hinzugefügt wird, das angibt, dass das zweite Argument ein [`usize`] ist, das die Breite angibt.
//!
//! Das Verweisen auf ein Argument mit der Dollar-Syntax wirkt sich nicht auf den "next argument"-Zähler aus. Daher ist es normalerweise eine gute Idee, auf Argumente nach Position zu verweisen oder benannte Argumente zu verwenden.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Das optionale Füllzeichen und die optionale Ausrichtung werden normalerweise in Verbindung mit dem Parameter [`width`](#width) bereitgestellt.Es muss vor `width` direkt nach dem `:` definiert werden.
//! Dies zeigt an, dass, wenn der zu formatierende Wert kleiner als `width` ist, einige zusätzliche Zeichen um ihn herum gedruckt werden.
//! Die Füllung erfolgt in folgenden Varianten für verschiedene Ausrichtungen:
//!
//! * `[fill]<` - Das Argument ist in `width`-Spalten linksbündig
//! * `[fill]^` - Das Argument ist in `width`-Spalten zentriert
//! * `[fill]>` - Das Argument ist in `width`-Spalten rechtsbündig
//!
//! Das Standard-[fill/alignment](#fillalignment) für nicht numerische Zeichen ist ein Leerzeichen und linksbündig.Die Standardeinstellung für numerische Formatierer ist ebenfalls ein Leerzeichen, jedoch mit Rechtsausrichtung.
//! Wenn das `0`-Flag (siehe unten) für Zahlen angegeben ist, lautet das implizite Füllzeichen `0`.
//!
//! Beachten Sie, dass die Ausrichtung von einigen Typen möglicherweise nicht implementiert wird.Insbesondere ist es für den `Debug` trait im Allgemeinen nicht implementiert.
//! Eine gute Möglichkeit, um sicherzustellen, dass das Auffüllen angewendet wird, besteht darin, Ihre Eingabe zu formatieren und dann diese resultierende Zeichenfolge aufzufüllen, um Ihre Ausgabe zu erhalten:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hallo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dies sind alles Flags, die das Verhalten des Formatierers ändern.
//!
//! * `+` - Dies ist für numerische Typen vorgesehen und gibt an, dass das Zeichen immer gedruckt werden sollte.Positive Vorzeichen werden standardmäßig nie gedruckt, und das negative Vorzeichen wird standardmäßig nur für den `Signed` trait gedruckt.
//! Dieses Flag zeigt an, dass immer das richtige Zeichen (`+` oder `-`) gedruckt werden sollte.
//! * `-` - Derzeit nicht verwendet
//! * `#` - Dieses Flag zeigt an, dass die "alternate"-Druckform verwendet werden soll.Die alternativen Formen sind:
//!     * `#?` - Drucken Sie die [`Debug`]-Formatierung hübsch aus
//!     * `#x` - Vor dem Argument steht ein `0x`
//!     * `#X` - Vor dem Argument steht ein `0x`
//!     * `#b` - Vor dem Argument steht ein `0b`
//!     * `#o` - Vor dem Argument steht ein `0o`
//! * `0` - Dies wird verwendet, um für ganzzahlige Formate anzugeben, dass das Auffüllen von `width` sowohl mit einem `0`-Zeichen als auch mit Vorzeichen erfolgen sollte.
//! Ein Format wie `{:08}` würde `00000001` für die Ganzzahl `1` ergeben, während dasselbe Format `-0000001` für die Ganzzahl `-1` ergeben würde.
//! Beachten Sie, dass die negative Version eine Null weniger hat als die positive Version.
//!         Beachten Sie, dass Füllzeichen immer nach dem Vorzeichen (falls vorhanden) und vor den Ziffern stehen.Bei Verwendung zusammen mit dem `#`-Flag gilt eine ähnliche Regel: Nach dem Präfix, jedoch vor den Ziffern werden Auffüllnullen eingefügt.
//!         Das Präfix ist in der Gesamtbreite enthalten.
//!
//! ## Precision
//!
//! Bei nicht numerischen Typen kann dies als "maximum width" betrachtet werden.
//! Wenn die resultierende Zeichenfolge länger als diese Breite ist, wird sie auf so viele Zeichen gekürzt, und dieser abgeschnittene Wert wird mit den richtigen `fill`, `alignment` und `width` ausgegeben, wenn diese Parameter festgelegt sind.
//!
//! Bei integralen Typen wird dies ignoriert.
//!
//! Bei Gleitkommatypen gibt dies an, wie viele Stellen nach dem Dezimalpunkt gedruckt werden sollen.
//!
//! Es gibt drei Möglichkeiten, das gewünschte `precision` anzugeben:
//!
//! 1. Eine Ganzzahl `.N`:
//!
//!    Die Ganzzahl `N` selbst ist die Genauigkeit.
//!
//! 2. Eine Ganzzahl oder ein Name, gefolgt von einem Dollarzeichen `.N$`:
//!
//!    Verwenden Sie als Genauigkeit das Format *Argument*`N` (das ein `usize` sein muss).
//!
//! 3. Ein Sternchen `.*`:
//!
//!    `.*` bedeutet, dass dieser `{...}` eher Eingaben im Format *zwei* als einer zugeordnet ist: Die erste Eingabe enthält die `usize`-Genauigkeit und die zweite den zu druckenden Wert.
//!    Beachten Sie, dass in diesem Fall, wenn Sie die Formatzeichenfolge `{<arg>:<spec>.*}` verwenden, der `<arg>`-Teil auf den zu druckenden* Wert * verweist und der `precision` in die Eingabe vor `<arg>` kommen muss.
//!
//! Die folgenden Aufrufe drucken beispielsweise alle dasselbe `Hello x is 0.01000`:
//!
//! ```
//! // Hallo {arg 0 ("x")} ist {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hallo {arg 1 ("x")} ist {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hallo {arg 0 ("x")} ist {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} ist {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} ist {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} ist {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Während diese:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! Drucken Sie drei wesentlich unterschiedliche Dinge:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! In einigen Programmiersprachen hängt das Verhalten der Zeichenfolgenformatierungsfunktionen von der Ländereinstellung des Betriebssystems ab.
//! Die von der Standardbibliothek von Rust bereitgestellten Formatierungsfunktionen haben kein Konzept für das Gebietsschema und führen auf allen Systemen unabhängig von der Benutzerkonfiguration zu denselben Ergebnissen.
//!
//! Der folgende Code gibt beispielsweise immer `1.5` aus, auch wenn das Systemgebietsschema ein anderes Dezimaltrennzeichen als einen Punkt verwendet.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Die Literalzeichen `{` und `}` können in eine Zeichenfolge aufgenommen werden, indem ihnen dasselbe Zeichen vorangestellt wird.Beispielsweise wird das `{`-Zeichen mit `{{` und das `}`-Zeichen mit `}}` maskiert.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Zusammenfassend finden Sie hier die vollständige Grammatik der Formatzeichenfolgen.
//! Die Syntax für die verwendete Formatierungssprache stammt aus anderen Sprachen und sollte daher nicht zu fremd sein.Argumente werden mit der Python-ähnlichen Syntax formatiert, was bedeutet, dass Argumente von `{}` anstelle des C-ähnlichen `%` umgeben sind.
//! Die eigentliche Grammatik für die Formatierungssyntax lautet:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! In der obigen Grammatik darf `text` keine `'{'`-oder `'}'`-Zeichen enthalten.
//!
//! # Formatieren von traits
//!
//! Wenn Sie anfordern, dass ein Argument mit einem bestimmten Typ formatiert wird, fordern Sie tatsächlich an, dass ein Argument einem bestimmten trait zugeordnet wird.
//! Dadurch können mehrere tatsächliche Typen über `{:x}` formatiert werden (wie [`i8`] sowie [`isize`]).Die aktuelle Zuordnung von Typen zu traits lautet:
//!
//! * *nichts* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] mit hexadezimalen Ganzzahlen in Kleinbuchstaben
//! * `X?` ⇒ [`Debug`] mit hexadezimalen Ganzzahlen in Großbuchstaben
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Dies bedeutet, dass jede Art von Argument, das den [`fmt::Binary`][`Binary`] trait implementiert, dann mit `{:b}` formatiert werden kann.Für diese traits werden auch Implementierungen für eine Reihe von primitiven Typen von der Standardbibliothek bereitgestellt.
//!
//! Wenn kein Format angegeben ist (wie in `{}` oder `{:6}`), wird als Format trait [`Display`] trait verwendet.
//!
//! Wenn Sie ein Format trait für Ihren eigenen Typ implementieren, müssen Sie eine Methode der Signatur implementieren:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // unser kundenspezifischer Typ
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Ihr Typ wird als `self`-Referenz übergeben, und dann sollte die Funktion eine Ausgabe in den `f.buf`-Stream ausgeben.Es liegt an jeder Format-trait-Implementierung, die angeforderten Formatierungsparameter korrekt einzuhalten.
//! Die Werte dieser Parameter werden in den Feldern der [`Formatter`]-Struktur aufgelistet.Um dies zu unterstützen, bietet die [`Formatter`]-Struktur auch einige Hilfsmethoden.
//!
//! Außerdem ist der Rückgabewert dieser Funktion [`fmt::Result`], ein Typalias von [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Formatierungsimplementierungen sollten sicherstellen, dass sie Fehler vom [`Formatter`] weitergeben (z. B. beim Aufrufen von [`write!`]).
//! Sie sollten jedoch niemals fälschlicherweise Fehler zurückgeben.
//! Das heißt, eine Formatierungsimplementierung muss und darf nur dann einen Fehler zurückgeben, wenn das übergebene [`Formatter`] einen Fehler zurückgibt.
//! Dies liegt daran, dass die Formatierung von Zeichenfolgen im Gegensatz zu dem, was die Funktionssignatur vermuten lässt, eine unfehlbare Operation ist.
//! Diese Funktion gibt nur ein Ergebnis zurück, da das Schreiben in den zugrunde liegenden Stream möglicherweise fehlschlägt und eine Möglichkeit bieten muss, die Tatsache zu verbreiten, dass beim Sichern des Stapels ein Fehler aufgetreten ist.
//!
//! Ein Beispiel für die Implementierung der Formatierung traits sieht folgendermaßen aus:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Der `f`-Wert implementiert den `Write` trait, was das Schreiben ist!Makro erwartet.
//!         // Beachten Sie, dass bei dieser Formatierung die verschiedenen Flags zum Formatieren von Zeichenfolgen ignoriert werden.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Unterschiedliche traits ermöglichen unterschiedliche Ausgabeformen eines Typs.
//! // Die Bedeutung dieses Formats besteht darin, die Größe eines vector zu drucken.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Beachten Sie die Formatierungsflags mithilfe der Hilfsmethode `pad_integral` für das Formatter-Objekt.
//!         // Weitere Informationen finden Sie in der Methodendokumentation. Mit der Funktion `pad` können Zeichenfolgen aufgefüllt werden.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Diese beiden Formatierungen von traits dienen unterschiedlichen Zwecken:
//!
//! - [`fmt::Display`][`Display`] Implementierungen bestätigen, dass der Typ jederzeit originalgetreu als UTF-8-Zeichenfolge dargestellt werden kann.Es wird **nicht** erwartet, dass alle Typen den [`Display`] trait implementieren.
//! - [`fmt::Debug`][`Debug`] Implementierungen sollten für **alle** öffentlichen Typen implementiert werden.
//!   Die Ausgabe repräsentiert normalerweise den internen Zustand so genau wie möglich.
//!   Der Zweck des [`Debug`] trait besteht darin, das Debuggen von Rust-Code zu erleichtern.In den meisten Fällen ist die Verwendung von `#[derive(Debug)]` ausreichend und wird empfohlen.
//!
//! Einige Beispiele für die Ausgabe von beiden traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Verwandte Makros
//!
//! Es gibt eine Reihe verwandter Makros in der [`format!`]-Familie.Die derzeit implementierten sind:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dies und [`writeln!`] sind zwei Makros, mit denen die Formatzeichenfolge an einen bestimmten Stream ausgegeben wird.Dies wird verwendet, um Zwischenzuweisungen von Formatzeichenfolgen zu verhindern und stattdessen die Ausgabe direkt zu schreiben.
//! Unter der Haube ruft diese Funktion tatsächlich die auf dem [`std::io::Write`] trait definierte [`write_fmt`]-Funktion auf.
//! Beispiel für die Verwendung ist:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dies und [`println!`] senden ihre Ausgabe an stdout.Ähnlich wie beim [`write!`]-Makro besteht das Ziel dieser Makros darin, Zwischenzuweisungen beim Drucken der Ausgabe zu vermeiden.Beispiel für die Verwendung ist:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Die Makros [`eprint!`] und [`eprintln!`] sind mit [`print!`] bzw. [`println!`] identisch, außer dass sie ihre Ausgabe an stderr senden.
//!
//! ### `format_args!`
//!
//! Dies ist ein merkwürdiges Makro, mit dem ein undurchsichtiges Objekt, das die Formatzeichenfolge beschreibt, sicher umgangen werden kann.Für dieses Objekt sind keine Heap-Zuordnungen erforderlich, und es verweist nur auf Informationen auf dem Stapel.
//! Unter der Haube werden alle zugehörigen Makros in diesem Sinne implementiert.
//! Zunächst einmal ist ein Beispiel für die Verwendung:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Das Ergebnis des [`format_args!`]-Makros ist ein Wert vom Typ [`fmt::Arguments`].
//! Diese Struktur kann dann an die [`write`]-und [`format`]-Funktionen in diesem Modul übergeben werden, um die Formatzeichenfolge zu verarbeiten.
//! Das Ziel dieses Makros ist es, Zwischenzuordnungen beim Formatieren von Zeichenfolgen noch weiter zu verhindern.
//!
//! Beispielsweise könnte eine Protokollierungsbibliothek die Standardformatierungssyntax verwenden, diese Struktur wird jedoch intern weitergegeben, bis festgelegt wurde, wohin die Ausgabe gehen soll.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Die `format`-Funktion verwendet eine [`Arguments`]-Struktur und gibt die resultierende formatierte Zeichenfolge zurück.
///
///
/// Die [`Arguments`]-Instanz kann mit dem [`format_args!`]-Makro erstellt werden.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Bitte beachten Sie, dass die Verwendung von [`format!`] möglicherweise vorzuziehen ist.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}