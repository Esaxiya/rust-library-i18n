#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typen und Traits für die Arbeit mit asynchronen Aufgaben.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Die Implementierung des Aufweckens einer Aufgabe auf einem Executor.
///
/// Mit diesem trait kann ein [`Waker`] erstellt werden.
/// Ein Executor kann eine Implementierung dieses trait definieren und damit einen Waker erstellen, der an die Aufgaben übergeben wird, die auf diesem Executor ausgeführt werden.
///
/// Dieser trait ist eine speichersichere und ergonomische Alternative zum Aufbau eines [`RawWaker`].
/// Es unterstützt das allgemeine Executor-Design, bei dem die zum Aufwecken einer Aufgabe verwendeten Daten in einem [`Arc`] gespeichert werden.
/// Einige Executoren (insbesondere für eingebettete Systeme) können diese API nicht verwenden, weshalb [`RawWaker`] als Alternative für diese Systeme verfügbar ist.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Eine grundlegende `block_on`-Funktion, die ein future verwendet und es auf dem aktuellen Thread vollständig ausführt.
///
/// **Note:** In diesem Beispiel wird die Korrektheit der Einfachheit halber ausgetauscht.
/// Um Deadlocks zu vermeiden, müssen Implementierungen in Produktionsqualität auch Zwischenaufrufe an `thread::unpark` sowie verschachtelte Aufrufe verarbeiten.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Ein Waker, der beim Aufrufen den aktuellen Thread aufweckt.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Führen Sie eine future für den aktuellen Thread vollständig aus.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin das future, damit es abgefragt werden kann.
///     let mut fut = Box::pin(fut);
///
///     // Erstellen Sie einen neuen Kontext, der an future übergeben werden soll.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Führen Sie den future vollständig aus.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Wecken Sie diese Aufgabe.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Wecken Sie diese Aufgabe, ohne den Waker zu verbrauchen.
    ///
    /// Wenn ein Executor eine billigere Methode zum Aufwecken unterstützt, ohne den Waker zu verbrauchen, sollte er diese Methode überschreiben.
    /// Standardmäßig klont es den [`Arc`] und ruft [`wake`] auf dem Klon auf.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SICHERHEIT: Dies ist sicher, da raw_waker sicher konstruiert
        // ein RawWaker von Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Diese private Funktion zum Erstellen eines RawWaker wird anstelle von verwendet
// Dies wird in das `From<Arc<W>> for RawWaker`-Gerät eingefügt, um sicherzustellen, dass die Sicherheit von `From<Arc<W>> for Waker` nicht vom korrekten trait-Versand abhängt. Stattdessen rufen beide Geräte diese Funktion direkt und explizit auf.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Erhöhen Sie den Referenzzähler des Bogens, um ihn zu klonen.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wecken Sie nach Wert und verschieben Sie den Bogen in die Wake::wake-Funktion
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Wachen Sie als Referenz auf und wickeln Sie den Waker in ManuallyDrop ein, um ein Fallenlassen zu vermeiden
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Verringern Sie die Referenzanzahl des Bogens beim Ablegen
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}