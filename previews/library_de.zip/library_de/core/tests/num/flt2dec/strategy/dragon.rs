use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri ist zu langsam
fn exact_sanity_test() {
    // Dieser Test wird ausgeführt. Ich kann nur davon ausgehen, dass es sich um einen Eckfall der `exp2`-Bibliotheksfunktion handelt, der in der von uns verwendeten C-Laufzeit definiert ist.
    // In VS 2013 hatte diese Funktion anscheinend einen Fehler, da dieser Test beim Verknüpfen fehlschlägt. Bei VS 2015 scheint der Fehler jedoch behoben zu sein, da der Test einwandfrei ausgeführt wird.
    //
    // Der Fehler scheint ein Unterschied im Rückgabewert von `exp2(-1057)` zu sein, wobei in VS 2013 ein Double mit dem Bitmuster 0x2 und in VS 2015 0x20000 zurückgegeben wird.
    //
    //
    // Ignorieren Sie diesen Test vorerst einfach vollständig auf MSVC, da er ohnehin an anderer Stelle getestet wurde und wir nicht besonders daran interessiert sind, die exp2-Implementierung jeder Plattform zu testen.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}