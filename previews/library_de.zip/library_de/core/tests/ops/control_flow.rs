use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Dies ist keine stabile Oberfläche, hilft aber dabei, `?` zwischen ihnen billig zu halten, auch wenn LLVM dies momentan nicht immer nutzen kann.
    //
    // (Leider sind Ergebnis und Option inkonsistent, sodass ControlFlow nicht mit beiden übereinstimmen kann.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}