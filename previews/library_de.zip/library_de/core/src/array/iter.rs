//! Definiert den `IntoIter`-eigenen Iterator für Arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Ein Byte-Value-[array]-Iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dies ist das Array, über das wir iterieren.
    ///
    /// Elemente mit dem Index `i`, bei denen `alive.start <= i < alive.end` noch nicht ausgegeben wurde und gültige Array-Einträge sind.
    /// Elemente mit den Indizes `i < alive.start` oder `i >= alive.end` wurden bereits ausgegeben und dürfen nicht mehr aufgerufen werden!Diese toten Elemente könnten sich sogar in einem völlig nicht initialisierten Zustand befinden!
    ///
    ///
    /// Die Invarianten sind also:
    /// - `data[alive]` lebt (dh enthält gültige Elemente)
    /// - `data[..alive.start]` und `data[alive.end..]` sind tot (dh die Elemente wurden bereits gelesen und dürfen nicht mehr berührt werden!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Die Elemente in `data`, die noch nicht ausgegeben wurden.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Erstellt einen neuen Iterator über dem angegebenen `array`.
    ///
    /// *Hinweis*: Diese Methode ist im future nach [`IntoIterator` is implemented for arrays][array-into-iter] möglicherweise veraltet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Der Typ von `value` ist hier ein `i32` anstelle von `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SICHERHEIT: Die Umwandlung hier ist tatsächlich sicher.Die Dokumente von `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ist garantiert die gleiche Größe und Ausrichtung
        // > als `T`.
        //
        // Die Dokumente zeigen sogar eine Umwandlung von einem Array von `MaybeUninit<T>` in ein Array von `T`.
        //
        //
        // Damit erfüllt diese Initialisierung die Invarianten.

        // FIXME(LukasKalbertodt): Verwenden Sie hier tatsächlich `mem::transmute`, sobald es mit const generics funktioniert:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Bis dahin können wir mit `mem::transmute_copy` eine bitweise Kopie als anderen Typ erstellen und dann `array` vergessen, damit es nicht gelöscht wird.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Gibt einen unveränderlichen Slice aller Elemente zurück, die noch nicht erhalten wurden.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SICHERHEIT: Wir wissen, dass alle Elemente in `alive` ordnungsgemäß initialisiert wurden.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Gibt eine veränderbare Schicht aller Elemente zurück, die noch nicht erhalten wurden.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SICHERHEIT: Wir wissen, dass alle Elemente in `alive` ordnungsgemäß initialisiert wurden.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Holen Sie sich den nächsten Index von vorne.
        //
        // Durch Erhöhen von `alive.start` um 1 bleibt die Invariante in Bezug auf `alive` erhalten.
        // Aufgrund dieser Änderung ist die lebendige Zone jedoch für kurze Zeit nicht mehr `data[alive]`, sondern `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lesen Sie das Element aus dem Array.
            // SICHERHEIT: `idx` ist ein Index in die frühere "alive"-Region der
            // Array.Das Lesen dieses Elements bedeutet, dass `data[idx]` jetzt als tot angesehen wird (dh nicht berühren).
            // Da `idx` der Beginn der lebendigen Zone war, ist die lebendige Zone jetzt wieder `data[alive]` und stellt alle Invarianten wieder her.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Holen Sie sich den nächsten Index von hinten.
        //
        // Wenn Sie `alive.end` um 1 verringern, bleibt die Invariante für `alive` erhalten.
        // Aufgrund dieser Änderung ist die lebendige Zone jedoch für kurze Zeit nicht mehr `data[alive]`, sondern `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lesen Sie das Element aus dem Array.
            // SICHERHEIT: `idx` ist ein Index in die frühere "alive"-Region der
            // Array.Das Lesen dieses Elements bedeutet, dass `data[idx]` jetzt als tot angesehen wird (dh nicht berühren).
            // Da `idx` das Ende der lebendigen Zone war, ist die lebendige Zone jetzt wieder `data[alive]` und stellt alle Invarianten wieder her.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SICHERHEIT: Dies ist sicher: `as_mut_slice` gibt genau das Sub-Slice zurück
        // von Elementen, die noch nicht verschoben wurden und die noch gelöscht werden müssen.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Wird aufgrund der Invariante `living.start <=niemals unterlaufen
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Der Iterator gibt tatsächlich die richtige Länge an.
// Die Anzahl der "alive"-Elemente (die noch ausgegeben werden) entspricht der Länge des Bereichs `alive`.
// Dieser Bereich wird in `next` oder `next_back` in der Länge verringert.
// Bei diesen Methoden wird es immer um 1 dekrementiert, jedoch nur, wenn `Some(_)` zurückgegeben wird.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Beachten Sie, dass wir nicht wirklich genau den gleichen aktiven Bereich haben müssen, sodass wir einfach in den Offset 0 klonen können, unabhängig davon, wo sich `self` befindet.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonen Sie alle lebendigen Elemente.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Schreiben Sie einen Klon in das neue Array und aktualisieren Sie den aktiven Bereich.
            // Wenn Sie panics klonen, werden die vorherigen Elemente korrekt gelöscht.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Drucken Sie nur die Elemente aus, die noch nicht ausgegeben wurden: Wir können nicht mehr auf die zurückgegebenen Elemente zugreifen.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}