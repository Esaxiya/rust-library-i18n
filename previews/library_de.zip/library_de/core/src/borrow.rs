//! Ein Modul zum Arbeiten mit ausgeliehenen Daten.

#![stable(feature = "rust1", since = "1.0.0")]

/// Ein trait zum Ausleihen von Daten.
///
/// In Rust ist es üblich, unterschiedliche Darstellungen eines Typs für unterschiedliche Anwendungsfälle bereitzustellen.
/// Beispielsweise können Speicherort und Verwaltung für einen Wert über Zeigertypen wie [`Box<T>`] oder [`Rc<T>`] speziell für eine bestimmte Verwendung ausgewählt werden.
/// Abgesehen von diesen generischen Wrappern, die mit jedem Typ verwendet werden können, bieten einige Typen optionale Facetten, die möglicherweise kostspielige Funktionen bieten.
/// Ein Beispiel für einen solchen Typ ist [`String`], mit dem eine Zeichenfolge zum Basis-[`str`] erweitert werden kann.
/// Dies erfordert, dass zusätzliche Informationen für eine einfache, unveränderliche Zeichenfolge nicht erforderlich sind.
///
/// Diese Typen bieten Zugriff auf die zugrunde liegenden Daten durch Verweise auf den Typ dieser Daten.Sie sollen als dieser Typ "ausgeliehen" sein.
/// Beispielsweise kann ein [`Box<T>`] als `T` ausgeliehen werden, während ein [`String`] als `str` ausgeliehen werden kann.
///
/// Typen drücken aus, dass sie durch Implementierung von `Borrow<T>` als Typ `T` ausgeliehen werden können, wobei ein Verweis auf ein `T` in der [`borrow`]-Methode des trait bereitgestellt wird.Ein Typ kann kostenlos als verschiedene Typen ausgeliehen werden.
/// Wenn es als Typ veränderlich ausgeliehen werden soll, sodass die zugrunde liegenden Daten geändert werden können, kann es zusätzlich [`BorrowMut<T>`] implementieren.
///
/// Wenn Implementierungen für zusätzliche traits bereitgestellt werden, muss außerdem berücksichtigt werden, ob sie sich als Folge der Darstellung dieses zugrunde liegenden Typs mit denen des zugrunde liegenden Typs identisch verhalten sollten.
/// Generischer Code verwendet normalerweise `Borrow<T>`, wenn er sich auf das identische Verhalten dieser zusätzlichen trait-Implementierungen stützt.
/// Diese traits werden wahrscheinlich als zusätzliche trait bounds angezeigt.
///
/// Insbesondere müssen `Eq`, `Ord` und `Hash` für geliehene und eigene Werte gleichwertig sein: `x.borrow() == y.borrow()` sollte das gleiche Ergebnis wie `x == y` liefern.
///
/// Wenn generischer Code nur für alle Typen funktionieren muss, die einen Verweis auf den verwandten Typ `T` liefern können, ist es häufig besser, [`AsRef<T>`] zu verwenden, da mehr Typen ihn sicher implementieren können.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Als Datenerfassung besitzt [`HashMap<K, V>`] sowohl Schlüssel als auch Werte.Wenn die tatsächlichen Daten des Schlüssels in einen Verwaltungstyp eingeschlossen sind, sollte es dennoch möglich sein, unter Verwendung eines Verweises auf die Daten des Schlüssels nach einem Wert zu suchen.
/// Wenn der Schlüssel beispielsweise eine Zeichenfolge ist, wird er wahrscheinlich mit der Hash-Map als [`String`] gespeichert, während die Suche mit einem [`&str`][`str`] möglich sein sollte.
/// Daher muss `insert` auf einem `String` betrieben werden, während `get` in der Lage sein muss, einen `&str` zu verwenden.
///
/// Etwas vereinfacht sehen die relevanten Teile von `HashMap<K, V>` folgendermaßen aus:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // Felder weggelassen
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Die gesamte Hash-Map ist generisch über einen Schlüsseltyp `K`.Da diese Schlüssel in der Hash-Map gespeichert sind, muss dieser Typ die Daten des Schlüssels besitzen.
/// Beim Einfügen eines Schlüssel-Wert-Paares erhält die Karte einen solchen `K` und muss den richtigen Hash-Bucket finden und anhand dieses `K` prüfen, ob der Schlüssel bereits vorhanden ist.Es erfordert daher `K: Hash + Eq`.
///
/// Bei der Suche nach einem Wert in der Karte muss jedoch immer ein solcher Wert erstellt werden, wenn ein Verweis auf einen `K` als zu suchenden Schlüssel angegeben werden muss.
/// Für Zeichenfolgenschlüssel würde dies bedeuten, dass ein `String`-Wert nur für die Suche nach Fällen erstellt werden muss, in denen nur ein `str` verfügbar ist.
///
/// Stattdessen ist die `get`-Methode generisch über den Typ der zugrunde liegenden Schlüsseldaten, die in der obigen Methodensignatur als `Q` bezeichnet werden.Es besagt, dass `K` als `Q` ausgeliehen wird, indem `K: Borrow<Q>` benötigt wird.
/// Durch die zusätzliche Anforderung von `Q: Hash + Eq` wird die Anforderung signalisiert, dass `K` und `Q` über Implementierungen von `Hash` und `Eq` traits verfügen, die identische Ergebnisse liefern.
///
/// Die Implementierung von `get` basiert insbesondere auf identischen Implementierungen von `Hash`, indem der Hash-Bucket des Schlüssels durch Aufrufen von `Hash::hash` für den `Q`-Wert ermittelt wird, obwohl der Schlüssel basierend auf dem aus dem `K`-Wert berechneten Hash-Wert eingefügt wurde.
///
///
/// Infolgedessen wird die Hash-Map unterbrochen, wenn ein `K`, der einen `Q`-Wert umschließt, einen anderen Hash als `Q` erzeugt.Stellen Sie sich zum Beispiel vor, Sie haben einen Typ, der eine Zeichenfolge umschließt, aber ASCII-Buchstaben vergleicht, wobei die Groß-und Kleinschreibung ignoriert wird:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Da zwei gleiche Werte denselben Hashwert erzeugen müssen, muss bei der Implementierung von `Hash` auch der ASCII-Fall ignoriert werden:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kann `CaseInsensitiveString` `Borrow<str>` implementieren?Es kann sicherlich einen Verweis auf ein String-Slice über seinen enthaltenen eigenen String liefern.
/// Da sich die `Hash`-Implementierung jedoch unterscheidet, verhält es sich anders als `str` und darf daher `Borrow<str>` nicht implementieren.
/// Wenn es anderen den Zugriff auf das zugrunde liegende `str` ermöglichen soll, kann dies über `AsRef<str>` erfolgen, für das keine zusätzlichen Anforderungen gelten.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Unveränderlich von einem eigenen Wert entlehnt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Ein trait zum veränderlichen Ausleihen von Daten.
///
/// Als Begleiter von [`Borrow<T>`] ermöglicht dieser trait, dass ein Typ als zugrunde liegender Typ ausgeliehen wird, indem eine veränderbare Referenz bereitgestellt wird.
/// Weitere Informationen zum Ausleihen als anderer Typ finden Sie unter [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Veränderbar aus einem eigenen Wert entlehnt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}