#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Mit einem `RawWaker` kann der Implementierer eines Task-Executors einen [`Waker`] erstellen, der ein benutzerdefiniertes Aufweckverhalten bietet.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Es besteht aus einem Datenzeiger und einem [virtual function pointer table (vtable)][vtable], der das Verhalten des `RawWaker` anpasst.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Ein Datenzeiger, mit dem beliebige Daten gespeichert werden können, wie vom Executor gefordert.
    /// Dies könnte zB sein
    /// Ein vom Typ gelöschter Zeiger auf einen `Arc`, der der Aufgabe zugeordnet ist.
    /// Der Wert dieses Feldes wird als erster Parameter an alle Funktionen übergeben, die Teil der vtable sind.
    ///
    data: *const (),
    /// Virtuelle Funktionszeigertabelle, die das Verhalten dieses Wakers anpasst.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Erstellt einen neuen `RawWaker` aus dem bereitgestellten `data`-Zeiger und `vtable`.
    ///
    /// Mit dem `data`-Zeiger können beliebige Daten gespeichert werden, die vom Executor benötigt werden.Dies könnte zB sein
    /// Ein vom Typ gelöschter Zeiger auf einen `Arc`, der der Aufgabe zugeordnet ist.
    /// Der Wert dieses Zeigers wird als erster Parameter an alle Funktionen übergeben, die Teil des `vtable` sind.
    ///
    /// Der `vtable` passt das Verhalten eines `Waker` an, der aus einem `RawWaker` erstellt wird.
    /// Für jede Operation auf dem `Waker` wird die zugehörige Funktion im `vtable` des zugrunde liegenden `RawWaker` aufgerufen.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Eine virtuelle Funktionszeigertabelle (vtable), die das Verhalten eines [`RawWaker`] angibt.
///
/// Der Zeiger, der an alle Funktionen in der vtable übergeben wird, ist der `data`-Zeiger aus dem umschließenden [`RawWaker`]-Objekt.
///
/// Die Funktionen in dieser Struktur sollen nur für den `data`-Zeiger eines ordnungsgemäß erstellten [`RawWaker`]-Objekts innerhalb der [`RawWaker`]-Implementierung aufgerufen werden.
/// Das Aufrufen einer der enthaltenen Funktionen mit einem anderen `data`-Zeiger führt zu undefiniertem Verhalten.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Diese Funktion wird aufgerufen, wenn der [`RawWaker`] geklont wird, z. B. wenn der [`Waker`], in dem der [`RawWaker`] gespeichert ist, geklont wird.
    ///
    /// Bei der Implementierung dieser Funktion müssen alle Ressourcen erhalten bleiben, die für diese zusätzliche Instanz eines [`RawWaker`] und der zugehörigen Aufgabe erforderlich sind.
    /// Das Aufrufen von `wake` auf dem resultierenden [`RawWaker`] sollte zu einem Aufwecken derselben Aufgabe führen, die vom ursprünglichen [`RawWaker`] geweckt worden wäre.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Diese Funktion wird aufgerufen, wenn `wake` auf dem [`Waker`] aufgerufen wird.
    /// Es muss die mit diesem [`RawWaker`] verknüpfte Aufgabe aktivieren.
    ///
    /// Bei der Implementierung dieser Funktion muss sichergestellt werden, dass alle Ressourcen freigegeben werden, die dieser Instanz eines [`RawWaker`] und der zugehörigen Task zugeordnet sind.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Diese Funktion wird aufgerufen, wenn `wake_by_ref` auf dem [`Waker`] aufgerufen wird.
    /// Es muss die mit diesem [`RawWaker`] verknüpfte Aufgabe aktivieren.
    ///
    /// Diese Funktion ähnelt `wake`, darf jedoch den bereitgestellten Datenzeiger nicht verwenden.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Diese Funktion wird aufgerufen, wenn ein [`RawWaker`] fallen gelassen wird.
    ///
    /// Bei der Implementierung dieser Funktion muss sichergestellt werden, dass alle Ressourcen freigegeben werden, die dieser Instanz eines [`RawWaker`] und der zugehörigen Task zugeordnet sind.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Erstellt einen neuen `RawWakerVTable` aus den bereitgestellten `clone`-, `wake`-, `wake_by_ref`-und `drop`-Funktionen.
    ///
    /// # `clone`
    ///
    /// Diese Funktion wird aufgerufen, wenn der [`RawWaker`] geklont wird, z. B. wenn der [`Waker`], in dem der [`RawWaker`] gespeichert ist, geklont wird.
    ///
    /// Bei der Implementierung dieser Funktion müssen alle Ressourcen erhalten bleiben, die für diese zusätzliche Instanz eines [`RawWaker`] und der zugehörigen Aufgabe erforderlich sind.
    /// Das Aufrufen von `wake` auf dem resultierenden [`RawWaker`] sollte zu einem Aufwecken derselben Aufgabe führen, die vom ursprünglichen [`RawWaker`] geweckt worden wäre.
    ///
    /// # `wake`
    ///
    /// Diese Funktion wird aufgerufen, wenn `wake` auf dem [`Waker`] aufgerufen wird.
    /// Es muss die mit diesem [`RawWaker`] verknüpfte Aufgabe aktivieren.
    ///
    /// Bei der Implementierung dieser Funktion muss sichergestellt werden, dass alle Ressourcen freigegeben werden, die dieser Instanz eines [`RawWaker`] und der zugehörigen Task zugeordnet sind.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Diese Funktion wird aufgerufen, wenn `wake_by_ref` auf dem [`Waker`] aufgerufen wird.
    /// Es muss die mit diesem [`RawWaker`] verknüpfte Aufgabe aktivieren.
    ///
    /// Diese Funktion ähnelt `wake`, darf jedoch den bereitgestellten Datenzeiger nicht verwenden.
    ///
    /// # `drop`
    ///
    /// Diese Funktion wird aufgerufen, wenn ein [`RawWaker`] fallen gelassen wird.
    ///
    /// Bei der Implementierung dieser Funktion muss sichergestellt werden, dass alle Ressourcen freigegeben werden, die dieser Instanz eines [`RawWaker`] und der zugehörigen Task zugeordnet sind.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Das `Context` einer asynchronen Aufgabe.
///
/// Derzeit dient `Context` nur dazu, den Zugriff auf einen `&Waker` zu ermöglichen, mit dem die aktuelle Aufgabe aktiviert werden kann.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Stellen Sie sicher, dass wir gegen Varianzänderungen future-sicher sind, indem Sie die Lebensdauer als invariant erzwingen (die Lebensdauer der Argumentposition ist kontravariant, während die Lebensdauer der Rückkehrposition kovariant ist).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Erstellen Sie einen neuen `Context` aus einem `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Gibt einen Verweis auf den `Waker` für die aktuelle Aufgabe zurück.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Ein `Waker` ist ein Handle zum Aufwecken einer Aufgabe, indem sein Executor benachrichtigt wird, dass sie zur Ausführung bereit ist.
///
/// Dieses Handle kapselt eine [`RawWaker`]-Instanz, die das ausführerspezifische Aufweckverhalten definiert.
///
///
/// Implementiert [`Clone`], [`Send`] und [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Wecken Sie die mit diesem `Waker` verknüpfte Aufgabe auf.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Der eigentliche Weckaufruf wird über einen virtuellen Funktionsaufruf an die vom Executor definierte Implementierung delegiert.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Rufen Sie nicht `drop` an-der Waker wird von `wake` verbraucht.
        crate::mem::forget(self);

        // SICHERHEIT: Dies ist sicher, da nur `Waker::from_raw` möglich ist
        // Um `wake` und `data` zu initialisieren, muss der Benutzer bestätigen, dass der Vertrag von `RawWaker` eingehalten wird.
        //
        unsafe { (wake)(data) };
    }

    /// Wecken Sie die mit diesem `Waker` verknüpfte Aufgabe auf, ohne den `Waker` zu verbrauchen.
    ///
    /// Dies ähnelt `wake`, ist jedoch möglicherweise etwas weniger effizient, wenn ein eigenes `Waker` verfügbar ist.
    /// Diese Methode sollte dem Aufruf von `waker.clone().wake()` vorgezogen werden.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Der eigentliche Weckaufruf wird über einen virtuellen Funktionsaufruf an die vom Executor definierte Implementierung delegiert.
        //

        // SICHERHEIT: siehe `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Gibt `true` zurück, wenn dieses `Waker` und ein anderes `Waker` dieselbe Aufgabe geweckt haben.
    ///
    /// Diese Funktion arbeitet auf Best-Effort-Basis und kann auch dann false zurückgeben, wenn die `Waker`s dieselbe Aufgabe wecken würden.
    /// Wenn diese Funktion jedoch `true` zurückgibt, ist garantiert, dass die Waker die gleiche Aufgabe aktivieren.
    ///
    /// Diese Funktion wird hauptsächlich zu Optimierungszwecken verwendet.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Erstellt einen neuen `Waker` aus [`RawWaker`].
    ///
    /// Das Verhalten des zurückgegebenen `Waker` ist undefiniert, wenn der in der Dokumentation von [`RawWaker`] und [`RawWakerVTable`] definierte Vertrag nicht eingehalten wird.
    ///
    /// Daher ist diese Methode unsicher.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SICHERHEIT: Dies ist sicher, da nur `Waker::from_raw` möglich ist
            // Um `clone` und `data` zu initialisieren, muss der Benutzer bestätigen, dass der Vertrag von [`RawWaker`] eingehalten wird.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SICHERHEIT: Dies ist sicher, da nur `Waker::from_raw` möglich ist
        // Um `drop` und `data` zu initialisieren, muss der Benutzer bestätigen, dass der Vertrag von `RawWaker` eingehalten wird.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}