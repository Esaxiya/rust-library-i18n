//! Dieses Modul implementiert den `Any` trait, der die dynamische Typisierung eines beliebigen `'static`-Typs durch Laufzeitreflexion ermöglicht.
//!
//! `Any` selbst kann verwendet werden, um ein `TypeId` zu erhalten, und verfügt über mehr Funktionen, wenn es als trait-Objekt verwendet wird.
//! Als `&dyn Any` (ein geliehenes trait-Objekt) verfügt es über die Methoden `is` und `downcast_ref`, um zu testen, ob der enthaltene Wert von einem bestimmten Typ ist, und um einen Verweis auf den inneren Wert als Typ zu erhalten.
//! Als `&mut dyn Any` gibt es auch die `downcast_mut`-Methode, um einen veränderlichen Verweis auf den inneren Wert zu erhalten.
//! `Box<dyn Any>` fügt die `downcast`-Methode hinzu, die versucht, in eine `Box<T>` zu konvertieren.
//! Ausführliche Informationen finden Sie in der [`Box`]-Dokumentation.
//!
//! Beachten Sie, dass `&dyn Any` auf das Testen beschränkt ist, ob ein Wert von einem bestimmten konkreten Typ ist, und nicht zum Testen verwendet werden kann, ob ein Typ ein trait implementiert.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Intelligente Zeiger und `dyn Any`
//!
//! Ein Verhalten, das Sie bei der Verwendung von `Any` als trait-Objekt beachten sollten, insbesondere bei Typen wie `Box<dyn Any>` oder `Arc<dyn Any>`, besteht darin, dass durch einfaches Aufrufen von `.type_id()` für den Wert das `TypeId` des *Containers* und nicht das zugrunde liegende trait-Objekt erzeugt wird.
//!
//! Dies kann vermieden werden, indem stattdessen der Smart Pointer in einen `&dyn Any` konvertiert wird, der den `TypeId` des Objekts zurückgibt.
//! Beispielsweise:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Es ist wahrscheinlicher, dass Sie dies möchten:
//! let actual_id = (&*boxed).type_id();
//! // ... als das:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Stellen Sie sich eine Situation vor, in der wir einen an eine Funktion übergebenen Wert abmelden möchten.
//! Wir kennen den Wert, an dem wir arbeiten, um Debug zu implementieren, aber wir kennen den konkreten Typ nicht.Wir möchten bestimmten Typen eine besondere Behandlung geben: In diesem Fall wird die Länge der String-Werte vor ihrem Wert ausgedruckt.
//! Wir kennen den konkreten Typ unseres Werts zur Kompilierungszeit nicht, daher müssen wir stattdessen die Laufzeitreflexion verwenden.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger-Funktion für jeden Typ, der Debug implementiert.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Versuchen Sie, unseren Wert in einen `String` umzuwandeln.
//!     // Bei Erfolg möchten wir die Länge des Strings sowie seinen Wert ausgeben.
//!     // Wenn nicht, handelt es sich um einen anderen Typ: Drucken Sie ihn einfach schmucklos aus.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Diese Funktion möchte ihren Parameter abmelden, bevor sie damit arbeitet.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... andere Arbeiten erledigen
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Beliebiger trait
///////////////////////////////////////////////////////////////////////////////

/// Ein trait zum Emulieren der dynamischen Eingabe.
///
/// Die meisten Typen implementieren `Any`.Jeder Typ, der eine nicht statische Referenz enthält, tut dies jedoch nicht.
/// Weitere Informationen finden Sie im [module-level documentation][mod].
///
/// [mod]: crate::any
// Dieser trait ist nicht unsicher, obwohl wir uns auf die Besonderheiten der `type_id`-Funktion seines alleinigen Geräts in unsicherem Code (z. B. `downcast`) verlassen.Normalerweise wäre das ein Problem, aber da die einzige Implementierung von `Any` eine pauschale Implementierung ist, kann kein anderer Code `Any` implementieren.
//
// Wir könnten dieses trait plausibel unsicher machen-es würde keinen Bruch verursachen, da wir alle Implementierungen kontrollieren-, aber wir entscheiden uns dagegen, da dies nicht unbedingt erforderlich ist und die Benutzer über die Unterscheidung zwischen unsicheren traits-und unsicheren Methoden (dh z. `type_id` wäre immer noch sicher anzurufen, aber wir möchten dies wahrscheinlich in der Dokumentation als solches angeben.
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ruft den `TypeId` von `self` ab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Erweiterungsmethoden für beliebige trait-Objekte.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Stellen Sie sicher, dass das Ergebnis des Verbindens eines Threads gedruckt und daher mit `unwrap` verwendet werden kann.
// Wird möglicherweise nicht mehr benötigt, wenn der Versand mit Upcasting funktioniert.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Gibt `true` zurück, wenn der Box-Typ mit `T` identisch ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Holen Sie sich `TypeId` des Typs, mit dem diese Funktion instanziiert wird.
        let t = TypeId::of::<T>();

        // Ruft `TypeId` des Typs im trait-Objekt (`self`) ab.
        let concrete = self.type_id();

        // Vergleichen Sie beide TypeIds auf Gleichheit.
        t == concrete
    }

    /// Gibt einen Verweis auf den Wert in der Box zurück, wenn er vom Typ `T` ist, oder auf `None`, wenn dies nicht der Fall ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SICHERHEIT: Ich habe gerade überprüft, ob wir auf den richtigen Typ zeigen, und wir können uns darauf verlassen
            // diese Überprüfung der Speichersicherheit, da wir Any für alle Typen implementiert haben;Es können keine anderen Impls existieren, da sie mit unseren Impls in Konflikt stehen würden.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Gibt einen veränderlichen Verweis auf den Wert in der Box zurück, wenn er vom Typ `T` ist, oder auf `None`, wenn dies nicht der Fall ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SICHERHEIT: Ich habe gerade überprüft, ob wir auf den richtigen Typ zeigen, und wir können uns darauf verlassen
            // diese Überprüfung der Speichersicherheit, da wir Any für alle Typen implementiert haben;Es können keine anderen Impls existieren, da sie mit unseren Impls in Konflikt stehen würden.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Weiterleitung an die am Typ `Any` definierte Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Weiterleitung an die am Typ `Any` definierte Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Weiterleitung an die am Typ `Any` definierte Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Weiterleitung an die am Typ `Any` definierte Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Weiterleitung an die am Typ `Any` definierte Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Weiterleitung an die am Typ `Any` definierte Methode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID und seine Methoden
///////////////////////////////////////////////////////////////////////////////

/// Ein `TypeId` repräsentiert eine global eindeutige Kennung für einen Typ.
///
/// Jedes `TypeId` ist ein undurchsichtiges Objekt, das keine Überprüfung des Inhalts ermöglicht, aber grundlegende Vorgänge wie Klonen, Vergleichen, Drucken und Anzeigen ermöglicht.
///
///
/// Ein `TypeId` ist derzeit nur für Typen verfügbar, die `'static` zuschreiben. Diese Einschränkung kann jedoch im future aufgehoben werden.
///
/// Während `TypeId` `Hash`, `PartialOrd` und `Ord` implementiert, ist zu beachten, dass die Hashes und die Reihenfolge zwischen den Rust-Versionen variieren.
/// Verlassen Sie sich nicht auf sie in Ihrem Code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Gibt das `TypeId` des Typs zurück, mit dem diese generische Funktion instanziiert wurde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Gibt den Namen eines Typs als String-Slice zurück.
///
/// # Note
///
/// Dies ist für diagnostische Zwecke vorgesehen.
/// Der genaue Inhalt und das Format der zurückgegebenen Zeichenfolge werden nicht angegeben, außer dass es sich um eine Best-Effort-Beschreibung des Typs handelt.
/// Zu den Zeichenfolgen, die `type_name::<Option<String>>()` möglicherweise zurückgibt, gehören beispielsweise `"Option<String>"` und `"std::option::Option<std::string::String>"`.
///
///
/// Die zurückgegebene Zeichenfolge darf nicht als eindeutige Kennung eines Typs betrachtet werden, da mehrere Typen möglicherweise demselben Typnamen zugeordnet sind.
/// Ebenso kann nicht garantiert werden, dass alle Teile eines Typs in der zurückgegebenen Zeichenfolge angezeigt werden. Beispielsweise sind derzeit keine Lebensdauerspezifizierer enthalten.
/// Darüber hinaus kann sich die Ausgabe zwischen den Versionen des Compilers ändern.
///
/// Die aktuelle Implementierung verwendet dieselbe Infrastruktur wie Compilerdiagnose und Debuginfo, dies ist jedoch nicht garantiert.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Gibt den Namen des Typs des Wertes, auf den verwiesen wird, als Zeichenfolgenscheibe zurück.
/// Dies ist dasselbe wie `type_name::<T>()`, kann jedoch verwendet werden, wenn der Typ einer Variablen nicht leicht verfügbar ist.
///
/// # Note
///
/// Dies ist für diagnostische Zwecke vorgesehen.Der genaue Inhalt und das Format der Zeichenfolge werden nicht angegeben, außer dass es sich um eine Best-Effort-Beschreibung des Typs handelt.
/// Beispielsweise könnte `type_name_of_val::<Option<String>>(None)` `"Option<String>"` oder `"std::option::Option<std::string::String>"` zurückgeben, nicht jedoch `"foobar"`.
///
/// Darüber hinaus kann sich die Ausgabe zwischen den Versionen des Compilers ändern.
///
/// Diese Funktion löst keine trait-Objekte auf, was bedeutet, dass `type_name_of_val(&7u32 as &dyn Debug)` möglicherweise `"dyn Debug"` zurückgibt, nicht jedoch `"u32"`.
///
/// Der Typname sollte nicht als eindeutige Kennung eines Typs betrachtet werden.
/// Mehrere Typen können denselben Typnamen haben.
///
/// Die aktuelle Implementierung verwendet dieselbe Infrastruktur wie Compilerdiagnose und Debuginfo, dies ist jedoch nicht garantiert.
///
/// # Examples
///
/// Druckt die Standardtypen Integer und Float.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}