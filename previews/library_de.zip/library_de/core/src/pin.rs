//! Typen, die Daten an ihren Speicherort anheften.
//!
//! Es ist manchmal nützlich, Objekte zu haben, die sich garantiert nicht bewegen, in dem Sinne, dass sich ihre Platzierung im Speicher nicht ändert und man sich daher auf sie verlassen kann.
//! Ein Paradebeispiel für ein solches Szenario wäre das Erstellen selbstreferenzieller Strukturen, da das Verschieben eines Objekts mit Zeigern auf sich selbst diese ungültig macht, was zu undefiniertem Verhalten führen kann.
//!
//! Auf hoher Ebene stellt ein [`Pin<P>`] sicher, dass der Pointee eines Zeigertyps `P` einen stabilen Speicherort hat, was bedeutet, dass er nicht an einen anderen Ort verschoben werden kann und sein Speicher erst freigegeben werden kann, wenn er gelöscht wird.Wir sagen, dass der Spitzenwert "pinned" ist.Bei der Erörterung von Typen, die angeheftete mit nicht angehefteten Daten kombinieren, werden die Dinge subtiler.[see below](#projections-and-structural-pinning) für weitere Details.
//!
//! Standardmäßig sind alle Typen in Rust beweglich.
//! Mit Rust können alle Typen als Wert übergeben werden, und mit gängigen Smart-Pointer-Typen wie [`Box<T>`] und `&mut T` können die darin enthaltenen Werte ersetzt und verschoben werden: Sie können einen [`Box<T>`] verlassen oder [`mem::swap`] verwenden.
//! [`Pin<P>`] umschließt einen Zeigertyp `P`, also [`Pin`]`<`[`Box`] `<T>>`funktioniert ähnlich wie ein normaler
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`wird gelöscht, ebenso der Inhalt, und der Speicher wird gelöscht
//!
//! freigegeben.In ähnlicher Weise ist [`Pin`]`<&mut T>`&mut T` sehr ähnlich.Mit [`Pin<P>`] können Clients jedoch nicht [`Box<T>`] oder `&mut T` für angeheftete Daten erhalten. Dies bedeutet, dass Sie keine Vorgänge wie [`mem::swap`] verwenden können:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` braucht `&mut T`, aber wir können es nicht bekommen.
//!     // Wir stecken fest, wir können den Inhalt dieser Referenzen nicht austauschen.
//!     // Wir könnten `Pin::get_unchecked_mut` verwenden, aber das ist aus einem Grund unsicher:
//!     // Wir dürfen es nicht verwenden, um Dinge aus dem `Pin` zu entfernen.
//! }
//! ```
//!
//! Es sei noch einmal darauf hingewiesen, dass [`Pin<P>`] die Tatsache *nicht* ändert, dass ein Rust-Compiler alle Typen als beweglich betrachtet.[`mem::swap`] bleibt für jedes `T` aufrufbar.Stattdessen verhindert [`Pin<P>`], dass bestimmte *Werte*(auf die durch in [`Pin<P>`] eingeschlossene Zeiger verwiesen wird) verschoben werden, indem es unmöglich gemacht wird, Methoden aufzurufen, für die `&mut T` erforderlich ist (z. B. [`mem::swap`]).
//!
//! [`Pin<P>`] kann zum Umschließen eines beliebigen Zeigertyps `P` verwendet werden und interagiert als solcher mit [`Deref`] und [`DerefMut`].Ein [`Pin<P>`], bei dem `P: Deref` als "`P`-style pointer" zu einem fixierten `P::Target` betrachtet werden sollte-also ein [`Pin`]`<`[`Box`] `<T>>`ist ein eigener Zeiger auf einen angehefteten `T` und ein [`Pin`] `<` [`Rc`]`<T>>`ist ein Zeiger mit Referenzzählung auf einen angehefteten `T`.
//! Um die Richtigkeit zu gewährleisten, verlässt sich [`Pin<P>`] auf die Implementierungen von [`Deref`] und [`DerefMut`], um nicht aus ihrem `self`-Parameter herauszukommen und immer nur dann einen Zeiger auf angeheftete Daten zurückzugeben, wenn sie auf einem angehefteten Zeiger aufgerufen werden.
//!
//! # `Unpin`
//!
//! Viele Typen sind immer frei beweglich, auch wenn sie fixiert sind, da sie nicht auf eine stabile Adresse angewiesen sind.Dies umfasst alle Basistypen (wie [`bool`], [`i32`] und Referenzen) sowie Typen, die ausschließlich aus diesen Typen bestehen.Typen, die sich nicht für das Fixieren interessieren, implementieren den [`Unpin`] auto-trait, der den Effekt von [`Pin<P>`] aufhebt.
//! Für `T: Unpin` [`Pin`]`<`[`Box`] `<T>>`und [`Box<T>`] funktionieren identisch, ebenso wie [`Pin`] `<&mut T>` und `&mut T`.
//!
//! Beachten Sie, dass Pinning und [`Unpin`] nur den Zeigertyp `P::Target` betreffen, nicht den Zeigertyp `P` selbst, der in [`Pin<P>`] eingeschlossen wurde.Ob [`Box<T>`] beispielsweise [`Unpin`] ist oder nicht, hat keinen Einfluss auf das Verhalten von [`Pin`]`<`[`Box`] `<T>>`(hier ist `T` der Typ, auf den gezeigt wird).
//!
//! # Beispiel: selbstreferenzielle Struktur
//!
//! Bevor wir näher auf die mit `Pin<T>` verbundenen Garantien und Auswahlmöglichkeiten eingehen, werden einige Beispiele für deren Verwendung erläutert.
//! Fühlen Sie sich frei zu [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dies ist eine selbstreferenzielle Struktur, da das Slice-Feld auf das Datenfeld zeigt.
//! // Wir können den Compiler nicht mit einer normalen Referenz darüber informieren, da dieses Muster nicht mit den üblichen Ausleihregeln beschrieben werden kann.
//! //
//! // Stattdessen verwenden wir einen Rohzeiger, von dem bekannt ist, dass er nicht null ist, da wir wissen, dass er auf die Zeichenfolge zeigt.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Um sicherzustellen, dass sich die Daten bei der Rückkehr der Funktion nicht verschieben, platzieren wir sie auf dem Heap, wo sie für die Lebensdauer des Objekts verbleiben. Der einzige Zugriff darauf ist ein Zeiger darauf.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // Wir erstellen den Zeiger erst, wenn die Daten vorhanden sind. Andernfalls haben sie sich bereits verschoben, bevor wir überhaupt angefangen haben
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // Wir wissen, dass dies sicher ist, da das Ändern eines Feldes nicht die gesamte Struktur verschiebt
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Der Zeiger sollte auf die richtige Position zeigen, solange sich die Struktur nicht bewegt hat.
//! //
//! // In der Zwischenzeit können wir den Zeiger frei bewegen.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Da unser Typ Unpin nicht implementiert, kann dies nicht kompiliert werden:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Beispiel: aufdringliche doppelt verknüpfte Liste
//!
//! In einer aufdringlichen doppelt verknüpften Liste ordnet die Sammlung den Speicher für die Elemente selbst nicht zu.
//! Die Zuordnung wird von den Clients gesteuert, und Elemente können auf einem Stapelrahmen leben, der kürzer als die Sammlung ist.
//!
//! Damit dies funktioniert, hat jedes Element Zeiger auf seinen Vorgänger und Nachfolger in der Liste.Elemente können nur hinzugefügt werden, wenn sie angeheftet sind, da das Verschieben der Elemente die Zeiger ungültig machen würde.Darüber hinaus werden durch die [`Drop`]-Implementierung eines verknüpften Listenelements die Zeiger des Vorgängers und Nachfolgers gepatcht, um sich selbst aus der Liste zu entfernen.
//!
//! Entscheidend ist, dass wir uns darauf verlassen können, dass [`drop`] aufgerufen wird.Wenn ein Element freigegeben oder auf andere Weise ungültig gemacht werden könnte, ohne [`drop`] aufzurufen, würden die Zeiger von benachbarten Elementen ungültig, was die Datenstruktur beschädigen würde.
//!
//! Daher ist das Fixieren auch mit einer [`drop`]-bezogenen Garantie verbunden.
//!
//! # `Drop` guarantee
//!
//! Der Zweck des Fixierens besteht darin, sich auf die Platzierung einiger Daten im Speicher verlassen zu können.
//! Damit dies funktioniert, ist nicht nur das Verschieben der Daten eingeschränkt.Die Freigabe, Umnutzung oder anderweitige Ungültigmachung des zum Speichern der Daten verwendeten Speichers ist ebenfalls eingeschränkt.
//! Konkret müssen Sie für angeheftete Daten die Invariante beibehalten, dass *der Speicher von dem Moment an, in dem er angeheftet wird, bis zum Aufruf von [`drop`]* nicht ungültig oder zweckentfremdet wird.Erst wenn [`drop`] oder panics zurückgegeben wird, kann der Speicher wiederverwendet werden.
//!
//! Der Speicher kann "invalidated" durch Freigabe sein, aber auch durch Ersetzen eines [`Some(v)`] durch [`None`] oder durch Aufrufen von [`Vec::set_len`] bis "kill" einiger Elemente von einem vector.Es kann mithilfe von [`ptr::write`] zum Überschreiben verwendet werden, ohne zuvor den Destruktor aufzurufen.Nichts davon ist für angeheftete Daten zulässig, ohne [`drop`] aufzurufen.
//!
//! Dies ist genau die Art von Garantie, dass die aufdringliche verknüpfte Liste aus dem vorherigen Abschnitt ordnungsgemäß funktionieren muss.
//!
//! Beachten Sie, dass diese Garantie *nicht* bedeutet, dass kein Speicher verloren geht!Es ist immer noch völlig in Ordnung, [`drop`] niemals für ein angeheftetes Element aufzurufen (z. B. können Sie [`mem::forget`] immer noch für einen [`Pin`]`<`[`Box`] `aufrufen<T>>`).Im Beispiel der doppelt verknüpften Liste würde dieses Element nur in der Liste bleiben.Sie dürfen den Speicher jedoch nicht freigeben oder wiederverwenden *, ohne [`drop`]* aufzurufen.
//!
//! # `Drop` implementation
//!
//! Wenn Ihr Typ Pinning verwendet (wie in den beiden obigen Beispielen), müssen Sie bei der Implementierung von [`Drop`] vorsichtig sein.Die [`drop`]-Funktion benötigt `&mut self`, dies wird jedoch *genannt, auch wenn Ihr Typ zuvor angeheftet wurde*!Es ist, als würde der Compiler automatisch [`Pin::get_unchecked_mut`] aufrufen.
//!
//! Dies kann niemals zu Problemen bei sicherem Code führen, da für die Implementierung eines Typs, der auf Pinning basiert, unsicherer Code erforderlich ist. Beachten Sie jedoch, dass Sie sich für die Verwendung von Pinning in Ihrem Typ entscheiden (z. B. durch Implementieren einer Operation für [`Pin`]`<&Self) >`oder [`Pin`] `<&mut Self>`) hat auch Konsequenzen für Ihre [`Drop`]-Implementierung: Wenn ein Element Ihres Typs angeheftet werden könnte, müssen Sie [`Drop`] so behandeln, als würde es implizit [`Pin`]`<&mut nehmen Selbst>`.
//!
//!
//! Sie können `Drop` beispielsweise wie folgt implementieren:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ist in Ordnung, da wir wissen, dass dieser Wert nach dem Löschen nie wieder verwendet wird.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Der tatsächliche Drop-Code finden Sie hier.
//!         }
//!     }
//! }
//! ```
//!
//! Die Funktion `inner_drop` hat den Typ, den [`drop`]*haben sollte*, sodass sichergestellt ist, dass Sie `self`/`this` nicht versehentlich in einer Weise verwenden, die im Widerspruch zum Fixieren steht.
//!
//! Wenn Ihr Typ `#[repr(packed)]` ist, verschiebt der Compiler außerdem automatisch Felder, um sie löschen zu können.Dies kann sogar für Felder der Fall sein, die gerade ausreichend ausgerichtet sind.Infolgedessen können Sie das Fixieren nicht mit einem `#[repr(packed)]`-Typ verwenden.
//!
//! # Projektionen und strukturelles Fixieren
//!
//! Bei der Arbeit mit angehefteten Strukturen stellt sich die Frage, wie man auf die Felder dieser Struktur in einer Methode zugreifen kann, die nur [`Pin`]`<&mut Struct>`benötigt.
//! Der übliche Ansatz besteht darin, Hilfsmethoden (sogenannte *Projektionen*) zu schreiben, die [`Pin`]`<&mut Struct>`in eine Referenz auf das Feld verwandeln. Aber welchen Typ sollte diese Referenz haben?Ist es [`Pin`]`<&mut Field>`oder `&mut Field`?
//! Die gleiche Frage stellt sich bei den Feldern eines `enum` und auch bei der Betrachtung von container/wrapper-Typen wie [`Vec<T>`], [`Box<T>`] oder [`RefCell<T>`].
//! (Diese Frage gilt sowohl für veränderbare als auch für gemeinsam genutzte Referenzen. Zur Veranschaulichung wird hier nur der häufigere Fall von veränderlichen Referenzen verwendet.)
//!
//! Es stellt sich heraus, dass es tatsächlich Sache des Autors der Datenstruktur ist, zu entscheiden, ob die angeheftete Projektion für ein bestimmtes Feld [`Pin`]`<&mut Struct>`in [`Pin`] `<&mut Field>` oder verwandelt `&mut Field`.Es gibt jedoch einige Einschränkungen, und die wichtigste Einschränkung ist *Konsistenz*:
//! Jedes Feld kann *entweder* auf eine angeheftete Referenz projiziert *oder* als Teil der Projektion entfernt werden.
//! Wenn beide für dasselbe Feld ausgeführt werden, ist dies wahrscheinlich nicht stichhaltig!
//!
//! Als Autor einer Datenstruktur können Sie für jedes Feld entscheiden, ob "propagates" an dieses Feld angeheftet werden soll oder nicht.
//! Das Pinning, das sich ausbreitet, wird auch als "structural" bezeichnet, da es der Struktur des Typs folgt.
//! In den folgenden Unterabschnitten beschreiben wir die Überlegungen, die für jede Auswahl getroffen werden müssen.
//!
//! ## Das Fixieren *ist für `field` nicht* strukturell
//!
//! Es mag kontraintuitiv erscheinen, dass das Feld einer angehefteten Struktur möglicherweise nicht angeheftet ist, aber das ist tatsächlich die einfachste Wahl: Wenn niemals ein [`Pin`]`<&mut Field>`erstellt wird, kann nichts schief gehen!Wenn Sie also entscheiden, dass ein Feld nicht strukturell fixiert ist, müssen Sie nur sicherstellen, dass Sie niemals einen fixierten Verweis auf dieses Feld erstellen.
//!
//! Felder ohne strukturelles Fixieren können eine Projektionsmethode haben, die [`Pin`]`<&mut Struct>`in `&mut Field` verwandelt:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dies ist in Ordnung, da `field` niemals als fixiert betrachtet wird.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Sie können auch `impl Unpin for Struct`*auch wenn* der Typ von `field` nicht [`Unpin`] ist.Was dieser Typ über das Fixieren denkt, ist nicht relevant, wenn niemals ein [`Pin`]`<&mut Field>`erstellt wird.
//!
//! ## Das Fixieren *ist* strukturell für `field`
//!
//! Die andere Option besteht darin, zu entscheiden, dass das Fixieren "structural" für `field` ist. Wenn also die Struktur fixiert ist, ist dies auch das Feld.
//!
//! Dies ermöglicht das Schreiben einer Projektion, die ein [`Pin`]`<&mut Field>`erstellt, wodurch festgestellt wird, dass das Feld fixiert ist:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dies ist in Ordnung, da `field` bei `self` fixiert ist.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Das strukturelle Fixieren ist jedoch mit einigen zusätzlichen Anforderungen verbunden:
//!
//! 1. Die Struktur darf nur [`Unpin`] sein, wenn alle Strukturfelder [`Unpin`] sind.Dies ist die Standardeinstellung, aber [`Unpin`] ist ein sicheres trait. Als Autor der Struktur liegt es in Ihrer Verantwortung,*nicht* etwas wie `impl<T> Unpin for Struct<T>` hinzuzufügen.
//! (Beachten Sie, dass für das Hinzufügen einer Projektionsoperation unsicherer Code erforderlich ist. Die Tatsache, dass [`Unpin`] ein sicherer trait ist, verstößt also nicht gegen das Prinzip, dass Sie sich nur darum kümmern müssen, wenn Sie "unsicher" verwenden.)
//! 2. Der Destruktor der Struktur darf Strukturfelder nicht aus seinem Argument entfernen.Dies ist der genaue Punkt, der in [previous section][drop-impl] angesprochen wurde: `drop` benötigt `&mut self`, aber die Struktur (und damit ihre Felder) wurde möglicherweise zuvor angeheftet.
//!     Sie müssen sicherstellen, dass Sie kein Feld in Ihrer [`Drop`]-Implementierung verschieben.
//!     Wie bereits erläutert, bedeutet dies insbesondere, dass Ihre Struktur *nicht*`#[repr(packed)]` sein darf.
//!     In diesem Abschnitt erfahren Sie, wie Sie [`drop`] so schreiben, dass der Compiler Ihnen dabei hilft, das Pinning nicht versehentlich zu unterbrechen.
//! 3. Sie müssen sicherstellen, dass Sie den [`Drop` guarantee][drop-guarantee] hochhalten:
//!     Sobald Ihre Struktur fixiert ist, wird der Speicher, der den Inhalt enthält, nicht überschrieben oder freigegeben, ohne die Destruktoren des Inhalts aufzurufen.
//!     Dies kann schwierig sein, wie [`VecDeque<T>`] bezeugt: Der Destruktor von [`VecDeque<T>`] kann [`drop`] nicht für alle Elemente aufrufen, wenn einer der Destruktoren panics.Dies verstößt gegen die [`Drop`]-Garantie, da es dazu führen kann, dass Elemente freigegeben werden, ohne dass ihr Destruktor aufgerufen wird.([`VecDeque<T>`] hat keine Pinning-Projektionen, dies führt also nicht zu Unklarheiten.)
//! 4. Sie dürfen keine anderen Vorgänge anbieten, die dazu führen könnten, dass Daten aus den Strukturfeldern verschoben werden, wenn Ihr Typ fixiert ist.Wenn die Struktur beispielsweise ein [`Option<T>`] enthält und es eine "take"-ähnliche Operation mit dem Typ `fn(Pin<&mut Struct<T>>) -> Option<T>` gibt, kann diese Operation verwendet werden, um ein `T` aus einem fixierten `Struct<T>` zu verschieben-was bedeutet, dass das Fixieren für das Feld, das dies enthält, nicht strukturell sein kann Daten.
//!
//!     Stellen Sie sich für ein komplexeres Beispiel für das Verschieben von Daten aus einem angehefteten Typ vor, [`RefCell<T>`] hätte eine Methode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Dann könnten wir folgendes tun:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dies ist katastrophal. Dies bedeutet, dass wir zuerst den Inhalt des [`RefCell<T>`] (mit `RefCell::get_pin_mut`) anheften und diesen Inhalt dann mit der veränderlichen Referenz verschieben können, die wir später erhalten haben.
//!
//! ## Examples
//!
//! Für einen Typ wie [`Vec<T>`] sind beide Möglichkeiten (strukturelles Fixieren oder nicht) sinnvoll.
//! Ein [`Vec<T>`] mit struktureller Fixierung kann über `get_pin`/`get_pin_mut`-Methoden verfügen, um fixierte Verweise auf Elemente zu erhalten.Es konnte jedoch *nicht* erlaubt werden, [`pop`][Vec::pop] auf einem angehefteten [`Vec<T>`] aufzurufen, da dies den (strukturell angehefteten) Inhalt verschieben würde!Es konnte auch kein [`push`][Vec::push] zulassen, das den Inhalt neu zuweisen und damit auch verschieben könnte.
//!
//! Ein [`Vec<T>`] ohne strukturelles Fixieren könnte `impl<T> Unpin for Vec<T>` sein, da der Inhalt niemals fixiert wird und der [`Vec<T>`] selbst auch gut verschoben werden kann.
//! Zu diesem Zeitpunkt hat das Fixieren überhaupt keine Auswirkung auf den vector.
//!
//! In der Standardbibliothek haben Zeigertypen im Allgemeinen keine strukturelle Fixierung und bieten daher keine Fixierungsprojektionen.Aus diesem Grund gilt `Box<T>: Unpin` für alle `T`.
//! Dies ist für Zeigertypen sinnvoll, da durch Bewegen des `Box<T>` der `T` nicht bewegt wird: Der [`Box<T>`] kann frei beweglich sein (auch bekannt als `Unpin`), auch wenn der `T` dies nicht ist.In der Tat sogar [`Pin`]`<`[`Box`] `<T>>`und [`Pin`] `<&mut T>` sind aus demselben Grund immer [`Unpin`] selbst: Ihr Inhalt (`T`) ist fixiert, aber die Zeiger selbst können verschoben werden, ohne die angehefteten Daten zu verschieben.
//! Für [`Box<T>`] und [`Pin`]`<`[`Box`] `<T>>`, ob der Inhalt fixiert ist, ist völlig unabhängig davon, ob der Zeiger fixiert ist, was bedeutet, dass das Fixieren *nicht* strukturell ist.
//!
//! Wenn Sie einen [`Future`]-Kombinator implementieren, benötigen Sie normalerweise strukturelles Pinning für die verschachtelten futures, da Sie angeheftete Verweise darauf erhalten müssen, um [`poll`] aufzurufen.
//! Wenn Ihr Kombinator jedoch andere Daten enthält, die nicht angeheftet werden müssen, können Sie diese Felder nicht strukturell gestalten und daher mit einer veränderlichen Referenz frei darauf zugreifen, selbst wenn Sie nur [`Pin`]`<&mut Self>`(z wie in Ihrer eigenen [`poll`]-Implementierung).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Ein festgesteckter Zeiger.
///
/// Dies ist ein Wrapper um eine Art Zeiger, der diesen Zeiger "pin" zu seinem Wert macht und verhindert, dass der von diesem Zeiger referenzierte Wert verschoben wird, es sei denn, er implementiert [`Unpin`].
///
///
/// *In der [`pin` module]-Dokumentation finden Sie eine Erläuterung zum Fixieren.*
///
/// [`pin` module]: self
///
// Note: Die unten stehende `Clone`-Ableitung verursacht Unklarheiten, da sie implementiert werden kann
// `Clone` für veränderbare Referenzen.
// Weitere Informationen finden Sie unter <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Die folgenden Implementierungen werden nicht abgeleitet, um Probleme mit der Solidität zu vermeiden.
// `&self.pointer` sollte nicht vertrauenswürdigen trait-Implementierungen nicht zugänglich sein.
//
// Weitere Informationen finden Sie unter <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Erstellen Sie ein neues `Pin<P>` um einen Zeiger auf einige Daten eines Typs, der [`Unpin`] implementiert.
    ///
    /// Im Gegensatz zu `Pin::new_unchecked` ist diese Methode sicher, da der Zeiger `P` auf einen [`Unpin`]-Typ dereferenziert, wodurch die Pinning-Garantien aufgehoben werden.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SICHERHEIT: Der angegebene Wert ist `Unpin` und hat daher keine Anforderungen
        // um festzunageln.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Packt diesen `Pin<P>` aus und gibt den zugrunde liegenden Zeiger zurück.
    ///
    /// Dies erfordert, dass die Daten in diesem `Pin` [`Unpin`] sind, damit wir die Pinning-Invarianten beim Auspacken ignorieren können.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Erstellen Sie ein neues `Pin<P>` um einen Verweis auf einige Daten eines Typs, der `Unpin` möglicherweise implementiert oder nicht.
    ///
    /// Wenn `pointer` von einem `Unpin`-Typ abweicht, sollte stattdessen `Pin::new` verwendet werden.
    ///
    /// # Safety
    ///
    /// Dieser Konstruktor ist unsicher, da wir nicht garantieren können, dass die Daten, auf die `pointer` zeigt, fixiert sind. Dies bedeutet, dass die Daten nicht verschoben oder ihr Speicher ungültig gemacht werden, bis sie gelöscht werden.
    /// Wenn das erstellte `Pin<P>` nicht garantiert, dass die Daten, auf die `P` zeigt, fixiert sind, stellt dies eine Verletzung des API-Vertrags dar und kann bei späteren (safe)-Vorgängen zu undefiniertem Verhalten führen.
    ///
    /// Mit dieser Methode erstellen Sie ein promise für die `P::Deref`-und `P::DerefMut`-Implementierungen, sofern vorhanden.
    /// Am wichtigsten ist, dass sie ihre `self`-Argumente nicht verlassen dürfen: `Pin::as_mut` und `Pin::as_ref` rufen `DerefMut::deref_mut` und `Deref::deref`*auf dem angehefteten Zeiger* auf und erwarten, dass diese Methoden die feststeckenden Invarianten aufrechterhalten.
    /// Wenn Sie diese Methode aufrufen, werden Sie außerdem promise, dass die Referenz-`P`-Dereferenzen auf nicht wieder verschoben werden.Insbesondere darf es nicht möglich sein, einen `&mut P::Target` zu erhalten und dann aus dieser Referenz herauszukommen (z. B. mit [`mem::swap`]).
    ///
    ///
    /// Zum Beispiel ist das Aufrufen von `Pin::new_unchecked` auf einem `&'a mut T` unsicher, da Sie es zwar für die gegebene Lebensdauer von `'a` anheften können, aber keine Kontrolle darüber haben, ob es nach dem Ende von `'a` festgehalten wird:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dies sollte bedeuten, dass sich der Pointee `a` nie wieder bewegen kann.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Die Adresse von `a` wurde in den Stapelsteckplatz von `b` geändert, sodass `a` verschoben wurde, obwohl wir ihn zuvor angeheftet haben!Wir haben den Pinning-API-Vertrag verletzt.
    /////
    /// }
    /// ```
    ///
    /// Ein einmal fixierter Wert muss für immer fixiert bleiben (es sei denn, sein Typ implementiert `Unpin`).
    ///
    /// Ebenso ist das Aufrufen von `Pin::new_unchecked` auf einem `Rc<T>` unsicher, da möglicherweise Aliase für dieselben Daten vorhanden sind, für die keine Pinning-Einschränkungen gelten:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dies sollte bedeuten, dass sich der Spitzenreiter nie wieder bewegen kann.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Wenn `x` die einzige Referenz war, haben wir eine veränderbare Referenz auf Daten, die wir oben angeheftet haben und die wir verwenden können, um sie zu verschieben, wie wir im vorherigen Beispiel gesehen haben.
    ///     // Wir haben den Pinning-API-Vertrag verletzt.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ruft eine angeheftete gemeinsame Referenz von diesem angehefteten Zeiger ab.
    ///
    /// Dies ist eine generische Methode, um von `&Pin<Pointer<T>>` zu `Pin<&T>` zu wechseln.
    /// Dies ist sicher, da sich der Pointee im Rahmen des Vertrags von `Pin::new_unchecked` nach der Erstellung von `Pin<Pointer<T>>` nicht mehr bewegen kann.
    ///
    /// "Malicious" Implementierungen von `Pointer::Deref` sind ebenfalls durch den Vertrag von `Pin::new_unchecked` ausgeschlossen.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SICHERHEIT: Siehe Dokumentation zu dieser Funktion
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Packt diesen `Pin<P>` aus und gibt den zugrunde liegenden Zeiger zurück.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher.Sie müssen sicherstellen, dass Sie den Zeiger `P` nach dem Aufrufen dieser Funktion weiterhin als fixiert behandeln, damit die Invarianten des `Pin`-Typs beibehalten werden können.
    /// Wenn der Code, der das resultierende `P` verwendet, die Pinning-Invarianten nicht weiterhin beibehält, verstößt dies gegen den API-Vertrag und kann bei späteren (safe)-Vorgängen zu undefiniertem Verhalten führen.
    ///
    ///
    /// Wenn die zugrunde liegenden Daten [`Unpin`] sind, sollte stattdessen [`Pin::into_inner`] verwendet werden.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ruft eine angeheftete veränderbare Referenz von diesem angehefteten Zeiger ab.
    ///
    /// Dies ist eine generische Methode, um von `&mut Pin<Pointer<T>>` zu `Pin<&mut T>` zu wechseln.
    /// Dies ist sicher, da sich der Pointee im Rahmen des Vertrags von `Pin::new_unchecked` nach der Erstellung von `Pin<Pointer<T>>` nicht mehr bewegen kann.
    ///
    /// "Malicious" Implementierungen von `Pointer::DerefMut` sind ebenfalls durch den Vertrag von `Pin::new_unchecked` ausgeschlossen.
    ///
    /// Diese Methode ist nützlich, wenn Sie mehrere Aufrufe von Funktionen ausführen, die den angehefteten Typ verwenden.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // etwas tun
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` verbraucht `self`, also leihen Sie den `Pin<&mut Self>` über `as_mut` neu aus.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SICHERHEIT: Siehe Dokumentation zu dieser Funktion
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Weist dem Speicher hinter der angehefteten Referenz einen neuen Wert zu.
    ///
    /// Dadurch werden angeheftete Daten überschrieben, aber das ist in Ordnung: Der Destruktor wird ausgeführt, bevor er überschrieben wird, sodass keine Pinning-Garantie verletzt wird.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruiert einen neuen Pin durch Zuordnung des Innenwerts.
    ///
    /// Wenn Sie beispielsweise ein `Pin` eines Feldes von etwas erhalten möchten, können Sie dies verwenden, um in einer Codezeile auf dieses Feld zuzugreifen.
    /// Bei diesem "pinning projections" gibt es jedoch mehrere Fallstricke.
    /// Weitere Informationen zu diesem Thema finden Sie in der [`pin` module]-Dokumentation.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher.
    /// Sie müssen sicherstellen, dass sich die von Ihnen zurückgegebenen Daten nicht verschieben, solange sich der Argumentwert nicht bewegt (z. B. weil es sich um eines der Felder dieses Werts handelt), und dass Sie sich nicht aus dem Argument herausbewegen, zu dem Sie empfangen die Innenfunktion.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SICHERHEIT: Der Sicherheitsvertrag für `new_unchecked` muss sein
        // vom Anrufer bestätigt.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Ruft eine gemeinsame Referenz aus einem Pin ab.
    ///
    /// Dies ist sicher, da es nicht möglich ist, eine gemeinsam genutzte Referenz zu verlassen.
    /// Es scheint, als gäbe es hier ein Problem mit der inneren Veränderlichkeit: Tatsächlich ist es *möglich*, einen `T` aus einem `&RefCell<T>` zu verschieben.
    /// Dies ist jedoch kein Problem, solange nicht auch ein `Pin<&T>` vorhanden ist, der auf dieselben Daten verweist, und mit `RefCell<T>` können Sie keinen angehefteten Verweis auf dessen Inhalt erstellen.
    ///
    /// Weitere Informationen finden Sie in der Diskussion zu ["pinning projections"].
    ///
    /// Note: `Pin` implementiert auch `Deref` für das Ziel, mit dem auf den inneren Wert zugegriffen werden kann.
    /// `Deref` bietet jedoch nur eine Referenz, die so lange gültig ist wie die Ausleihe des `Pin`, nicht die Lebensdauer des `Pin` selbst.
    /// Mit dieser Methode wird der `Pin` zu einer Referenz mit der gleichen Lebensdauer wie der ursprüngliche `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Wandelt diesen `Pin<&mut T>` in einen `Pin<&T>` mit derselben Lebensdauer um.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ruft einen veränderlichen Verweis auf die Daten in diesem `Pin` ab.
    ///
    /// Dies erfordert, dass die Daten in diesem `Pin` `Unpin` sind.
    ///
    /// Note: `Pin` implementiert auch `DerefMut` in die Daten, mit denen auf den inneren Wert zugegriffen werden kann.
    /// `DerefMut` bietet jedoch nur eine Referenz, die so lange gültig ist wie die Ausleihe des `Pin`, nicht die Lebensdauer des `Pin` selbst.
    ///
    /// Mit dieser Methode wird der `Pin` zu einer Referenz mit der gleichen Lebensdauer wie der ursprüngliche `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ruft einen veränderlichen Verweis auf die Daten in diesem `Pin` ab.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher.
    /// Sie müssen sicherstellen, dass Sie die Daten niemals aus der veränderlichen Referenz verschieben, die Sie beim Aufrufen dieser Funktion erhalten, damit die Invarianten des `Pin`-Typs beibehalten werden können.
    ///
    ///
    /// Wenn die zugrunde liegenden Daten `Unpin` sind, sollte stattdessen `Pin::get_mut` verwendet werden.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Erstellen Sie einen neuen Pin, indem Sie den Innenwert abbilden.
    ///
    /// Wenn Sie beispielsweise ein `Pin` eines Feldes von etwas erhalten möchten, können Sie dies verwenden, um in einer Codezeile auf dieses Feld zuzugreifen.
    /// Bei diesem "pinning projections" gibt es jedoch mehrere Fallstricke.
    /// Weitere Informationen zu diesem Thema finden Sie in der [`pin` module]-Dokumentation.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher.
    /// Sie müssen sicherstellen, dass sich die von Ihnen zurückgegebenen Daten nicht verschieben, solange sich der Argumentwert nicht bewegt (z. B. weil es sich um eines der Felder dieses Werts handelt), und dass Sie sich nicht aus dem Argument herausbewegen, zu dem Sie empfangen die Innenfunktion.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SICHERHEIT: Der Anrufer ist dafür verantwortlich, dass er den nicht bewegt
        // Wert aus dieser Referenz.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SICHERHEIT: da der Wert von `this` garantiert nicht hat
        // Wurde dieser Anruf an `new_unchecked` ausgezogen, ist er sicher.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Holen Sie sich eine angeheftete Referenz aus einer statischen Referenz.
    ///
    /// Dies ist sicher, da `T` für die `'static`-Lebensdauer ausgeliehen wird, die niemals endet.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SICHERHEIT: Die statische Ausleihe garantiert, dass die Daten nicht gespeichert werden
        // moved/invalidated bis es fallen gelassen wird (was niemals ist).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Holen Sie sich eine angeheftete veränderbare Referenz aus einer statischen veränderlichen Referenz.
    ///
    /// Dies ist sicher, da `T` für die `'static`-Lebensdauer ausgeliehen wird, die niemals endet.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SICHERHEIT: Die statische Ausleihe garantiert, dass die Daten nicht gespeichert werden
        // moved/invalidated bis es fallen gelassen wird (was niemals ist).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: Dies bedeutet, dass jedes Gerät von `CoerceUnsized`, das das Erzwingen von erlaubt
// Ein Typ, der `Deref<Target=impl !Unpin>` in einen Typ implementiert, der `Deref<Target=Unpin>` impliziert, ist nicht in Ordnung.
// Ein solches Gerät wäre wahrscheinlich aus anderen Gründen nicht in Ordnung, daher müssen wir nur darauf achten, dass solche Geräte nicht in std landen.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}