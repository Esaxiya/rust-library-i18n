//! Überladbare Operatoren.
//!
//! Durch die Implementierung dieser traits können Sie bestimmte Operatoren überladen.
//!
//! Einige dieser traits werden vom prelude importiert, sodass sie in jedem Rust-Programm verfügbar sind.Nur von traits unterstützte Operatoren können überladen werden.
//! Beispielsweise kann der Additionsoperator (`+`) über den [`Add`] trait überladen werden. Da der Zuweisungsoperator (`=`) jedoch keine Unterstützung für trait hat, gibt es keine Möglichkeit, seine Semantik zu überladen.
//! Darüber hinaus bietet dieses Modul keinen Mechanismus zum Erstellen neuer Operatoren.
//! Wenn eine merkwürdige Überladung oder benutzerdefinierte Operatoren erforderlich sind, sollten Sie nach Makros oder Compiler-Plugins suchen, um die Syntax von Rust zu erweitern.
//!
//! Implementierungen des Operators traits sollten in ihren jeweiligen Kontexten nicht überraschend sein, wobei die üblichen Bedeutungen und [operator precedence] zu berücksichtigen sind.
//! Wenn Sie beispielsweise [`Mul`] implementieren, sollte die Operation etwas Ähnlichkeit mit der Multiplikation haben (und erwartete Eigenschaften wie Assoziativität gemeinsam haben).
//!
//! Beachten Sie, dass die Operatoren `&&` und `||` kurzschließen, dh ihren zweiten Operanden nur dann auswerten, wenn er zum Ergebnis beiträgt.Da dieses Verhalten von traits nicht erzwungen werden kann, werden `&&` und `||` nicht als überladbare Operatoren unterstützt.
//!
//! Viele der Operatoren nehmen ihre Operanden nach Wert.In nicht generischen Kontexten mit integrierten Typen ist dies normalerweise kein Problem.
//! Die Verwendung dieser Operatoren in generischem Code erfordert jedoch einige Aufmerksamkeit, wenn Werte wiederverwendet werden müssen, anstatt sie von den Operatoren verwenden zu lassen.Eine Möglichkeit besteht darin, gelegentlich [`clone`] zu verwenden.
//! Eine andere Möglichkeit besteht darin, sich auf die beteiligten Typen zu verlassen und zusätzliche Operatorimplementierungen für Referenzen bereitzustellen.
//! Für einen benutzerdefinierten Typ `T`, der das Hinzufügen unterstützen soll, ist es wahrscheinlich eine gute Idee, dass sowohl `T` als auch `&T` die traits [`Add<T>`][`Add`] und [`Add<&T>`][`Add`] implementieren, damit generischer Code ohne unnötiges Klonen geschrieben werden kann.
//!
//!
//! # Examples
//!
//! In diesem Beispiel wird eine `Point`-Struktur erstellt, die [`Add`] und [`Sub`] implementiert, und anschließend das Addieren und Subtrahieren von zwei `Punkten`s demonstriert.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Eine Beispielimplementierung finden Sie in der Dokumentation zu jedem trait.
//!
//! [`Fn`], [`FnMut`] und [`FnOnce`] traits werden von Typen implementiert, die wie Funktionen aufgerufen werden können.Beachten Sie, dass [`Fn`] `&self`, [`FnMut`] `&mut self` und [`FnOnce`] `self` benötigt.
//! Diese entsprechen den drei Arten von Methoden, die für eine Instanz aufgerufen werden können: Call-by-Reference, Call-by-Mutable-Reference und Call-by-Value.
//! Die häufigste Verwendung dieser traits besteht darin, als Grenzen für übergeordnete Funktionen zu fungieren, die Funktionen oder Abschlüsse als Argumente verwenden.
//!
//! Nehmen Sie einen [`Fn`] als Parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Nehmen Sie einen [`FnMut`] als Parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Nehmen Sie einen [`FnOnce`] als Parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` verbraucht die erfassten Variablen, sodass es nicht mehr als einmal ausgeführt werden kann
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Wenn Sie versuchen, `func()` erneut aufzurufen, wird ein `use of moved value`-Fehler für `func` ausgegeben
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kann an dieser Stelle nicht mehr aufgerufen werden
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;