/// Ein trait zum Anpassen des Verhaltens des `?`-Operators.
///
/// Ein Typ, der `Try` implementiert, kann kanonisch anhand einer success/failure-Dichotomie angezeigt werden.
/// Mit diesem trait können Sie sowohl diese Erfolgs-oder Fehlerwerte aus einer vorhandenen Instanz extrahieren als auch eine neue Instanz aus einem Erfolgs-oder Fehlerwert erstellen.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Der Typ dieses Werts, wenn er als erfolgreich angesehen wird.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Der Typ dieses Werts, wenn er als fehlgeschlagen angesehen wird.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Wendet den "?"-Operator an.Eine Rückgabe von `Ok(t)` bedeutet, dass die Ausführung normal fortgesetzt werden sollte und das Ergebnis von `?` der Wert `t` ist.
    /// Eine Rückgabe von `Err(e)` bedeutet, dass die Ausführung branch auf das innerste umschließende `catch` erfolgen oder von der Funktion zurückkehren sollte.
    ///
    /// Wenn ein `Err(e)`-Ergebnis zurückgegeben wird, ist der Wert `e` "wrapped" im Rückgabetyp des umschließenden Bereichs (der selbst `Try` implementieren muss).
    ///
    /// Insbesondere wird der Wert `X::from_error(From::from(e))` zurückgegeben, wobei `X` der Rückgabetyp der umschließenden Funktion ist.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Wickeln Sie einen Fehlerwert ein, um das zusammengesetzte Ergebnis zu erstellen.
    /// Zum Beispiel sind `Result::Err(x)` und `Result::from_error(x)` gleichwertig.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Schließen Sie einen OK-Wert ein, um das zusammengesetzte Ergebnis zu erstellen.
    /// Zum Beispiel sind `Result::Ok(x)` und `Result::from_ok(x)` gleichwertig.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}