use crate::marker::Unpin;
use crate::pin::Pin;

/// Das Ergebnis einer Wiederaufnahme des Generators.
///
/// Diese Aufzählung wird von der `Generator::resume`-Methode zurückgegeben und gibt die möglichen Rückgabewerte eines Generators an.
/// Derzeit entspricht dies entweder einem Aufhängepunkt (`Yielded`) oder einem Endpunkt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Der Generator wurde mit einem Wert angehalten.
    ///
    /// Dieser Status zeigt an, dass ein Generator angehalten wurde, und entspricht normalerweise einer `yield`-Anweisung.
    /// Der in dieser Variante angegebene Wert entspricht dem an `yield` übergebenen Ausdruck und ermöglicht es Generatoren, jedes Mal einen Wert bereitzustellen, wenn sie ergeben.
    ///
    ///
    Yielded(Y),

    /// Der Generator wurde mit einem Rückgabewert abgeschlossen.
    ///
    /// Dieser Status zeigt an, dass ein Generator die Ausführung mit dem angegebenen Wert beendet hat.
    /// Sobald ein Generator `Complete` zurückgegeben hat, wird es als Programmiererfehler angesehen, `resume` erneut aufzurufen.
    ///
    Complete(R),
}

/// Der trait wird von eingebauten Generatortypen implementiert.
///
/// Generatoren, auch als Coroutinen bezeichnet, sind derzeit ein experimentelles Sprachmerkmal in Rust.
/// In [RFC 2033] hinzugefügte Generatoren sollen derzeit in erster Linie einen Baustein für die async/await-Syntax darstellen, werden sich aber wahrscheinlich auch auf eine ergonomische Definition für Iteratoren und andere Grundelemente erstrecken.
///
///
/// Die Syntax und Semantik für Generatoren ist instabil und erfordert einen weiteren RFC zur Stabilisierung.Zu diesem Zeitpunkt ist die Syntax jedoch wie ein Abschluss:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Weitere Dokumentationen zu Generatoren finden Sie im instabilen Buch.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Die Art des Wertes, den dieser Generator liefert.
    ///
    /// Dieser zugehörige Typ entspricht dem `yield`-Ausdruck und den Werten, die jedes Mal zurückgegeben werden dürfen, wenn ein Generator nachgibt.
    ///
    /// Zum Beispiel würde ein Iterator als Generator wahrscheinlich diesen Typ als `T` haben, wobei der Typ durchlaufen wird.
    ///
    type Yield;

    /// Der Wertetyp, den dieser Generator zurückgibt.
    ///
    /// Dies entspricht dem Typ, der von einem Generator entweder mit einer `return`-Anweisung oder implizit als letzter Ausdruck eines Generatorliteral zurückgegeben wird.
    /// Zum Beispiel würde futures dies als `Result<T, E>` verwenden, da es ein abgeschlossenes future darstellt.
    ///
    ///
    type Return;

    /// Setzt die Ausführung dieses Generators fort.
    ///
    /// Diese Funktion setzt die Ausführung des Generators fort oder startet die Ausführung, falls dies noch nicht geschehen ist.
    /// Dieser Aufruf kehrt zum letzten Suspendierungspunkt des Generators zurück und setzt die Ausführung vom neuesten `yield` fort.
    /// Der Generator wird so lange ausgeführt, bis er entweder nachgibt oder zurückkehrt. An diesem Punkt kehrt diese Funktion zurück.
    ///
    /// # Rückgabewert
    ///
    /// Die von dieser Funktion zurückgegebene `GeneratorState`-Aufzählung gibt an, in welchem Zustand sich der Generator bei der Rückkehr befindet.
    /// Wenn die `Yielded`-Variante zurückgegeben wird, hat der Generator einen Aufhängepunkt erreicht und ein Wert wurde ausgegeben.
    /// Generatoren in diesem Zustand können zu einem späteren Zeitpunkt wieder aufgenommen werden.
    ///
    /// Wenn `Complete` zurückgegeben wird, ist der Generator mit dem angegebenen Wert vollständig fertig.Es ist ungültig, wenn der Generator wieder aufgenommen wird.
    ///
    /// # Panics
    ///
    /// Diese Funktion kann panic sein, wenn sie aufgerufen wird, nachdem die `Complete`-Variante zuvor zurückgegeben wurde.
    /// Während Generatorliterale in der Sprache bei Wiederaufnahme nach `Complete` für panic garantiert sind, ist dies nicht für alle Implementierungen des `Generator` trait garantiert.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}