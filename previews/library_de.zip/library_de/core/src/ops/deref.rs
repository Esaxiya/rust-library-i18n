/// Wird für unveränderliche Dereferenzierungsvorgänge wie `*v` verwendet.
///
/// `Deref` wird nicht nur für explizite Dereferenzierungsvorgänge mit dem (unary) `*`-Operator in unveränderlichen Kontexten verwendet, sondern unter vielen Umständen auch implizit vom Compiler verwendet.
/// Dieser Mechanismus heißt ['`Deref` coercion'][more].
/// In veränderlichen Kontexten wird [`DerefMut`] verwendet.
///
/// Durch die Implementierung von `Deref` für intelligente Zeiger wird der Zugriff auf die dahinter liegenden Daten bequem, weshalb `Deref` implementiert wird.
/// Andererseits wurden die Regeln für `Deref` und [`DerefMut`] speziell für intelligente Zeiger entwickelt.
/// Aus diesem Grund sollte **`Deref` nur für intelligente Zeiger** implementiert werden, um Verwirrung zu vermeiden.
///
/// Aus ähnlichen Gründen **sollte dieser trait niemals ausfallen**.Ein Fehler während der Dereferenzierung kann äußerst verwirrend sein, wenn `Deref` implizit aufgerufen wird.
///
/// # Mehr zum `Deref`-Zwang
///
/// Wenn `T` `Deref<Target = U>` implementiert und `x` ein Wert vom Typ `T` ist, gilt Folgendes:
///
/// * In unveränderlichen Kontexten entspricht `*x` (wobei `T` weder eine Referenz noch ein Rohzeiger ist) `* Deref::deref(&x)`.
/// * Werte vom Typ `&T` werden zu Werten vom Typ `&U` gezwungen
/// * `T` implementiert implizit alle (immutable)-Methoden vom Typ `U`.
///
/// Weitere Informationen finden Sie unter [the chapter in *The Rust Programming Language*][book] sowie in den Referenzabschnitten zu [the dereference operator][ref-deref-op], [method resolution] und [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Eine Struktur mit einem einzelnen Feld, auf die durch Dereferenzieren der Struktur zugegriffen werden kann.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Der resultierende Typ nach der Dereferenzierung.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferenziert den Wert.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Wird für veränderbare Dereferenzierungsvorgänge wie in `*v = 1;` verwendet.
///
/// `DerefMut` wird nicht nur für explizite Dereferenzierungsvorgänge mit dem (unary) `*`-Operator in veränderlichen Kontexten verwendet, sondern unter vielen Umständen auch implizit vom Compiler verwendet.
/// Dieser Mechanismus heißt ['`Deref` coercion'][more].
/// In unveränderlichen Kontexten wird [`Deref`] verwendet.
///
/// Durch die Implementierung von `DerefMut` für intelligente Zeiger wird das Mutieren der dahinter liegenden Daten bequem, weshalb `DerefMut` implementiert wird.
/// Andererseits wurden die Regeln für [`Deref`] und `DerefMut` speziell für intelligente Zeiger entwickelt.
/// Aus diesem Grund sollte **`DerefMut` nur für intelligente Zeiger** implementiert werden, um Verwirrung zu vermeiden.
///
/// Aus ähnlichen Gründen **sollte dieser trait niemals ausfallen**.Ein Fehler während der Dereferenzierung kann äußerst verwirrend sein, wenn `DerefMut` implizit aufgerufen wird.
///
/// # Mehr zum `Deref`-Zwang
///
/// Wenn `T` `DerefMut<Target = U>` implementiert und `x` ein Wert vom Typ `T` ist, gilt Folgendes:
///
/// * In veränderlichen Kontexten entspricht `*x` (wobei `T` weder eine Referenz noch ein Rohzeiger ist) `* DerefMut::deref_mut(&mut x)`.
/// * Werte vom Typ `&mut T` werden zu Werten vom Typ `&mut U` gezwungen
/// * `T` implementiert implizit alle (mutable)-Methoden vom Typ `U`.
///
/// Weitere Informationen finden Sie unter [the chapter in *The Rust Programming Language*][book] sowie in den Referenzabschnitten zu [the dereference operator][ref-deref-op], [method resolution] und [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Eine Struktur mit einem einzelnen Feld, die durch Dereferenzieren der Struktur geändert werden kann.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Der Wert wird veränderlich dereferenziert.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Gibt an, dass eine Struktur ohne die `arbitrary_self_types`-Funktion als Methodenempfänger verwendet werden kann.
///
/// Dies wird durch stdlib-Zeigertypen wie `Box<T>`, `Rc<T>`, `&T` und `Pin<P>` implementiert.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}