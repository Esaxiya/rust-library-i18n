/// Die Version des Anrufbetreibers, der einen unveränderlichen Empfänger nimmt.
///
/// Instanzen von `Fn` können wiederholt aufgerufen werden, ohne den Status zu ändern.
///
/// *Dieser trait (`Fn`) ist nicht mit [function pointers] (`fn`) zu verwechseln.*
///
/// `Fn` wird automatisch durch Abschlüsse implementiert, die nur unveränderliche Verweise auf erfasste Variablen enthalten oder überhaupt nichts erfassen, sowie (safe) [function pointers] (mit einigen Einschränkungen siehe deren Dokumentation für weitere Details).
///
/// Darüber hinaus implementiert `&F` für jeden Typ `F`, der `Fn` implementiert, auch `Fn`.
///
/// Da sowohl [`FnMut`] als auch [`FnOnce`] Supertraits von `Fn` sind, kann jede Instanz von `Fn` als Parameter verwendet werden, bei dem ein [`FnMut`] oder [`FnOnce`] erwartet wird.
///
/// Verwenden Sie `Fn` als Grenze, wenn Sie einen Parameter vom funktionsähnlichen Typ akzeptieren möchten und ihn wiederholt und ohne Mutationsstatus aufrufen müssen (z. B. wenn Sie ihn gleichzeitig aufrufen).
/// Wenn Sie keine so strengen Anforderungen benötigen, verwenden Sie [`FnMut`] oder [`FnOnce`] als Grenzen.
///
/// Weitere Informationen zu diesem Thema finden Sie im [chapter on closures in *The Rust Programming Language*][book].
///
/// Bemerkenswert ist auch die spezielle Syntax für `Fn` traits (z
/// `Fn(usize, bool) -> usize`).Wer sich für die technischen Details interessiert, kann sich auf [the relevant section in the *Rustonomicon*][nomicon] beziehen.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Schließung schließen
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Verwenden eines `Fn`-Parameters
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // damit regex sich auf dieses `&str: !FnMut` verlassen kann
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Führt den Anrufvorgang aus.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Die Version des Anrufbetreibers, der einen veränderlichen Empfänger akzeptiert.
///
/// Instanzen von `FnMut` können wiederholt aufgerufen werden und den Status ändern.
///
/// `FnMut` wird automatisch durch Abschlüsse implementiert, die veränderbare Verweise auf erfasste Variablen enthalten, sowie durch alle Typen, die [`Fn`] implementieren, z. B. (safe) [function pointers] (da `FnMut` ein Supertrait von [`Fn`] ist).
/// Darüber hinaus implementiert `&mut F` für jeden Typ `F`, der `FnMut` implementiert, auch `FnMut`.
///
/// Da [`FnOnce`] ein Supertrait von `FnMut` ist, kann jede Instanz von `FnMut` verwendet werden, wenn ein [`FnOnce`] erwartet wird, und da [`Fn`] ein Subtrait von `FnMut` ist, kann jede Instanz von [`Fn`] verwendet werden, wenn `FnMut` erwartet wird.
///
/// Verwenden Sie `FnMut` als Grenze, wenn Sie einen Parameter vom funktionsähnlichen Typ akzeptieren möchten und ihn wiederholt aufrufen müssen, während Sie ihm erlauben, den Status zu ändern.
/// Wenn Sie nicht möchten, dass der Parameter den Status ändert, verwenden Sie [`Fn`] als Grenze.Wenn Sie es nicht wiederholt aufrufen müssen, verwenden Sie [`FnOnce`].
///
/// Weitere Informationen zu diesem Thema finden Sie im [chapter on closures in *The Rust Programming Language*][book].
///
/// Bemerkenswert ist auch die spezielle Syntax für `Fn` traits (z
/// `Fn(usize, bool) -> usize`).Wer sich für die technischen Details interessiert, kann sich auf [the relevant section in the *Rustonomicon*][nomicon] beziehen.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Aufruf eines veränderlich erfassenden Verschlusses
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Verwenden eines `FnMut`-Parameters
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // damit regex sich auf dieses `&str: !FnMut` verlassen kann
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Führt den Anrufvorgang aus.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Die Version des Anrufbetreibers, die einen By-Value-Empfänger verwendet.
///
/// Instanzen von `FnOnce` können aufgerufen werden, sind jedoch möglicherweise nicht mehrmals aufrufbar.Wenn aus einem Typ nur bekannt ist, dass er `FnOnce` implementiert, kann er aus diesem Grund nur einmal aufgerufen werden.
///
/// `FnOnce` wird automatisch durch Schließungen implementiert, die möglicherweise erfasste Variablen verbrauchen, sowie durch alle Typen, die [`FnMut`] implementieren, z. B. (safe) [function pointers] (da `FnOnce` eine Supertrait von [`FnMut`] ist).
///
///
/// Da sowohl [`Fn`] als auch [`FnMut`] Subtraits von `FnOnce` sind, kann jede Instanz von [`Fn`] oder [`FnMut`] verwendet werden, wenn ein `FnOnce` erwartet wird.
///
/// Verwenden Sie `FnOnce` als Grenze, wenn Sie einen Parameter vom funktionsähnlichen Typ akzeptieren möchten und ihn nur einmal aufrufen müssen.
/// Wenn Sie den Parameter wiederholt aufrufen müssen, verwenden Sie [`FnMut`] als Grenze.Wenn Sie es auch benötigen, um den Status nicht zu ändern, verwenden Sie [`Fn`].
///
/// Weitere Informationen zu diesem Thema finden Sie im [chapter on closures in *The Rust Programming Language*][book].
///
/// Bemerkenswert ist auch die spezielle Syntax für `Fn` traits (z
/// `Fn(usize, bool) -> usize`).Wer sich für die technischen Details interessiert, kann sich auf [the relevant section in the *Rustonomicon*][nomicon] beziehen.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Verwenden eines `FnOnce`-Parameters
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` verbraucht die erfassten Variablen, sodass es nicht mehr als einmal ausgeführt werden kann.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Wenn Sie versuchen, `func()` erneut aufzurufen, wird ein `use of moved value`-Fehler für `func` ausgegeben.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kann an dieser Stelle nicht mehr aufgerufen werden
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // damit regex sich auf dieses `&str: !FnMut` verlassen kann
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Der zurückgegebene Typ, nachdem der Anrufoperator verwendet wurde.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Führt den Anrufvorgang aus.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}