use crate::marker::Unsize;

/// Trait, das angibt, dass dies ein Zeiger oder ein Wrapper für einen Zeiger ist, bei dem die Größenänderung am Pointee durchgeführt werden kann.
///
/// Weitere Informationen finden Sie im [DST coercion RFC][dst-coerce] und [the nomicon entry on coercion][nomicon-coerce].
///
/// Bei integrierten Zeigertypen werden Zeiger auf `T` zu Zeigern auf `U` erzwungen, wenn `T: Unsize<U>` von einem dünnen Zeiger in einen fetten Zeiger konvertiert wird.
///
/// Bei benutzerdefinierten Typen erzwingt der Zwang hier `Foo<T>` zu `Foo<U>`, sofern ein Impl von `CoerceUnsized<Foo<U>> for Foo<T>` vorhanden ist.
/// Ein solches Impl kann nur geschrieben werden, wenn `Foo<T>` nur ein einziges Nicht-Phantomdatenfeld hat, an dem `T` beteiligt ist.
/// Wenn der Typ dieses Felds `Bar<T>` ist, muss eine Implementierung von `CoerceUnsized<Bar<U>> for Bar<T>` vorhanden sein.
/// Der Zwang funktioniert, indem das `Bar<T>`-Feld in `Bar<U>` gezwungen und die restlichen Felder von `Foo<T>` ausgefüllt werden, um ein `Foo<U>` zu erstellen.
/// Dadurch wird effektiv ein Drilldown zu einem Zeigerfeld durchgeführt und dieses erzwungen.
///
/// Im Allgemeinen implementieren Sie für intelligente Zeiger `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, wobei ein optionales `?Sized` an `T` selbst gebunden ist.
/// Für Wrapper-Typen, die `T` direkt einbetten, wie `Cell<T>` und `RefCell<T>`, können Sie `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` direkt implementieren.
///
/// Dadurch können Zwänge von Typen wie `Cell<Box<T>>` funktionieren.
///
/// [`Unsize`][unsize] wird verwendet, um Typen zu markieren, die hinter Zeigern zu Sommerzeiten gezwungen werden können.Es wird vom Compiler automatisch implementiert.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Dies wird zur Objektsicherheit verwendet, um zu überprüfen, ob der Empfängertyp einer Methode versendet werden kann.
///
/// Eine Beispielimplementierung des trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}