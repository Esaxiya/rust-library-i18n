/// Benutzerdefinierter Code im Destruktor.
///
/// Wenn ein Wert nicht mehr benötigt wird, führt Rust einen "destructor" für diesen Wert aus.
/// Ein Wert wird am häufigsten nicht mehr benötigt, wenn er außerhalb des Gültigkeitsbereichs liegt.Destruktoren können unter anderen Umständen noch ausgeführt werden, aber wir werden uns hier auf den Umfang der Beispiele konzentrieren.
/// Informationen zu einigen dieser anderen Fälle finden Sie im Abschnitt [the reference] zu Destruktoren.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Dieser Destruktor besteht aus zwei Komponenten:
/// - Ein Aufruf von `Drop::drop` für diesen Wert, wenn dieser spezielle `Drop` trait für seinen Typ implementiert ist.
/// - Das automatisch generierte "drop glue", das rekursiv die Destruktoren aller Felder dieses Werts aufruft.
///
/// Da Rust automatisch die Destruktoren aller enthaltenen Felder aufruft, müssen Sie `Drop` in den meisten Fällen nicht implementieren.
/// In einigen Fällen ist dies jedoch hilfreich, z. B. für Typen, die eine Ressource direkt verwalten.
/// Diese Ressource kann Speicher sein, es kann ein Dateideskriptor sein, es kann ein Netzwerk-Socket sein.
/// Sobald ein Wert dieses Typs nicht mehr verwendet wird, sollte er seine Ressource "clean up", indem er den Speicher freigibt oder die Datei oder den Socket schließt.
/// Dies ist die Aufgabe eines Destruktors und daher die Aufgabe von `Drop::drop`.
///
/// ## Examples
///
/// Schauen wir uns das folgende Programm an, um Destruktoren in Aktion zu sehen:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust ruft zuerst `Drop::drop` für `_x` und dann sowohl für `_x.one` als auch für `_x.two` auf, was bedeutet, dass dies ausgeführt wird
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Selbst wenn wir die Implementierung von `Drop` für `HasTwoDrop` entfernen, werden die Destruktoren seiner Felder immer noch aufgerufen.
/// Dies würde dazu führen
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Sie können `Drop::drop` nicht selbst anrufen
///
/// Da `Drop::drop` zum Bereinigen eines Werts verwendet wird, kann es gefährlich sein, diesen Wert nach dem Aufruf der Methode zu verwenden.
/// Da `Drop::drop` nicht den Besitz seiner Eingabe übernimmt, verhindert Rust Missbrauch, indem Sie `Drop::drop` nicht direkt aufrufen können.
///
/// Mit anderen Worten, wenn Sie im obigen Beispiel explizit versucht haben, `Drop::drop` aufzurufen, wird ein Compilerfehler angezeigt.
///
/// Wenn Sie den Destruktor eines Werts explizit aufrufen möchten, kann stattdessen [`mem::drop`] verwendet werden.
///
/// [`mem::drop`]: drop
///
/// ## Bestellung aufgeben
///
/// Welcher unserer beiden `HasDrop` fällt jedoch zuerst ab?Für Strukturen ist es dieselbe Reihenfolge, in der sie deklariert sind: zuerst `one`, dann `two`.
/// Wenn Sie dies selbst versuchen möchten, können Sie `HasDrop` oben so ändern, dass es einige Daten enthält, z. B. eine Ganzzahl, und diese dann in `println!` innerhalb von `Drop` verwenden.
/// Dieses Verhalten wird durch die Sprache garantiert.
///
/// Im Gegensatz zu Strukturen werden lokale Variablen in umgekehrter Reihenfolge gelöscht:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dies wird gedruckt
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Die vollständigen Regeln finden Sie unter [the reference].
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` und `Drop` sind exklusiv
///
/// Sie können nicht sowohl [`Copy`] als auch `Drop` auf demselben Typ implementieren.`Copy`-Typen werden vom Compiler implizit dupliziert, was es sehr schwierig macht, vorherzusagen, wann und wie oft Destruktoren ausgeführt werden.
///
/// Daher können diese Typen keine Destruktoren haben.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Führt den Destruktor für diesen Typ aus.
    ///
    /// Diese Methode wird implizit aufgerufen, wenn der Wert den Gültigkeitsbereich verlässt, und kann nicht explizit aufgerufen werden (dies ist der Compilerfehler [E0040]).
    /// Mit der [`mem::drop`]-Funktion im prelude kann jedoch die `Drop`-Implementierung des Arguments aufgerufen werden.
    ///
    /// Wenn diese Methode aufgerufen wurde, wurde `self` noch nicht freigegeben.
    /// Dies geschieht erst, nachdem die Methode beendet ist.
    /// Wenn dies nicht der Fall wäre, wäre `self` eine baumelnde Referenz.
    ///
    /// # Panics
    ///
    /// Da ein [`panic!`] beim Abwickeln `drop` aufruft, wird wahrscheinlich jedes [`panic!`] in einer `drop`-Implementierung abgebrochen.
    ///
    /// Beachten Sie, dass selbst bei diesem panics der Wert als gelöscht betrachtet wird.
    /// Sie dürfen nicht veranlassen, dass `drop` erneut aufgerufen wird.
    /// Dies wird normalerweise automatisch vom Compiler erledigt. Bei Verwendung von unsicherem Code kann dies jedoch manchmal unbeabsichtigt auftreten, insbesondere bei Verwendung von [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}