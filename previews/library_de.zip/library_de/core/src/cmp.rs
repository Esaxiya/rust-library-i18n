//! Funktionalität zum Bestellen und Vergleichen.
//!
//! Dieses Modul enthält verschiedene Tools zum Bestellen und Vergleichen von Werten.Zusammenfassend:
//!
//! * [`Eq`] und [`PartialEq`] sind traits, mit denen Sie die vollständige bzw. teilweise Gleichheit zwischen Werten definieren können.
//! Durch ihre Implementierung werden die Operatoren `==` und `!=` überlastet.
//! * [`Ord`] und [`PartialOrd`] sind traits, mit denen Sie Gesamt-und Teilreihenfolgen zwischen Werten definieren können.
//!
//! Durch ihre Implementierung werden die Operatoren `<`, `<=`, `>` und `>=` überlastet.
//! * [`Ordering`] ist eine Aufzählung, die von den Hauptfunktionen von [`Ord`] und [`PartialOrd`] zurückgegeben wird und eine Bestellung beschreibt.
//! * [`Reverse`] ist eine Struktur, mit der Sie eine Bestellung einfach umkehren können.
//! * [`max`] und [`min`] sind Funktionen, die auf [`Ord`] aufbauen und es Ihnen ermöglichen, das Maximum oder Minimum von zwei Werten zu finden.
//!
//! Weitere Einzelheiten finden Sie in der jeweiligen Dokumentation der einzelnen Elemente in der Liste.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait für Gleichheitsvergleiche, die [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) sind.
///
/// Dieser trait ermöglicht eine teilweise Gleichheit für Typen, die keine vollständige Äquivalenzbeziehung haben.
/// Beispielsweise implementieren Gleitkommazahlen in Gleitkommazahlen `NaN != NaN` `PartialEq`, nicht jedoch [`trait@Eq`].
///
/// Formal muss die Gleichheit sein (für alle `a`, `b`, `c` vom Typ `A`, `B`, `C`):
///
/// - **Symmetrisch**: Wenn `A: PartialEq<B>` und `B: PartialEq<A>`, dann impliziert **`a==b`` b==a`**;und
///
/// - **Transitiv**: wenn `A: PartialEq<B>` und `B: PartialEq<C>` und `A:
///   PartialEq<C>`, dann impliziert **` a==b`und `b == c` a==c`**.
///
/// Beachten Sie, dass die `B: PartialEq<A>` (symmetric)-und `A: PartialEq<C>` (transitive)-Geräte nicht zur Existenz gezwungen werden. Diese Anforderungen gelten jedoch immer dann, wenn sie vorhanden sind.
///
/// ## Derivable
///
/// Dieser trait kann mit `#[derive]` verwendet werden.Wenn auf Strukturen abgeleitet werden, sind zwei Instanzen gleich, wenn alle Felder gleich sind, und ungleich, wenn Felder nicht gleich sind.Wenn auf Enums abgeleitet wird, ist jede Variante gleich sich selbst und nicht gleich den anderen Varianten.
///
/// ## Wie kann ich `PartialEq` implementieren?
///
/// `PartialEq` erfordert nur die Implementierung der [`eq`]-Methode;[`ne`] ist standardmäßig definiert.Bei jeder manuellen Implementierung von [`ne`]*muss* die Regel beachtet werden, dass [`eq`] eine strikte Umkehrung von [`ne`] ist.das heißt, `!(a == b)` genau dann, wenn `a != b`.
///
/// Implementierungen von `PartialEq`, [`PartialOrd`] und [`Ord`]*müssen* miteinander übereinstimmen.Es ist leicht, sie versehentlich nicht einverstanden zu machen, indem einige der traits abgeleitet und andere manuell implementiert werden.
///
/// Eine Beispielimplementierung für eine Domäne, in der zwei Bücher als dasselbe Buch betrachtet werden, wenn ihre ISBN übereinstimmt, auch wenn sich die Formate unterscheiden:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Wie kann ich zwei verschiedene Typen vergleichen?
///
/// Der Typ, mit dem Sie vergleichen können, wird durch den Typparameter von PartialEq gesteuert.
/// Lassen Sie uns zum Beispiel unseren vorherigen Code ein wenig optimieren:
///
/// ```
/// // Die Ableitung implementiert<BookFormat>==<BookFormat>Vergleiche
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Implementieren<Book>==<BookFormat>Vergleiche
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Implementieren<BookFormat>==<Book>Vergleiche
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Durch Ändern von `impl PartialEq for Book` in `impl PartialEq<BookFormat> for Book` können wir "BookFormat" mit "Book" vergleichen.
///
/// Ein Vergleich wie der obige, bei dem einige Felder der Struktur ignoriert werden, kann gefährlich sein.Dies kann leicht zu einer unbeabsichtigten Verletzung der Anforderungen für eine partielle Äquivalenzbeziehung führen.
/// Wenn wir beispielsweise die obige Implementierung von `PartialEq<Book>` für `BookFormat` beibehalten und eine Implementierung von `PartialEq<Book>` für `Book` hinzufügen (entweder über `#[derive]` oder über die manuelle Implementierung aus dem ersten Beispiel), würde das Ergebnis die Transitivität verletzen:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Diese Methode prüft, ob `self`-und `other`-Werte gleich sind, und wird von `==` verwendet.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Diese Methode testet auf `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Leiten Sie ein Makro ab, das ein Impl des trait `PartialEq` generiert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait für Gleichheitsvergleiche, die [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) sind.
///
/// Dies bedeutet, dass zusätzlich zu den strengen Umkehrungen von `a == b` und `a != b` die Gleichheit sein muss (für alle `a`, `b` und `c`):
///
/// - reflexive: `a == a`;
/// - symmetrisch: `a == b` impliziert `b == a`;und
/// - transitiv: `a == b` und `b == c` implizieren `a == c`.
///
/// Diese Eigenschaft kann vom Compiler nicht überprüft werden. Daher impliziert `Eq` [`PartialEq`] und verfügt über keine zusätzlichen Methoden.
///
/// ## Derivable
///
/// Dieser trait kann mit `#[derive]` verwendet werden.
/// Wenn "ableiten", weil `Eq` keine zusätzlichen Methoden hat, informiert es den Compiler nur, dass dies eher eine Äquivalenzrelation als eine partielle Äquivalenzrelation ist.
///
/// Beachten Sie, dass für die `derive`-Strategie alle Felder `Eq` sind, was nicht immer erwünscht ist.
///
/// ## Wie kann ich `Eq` implementieren?
///
/// Wenn Sie die `derive`-Strategie nicht verwenden können, geben Sie an, dass Ihr Typ `Eq` implementiert, für das keine Methoden vorhanden sind:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // Diese Methode wird ausschließlich von#[Ableiten] verwendet, um zu behaupten, dass jede Komponente eines Typs#[Ableiten] selbst implementiert. Die aktuelle Ableitungsinfrastruktur bedeutet, dass diese Behauptung ohne Verwendung einer Methode für diesen trait nahezu unmöglich ist.
    //
    //
    // Dies sollte niemals von Hand durchgeführt werden.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Leiten Sie ein Makro ab, das ein Impl des trait `Eq` generiert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: Diese Struktur wird ausschließlich von#[ableiten] bis verwendet
// behaupten, dass jede Komponente eines Typs Gl.
//
// Diese Struktur sollte niemals im Benutzercode erscheinen.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ein `Ordering` ist das Ergebnis eines Vergleichs zwischen zwei Werten.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Eine Bestellung, bei der ein Vergleichswert kleiner als ein anderer ist.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Eine Bestellung, bei der ein Vergleichswert gleich einem anderen ist.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Eine Bestellung, bei der ein Vergleichswert größer als ein anderer ist.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Gibt `true` zurück, wenn die Bestellung die `Equal`-Variante ist.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Gibt `true` zurück, wenn die Bestellung nicht die `Equal`-Variante ist.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Gibt `true` zurück, wenn die Bestellung die `Less`-Variante ist.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Gibt `true` zurück, wenn die Bestellung die `Greater`-Variante ist.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Gibt `true` zurück, wenn die Bestellung entweder die Variante `Less` oder `Equal` ist.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Gibt `true` zurück, wenn die Bestellung entweder die Variante `Greater` oder `Equal` ist.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Kehrt den `Ordering` um.
    ///
    /// * `Less` wird `Greater`.
    /// * `Greater` wird `Less`.
    /// * `Equal` wird `Equal`.
    ///
    /// # Examples
    ///
    /// Grundlegendes Verhalten:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Diese Methode kann verwendet werden, um einen Vergleich umzukehren:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // Sortieren Sie das Array vom größten zum kleinsten.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Verkettet zwei Ordnungen.
    ///
    /// Gibt `self` zurück, wenn es nicht `Equal` ist.Andernfalls wird `other` zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Verkettet die Reihenfolge mit der angegebenen Funktion.
    ///
    /// Gibt `self` zurück, wenn es nicht `Equal` ist.
    /// Andernfalls wird `f` aufgerufen und das Ergebnis zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Eine Hilfsstruktur für die umgekehrte Reihenfolge.
///
/// Diese Struktur ist ein Helfer für Funktionen wie [`Vec::sort_by_key`] und kann verwendet werden, um die Reihenfolge eines Teils eines Schlüssels umzukehren.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait für Typen, die einen [total order](https://en.wikipedia.org/wiki/Total_order) bilden.
///
/// Eine Bestellung ist eine Gesamtbestellung, wenn dies der Fall ist (für alle `a`, `b` und `c`):
///
/// - total und asymmetrisch: genau eines von `a < b`, `a == b` oder `a > b` ist wahr;und
/// - transitiv, `a < b` und `b < c` implizieren `a < c`.Das Gleiche muss für `==` und `>` gelten.
///
/// ## Derivable
///
/// Dieser trait kann mit `#[derive]` verwendet werden.
/// Wenn es von Strukturen abgeleitet wird, wird eine [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order)-Reihenfolge basierend auf der Deklarationsreihenfolge von oben nach unten der Mitglieder der Struktur erzeugt.
///
/// Wenn auf Enums abgeleitet werden, werden Varianten nach ihrer Diskriminanzreihenfolge von oben nach unten geordnet.
///
/// ## Lexikographischer Vergleich
///
/// Der lexikografische Vergleich ist eine Operation mit den folgenden Eigenschaften:
///  - Zwei Sequenzen werden Element für Element verglichen.
///  - Das erste nicht übereinstimmende Element definiert, welche Sequenz lexikographisch kleiner oder größer als die andere ist.
///  - Wenn eine Sequenz ein Präfix einer anderen ist, ist die kürzere Sequenz lexikographisch kleiner als die andere.
///  - Wenn zwei Sequenzen äquivalente Elemente haben und gleich lang sind, sind die Sequenzen lexikographisch gleich.
///  - Eine leere Sequenz ist lexikographisch weniger als jede nicht leere Sequenz.
///  - Zwei leere Sequenzen sind lexikographisch gleich.
///
/// ## Wie kann ich `Ord` implementieren?
///
/// `Ord` erfordert, dass der Typ auch [`PartialOrd`] und [`Eq`] ist (was [`PartialEq`] erfordert).
///
/// Dann müssen Sie eine Implementierung für [`cmp`] definieren.Möglicherweise ist es hilfreich, [`cmp`] in den Feldern Ihres Typs zu verwenden.
///
/// Implementierungen von [`PartialEq`], [`PartialOrd`] und `Ord`*müssen* miteinander übereinstimmen.
/// Das heißt, `a.cmp(b) == Ordering::Equal` genau dann, wenn `a == b` und `Some(a.cmp(b)) == a.partial_cmp(b)` für alle `a` und `b`.
/// Es ist leicht, sie versehentlich nicht einverstanden zu machen, indem einige der traits abgeleitet und andere manuell implementiert werden.
///
/// Hier ist ein Beispiel, in dem Sie Personen nur nach Größe sortieren möchten, ohne `id` und `name` zu berücksichtigen:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Diese Methode gibt ein [`Ordering`] zwischen `self` und `other` zurück.
    ///
    /// Gemäß der Konvention gibt `self.cmp(&other)` die Reihenfolge zurück, die mit dem Ausdruck `self <operator> other` übereinstimmt, wenn true.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Vergleicht und gibt maximal zwei Werte zurück.
    ///
    /// Gibt das zweite Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Vergleicht und gibt das Minimum von zwei Werten zurück.
    ///
    /// Gibt das erste Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Beschränken Sie einen Wert auf ein bestimmtes Intervall.
    ///
    /// Gibt `max` zurück, wenn `self` größer als `max` ist, und `min`, wenn `self` kleiner als `min` ist.
    /// Andernfalls wird `self` zurückgegeben.
    ///
    /// # Panics
    ///
    /// Panics wenn `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Leiten Sie ein Makro ab, das ein Impl des trait `Ord` generiert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait für Werte, die für eine Sortierreihenfolge verglichen werden können.
///
/// Der Vergleich muss für alle `a`, `b` und `c` Folgendes erfüllen:
///
/// - Asymmetrie: Wenn `a < b`, dann `!(a > b)` sowie `a > b`, was `!(a < b)` impliziert;und
/// - Transitivität: `a < b` und `b < c` implizieren `a < c`.Das Gleiche muss für `==` und `>` gelten.
///
/// Beachten Sie, dass diese Anforderungen bedeuten, dass der trait selbst symmetrisch und transitiv implementiert werden muss: Wenn `T: PartialOrd<U>` und `U: PartialOrd<V>`, dann `U: PartialOrd<T>` und `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Dieser trait kann mit `#[derive]` verwendet werden.Wenn es von Strukturen abgeleitet wird, wird eine lexikografische Reihenfolge basierend auf der Deklarationsreihenfolge der Mitglieder der Struktur von oben nach unten erstellt.
/// Wenn auf Enums abgeleitet werden, werden Varianten nach ihrer Diskriminanzreihenfolge von oben nach unten geordnet.
///
/// ## Wie kann ich `PartialOrd` implementieren?
///
/// `PartialOrd` erfordert nur die Implementierung der [`partial_cmp`]-Methode, wobei die anderen aus Standardimplementierungen generiert werden.
///
/// Es bleibt jedoch möglich, die anderen separat für Typen zu implementieren, die keine Gesamtreihenfolge haben.
/// Zum Beispiel für Gleitkommazahlen `NaN < 0 == false` und `NaN >= 0 == false` (vgl.
/// IEEE 754-2008 Abschnitt 5.11).
///
/// `PartialOrd` erfordert, dass Ihr Typ [`PartialEq`] ist.
///
/// Implementierungen von [`PartialEq`], `PartialOrd` und [`Ord`]*müssen* miteinander übereinstimmen.
/// Es ist leicht, sie versehentlich nicht einverstanden zu machen, indem einige der traits abgeleitet und andere manuell implementiert werden.
///
/// Wenn Ihr Typ [`Ord`] ist, können Sie [`partial_cmp`] mithilfe von [`cmp`] implementieren:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Möglicherweise ist es auch nützlich, [`partial_cmp`] für die Felder Ihres Typs zu verwenden.
/// Hier ist ein Beispiel für `Person`-Typen mit einem Gleitkomma-`height`-Feld, das als einziges Feld zum Sortieren verwendet wird:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Diese Methode gibt eine Reihenfolge zwischen `self`-und `other`-Werten zurück, falls vorhanden.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Wenn ein Vergleich unmöglich ist:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Diese Methode testet weniger als (für `self` und `other`) und wird vom `<`-Operator verwendet.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Diese Methode testet weniger als oder gleich (für `self` und `other`) und wird vom `<=`-Operator verwendet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Diese Methode testet größer als (für `self` und `other`) und wird vom `>`-Operator verwendet.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Diese Methode testet größer oder gleich (für `self` und `other`) und wird vom `>=`-Operator verwendet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Leiten Sie ein Makro ab, das ein Impl des trait `PartialOrd` generiert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Vergleicht und gibt das Minimum von zwei Werten zurück.
///
/// Gibt das erste Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
///
/// Verwendet intern einen Alias für [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Gibt das Minimum von zwei Werten in Bezug auf die angegebene Vergleichsfunktion zurück.
///
/// Gibt das erste Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Gibt das Element zurück, das den Mindestwert der angegebenen Funktion angibt.
///
/// Gibt das erste Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Vergleicht und gibt maximal zwei Werte zurück.
///
/// Gibt das zweite Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
///
/// Verwendet intern einen Alias für [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Gibt das Maximum von zwei Werten in Bezug auf die angegebene Vergleichsfunktion zurück.
///
/// Gibt das zweite Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Gibt das Element zurück, das den Maximalwert der angegebenen Funktion angibt.
///
/// Gibt das zweite Argument zurück, wenn der Vergleich feststellt, dass sie gleich sind.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Implementierung von PartialEq, Eq, PartialOrd und Ord für primitive Typen
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Die Reihenfolge hier ist wichtig, um eine optimalere Montage zu erzielen.
                    // Weitere Informationen finden Sie unter <https://github.com/rust-lang/rust/issues/63758>.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Das Casting auf i8 und das Konvertieren der Differenz in eine Bestellung führt zu einer optimaleren Montage.
            //
            // Weitere Informationen finden Sie unter <https://github.com/rust-lang/rust/issues/66780>.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SICHERHEIT: bool als i8 gibt 0 oder 1 zurück, daher kann der Unterschied nichts anderes sein
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &Zeiger

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}