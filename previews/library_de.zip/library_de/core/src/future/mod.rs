#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchrone Werte.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Dieser Typ wird benötigt, weil:
///
/// a) Generatoren können `for<'a, 'b> Generator<&'a mut Context<'b>>` nicht implementieren, daher müssen wir einen Rohzeiger übergeben (siehe <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raw-Zeiger und `NonNull` sind nicht `Send` oder `Sync`, so dass jeder einzelne future auch non-Send/Sync wäre, und das wollen wir nicht.
///
/// Es vereinfacht auch das HIR-Absenken von `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Wickeln Sie einen Generator in eine future.
///
/// Diese Funktion gibt ein `GenFuture` darunter zurück, versteckt es jedoch in `impl Trait`, um bessere Fehlermeldungen zu erhalten (`impl Future` anstelle von `GenFuture<[closure.....]>`).
///
// Dies ist `const`, um zusätzliche Fehler zu vermeiden, nachdem wir uns von `const async fn` erholt haben
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Wir verlassen uns auf die Tatsache, dass async/await futures unbeweglich sind, um selbstreferenzielle Ausleihen im zugrunde liegenden Generator zu erstellen.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SICHERHEIT: Sicher, weil wir !Unpin + !Drop sind und dies nur eine Feldprojektion ist.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Setzen Sie den Generator fort und verwandeln Sie den `&mut Context` in einen `NonNull`-Rohzeiger.
            // Durch das Absenken des `.await` wird dies sicher auf einen `&mut Context` zurückgeworfen.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SICHERHEIT: Der Anrufer muss garantieren, dass `cx.0` ein gültiger Zeiger ist
    // das erfüllt alle Voraussetzungen für eine veränderbare Referenz.
    unsafe { &mut *cx.0.as_ptr().cast() }
}