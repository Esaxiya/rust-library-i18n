use crate::future::Future;

/// Umwandlung in einen `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Die Ausgabe, die der future nach Abschluss erzeugt.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// In welche Art von future verwandeln wir das?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Erstellt eine future aus einem Wert.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}