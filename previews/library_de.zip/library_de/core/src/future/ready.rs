use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Erstellt eine future, die sofort mit einem Wert fertig ist.
///
/// Dieser `struct` wird von [`ready()`] erstellt.
/// Weitere Informationen finden Sie in der Dokumentation.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// Erstellt eine future, die sofort mit einem Wert fertig ist.
///
/// Mit dieser Funktion erstellte Futures ähneln funktional denen, die mit `async {}` erstellt wurden.
/// Der Hauptunterschied besteht darin, dass futures, die mit dieser Funktion erstellt wurden, benannt werden und `Unpin` implementieren.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}