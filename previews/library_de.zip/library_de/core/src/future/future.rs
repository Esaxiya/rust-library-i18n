#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Ein future repräsentiert eine asynchrone Berechnung.
///
/// Ein future ist ein Wert, dessen Berechnung möglicherweise noch nicht abgeschlossen ist.
/// Diese Art von "asynchronous value" ermöglicht es einem Thread, weiterhin nützliche Arbeit zu leisten, während er darauf wartet, dass der Wert verfügbar wird.
///
///
/// # Die `poll`-Methode
///
/// Die Kernmethode von future, `poll`,*versucht*, das future in einen Endwert aufzulösen.
/// Diese Methode wird nicht blockiert, wenn der Wert nicht bereit ist.
/// Stattdessen soll die aktuelle Aufgabe aktiviert werden, wenn durch erneutes Abrufen weitere Fortschritte erzielt werden können.
/// Das an die `poll`-Methode übergebene `context` kann ein [`Waker`] bereitstellen, das ein Handle zum Aufwecken der aktuellen Aufgabe ist.
///
/// Wenn Sie eine future verwenden, rufen Sie `poll` im Allgemeinen nicht direkt auf, sondern `.await` als Wert.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Die Art des Wertes, der bei Fertigstellung erzeugt wird.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Versuchen Sie, future in einen endgültigen Wert aufzulösen, und registrieren Sie die aktuelle Aufgabe zum Aufwecken, wenn der Wert noch nicht verfügbar ist.
    ///
    /// # Rückgabewert
    ///
    /// Diese Funktion gibt Folgendes zurück:
    ///
    /// - [`Poll::Pending`] wenn der future noch nicht fertig ist
    /// - [`Poll::Ready(val)`] mit dem Ergebnis `val` dieses future, wenn es erfolgreich beendet wurde.
    ///
    /// Sobald ein future fertig ist, sollten Clients es nicht mehr `poll`.
    ///
    /// Wenn ein future noch nicht bereit ist, gibt `poll` `Poll::Pending` zurück und speichert einen Klon des [`Waker`], der vom aktuellen [`Context`] kopiert wurde.
    /// Dieser [`Waker`] wird dann geweckt, sobald der future Fortschritte machen kann.
    /// Beispielsweise würde ein future, der darauf wartet, dass ein Socket lesbar wird, `.clone()` auf dem [`Waker`] aufrufen und speichern.
    /// Wenn an anderer Stelle ein Signal ankommt, das anzeigt, dass der Socket lesbar ist, wird [`Waker::wake`] aufgerufen und die Aufgabe des Sockets future wird aktiviert.
    /// Sobald eine Aufgabe aufgeweckt wurde, sollte sie erneut versuchen, die future zu `poll`, was möglicherweise einen endgültigen Wert ergibt oder nicht.
    ///
    /// Beachten Sie, dass bei mehreren Anrufen an `poll` nur der [`Waker`] von [`Context`], der an den letzten Anruf übergeben wurde, für den Empfang eines Weckvorgangs geplant werden sollte.
    ///
    /// # Laufzeitmerkmale
    ///
    /// Futures alleine sind *inert*;Sie müssen *aktiv*"abgefragt" werden, um Fortschritte zu erzielen. Dies bedeutet, dass jedes Mal, wenn die aktuelle Aufgabe aufgeweckt wird, sie bis zu futures, an dem sie noch interessiert ist, aktiv erneut "poll".
    ///
    /// Die `poll`-Funktion wird nicht wiederholt in einer engen Schleife aufgerufen. Stattdessen sollte sie nur aufgerufen werden, wenn die future anzeigt, dass sie bereit ist, Fortschritte zu erzielen (durch Aufrufen von `wake()`)).
    /// Wenn Sie mit den `poll(2)`-oder `select(2)`-Systemaufrufen unter Unix vertraut sind, sollten Sie beachten, dass futures normalerweise nicht die gleichen Probleme wie "all wakeups must poll all events" hat.Sie sind eher wie `epoll(4)`.
    ///
    /// Eine Implementierung von `poll` sollte sich um eine schnelle Rückkehr bemühen und nicht blockieren.Durch die schnelle Rückkehr wird verhindert, dass Threads oder Ereignisschleifen unnötig verstopft werden.
    /// Wenn im Voraus bekannt ist, dass ein Aufruf von `poll` eine Weile dauern kann, sollte die Arbeit in einen Thread-Pool (oder ähnliches) verlagert werden, um sicherzustellen, dass `poll` schnell zurückkehren kann.
    ///
    /// # Panics
    ///
    /// Sobald ein future abgeschlossen ist (`Ready` von `poll` zurückgegeben), kann das erneute Aufrufen seiner `poll`-Methode panic blockieren, für immer blockieren oder andere Probleme verursachen.Der `Future` trait stellt keine Anforderungen an die Auswirkungen eines solchen Anrufs.
    /// Da die `poll`-Methode jedoch nicht als `unsafe` gekennzeichnet ist, gelten die üblichen Regeln von Rust: Aufrufe dürfen niemals undefiniertes Verhalten (Speicherbeschädigung, falsche Verwendung von `unsafe`-Funktionen oder dergleichen) verursachen, unabhängig vom Status von future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}