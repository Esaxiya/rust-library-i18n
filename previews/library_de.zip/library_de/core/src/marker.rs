//! Primitive traits und Typen, die grundlegende Eigenschaften von Typen darstellen.
//!
//! Rust-Typen können anhand ihrer intrinsischen Eigenschaften auf verschiedene nützliche Arten klassifiziert werden.
//! Diese Klassifikationen werden als traits dargestellt.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typen, die über Threadgrenzen hinweg übertragen werden können.
///
/// Dieser trait wird automatisch implementiert, wenn der Compiler feststellt, dass er geeignet ist.
///
/// Ein Beispiel für einen Nicht-Sende-Typ ist der Referenzzählzeiger [`rc::Rc`][`Rc`].
/// Wenn zwei Threads versuchen, [`Rc`] zu klonen, die auf denselben Referenzzählwert verweisen, versuchen sie möglicherweise, den Referenzzähler gleichzeitig zu aktualisieren. Dies ist [undefined behavior][ub], da [`Rc`] keine atomaren Operationen verwendet.
///
/// Sein Cousin [`sync::Arc`][arc] verwendet atomare Operationen (was zu einem gewissen Overhead führt) und ist daher `Send`.
///
/// Weitere Informationen finden Sie unter [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typen mit einer konstanten Größe, die zur Kompilierungszeit bekannt sind.
///
/// Alle Typparameter haben eine implizite Grenze von `Sized`.Die spezielle Syntax `?Sized` kann verwendet werden, um diese Grenze zu entfernen, wenn sie nicht geeignet ist.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//Fehler: Größe ist für [i32] nicht implementiert
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Die einzige Ausnahme ist der implizite `Self`-Typ eines trait.
/// Ein trait hat keine implizite `Sized`-Bindung, da dies nicht mit [trait-Objekt] kompatibel ist, bei denen das trait per Definition mit allen möglichen Implementierern zusammenarbeiten muss und daher eine beliebige Größe haben kann.
///
///
/// Obwohl Sie mit Rust `Sized` an ein trait binden können, können Sie es später nicht mehr zum Erstellen eines trait-Objekts verwenden:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // sei y: &dyn Bar= &Impl;//Fehler: Der trait `Bar` kann nicht zu einem Objekt gemacht werden
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // Zum Beispiel für Standard, für das `[T]: !Default` auswertbar sein muss
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typen, die "unsized" für einen Typ mit dynamischer Größe sein können.
///
/// Beispielsweise implementiert der Array-Typ `[i8; 2]` `Unsize<[i8]>` und `Unsize<dyn fmt::Debug>`.
///
/// Alle Implementierungen von `Unsize` werden automatisch vom Compiler bereitgestellt.
///
/// `Unsize` ist implementiert für:
///
/// - `[T; N]` ist `Unsize<[T]>`
/// - `T` ist `Unsize<dyn Trait>` bei `T: Trait`
/// - `Foo<..., T, ...>` ist `Unsize<Foo<..., U, ...>>` wenn:
///   - `T: Unsize<U>`
///   - Foo ist eine Struktur
///   - Nur das letzte Feld von `Foo` hat einen Typ, an dem `T` beteiligt ist
///   - `T` ist nicht Teil des Typs anderer Felder
///   - `Bar<T>: Unsize<Bar<U>>`, wenn das letzte Feld von `Foo` den Typ `Bar<T>` hat
///
/// `Unsize` wird zusammen mit [`ops::CoerceUnsized`] verwendet, damit "user-defined"-Container wie [`Rc`] Typen mit dynamischer Größe enthalten können.
/// Weitere Informationen finden Sie im [DST coercion RFC][RFC982] und [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Erforderliches trait für Konstanten, die in Musterübereinstimmungen verwendet werden.
///
/// Jeder Typ, der `PartialEq` ableitet, implementiert diesen trait automatisch,*unabhängig* davon, ob seine Typparameter `Eq` implementieren.
///
/// Wenn ein `const`-Element einen Typ enthält, der dieses trait nicht implementiert, implementiert dieser Typ entweder (1.) kein `PartialEq` (was bedeutet, dass die Konstante nicht die Vergleichsmethode bereitstellt, von der die Codegenerierung annimmt, dass sie verfügbar ist), oder (2.) implementiert *seinen eigenen* Version von `PartialEq` (von der wir annehmen, dass sie keinem Strukturgleichheitsvergleich entspricht).
///
///
/// In beiden oben genannten Szenarien lehnen wir die Verwendung einer solchen Konstante in einer Musterübereinstimmung ab.
///
/// Siehe auch [structural match RFC][RFC1445] und [issue 63438], die die Migration vom attributbasierten Design zu diesem trait motiviert haben.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Erforderliches trait für Konstanten, die in Musterübereinstimmungen verwendet werden.
///
/// Jeder Typ, der `Eq` ableitet, implementiert diesen trait automatisch,*unabhängig* davon, ob seine Typparameter `Eq` implementieren.
///
/// Dies ist ein Hack, um eine Einschränkung in unserem Typsystem zu umgehen.
///
/// # Background
///
/// Wir möchten verlangen, dass Konstantentypen, die in Musterübereinstimmungen verwendet werden, das Attribut `#[derive(PartialEq, Eq)]` haben.
///
/// In einer idealeren Welt könnten wir diese Anforderung überprüfen, indem wir nur überprüfen, ob der angegebene Typ sowohl den `StructuralPartialEq` trait * als auch den `Eq` trait implementiert.
/// Sie können jedoch ADTs haben, die *`derive(PartialEq, Eq)`* ausführen, und ein Fall sein, den der Compiler akzeptieren soll, und dennoch kann der Typ der Konstante `Eq` nicht implementieren.
///
/// Ein Fall wie dieser:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Das Problem im obigen Code ist, dass `Wrap<fn(&())>` weder `PartialEq` noch `Eq` implementiert, weil `für <'a> fn(&'a _)` does not implement those traits.)
///
/// Daher können wir uns nicht auf eine naive Prüfung für `StructuralPartialEq` und nur für `Eq` verlassen.
///
/// Um dies zu umgehen, verwenden wir zwei separate traits, die von jedem der beiden Derivate (`#[derive(PartialEq)]` und `#[derive(Eq)]`) injiziert werden, und überprüfen, ob beide im Rahmen der strukturellen Übereinstimmungsprüfung vorhanden sind.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typen, deren Werte einfach durch Kopieren von Bits dupliziert werden können.
///
/// Standardmäßig haben Variablenbindungen die Verschiebungssemantik.Mit anderen Worten:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ist in `y` umgezogen und kann daher nicht verwendet werden
///
/// // println! ("{: ?}", x);//Fehler: Verwendung des verschobenen Wertes
/// ```
///
/// Wenn ein Typ jedoch `Copy` implementiert, verfügt er stattdessen über 'Kopiersemantik':
///
/// ```
/// // Wir können eine `Copy`-Implementierung ableiten.
/// // `Clone` ist auch erforderlich, da es sich um ein Supertrait von `Copy` handelt.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ist eine Kopie von `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Es ist wichtig zu beachten, dass in diesen beiden Beispielen der einzige Unterschied darin besteht, ob Sie nach der Zuweisung auf `x` zugreifen dürfen.
/// Unter der Haube können sowohl eine Kopie als auch eine Verschiebung dazu führen, dass Bits in den Speicher kopiert werden, obwohl dies manchmal wegoptimiert wird.
///
/// ## Wie kann ich `Copy` implementieren?
///
/// Es gibt zwei Möglichkeiten, `Copy` auf Ihrem Typ zu implementieren.Am einfachsten ist es, `derive` zu verwenden:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Sie können `Copy` und `Clone` auch manuell implementieren:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Es gibt einen kleinen Unterschied zwischen den beiden: Die `derive`-Strategie setzt auch eine `Copy`-Bindung an Typparameter, was nicht immer erwünscht ist.
///
/// ## Was ist der Unterschied zwischen `Copy` und `Clone`?
///
/// Kopien erfolgen implizit, beispielsweise als Teil einer Zuweisung `y = x`.Das Verhalten von `Copy` ist nicht überladbar.Es ist immer eine einfache bitweise Kopie.
///
/// Das Klonen ist eine explizite Aktion, `x.clone()`.Die Implementierung von [`Clone`] kann jedes typspezifische Verhalten bereitstellen, das zum sicheren Duplizieren von Werten erforderlich ist.
/// Beispielsweise muss bei der Implementierung von [`Clone`] für [`String`] der Zeichenfolgenpuffer, auf den verwiesen wird, in den Heap kopiert werden.
/// Eine einfache bitweise Kopie von [`String`]-Werten würde lediglich den Zeiger kopieren, was zu einem doppelten freien Ergebnis auf der ganzen Linie führen würde.
/// Aus diesem Grund ist [`String`] [`Clone`], aber nicht `Copy`.
///
/// [`Clone`] ist ein Supertrait von `Copy`, daher muss alles, was `Copy` ist, auch [`Clone`] implementieren.
/// Wenn ein Typ `Copy` ist, muss seine [`Clone`]-Implementierung nur `*self` zurückgeben (siehe obiges Beispiel).
///
/// ## Wann kann mein Typ `Copy` sein?
///
/// Ein Typ kann `Copy` implementieren, wenn alle seine Komponenten `Copy` implementieren.Diese Struktur kann beispielsweise `Copy` sein:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Eine Struktur kann `Copy` sein und [`i32`] ist `Copy`, daher kann `Point` `Copy` sein.
/// Im Gegensatz dazu betrachten
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Die Struktur `PointList` kann `Copy` nicht implementieren, da [`Vec<T>`] nicht `Copy` ist.Wenn wir versuchen, eine `Copy`-Implementierung abzuleiten, wird eine Fehlermeldung angezeigt:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Gemeinsame Referenzen (`&T`) sind auch `Copy`, daher kann ein Typ `Copy` sein, selbst wenn er gemeinsame Referenzen der Typen `T` enthält, die *nicht*`Copy` sind.
/// Betrachten Sie die folgende Struktur, die `Copy` implementieren kann, da sie nur einen *gemeinsamen Verweis* auf unseren Nicht-Kopiertyp `PointList` von oben enthält:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Wann *kann* mein Typ nicht `Copy` sein?
///
/// Einige Typen können nicht sicher kopiert werden.Wenn Sie beispielsweise `&mut T` kopieren, wird eine veränderbare Alias-Referenz erstellt.
/// Das Kopieren von [`String`] würde die Verantwortung für die Verwaltung des Puffers des [`String`] verdoppeln, was zu einem Double Free führen würde.
///
/// Im letzteren Fall kann jeder Typ, der [`Drop`] implementiert, nicht `Copy` sein, da er neben seinen eigenen [`size_of::<T>`]-Bytes eine Ressource verwaltet.
///
/// Wenn Sie versuchen, `Copy` in einer Struktur oder Enumeration zu implementieren, die Nicht-`Copy`-Daten enthält, wird der Fehler [E0204] angezeigt.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Wann *sollte* mein Typ `Copy` sein?
///
/// Wenn Ihr Typ _can_ `Copy` implementiert, sollte dies im Allgemeinen der Fall sein.
/// Beachten Sie jedoch, dass die Implementierung von `Copy` Teil der öffentlichen API Ihres Typs ist.
/// Wenn der Typ in future möglicherweise nicht "Kopieren" wird, kann es ratsam sein, die `Copy`-Implementierung jetzt wegzulassen, um eine fehlerhafte API-Änderung zu vermeiden.
///
/// ## Zusätzliche Implementierer
///
/// Neben dem [implementors listed below][impls] implementieren die folgenden Typen auch `Copy`:
///
/// * Funktionselementtypen (dh die für jede Funktion definierten unterschiedlichen Typen)
/// * Funktionszeigertypen (z. `fn() -> i32`)
/// * Array-Typen für alle Größen, wenn der Elementtyp auch `Copy` implementiert (z. B. `[i32; 123456]`)
/// * Tupeltypen, wenn jede Komponente auch `Copy` implementiert (z. B. `()`, `(i32, bool)`)
/// * Abschlussarten, wenn sie keinen Wert aus der Umgebung erfassen oder wenn alle erfassten Werte `Copy` selbst implementieren.
///   Beachten Sie, dass Variablen, die von einer gemeinsam genutzten Referenz erfasst werden, immer `Copy` implementieren (auch wenn der Referent dies nicht tut), während Variablen, die von einer veränderlichen Referenz erfasst werden, niemals `Copy` implementieren.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Dies ermöglicht das Kopieren eines Typs, der `Copy` aufgrund nicht erfüllter Lebensdauergrenzen nicht implementiert (Kopieren von `A<'_>`, wenn nur `A<'static>: Copy` und `A<'_>: Clone`).
// Wir haben dieses Attribut hier vorerst nur, weil es in der Standardbibliothek bereits einige Spezialisierungen für `Copy` gibt, und es gibt derzeit keine Möglichkeit, dieses Verhalten sicher zu haben.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Leiten Sie ein Makro ab, das ein Impl des trait `Copy` generiert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typen, für die es sicher ist, Referenzen zwischen Threads zu teilen.
///
/// Dieser trait wird automatisch implementiert, wenn der Compiler feststellt, dass er geeignet ist.
///
/// Die genaue Definition lautet: Ein Typ `T` ist genau dann [`Sync`], wenn `&T` [`Send`] ist.
/// Mit anderen Worten, wenn beim Übergeben von `&T`-Referenzen zwischen Threads keine Möglichkeit für [undefined behavior][ub] (einschließlich Datenrennen) besteht.
///
/// Wie zu erwarten ist, sind primitive Typen wie [`u8`] und [`f64`] alle [`Sync`], ebenso wie einfache Aggregattypen, die sie enthalten, wie Tupel, Strukturen und Aufzählungen.
/// Weitere Beispiele für grundlegende [`Sync`]-Typen sind "immutable"-Typen wie `&T` und solche mit einfacher vererbter Veränderlichkeit wie [`Box<T>`][box], [`Vec<T>`][vec] und die meisten anderen Sammlungstypen.
///
/// (Generische Parameter müssen [`Sync`] sein, damit ihr Container [`Sync`] ist.)
///
/// Eine etwas überraschende Konsequenz der Definition ist, dass `&mut T` `Sync` ist (wenn `T` `Sync` ist), obwohl es so aussieht, als würde dies eine nicht synchronisierte Mutation liefern.
/// Der Trick besteht darin, dass eine veränderbare Referenz hinter einer gemeinsam genutzten Referenz (dh `& &mut T`) schreibgeschützt wird, als wäre es eine `& &T`.
/// Daher besteht kein Risiko für ein Datenrennen.
///
/// Typen, die nicht `Sync` sind, haben "interior mutability" in einer nicht threadsicheren Form, z. B. [`Cell`][cell] und [`RefCell`][refcell].
/// Diese Typen ermöglichen eine Mutation ihres Inhalts selbst durch eine unveränderliche, gemeinsame Referenz.
/// Beispielsweise verwendet die `set`-Methode unter [`Cell<T>`][cell] `&self`, sodass nur eine gemeinsame Referenz [`&Cell<T>`][cell] erforderlich ist.
/// Die Methode führt keine Synchronisation durch, daher kann [`Cell`][cell] nicht `Sync` sein.
///
/// Ein weiteres Beispiel für einen Nicht-Sync-Typ ist der Referenzzählzeiger [`Rc`][rc].
/// Bei jedem Referenz-[`&Rc<T>`][rc] können Sie einen neuen [`Rc<T>`][rc] klonen und die Referenzanzahl nicht atomar ändern.
///
/// Für Fälle, in denen eine thread-sichere innere Mutabilität erforderlich ist, bietet Rust [atomic data types] sowie explizite Sperren über [`sync::Mutex`][mutex] und [`sync::RwLock`][rwlock].
/// Diese Typen stellen sicher, dass keine Mutation Datenrennen verursachen kann. Daher sind die Typen `Sync`.
/// Ebenso bietet [`sync::Arc`][arc] ein thread-sicheres Analogon zu [`Rc`][rc].
///
/// Alle Typen mit innerer Veränderbarkeit müssen auch den [`cell::UnsafeCell`][unsafecell]-Wrapper um den value(s) verwenden, der über eine gemeinsame Referenz mutiert werden kann.
/// Andernfalls ist [undefined behavior][ub].
/// Zum Beispiel ist [`transmute`][transmute]-ing von `&T` nach `&mut T` ungültig.
///
/// Weitere Informationen zu `Sync` finden Sie unter [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): Sobald die Unterstützung für das Hinzufügen von Notizen in `rustc_on_unimplemented` in der Beta landet und erweitert wurde, um zu überprüfen, ob sich ein Abschluss an einer beliebigen Stelle in der Anforderungskette befindet, erweitern Sie ihn als solchen (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Typ mit der Größe Null, der verwendet wird, um Dinge zu markieren, die "act like" besitzen und die `T` besitzen.
///
/// Durch Hinzufügen eines `PhantomData<T>`-Felds zu Ihrem Typ wird dem Compiler mitgeteilt, dass Ihr Typ so verhält, als würde er einen Wert vom Typ `T` speichern, obwohl dies nicht wirklich der Fall ist.
/// Diese Informationen werden bei der Berechnung bestimmter Sicherheitseigenschaften verwendet.
///
/// Eine ausführlichere Erklärung zur Verwendung von `PhantomData<T>` finden Sie unter [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Eine schreckliche Notiz 👻👻👻
///
/// Obwohl beide beängstigende Namen haben, sind `PhantomData`-und Phantomtypen verwandt, aber nicht identisch.Ein Phantomtypparameter ist einfach ein Typparameter, der niemals verwendet wird.
/// In Rust führt dies häufig dazu, dass sich der Compiler beschwert, und die Lösung besteht darin, eine "dummy"-Verwendung über `PhantomData` hinzuzufügen.
///
/// # Examples
///
/// ## Nicht verwendete Lebensdauerparameter
///
/// Der wahrscheinlich häufigste Anwendungsfall für `PhantomData` ist eine Struktur mit einem nicht verwendeten Lebensdauerparameter, normalerweise als Teil eines unsicheren Codes.
/// Hier ist beispielsweise eine Struktur `Slice` mit zwei Zeigern vom Typ `*const T`, die vermutlich irgendwo auf ein Array zeigen:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Die zugrunde liegenden Daten sind nur für die Lebensdauer von `'a` gültig, sodass `Slice` `'a` nicht überleben sollte.
/// Diese Absicht wird jedoch nicht im Code ausgedrückt, da die Lebensdauer von `'a` nicht verwendet wird und daher nicht klar ist, für welche Daten sie gilt.
/// Wir können dies korrigieren, indem wir den Compiler anweisen,*so zu handeln, als ob* die `Slice`-Struktur eine Referenz `&'a T` enthält:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Dies erfordert wiederum die Anmerkung `T: 'a`, die angibt, dass alle Referenzen in `T` über die Lebensdauer von `'a` gültig sind.
///
/// Bei der Initialisierung eines `Slice` geben Sie einfach den Wert `PhantomData` für das Feld `phantom` ein:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nicht verwendete Typparameter
///
/// Es kommt manchmal vor, dass Sie nicht verwendete Typparameter haben, die angeben, für welchen Datentyp eine Struktur "tied" ist, obwohl diese Daten nicht tatsächlich in der Struktur selbst gefunden werden.
/// Hier ist ein Beispiel, wo dies bei [FFI] auftritt.
/// Die Fremdschnittstelle verwendet Handles vom Typ `*mut ()`, um auf Rust-Werte verschiedener Typen zu verweisen.
/// Wir verfolgen den Typ Rust mithilfe eines Phantomtyp-Parameters in der Struktur `ExternalResource`, der ein Handle umschließt.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Eigentum und Drop Check
///
/// Das Hinzufügen eines Felds vom Typ `PhantomData<T>` zeigt an, dass Ihr Typ Daten vom Typ `T` besitzt.Dies bedeutet wiederum, dass beim Löschen Ihres Typs möglicherweise eine oder mehrere Instanzen des Typs `T` gelöscht werden.
/// Dies hat Einfluss auf die [drop check]-Analyse des Rust-Compilers.
///
/// Wenn Ihre Struktur die Daten vom Typ `T` tatsächlich nicht *besitzt*, ist es besser, einen Referenztyp wie `PhantomData<&'a T>` (ideally) oder `PhantomData<*const T>` zu verwenden (wenn keine Lebensdauer gilt), um keinen Besitz anzuzeigen.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-internes trait zur Angabe der Art der Enum-Diskriminanten.
///
/// Dieser trait wird automatisch für jeden Typ implementiert und fügt [`mem::Discriminant`] keine Garantien hinzu.
/// Es ist **undefiniertes Verhalten**, zwischen `DiscriminantKind::Discriminant` und `mem::Discriminant` zu wechseln.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Der Typ der Diskriminante, der die von `mem::Discriminant` geforderten trait bounds erfüllen muss.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-internes trait wird verwendet, um zu bestimmen, ob ein Typ intern `UnsafeCell` enthält, jedoch nicht durch eine Indirektion.
///
/// Dies wirkt sich beispielsweise darauf aus, ob ein `static` dieses Typs im statischen Nur-Lese-Speicher oder im beschreibbaren statischen Speicher abgelegt wird.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typen, die nach dem Fixieren sicher verschoben werden können.
///
/// Rust selbst kennt keine unbeweglichen Typen und betrachtet Bewegungen (z. B. durch Zuweisung oder [`mem::replace`]) immer als sicher.
///
/// Der Typ [`Pin`][Pin] wird stattdessen verwendet, um Bewegungen durch das Typsystem zu verhindern.Zeiger `P<T>`, die in den [`Pin<P<T>>`][Pin]-Wrapper eingeschlossen sind, können nicht verschoben werden.
/// Weitere Informationen zum Fixieren finden Sie in der [`pin` module]-Dokumentation.
///
/// Durch die Implementierung des `Unpin` trait für `T` werden die Einschränkungen beim Anheften des Typs aufgehoben, sodass `T` mit Funktionen wie [`mem::replace`] aus [`Pin<P<T>>`][Pin] verschoben werden kann.
///
///
/// `Unpin` hat für nicht fixierte Daten überhaupt keine Konsequenz.
/// Insbesondere verschiebt [`mem::replace`] `!Unpin`-Daten problemlos (es funktioniert für jedes `&mut T`, nicht nur für `T: Unpin`).
/// Sie können [`mem::replace`] jedoch nicht für Daten verwenden, die in einem [`Pin<P<T>>`][Pin] eingeschlossen sind, da Sie nicht das `&mut T` erhalten können, das Sie dafür benötigen, und *das* macht dieses System funktionsfähig.
///
/// Dies ist beispielsweise nur bei Typen möglich, die `Unpin` implementieren:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Wir benötigen eine veränderbare Referenz, um `mem::replace` aufzurufen.
/// // Wir können eine solche Referenz erhalten, indem (implicitly) `Pin::deref_mut` aufruft, aber das ist nur möglich, weil `String` `Unpin` implementiert.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Dieser trait wird für fast jeden Typ automatisch implementiert.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Ein Markertyp, der `Unpin` nicht implementiert.
///
/// Wenn ein Typ ein `PhantomPinned` enthält, wird `Unpin` standardmäßig nicht implementiert.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementierungen von `Copy` für primitive Typen.
///
/// Implementierungen, die in Rust nicht beschrieben werden können, sind in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection` implementiert.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Freigegebene Referenzen können kopiert werden, veränderbare Referenzen jedoch nicht *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}