#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Enthält Strukturdefinitionen für das Layout der integrierten Compilertypen.
//!
//! Sie können als Ziele für Transmutationen in unsicherem Code verwendet werden, um die Rohdarstellungen direkt zu manipulieren.
//!
//!
//! Ihre Definition sollte immer mit dem in `rustc_middle::ty::layout` definierten ABI übereinstimmen.
//!

/// Die Darstellung eines trait-Objekts wie `&dyn SomeTrait`.
///
/// Diese Struktur hat das gleiche Layout wie Typen wie `&dyn SomeTrait` und `Box<dyn AnotherTrait>`.
///
/// `TraitObject` Es wird garantiert, dass sie mit Layouts übereinstimmen, es handelt sich jedoch nicht um den Typ von trait-Objekten (z. B. sind die Felder auf einem `&dyn SomeTrait` nicht direkt zugänglich), und es wird auch nicht das Layout gesteuert (durch Ändern der Definition wird das Layout eines `&dyn SomeTrait` nicht geändert).
///
/// Es ist nur für die Verwendung durch unsicheren Code vorgesehen, der die Details auf niedriger Ebene bearbeiten muss.
///
/// Es gibt keine Möglichkeit, generisch auf alle trait-Objekte zu verweisen. Die einzige Möglichkeit, Werte dieses Typs zu erstellen, besteht in Funktionen wie [`std::mem::transmute`][transmute].
/// Ebenso ist die einzige Möglichkeit, ein echtes trait-Objekt aus einem `TraitObject`-Wert zu erstellen, `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Die Synthese eines trait-Objekts mit nicht übereinstimmenden Typen-einer, bei der die vtable nicht dem Typ des Werts entspricht, auf den der Datenzeiger zeigt-führt höchstwahrscheinlich zu undefiniertem Verhalten.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ein Beispiel trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // Lassen Sie den Compiler ein trait-Objekt erstellen
/// let object: &dyn Foo = &value;
///
/// // Schauen Sie sich die Rohdarstellung an
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // Der Datenzeiger ist die Adresse von `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // Erstellen Sie ein neues Objekt, das auf ein anderes `i32` zeigt, und achten Sie darauf, die `i32`-vtable von `object` zu verwenden
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // Es sollte so funktionieren, als hätten wir ein trait-Objekt direkt aus `other_value` erstellt
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}