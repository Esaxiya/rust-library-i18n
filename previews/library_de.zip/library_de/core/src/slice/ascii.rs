//! Operationen auf ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Überprüft, ob alle Bytes in diesem Slice innerhalb des ASCII-Bereichs liegen.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Überprüft, ob zwei Slices eine Übereinstimmung zwischen ASCII-Groß-und Kleinschreibung sind.
    ///
    /// Wie `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, jedoch ohne Zuweisen und Kopieren von Provisorien.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konvertiert dieses Slice direkt in sein ASCII-Großbuchstabenäquivalent.
    ///
    /// ASCII-Buchstaben 'a' bis 'z' werden 'A' bis 'Z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`to_ascii_uppercase`], um einen neuen Wert in Großbuchstaben zurückzugeben, ohne den vorhandenen zu ändern.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konvertiert dieses Slice direkt in sein ASCII-Kleinbuchstabenäquivalent.
    ///
    /// ASCII-Buchstaben 'A' bis 'Z' werden 'a' bis 'z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`to_ascii_lowercase`], um einen neuen Wert in Kleinbuchstaben zurückzugeben, ohne den vorhandenen zu ändern.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Gibt `true` zurück, wenn ein Byte im Wort `v` nonascii ist (>=128).
/// Snarfed von `../str/mod.rs`, das für die utf8-Validierung etwas Ähnliches tut.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimierter ASCII-Test, bei dem Usize-at-A-Time-Operationen anstelle von Byte-at-A-Time-Operationen verwendet werden (sofern möglich).
///
/// Der Algorithmus, den wir hier verwenden, ist ziemlich einfach.Wenn `s` zu kurz ist, überprüfen wir einfach jedes Byte und sind fertig.Andernfalls:
///
/// - Lesen Sie das erste Wort mit einer nicht ausgerichteten Last.
/// - Richten Sie den Zeiger aus und lesen Sie die nachfolgenden Wörter bis zum Ende mit ausgerichteten Lasten.
/// - Lesen Sie den letzten `usize` von `s` mit einer nicht ausgerichteten Last.
///
/// Wenn eine dieser Lasten etwas erzeugt, für das `contains_nonascii` (above) true zurückgibt, wissen wir, dass die Antwort falsch ist.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Wenn wir von der wortweisen Implementierung nichts profitieren würden, greifen Sie auf eine Skalarschleife zurück.
    //
    // Wir tun dies auch für Architekturen, bei denen `size_of::<usize>()` für `usize` nicht ausreichend ausgerichtet ist, da es sich um einen seltsamen edge-Fall handelt.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Wir lesen immer das erste Wort unausgerichtet, was bedeutet, dass `align_offset` ist
    // 0, wir würden den gleichen Wert für den ausgerichteten Lesevorgang erneut lesen.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SICHERHEIT: Wir überprüfen `len < USIZE_SIZE` oben.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Wir haben dies oben etwas implizit überprüft.
    // Beachten Sie, dass `offset_to_aligned` entweder `align_offset` oder `USIZE_SIZE` ist. Beide sind oben explizit überprüft.
    //
    debug_assert!(offset_to_aligned <= len);

    // SICHERHEIT: word_ptr ist das (richtig ausgerichtete) usize ptr, mit dem wir das lesen
    // mittleres Stück der Scheibe.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ist der Byte-Index von `word_ptr`, der für Schleifenendprüfungen verwendet wird.
    let mut byte_pos = offset_to_aligned;

    // Paranoia prüft die Ausrichtung, da wir eine Reihe nicht ausgerichteter Lasten ausführen werden.
    // In der Praxis sollte dies jedoch unmöglich sein, es sei denn, es liegt ein Fehler in `align_offset` vor.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lesen Sie die nachfolgenden Wörter bis zum zuletzt ausgerichteten Wort, mit Ausnahme des zuletzt ausgerichteten Wortes, das später bei der Schwanzprüfung durchgeführt werden soll, um sicherzustellen, dass der Schwanz immer höchstens ein `usize` bis zu einem zusätzlichen branch `byte_pos == len` ist.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Überprüfen Sie, ob der Lesevorgang in Grenzen liegt
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Und dass unsere Annahmen über `byte_pos` gelten.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SICHERHEIT: Wir wissen, dass `word_ptr` richtig ausgerichtet ist (wegen
        // `align_offset`), und wir wissen, dass wir zwischen `word_ptr` und dem Ende genügend Bytes haben
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SICHERHEIT: Wir kennen das `byte_pos <= len - USIZE_SIZE`, was das bedeutet
        // Nach diesem `add` wird `word_ptr` höchstens ein Ende haben.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity Check, um sicherzustellen, dass wirklich nur noch ein `usize` übrig ist.
    // Dies sollte durch unsere Schleifenbedingung gewährleistet sein.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SICHERHEIT: Dies hängt von `len >= USIZE_SIZE` ab, das wir zu Beginn überprüfen.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}