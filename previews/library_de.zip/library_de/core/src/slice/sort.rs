//! Scheibensortierung
//!
//! Dieses Modul enthält einen Sortieralgorithmus, der auf Orson Peters 'Quicksort zur Überwindung von Mustern basiert und veröffentlicht wurde unter: <https://github.com/orlp/pdqsort>
//!
//!
//! Die instabile Sortierung ist mit libcore kompatibel, da im Gegensatz zu unserer stabilen Sortierimplementierung kein Speicher zugewiesen wird.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nach dem Löschen werden Kopien von `src` in `dest` kopiert.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SICHERHEIT: Dies ist eine Hilfsklasse.
        //          Bitte beachten Sie die korrekte Verwendung.
        //          Man muss nämlich sicherstellen, dass sich `src` und `dst` nicht wie von `ptr::copy_nonoverlapping` gefordert überlappen.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Verschiebt das erste Element nach rechts, bis es auf ein größeres oder gleiches Element trifft.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SICHERHEIT: Die folgenden unsicheren Vorgänge umfassen die Indizierung ohne gebundene Prüfung (`get_unchecked` und `get_unchecked_mut`).
    // und Kopieren des Speichers (`ptr::copy_nonoverlapping`).
    //
    // ein.Indizierung:
    //  1. Wir haben die Größe des Arrays auf>=2 überprüft.
    //  2. Die gesamte Indizierung, die wir durchführen werden, erfolgt höchstens zwischen {0 <= index < len}.
    //
    // b.Kopieren des Speichers
    //  1. Wir erhalten Hinweise auf Referenzen, deren Gültigkeit garantiert ist.
    //  2. Sie können sich nicht überlappen, da wir Zeiger auf Differenzindizes des Slice erhalten.
    //     Nämlich `i` und `i-1`.
    //  3. Wenn das Slice richtig ausgerichtet ist, sind die Elemente richtig ausgerichtet.
    //     Es liegt in der Verantwortung des Anrufers, sicherzustellen, dass das Slice richtig ausgerichtet ist.
    //
    // Siehe Kommentare unten für weitere Details.
    unsafe {
        // Wenn die ersten beiden Elemente nicht in Ordnung sind ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lesen Sie das erste Element in eine vom Stapel zugewiesene Variable.
            // Wenn eine folgende Vergleichsoperation panics ausgeführt wird, wird `hole` gelöscht und das Element wird automatisch in das Slice zurückgeschrieben.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Bewegen Sie das i-te Element um eine Stelle nach links und verschieben Sie so das Loch nach rechts.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` wird fallen gelassen und kopiert somit `tmp` in das verbleibende Loch in `v`.
        }
    }
}

/// Verschiebt das letzte Element nach links, bis es auf ein kleineres oder gleiches Element trifft.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SICHERHEIT: Die folgenden unsicheren Vorgänge umfassen die Indizierung ohne gebundene Prüfung (`get_unchecked` und `get_unchecked_mut`).
    // und Kopieren des Speichers (`ptr::copy_nonoverlapping`).
    //
    // ein.Indizierung:
    //  1. Wir haben die Größe des Arrays auf>=2 überprüft.
    //  2. Die gesamte Indizierung, die wir durchführen werden, erfolgt höchstens zwischen `0 <= index < len-1`.
    //
    // b.Kopieren des Speichers
    //  1. Wir erhalten Hinweise auf Referenzen, deren Gültigkeit garantiert ist.
    //  2. Sie können sich nicht überlappen, da wir Zeiger auf Differenzindizes des Slice erhalten.
    //     Nämlich `i` und `i+1`.
    //  3. Wenn das Slice richtig ausgerichtet ist, sind die Elemente richtig ausgerichtet.
    //     Es liegt in der Verantwortung des Anrufers, sicherzustellen, dass das Slice richtig ausgerichtet ist.
    //
    // Siehe Kommentare unten für weitere Details.
    unsafe {
        // Wenn die letzten beiden Elemente nicht in Ordnung sind ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lesen Sie das letzte Element in eine vom Stapel zugewiesene Variable.
            // Wenn eine folgende Vergleichsoperation panics ausgeführt wird, wird `hole` gelöscht und das Element wird automatisch in das Slice zurückgeschrieben.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Bewegen Sie das i-te Element um eine Stelle nach rechts und verschieben Sie so das Loch nach links.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` wird fallen gelassen und kopiert somit `tmp` in das verbleibende Loch in `v`.
        }
    }
}

/// Sortiert ein Slice teilweise, indem mehrere Elemente außerhalb der Reihenfolge verschoben werden.
///
/// Gibt `true` zurück, wenn das Slice am Ende sortiert ist.Diese Funktion ist im schlimmsten Fall *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maximale Anzahl benachbarter Paare außerhalb der Reihenfolge, die verschoben werden.
    const MAX_STEPS: usize = 5;
    // Wenn das Slice kürzer ist, verschieben Sie keine Elemente.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SICHERHEIT: Wir haben die gebundene Prüfung bereits explizit mit `i < len` durchgeführt.
        // Alle unsere nachfolgenden Indizierungen liegen nur im Bereich `0 <= index < len`
        unsafe {
            // Suchen Sie das nächste Paar benachbarter Elemente außerhalb der Reihenfolge.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Sind wir fertig?
        if i == len {
            return true;
        }

        // Verschieben Sie keine Elemente auf kurzen Arrays, da dies Leistungskosten verursacht.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Tauschen Sie das gefundene Elementpaar aus.Dies bringt sie in die richtige Reihenfolge.
        v.swap(i - 1, i);

        // Verschieben Sie das kleinere Element nach links.
        shift_tail(&mut v[..i], is_less);
        // Verschieben Sie das größere Element nach rechts.
        shift_head(&mut v[i..], is_less);
    }

    // Es ist mir nicht gelungen, das Slice in der begrenzten Anzahl von Schritten zu sortieren.
    false
}

/// Sortiert ein Slice mithilfe der Einfügesortierung, was im schlimmsten Fall *O*(*n*^ 2) ist.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sortiert `v` mithilfe von Heapsort, wodurch *O*(*n*\*log(* n*)) Worst-Case) garantiert wird.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Dieser binäre Heap respektiert die invariante `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Kinder von `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Wähle das größere Kind.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stoppen Sie, wenn die Invariante bei `node` gilt.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Tauschen Sie `node` mit dem größeren Kind aus, gehen Sie einen Schritt nach unten und sichten Sie weiter.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Erstellen Sie den Heap in linearer Zeit.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximale Elemente aus dem Haufen.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partitioniert `v` in Elemente, die kleiner als `pivot` sind, gefolgt von Elementen, die größer oder gleich `pivot` sind.
///
///
/// Gibt die Anzahl der Elemente zurück, die kleiner als `pivot` sind.
///
/// Die Partitionierung wird blockweise durchgeführt, um die Kosten für Verzweigungsvorgänge zu minimieren.
/// Diese Idee wird im [BlockQuicksort][pdf]-Papier vorgestellt.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Anzahl der Elemente in einem typischen Block.
    const BLOCK: usize = 128;

    // Der Partitionierungsalgorithmus wiederholt die folgenden Schritte bis zum Abschluss:
    //
    // 1. Verfolgen Sie einen Block von der linken Seite, um Elemente zu identifizieren, die größer oder gleich dem Drehpunkt sind.
    // 2. Verfolgen Sie einen Block von der rechten Seite, um Elemente zu identifizieren, die kleiner als der Drehpunkt sind.
    // 3. Tauschen Sie die identifizierten Elemente zwischen der linken und rechten Seite aus.
    //
    // Wir behalten die folgenden Variablen für einen Elementblock bei:
    //
    // 1. `block` - Anzahl der Elemente im Block.
    // 2. `start` - Starten Sie den Zeiger in das `offsets`-Array.
    // 3. `end` - Beenden Sie den Zeiger in das `offsets`-Array.
    // 4. `Offsets, Indizes von Elementen außerhalb der Reihenfolge innerhalb des Blocks.

    // Der aktuelle Block auf der linken Seite (von `l` bis `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Der aktuelle Block auf der rechten Seite (von `r.sub(block_r)` to `r`).
    // SICHERHEIT: In der Dokumentation zu .add() wird ausdrücklich erwähnt, dass `vec.as_ptr().add(vec.len())` immer sicher ist
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Wenn wir VLAs erhalten, versuchen Sie lieber, ein Array mit der Länge `min(v.len(), 2 * BLOCK) `zu erstellen
    // als zwei Arrays mit fester Größe der Länge `BLOCK`.VLAs sind möglicherweise cacheeffizienter.

    // Gibt die Anzahl der Elemente zwischen den Zeigern `l` (inclusive) und `r` (exclusive) zurück.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Wir sind mit der Block-für-Block-Partitionierung fertig, wenn `l` und `r` sehr nahe kommen.
        // Dann machen wir einige Patch-Up-Arbeiten, um die verbleibenden Elemente dazwischen zu partitionieren.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Anzahl der verbleibenden Elemente (immer noch nicht mit dem Drehpunkt verglichen).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Passen Sie die Blockgrößen so an, dass sich der linke und der rechte Block nicht überlappen, sondern perfekt ausgerichtet sind, um die gesamte verbleibende Lücke abzudecken.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Verfolgen Sie `block_l`-Elemente von der linken Seite.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SICHERHEIT: Die folgenden Sicherheitsvorkehrungen betreffen die Verwendung des `offset`.
                //         Entsprechend den von der Funktion geforderten Bedingungen erfüllen wir sie, weil:
                //         1. `offsets_l` wird stapelweise zugewiesen und somit als separat zugewiesenes Objekt betrachtet.
                //         2. Die Funktion `is_less` gibt einen `bool` zurück.
                //            Beim Casting eines `bool` wird `isize` niemals überlaufen.
                //         3. Wir haben garantiert, dass `block_l` `<= BLOCK` sein wird.
                //            Außerdem wurde `end_l` ursprünglich auf den Anfangszeiger von `offsets_` gesetzt, der auf dem Stapel deklariert wurde.
                //            Somit wissen wir, dass wir selbst im schlimmsten Fall (alle Aufrufe von `is_less` geben false zurück) höchstens 1 Byte am Ende passieren werden.
                //        Ein weiterer unsicherer Vorgang ist die Dereferenzierung von `elem`.
                //        `elem` war jedoch anfangs der Anfangszeiger auf das Slice, das immer gültig ist.
                unsafe {
                    // Verzweigungsloser Vergleich.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Verfolgen Sie `block_r`-Elemente von der rechten Seite.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SICHERHEIT: Die folgenden Sicherheitsvorkehrungen betreffen die Verwendung des `offset`.
                //         Entsprechend den von der Funktion geforderten Bedingungen erfüllen wir sie, weil:
                //         1. `offsets_r` wird stapelweise zugewiesen und somit als separat zugewiesenes Objekt betrachtet.
                //         2. Die Funktion `is_less` gibt einen `bool` zurück.
                //            Beim Casting eines `bool` wird `isize` niemals überlaufen.
                //         3. Wir haben garantiert, dass `block_r` `<= BLOCK` sein wird.
                //            Außerdem wurde `end_r` ursprünglich auf den Anfangszeiger von `offsets_` gesetzt, der auf dem Stapel deklariert wurde.
                //            Somit wissen wir, dass wir selbst im schlimmsten Fall (alle Aufrufe von `is_less` geben true zurück) höchstens 1 Byte am Ende passieren werden.
                //        Ein weiterer unsicherer Vorgang ist die Dereferenzierung von `elem`.
                //        `elem` war jedoch anfangs `1 *sizeof(T)` nach dem Ende und wir dekrementieren es um `1* sizeof(T)`, bevor wir darauf zugreifen.
                //        Außerdem wurde behauptet, dass `block_r` kleiner als `BLOCK` ist und `elem` daher höchstens auf den Anfang des Slice zeigt.
                unsafe {
                    // Verzweigungsloser Vergleich.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Anzahl der Elemente außerhalb der Reihenfolge, die zwischen der linken und der rechten Seite ausgetauscht werden sollen.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Anstatt jeweils ein Paar zu tauschen, ist es effizienter, eine zyklische Permutation durchzuführen.
            // Dies ist nicht unbedingt gleichbedeutend mit dem Auslagern, führt jedoch zu einem ähnlichen Ergebnis mit weniger Speicheroperationen.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Alle außer Betrieb befindlichen Elemente im linken Block wurden verschoben.Gehen Sie zum nächsten Block.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Alle außer Betrieb befindlichen Elemente im rechten Block wurden verschoben.Wechseln Sie zum vorherigen Block.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Jetzt bleibt höchstens ein Block (entweder links oder rechts) mit Elementen außerhalb der Reihenfolge, die verschoben werden müssen.
    // Solche verbleibenden Elemente können einfach innerhalb ihres Blocks bis zum Ende verschoben werden.
    //

    if start_l < end_l {
        // Der linke Block bleibt.
        // Verschieben Sie die verbleibenden nicht in der richtigen Reihenfolge befindlichen Elemente ganz nach rechts.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Der rechte Block bleibt.
        // Verschieben Sie die verbleibenden nicht in der richtigen Reihenfolge befindlichen Elemente ganz nach links.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Sonst nichts zu tun, wir sind fertig.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitioniert `v` in Elemente, die kleiner als `v[pivot]` sind, gefolgt von Elementen, die größer oder gleich `v[pivot]` sind.
///
///
/// Gibt ein Tupel von zurück:
///
/// 1. Anzahl der Elemente kleiner als `v[pivot]`.
/// 2. True, wenn `v` bereits partitioniert war.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Platzieren Sie den Drehpunkt am Anfang der Scheibe.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lesen Sie den Pivot aus Effizienzgründen in eine vom Stapel zugewiesene Variable.
        // Bei einer folgenden Vergleichsoperation panics wird der Pivot automatisch in das Slice zurückgeschrieben.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Suchen Sie das erste Paar von Elementen, die nicht in der richtigen Reihenfolge sind.
        let mut l = 0;
        let mut r = v.len();

        // SICHERHEIT: Die folgende Unsicherheit beinhaltet die Indizierung eines Arrays.
        // Zum ersten: Wir überprüfen hier bereits die Grenzen mit `l < r`.
        // Zum zweiten: Wir haben anfangs `l == 0` und `r == v.len()` und haben `l < r` bei jeder Indizierungsoperation überprüft.
        //                     Von hier aus wissen wir, dass `r` mindestens `r == l` sein muss, was vom ersten an als gültig erwiesen wurde.
        unsafe {
            // Suchen Sie das erste Element, das größer oder gleich dem Drehpunkt ist.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Suchen Sie das letzte Element, das kleiner als der Drehpunkt ist.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` Verlässt den Gültigkeitsbereich und schreibt den Pivot (eine vom Stapel zugewiesene Variable) zurück in das Slice, in dem er ursprünglich war.
        // Dieser Schritt ist entscheidend für die Sicherheit!
        //
    };

    // Platzieren Sie den Drehpunkt zwischen den beiden Partitionen.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partitioniert `v` in Elemente, die `v[pivot]` entsprechen, gefolgt von Elementen, die größer als `v[pivot]` sind.
///
/// Gibt die Anzahl der Elemente zurück, die dem Pivot entsprechen.
/// Es wird angenommen, dass `v` keine Elemente enthält, die kleiner als der Drehpunkt sind.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Platzieren Sie den Drehpunkt am Anfang der Scheibe.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lesen Sie den Pivot aus Effizienzgründen in eine vom Stapel zugewiesene Variable.
    // Bei einer folgenden Vergleichsoperation panics wird der Pivot automatisch in das Slice zurückgeschrieben.
    // SICHERHEIT: Der Zeiger hier ist gültig, da er aus einer Referenz auf ein Slice erhalten wird.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Partitionieren Sie nun das Slice.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SICHERHEIT: Die folgende Unsicherheit beinhaltet die Indizierung eines Arrays.
        // Zum ersten: Wir überprüfen hier bereits die Grenzen mit `l < r`.
        // Zum zweiten: Wir haben anfangs `l == 0` und `r == v.len()` und haben `l < r` bei jeder Indizierungsoperation überprüft.
        //                     Von hier aus wissen wir, dass `r` mindestens `r == l` sein muss, was vom ersten an als gültig erwiesen wurde.
        unsafe {
            // Suchen Sie das erste Element, das größer als der Drehpunkt ist.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Suchen Sie das letzte Element, das dem Drehpunkt entspricht.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Sind wir fertig?
            if l >= r {
                break;
            }

            // Tauschen Sie das gefundene Paar nicht in der richtigen Reihenfolge befindlicher Elemente aus.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Wir haben `l`-Elemente gefunden, die dem Drehpunkt entsprechen.Fügen Sie 1 hinzu, um den Pivot selbst zu berücksichtigen.
    l + 1

    // `_pivot_guard` Verlässt den Gültigkeitsbereich und schreibt den Pivot (eine vom Stapel zugewiesene Variable) zurück in das Slice, in dem er ursprünglich war.
    // Dieser Schritt ist entscheidend für die Sicherheit!
}

/// Streut einige Elemente herum, um Muster zu brechen, die zu unausgeglichenen Partitionen in Quicksort führen können.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudozufallszahlengenerator aus dem "Xorshift RNGs"-Papier von George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Nehmen Sie Zufallszahlen modulo diese Zahl.
        // Die Zahl passt in `usize`, da `len` nicht größer als `isize::MAX` ist.
        let modulus = len.next_power_of_two();

        // Einige Pivot-Kandidaten befinden sich in der Nähe dieses Index.Lassen Sie uns sie randomisieren.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generieren Sie eine Zufallszahl modulo `len`.
            // Um jedoch kostspielige Operationen zu vermeiden, nehmen wir zunächst eine Zweierpotenz modulo und verringern sie dann um `len`, bis sie in den Bereich `[0, len - 1]` passt.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ist garantiert kleiner als `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Wählt einen Pivot in `v` und gibt den Index und `true` zurück, wenn das Slice wahrscheinlich bereits sortiert ist.
///
/// Elemente in `v` werden dabei möglicherweise neu angeordnet.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mindestlänge für die Auswahl der Median-of-Medians-Methode.
    // Kürzere Schnitte verwenden die einfache Median-of-Three-Methode.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maximale Anzahl von Swaps, die in dieser Funktion ausgeführt werden können.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Drei Indizes, in deren Nähe wir einen Pivot wählen werden.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Zählt die Gesamtzahl der Swaps, die wir beim Sortieren von Indizes durchführen werden.
    let mut swaps = 0;

    if len >= 8 {
        // Tauscht Indizes so, dass `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Tauscht Indizes so, dass `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Findet den Median von `v[a - 1], v[a], v[a + 1]` und speichert den Index in `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Finden Sie Mediane in den Stadtteilen `a`, `b` und `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Finden Sie den Median zwischen `a`, `b` und `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Die maximale Anzahl von Swaps wurde durchgeführt.
        // Es besteht die Möglichkeit, dass das Slice absteigend oder größtenteils absteigend ist. Durch das Umkehren wird es wahrscheinlich schneller sortiert.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sortiert `v` rekursiv.
///
/// Wenn das Slice einen Vorgänger im ursprünglichen Array hatte, wird es als `pred` angegeben.
///
/// `limit` ist die Anzahl der zulässigen unausgeglichenen Partitionen vor dem Wechsel zu `heapsort`.
/// Bei Null wird diese Funktion sofort auf Heapsort umgeschaltet.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Scheiben bis zu dieser Länge werden mithilfe der Einfügesortierung sortiert.
    const MAX_INSERTION: usize = 20;

    // Richtig, wenn die letzte Partitionierung einigermaßen ausgeglichen war.
    let mut was_balanced = true;
    // True, wenn bei der letzten Partitionierung keine Elemente gemischt wurden (das Slice war bereits partitioniert).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Sehr kurze Scheiben werden mit der Einfügesortierung sortiert.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Wenn zu viele schlechte Pivot-Entscheidungen getroffen wurden, greifen Sie einfach auf Heapsort zurück, um den `O(n * log(n))`-Worst-Case zu garantieren.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Wenn die letzte Partitionierung nicht ausgeglichen war, versuchen Sie, Muster im Slice zu brechen, indem Sie einige Elemente mischen.
        // Hoffentlich wählen wir diesmal einen besseren Pivot.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Wählen Sie einen Pivot und versuchen Sie zu erraten, ob das Slice bereits sortiert ist.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Wenn die letzte Partitionierung anständig ausgeglichen war und keine Elemente gemischt hat und wenn die Pivot-Auswahl vorhersagt, dass das Slice wahrscheinlich bereits sortiert ist ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Versuchen Sie, mehrere nicht in der richtigen Reihenfolge befindliche Elemente zu identifizieren und an die richtigen Positionen zu verschieben.
            // Wenn das Slice vollständig sortiert ist, sind wir fertig.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Wenn der gewählte Drehpunkt dem Vorgänger entspricht, ist er das kleinste Element im Slice.
        // Partitionieren Sie das Slice in Elemente, die gleich und größer als der Drehpunkt sind.
        // Dieser Fall wird normalerweise getroffen, wenn das Slice viele doppelte Elemente enthält.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Sortieren Sie weiterhin Elemente, die größer als der Drehpunkt sind.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Partitionieren Sie die Scheibe.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Teilen Sie das Slice in `left`, `pivot` und `right` auf.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Kehren Sie nur auf die kürzere Seite zurück, um die Gesamtzahl der rekursiven Aufrufe zu minimieren und weniger Stapelspeicherplatz zu verbrauchen.
        // Fahren Sie dann einfach mit der längeren Seite fort (dies entspricht einer Schwanzrekursion).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sortiert `v` mit mustersicherem Quicksort, was *O*(*n*\*log(* n*)) Worst-Case) ist.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Das Sortieren hat bei Typen mit der Größe Null kein aussagekräftiges Verhalten.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Begrenzen Sie die Anzahl der nicht ausgeglichenen Partitionen auf `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Bei Scheiben bis zu dieser Länge ist es wahrscheinlich schneller, sie einfach zu sortieren.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Wählen Sie einen Drehpunkt
        let (pivot, _) = choose_pivot(v, is_less);

        // Wenn der gewählte Drehpunkt dem Vorgänger entspricht, ist er das kleinste Element im Slice.
        // Partitionieren Sie das Slice in Elemente, die gleich und größer als der Drehpunkt sind.
        // Dieser Fall wird normalerweise getroffen, wenn das Slice viele doppelte Elemente enthält.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Wenn wir unseren Index bestanden haben, sind wir gut.
                if mid > index {
                    return;
                }

                // Andernfalls sortieren Sie weiterhin Elemente, die größer als der Drehpunkt sind.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Teilen Sie das Slice in `left`, `pivot` und `right` auf.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Wenn mid==index, dann sind wir fertig, da partition() garantiert hat, dass alle Elemente nach mid größer oder gleich mid sind.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Das Sortieren hat bei Typen mit der Größe Null kein aussagekräftiges Verhalten.Nichts tun.
    } else if index == v.len() - 1 {
        // Suchen Sie das max-Element und platzieren Sie es an der letzten Position des Arrays.
        // Es steht uns frei, `unwrap()` hier zu verwenden, da wir wissen, dass v nicht leer sein darf.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Suchen Sie das min-Element und platzieren Sie es an der ersten Position des Arrays.
        // Es steht uns frei, `unwrap()` hier zu verwenden, da wir wissen, dass v nicht leer sein darf.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}