// ignore-tidy-filelength

//! Slice Management und Manipulation.
//!
//! Weitere Details finden Sie unter [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Reine rust-Memchr-Implementierung, entnommen aus rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Diese Funktion ist nur öffentlich, weil es keine andere Möglichkeit gibt, Heapsort zu testen.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Gibt die Anzahl der Elemente im Slice zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SICHERHEIT: const sound, weil wir das Längenfeld als usize umwandeln (was es sein muss)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SICHERHEIT: Dies ist sicher, da `&[T]` und `FatPtr<T>` das gleiche Layout haben.
            // Nur `std` kann diese Garantie übernehmen.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Durch `crate::ptr::metadata(self)` ersetzen, wenn dies stabil ist.
            // Zum jetzigen Zeitpunkt verursacht dies einen "Const-stable functions can only call other const-stable functions"-Fehler.
            //

            // SICHERHEIT: Der Zugriff auf den Wert über die `PtrRepr`-Union ist sicher, da * const T.
            // und PtrComponents<T>haben die gleichen Speicherlayouts.
            // Nur std kann diese Garantie übernehmen.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Gibt `true` zurück, wenn das Slice eine Länge von 0 hat.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Gibt das erste Element des Slice zurück oder `None`, wenn es leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Gibt einen veränderlichen Zeiger auf das erste Element des Slice zurück oder `None`, wenn es leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Gibt das erste und alle übrigen Elemente des Slice zurück oder `None`, wenn es leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Gibt das erste und alle übrigen Elemente des Slice zurück oder `None`, wenn es leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Gibt das letzte und alle übrigen Elemente des Slice zurück oder `None`, wenn es leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Gibt das letzte und alle übrigen Elemente des Slice zurück oder `None`, wenn es leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Gibt das letzte Element des Slice zurück oder `None`, wenn es leer ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Gibt einen veränderlichen Zeiger auf das letzte Element im Slice zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Gibt je nach Indextyp einen Verweis auf ein Element oder eine Unterschicht zurück.
    ///
    /// - Wenn eine Position angegeben ist, wird ein Verweis auf das Element an dieser Position oder `None` zurückgegeben, wenn diese außerhalb der Grenzen liegt.
    ///
    /// - Wenn ein Bereich angegeben ist, wird die diesem Bereich entsprechende Unterscheibe oder `None` zurückgegeben, wenn sie außerhalb der Grenzen liegt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Gibt abhängig vom Indextyp (siehe [`get`]) oder `None` einen veränderlichen Verweis auf ein Element oder eine Untergruppe zurück, wenn der Index außerhalb der Grenzen liegt.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Gibt einen Verweis auf ein Element oder eine Untergruppe zurück, ohne die Grenzen zu überprüfen.
    ///
    /// Eine sichere Alternative finden Sie unter [`get`].
    ///
    /// # Safety
    ///
    /// Das Aufrufen dieser Methode mit einem Out-of-Bound-Index ist *[undefiniertes Verhalten]*, auch wenn die resultierende Referenz nicht verwendet wird.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SICHERHEIT: Der Anrufer muss die meisten Sicherheitsanforderungen für `get_unchecked` erfüllen.
        // Das Slice ist dereferenzierbar, da `self` eine sichere Referenz ist.
        // Der zurückgegebene Zeiger ist sicher, da Impls von `SliceIndex` dies sicherstellen müssen.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Gibt einen veränderlichen Verweis auf ein Element oder eine Unterscheibe zurück, ohne die Grenzen zu überprüfen.
    ///
    /// Eine sichere Alternative finden Sie unter [`get_mut`].
    ///
    /// # Safety
    ///
    /// Das Aufrufen dieser Methode mit einem Out-of-Bound-Index ist *[undefiniertes Verhalten]*, auch wenn die resultierende Referenz nicht verwendet wird.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SICHERHEIT: Der Anrufer muss die Sicherheitsanforderungen für `get_unchecked_mut` einhalten.
        // Das Slice ist dereferenzierbar, da `self` eine sichere Referenz ist.
        // Der zurückgegebene Zeiger ist sicher, da Impls von `SliceIndex` dies sicherstellen müssen.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Gibt einen Rohzeiger auf den Puffer des Slice zurück.
    ///
    /// Der Aufrufer muss sicherstellen, dass das Slice den Zeiger überlebt, den diese Funktion zurückgibt. Andernfalls zeigt es auf Müll.
    ///
    /// Der Aufrufer muss außerdem sicherstellen, dass der Speicher, auf den der Zeiger (non-transitively) zeigt, niemals mit diesem Zeiger oder einem von ihm abgeleiteten Zeiger in den Speicher geschrieben wird (außer innerhalb eines `UnsafeCell`).
    /// Wenn Sie den Inhalt des Slice mutieren müssen, verwenden Sie [`as_mut_ptr`].
    ///
    /// Das Ändern des Containers, auf den dieses Slice verweist, kann dazu führen, dass sein Puffer neu zugewiesen wird, wodurch auch alle Zeiger auf ihn ungültig werden.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Gibt einen unsicheren veränderbaren Zeiger auf den Puffer des Slice zurück.
    ///
    /// Der Aufrufer muss sicherstellen, dass das Slice den Zeiger überlebt, den diese Funktion zurückgibt. Andernfalls zeigt es auf Müll.
    ///
    /// Das Ändern des Containers, auf den dieses Slice verweist, kann dazu führen, dass sein Puffer neu zugewiesen wird, wodurch auch alle Zeiger auf ihn ungültig werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Gibt die beiden rohen Zeiger zurück, die sich über das Slice erstrecken.
    ///
    /// Der zurückgegebene Bereich ist halb offen, was bedeutet, dass der Endzeiger *eins nach* dem letzten Element des Slice zeigt.
    /// Auf diese Weise wird ein leeres Slice durch zwei gleiche Zeiger dargestellt, und die Differenz zwischen den beiden Zeigern repräsentiert die Größe des Slice.
    ///
    /// In [`as_ptr`] finden Sie Warnungen zur Verwendung dieser Zeiger.Der Endzeiger erfordert besondere Vorsicht, da er nicht auf ein gültiges Element im Slice verweist.
    ///
    /// Diese Funktion ist nützlich für die Interaktion mit fremden Schnittstellen, die zwei Zeiger verwenden, um auf eine Reihe von Elementen im Speicher zu verweisen, wie dies in C++ üblich ist.
    ///
    ///
    /// Es kann auch nützlich sein zu überprüfen, ob ein Zeiger auf ein Element auf ein Element dieses Slice verweist:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SICHERHEIT: Der `add` hier ist sicher, weil:
        //
        //   - Beide Zeiger sind Teil desselben Objekts, da auch das Zeigen direkt hinter dem Objekt zählt.
        //
        //   - Die Größe des Slice ist niemals größer als isize::MAX Bytes, wie hier angegeben:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Es ist kein Umbruch erforderlich, da Slices nicht über das Ende des Adressraums hinausgehen.
        //
        // Siehe die Dokumentation von pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Gibt die zwei unsicheren veränderlichen Zeiger zurück, die sich über das Slice erstrecken.
    ///
    /// Der zurückgegebene Bereich ist halb offen, was bedeutet, dass der Endzeiger *eins nach* dem letzten Element des Slice zeigt.
    /// Auf diese Weise wird ein leeres Slice durch zwei gleiche Zeiger dargestellt, und die Differenz zwischen den beiden Zeigern repräsentiert die Größe des Slice.
    ///
    /// In [`as_mut_ptr`] finden Sie Warnungen zur Verwendung dieser Zeiger.
    /// Der Endzeiger erfordert besondere Vorsicht, da er nicht auf ein gültiges Element im Slice verweist.
    ///
    /// Diese Funktion ist nützlich für die Interaktion mit fremden Schnittstellen, die zwei Zeiger verwenden, um auf eine Reihe von Elementen im Speicher zu verweisen, wie dies in C++ üblich ist.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SICHERHEIT: Siehe as_ptr_range() oben, warum `add` hier sicher ist.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Vertauscht zwei Elemente im Slice.
    ///
    /// # Arguments
    ///
    /// * a, Der Index des ersten Elements
    /// * b, Der Index des zweiten Elements
    ///
    /// # Panics
    ///
    /// Panics, wenn `a` oder `b` außerhalb der Grenzen liegen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Es können nicht zwei veränderbare Kredite von einem vector aufgenommen werden. Verwenden Sie stattdessen Rohzeiger.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SICHERHEIT: `pa` und `pb` wurden aus sicheren veränderlichen Referenzen erstellt und verweisen
        // auf Elemente im Slice und sind daher garantiert gültig und ausgerichtet.
        // Beachten Sie, dass der Zugriff auf die Elemente hinter `a` und `b` aktiviert ist und panic außerhalb der Grenzen ausführt.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Kehrt die Reihenfolge der Elemente im Slice um.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Bei sehr kleinen Typen sind alle einzelnen Lesevorgänge im normalen Pfad schlecht.
        // Bei effizientem, nicht ausgerichtetem load/store können wir es besser machen, indem wir einen größeren Block laden und ein Register umkehren.
        //

        // Im Idealfall würde LLVM dies für uns tun, da es besser als wir weiß, ob nicht ausgerichtete Lesevorgänge effizient sind (da sich dies beispielsweise zwischen verschiedenen ARM-Versionen ändert) und welche Chunk-Größe am besten wäre.
        // Leider wird ab LLVM 4.0 (2017-05) nur die Schleife abgewickelt, sodass wir dies selbst tun müssen.
        // (Hypothese: Die Umkehrung ist problematisch, da die Seiten unterschiedlich ausgerichtet werden können-wenn die Länge ungerade ist-, sodass es keine Möglichkeit gibt, Vor-und Nachspiele auszusenden, um eine vollständig ausgerichtete SIMD in der Mitte zu verwenden.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Verwenden Sie das llvm.bswap-Intrinsic, um U8s in einem Usize umzukehren
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SICHERHEIT: Hier sind einige Dinge zu überprüfen:
                //
                // - Beachten Sie, dass `chunk` aufgrund der obigen CFG-Prüfung entweder 4 oder 8 ist.`chunk - 1` ist also positiv.
                // - Die Indizierung mit dem Index `i` ist in Ordnung, wie die Schleifenprüfung garantiert
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Die Indizierung mit dem Index `ln - i - chunk = ln - (i + chunk)` ist in Ordnung:
                //   - `i + chunk > 0` ist trivial wahr.
                //   - Die Schleifenprüfung garantiert:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, daher läuft die Subtraktion nicht unter.
                // - Die `read_unaligned`-und `write_unaligned`-Aufrufe sind in Ordnung:
                //   - `pa` zeigt auf den Index `i`, wobei `i < ln / 2 - (chunk - 1)` (siehe oben) und `pb` auf den Index `ln - i - chunk` zeigen, sodass beide mindestens `chunk` viele Bytes vom Ende von `self` entfernt sind.
                //
                //   - Jeder initialisierte Speicher ist `usize` gültig.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Verwenden Sie Rotate-by-16, um u16s in einem u32 umzukehren
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SICHERHEIT: Ein nicht ausgerichtetes u32 kann von `i` gelesen werden, wenn `i + 1 < ln`
                // (und natürlich `i < ln`), weil jedes Element 2 Bytes hat und wir 4 lesen.
                //
                // `i + chunk - 1 < ln / 2` # während Zustand
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Da es kleiner als die durch 2 geteilte Länge ist, muss es in Grenzen sein.
                //
                // Dies bedeutet auch, dass die Bedingung `0 < i + chunk <= ln` immer eingehalten wird, um sicherzustellen, dass der `pb`-Zeiger sicher verwendet werden kann.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SICHERHEIT: `i` ist also der halben Länge der Scheibe unterlegen
            // Der Zugriff auf `i` und `ln - i - 1` ist sicher (`i` beginnt bei 0 und geht nicht weiter als `ln / 2 - 1`).
            // Die resultierenden Zeiger `pa` und `pb` sind daher gültig und ausgerichtet und können gelesen und beschrieben werden.
            //
            //
            unsafe {
                // Unsicherer Tausch, um zu vermeiden, dass die Grenzen beim sicheren Tausch überprüft werden.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Gibt einen Iterator über das Slice zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Gibt einen Iterator zurück, mit dem jeder Wert geändert werden kann.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Gibt einen Iterator über alle zusammenhängenden windows der Länge `size` zurück.
    /// Die windows-Überlappung.
    /// Wenn das Slice kürzer als `size` ist, gibt der Iterator keine Werte zurück.
    ///
    /// # Panics
    ///
    /// Panics wenn `size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wenn das Slice kürzer als `size` ist:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Gibt einen Iterator über jeweils `chunk_size`-Elemente des Slice zurück, beginnend am Anfang des Slice.
    ///
    /// Die Stücke sind Scheiben und überlappen sich nicht.Wenn `chunk_size` die Länge des Slice nicht teilt, hat der letzte Block keine Länge `chunk_size`.
    ///
    /// In [`chunks_exact`] finden Sie eine Variante dieses Iterators, die Blöcke von immer genau `chunk_size`-Elementen zurückgibt, und in [`rchunks`] für denselben Iterator, der jedoch am Ende des Slice beginnt.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Gibt einen Iterator über jeweils `chunk_size`-Elemente des Slice zurück, beginnend am Anfang des Slice.
    ///
    /// Die Stücke sind veränderbare Scheiben und überlappen sich nicht.Wenn `chunk_size` die Länge des Slice nicht teilt, hat der letzte Block keine Länge `chunk_size`.
    ///
    /// In [`chunks_exact_mut`] finden Sie eine Variante dieses Iterators, die Blöcke von immer genau `chunk_size`-Elementen zurückgibt, und in [`rchunks_mut`] für denselben Iterator, der jedoch am Ende des Slice beginnt.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Gibt einen Iterator über jeweils `chunk_size`-Elemente des Slice zurück, beginnend am Anfang des Slice.
    ///
    /// Die Stücke sind Scheiben und überlappen sich nicht.
    /// Wenn `chunk_size` die Länge des Slice nicht teilt, werden die letzten bis zu `chunk_size-1`-Elemente weggelassen und können aus der `remainder`-Funktion des Iterators abgerufen werden.
    ///
    ///
    /// Da jeder Block genau `chunk_size`-Elemente enthält, kann der Compiler den resultierenden Code häufig besser optimieren als im Fall von [`chunks`].
    ///
    /// Siehe [`chunks`] für eine Variante dieses Iterators, die auch den Rest als kleineren Block zurückgibt, und [`rchunks_exact`] für denselben Iterator, jedoch beginnend am Ende des Slice.
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Gibt einen Iterator über jeweils `chunk_size`-Elemente des Slice zurück, beginnend am Anfang des Slice.
    ///
    /// Die Stücke sind veränderbare Scheiben und überlappen sich nicht.
    /// Wenn `chunk_size` die Länge des Slice nicht teilt, werden die letzten bis zu `chunk_size-1`-Elemente weggelassen und können aus der `into_remainder`-Funktion des Iterators abgerufen werden.
    ///
    ///
    /// Da jeder Block genau `chunk_size`-Elemente enthält, kann der Compiler den resultierenden Code häufig besser optimieren als im Fall von [`chunks_mut`].
    ///
    /// Siehe [`chunks_mut`] für eine Variante dieses Iterators, die auch den Rest als kleineren Block zurückgibt, und [`rchunks_exact_mut`] für denselben Iterator, jedoch beginnend am Ende des Slice.
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Teilt das Slice in ein Slice von N-Element-Arrays auf, vorausgesetzt, es gibt keinen Rest.
    ///
    ///
    /// # Safety
    ///
    /// Dies darf nur aufgerufen werden, wenn
    /// - Das Slice teilt sich genau in N-Element-Chunks (auch bekannt als `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SICHERHEIT: 1-Element-Chunks haben nie Rest
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SICHERHEIT: Die Schnittlänge (6) ist ein Vielfaches von 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Diese wären nicht stichhaltig:
    /// // lass Brocken: &[[_;5]]= slice.as_chunks_unchecked()//Die Slice-Länge ist kein Vielfaches von 5 Let-Chunks:&[[_;0]]= slice.as_chunks_unchecked()//Blöcke mit der Länge Null sind niemals zulässig
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SICHERHEIT: Unsere Voraussetzung ist genau das, was benötigt wird, um dies zu nennen
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SICHERHEIT: Wir haben ein Stück `new_len * N`-Elemente in gegossen
        // Ein Stück `new_len` viele `N`-Elemente.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Teilt das Slice in ein Slice mit N-Element-Arrays auf, beginnend am Anfang des Slice, und ein Rest-Slice mit einer Länge von weniger als `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn `N` 0 ist. Diese Prüfung wird höchstwahrscheinlich in einen Fehler bei der Kompilierung geändert, bevor diese Methode stabilisiert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SICHERHEIT: Wir sind bereits in Panik geraten und haben durch den Bau dafür gesorgt
        // dass die Länge der Unterscheibe ein Vielfaches von N ist.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Teilt das Slice in ein Slice mit N-Element-Arrays auf, beginnend am Ende des Slice, und ein Rest-Slice mit einer Länge von weniger als `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn `N` 0 ist. Diese Prüfung wird höchstwahrscheinlich in einen Fehler bei der Kompilierung geändert, bevor diese Methode stabilisiert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SICHERHEIT: Wir sind bereits in Panik geraten und haben durch den Bau dafür gesorgt
        // dass die Länge der Unterscheibe ein Vielfaches von N ist.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Gibt einen Iterator über jeweils `N`-Elemente des Slice zurück, beginnend am Anfang des Slice.
    ///
    /// Die Chunks sind Array-Referenzen und überlappen sich nicht.
    /// Wenn `N` die Länge des Slice nicht teilt, werden die letzten bis zu `N-1`-Elemente weggelassen und können aus der `remainder`-Funktion des Iterators abgerufen werden.
    ///
    ///
    /// Diese Methode ist das konstante generische Äquivalent von [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics, wenn `N` 0 ist. Diese Prüfung wird höchstwahrscheinlich in einen Fehler bei der Kompilierung geändert, bevor diese Methode stabilisiert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Teilt das Slice in ein Slice von N-Element-Arrays auf, vorausgesetzt, es gibt keinen Rest.
    ///
    ///
    /// # Safety
    ///
    /// Dies darf nur aufgerufen werden, wenn
    /// - Das Slice teilt sich genau in N-Element-Chunks (auch bekannt als `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SICHERHEIT: 1-Element-Chunks haben nie Rest
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SICHERHEIT: Die Schnittlänge (6) ist ein Vielfaches von 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Diese wären nicht stichhaltig:
    /// // lass Brocken: &[[_;5]]= slice.as_chunks_unchecked_mut()//Die Slice-Länge ist kein Vielfaches von 5 Let-Chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Blöcke mit der Länge Null sind niemals zulässig
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SICHERHEIT: Unsere Voraussetzung ist genau das, was benötigt wird, um dies zu nennen
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SICHERHEIT: Wir haben ein Stück `new_len * N`-Elemente in gegossen
        // Ein Stück `new_len` viele `N`-Elemente.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Teilt das Slice in ein Slice mit N-Element-Arrays auf, beginnend am Anfang des Slice, und ein Rest-Slice mit einer Länge von weniger als `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn `N` 0 ist. Diese Prüfung wird höchstwahrscheinlich in einen Fehler bei der Kompilierung geändert, bevor diese Methode stabilisiert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SICHERHEIT: Wir sind bereits in Panik geraten und haben durch den Bau dafür gesorgt
        // dass die Länge der Unterscheibe ein Vielfaches von N ist.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Teilt das Slice in ein Slice mit N-Element-Arrays auf, beginnend am Ende des Slice, und ein Rest-Slice mit einer Länge von weniger als `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn `N` 0 ist. Diese Prüfung wird höchstwahrscheinlich in einen Fehler bei der Kompilierung geändert, bevor diese Methode stabilisiert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SICHERHEIT: Wir sind bereits in Panik geraten und haben durch den Bau dafür gesorgt
        // dass die Länge der Unterscheibe ein Vielfaches von N ist.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Gibt einen Iterator über jeweils `N`-Elemente des Slice zurück, beginnend am Anfang des Slice.
    ///
    /// Die Chunks sind veränderbare Array-Referenzen und überlappen sich nicht.
    /// Wenn `N` die Länge des Slice nicht teilt, werden die letzten bis zu `N-1`-Elemente weggelassen und können aus der `into_remainder`-Funktion des Iterators abgerufen werden.
    ///
    ///
    /// Diese Methode ist das konstante generische Äquivalent von [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics, wenn `N` 0 ist. Diese Prüfung wird höchstwahrscheinlich in einen Fehler bei der Kompilierung geändert, bevor diese Methode stabilisiert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Gibt einen Iterator über überlappende windows von `N`-Elementen eines Slice zurück, beginnend am Anfang des Slice.
    ///
    ///
    /// Dies ist das konstante generische Äquivalent von [`windows`].
    ///
    /// Wenn `N` größer als die Größe des Slice ist, wird kein windows zurückgegeben.
    ///
    /// # Panics
    ///
    /// Panics wenn `N` 0 ist.
    /// Diese Prüfung wird höchstwahrscheinlich in einen Kompilierungsfehler geändert, bevor diese Methode stabilisiert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Gibt einen Iterator über `chunk_size`-Elemente des Slice gleichzeitig zurück, beginnend am Ende des Slice.
    ///
    /// Die Stücke sind Scheiben und überlappen sich nicht.Wenn `chunk_size` die Länge des Slice nicht teilt, hat der letzte Block keine Länge `chunk_size`.
    ///
    /// In [`rchunks_exact`] finden Sie eine Variante dieses Iterators, die Blöcke von immer genau `chunk_size`-Elementen zurückgibt, und in [`chunks`] für denselben Iterator, der jedoch am Anfang des Slice beginnt.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Gibt einen Iterator über `chunk_size`-Elemente des Slice gleichzeitig zurück, beginnend am Ende des Slice.
    ///
    /// Die Stücke sind veränderbare Scheiben und überlappen sich nicht.Wenn `chunk_size` die Länge des Slice nicht teilt, hat der letzte Block keine Länge `chunk_size`.
    ///
    /// In [`rchunks_exact_mut`] finden Sie eine Variante dieses Iterators, die Blöcke von immer genau `chunk_size`-Elementen zurückgibt, und in [`chunks_mut`] für denselben Iterator, der jedoch am Anfang des Slice beginnt.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Gibt einen Iterator über `chunk_size`-Elemente des Slice gleichzeitig zurück, beginnend am Ende des Slice.
    ///
    /// Die Stücke sind Scheiben und überlappen sich nicht.
    /// Wenn `chunk_size` die Länge des Slice nicht teilt, werden die letzten bis zu `chunk_size-1`-Elemente weggelassen und können aus der `remainder`-Funktion des Iterators abgerufen werden.
    ///
    /// Da jeder Block genau `chunk_size`-Elemente enthält, kann der Compiler den resultierenden Code häufig besser optimieren als im Fall von [`chunks`].
    ///
    /// Siehe [`rchunks`] für eine Variante dieses Iterators, die auch den Rest als kleineren Block zurückgibt, und [`chunks_exact`] für denselben Iterator, jedoch beginnend am Anfang des Slice.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Gibt einen Iterator über `chunk_size`-Elemente des Slice gleichzeitig zurück, beginnend am Ende des Slice.
    ///
    /// Die Stücke sind veränderbare Scheiben und überlappen sich nicht.
    /// Wenn `chunk_size` die Länge des Slice nicht teilt, werden die letzten bis zu `chunk_size-1`-Elemente weggelassen und können aus der `into_remainder`-Funktion des Iterators abgerufen werden.
    ///
    /// Da jeder Block genau `chunk_size`-Elemente enthält, kann der Compiler den resultierenden Code häufig besser optimieren als im Fall von [`chunks_mut`].
    ///
    /// Siehe [`rchunks_mut`] für eine Variante dieses Iterators, die auch den Rest als kleineren Block zurückgibt, und [`chunks_exact_mut`] für denselben Iterator, jedoch beginnend am Anfang des Slice.
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `chunk_size` 0 ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Gibt einen Iterator über das Slice zurück, der nicht überlappende Elementläufe erzeugt, wobei das Prädikat verwendet wird, um sie zu trennen.
    ///
    /// Das Prädikat wird für zwei Elemente aufgerufen, die sich selbst folgen. Dies bedeutet, dass das Prädikat für `slice[0]` und `slice[1]`, dann für `slice[1]` und `slice[2]` usw. aufgerufen wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Diese Methode kann verwendet werden, um die sortierten Unterscheiben zu extrahieren:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Gibt einen Iterator über das Slice zurück, der nicht überlappende veränderbare Läufe von Elementen erzeugt, wobei das Prädikat verwendet wird, um sie zu trennen.
    ///
    /// Das Prädikat wird für zwei Elemente aufgerufen, die sich selbst folgen. Dies bedeutet, dass das Prädikat für `slice[0]` und `slice[1]`, dann für `slice[1]` und `slice[2]` usw. aufgerufen wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Diese Methode kann verwendet werden, um die sortierten Unterscheiben zu extrahieren:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Teilt eine Scheibe an einem Index in zwei.
    ///
    /// Der erste enthält alle Indizes von `[0, mid)` (mit Ausnahme des Index `mid` selbst) und der zweite enthält alle Indizes von `[mid, len)` (mit Ausnahme des Index `len` selbst).
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SICHERHEIT: `[ptr; mid]` und `[mid; len]` befinden sich in `self`, die
        // erfüllt die Anforderungen von `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Teilt eine veränderbare Schicht an einem Index in zwei.
    ///
    /// Der erste enthält alle Indizes von `[0, mid)` (mit Ausnahme des Index `mid` selbst) und der zweite enthält alle Indizes von `[mid, len)` (mit Ausnahme des Index `len` selbst).
    ///
    ///
    /// # Panics
    ///
    /// Panics wenn `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SICHERHEIT: `[ptr; mid]` und `[mid; len]` befinden sich in `self`, die
        // erfüllt die Anforderungen von `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Teilt ein Slice an einem Index in zwei, ohne die Grenzen zu überprüfen.
    ///
    /// Der erste enthält alle Indizes von `[0, mid)` (mit Ausnahme des Index `mid` selbst) und der zweite enthält alle Indizes von `[mid, len)` (mit Ausnahme des Index `len` selbst).
    ///
    ///
    /// Eine sichere Alternative finden Sie unter [`split_at`].
    ///
    /// # Safety
    ///
    /// Das Aufrufen dieser Methode mit einem Out-of-Bound-Index ist *[undefiniertes Verhalten]*, auch wenn die resultierende Referenz nicht verwendet wird.Der Anrufer muss sicherstellen, dass `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SICHERHEIT: Der Anrufer muss das `0 <= mid <= self.len()` überprüfen
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Teilt einen veränderlichen Slice an einem Index in zwei, ohne die Grenzen zu überprüfen.
    ///
    /// Der erste enthält alle Indizes von `[0, mid)` (mit Ausnahme des Index `mid` selbst) und der zweite enthält alle Indizes von `[mid, len)` (mit Ausnahme des Index `len` selbst).
    ///
    ///
    /// Eine sichere Alternative finden Sie unter [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Das Aufrufen dieser Methode mit einem Out-of-Bound-Index ist *[undefiniertes Verhalten]*, auch wenn die resultierende Referenz nicht verwendet wird.Der Anrufer muss sicherstellen, dass `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SICHERHEIT: Der Anrufer muss das `0 <= mid <= self.len()` überprüfen.
        //
        // `[ptr; mid]` und `[mid; len]` überlappen sich nicht, daher ist die Rückgabe einer veränderlichen Referenz in Ordnung.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Gibt einen Iterator über Subslices zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wenn das erste Element übereinstimmt, ist ein leeres Slice das erste vom Iterator zurückgegebene Element.
    /// Wenn das letzte Element im Slice übereinstimmt, ist ein leeres Slice das letzte vom Iterator zurückgegebene Element:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wenn zwei übereinstimmende Elemente direkt nebeneinander liegen, befindet sich zwischen ihnen ein leeres Slice:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Gibt einen Iterator über veränderbare Unterscheiben zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Gibt einen Iterator über Subslices zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen.
    /// Das übereinstimmende Element ist am Ende der vorherigen Unterscheibe als Terminator enthalten.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wenn das letzte Element des Slice übereinstimmt, wird dieses Element als Terminator des vorhergehenden Slice betrachtet.
    ///
    /// Dieses Slice ist das letzte vom Iterator zurückgegebene Element.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Gibt einen Iterator über veränderbare Unterscheiben zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen.
    /// Das übereinstimmende Element ist in der vorherigen Unterscheibe als Terminator enthalten.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Gibt einen Iterator über Subslices zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen. Beginnen Sie am Ende des Slice und arbeiten Sie rückwärts.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wie bei `split()` ist ein leeres Slice das erste (oder letzte) Element, das vom Iterator zurückgegeben wird, wenn das erste oder letzte Element übereinstimmt.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Gibt einen Iterator über veränderbare Subslices zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen. Beginnen Sie am Ende des Slice und arbeiten Sie rückwärts.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Gibt einen Iterator über Unterabschnitte zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen, und beschränkt sich auf die Rückgabe von höchstens `n`-Elementen.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// Das zuletzt zurückgegebene Element, falls vorhanden, enthält den Rest des Slice.
    ///
    /// # Examples
    ///
    /// Drucken Sie die Scheibe einmal geteilt durch durch 3 teilbare Zahlen (dh `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Gibt einen Iterator über Unterabschnitte zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen, und beschränkt sich auf die Rückgabe von höchstens `n`-Elementen.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// Das zuletzt zurückgegebene Element, falls vorhanden, enthält den Rest des Slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Gibt einen Iterator über Unterabschnitte zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen, und beschränkt sich darauf, höchstens `n`-Elemente zurückzugeben.
    /// Dies beginnt am Ende des Slice und funktioniert rückwärts.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// Das zuletzt zurückgegebene Element, falls vorhanden, enthält den Rest des Slice.
    ///
    /// # Examples
    ///
    /// Drucken Sie den Slice-Split einmal beginnend am Ende durch durch 3 teilbare Zahlen (dh `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Gibt einen Iterator über Unterabschnitte zurück, die durch Elemente getrennt sind, die mit `pred` übereinstimmen, und beschränkt sich darauf, höchstens `n`-Elemente zurückzugeben.
    /// Dies beginnt am Ende des Slice und funktioniert rückwärts.
    /// Das übereinstimmende Element ist nicht in den Subslices enthalten.
    ///
    /// Das zuletzt zurückgegebene Element, falls vorhanden, enthält den Rest des Slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Gibt `true` zurück, wenn das Slice ein Element mit dem angegebenen Wert enthält.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Wenn Sie keinen `&T` haben, sondern nur einen `&U`, so dass `T: Borrow<U>` (z
    /// `String: Ausleihen<str>`) können Sie `iter().any` verwenden:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // Scheibe `String`
    /// assert!(v.iter().any(|e| e == "hello")); // Suche mit `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Gibt `true` zurück, wenn `needle` ein Präfix des Slice ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Gibt immer `true` zurück, wenn `needle` ein leeres Slice ist:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Gibt `true` zurück, wenn `needle` ein Suffix des Slice ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Gibt immer `true` zurück, wenn `needle` ein leeres Slice ist:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Gibt ein Subslice mit entferntem Präfix zurück.
    ///
    /// Wenn das Slice mit `prefix` beginnt, wird das Subslice nach dem in `Some` eingeschlossenen Präfix zurückgegeben.
    /// Wenn `prefix` leer ist, wird einfach das ursprüngliche Slice zurückgegeben.
    ///
    /// Wenn das Slice nicht mit `prefix` startet, wird `None` zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Diese Funktion muss neu geschrieben werden, wenn SlicePattern komplexer wird.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Gibt ein Subslice mit entferntem Suffix zurück.
    ///
    /// Wenn das Slice mit `suffix` endet, wird das Subslice vor dem in `Some` eingeschlossenen Suffix zurückgegeben.
    /// Wenn `suffix` leer ist, wird einfach das ursprüngliche Slice zurückgegeben.
    ///
    /// Wenn das Slice nicht mit `suffix` endet, wird `None` zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Diese Funktion muss neu geschrieben werden, wenn SlicePattern komplexer wird.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary durchsucht dieses sortierte Segment nach einem bestimmten Element.
    ///
    /// Wenn der Wert gefunden wird, wird [`Result::Ok`] zurückgegeben, das den Index des übereinstimmenden Elements enthält.
    /// Wenn es mehrere Übereinstimmungen gibt, kann eine der Übereinstimmungen zurückgegeben werden.
    /// Wenn der Wert nicht gefunden wird, wird [`Result::Err`] zurückgegeben, das den Index enthält, in den ein übereinstimmendes Element eingefügt werden kann, während die sortierte Reihenfolge beibehalten wird.
    ///
    ///
    /// Siehe auch [`binary_search_by`], [`binary_search_by_key`] und [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Schlägt eine Reihe von vier Elementen nach.
    /// Die erste wird mit einer eindeutig bestimmten Position gefunden;der zweite und dritte werden nicht gefunden;Der vierte könnte mit jeder Position in `[1, 4]` übereinstimmen.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Wenn Sie einen Artikel in einen sortierten vector einfügen möchten, während Sie die Sortierreihenfolge beibehalten:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binär durchsucht dieses sortierte Segment mit einer Komparatorfunktion.
    ///
    /// Die Komparatorfunktion sollte eine Reihenfolge implementieren, die mit der Sortierreihenfolge des zugrunde liegenden Slice übereinstimmt, und einen Bestellcode zurückgeben, der angibt, ob das Argument `Less`, `Equal` oder `Greater` das gewünschte Ziel ist.
    ///
    ///
    /// Wenn der Wert gefunden wird, wird [`Result::Ok`] zurückgegeben, das den Index des übereinstimmenden Elements enthält.Wenn es mehrere Übereinstimmungen gibt, kann eine der Übereinstimmungen zurückgegeben werden.
    /// Wenn der Wert nicht gefunden wird, wird [`Result::Err`] zurückgegeben, das den Index enthält, in den ein übereinstimmendes Element eingefügt werden kann, während die sortierte Reihenfolge beibehalten wird.
    ///
    /// Siehe auch [`binary_search`], [`binary_search_by_key`] und [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Schlägt eine Reihe von vier Elementen nach.Die erste wird mit einer eindeutig bestimmten Position gefunden;der zweite und dritte werden nicht gefunden;Der vierte könnte mit jeder Position in `[1, 4]` übereinstimmen.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SICHERHEIT: Der Anruf wird durch die folgenden Invarianten sicher gemacht:
            // - `mid >= 0`
            // - `mid < size`: `mid` ist durch `[left; right)` gebunden.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Der Grund, warum wir den if/else-Kontrollfluss anstelle von Match verwenden, liegt darin, dass Match Vergleichsoperationen neu ordnet, was perfekt ist.
            //
            // Dies ist x86 asm für u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary durchsucht dieses sortierte Slice mit einer Schlüsselextraktionsfunktion.
    ///
    /// Angenommen, das Slice wird nach dem Schlüssel sortiert, z. B. mit [`sort_by_key`], das dieselbe Schlüsselextraktionsfunktion verwendet.
    ///
    /// Wenn der Wert gefunden wird, wird [`Result::Ok`] zurückgegeben, das den Index des übereinstimmenden Elements enthält.
    /// Wenn es mehrere Übereinstimmungen gibt, kann eine der Übereinstimmungen zurückgegeben werden.
    /// Wenn der Wert nicht gefunden wird, wird [`Result::Err`] zurückgegeben, das den Index enthält, in den ein übereinstimmendes Element eingefügt werden kann, während die sortierte Reihenfolge beibehalten wird.
    ///
    ///
    /// Siehe auch [`binary_search`], [`binary_search_by`] und [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Sucht eine Reihe von vier Elementen in einer Gruppe von Paaren, die nach ihren zweiten Elementen sortiert sind.
    /// Die erste wird mit einer eindeutig bestimmten Position gefunden;der zweite und dritte werden nicht gefunden;Der vierte könnte mit jeder Position in `[1, 4]` übereinstimmen.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ist zulässig, da `slice::sort_by_key` in crate `alloc` enthalten ist und als solches beim Erstellen von `core` noch nicht vorhanden ist.
    //
    // Links zu Downstream crate: #74481.Da Grundelemente nur in libstd (#73423) dokumentiert sind, führt dies in der Praxis nie zu fehlerhaften Verknüpfungen.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sortiert das Slice, behält jedoch möglicherweise nicht die Reihenfolge gleicher Elemente bei.
    ///
    /// Diese Sortierung ist instabil (dh kann gleiche Elemente neu anordnen), vorhanden (dh nicht zugeordnet) und *O*(*n*\*log(* n*)) Worst-Case).
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus basiert auf [pattern-defeating quicksort][pdqsort] von Orson Peters, der den schnellen Durchschnittsfall von randomisiertem Quicksort mit dem schnellsten Worst-Fall von Heapsort kombiniert und gleichzeitig eine lineare Zeit für Slices mit bestimmten Mustern erreicht.
    /// Es verwendet eine Randomisierung, um entartete Fälle zu vermeiden, aber mit einem festen seed, um immer deterministisches Verhalten bereitzustellen.
    ///
    /// Es ist normalerweise schneller als eine stabile Sortierung, außer in einigen besonderen Fällen, z. B. wenn das Slice aus mehreren verketteten sortierten Sequenzen besteht.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sortiert das Slice mit einer Komparatorfunktion, behält jedoch möglicherweise nicht die Reihenfolge gleicher Elemente bei.
    ///
    /// Diese Sortierung ist instabil (dh kann gleiche Elemente neu anordnen), vorhanden (dh nicht zugeordnet) und *O*(*n*\*log(* n*)) Worst-Case).
    ///
    /// Die Komparatorfunktion muss eine Gesamtreihenfolge für die Elemente im Slice definieren.Wenn die Reihenfolge nicht vollständig ist, ist die Reihenfolge der Elemente nicht angegeben.Eine Bestellung ist eine Gesamtbestellung, wenn dies der Fall ist (für alle `a`, `b` und `c`):
    ///
    /// * total und antisymmetrisch: genau eines von `a < b`, `a == b` oder `a > b` ist wahr, und
    /// * transitiv, `a < b` und `b < c` implizieren `a < c`.Das Gleiche muss für `==` und `>` gelten.
    ///
    /// Während [`f64`] beispielsweise [`Ord`] aufgrund von `NaN != NaN` nicht implementiert, können wir `partial_cmp` als Sortierfunktion verwenden, wenn wir wissen, dass das Slice kein `NaN` enthält.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus basiert auf [pattern-defeating quicksort][pdqsort] von Orson Peters, der den schnellen Durchschnittsfall von randomisiertem Quicksort mit dem schnellsten Worst-Fall von Heapsort kombiniert und gleichzeitig eine lineare Zeit für Slices mit bestimmten Mustern erreicht.
    /// Es verwendet eine Randomisierung, um entartete Fälle zu vermeiden, aber mit einem festen seed, um immer deterministisches Verhalten bereitzustellen.
    ///
    /// Es ist normalerweise schneller als eine stabile Sortierung, außer in einigen besonderen Fällen, z. B. wenn das Slice aus mehreren verketteten sortierten Sequenzen besteht.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // umgekehrte Sortierung
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sortiert das Slice mit einer Schlüsselextraktionsfunktion, behält jedoch möglicherweise nicht die Reihenfolge gleicher Elemente bei.
    ///
    /// Diese Sortierung ist instabil (dh kann gleiche Elemente neu anordnen), vorhanden (dh nicht zugeordnet) und *O*(m\* * n *\* log(*n*)) Worst-Case, wobei die Schlüsselfunktion *O* ist)(*m*).
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus basiert auf [pattern-defeating quicksort][pdqsort] von Orson Peters, der den schnellen Durchschnittsfall von randomisiertem Quicksort mit dem schnellsten Worst-Fall von Heapsort kombiniert und gleichzeitig eine lineare Zeit für Slices mit bestimmten Mustern erreicht.
    /// Es verwendet eine Randomisierung, um entartete Fälle zu vermeiden, aber mit einem festen seed, um immer deterministisches Verhalten bereitzustellen.
    ///
    /// Aufgrund seiner Schlüsselaufrufstrategie ist [`sort_unstable_by_key`](#method.sort_unstable_by_key) in Fällen, in denen die Tastenfunktion teuer ist, wahrscheinlich langsamer als [`sort_by_cached_key`](#method.sort_by_cached_key).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ordnen Sie das Slice so an, dass sich das Element bei `index` an seiner endgültigen sortierten Position befindet.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Ordnen Sie das Slice mit einer Komparatorfunktion neu an, sodass sich das Element bei `index` an seiner endgültigen sortierten Position befindet.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Ordnen Sie das Slice mit einer Schlüsselextraktionsfunktion neu an, sodass sich das Element bei `index` an seiner endgültigen sortierten Position befindet.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Ordnen Sie das Slice so an, dass sich das Element bei `index` an seiner endgültigen sortierten Position befindet.
    ///
    /// Diese Neuordnung hat die zusätzliche Eigenschaft, dass jeder Wert an Position `i < index` kleiner oder gleich einem Wert an Position `j > index` ist.
    /// Zusätzlich ist diese Neuordnung instabil (dh
    /// Eine beliebige Anzahl gleicher Elemente kann an Position `index`) an Ort und Stelle landen (dh
    /// ordnet nicht zu) und *O*(*n*) Worst-Case.
    /// Diese Funktion wird in anderen Bibliotheken auch als "kth element" bezeichnet.
    /// Es wird ein Triplett der folgenden Werte zurückgegeben: alle Elemente, die kleiner als das am angegebenen Index sind, der Wert am angegebenen Index und alle Elemente, die größer als das am angegebenen Index sind.
    ///
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus basiert auf dem Quickselect-Teil des gleichen QuickSort-Algorithmus, der für [`sort_unstable`] verwendet wird.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics bei `index >= len()`, dh es ist immer panics bei leeren Slices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Finden Sie den Median
    /// v.select_nth_unstable(2);
    ///
    /// // Wir können nur garantieren, dass das Slice eines der folgenden ist, basierend auf der Art und Weise, wie wir nach dem angegebenen Index sortieren.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ordnen Sie das Slice mit einer Komparatorfunktion neu an, sodass sich das Element bei `index` an seiner endgültigen sortierten Position befindet.
    ///
    /// Diese Neuordnung hat die zusätzliche Eigenschaft, dass jeder Wert an Position `i < index` mit der Komparatorfunktion kleiner oder gleich einem Wert an Position `j > index` ist.
    /// Darüber hinaus ist diese Neuordnung instabil (dh eine beliebige Anzahl gleicher Elemente kann an Position `index` enden), an Ort und Stelle (dh nicht zugeordnet) und im schlimmsten Fall *O*(*n*).
    /// Diese Funktion wird in anderen Bibliotheken auch als "kth element" bezeichnet.
    /// Es wird ein Triplett der folgenden Werte zurückgegeben: alle Elemente, die kleiner als das am angegebenen Index sind, der Wert am angegebenen Index und alle Elemente, die größer als das am angegebenen Index sind, unter Verwendung der bereitgestellten Komparatorfunktion.
    ///
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus basiert auf dem Quickselect-Teil des gleichen QuickSort-Algorithmus, der für [`sort_unstable`] verwendet wird.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics bei `index >= len()`, dh es ist immer panics bei leeren Slices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Finden Sie den Median so, als ob das Slice in absteigender Reihenfolge sortiert wäre.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Wir können nur garantieren, dass das Slice eines der folgenden ist, basierend auf der Art und Weise, wie wir nach dem angegebenen Index sortieren.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ordnen Sie das Slice mit einer Schlüsselextraktionsfunktion neu an, sodass sich das Element bei `index` an seiner endgültigen sortierten Position befindet.
    ///
    /// Diese Neuordnung hat die zusätzliche Eigenschaft, dass jeder Wert an Position `i < index` mit der Schlüsselextraktionsfunktion kleiner oder gleich einem Wert an Position `j > index` ist.
    /// Darüber hinaus ist diese Neuordnung instabil (dh eine beliebige Anzahl gleicher Elemente kann an Position `index` enden), an Ort und Stelle (dh nicht zugeordnet) und im schlimmsten Fall *O*(*n*).
    /// Diese Funktion wird in anderen Bibliotheken auch als "kth element" bezeichnet.
    /// Es gibt ein Triplett der folgenden Werte zurück: Alle Elemente, die kleiner als das am angegebenen Index sind, der Wert am angegebenen Index und alle Elemente, die größer als das am angegebenen Index sind, verwenden die bereitgestellte Schlüsselextraktionsfunktion.
    ///
    ///
    /// # Aktuelle Implementierung
    ///
    /// Der aktuelle Algorithmus basiert auf dem Quickselect-Teil des gleichen QuickSort-Algorithmus, der für [`sort_unstable`] verwendet wird.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics bei `index >= len()`, dh es ist immer panics bei leeren Slices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Geben Sie den Median zurück, als ob das Array nach dem absoluten Wert sortiert wäre.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Wir können nur garantieren, dass das Slice eines der folgenden ist, basierend auf der Art und Weise, wie wir nach dem angegebenen Index sortieren.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Verschiebt alle aufeinanderfolgenden wiederholten Elemente gemäß der [`PartialEq`] trait-Implementierung an das Ende des Slice.
    ///
    ///
    /// Gibt zwei Slices zurück.Das erste enthält keine aufeinanderfolgenden wiederholten Elemente.
    /// Die zweite enthält alle Duplikate in keiner festgelegten Reihenfolge.
    ///
    /// Wenn das Slice sortiert ist, enthält das erste zurückgegebene Slice keine Duplikate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Verschiebt alle bis auf das erste aufeinanderfolgende Element an das Ende des Slice, um eine bestimmte Gleichheitsrelation zu erfüllen.
    ///
    /// Gibt zwei Slices zurück.Das erste enthält keine aufeinanderfolgenden wiederholten Elemente.
    /// Die zweite enthält alle Duplikate in keiner festgelegten Reihenfolge.
    ///
    /// Die `same_bucket`-Funktion erhält Verweise auf zwei Elemente aus dem Slice und muss bestimmen, ob die Elemente gleich sind.
    /// Die Elemente werden in entgegengesetzter Reihenfolge zu ihrer Reihenfolge im Slice übergeben. Wenn also `same_bucket(a, b)` `true` zurückgibt, wird `a` am Ende des Slice verschoben.
    ///
    ///
    /// Wenn das Slice sortiert ist, enthält das erste zurückgegebene Slice keine Duplikate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Obwohl wir einen veränderlichen Verweis auf `self` haben, können wir keine *willkürlichen* Änderungen vornehmen.Die `same_bucket`-Aufrufe könnten panic sein, daher müssen wir sicherstellen, dass sich das Slice jederzeit in einem gültigen Zustand befindet.
        //
        // Wir gehen damit um, indem wir Swaps verwenden.Wir durchlaufen alle Elemente und tauschen sie aus, sodass am Ende die Elemente, die wir behalten möchten, vorne und die Elemente, die wir ablehnen möchten, hinten sind.
        // Wir können dann die Scheibe teilen.
        // Dieser Vorgang ist immer noch `O(n)`.
        //
        // Beispiel: Wir beginnen in diesem Zustand, in dem `r` "next" darstellt
        // read "und `w` steht für" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Wenn wir self[r] mit self [w-1] vergleichen, ist dies kein Duplikat. Wir tauschen also self[r] und self[w] aus (kein Effekt als r==w) und erhöhen dann sowohl r als auch w.
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Wenn wir self[r] mit self [w-1] vergleichen, ist dieser Wert ein Duplikat. Wir erhöhen also `r`, lassen aber alles andere unverändert:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Wenn Sie self[r] mit self [w-1] vergleichen, ist dies kein Duplikat. Tauschen Sie also self[r] und self[w] aus und rücken Sie r und w vor:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Kein Duplikat, wiederholen Sie:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplizieren, advance r. End Scheibe.Aufteilen bei w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SICHERHEIT: Die `while`-Bedingung garantiert `next_read` und `next_write`
        // sind kleiner als `len`, befinden sich also in `self`.
        // `prev_ptr_write` zeigt auf ein Element vor `ptr_write`, aber `next_write` beginnt bei 1, sodass `prev_ptr_write` niemals kleiner als 0 ist und sich innerhalb des Slice befindet.
        // Dies erfüllt die Anforderungen für die Dereferenzierung von `ptr_read`, `prev_ptr_write` und `ptr_write` sowie für die Verwendung von `ptr.add(next_read)`, `ptr.add(next_write - 1)` und `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` wird auch höchstens einmal pro Schleife erhöht, was bedeutet, dass kein Element übersprungen wird, wenn es möglicherweise ausgetauscht werden muss.
        //
        // `ptr_read` und `prev_ptr_write` zeigen niemals auf dasselbe Element.Dies ist erforderlich, damit `&mut *ptr_read`, `&mut* prev_ptr_write` sicher ist.
        // Die Erklärung ist einfach, dass `next_read >= next_write` immer wahr ist, also auch `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Vermeiden Sie Grenzüberprüfungen, indem Sie Rohzeiger verwenden.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Verschiebt alle bis auf das erste aufeinanderfolgende Element an das Ende des Slice, das in denselben Schlüssel aufgelöst wird.
    ///
    ///
    /// Gibt zwei Slices zurück.Das erste enthält keine aufeinanderfolgenden wiederholten Elemente.
    /// Die zweite enthält alle Duplikate in keiner festgelegten Reihenfolge.
    ///
    /// Wenn das Slice sortiert ist, enthält das erste zurückgegebene Slice keine Duplikate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Dreht das Slice an Ort und Stelle, sodass sich die ersten `mid`-Elemente des Slice zum Ende bewegen, während sich die letzten `self.len() - mid`-Elemente nach vorne bewegen.
    /// Nach dem Aufruf von `rotate_left` wird das Element am Index `mid` zum ersten Element im Slice.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn `mid` größer als die Länge des Slice ist.Beachten Sie, dass `mid == self.len()` _not_ panic ausführt und eine No-Op-Drehung ist.
    ///
    /// # Complexity
    ///
    /// Nimmt linear (in `self.len()`)-Zeit).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Unterscheibe drehen:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SICHERHEIT: Der Bereich `[p.add(mid) - mid, p.add(mid) + k)` ist trivial
        // Gültig zum Lesen und Schreiben, wie von `ptr_rotate` gefordert.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Dreht das Slice an Ort und Stelle, sodass sich die ersten `self.len() - k`-Elemente des Slice zum Ende bewegen, während sich die letzten `k`-Elemente nach vorne bewegen.
    /// Nach dem Aufruf von `rotate_right` wird das Element am Index `self.len() - k` zum ersten Element im Slice.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn `k` größer als die Länge des Slice ist.Beachten Sie, dass `k == self.len()` _not_ panic ausführt und eine No-Op-Drehung ist.
    ///
    /// # Complexity
    ///
    /// Nimmt linear (in `self.len()`)-Zeit).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Unterscheibe drehen:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SICHERHEIT: Der Bereich `[p.add(mid) - mid, p.add(mid) + k)` ist trivial
        // Gültig zum Lesen und Schreiben, wie von `ptr_rotate` gefordert.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Füllt `self` mit Elementen, indem `value` geklont wird.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Füllt `self` mit Elementen, die durch wiederholtes Aufrufen eines Abschlusses zurückgegeben werden.
    ///
    /// Diese Methode verwendet einen Abschluss, um neue Werte zu erstellen.Wenn Sie lieber einen bestimmten Wert [`Clone`] möchten, verwenden Sie [`fill`].
    /// Wenn Sie [`Default`] trait zum Generieren von Werten verwenden möchten, können Sie [`Default::default`] als Argument übergeben.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopiert die Elemente von `src` nach `self`.
    ///
    /// Die Länge von `src` muss mit der von `self` übereinstimmen.
    ///
    /// Wenn `T` `Copy` implementiert, kann die Verwendung von [`copy_from_slice`] leistungsfähiger sein.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn die beiden Slices unterschiedliche Längen haben.
    ///
    /// # Examples
    ///
    /// Klonen von zwei Elementen aus einem Slice in ein anderes:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Da die Slices gleich lang sein müssen, schneiden wir den Quell-Slice von vier auf zwei Elemente.
    /// // Es wird panic, wenn wir dies nicht tun.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust erzwingt, dass es nur eine veränderbare Referenz ohne unveränderliche Verweise auf ein bestimmtes Datenelement in einem bestimmten Bereich geben kann.
    /// Aus diesem Grund führt der Versuch, `clone_from_slice` für ein einzelnes Slice zu verwenden, zu einem Kompilierungsfehler:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Um dies zu umgehen, können wir mit [`split_at_mut`] zwei unterschiedliche Unter-Slices aus einem Slice erstellen:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopiert alle Elemente von `src` mit einem Memcpy nach `self`.
    ///
    /// Die Länge von `src` muss mit der von `self` übereinstimmen.
    ///
    /// Wenn `T` `Copy` nicht implementiert, verwenden Sie [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn die beiden Slices unterschiedliche Längen haben.
    ///
    /// # Examples
    ///
    /// Kopieren von zwei Elementen aus einem Slice in ein anderes:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Da die Slices gleich lang sein müssen, schneiden wir den Quell-Slice von vier auf zwei Elemente.
    /// // Es wird panic, wenn wir dies nicht tun.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust erzwingt, dass es nur eine veränderbare Referenz ohne unveränderliche Verweise auf ein bestimmtes Datenelement in einem bestimmten Bereich geben kann.
    /// Aus diesem Grund führt der Versuch, `copy_from_slice` für ein einzelnes Slice zu verwenden, zu einem Kompilierungsfehler:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Um dies zu umgehen, können wir mit [`split_at_mut`] zwei unterschiedliche Unter-Slices aus einem Slice erstellen:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Der panic-Codepfad wurde in eine Cold-Funktion versetzt, um die Anrufstelle nicht aufzublähen.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SICHERHEIT: `self` ist per Definition für `self.len()`-Elemente gültig, und `src` war
        // überprüft, um die gleiche Länge zu haben.
        // Die Slices können sich nicht überlappen, da veränderbare Referenzen exklusiv sind.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopiert Elemente mit einem Memmove von einem Teil des Slice in einen anderen Teil von sich.
    ///
    /// `src` ist der Bereich innerhalb von `self`, aus dem kopiert werden soll.
    /// `dest` ist der Startindex des Bereichs innerhalb von `self`, in den kopiert werden soll und der dieselbe Länge wie `src` hat.
    /// Die beiden Bereiche können sich überschneiden.
    /// Die Enden der beiden Bereiche müssen kleiner oder gleich `self.len()` sein.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn einer der Bereiche das Ende des Slice überschreitet oder wenn das Ende von `src` vor dem Start liegt.
    ///
    ///
    /// # Examples
    ///
    /// Kopieren von vier Bytes innerhalb eines Slice:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SICHERHEIT: Die Bedingungen für `ptr::copy` wurden alle oben überprüft.
        // wie die für `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Tauscht alle Elemente in `self` gegen die in `other` aus.
    ///
    /// Die Länge von `other` muss mit der von `self` übereinstimmen.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn die beiden Slices unterschiedliche Längen haben.
    ///
    /// # Example
    ///
    /// Vertauschen von zwei Elementen über Slices:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust erzwingt, dass es nur einen veränderlichen Verweis auf ein bestimmtes Datenelement in einem bestimmten Bereich geben kann.
    ///
    /// Aus diesem Grund führt der Versuch, `swap_with_slice` für ein einzelnes Slice zu verwenden, zu einem Kompilierungsfehler:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Um dies zu umgehen, können wir mit [`split_at_mut`] zwei unterschiedliche veränderbare Unter-Slices aus einem Slice erstellen:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SICHERHEIT: `self` ist per Definition für `self.len()`-Elemente gültig, und `src` war
        // überprüft, um die gleiche Länge zu haben.
        // Die Slices können sich nicht überlappen, da veränderbare Referenzen exklusiv sind.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funktion zum Berechnen der Länge des mittleren und hinteren Slice für `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Was wir mit `rest` tun werden, ist herauszufinden, welches Vielfache von "U" wir in eine niedrigste Anzahl von "T" einfügen können.
        //
        // Und wie viele T's brauchen wir für jeden solchen "multiple".
        //
        // Betrachten Sie zum Beispiel T=u8 U=u16.Dann können wir 1 U in 2 Ts setzen.Einfach.
        // Stellen Sie sich zum Beispiel einen Fall vor, in dem size_of: :<T>=16, size_of::<U>=24.</u>
        // Wir können 2 Us anstelle von jeweils 3 Ts in der `rest`-Scheibe setzen.
        // Etwas komplizierter.
        //
        // Die Formel zur Berechnung lautet:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Erweitert und vereinfacht:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Zum Glück wird das alles konstant bewertet ... Leistung spielt hier keine Rolle!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterativer Stein-Algorithmus Wir sollten diesen `const fn` trotzdem machen (und in diesem Fall zum rekursiven Algorithmus zurückkehren), weil es…unangenehm ist, mich auf llvm zu verlassen, um all dies zu kontrollieren.
            //
            //

            // SICHERHEIT: `a` und `b` werden als Werte ungleich Null überprüft.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // entferne alle Faktoren von 2 aus b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SICHERHEIT: `b` wird auf einen Wert ungleich Null geprüft.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Mit diesem Wissen können wir herausfinden, wie viele Us wir passen können!
        let us_len = self.len() / ts * us;
        // Und wie viele `T`s werden in der nachfolgenden Scheibe sein!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Wandeln Sie das Slice in ein Slice eines anderen Typs um, um sicherzustellen, dass die Ausrichtung der Typen erhalten bleibt.
    ///
    /// Diese Methode teilt das Slice in drei verschiedene Slices auf: Präfix, korrekt ausgerichtetes mittleres Slice eines neuen Typs und das Suffix Slice.
    /// Die Methode macht das mittlere Slice möglicherweise zur größtmöglichen Länge für einen bestimmten Typ und ein bestimmtes Eingabeschnitt, aber nur die Leistung Ihres Algorithmus sollte davon abhängen, nicht von seiner Richtigkeit.
    ///
    /// Es ist zulässig, dass alle Eingabedaten als Präfix oder Suffix-Slice zurückgegeben werden.
    ///
    /// Diese Methode hat keinen Zweck, wenn entweder das Eingabeelement `T` oder das Ausgabeelement `U` die Größe Null haben und das ursprüngliche Slice zurückgeben, ohne etwas zu teilen.
    ///
    /// # Safety
    ///
    /// Bei dieser Methode handelt es sich im Wesentlichen um eine `transmute`-Methode in Bezug auf die Elemente in der zurückgegebenen mittleren Schicht. Daher gelten auch hier alle üblichen Einschränkungen für `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Beachten Sie, dass der größte Teil dieser Funktion konstant ausgewertet wird.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // Behandeln Sie ZSTs speziell, dh-behandeln Sie sie überhaupt nicht.
            return (self, &[], &[]);
        }

        // Finden Sie zuerst heraus, an welchem Punkt wir zwischen der ersten und der zweiten Scheibe aufteilen.
        // Einfach mit ptr.align_offset.
        let ptr = self.as_ptr();
        // SICHERHEIT: Ausführliche Informationen zur Sicherheit finden Sie in der `align_to_mut`-Methode.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SICHERHEIT: Jetzt ist `rest` definitiv ausgerichtet, also ist `from_raw_parts` unten in Ordnung.
            // da der Anrufer garantiert, dass wir `T` sicher in `U` umwandeln können.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Wandeln Sie das Slice in ein Slice eines anderen Typs um, um sicherzustellen, dass die Ausrichtung der Typen erhalten bleibt.
    ///
    /// Diese Methode teilt das Slice in drei verschiedene Slices auf: Präfix, korrekt ausgerichtetes mittleres Slice eines neuen Typs und das Suffix Slice.
    /// Die Methode macht das mittlere Slice möglicherweise zur größtmöglichen Länge für einen bestimmten Typ und ein bestimmtes Eingabeschnitt, aber nur die Leistung Ihres Algorithmus sollte davon abhängen, nicht von seiner Richtigkeit.
    ///
    /// Es ist zulässig, dass alle Eingabedaten als Präfix oder Suffix-Slice zurückgegeben werden.
    ///
    /// Diese Methode hat keinen Zweck, wenn entweder das Eingabeelement `T` oder das Ausgabeelement `U` die Größe Null haben und das ursprüngliche Slice zurückgeben, ohne etwas zu teilen.
    ///
    /// # Safety
    ///
    /// Bei dieser Methode handelt es sich im Wesentlichen um eine `transmute`-Methode in Bezug auf die Elemente in der zurückgegebenen mittleren Schicht. Daher gelten auch hier alle üblichen Einschränkungen für `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Beachten Sie, dass der größte Teil dieser Funktion konstant ausgewertet wird.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // Behandeln Sie ZSTs speziell, dh-behandeln Sie sie überhaupt nicht.
            return (self, &mut [], &mut []);
        }

        // Finden Sie zuerst heraus, an welchem Punkt wir zwischen der ersten und der zweiten Scheibe aufteilen.
        // Einfach mit ptr.align_offset.
        let ptr = self.as_ptr();
        // SICHERHEIT: Hier stellen wir sicher, dass wir ausgerichtete Zeiger für U für die verwenden
        // Rest der Methode.Dies erfolgt durch Übergeben eines Zeigers auf&[T] mit einer Ausrichtung, die auf U ausgerichtet ist.
        // `crate::ptr::align_offset` wird mit einem korrekt ausgerichteten und gültigen Zeiger `ptr` (er stammt aus einem Verweis auf `self`) und mit einer Größe, die eine Zweierpotenz ist (da er aus der Ausrichtung für U stammt) aufgerufen, um seine Sicherheitsbeschränkungen zu erfüllen.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Danach können wir `rest` nicht mehr verwenden, da dies den Alias `mut_ptr` ungültig machen würde!SICHERHEIT: Siehe Kommentare für `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Überprüft, ob die Elemente dieses Slice sortiert sind.
    ///
    /// Das heißt, für jedes Element `a` und das folgende Element `b` muss `a <= b` gelten.Wenn das Slice genau null oder ein Element ergibt, wird `true` zurückgegeben.
    ///
    /// Beachten Sie, dass, wenn `Self::Item` nur `PartialOrd`, aber nicht `Ord` ist, die obige Definition impliziert, dass diese Funktion `false` zurückgibt, wenn zwei aufeinanderfolgende Elemente nicht vergleichbar sind.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Überprüft, ob die Elemente dieses Slice mit der angegebenen Komparatorfunktion sortiert sind.
    ///
    /// Anstatt `PartialOrd::partial_cmp` zu verwenden, verwendet diese Funktion die angegebene `compare`-Funktion, um die Reihenfolge von zwei Elementen zu bestimmen.
    /// Abgesehen davon entspricht es [`is_sorted`];Weitere Informationen finden Sie in der Dokumentation.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Überprüft, ob die Elemente dieses Slice mit der angegebenen Schlüsselextraktionsfunktion sortiert sind.
    ///
    /// Anstatt die Elemente des Slice direkt zu vergleichen, vergleicht diese Funktion die Tasten der Elemente, wie von `f` bestimmt.
    /// Abgesehen davon entspricht es [`is_sorted`];Weitere Informationen finden Sie in der Dokumentation.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Gibt den Index des Partitionspunkts gemäß dem angegebenen Prädikat zurück (den Index des ersten Elements der zweiten Partition).
    ///
    /// Es wird angenommen, dass das Slice gemäß dem angegebenen Prädikat partitioniert ist.
    /// Dies bedeutet, dass alle Elemente, für die das Prädikat true zurückgibt, am Anfang des Slice stehen und alle Elemente, für die das Prädikat false zurückgibt, am Ende stehen.
    ///
    /// Zum Beispiel ist [7, 15, 3, 5, 4, 12, 6] eine Partition unter dem Prädikat x% 2!=0 (alle ungeraden Zahlen stehen am Anfang, alle am Ende gerade).
    ///
    /// Wenn dieses Slice nicht partitioniert ist, ist das zurückgegebene Ergebnis nicht angegeben und bedeutungslos, da diese Methode eine Art binäre Suche durchführt.
    ///
    /// Siehe auch [`binary_search`], [`binary_search_by`] und [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SICHERHEIT: Wenn `left < right`, `left <= mid < right`.
            // Daher nimmt `left` immer zu und `right` immer ab, und einer von beiden ist ausgewählt.In beiden Fällen ist `left <= right` erfüllt.Wenn sich `left < right` in einem Schritt befindet, ist `left <= right` im nächsten Schritt erfüllt.
            //
            // Daher ist `0 <= left < right <= len`, solange `left != right` erfüllt ist, und in diesem Fall auch `0 <= mid < len` erfüllt.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Wir müssen sie explizit auf die gleiche Länge schneiden
        // um es dem Optimierer zu erleichtern, die Überprüfung der Grenzen zu umgehen.
        // Da man sich aber nicht darauf verlassen kann, haben wir auch eine explizite Spezialisierung für T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Erstellt ein leeres Slice.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Erstellt ein veränderbares leeres Slice.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Muster in Slices werden derzeit nur von `strip_prefix` und `strip_suffix` verwendet.
/// An einem future-Punkt hoffen wir, `core::str::Pattern` (das zum Zeitpunkt des Schreibens auf `str` beschränkt ist) auf Slices zu verallgemeinern, und dann wird dieses trait ersetzt oder abgeschafft.
///
pub trait SlicePattern {
    /// Der Elementtyp des Slice, auf dem abgeglichen wird.
    type Item;

    /// Derzeit benötigen die Verbraucher von `SlicePattern` eine Scheibe.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}