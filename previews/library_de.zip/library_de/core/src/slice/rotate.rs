// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Dreht den Bereich `[mid-left, mid+right)` so, dass das Element bei `mid` das erste Element wird.Dreht den Bereich `left`-Elemente entsprechend nach links oder `right`-Elemente nach rechts.
///
/// # Safety
///
/// Der angegebene Bereich muss zum Lesen und Schreiben gültig sein.
///
/// # Algorithm
///
/// Algorithmus 1 wird für kleine Werte von `left + right` oder für große `T` verwendet.
/// Die Elemente werden nacheinander ab `mid - left` in ihre endgültigen Positionen gebracht und um die `right`-Schritte modulo `left + right` vorgerückt, sodass nur eine temporäre Position benötigt wird.
/// Schließlich kommen wir wieder bei `mid - left` an.
/// Wenn `gcd(left + right, right)` jedoch nicht 1 ist, wurden bei den obigen Schritten Elemente übersprungen.
/// Beispielsweise:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Glücklicherweise ist die Anzahl der übersprungenen Elemente zwischen den finalisierten Elementen immer gleich, sodass wir einfach unsere Startposition versetzen und mehr Runden machen können (die Gesamtzahl der Runden ist der `gcd(left + right, right)` value).
///
/// Das Endergebnis ist, dass alle Elemente einmal und nur einmal finalisiert werden.
///
/// Algorithmus 2 wird verwendet, wenn `left + right` groß ist, `min(left, right)` jedoch klein genug ist, um auf einen Stapelpuffer zu passen.
/// Die `min(left, right)`-Elemente werden in den Puffer kopiert, `memmove` wird auf die anderen angewendet und die Elemente im Puffer werden zurück in das Loch auf der gegenüberliegenden Seite ihres Ursprungs verschoben.
///
/// Algorithmen, die vektorisiert werden können, übertreffen die oben genannten, sobald `left + right` groß genug wird.
/// Algorithmus 1 kann durch Aufteilen und Ausführen vieler Runden gleichzeitig vektorisiert werden. Es gibt jedoch im Durchschnitt zu wenige Runden, bis `left + right` enorm ist und der schlimmste Fall einer einzelnen Runde immer vorliegt.
/// Stattdessen verwendet Algorithmus 3 das wiederholte Austauschen von `min(left, right)`-Elementen, bis ein kleineres Rotationsproblem übrig bleibt.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// Bei `left < right` erfolgt der Austausch stattdessen von links.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. Die folgenden Algorithmen können fehlschlagen, wenn diese Fälle nicht überprüft werden
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithmus 1 Mikrobenchmarks zeigen an, dass die durchschnittliche Leistung für zufällige Verschiebungen bis etwa `left + right == 32` besser ist, die Leistung im ungünstigsten Fall jedoch gegen 16 ausgeglichen ist.
            // 24 wurde als Mittelweg gewählt.
            // Wenn die Größe von `T` größer als 4 "usize" ist, übertrifft dieser Algorithmus auch andere Algorithmen.
            //
            //
            let x = unsafe { mid.sub(left) };
            // Beginn der ersten Runde
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kann vorab durch Berechnen von `gcd(left + right, right)` gefunden werden, aber es ist schneller, eine Schleife zu erstellen, die den gcd als Nebeneffekt berechnet, als den Rest des Blocks
            //
            //
            let mut gcd = right;
            // Benchmarks zeigen, dass es schneller ist, Provisorien vollständig auszutauschen, anstatt eine temporäre einmal zu lesen, rückwärts zu kopieren und diese temporäre dann ganz am Ende zu schreiben.
            // Dies ist möglicherweise auf die Tatsache zurückzuführen, dass beim Austauschen oder Ersetzen von Provisorien nur eine Speicheradresse in der Schleife verwendet wird, anstatt zwei verwalten zu müssen.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // Anstatt `i` zu inkrementieren und dann zu überprüfen, ob es außerhalb der Grenzen liegt, prüfen wir, ob `i` beim nächsten Inkrement außerhalb der Grenzen liegt.
                // Dies verhindert das Umbrechen von Zeigern oder `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // Ende der ersten Runde
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // Diese Bedingung muss hier sein, wenn `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // Beende das Stück mit mehr Runden
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ist kein Typ mit der Größe Null, daher ist es in Ordnung, durch seine Größe zu teilen.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithmus 2 Der `[T; 0]` soll hier sicherstellen, dass dieser für T angemessen ausgerichtet ist
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithmus 3 Es gibt eine alternative Art des Austauschs, bei der ermittelt wird, wo sich der letzte Austausch dieses Algorithmus befindet, und der Austausch mit diesem letzten Block erfolgt, anstatt benachbarte Blöcke auszutauschen, wie dies bei diesem Algorithmus der Fall ist. Dieser Weg ist jedoch immer noch schneller.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithmus 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}