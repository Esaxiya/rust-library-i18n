//! Kostenlose Funktionen zum Erstellen von `&[T]` und `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Bildet aus einem Zeiger und einer Länge ein Slice.
///
/// Das `len`-Argument ist die Anzahl der **Elemente**, nicht die Anzahl der Bytes.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `data` muss [valid] für Lesevorgänge für `len * mem::size_of::<T>()` viele Bytes sein, und es muss richtig ausgerichtet sein.Dies bedeutet insbesondere:
///
///     * Der gesamte Speicherbereich dieses Slice muss in einem einzelnen zugewiesenen Objekt enthalten sein!
///       Slices können sich niemals über mehrere zugewiesene Objekte erstrecken.In [below](#incorrect-usage) finden Sie ein Beispiel, das dies fälschlicherweise nicht berücksichtigt.
///     * `data` muss ungleich Null sein und auch für Slices mit der Länge Null ausgerichtet sein.
///     Ein Grund dafür ist, dass Optimierungen des Enum-Layouts davon abhängen können, dass Referenzen (einschließlich Slices beliebiger Länge) ausgerichtet und nicht null sind, um sie von anderen Daten zu unterscheiden.
///     Mit [`NonNull::dangling()`] können Sie einen Zeiger erhalten, der als `data` für Slices mit der Länge Null verwendet werden kann.
///
/// * `data` muss auf `len` aufeinanderfolgende ordnungsgemäß initialisierte Werte vom Typ `T` zeigen.
///
/// * Der Speicher, auf den das zurückgegebene Slice verweist, darf für die Dauer der Lebensdauer `'a` nicht mutiert werden, außer innerhalb eines `UnsafeCell`.
///
/// * Die Gesamtgröße `len * mem::size_of::<T>()` des Slice darf nicht größer als `isize::MAX` sein.
///   Siehe die Sicherheitsdokumentation von [`pointer::offset`].
///
/// # Caveat
///
/// Die Lebensdauer des zurückgegebenen Slice wird aus seiner Verwendung abgeleitet.
/// Um einen versehentlichen Missbrauch zu vermeiden, wird empfohlen, die Lebensdauer an die im Kontext sichere Quelllebensdauer zu binden, z. B. durch Bereitstellung einer Hilfsfunktion, die die Lebensdauer eines Hostwerts für das Slice übernimmt, oder durch explizite Anmerkungen.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // Manifestieren Sie ein Slice für ein einzelnes Element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Falsche Verwendung
///
/// Die folgende `join_slices`-Funktion ist **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Die obige Behauptung stellt sicher, dass `fst` und `snd` zusammenhängend sind, sie können jedoch weiterhin in _different allocated objects_ enthalten sein. In diesem Fall ist das Erstellen dieses Slice ein undefiniertes Verhalten.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` und `b` sind unterschiedliche zugewiesene Objekte ...
///     let a = 42;
///     let b = 27;
///     // ... die dennoch zusammenhängend in Erinnerung bleiben können: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `from_raw_parts` einhalten.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Führt die gleiche Funktionalität wie [`from_raw_parts`] aus, außer dass ein veränderbares Slice zurückgegeben wird.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `data` muss für Lese-und Schreibvorgänge für `len * mem::size_of::<T>()` viele Bytes [valid] sein und muss korrekt ausgerichtet sein.Dies bedeutet insbesondere:
///
///     * Der gesamte Speicherbereich dieses Slice muss in einem einzelnen zugewiesenen Objekt enthalten sein!
///       Slices können sich niemals über mehrere zugewiesene Objekte erstrecken.
///     * `data` muss ungleich Null sein und auch für Slices mit der Länge Null ausgerichtet sein.
///     Ein Grund dafür ist, dass Optimierungen des Enum-Layouts davon abhängen können, dass Referenzen (einschließlich Slices beliebiger Länge) ausgerichtet und nicht null sind, um sie von anderen Daten zu unterscheiden.
///
///     Mit [`NonNull::dangling()`] können Sie einen Zeiger erhalten, der als `data` für Slices mit der Länge Null verwendet werden kann.
///
/// * `data` muss auf `len` aufeinanderfolgende ordnungsgemäß initialisierte Werte vom Typ `T` zeigen.
///
/// * Auf den Speicher, auf den das zurückgegebene Slice verweist, darf für die Dauer der Lebensdauer `'a` nicht über einen anderen Zeiger (der nicht vom Rückgabewert abgeleitet ist) zugegriffen werden.
///   Sowohl Lese-als auch Schreibzugriffe sind verboten.
///
/// * Die Gesamtgröße `len * mem::size_of::<T>()` des Slice darf nicht größer als `isize::MAX` sein.
///   Siehe die Sicherheitsdokumentation von [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `from_raw_parts_mut` einhalten.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konvertiert einen Verweis auf T in einen Slice der Länge 1 (ohne zu kopieren).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konvertiert einen Verweis auf T in einen Slice der Länge 1 (ohne zu kopieren).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}