//! Makros, die von Iteratoren von Slice verwendet werden.

// Inlining is_empty und len machen einen großen Leistungsunterschied
macro_rules! is_empty {
    // Die Art und Weise, wie wir die Länge eines ZST-Iterators codieren, funktioniert sowohl für ZST als auch für Nicht-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Um einige Grenzprüfungen zu vermeiden (siehe `position`), berechnen wir die Länge auf etwas unerwartete Weise.
// (Getestet durch "Codegen/Slice-Position-Bounds-Check".)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // Wir werden manchmal in einem unsicheren Block verwendet

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Diese _cannot_ verwenden `unchecked_sub`, da wir auf das Umbrechen angewiesen sind, um die Länge langer ZST-Slice-Iteratoren darzustellen.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Wir wissen, dass `start <= end` also besser kann als `offset_from`, das signiert handeln muss.
            // Indem wir hier die entsprechenden Flags setzen, können wir LLVM dies mitteilen, wodurch es hilft, Grenzprüfungen zu entfernen.
            // SICHERHEIT: Durch den Typ invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Indem LLVM auch mitgeteilt wird, dass die Zeiger durch ein genaues Vielfaches der Typgröße voneinander getrennt sind, kann `len() == 0` anstelle von `(end - start) < size` auf `start == end` optimiert werden.
            //
            // SICHERHEIT: Durch die Typinvariante werden die Zeiger so ausgerichtet, dass die
            //         Der Abstand zwischen ihnen muss ein Vielfaches der Spitzengröße sein
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Die gemeinsame Definition der `Iter`-und `IterMut`-Iteratoren
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Gibt das erste Element zurück und verschiebt den Start des Iterators um 1 vorwärts.
        // Verbessert die Leistung im Vergleich zu einer Inline-Funktion erheblich.
        // Der Iterator darf nicht leer sein.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Gibt das letzte Element zurück und verschiebt das Ende des Iterators um 1 rückwärts.
        // Verbessert die Leistung im Vergleich zu einer Inline-Funktion erheblich.
        // Der Iterator darf nicht leer sein.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Verkleinert den Iterator, wenn T eine ZST ist, indem das Ende des Iterators um `n` rückwärts verschoben wird.
        // `n` darf `self.len()` nicht überschreiten.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Hilfsfunktion zum Erstellen eines Slice aus dem Iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SICHERHEIT: Der Iterator wurde aus einem Slice mit Zeiger erstellt
                // `self.ptr` und Länge `len!(self)`.
                // Dies garantiert, dass alle Voraussetzungen für `from_raw_parts` erfüllt sind.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Hilfsfunktion zum Vorwärtsbewegen des Starts des Iterators um `offset`-Elemente, wobei der alte Start zurückgegeben wird.
            //
            // Unsicher, da der Offset `self.len()` nicht überschreiten darf.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SICHERHEIT: Der Anrufer garantiert, dass `offset` `self.len()` nicht überschreitet.
                    // Dieser neue Zeiger befindet sich also in `self` und ist somit garantiert nicht null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Hilfsfunktion zum Verschieben des Endes des Iterators um `offset`-Elemente nach hinten, wobei das neue Ende zurückgegeben wird.
            //
            // Unsicher, da der Offset `self.len()` nicht überschreiten darf.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SICHERHEIT: Der Anrufer garantiert, dass `offset` `self.len()` nicht überschreitet.
                    // Dies garantiert, dass ein `isize` nicht überläuft.
                    // Der resultierende Zeiger befindet sich auch in den Grenzen von `slice`, wodurch die anderen Anforderungen für `offset` erfüllt werden.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // könnte mit Slices implementiert werden, aber dies vermeidet Grenzprüfungen

                // SICHERHEIT: `assume`-Aufrufe sind seit dem Startzeiger eines Slice sicher
                // muss nicht null sein, und Slices über Nicht-ZSTs müssen auch einen Endzeiger ungleich null haben.
                // Der Aufruf von `next_unchecked!` ist sicher, da wir zuerst prüfen, ob der Iterator leer ist.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dieser Iterator ist jetzt leer.
                    if mem::size_of::<T>() == 0 {
                        // Wir müssen es so machen, da `ptr` möglicherweise nie 0 ist, `end` jedoch (aufgrund von Wrapping).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SICHERHEIT: Ende kann nicht 0 sein, wenn T nicht ZST ist, weil ptr nicht 0 ist und Ende>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SICHERHEIT: Wir sind in Grenzen.`post_inc_start` macht auch für ZSTs das Richtige.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Wir überschreiben die Standardimplementierung, die `try_fold` verwendet, da diese einfache Implementierung weniger LLVM-IR generiert und schneller zu kompilieren ist.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Wir überschreiben die Standardimplementierung, die `try_fold` verwendet, da diese einfache Implementierung weniger LLVM-IR generiert und schneller zu kompilieren ist.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Wir überschreiben die Standardimplementierung, die `try_fold` verwendet, da diese einfache Implementierung weniger LLVM-IR generiert und schneller zu kompilieren ist.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Wir überschreiben die Standardimplementierung, die `try_fold` verwendet, da diese einfache Implementierung weniger LLVM-IR generiert und schneller zu kompilieren ist.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Wir überschreiben die Standardimplementierung, die `try_fold` verwendet, da diese einfache Implementierung weniger LLVM-IR generiert und schneller zu kompilieren ist.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Wir überschreiben die Standardimplementierung, die `try_fold` verwendet, da diese einfache Implementierung weniger LLVM-IR generiert und schneller zu kompilieren ist.
            // Außerdem vermeidet der `assume` eine Überprüfung der Grenzen.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SICHERHEIT: Wir sind garantiert durch die Schleifeninvariante in Grenzen:
                        // Bei `i >= n` gibt `self.next()` `None` zurück und die Schleife wird unterbrochen.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Wir überschreiben die Standardimplementierung, die `try_fold` verwendet, da diese einfache Implementierung weniger LLVM-IR generiert und schneller zu kompilieren ist.
            // Außerdem vermeidet der `assume` eine Überprüfung der Grenzen.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SICHERHEIT: `i` muss niedriger als `n` sein, da es bei `n` beginnt
                        // und nimmt nur ab.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SICHERHEIT: Der Anrufer muss garantieren, dass sich `i` in Grenzen von befindet
                // Das zugrunde liegende Slice, sodass `i` ein `isize` nicht überlaufen kann, und die zurückgegebenen Referenzen beziehen sich garantiert auf ein Element des Slice und sind somit garantiert gültig.
                //
                // Beachten Sie auch, dass der Aufrufer auch garantiert, dass wir nie wieder mit demselben Index aufgerufen werden und dass keine anderen Methoden aufgerufen werden, die auf diese Untergruppe zugreifen. Daher gilt, dass die zurückgegebene Referenz im Fall von veränderbar ist
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // könnte mit Slices implementiert werden, aber dies vermeidet Grenzprüfungen

                // SICHERHEIT: `assume`-Aufrufe sind sicher, da der Startzeiger eines Slice nicht null sein darf.
                // und Slices über Nicht-ZSTs müssen auch einen Nicht-Null-Endzeiger haben.
                // Der Aufruf von `next_back_unchecked!` ist sicher, da wir zuerst prüfen, ob der Iterator leer ist.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dieser Iterator ist jetzt leer.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SICHERHEIT: Wir sind in Grenzen.`pre_dec_end` macht auch für ZSTs das Richtige.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}