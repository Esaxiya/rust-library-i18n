//! Der libcore prelude
//!
//! Dieses Modul ist für Benutzer von libcore gedacht, die ebenfalls keine Verknüpfung zu libstd herstellen.
//! Dieses Modul wird standardmäßig importiert, wenn `#![no_std]` auf die gleiche Weise wie das prelude der Standardbibliothek verwendet wird.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Die 2015er Version des Kerns prelude.
///
/// Weitere Informationen finden Sie im [module-level documentation](self).
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Die 2018-Version des Kerns prelude.
///
/// Weitere Informationen finden Sie im [module-level documentation](self).
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Die 2021-Version des Kerns prelude.
///
/// Weitere Informationen finden Sie im [module-level documentation](self).
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Fügen Sie weitere Dinge hinzu.
}