//! Gemeinsam nutzbare veränderbare Container.
//!
//! Die Speichersicherheit von Rust basiert auf dieser Regel: Bei einem Objekt `T` kann nur eines der folgenden Elemente verwendet werden:
//!
//! - Mehrere unveränderliche Verweise (`&T`) auf das Objekt (auch als **Aliasing** bezeichnet).
//! - Eine veränderbare Referenz ("&mut T") auf das Objekt haben (auch als "Veränderlichkeit" bekannt).
//!
//! Dies wird vom Rust-Compiler erzwungen.Es gibt jedoch Situationen, in denen diese Regel nicht flexibel genug ist.Manchmal ist es erforderlich, mehrere Verweise auf ein Objekt zu haben und es dennoch zu mutieren.
//!
//! Es gibt gemeinsam nutzbare veränderbare Container, um die Veränderlichkeit auch bei Vorhandensein von Aliasing auf kontrollierte Weise zu ermöglichen.Sowohl [`Cell<T>`] als auch [`RefCell<T>`] ermöglichen dies mit einem einzigen Thread.
//! Weder `Cell<T>` noch `RefCell<T>` sind jedoch threadsicher (sie implementieren [`Sync`] nicht).
//! Wenn Sie Aliasing und Mutation zwischen mehreren Threads durchführen müssen, können Sie die Typen [`Mutex<T>`], [`RwLock<T>`] oder [`atomic`] verwenden.
//!
//! Werte der Typen `Cell<T>` und `RefCell<T>` können durch gemeinsame Referenzen mutiert werden (d. H.
//! der übliche `&T`-Typ), während die meisten Rust-Typen nur durch eindeutige (`&mut T`) Referenzen mutiert werden können.
//! Wir sagen, dass `Cell<T>` und `RefCell<T>` im Gegensatz zu typischen Rust-Typen, die eine "vererbte Mutabilität" aufweisen, eine "innere Mutabilität" bieten.
//!
//! Zelltypen gibt es in zwei Varianten: `Cell<T>` und `RefCell<T>`.`Cell<T>` implementiert die innere Veränderlichkeit, indem Werte in den `Cell<T>` hinein und aus ihm heraus verschoben werden.
//! Um Referenzen anstelle von Werten zu verwenden, muss der Typ `RefCell<T>` verwendet werden, um vor dem Mutieren eine Schreibsperre zu erhalten.`Cell<T>` bietet Methoden zum Abrufen und Ändern des aktuellen Innenwerts:
//!
//!  - Bei Typen, die [`Copy`] implementieren, ruft die [`get`](Cell::get)-Methode den aktuellen Innenwert ab.
//!  - Bei Typen, die [`Default`] implementieren, ersetzt die [`take`](Cell::take)-Methode den aktuellen Innenwert durch [`Default::default()`] und gibt den ersetzten Wert zurück.
//!  - Für alle Typen ersetzt die [`replace`](Cell::replace)-Methode den aktuellen Innenwert und gibt den ersetzten Wert zurück, und die [`into_inner`](Cell::into_inner)-Methode verwendet den `Cell<T>` und gibt den Innenwert zurück.
//!  Darüber hinaus ersetzt die [`set`](Cell::set)-Methode den inneren Wert und löscht den ersetzten Wert.
//!
//! `RefCell<T>` verwendet die Lebensdauern von Rust, um 'dynamisches Ausleihen' zu implementieren, ein Prozess, bei dem man temporären, exklusiven, veränderlichen Zugriff auf den inneren Wert beanspruchen kann.
//! Ausleihen für `RefCell<T>`s werden 'zur Laufzeit' verfolgt, im Gegensatz zu den nativen Referenztypen von Rust, die zur Kompilierungszeit vollständig statisch verfolgt werden.
//! Da `RefCell<T>`-Ausleihen dynamisch sind, kann versucht werden, einen Wert auszuleihen, der bereits veränderlich ausgeliehen ist.In diesem Fall wird der Thread panic erstellt.
//!
//! # Wann sollte man die innere Veränderlichkeit wählen?
//!
//! Die häufigere vererbte Mutabilität, bei der ein eindeutiger Zugriff erforderlich ist, um einen Wert zu mutieren, ist eines der wichtigsten Sprachelemente, mit denen Rust stark über Zeiger-Aliasing nachdenken und Absturzfehler statisch verhindern kann.
//! Aus diesem Grund wird die ererbte Veränderlichkeit bevorzugt, und die innere Veränderlichkeit ist ein letzter Ausweg.
//! Da Zelltypen eine Mutation ermöglichen, wo sie sonst nicht erlaubt wäre, kann es vorkommen, dass eine innere Mutabilität angemessen ist oder sogar *verwendet* werden muss, z
//!
//! * Einführung der Veränderlichkeit 'inside' von etwas Unveränderlichem
//! * Implementierungsdetails von logisch unveränderlichen Methoden.
//! * Mutierende Implementierungen von [`Clone`].
//!
//! ## Einführung der Veränderlichkeit 'inside' von etwas Unveränderlichem
//!
//! Viele gemeinsam genutzte Smart-Pointer-Typen, einschließlich [`Rc<T>`] und [`Arc<T>`], bieten Container, die geklont und von mehreren Parteien gemeinsam genutzt werden können.
//! Da die enthaltenen Werte möglicherweise mit einem Multiplikationsalias versehen sind, können sie nur mit `&` und nicht mit `&mut` ausgeliehen werden.
//! Ohne Zellen wäre es unmöglich, Daten innerhalb dieser intelligenten Zeiger überhaupt zu mutieren.
//!
//! Es ist dann sehr üblich, einen `RefCell<T>` in gemeinsam genutzte Zeigertypen zu setzen, um die Veränderlichkeit wieder einzuführen:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Erstellen Sie einen neuen Block, um den Umfang der dynamischen Ausleihe zu begrenzen
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Beachten Sie, dass das nachfolgende Ausleihen einen dynamischen Thread panic verursachen würde, wenn das vorherige Ausleihen des Caches nicht aus dem Gültigkeitsbereich geraten wäre.
//!     //
//!     // Dies ist die größte Gefahr bei der Verwendung von `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Beachten Sie, dass in diesem Beispiel `Rc<T>` und nicht `Arc<T>` verwendet wird.`RefCell<T>`s sind für Single-Threaded-Szenarien.Erwägen Sie die Verwendung von [`RwLock<T>`] oder [`Mutex<T>`], wenn Sie in einer Multithread-Situation eine gemeinsame Veränderbarkeit benötigen.
//!
//! ## Implementierungsdetails von logisch unveränderlichen Methoden
//!
//! Gelegentlich kann es wünschenswert sein, in einer API nicht zu zeigen, dass eine Mutation "under the hood" stattfindet.
//! Dies kann daran liegen, dass die Operation logischerweise unveränderlich ist, aber z. B. zwingt das Caching die Implementierung, eine Mutation durchzuführen.oder weil Sie eine Mutation verwenden müssen, um eine trait-Methode zu implementieren, die ursprünglich für `&self` definiert wurde.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Teure Berechnungen gehen hier
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutierende Implementierungen von `Clone`
//!
//! Dies ist einfach ein spezieller, aber häufiger Fall des vorherigen: Verstecken der Veränderlichkeit für Operationen, die unveränderlich erscheinen.
//! Es wird erwartet, dass die [`clone`](Clone::clone)-Methode den Quellwert nicht ändert, und es wird deklariert, dass sie `&self` und nicht `&mut self` verwendet.
//! Daher müssen für jede Mutation, die bei der `clone`-Methode auftritt, Zelltypen verwendet werden.
//! Beispielsweise behält [`Rc<T>`] seine Referenzzählungen innerhalb eines `Cell<T>` bei.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Ein veränderlicher Speicherort.
///
/// # Examples
///
/// In diesem Beispiel sehen Sie, dass `Cell<T>` die Mutation innerhalb einer unveränderlichen Struktur aktiviert.
/// Mit anderen Worten, es aktiviert "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // FEHLER: `my_struct` ist unveränderlich
/// // my_struct.regular_field =neuer_Wert;
///
/// // WERKE: Obwohl `my_struct` unveränderlich ist, ist `special_field` ein `Cell`,
/// // was immer mutiert werden kann
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Weitere Informationen finden Sie im [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Erstellt ein `Cell<T>` mit dem `Default`-Wert für T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Erstellt ein neues `Cell` mit dem angegebenen Wert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Legt den enthaltenen Wert fest.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Vertauscht die Werte von zwei Zellen.
    /// Der Unterschied zu `std::mem::swap` besteht darin, dass für diese Funktion keine `&mut`-Referenz erforderlich ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SICHERHEIT: Dies kann riskant sein, wenn es von separaten Threads, aber `Cell` aufgerufen wird
        // ist `!Sync`, also wird dies nicht passieren.
        // Dies macht auch keine Zeiger ungültig, da `Cell` sicherstellt, dass nichts anderes auf eine dieser "Zellen" zeigt.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ersetzt den enthaltenen Wert durch `val` und gibt den alten enthaltenen Wert zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SICHERHEIT: Dies kann zu Datenrennen führen, wenn es von einem separaten Thread aufgerufen wird.
        // Aber `Cell` ist `!Sync`, also wird dies nicht passieren.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Packt den Wert aus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Gibt eine Kopie des enthaltenen Werts zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SICHERHEIT: Dies kann zu Datenrennen führen, wenn es von einem separaten Thread aufgerufen wird.
        // Aber `Cell` ist `!Sync`, also wird dies nicht passieren.
        unsafe { *self.value.get() }
    }

    /// Aktualisiert den enthaltenen Wert mithilfe einer Funktion und gibt den neuen Wert zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Gibt einen Rohzeiger auf die zugrunde liegenden Daten in dieser Zelle zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Gibt einen veränderlichen Verweis auf die zugrunde liegenden Daten zurück.
    ///
    /// Dieser Aufruf leiht `Cell` veränderlich (zur Kompilierungszeit) aus, was garantiert, dass wir die einzige Referenz besitzen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Gibt einen `&Cell<T>` von einem `&mut T` zurück
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SICHERHEIT: `&mut` gewährleistet einen eindeutigen Zugriff.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Nimmt den Wert der Zelle und lässt `Default::default()` an seiner Stelle.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Gibt einen `&[Cell<T>]` von einem `&Cell<[T]>` zurück
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SICHERHEIT: `Cell<T>` hat das gleiche Speicherlayout wie `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Ein veränderlicher Speicherort mit dynamisch überprüften Ausleihregeln
///
/// Weitere Informationen finden Sie im [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Ein von [`RefCell::try_borrow`] zurückgegebener Fehler.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Ein von [`RefCell::try_borrow_mut`] zurückgegebener Fehler.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positive Werte geben die Anzahl der aktiven `Ref` an.Negative Werte geben die Anzahl der aktiven `RefMut` an.
// Mehrere "RefMut" können gleichzeitig nur aktiv sein, wenn sie sich auf unterschiedliche, nicht überlappende Komponenten eines `RefCell` beziehen (z. B. unterschiedliche Bereiche eines Slice).
//
// `Ref` und `RefMut` sind beide zwei Wörter groß, und daher wird es wahrscheinlich nie genug "Ref" oder "RefMut" geben, um die Hälfte des `usize`-Bereichs zu überlaufen.
// Daher wird ein `BorrowFlag` wahrscheinlich niemals über-oder unterlaufen.
// Dies ist jedoch keine Garantie, da ein pathologisches Programm wiederholt mem::forget-Refs oder RefMuts erstellen könnte.
// Daher muss der gesamte Code explizit auf Überlauf und Unterlauf prüfen, um Unsicherheit zu vermeiden, oder sich zumindest im Falle eines Überlaufs oder Unterlaufs korrekt verhalten (siehe z. B. BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Erstellt ein neues `RefCell` mit `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Verbraucht den `RefCell` und gibt den umschlossenen Wert zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Da diese Funktion `self` (das `RefCell`) als Wert verwendet, überprüft der Compiler statisch, ob es derzeit nicht ausgeliehen ist.
        //
        self.value.into_inner()
    }

    /// Ersetzt den umschlossenen Wert durch einen neuen und gibt den alten Wert zurück, ohne einen der Werte zu deinitialisieren.
    ///
    ///
    /// Diese Funktion entspricht [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, wenn der Wert aktuell ausgeliehen ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ersetzt den umschlossenen Wert durch einen neuen, der aus `f` berechnet wurde, und gibt den alten Wert zurück, ohne einen der Werte zu deinitialisieren.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn der Wert aktuell ausgeliehen ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Tauscht den umschlossenen Wert von `self` gegen den umschlossenen Wert von `other` aus, ohne einen der Werte zu deinitialisieren.
    ///
    ///
    /// Diese Funktion entspricht [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Leiht den verpackten Wert unveränderlich aus.
    ///
    /// Die Ausleihe dauert so lange, bis der zurückgegebene `Ref` den Gültigkeitsbereich verlässt.
    /// Es können mehrere unveränderliche Kredite gleichzeitig aufgenommen werden.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Wert derzeit veränderlich ausgeliehen ist.
    /// Verwenden Sie für eine nicht in Panik geratene Variante [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Ein Beispiel für panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Leiht den umschlossenen Wert unveränderlich aus und gibt einen Fehler zurück, wenn der Wert derzeit veränderlich ausgeliehen ist.
    ///
    ///
    /// Die Ausleihe dauert so lange, bis der zurückgegebene `Ref` den Gültigkeitsbereich verlässt.
    /// Es können mehrere unveränderliche Kredite gleichzeitig aufgenommen werden.
    ///
    /// Dies ist die nicht in Panik geratene Variante von [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SICHERHEIT: `BorrowRef` stellt sicher, dass nur unveränderlicher Zugriff besteht
            // auf den Wert während ausgeliehen.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Leiht den umschlossenen Wert veränderlich aus.
    ///
    /// Das Ausleihen dauert so lange, bis das zurückgegebene `RefMut` oder alle daraus abgeleiteten "RefMut" den Gültigkeitsbereich verlassen.
    ///
    /// Der Wert kann nicht ausgeliehen werden, solange dieser Kredit aktiv ist.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Wert aktuell ausgeliehen ist.
    /// Verwenden Sie für eine nicht in Panik geratene Variante [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Ein Beispiel für panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Leiht den umschlossenen Wert veränderlich aus und gibt einen Fehler zurück, wenn der Wert gerade ausgeliehen ist.
    ///
    ///
    /// Das Ausleihen dauert so lange, bis das zurückgegebene `RefMut` oder alle daraus abgeleiteten "RefMut" den Gültigkeitsbereich verlassen.
    /// Der Wert kann nicht ausgeliehen werden, solange dieser Kredit aktiv ist.
    ///
    /// Dies ist die nicht in Panik geratene Variante von [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SICHERHEIT: `BorrowRef` garantiert einen einzigartigen Zugriff.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Gibt einen Rohzeiger auf die zugrunde liegenden Daten in dieser Zelle zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Gibt einen veränderlichen Verweis auf die zugrunde liegenden Daten zurück.
    ///
    /// Dieser Aufruf leiht `RefCell` veränderlich aus (zur Kompilierungszeit), sodass keine dynamischen Überprüfungen erforderlich sind.
    ///
    /// Seien Sie jedoch vorsichtig: Diese Methode erwartet, dass `self` veränderbar ist, was bei Verwendung eines `RefCell` im Allgemeinen nicht der Fall ist.
    ///
    /// Schauen Sie sich stattdessen die [`borrow_mut`]-Methode an, wenn `self` nicht veränderbar ist.
    ///
    /// Bitte beachten Sie auch, dass diese Methode nur für besondere Umstände geeignet ist und normalerweise nicht Ihren Wünschen entspricht.
    /// Verwenden Sie im Zweifelsfall stattdessen [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Machen Sie die Auswirkung von durchgesickerten Schutzvorrichtungen auf den Ausleihstatus des `RefCell` rückgängig.
    ///
    /// Dieser Aufruf ähnelt [`get_mut`], ist jedoch spezialisierter.
    /// Es leiht `RefCell` veränderlich aus, um sicherzustellen, dass keine Ausleihen vorhanden sind, und setzt dann die Statusverfolgung für gemeinsam genutzte Ausleihen zurück.
    /// Dies ist relevant, wenn einige `Ref`-oder `RefMut`-Kredite ausgelaufen sind.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Leiht den umschlossenen Wert unveränderlich aus und gibt einen Fehler zurück, wenn der Wert derzeit veränderlich ausgeliehen ist.
    ///
    /// # Safety
    ///
    /// Im Gegensatz zu `RefCell::borrow` ist diese Methode unsicher, da kein `Ref` zurückgegeben wird und das Ausleih-Flag unberührt bleibt.
    /// Das unveränderliche Ausleihen des `RefCell`, während die von dieser Methode zurückgegebene Referenz aktiv ist, ist ein undefiniertes Verhalten.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SICHERHEIT: Wir überprüfen, ob derzeit niemand aktiv schreibt, aber es ist so
            // Es liegt in der Verantwortung des Anrufers, sicherzustellen, dass niemand schreibt, bis die zurückgegebene Referenz nicht mehr verwendet wird.
            // Außerdem bezieht sich `self.value.get()` auf den Wert von `self` und ist somit garantiert für die Lebensdauer von `self` gültig.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Nimmt den umschlossenen Wert und lässt `Default::default()` an seiner Stelle.
    ///
    /// # Panics
    ///
    /// Panics, wenn der Wert aktuell ausgeliehen ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, wenn der Wert derzeit veränderlich ausgeliehen ist.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Erstellt ein `RefCell<T>` mit dem `Default`-Wert für T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, wenn der Wert in `RefCell` derzeit ausgeliehen ist.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Inkrementelle Ausleihe kann in folgenden Fällen zu einem nicht lesbaren Wert (<=0) führen:
            // 1. Es war <0, dh es gibt Ausleihe zum Schreiben, daher können wir aufgrund der Referenz-Aliasing-Regeln von Rust keine Ausleihe zum Lesen zulassen
            // 2.
            // Es war isize::MAX (die maximale Anzahl an Leseausleihen) und es lief über in isize::MIN (die maximale Anzahl an Schreibkrediten), sodass wir keine zusätzliche Leseausleihe zulassen können, da isize nicht so viele Leseausleihen darstellen kann (dies kann nur passieren, wenn Sie mem::forget mehr als eine kleine konstante Menge von `Ref`s, was keine gute Praxis ist)
            //
            //
            //
            //
            None
        } else {
            // Inkrementelle Kredite können in folgenden Fällen zu einem Lesewert (> 0) führen:
            // 1. Es war=0, dh es wurde nicht ausgeliehen, und wir nehmen das erste gelesene Ausleihen
            // 2. Es war> 0 und <isize::MAX, dh
            // Es gab gelesene Ausleihen, und isize ist groß genug, um eine weitere gelesene Ausleihe darzustellen
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Da dieser Verweis vorhanden ist, wissen wir, dass das Ausleih-Flag ein Lese-Ausleihen ist.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Verhindern Sie, dass der Ausleihzähler in einen schriftlichen Ausleihbestand überläuft.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wickelt einen geliehenen Verweis auf einen Wert in eine `RefCell`-Box ein.
/// Ein Wrapper-Typ für einen unveränderlich geliehenen Wert von einem `RefCell<T>`.
///
/// Weitere Informationen finden Sie im [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopiert einen `Ref`.
    ///
    /// Der `RefCell` ist bereits unveränderlich ausgeliehen, daher kann dies nicht scheitern.
    ///
    /// Dies ist eine zugehörige Funktion, die als `Ref::clone(...)` verwendet werden muss.
    /// Eine `Clone`-Implementierung oder eine Methode würde die weit verbreitete Verwendung von `r.borrow().clone()` zum Klonen des Inhalts eines `RefCell` beeinträchtigen.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Erstellt einen neuen `Ref` für eine Komponente der ausgeliehenen Daten.
    ///
    /// Der `RefCell` ist bereits unveränderlich ausgeliehen, daher kann dies nicht scheitern.
    ///
    /// Dies ist eine zugehörige Funktion, die als `Ref::map(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Erstellt einen neuen `Ref` für eine optionale Komponente der ausgeliehenen Daten.
    /// Der ursprüngliche Schutz wird als `Err(..)` zurückgegeben, wenn der Verschluss `None` zurückgibt.
    ///
    /// Der `RefCell` ist bereits unveränderlich ausgeliehen, daher kann dies nicht scheitern.
    ///
    /// Dies ist eine zugehörige Funktion, die als `Ref::filter_map(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Teilt einen `Ref` in mehrere Refs für verschiedene Komponenten der ausgeliehenen Daten auf.
    ///
    /// Der `RefCell` ist bereits unveränderlich ausgeliehen, daher kann dies nicht scheitern.
    ///
    /// Dies ist eine zugehörige Funktion, die als `Ref::map_split(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// In einen Verweis auf die zugrunde liegenden Daten konvertieren.
    ///
    /// Der zugrunde liegende `RefCell` kann nie wieder ausleihbar ausgeliehen werden und erscheint immer bereits unveränderlich ausgeliehen.
    ///
    /// Es ist keine gute Idee, mehr als eine konstante Anzahl von Referenzen zu verlieren.
    /// Der `RefCell` kann unveränderlich wieder ausgeliehen werden, wenn insgesamt nur eine geringere Anzahl von Lecks aufgetreten ist.
    ///
    /// Dies ist eine zugehörige Funktion, die als `Ref::leak(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Durch das Vergessen dieses Ref stellen wir sicher, dass der Ausleihzähler in der RefCell innerhalb der Lebensdauer von `'b` nicht auf UNUSED zurückgesetzt werden kann.
        // Das Zurücksetzen des Referenzverfolgungsstatus würde eine eindeutige Referenz auf die ausgeliehene RefCell erfordern.
        // Aus der ursprünglichen Zelle können keine weiteren veränderlichen Referenzen erstellt werden.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Erstellt einen neuen `RefMut` für eine Komponente der ausgeliehenen Daten, z. B. eine Aufzählungsvariante.
    ///
    /// Der `RefCell` ist bereits veränderlich ausgeliehen, daher kann dies nicht fehlschlagen.
    ///
    /// Dies ist eine zugehörige Funktion, die als `RefMut::map(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): Leihscheck reparieren
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Erstellt einen neuen `RefMut` für eine optionale Komponente der ausgeliehenen Daten.
    /// Der ursprüngliche Schutz wird als `Err(..)` zurückgegeben, wenn der Verschluss `None` zurückgibt.
    ///
    /// Der `RefCell` ist bereits veränderlich ausgeliehen, daher kann dies nicht fehlschlagen.
    ///
    /// Dies ist eine zugehörige Funktion, die als `RefMut::filter_map(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): Leihscheck reparieren
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SICHERHEIT: Die Funktion behält eine exklusive Referenz für die Dauer bei
        // des Aufrufs über `orig`, und der Zeiger wird nur innerhalb des Funktionsaufrufs de-referenziert, ohne dass die exklusive Referenz entkommen kann.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SICHERHEIT: wie oben.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Teilt einen `RefMut` in mehrere RefMuts für verschiedene Komponenten der ausgeliehenen Daten auf.
    ///
    /// Das zugrunde liegende `RefCell` bleibt veränderlich ausgeliehen, bis beide zurückgegebenen "RefMut" den Geltungsbereich verlassen.
    ///
    /// Der `RefCell` ist bereits veränderlich ausgeliehen, daher kann dies nicht fehlschlagen.
    ///
    /// Dies ist eine zugehörige Funktion, die als `RefMut::map_split(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Konvertieren Sie in einen veränderlichen Verweis auf die zugrunde liegenden Daten.
    ///
    /// Der zugrunde liegende `RefCell` kann nicht erneut ausgeliehen werden und erscheint immer bereits veränderlich ausgeliehen, sodass der zurückgegebene Verweis der einzige Verweis auf das Innere ist.
    ///
    ///
    /// Dies ist eine zugehörige Funktion, die als `RefMut::leak(...)` verwendet werden muss.
    /// Eine Methode würde gleichnamige Methoden für den Inhalt eines `RefCell` stören, der über `Deref` verwendet wird.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Durch das Vergessen dieses BorrowRefMut stellen wir sicher, dass der Ausleihzähler in der RefCell innerhalb der Lebensdauer von `'b` nicht auf UNUSED zurückgesetzt werden kann.
        // Das Zurücksetzen des Referenzverfolgungsstatus würde eine eindeutige Referenz auf die ausgeliehene RefCell erfordern.
        // Innerhalb dieser Lebensdauer können keine weiteren Referenzen aus der ursprünglichen Zelle erstellt werden, sodass die aktuelle Ausleihe die einzige Referenz für die verbleibende Lebensdauer ist.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Im Gegensatz zu BorrowRefMut::clone wird new aufgerufen, um die Initiale zu erstellen
        // veränderbare Referenz, daher dürfen derzeit keine Referenzen vorhanden sein.
        // Während der Klon den veränderlichen Refcount erhöht, erlauben wir hier explizit nur den Übergang von UNUSED zu UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klont einen `BorrowRefMut`.
    //
    // Dies ist nur gültig, wenn jedes `BorrowRefMut` verwendet wird, um eine veränderbare Referenz auf einen bestimmten, nicht überlappenden Bereich des ursprünglichen Objekts zu verfolgen.
    //
    // Dies ist nicht in einem Clone-Impl enthalten, sodass Code dies nicht implizit aufruft.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Verhindern Sie, dass der Ausleihzähler unterläuft.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Ein Wrapper-Typ für einen veränderlich geliehenen Wert von einem `RefCell<T>`.
///
/// Weitere Informationen finden Sie im [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Das Kernprimitiv für die innere Mutabilität in Rust.
///
/// Wenn Sie eine Referenz `&T` haben, führt der Compiler normalerweise in Rust Optimierungen durch, basierend auf dem Wissen, dass `&T` auf unveränderliche Daten verweist.Das Mutieren dieser Daten, beispielsweise durch einen Alias oder durch Umwandeln eines `&T` in einen `&mut T`, wird als undefiniertes Verhalten angesehen.
/// `UnsafeCell<T>` Aufhebung der Unveränderlichkeitsgarantie für `&T`: Eine gemeinsame Referenz `&UnsafeCell<T>` kann auf Daten verweisen, die mutiert werden.Dies wird als "interior mutability" bezeichnet.
///
/// Alle anderen Typen, die interne Veränderbarkeit zulassen, wie z. B. `Cell<T>` und `RefCell<T>`, verwenden intern `UnsafeCell`, um ihre Daten zu verpacken.
///
/// Beachten Sie, dass nur die Unveränderlichkeitsgarantie für gemeinsam genutzte Referenzen von `UnsafeCell` betroffen ist.Die Eindeutigkeitsgarantie für veränderbare Referenzen bleibt unberührt.Es gibt *keine* legale Möglichkeit, Aliasing `&mut` zu erhalten, auch nicht mit `UnsafeCell<T>`.
///
/// Die `UnsafeCell`-API selbst ist technisch sehr einfach: [`.get()`] gibt Ihnen einen Rohzeiger `*mut T` auf seinen Inhalt.Es liegt an _you_ als Abstraktionsdesigner, diesen Rohzeiger korrekt zu verwenden.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Die genauen Rust-Aliasing-Regeln sind etwas im Fluss, aber die Hauptpunkte sind nicht umstritten:
///
/// - Wenn Sie eine sichere Referenz mit der Lebensdauer `'a` (entweder eine `&T`-oder eine `&mut T`-Referenz) erstellen, auf die über einen sicheren Code zugegriffen werden kann (z. B. weil Sie sie zurückgegeben haben), dürfen Sie auf die Daten in keiner Weise zugreifen, die dieser Referenz für den Rest widerspricht von `'a`.
/// Dies bedeutet beispielsweise, dass, wenn Sie den `*mut T` von einem `UnsafeCell<T>` nehmen und in einen `&T` umwandeln, die Daten in `T` unveränderlich bleiben müssen (natürlich modulo alle in `T` gefundenen `UnsafeCell`-Daten), bis die Lebensdauer dieser Referenz abläuft.
/// Wenn Sie eine `&mut T`-Referenz erstellen, die für sicheren Code freigegeben ist, dürfen Sie auf die Daten im `UnsafeCell` erst zugreifen, wenn diese Referenz abläuft.
///
/// - Sie müssen jederzeit Datenrennen vermeiden.Wenn mehrere Threads Zugriff auf dasselbe `UnsafeCell` haben, müssen alle Schreibvorgänge eine ordnungsgemäße Beziehung haben, bevor sie mit allen anderen Zugriffen in Beziehung stehen (oder Atomics verwenden).
///
/// Um das ordnungsgemäße Design zu unterstützen, werden die folgenden Szenarien für Single-Threaded-Code ausdrücklich als zulässig deklariert:
///
/// 1. Eine `&T`-Referenz kann für sicheren Code freigegeben werden und dort mit anderen `&T`-Referenzen koexistieren, jedoch nicht mit einer `&mut T`
///
/// 2. Eine `&mut T`-Referenz kann für den sicheren Code freigegeben werden, sofern weder andere `&mut T`-noch `&T`-Referenzen gleichzeitig vorhanden sind.Ein `&mut T` muss immer eindeutig sein.
///
/// Beachten Sie, dass das Mutieren des Inhalts eines `&UnsafeCell<T>` (auch wenn andere `&UnsafeCell<T>` auf die Zelle verweisen) in Ordnung ist (vorausgesetzt, Sie erzwingen die obigen Invarianten auf andere Weise), es jedoch immer noch undefiniertes Verhalten ist, mehrere `&mut UnsafeCell<T>`-Aliase zu haben.
/// Das heißt, `UnsafeCell` ist ein Wrapper, der für eine spezielle Interaktion mit _shared_ accesses (_i.e._ über eine `&UnsafeCell<_>`-Referenz entwickelt wurde.Beim Umgang mit _exclusive_ accesses (_e.g._ über `&mut UnsafeCell<_>` gibt es keinerlei Magie: Weder die Zelle noch der umschlossene Wert dürfen für die Dauer dieses `&mut`-Ausleihs als Alias verwendet werden.
///
/// Dies wird durch den [`.get_mut()`]-Accessor veranschaulicht, bei dem es sich um einen _safe_ getter handelt, der einen `&mut T` ergibt.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hier ist ein Beispiel, das zeigt, wie der Inhalt eines `UnsafeCell<_>` trotz mehrerer Referenzen, die die Zelle als Aliasing verwenden, solide mutiert werden kann:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Erhalten Sie mehrere/gemeinsam genutzte Verweise auf dasselbe `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SICHERHEIT: In diesem Bereich gibt es keine weiteren Verweise auf den Inhalt von `x`.
///     // So ist unsere effektiv einzigartig.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ausleihen-+
///     *p1_exclusive += 27; // |
/// } // <---------- kann nicht über diesen Punkt hinausgehen -------------------+
///
/// unsafe {
///     // SICHERHEIT: In diesem Bereich erwartet niemand exklusiven Zugriff auf die Inhalte von `x`.
///     // So können wir mehrere gemeinsame Zugriffe gleichzeitig haben.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Das folgende Beispiel zeigt die Tatsache, dass der exklusive Zugriff auf einen `UnsafeCell<T>` den exklusiven Zugriff auf seinen `T` impliziert:
///
/// ```rust
/// #![forbid(unsafe_code)] // mit exklusiven Zugriffen,
///                         // `UnsafeCell` ist ein transparenter No-Op-Wrapper, daher ist hier kein `unsafe` erforderlich.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Holen Sie sich einen eindeutigen Verweis auf `x`, der zur Kompilierungszeit überprüft wurde.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Mit einem exklusiven Verweis können wir den Inhalt kostenlos mutieren.
/// *p_unique.get_mut() = 0;
/// // Oder gleichwertig:
/// x = UnsafeCell::new(0);
///
/// // Wenn wir den Wert besitzen, können wir den Inhalt kostenlos extrahieren.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Erstellt eine neue Instanz von `UnsafeCell`, die den angegebenen Wert umschließt.
    ///
    ///
    /// Der gesamte Zugriff auf den inneren Wert über Methoden erfolgt über `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Packt den Wert aus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Ruft einen veränderlichen Zeiger auf den umschlossenen Wert ab.
    ///
    /// Dies kann auf einen Zeiger jeglicher Art umgewandelt werden.
    /// Stellen Sie sicher, dass der Zugriff beim Umwandeln in `&mut T` eindeutig ist (keine aktiven Referenzen, veränderbar oder nicht veränderbar), und stellen Sie sicher, dass beim Umwandeln in `&T` keine Mutationen oder veränderlichen Aliase vorhanden sind
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Wir können den Zeiger wegen #[repr(transparent)] einfach von `UnsafeCell<T>` auf `T` umwandeln.
        // Dies nutzt den Sonderstatus von libstd aus. Es gibt keine Garantie für Benutzercode, dass dies in future-Versionen des Compilers funktioniert!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Gibt einen veränderlichen Verweis auf die zugrunde liegenden Daten zurück.
    ///
    /// Dieser Aufruf leiht den `UnsafeCell` veränderlich aus (zur Kompilierungszeit), was garantiert, dass wir die einzige Referenz besitzen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Ruft einen veränderlichen Zeiger auf den umschlossenen Wert ab.
    /// Der Unterschied zu [`get`] besteht darin, dass diese Funktion einen Rohzeiger akzeptiert. Dies ist nützlich, um die Erstellung temporärer Referenzen zu vermeiden.
    ///
    /// Das Ergebnis kann in einen Zeiger beliebiger Art umgewandelt werden.
    /// Stellen Sie sicher, dass der Zugriff beim Umwandeln in `&mut T` eindeutig ist (keine aktiven Referenzen, veränderbar oder nicht veränderbar), und stellen Sie sicher, dass beim Umwandeln in `&T` keine Mutationen oder veränderlichen Aliase vorhanden sind.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Die schrittweise Initialisierung eines `UnsafeCell` erfordert `raw_get`, da für den Aufruf von `get` ein Verweis auf nicht initialisierte Daten erstellt werden muss:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Wir können den Zeiger wegen #[repr(transparent)] einfach von `UnsafeCell<T>` auf `T` umwandeln.
        // Dies nutzt den Sonderstatus von libstd aus. Es gibt keine Garantie für Benutzercode, dass dies in future-Versionen des Compilers funktioniert!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Erstellt ein `UnsafeCell` mit dem `Default`-Wert für T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}