use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Eine Schnittstelle für den Umgang mit asynchronen Iteratoren.
///
/// Dies ist der Hauptstrom trait.
/// Weitere Informationen zum Konzept von Streams im Allgemeinen finden Sie im [module-level documentation].
/// Insbesondere möchten Sie vielleicht wissen, wie man [implement `Stream`][impl] macht.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Die Art der Elemente, die der Stream liefert.
    type Item;

    /// Versuchen Sie, den nächsten Wert dieses Streams abzurufen, die aktuelle Task zum Aufwecken zu registrieren, wenn der Wert noch nicht verfügbar ist, und `None` zurückzugeben, wenn der Stream erschöpft ist.
    ///
    /// # Rückgabewert
    ///
    /// Es gibt mehrere mögliche Rückgabewerte, die jeweils einen bestimmten Stream-Status anzeigen:
    ///
    /// - `Poll::Pending` bedeutet, dass der nächste Wert dieses Streams noch nicht fertig ist.Durch Implementierungen wird sichergestellt, dass die aktuelle Aufgabe benachrichtigt wird, wenn der nächste Wert bereit ist.
    ///
    /// - `Poll::Ready(Some(val))` bedeutet, dass der Stream erfolgreich den Wert `val` erzeugt hat und bei nachfolgenden `poll_next`-Aufrufen möglicherweise weitere Werte erzeugt.
    ///
    /// - `Poll::Ready(None)` bedeutet, dass der Stream beendet wurde und `poll_next` nicht erneut aufgerufen werden sollte.
    ///
    /// # Panics
    ///
    /// Sobald ein Stream beendet ist (`Ready(None)` from `poll_next`) zurückgegeben, kann der erneute Aufruf der `poll_next`-Methode panic blockieren, für immer blockieren oder andere Probleme verursachen; der `Stream` trait stellt keine Anforderungen an die Auswirkungen eines solchen Aufrufs.
    ///
    /// Da die `poll_next`-Methode jedoch nicht als `unsafe` gekennzeichnet ist, gelten die üblichen Regeln von Rust: Aufrufe dürfen niemals undefiniertes Verhalten (Speicherbeschädigung, falsche Verwendung von `unsafe`-Funktionen oder dergleichen) verursachen, unabhängig vom Status des Streams.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Gibt die Grenzen für die verbleibende Länge des Streams zurück.
    ///
    /// Insbesondere gibt `size_hint()` ein Tupel zurück, bei dem das erste Element die Untergrenze und das zweite Element die Obergrenze ist.
    ///
    /// Die zweite Hälfte des zurückgegebenen Tupels ist eine [`Option`]`<`[`usize`] `>`.
    /// Ein [`None`] bedeutet hier, dass entweder keine Obergrenze bekannt ist oder die Obergrenze größer als [`usize`] ist.
    ///
    /// # Implementierungshinweise
    ///
    /// Es wird nicht erzwungen, dass eine Stream-Implementierung die deklarierte Anzahl von Elementen ergibt.Ein Buggy-Stream kann weniger als die Untergrenze oder mehr als die Obergrenze von Elementen ergeben.
    ///
    /// `size_hint()` ist in erster Linie für Optimierungen wie das Reservieren von Speicherplatz für die Elemente des Streams vorgesehen, darf jedoch nicht als vertrauenswürdig eingestuft werden, um z. B. Grenzprüfungen in unsicherem Code auszulassen.
    /// Eine fehlerhafte Implementierung von `size_hint()` sollte nicht zu Verstößen gegen die Speichersicherheit führen.
    ///
    /// Die Implementierung sollte jedoch eine korrekte Schätzung liefern, da dies sonst eine Verletzung des trait-Protokolls darstellen würde.
    ///
    /// Die Standardimplementierung gibt `(0,` [`None`]`)`zurück, was für jeden Stream korrekt ist.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}