//! Zusammensetzbare asynchrone Iteration.
//!
//! Wenn futures asynchrone Werte sind, sind Streams asynchrone Iteratoren.
//! Wenn Sie sich mit einer asynchronen Sammlung befunden haben und eine Operation für die Elemente dieser Sammlung ausführen müssen, wird 'streams' schnell ausgeführt.
//! Streams werden häufig in idiomatischem asynchronem Rust-Code verwendet, daher lohnt es sich, sich mit ihnen vertraut zu machen.
//!
//! Bevor wir mehr erklären, lassen Sie uns darüber sprechen, wie dieses Modul aufgebaut ist:
//!
//! # Organization
//!
//! Dieses Modul ist weitgehend nach Typ organisiert:
//!
//! * [Traits] sind der Kernteil: Diese traits definieren, welche Art von Streams existieren und was Sie damit machen können.Die Methoden dieser traits sind es wert, zusätzliche Lernzeit zu investieren.
//! * Funktionen bieten einige hilfreiche Möglichkeiten zum Erstellen einiger grundlegender Streams.
//! * Strukturen sind häufig die Rückgabetypen der verschiedenen Methoden in traits dieses Moduls.Normalerweise sollten Sie sich die Methode ansehen, mit der der `struct` erstellt wird, und nicht den `struct` selbst.
//! Weitere Informationen zum Warum finden Sie unter '[Implementing Stream](#Implementing-Stream)'.
//!
//! [Traits]: #traits
//!
//! Das ist es!Lassen Sie uns in Ströme graben.
//!
//! # Stream
//!
//! Das Herz und die Seele dieses Moduls ist der [`Stream`] trait.Der Kern von [`Stream`] sieht folgendermaßen aus:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Im Gegensatz zu `Iterator` unterscheidet `Stream` zwischen der [`poll_next`]-Methode, die bei der Implementierung eines `Stream` verwendet wird, und einer (to-be-implemented) `next`-Methode, die beim Konsumieren eines Streams verwendet wird.
//!
//! Verbraucher von `Stream` müssen nur `next` berücksichtigen, das beim Aufruf ein future zurückgibt, das `Option<Stream::Item>` ergibt.
//!
//! Das von `next` zurückgegebene future ergibt `Some(Item)`, solange Elemente vorhanden sind. Wenn alle Elemente erschöpft sind, wird `None` ausgegeben, um anzuzeigen, dass die Iteration abgeschlossen ist.
//! Wenn wir auf eine asynchrone Lösung warten, wartet der future, bis der Stream wieder bereit ist, nachzugeben.
//!
//! Einzelne Streams können sich dafür entscheiden, die Iteration fortzusetzen, und so kann ein erneuter Aufruf von `next` irgendwann zu einem erneuten Erhalt von `Some(Item)` führen oder auch nicht.
//!
//! Die vollständige Definition von [`Stream`] enthält auch eine Reihe anderer Methoden. Es handelt sich jedoch um Standardmethoden, die auf [`poll_next`] basieren und daher kostenlos zur Verfügung stehen.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Stream implementieren
//!
//! Das Erstellen eines eigenen Streams umfasst zwei Schritte: Erstellen eines `struct`, um den Status des Streams beizubehalten, und anschließendes Implementieren von [`Stream`] für diesen `struct`.
//!
//! Lassen Sie uns einen Stream mit dem Namen `Counter` erstellen, der von `1` bis `5` zählt:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Zunächst die Struktur:
//!
//! /// Ein Stream, der von eins bis fünf zählt
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Wir möchten, dass unsere Zählung bei eins beginnt. Fügen wir also eine new()-Methode hinzu, um zu helfen.
//! // Dies ist nicht unbedingt erforderlich, aber praktisch.
//! // Beachten Sie, dass wir `count` bei Null starten. Wir werden unten sehen, warum dies in der `poll_next()`'s-Implementierung der Fall ist.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dann implementieren wir `Stream` für unser `Counter`:
//!
//! impl Stream for Counter {
//!     // wir werden mit usize zählen
//!     type Item = usize;
//!
//!     // poll_next() ist die einzige erforderliche Methode
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Erhöhen Sie unsere Anzahl.Deshalb haben wir bei Null angefangen.
//!         self.count += 1;
//!
//!         // Überprüfen Sie, ob wir mit dem Zählen fertig sind oder nicht.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Streams sind *faul*.Dies bedeutet, dass nur das Erstellen eines Streams nicht viel _do_ ist.Nichts passiert wirklich, bis Sie `next` anrufen.
//! Dies ist manchmal eine Quelle der Verwirrung, wenn ein Stream nur wegen seiner Nebenwirkungen erstellt wird.
//! Der Compiler warnt uns vor diesem Verhalten:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;