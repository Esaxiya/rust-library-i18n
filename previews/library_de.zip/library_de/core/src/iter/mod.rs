//! Zusammensetzbare externe Iteration.
//!
//! Wenn Sie sich in einer Sammlung befinden und eine Operation für die Elemente dieser Sammlung ausführen müssen, wird 'iterators' schnell ausgeführt.
//! Iteratoren werden häufig im idiomatischen Rust-Code verwendet, daher lohnt es sich, sich mit ihnen vertraut zu machen.
//!
//! Bevor wir mehr erklären, lassen Sie uns darüber sprechen, wie dieses Modul aufgebaut ist:
//!
//! # Organization
//!
//! Dieses Modul ist weitgehend nach Typ organisiert:
//!
//! * [Traits] sind der Kernteil: Diese traits definieren, welche Art von Iteratoren existieren und was Sie damit machen können.Die Methoden dieser traits sind es wert, zusätzliche Lernzeit zu investieren.
//! * [Functions] bieten einige hilfreiche Möglichkeiten zum Erstellen einiger grundlegender Iteratoren.
//! * [Structs] sind häufig die Rückgabetypen der verschiedenen Methoden auf dem traits dieses Moduls.Normalerweise sollten Sie sich die Methode ansehen, mit der der `struct` erstellt wird, und nicht den `struct` selbst.
//! Weitere Informationen zum Warum finden Sie unter '[Implementieren des Iterators](#Implementieren des Iterators)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Das ist es!Lassen Sie uns in Iteratoren graben.
//!
//! # Iterator
//!
//! Das Herz und die Seele dieses Moduls ist der [`Iterator`] trait.Der Kern von [`Iterator`] sieht folgendermaßen aus:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Ein Iterator hat eine Methode, [`next`], die beim Aufruf eine [`Option`]`zurückgibt<Item>`.
//! [`next`] Gibt [`Some(Item)`] zurück, solange Elemente vorhanden sind. Wenn alle Elemente erschöpft sind, wird `None` zurückgegeben, um anzuzeigen, dass die Iteration abgeschlossen ist.
//! Einzelne Iteratoren können sich dafür entscheiden, die Iteration fortzusetzen. Wenn Sie [`next`] erneut aufrufen, wird [`Some(Item)`] möglicherweise irgendwann wieder zurückgegeben (siehe z. B. [`TryIter`]).
//!
//!
//! Die vollständige Definition von [`Iterator`] enthält auch eine Reihe anderer Methoden. Es handelt sich jedoch um Standardmethoden, die auf [`next`] basieren und daher kostenlos zur Verfügung stehen.
//!
//! Iteratoren sind auch zusammensetzbar, und es ist üblich, sie miteinander zu verketten, um komplexere Formen der Verarbeitung durchzuführen.Weitere Informationen finden Sie im Abschnitt [Adapters](#adapters) unten.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Die drei Formen der Iteration
//!
//! Es gibt drei gängige Methoden, mit denen Iteratoren aus einer Sammlung erstellt werden können:
//!
//! * `iter()`, welches über `&T` iteriert.
//! * `iter_mut()`, welches über `&mut T` iteriert.
//! * `into_iter()`, welches über `T` iteriert.
//!
//! Verschiedene Dinge in der Standardbibliothek können gegebenenfalls eine oder mehrere der drei implementieren.
//!
//! # Iterator implementieren
//!
//! Das Erstellen eines eigenen Iterators umfasst zwei Schritte: Erstellen eines `struct`, um den Status des Iterators beizubehalten, und anschließendes Implementieren von [`Iterator`] für diesen `struct`.
//! Aus diesem Grund gibt es in diesem Modul so viele "Strukturen": Für jeden Iterator und Iteratoradapter gibt es eine.
//!
//! Lassen Sie uns einen Iterator namens `Counter` erstellen, der von `1` bis `5` zählt:
//!
//! ```
//! // Zunächst die Struktur:
//!
//! /// Ein Iterator, der von eins bis fünf zählt
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Wir möchten, dass unsere Zählung bei eins beginnt. Fügen wir also eine new()-Methode hinzu, um zu helfen.
//! // Dies ist nicht unbedingt erforderlich, aber praktisch.
//! // Beachten Sie, dass wir `count` bei Null starten. Wir werden unten sehen, warum dies in der `next()`'s-Implementierung der Fall ist.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dann implementieren wir `Iterator` für unser `Counter`:
//!
//! impl Iterator for Counter {
//!     // wir werden mit usize zählen
//!     type Item = usize;
//!
//!     // next() ist die einzige erforderliche Methode
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Erhöhen Sie unsere Anzahl.Deshalb haben wir bei Null angefangen.
//!         self.count += 1;
//!
//!         // Überprüfen Sie, ob wir mit dem Zählen fertig sind oder nicht.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Und jetzt können wir es benutzen!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Das Aufrufen von [`next`] auf diese Weise wiederholt sich.Rust verfügt über ein Konstrukt, das [`next`] auf Ihrem Iterator aufrufen kann, bis es `None` erreicht.Lassen Sie uns das als nächstes durchgehen.
//!
//! Beachten Sie auch, dass `Iterator` eine Standardimplementierung von Methoden wie `nth` und `fold` bietet, die `next` intern aufrufen.
//! Es ist jedoch auch möglich, eine benutzerdefinierte Implementierung von Methoden wie `nth` und `fold` zu schreiben, wenn ein Iterator diese effizienter berechnen kann, ohne `next` aufzurufen.
//!
//! # `for` Schleifen und `IntoIterator`
//!
//! Die `for`-Schleifensyntax von Rust ist eigentlich Zucker für Iteratoren.Hier ist ein grundlegendes Beispiel für `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Dadurch werden die Zahlen eins bis fünf jeweils in einer eigenen Zeile gedruckt.Aber Sie werden hier etwas bemerken: Wir haben auf unserem vector nie etwas aufgerufen, um einen Iterator zu erzeugen.Was gibt?
//!
//! In der Standardbibliothek gibt es ein trait, mit dem Sie etwas in einen Iterator konvertieren können: [`IntoIterator`].
//! Dieser trait hat eine Methode, [`into_iter`], die das Ding, das [`IntoIterator`] implementiert, in einen Iterator konvertiert.
//! Schauen wir uns diese `for`-Schleife noch einmal an und was der Compiler in sie konvertiert:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust entzuckert dies in:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Zuerst rufen wir `into_iter()` für den Wert auf.Dann stimmen wir mit dem zurückkehrenden Iterator überein und rufen [`next`] immer wieder auf, bis wir einen `None` sehen.
//! An diesem Punkt verlassen wir `break` die Schleife und sind mit dem Iterieren fertig.
//!
//! Hier gibt es noch ein subtileres Element: Die Standardbibliothek enthält eine interessante Implementierung von [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Mit anderen Worten, alle [`Iterator`] implementieren [`IntoIterator`], indem sie sich einfach selbst zurückgeben.Dies bedeutet zwei Dinge:
//!
//! 1. Wenn Sie einen [`Iterator`] schreiben, können Sie ihn mit einer `for`-Schleife verwenden.
//! 2. Wenn Sie eine Sammlung erstellen und [`IntoIterator`] dafür implementieren, kann Ihre Sammlung mit der `for`-Schleife verwendet werden.
//!
//! # Durch Bezugnahme iterieren
//!
//! Da [`into_iter()`] `self` als Wert annimmt, verbraucht die Verwendung einer `for`-Schleife zum Durchlaufen einer Sammlung diese Sammlung.Oft möchten Sie eine Sammlung durchlaufen, ohne sie zu verbrauchen.
//! Viele Sammlungen bieten Methoden an, die Iteratoren über Referenzen bereitstellen, die üblicherweise als `iter()` bzw. `iter_mut()` bezeichnet werden:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ist immer noch im Besitz dieser Funktion.
//! ```
//!
//! Wenn ein Sammlungstyp `C` `iter()` bereitstellt, implementiert er normalerweise auch `IntoIterator` für `&C` mit einer Implementierung, die nur `iter()` aufruft.
//! Ebenso implementiert eine Sammlung `C`, die `iter_mut()` bereitstellt, im Allgemeinen `IntoIterator` für `&mut C`, indem sie an `iter_mut()` delegiert.Dies ermöglicht eine bequeme Abkürzung:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // wie `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // wie `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Während viele Kollektionen `iter()` anbieten, bieten nicht alle `iter_mut()` an.
//! Wenn Sie beispielsweise die Schlüssel eines [`HashSet<T>`] oder [`HashMap<K, V>`] mutieren, kann die Sammlung in einen inkonsistenten Zustand versetzt werden, wenn sich die Schlüssel-Hashes ändern. Daher bieten diese Sammlungen nur `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funktionen, die einen [`Iterator`] benötigen und einen anderen [`Iterator`] zurückgeben, werden häufig als "Iteratoradapter" bezeichnet, da sie eine Form des "Adapters" sind
//! pattern'.
//!
//! Zu den gängigen Iteratoradaptern gehören [`map`], [`take`] und [`filter`].
//! Weitere Informationen finden Sie in der Dokumentation.
//!
//! Wenn ein Iteratoradapter panics vorhanden ist, befindet sich der Iterator in einem nicht angegebenen (aber speichersicheren) Zustand.
//! Es ist auch nicht garantiert, dass dieser Status in allen Versionen von Rust gleich bleibt. Sie sollten sich daher nicht auf die genauen Werte verlassen, die von einem in Panik geratenen Iterator zurückgegeben werden.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratoren (und Iterator [adapters](#adapters)) sind *faul*. Dies bedeutet, dass das Erstellen eines Iterators nicht viel _do_ ist. Nichts passiert wirklich, bis Sie [`next`] aufrufen.
//! Dies ist manchmal verwirrend, wenn ein Iterator nur wegen seiner Nebenwirkungen erstellt wird.
//! Beispielsweise ruft die [`map`]-Methode einen Abschluss für jedes Element auf, über das sie iteriert:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Dadurch werden keine Werte gedruckt, da wir nur einen Iterator erstellt haben, anstatt ihn zu verwenden.Der Compiler warnt uns vor diesem Verhalten:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Die idiomatische Möglichkeit, einen [`map`] für seine Nebenwirkungen zu schreiben, besteht darin, eine `for`-Schleife zu verwenden oder die [`for_each`]-Methode aufzurufen:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Eine andere übliche Methode zum Auswerten eines Iterators ist die Verwendung der [`collect`]-Methode zum Erstellen einer neuen Sammlung.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratoren müssen nicht endlich sein.Ein offener Bereich ist beispielsweise ein unendlicher Iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Es ist üblich, den [`take`]-Iteratoradapter zu verwenden, um einen unendlichen Iterator in einen endlichen zu verwandeln:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Dadurch werden die Nummern `0` bis `4` jeweils in einer eigenen Zeile gedruckt.
//!
//! Beachten Sie, dass Methoden auf unendlichen Iteratoren, auch solche, für die ein Ergebnis in endlicher Zeit mathematisch bestimmt werden kann, möglicherweise nicht beendet werden.
//! Insbesondere Methoden wie [`min`], bei denen im Allgemeinen jedes Element im Iterator durchlaufen werden muss, werden wahrscheinlich nicht für unendliche Iteratoren erfolgreich zurückgegeben.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ach nein!Eine Endlosschleife!
//! // `ones.min()` verursacht eine Endlosschleife, so dass wir diesen Punkt nicht erreichen!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;