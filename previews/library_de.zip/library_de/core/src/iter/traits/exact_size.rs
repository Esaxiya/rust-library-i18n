/// Ein Iterator, der seine genaue Länge kennt.
///
/// Viele [`Iteratoren`] wissen nicht, wie oft sie iterieren werden, aber einige tun es.
/// Wenn ein Iterator weiß, wie oft er iterieren kann, kann es hilfreich sein, Zugriff auf diese Informationen zu gewähren.
/// Wenn Sie beispielsweise rückwärts iterieren möchten, ist es ein guter Anfang, zu wissen, wo das Ende liegt.
///
/// Bei der Implementierung eines `ExactSizeIterator` müssen Sie auch [`Iterator`] implementieren.
/// Dabei muss die Implementierung von [`Iterator::size_hint`]*die exakte Größe des Iterators* zurückgeben.
///
/// Die [`len`]-Methode verfügt über eine Standardimplementierung, daher sollten Sie diese normalerweise nicht implementieren.
/// Möglicherweise können Sie jedoch eine leistungsfähigere Implementierung als die Standardimplementierung bereitstellen. In diesem Fall ist es daher sinnvoll, diese zu überschreiben.
///
///
/// Beachten Sie, dass dieses trait ein sicheres trait ist und als solches *nicht* und *nicht* garantieren kann, dass die zurückgegebene Länge korrekt ist.
/// Dies bedeutet, dass der `unsafe`-Code **nicht** auf der Richtigkeit von [`Iterator::size_hint`] beruhen darf.
/// Der instabile und unsichere [`TrustedLen`](super::marker::TrustedLen) trait bietet diese zusätzliche Garantie.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// // Ein endlicher Bereich weiß genau, wie oft er iterieren wird
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Im [module-level docs] haben wir einen [`Iterator`] implementiert, `Counter`.
/// Lassen Sie uns auch `ExactSizeIterator` dafür implementieren:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Wir können die verbleibende Anzahl von Iterationen leicht berechnen.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Und jetzt können wir es benutzen!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Gibt die genaue Länge des Iterators zurück.
    ///
    /// Die Implementierung stellt sicher, dass der Iterator genau `len()` mehr als einen [`Some(T)`]-Wert zurückgibt, bevor er [`None`] zurückgibt.
    ///
    /// Diese Methode hat eine Standardimplementierung, daher sollten Sie sie normalerweise nicht direkt implementieren.
    /// Wenn Sie jedoch eine effizientere Implementierung bereitstellen können, können Sie dies tun.
    /// Ein Beispiel finden Sie in den [trait-level]-Dokumenten.
    ///
    /// Diese Funktion hat die gleichen Sicherheitsgarantien wie die [`Iterator::size_hint`]-Funktion.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // Ein endlicher Bereich weiß genau, wie oft er iterieren wird
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Diese Behauptung ist zu defensiv, überprüft aber die Invariante
        // garantiert durch den trait.
        // Wenn dieses trait rust-intern wäre, könnten wir debug_assert verwenden!;assert_eq!überprüft auch alle Rust-Benutzerimplementierungen.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Gibt `true` zurück, wenn der Iterator leer ist.
    ///
    /// Diese Methode hat eine Standardimplementierung mit [`ExactSizeIterator::len()`], sodass Sie sie nicht selbst implementieren müssen.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}