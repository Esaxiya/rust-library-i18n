use crate::ops::{ControlFlow, Try};

/// Ein Iterator, der Elemente von beiden Seiten liefern kann.
///
/// Etwas, das `DoubleEndedIterator` implementiert, hat eine zusätzliche Funktion gegenüber etwas, das [`Iterator`] implementiert: die Fähigkeit, sowohl Gegenstände von hinten als auch von vorne zu nehmen.
///
///
/// Es ist wichtig zu beachten, dass sowohl das Hin-als auch das Hin-und Herarbeiten im selben Bereich arbeiten und sich nicht kreuzen: Die Iteration ist beendet, wenn sie sich in der Mitte treffen.
///
/// Ähnlich wie beim [`Iterator`]-Protokoll kann ein erneuter Aufruf von `DoubleEndedIterator` von einem [`next_back()`] zu einem erneuten Aufruf von [`Some`] führen oder auch nicht.
/// [`next()`] und [`next_back()`] sind zu diesem Zweck austauschbar.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Entfernt ein Element vom Ende des Iterators und gibt es zurück.
    ///
    /// Gibt `None` zurück, wenn keine Elemente mehr vorhanden sind.
    ///
    /// Die [trait-level]-Dokumente enthalten weitere Details.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Die Elemente, die durch die Methoden von "DoubleEndedIterator" erhalten werden, können sich von denen unterscheiden, die durch die Methoden von ["Iterator"] erhalten werden:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Erweitert den Iterator von hinten um `n`-Elemente.
    ///
    /// `advance_back_by` ist die umgekehrte Version von [`advance_by`].Diese Methode überspringt eifrig `n`-Elemente von hinten, indem [`next_back`] bis zu `n`-mal aufgerufen wird, bis [`None`] gefunden wird.
    ///
    /// `advance_back_by(n)` gibt [`Ok(())`] zurück, wenn der Iterator erfolgreich um `n`-Elemente vorgerückt ist, oder [`Err(k)`], wenn [`None`] angetroffen wird, wobei `k` die Anzahl der Elemente ist, um die der Iterator vor dem Auslaufen der Elemente vorgerückt wird (d. h
    /// die Länge des Iterators).
    /// Beachten Sie, dass `k` immer kleiner als `n` ist.
    ///
    /// Das Aufrufen von `advance_back_by(0)` verbraucht keine Elemente und gibt immer [`Ok(())`] zurück.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // Nur `&3` wurde übersprungen
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Gibt das n-te Element vom Ende des Iterators zurück.
    ///
    /// Dies ist im Wesentlichen die umgekehrte Version von [`Iterator::nth()`].
    /// Obwohl wie bei den meisten Indizierungsvorgängen die Zählung bei Null beginnt, gibt `nth_back(0)` den ersten Wert vom Ende zurück, `nth_back(1)` den zweiten und so weiter.
    ///
    ///
    /// Beachten Sie, dass alle Elemente zwischen dem Ende und dem zurückgegebenen Element verbraucht werden, einschließlich des zurückgegebenen Elements.
    /// Dies bedeutet auch, dass ein mehrmaliger Aufruf von `nth_back(0)` auf demselben Iterator unterschiedliche Elemente zurückgibt.
    ///
    /// `nth_back()` gibt [`None`] zurück, wenn `n` größer oder gleich der Länge des Iterators ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Durch mehrmaliges Aufrufen von `nth_back()` wird der Iterator nicht zurückgespult:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Rückgabe von `None`, wenn weniger als `n + 1`-Elemente vorhanden sind:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Dies ist die umgekehrte Version von [`Iterator::try_fold()`]: Es werden Elemente verwendet, die von der Rückseite des Iterators ausgehen.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Aufgrund des Kurzschlusses sind die verbleibenden Elemente weiterhin über den Iterator verfügbar.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Eine Iteratormethode, die die Elemente des Iterators von hinten beginnend auf einen einzigen Endwert reduziert.
    ///
    /// Dies ist die umgekehrte Version von [`Iterator::fold()`]: Es werden Elemente verwendet, die von der Rückseite des Iterators ausgehen.
    ///
    /// `rfold()` Es werden zwei Argumente verwendet: ein Anfangswert und ein Abschluss mit zwei Argumenten: ein 'accumulator' und ein Element.
    /// Der Abschluss gibt den Wert zurück, den der Akkumulator für die nächste Iteration haben sollte.
    ///
    /// Der Anfangswert ist der Wert, den der Akku beim ersten Aufruf hat.
    ///
    /// Nachdem dieser Abschluss auf jedes Element des Iterators angewendet wurde, gibt `rfold()` den Akkumulator zurück.
    ///
    /// Diese Operation wird manchmal als 'reduce' oder 'inject' bezeichnet.
    ///
    /// Das Falten ist immer dann nützlich, wenn Sie eine Sammlung von etwas haben und daraus einen einzelnen Wert erzeugen möchten.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // die Summe aller Elemente von a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// In diesem Beispiel wird eine Zeichenfolge erstellt, die mit einem Anfangswert beginnt und mit jedem Element von hinten bis vorne fortgesetzt wird:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Sucht von hinten nach einem Element eines Iterators, das ein Prädikat erfüllt.
    ///
    /// `rfind()` nimmt einen Abschluss, der `true` oder `false` zurückgibt.
    /// Dieser Abschluss wird beginnend am Ende auf jedes Element des Iterators angewendet. Wenn eines von ihnen `true` zurückgibt, gibt `rfind()` [`Some(element)`] zurück.
    /// Wenn alle `false` zurückgeben, wird [`None`] zurückgegeben.
    ///
    /// `rfind()` ist kurzgeschlossen;Mit anderen Worten, die Verarbeitung wird beendet, sobald der Abschluss `true` zurückgibt.
    ///
    /// Da `rfind()` eine Referenz verwendet und viele Iteratoren über Referenzen iterieren, führt dies zu einer möglicherweise verwirrenden Situation, in der das Argument eine Doppelreferenz ist.
    ///
    /// Sie können diesen Effekt in den folgenden Beispielen mit `&&x` sehen.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Anhalten beim ersten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // Wir können immer noch `iter` verwenden, da es mehr Elemente gibt.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}