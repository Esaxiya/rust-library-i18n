/// Ein Iterator, der bei Erschöpfung immer `None` liefert.
///
/// Wenn Sie als nächstes einen fusionierten Iterator aufrufen, der `None` einmal zurückgegeben hat, wird [`None`] garantiert wieder zurückgegeben.
/// Dieses trait sollte von allen Iteratoren implementiert werden, die sich so verhalten, da es die Optimierung von [`Iterator::fuse()`] ermöglicht.
///
///
/// Note: Im Allgemeinen sollten Sie `FusedIterator` nicht in generischen Grenzen verwenden, wenn Sie einen fusionierten Iterator benötigen.
/// Stattdessen sollten Sie einfach [`Iterator::fuse()`] auf dem Iterator aufrufen.
/// Wenn der Iterator bereits fusioniert ist, ist der zusätzliche [`Fuse`]-Wrapper ein No-Op ohne Leistungseinbußen.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Ein Iterator, der mithilfe von size_hint eine genaue Länge angibt.
///
/// Der Iterator meldet einen Größenhinweis, bei dem er entweder genau ist (die untere Grenze entspricht der oberen Grenze) oder die obere Grenze ist [`None`].
///
/// Die Obergrenze darf nur [`None`] sein, wenn die tatsächliche Iteratorlänge größer als [`usize::MAX`] ist.
/// In diesem Fall muss die Untergrenze [`usize::MAX`] sein, was zu einem [`Iterator::size_hint()`] von `(usize::MAX, None)` führt.
///
/// Der Iterator muss genau die Anzahl der Elemente erzeugen, die er gemeldet hat oder von denen er abweicht, bevor er das Ende erreicht.
///
/// # Safety
///
/// Dieser trait darf nur implementiert werden, wenn der Vertrag eingehalten wird.
/// Verbraucher dieses trait müssen die [`Iterator::size_hint()`]’s-Obergrenze überprüfen.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ein Iterator, der bei der Ausgabe eines Elements mindestens ein Element aus dem zugrunde liegenden [`SourceIter`] übernommen hat.
///
/// Aufrufen einer Methode, die den Iterator weiterentwickelt, z
/// [`next()`] oder [`try_fold()`] garantiert, dass für jeden Schritt mindestens ein Wert der zugrunde liegenden Quelle des Iterators verschoben wurde und das Ergebnis der Iteratorkette an seiner Stelle eingefügt werden kann, vorausgesetzt, strukturelle Einschränkungen der Quelle ermöglichen ein solches Einfügen.
///
/// Mit anderen Worten, dieser trait zeigt an, dass eine Iterator-Pipeline an Ort und Stelle gesammelt werden kann.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}