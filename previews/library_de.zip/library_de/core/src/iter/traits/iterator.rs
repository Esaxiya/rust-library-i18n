// ignore-tidy-filelength Diese Datei besteht fast ausschließlich aus der Definition von `Iterator`.
// Wir können das nicht in mehrere Dateien aufteilen.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Eine Schnittstelle für den Umgang mit Iteratoren.
///
/// Dies ist der Hauptiterator trait.
/// Weitere Informationen zum Konzept der Iteratoren im Allgemeinen finden Sie im [module-level documentation].
/// Insbesondere möchten Sie vielleicht wissen, wie man [implement `Iterator`][impl] macht.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Der Typ der Elemente, über die iteriert wird.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Erweitert den Iterator und gibt den nächsten Wert zurück.
    ///
    /// Gibt [`None`] zurück, wenn die Iteration abgeschlossen ist.
    /// Einzelne Iterator-Implementierungen können sich dafür entscheiden, die Iteration fortzusetzen. Wenn Sie `next()` erneut aufrufen, wird [`Some(Item)`] möglicherweise irgendwann wieder zurückgegeben.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Ein Aufruf von next() gibt den nächsten Wert zurück ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... und dann keine, sobald es vorbei ist.
    /// assert_eq!(None, iter.next());
    ///
    /// // Weitere Anrufe können `None` zurückgeben oder nicht.Hier werden sie immer.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Gibt die Grenzen für die verbleibende Länge des Iterators zurück.
    ///
    /// Insbesondere gibt `size_hint()` ein Tupel zurück, bei dem das erste Element die Untergrenze und das zweite Element die Obergrenze ist.
    ///
    /// Die zweite Hälfte des zurückgegebenen Tupels ist eine [`Option`]`<`[`usize`] `>`.
    /// Ein [`None`] bedeutet hier, dass entweder keine Obergrenze bekannt ist oder die Obergrenze größer als [`usize`] ist.
    ///
    /// # Implementierungshinweise
    ///
    /// Es wird nicht erzwungen, dass eine Iterator-Implementierung die deklarierte Anzahl von Elementen ergibt.Ein fehlerhafter Iterator kann weniger als die Untergrenze oder mehr als die Obergrenze von Elementen liefern.
    ///
    /// `size_hint()` ist in erster Linie für Optimierungen wie das Reservieren von Speicherplatz für die Elemente des Iterators vorgesehen, darf jedoch nicht als vertrauenswürdig eingestuft werden, um z. B. Grenzprüfungen in unsicherem Code auszulassen.
    /// Eine fehlerhafte Implementierung von `size_hint()` sollte nicht zu Verstößen gegen die Speichersicherheit führen.
    ///
    /// Die Implementierung sollte jedoch eine korrekte Schätzung liefern, da dies sonst eine Verletzung des trait-Protokolls darstellen würde.
    ///
    /// Die Standardimplementierung gibt `(0,` [`None`]`)`zurück, was für jeden Iterator korrekt ist.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Ein komplexeres Beispiel:
    ///
    /// ```
    /// // Die geraden Zahlen von null bis zehn.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Wir könnten von null auf zehn Mal iterieren.
    /// // Zu wissen, dass es genau fünf sind, wäre ohne die Ausführung von filter() nicht möglich.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Fügen wir mit chain() fünf weitere Zahlen hinzu
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // Jetzt werden beide Grenzen um fünf erhöht
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Rückgabe von `None` für eine Obergrenze:
    ///
    /// ```
    /// // Ein unendlicher Iterator hat keine Obergrenze und die maximal mögliche Untergrenze
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Verbraucht den Iterator, zählt die Anzahl der Iterationen und gibt ihn zurück.
    ///
    /// Diese Methode ruft [`next`] wiederholt auf, bis [`None`] angetroffen wird, und gibt zurück, wie oft [`Some`] gesehen wurde.
    /// Beachten Sie, dass [`next`] mindestens einmal aufgerufen werden muss, auch wenn der Iterator keine Elemente enthält.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Überlaufverhalten
    ///
    /// Die Methode schützt nicht vor Überläufen. Wenn Sie also Elemente eines Iterators mit mehr als [`usize::MAX`]-Elementen zählen, erhalten Sie entweder das falsche Ergebnis oder panics.
    ///
    /// Wenn Debug-Zusicherungen aktiviert sind, ist ein panic garantiert.
    ///
    /// # Panics
    ///
    /// Diese Funktion kann panic sein, wenn der Iterator mehr als [`usize::MAX`]-Elemente enthält.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Verbraucht den Iterator und gibt das letzte Element zurück.
    ///
    /// Diese Methode wertet den Iterator aus, bis er [`None`] zurückgibt.
    /// Dabei wird das aktuelle Element verfolgt.
    /// Nachdem [`None`] zurückgegeben wurde, gibt `last()` das letzte Element zurück, das es gesehen hat.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Erweitert den Iterator um `n`-Elemente.
    ///
    /// Diese Methode überspringt eifrig `n`-Elemente, indem [`next`] bis zu `n`-mal aufgerufen wird, bis [`None`] angetroffen wird.
    ///
    /// `advance_by(n)` gibt [`Ok(())`][Ok] zurück, wenn der Iterator erfolgreich um `n`-Elemente vorgerückt ist, oder [`Err(k)`][Err], wenn [`None`] angetroffen wird, wobei `k` die Anzahl der Elemente ist, um die der Iterator vor dem Auslaufen der Elemente vorgerückt wird (d. h
    /// die Länge des Iterators).
    /// Beachten Sie, dass `k` immer kleiner als `n` ist.
    ///
    /// Das Aufrufen von `advance_by(0)` verbraucht keine Elemente und gibt immer [`Ok(())`][Ok] zurück.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // Nur `&4` wurde übersprungen
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Gibt das n-te Element des Iterators zurück.
    ///
    /// Wie bei den meisten Indizierungsvorgängen beginnt die Zählung bei Null, sodass `nth(0)` den ersten Wert, `nth(1)` den zweiten usw. zurückgibt.
    ///
    /// Beachten Sie, dass alle vorhergehenden Elemente sowie das zurückgegebene Element vom Iterator verwendet werden.
    /// Das bedeutet, dass die vorhergehenden Elemente verworfen werden und dass ein mehrmaliger Aufruf von `nth(0)` auf demselben Iterator unterschiedliche Elemente zurückgibt.
    ///
    ///
    /// `nth()` gibt [`None`] zurück, wenn `n` größer oder gleich der Länge des Iterators ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Durch mehrmaliges Aufrufen von `nth()` wird der Iterator nicht zurückgespult:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Rückgabe von `None`, wenn weniger als `n + 1`-Elemente vorhanden sind:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Erstellt einen Iterator, der am selben Punkt beginnt, aber bei jeder Iteration den angegebenen Betrag überschreitet.
    ///
    /// Hinweis 1: Das erste Element des Iterators wird unabhängig vom angegebenen Schritt immer zurückgegeben.
    ///
    /// Hinweis 2: Der Zeitpunkt, zu dem ignorierte Elemente gezogen werden, ist nicht festgelegt.
    /// `StepBy` verhält sich wie die Sequenz `next(), nth(step-1), nth(step-1),…`, kann sich aber auch wie die Sequenz verhalten
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Welche Methode verwendet wird, kann sich für einige Iteratoren aus Leistungsgründen ändern.
    /// Der zweite Weg führt den Iterator früher voran und verbraucht möglicherweise mehr Elemente.
    ///
    /// `advance_n_and_return_first` ist das Äquivalent von:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Die Methode wird panic, wenn der angegebene Schritt `0` ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Nimmt zwei Iteratoren und erstellt nacheinander einen neuen Iterator über beide.
    ///
    /// `chain()` gibt einen neuen Iterator zurück, der zuerst über die Werte des ersten Iterators und dann über die Werte des zweiten Iterators iteriert.
    ///
    /// Mit anderen Worten, es verbindet zwei Iteratoren in einer Kette miteinander.🔗
    ///
    /// [`once`] wird üblicherweise verwendet, um einen einzelnen Wert in eine Kette anderer Arten von Iterationen anzupassen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da das Argument für `chain()` [`IntoIterator`] verwendet, können wir alles übergeben, was in ein [`Iterator`] konvertiert werden kann, nicht nur ein [`Iterator`] selbst.
    /// Beispielsweise implementieren Slices (`&[T]`) [`IntoIterator`] und können so direkt an `chain()` übergeben werden:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wenn Sie mit der Windows-API arbeiten, möchten Sie möglicherweise [`OsStr`] in `Vec<u16>` konvertieren:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// Zwei Iteratoren werden zu einem einzigen Iterator von Paaren zusammengefasst.
    ///
    /// `zip()` Gibt einen neuen Iterator zurück, der über zwei andere Iteratoren iteriert und ein Tupel zurückgibt, bei dem das erste Element vom ersten Iterator und das zweite Element vom zweiten Iterator stammt.
    ///
    ///
    /// Mit anderen Worten, es werden zwei Iteratoren zu einem einzigen zusammengefasst.
    ///
    /// Wenn einer der Iteratoren [`None`] zurückgibt, gibt [`next`] vom gezippten Iterator [`None`] zurück.
    /// Wenn der erste Iterator [`None`] zurückgibt, wird `zip` kurzgeschlossen und `next` wird beim zweiten Iterator nicht aufgerufen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da das Argument für `zip()` [`IntoIterator`] verwendet, können wir alles übergeben, was in ein [`Iterator`] konvertiert werden kann, nicht nur ein [`Iterator`] selbst.
    /// Beispielsweise implementieren Slices (`&[T]`) [`IntoIterator`] und können so direkt an `zip()` übergeben werden:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` wird oft verwendet, um einen unendlichen Iterator auf einen endlichen zu komprimieren.
    /// Dies funktioniert, weil der endliche Iterator schließlich [`None`] zurückgibt und den Reißverschluss beendet.Das Zippen mit `(0..)` kann [`enumerate`] sehr ähnlich sehen:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Erstellt einen neuen Iterator, der eine Kopie von `separator` zwischen benachbarten Elementen des ursprünglichen Iterators platziert.
    ///
    /// Wenn `separator` [`Clone`] nicht implementiert oder jedes Mal berechnet werden muss, verwenden Sie [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Das erste Element von `a`.
    /// assert_eq!(a.next(), Some(&100)); // Der Separator.
    /// assert_eq!(a.next(), Some(&1));   // Das nächste Element von `a`.
    /// assert_eq!(a.next(), Some(&100)); // Der Separator.
    /// assert_eq!(a.next(), Some(&2));   // Das letzte Element von `a`.
    /// assert_eq!(a.next(), None);       // Der Iterator ist fertig.
    /// ```
    ///
    /// `intersperse` kann sehr nützlich sein, um die Elemente eines Iterators mithilfe eines gemeinsamen Elements zu verknüpfen:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Erstellt einen neuen Iterator, der ein von `separator` generiertes Element zwischen benachbarten Elementen des ursprünglichen Iterators platziert.
    ///
    /// Der Abschluss wird jedes Mal genau einmal aufgerufen, wenn ein Element zwischen zwei benachbarten Elementen des zugrunde liegenden Iterators platziert wird.
    /// Insbesondere wird der Abschluss nicht aufgerufen, wenn der zugrunde liegende Iterator weniger als zwei Elemente ergibt und nachdem das letzte Element ausgegeben wurde.
    ///
    ///
    /// Wenn das Element des Iterators [`Clone`] implementiert, ist die Verwendung von [`intersperse`] möglicherweise einfacher.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Das erste Element von `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Der Separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Das nächste Element von `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Der Separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Das letzte Element von `v`.
    /// assert_eq!(it.next(), None);               // Der Iterator ist fertig.
    /// ```
    ///
    /// `intersperse_with` kann in Situationen verwendet werden, in denen das Trennzeichen berechnet werden muss:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Der Verschluss leiht seinen Kontext veränderlich aus, um einen Gegenstand zu erzeugen.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Nimmt einen Abschluss und erstellt einen Iterator, der diesen Abschluss für jedes Element aufruft.
    ///
    /// `map()` wandelt einen Iterator durch sein Argument in einen anderen um:
    /// etwas, das [`FnMut`] implementiert.Es wird ein neuer Iterator erstellt, der diesen Abschluss für jedes Element des ursprünglichen Iterators aufruft.
    ///
    /// Wenn Sie gut in Typen denken können, können Sie sich `map()` folgendermaßen vorstellen:
    /// Wenn Sie einen Iterator haben, der Ihnen Elemente eines Typs `A` enthält, und Sie einen Iterator eines anderen Typs `B` möchten, können Sie `map()` verwenden und einen Abschluss übergeben, der einen `A` akzeptiert und einen `B` zurückgibt.
    ///
    ///
    /// `map()` ist konzeptionell einer [`for`]-Schleife ähnlich.Da `map()` jedoch faul ist, wird es am besten verwendet, wenn Sie bereits mit anderen Iteratoren arbeiten.
    /// Wenn Sie eine Art Schleife für einen Nebeneffekt ausführen, wird die Verwendung von [`for`] als idiomatischer angesehen als die Verwendung von `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wenn Sie eine Nebenwirkung haben, ziehen Sie [`for`] `map()` vor:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // Tu das nicht:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // es wird nicht einmal ausgeführt, da es faul ist.Rust warnt Sie davor.
    ///
    /// // Verwenden Sie stattdessen für:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Ruft einen Abschluss für jedes Element eines Iterators auf.
    ///
    /// Dies entspricht der Verwendung einer [`for`]-Schleife auf dem Iterator, obwohl `break` und `continue` von einem Abschluss aus nicht möglich sind.
    /// Es ist im Allgemeinen idiomatischer, eine `for`-Schleife zu verwenden, aber `for_each` ist möglicherweise besser lesbar, wenn Elemente am Ende längerer Iteratorketten verarbeitet werden.
    ///
    /// In einigen Fällen kann `for_each` auch schneller als eine Schleife sein, da bei Adaptern wie `Chain` eine interne Iteration verwendet wird.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// In einem so kleinen Beispiel ist eine `for`-Schleife möglicherweise sauberer, aber `for_each` ist möglicherweise vorzuziehen, um einen funktionalen Stil mit längeren Iteratoren beizubehalten:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Erstellt einen Iterator, der mithilfe eines Abschlusses bestimmt, ob ein Element ausgegeben werden soll.
    ///
    /// Bei einem bestimmten Element muss der Verschluss `true` oder `false` zurückgeben.Der zurückgegebene Iterator liefert nur die Elemente, für die der Abschluss true zurückgibt.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da der an `filter()` übergebene Abschluss eine Referenz enthält und viele Iteratoren über Referenzen iterieren, führt dies zu einer möglicherweise verwirrenden Situation, in der der Typ des Abschlusses eine Doppelreferenz ist:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // brauche zwei * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Es ist üblich, stattdessen eine Destrukturierung für das Argument zu verwenden, um eines zu entfernen:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // beide und *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// oder beides:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // zwei &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// dieser Schichten.
    ///
    /// Beachten Sie, dass `iter.filter(f).next()` `iter.find(f)` entspricht.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Erstellt einen Iterator, der sowohl filtert als auch abbildet.
    ///
    /// Der zurückgegebene Iterator liefert nur die "Werte", für die der angegebene Abschluss `Some(value)` zurückgibt.
    ///
    /// `filter_map` kann verwendet werden, um Ketten von [`filter`] und [`map`] präziser zu gestalten.
    /// Das folgende Beispiel zeigt, wie ein `map().filter().map()` auf einen einzelnen Aufruf von `filter_map` gekürzt werden kann.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hier ist das gleiche Beispiel, aber mit [`filter`] und [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Erstellt einen Iterator, der die aktuelle Iterationszahl sowie den nächsten Wert angibt.
    ///
    /// Der zurückgegebene Iterator ergibt die Paare `(i, val)`, wobei `i` der aktuelle Iterationsindex und `val` der vom Iterator zurückgegebene Wert ist.
    ///
    ///
    /// `enumerate()` behält seine Zählung als [`usize`].
    /// Wenn Sie mit einer ganzzahligen Ganzzahl zählen möchten, bietet die [`zip`]-Funktion ähnliche Funktionen.
    ///
    /// # Überlaufverhalten
    ///
    /// Die Methode schützt nicht vor Überläufen. Wenn Sie also mehr als [`usize::MAX`]-Elemente aufzählen, erhalten Sie entweder das falsche Ergebnis oder panics.
    /// Wenn Debug-Zusicherungen aktiviert sind, ist ein panic garantiert.
    ///
    /// # Panics
    ///
    /// Der zurückgegebene Iterator könnte panic sein, wenn der zurückzugebende Index einen [`usize`] überlaufen würde.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Erstellt einen Iterator, der mit [`peek`] das nächste Element des Iterators anzeigen kann, ohne es zu verbrauchen.
    ///
    /// Fügt einem Iterator eine [`peek`]-Methode hinzu.Weitere Informationen finden Sie in der Dokumentation.
    ///
    /// Beachten Sie, dass der zugrunde liegende Iterator beim ersten Aufruf von [`peek`] noch erweitert ist: Um das nächste Element abzurufen, wird [`next`] auf dem zugrunde liegenden Iterator aufgerufen, daher alle Nebenwirkungen (d. H.
    ///
    /// Alles andere als das Abrufen des nächsten Werts) der [`next`]-Methode wird ausgeführt.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() Lassen Sie uns in die future sehen
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Wir können peek() mehrmals ausführen, der Iterator wird nicht weiterentwickelt
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Nachdem der Iterator beendet ist, ist es auch peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Erstellt einen Iterator, der die Elemente von [`skip`] basierend auf einem Prädikat enthält.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` nimmt einen Abschluss als Argument.Dieser Abschluss wird für jedes Element des Iterators aufgerufen und Elemente werden ignoriert, bis `false` zurückgegeben wird.
    ///
    /// Nachdem `false` zurückgegeben wurde, ist der `skip_while()`'s-Job beendet und der Rest der Elemente wird ausgegeben.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da der an `skip_while()` übergebene Abschluss eine Referenz enthält und viele Iteratoren über Referenzen iterieren, führt dies zu einer möglicherweise verwirrenden Situation, in der der Typ des Abschlussarguments eine Doppelreferenz ist:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // brauche zwei * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Anhalten nach einem ersten `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Während dies falsch gewesen wäre, da wir bereits eine falsche haben, wird skip_while() nicht mehr verwendet
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Erstellt einen Iterator, der Elemente basierend auf einem Prädikat liefert.
    ///
    /// `take_while()` nimmt einen Abschluss als Argument.Dieser Abschluss wird für jedes Element des Iterators aufgerufen und es werden Elemente ausgegeben, während `true` zurückgegeben wird.
    ///
    /// Nachdem `false` zurückgegeben wurde, ist der `take_while()`'s-Job beendet und die restlichen Elemente werden ignoriert.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da der an `take_while()` übergebene Abschluss eine Referenz enthält und viele Iteratoren über Referenzen iterieren, führt dies zu einer möglicherweise verwirrenden Situation, in der der Typ des Abschlusses eine Doppelreferenz ist:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // brauche zwei * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Anhalten nach einem ersten `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Wir haben mehr Elemente, die kleiner als Null sind, aber da wir bereits eine falsche haben, wird take_while() nicht mehr verwendet
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da `take_while()` den Wert überprüfen muss, um festzustellen, ob er enthalten sein sollte oder nicht, wird bei konsumierenden Iteratoren festgestellt, dass er entfernt wird:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Der `3` ist nicht mehr vorhanden, da er verbraucht wurde, um zu prüfen, ob die Iteration gestoppt werden soll, aber nicht wieder in den Iterator eingefügt wurde.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Erstellt einen Iterator, der sowohl Elemente basierend auf einem Prädikat als auch Karten liefert.
    ///
    /// `map_while()` nimmt einen Abschluss als Argument.
    /// Dieser Abschluss wird für jedes Element des Iterators aufgerufen und es werden Elemente ausgegeben, während [`Some(_)`][`Some`] zurückgegeben wird.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hier ist das gleiche Beispiel, aber mit [`take_while`] und [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Anhalten nach einem ersten [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Wir haben mehr Elemente, die in u32 (4, 5) passen könnten, aber `map_while` hat `None` für `-3` zurückgegeben (wie `predicate` `None` zurückgegeben hat) und `collect` stoppt beim ersten Auftreten von `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Da `map_while()` den Wert überprüfen muss, um festzustellen, ob er enthalten sein sollte oder nicht, wird bei konsumierenden Iteratoren festgestellt, dass er entfernt wird:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Der `-3` ist nicht mehr vorhanden, da er verbraucht wurde, um zu prüfen, ob die Iteration gestoppt werden soll, aber nicht wieder in den Iterator eingefügt wurde.
    ///
    /// Beachten Sie, dass dieser Iterator im Gegensatz zu [`take_while`]**nicht** fusioniert ist.
    /// Es ist auch nicht angegeben, was dieser Iterator zurückgibt, nachdem der erste [`None`] zurückgegeben wurde.
    /// Wenn Sie einen fusionierten Iterator benötigen, verwenden Sie [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Erstellt einen Iterator, der die ersten `n`-Elemente überspringt.
    ///
    /// Nach dem Verzehr werden die restlichen Elemente erhalten.
    /// Anstatt diese Methode direkt zu überschreiben, überschreiben Sie stattdessen die `nth`-Methode.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Erstellt einen Iterator, der seine ersten `n`-Elemente liefert.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` wird oft mit einem unendlichen Iterator verwendet, um es endlich zu machen:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wenn weniger als `n`-Elemente verfügbar sind, beschränkt sich `take` auf die Größe des zugrunde liegenden Iterators:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Ein Iteratoradapter ähnlich [`fold`], der den internen Status beibehält und einen neuen Iterator erzeugt.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` nimmt zwei Argumente an: einen Anfangswert, der den internen Zustand festlegt, und einen Abschluss mit zwei Argumenten, wobei das erste eine veränderbare Referenz auf den internen Zustand und das zweite ein Iteratorelement ist.
    ///
    /// Der Abschluss kann dem internen Status zugewiesen werden, um den Status zwischen den Iterationen zu teilen.
    ///
    /// Bei der Iteration wird der Abschluss auf jedes Element des Iterators angewendet, und der Rückgabewert des Abschlusses, ein [`Option`], wird vom Iterator ausgegeben.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // Bei jeder Iteration multiplizieren wir den Status mit dem Element
    ///     *state = *state * x;
    ///
    ///     // dann werden wir die Negation des Staates nachgeben
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Erstellt einen Iterator, der wie eine Karte funktioniert, jedoch die verschachtelte Struktur abflacht.
    ///
    /// Der [`map`]-Adapter ist sehr nützlich, jedoch nur, wenn das Abschlussargument Werte erzeugt.
    /// Wenn stattdessen ein Iterator erzeugt wird, gibt es eine zusätzliche Indirektionsebene.
    /// `flat_map()` entfernt diese zusätzliche Schicht von selbst.
    ///
    /// Sie können sich `flat_map(f)` als das semantische Äquivalent von [`map`] ping und dann [`flatten`] als in `map(f).flatten()` vorstellen.
    ///
    /// Eine andere Art, über `flat_map()` nachzudenken: Der Abschluss von [`map`] gibt für jedes Element ein Element zurück, und der Abschluss von `flat_map()`'s gibt für jedes Element einen Iterator zurück.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() Gibt einen Iterator zurück
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Erstellt einen Iterator, der die verschachtelte Struktur abflacht.
    ///
    /// Dies ist nützlich, wenn Sie einen Iterator von Iteratoren oder einen Iterator von Dingen haben, die in Iteratoren umgewandelt werden können, und Sie eine Indirektionsebene entfernen möchten.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Abbildung und anschließende Abflachung:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() Gibt einen Iterator zurück
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Sie können dies auch in Bezug auf [`flat_map()`] umschreiben, was in diesem Fall vorzuziehen ist, da es die Absicht klarer vermittelt:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() Gibt einen Iterator zurück
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Durch das Reduzieren wird jeweils nur eine Verschachtelungsebene entfernt:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hier sehen wir, dass `flatten()` keine "deep"-Abflachung ausführt.
    /// Stattdessen wird nur eine Verschachtelungsebene entfernt.Das heißt, wenn Sie ein dreidimensionales Array `flatten()` verwenden, ist das Ergebnis zweidimensional und nicht eindimensional.
    /// Um eine eindimensionale Struktur zu erhalten, müssen Sie erneut `flatten()` ausführen.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Erstellt einen Iterator, der nach dem ersten [`None`] endet.
    ///
    /// Nachdem ein Iterator [`None`] zurückgegeben hat, können future-Aufrufe [`Some(T)`] erneut ergeben oder nicht.
    /// `fuse()` Passt einen Iterator an und stellt so sicher, dass nach der Angabe eines [`None`] immer [`None`] für immer zurückgegeben wird.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // ein Iterator, der zwischen Some und None wechselt
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // Wenn es gerade ist, Some(i32), sonst Keine
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // wir können sehen, wie unser Iterator hin und her geht
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Sobald wir es jedoch verschmelzen ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Nach dem ersten Mal wird immer `None` zurückgegeben.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Macht etwas mit jedem Element eines Iterators und gibt den Wert weiter.
    ///
    /// Wenn Sie Iteratoren verwenden, verketten Sie häufig mehrere davon.
    /// Während Sie an einem solchen Code arbeiten, möchten Sie möglicherweise überprüfen, was an verschiedenen Stellen in der Pipeline passiert.Fügen Sie dazu einen Anruf an `inspect()` ein.
    ///
    /// Es ist üblicher, dass `inspect()` als Debugging-Tool verwendet wird, als dass es in Ihrem endgültigen Code vorhanden ist. Anwendungen können es jedoch in bestimmten Situationen nützlich finden, wenn Fehler protokolliert werden müssen, bevor sie verworfen werden.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // Diese Iteratorsequenz ist komplex.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // Fügen wir einige inspect()-Aufrufe hinzu, um zu untersuchen, was passiert
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Dies wird gedruckt:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Protokollieren von Fehlern vor dem Verwerfen:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Dies wird gedruckt:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Leiht sich einen Iterator aus, anstatt ihn zu konsumieren.
    ///
    /// Dies ist nützlich, um das Anwenden von Iteratoradaptern zu ermöglichen, während der Besitz des ursprünglichen Iterators erhalten bleibt.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // Wenn wir erneut versuchen, iter zu verwenden, funktioniert dies nicht.
    /// // Die folgende Zeile gibt "Fehler: Verwendung des verschobenen Werts: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // Versuchen wir es noch einmal
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Stattdessen fügen wir einen .by_ref() hinzu
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // jetzt ist das in Ordnung:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Verwandelt einen Iterator in eine Sammlung.
    ///
    /// `collect()` kann alles iterable nehmen und es in eine relevante Sammlung verwandeln.
    /// Dies ist eine der leistungsstärkeren Methoden in der Standardbibliothek, die in verschiedenen Kontexten verwendet wird.
    ///
    /// Das grundlegendste Muster, in dem `collect()` verwendet wird, besteht darin, eine Sammlung in eine andere umzuwandeln.
    /// Sie nehmen eine Sammlung, rufen [`iter`] auf, führen eine Reihe von Transformationen durch und am Ende `collect()`.
    ///
    /// `collect()` kann auch Instanzen von Typen erstellen, die keine typischen Sammlungen sind.
    /// Beispielsweise kann ein [`String`] aus [`char`] erstellt werden, und ein Iterator von [`Result<T, E>`][`Result`]-Elementen kann in `Result<Collection<T>, E>` gesammelt werden.
    ///
    /// Weitere Informationen finden Sie in den folgenden Beispielen.
    ///
    /// Da `collect()` so allgemein ist, kann es zu Problemen mit der Typinferenz kommen.
    /// Daher ist `collect()` eines der wenigen Male, dass Sie die Syntax 'turbofish' sehen: `::<>`.
    /// Dies hilft dem Inferenzalgorithmus, genau zu verstehen, in welcher Sammlung Sie sammeln möchten.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Beachten Sie, dass wir den `: Vec<i32>` auf der linken Seite brauchten.Dies liegt daran, dass wir stattdessen beispielsweise in einem [`VecDeque<T>`] sammeln könnten:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Verwenden von 'turbofish' anstelle von Anmerkungen zu `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Da sich `collect()` nur um das kümmert, was Sie sammeln, können Sie mit dem Turbofisch immer noch einen Teil-Typ-Hinweis, `_`, verwenden:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Verwenden von `collect()` zum Erstellen eines [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Wenn Sie eine Liste von [`Ergebnis<T, E>`][`Ergebnis`] s, Sie können `collect()` verwenden, um zu sehen, ob einer von ihnen fehlgeschlagen ist:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gibt uns den ersten Fehler
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gibt uns die Liste der Antworten
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Verbraucht einen Iterator und erstellt daraus zwei Sammlungen.
    ///
    /// Das an `partition()` übergebene Prädikat kann `true` oder `false` zurückgeben.
    /// `partition()` Gibt ein Paar zurück, alle Elemente, für die `true` zurückgegeben wurde, und alle Elemente, für die `false` zurückgegeben wurde.
    ///
    ///
    /// Siehe auch [`is_partitioned()`] und [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Ordnet die Elemente dieses Iterators *an Ort und Stelle* gemäß dem angegebenen Prädikat neu an, sodass alle diejenigen, die `true` zurückgeben, allen denen vorausgehen, die `false` zurückgeben.
    ///
    /// Gibt die Anzahl der gefundenen `true`-Elemente zurück.
    ///
    /// Die relative Reihenfolge der partitionierten Elemente wird nicht beibehalten.
    ///
    /// Siehe auch [`is_partitioned()`] und [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partitionierung zwischen Evens und Odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: sollten wir uns Sorgen machen, dass die Anzahl überläuft?Der einzige Weg, mehr als zu haben
        // `usize::MAX` veränderbare Referenzen sind mit ZSTs, die für die Partitionierung nicht nützlich sind ...

        // Diese "factory"-Schließfunktionen dienen dazu, Generizität in `Self` zu vermeiden.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Suchen Sie wiederholt den ersten `false` und tauschen Sie ihn gegen den letzten `true` aus.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Überprüft, ob die Elemente dieses Iterators gemäß dem angegebenen Prädikat partitioniert sind, sodass alle Elemente, die `true` zurückgeben, allen Elementen vorausgehen, die `false` zurückgeben.
    ///
    ///
    /// Siehe auch [`partition()`] und [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Entweder testen alle Elemente `true`, oder die erste Klausel endet bei `false`, und wir prüfen, ob danach keine `true`-Elemente mehr vorhanden sind.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Eine Iteratormethode, die eine Funktion anwendet, solange sie erfolgreich zurückgegeben wird, und einen einzelnen Endwert erzeugt.
    ///
    /// `try_fold()` Es werden zwei Argumente verwendet: ein Anfangswert und ein Abschluss mit zwei Argumenten: ein 'accumulator' und ein Element.
    /// Der Abschluss wird entweder erfolgreich mit dem Wert zurückgegeben, den der Akkumulator für die nächste Iteration haben sollte, oder er gibt einen Fehler mit einem Fehlerwert zurück, der sofort (short-circuiting) an den Aufrufer zurückgesendet wird.
    ///
    ///
    /// Der Anfangswert ist der Wert, den der Akku beim ersten Aufruf hat.Wenn das Schließen des Abschlusses für jedes Element des Iterators erfolgreich war, gibt `try_fold()` den endgültigen Akkumulator als Erfolg zurück.
    ///
    /// Das Falten ist immer dann nützlich, wenn Sie eine Sammlung von etwas haben und daraus einen einzelnen Wert erzeugen möchten.
    ///
    /// # Hinweis für Implementierer
    ///
    /// Einige der anderen (forward)-Methoden haben Standardimplementierungen in Bezug auf diese. Versuchen Sie daher, dies explizit zu implementieren, wenn dies etwas Besseres als die Standardimplementierung der `for`-Schleife bewirken kann.
    ///
    /// Versuchen Sie insbesondere, diesen Aufruf `try_fold()` für die internen Teile zu verwenden, aus denen dieser Iterator besteht.
    /// Wenn mehrere Anrufe erforderlich sind, kann der `?`-Operator den Akkumulatorwert bequem verketten. Achten Sie jedoch auf alle Invarianten, die vor dieser vorzeitigen Rückkehr aufrechterhalten werden müssen.
    /// Dies ist eine `&mut self`-Methode, daher muss die Iteration fortgesetzt werden, nachdem hier ein Fehler aufgetreten ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // die überprüfte Summe aller Elemente des Arrays
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Diese Summe läuft beim Hinzufügen des 100-Elements über
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Aufgrund des Kurzschlusses sind die verbleibenden Elemente weiterhin über den Iterator verfügbar.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Eine Iteratormethode, die auf jedes Element im Iterator eine fehlbare Funktion anwendet, beim ersten Fehler stoppt und diesen Fehler zurückgibt.
    ///
    ///
    /// Dies kann auch als fehlbare Form von [`for_each()`] oder als zustandslose Version von [`try_fold()`] angesehen werden.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Es wurde kurzgeschlossen, sodass sich die verbleibenden Elemente noch im Iterator befinden:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Faltet jedes Element durch Anwenden einer Operation zu einem Akkumulator zusammen und gibt das Endergebnis zurück.
    ///
    /// `fold()` Es werden zwei Argumente verwendet: ein Anfangswert und ein Abschluss mit zwei Argumenten: ein 'accumulator' und ein Element.
    /// Der Abschluss gibt den Wert zurück, den der Akkumulator für die nächste Iteration haben sollte.
    ///
    /// Der Anfangswert ist der Wert, den der Akku beim ersten Aufruf hat.
    ///
    /// Nachdem dieser Abschluss auf jedes Element des Iterators angewendet wurde, gibt `fold()` den Akkumulator zurück.
    ///
    /// Diese Operation wird manchmal als 'reduce' oder 'inject' bezeichnet.
    ///
    /// Das Falten ist immer dann nützlich, wenn Sie eine Sammlung von etwas haben und daraus einen einzelnen Wert erzeugen möchten.
    ///
    /// Note: `fold()` und ähnliche Methoden, die den gesamten Iterator durchlaufen, werden möglicherweise nicht für unendliche Iteratoren beendet, selbst bei traits, für die ein Ergebnis in endlicher Zeit bestimmbar ist.
    ///
    /// Note: Mit [`reduce()`] kann das erste Element als Anfangswert verwendet werden, wenn der Akkumulatortyp und der Artikeltyp identisch sind.
    ///
    /// # Hinweis für Implementierer
    ///
    /// Einige der anderen (forward)-Methoden haben Standardimplementierungen in Bezug auf diese. Versuchen Sie daher, dies explizit zu implementieren, wenn dies etwas Besseres als die Standardimplementierung der `for`-Schleife bewirken kann.
    ///
    ///
    /// Versuchen Sie insbesondere, diesen Aufruf `fold()` für die internen Teile zu verwenden, aus denen dieser Iterator besteht.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // die Summe aller Elemente des Arrays
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Lassen Sie uns hier jeden Schritt der Iteration durchgehen:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Und so ist unser Endergebnis, `6`.
    ///
    /// Es ist üblich, dass Leute, die nicht oft Iteratoren verwendet haben, eine `for`-Schleife mit einer Liste von Dingen verwenden, um ein Ergebnis aufzubauen.Diese können in `fold()`s umgewandelt werden:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for-Schleife:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // Sie sind die gleichen
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduziert die Elemente auf ein einzelnes Element, indem wiederholt eine Reduzierungsoperation angewendet wird.
    ///
    /// Wenn der Iterator leer ist, wird [`None`] zurückgegeben.Andernfalls wird das Ergebnis der Reduzierung zurückgegeben.
    ///
    /// Bei Iteratoren mit mindestens einem Element entspricht dies [`fold()`] mit dem ersten Element des Iterators als Anfangswert, wobei jedes nachfolgende Element darin gefaltet wird.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Finden Sie den Maximalwert:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testet, ob jedes Element des Iterators mit einem Prädikat übereinstimmt.
    ///
    /// `all()` nimmt einen Abschluss, der `true` oder `false` zurückgibt.Dieser Abschluss wird auf jedes Element des Iterators angewendet. Wenn alle `true` zurückgeben, gilt dies auch für `all()`.
    /// Wenn einer von ihnen `false` zurückgibt, gibt er `false` zurück.
    ///
    /// `all()` ist kurzgeschlossen;Mit anderen Worten, die Verarbeitung wird beendet, sobald ein `false` gefunden wird, da das Ergebnis unabhängig davon, was sonst noch passiert, auch `false` ist.
    ///
    ///
    /// Ein leerer Iterator gibt `true` zurück.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Anhalten beim ersten `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // Wir können immer noch `iter` verwenden, da es mehr Elemente gibt.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testet, ob ein Element des Iterators mit einem Prädikat übereinstimmt.
    ///
    /// `any()` nimmt einen Abschluss, der `true` oder `false` zurückgibt.Dieser Abschluss wird auf jedes Element des Iterators angewendet. Wenn eines von ihnen `true` zurückgibt, gilt dies auch für `any()`.
    /// Wenn alle `false` zurückgeben, wird `false` zurückgegeben.
    ///
    /// `any()` ist kurzgeschlossen;Mit anderen Worten, die Verarbeitung wird beendet, sobald ein `true` gefunden wird, da das Ergebnis unabhängig davon, was sonst noch passiert, auch `true` ist.
    ///
    ///
    /// Ein leerer Iterator gibt `false` zurück.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Anhalten beim ersten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // Wir können immer noch `iter` verwenden, da es mehr Elemente gibt.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Sucht nach einem Element eines Iterators, das ein Prädikat erfüllt.
    ///
    /// `find()` nimmt einen Abschluss, der `true` oder `false` zurückgibt.
    /// Dieser Abschluss wird auf jedes Element des Iterators angewendet. Wenn eines von ihnen `true` zurückgibt, gibt `find()` [`Some(element)`] zurück.
    /// Wenn alle `false` zurückgeben, wird [`None`] zurückgegeben.
    ///
    /// `find()` ist kurzgeschlossen;Mit anderen Worten, die Verarbeitung wird beendet, sobald der Abschluss `true` zurückgibt.
    ///
    /// Da `find()` eine Referenz verwendet und viele Iteratoren über Referenzen iterieren, führt dies zu einer möglicherweise verwirrenden Situation, in der das Argument eine Doppelreferenz ist.
    ///
    /// Sie können diesen Effekt in den folgenden Beispielen mit `&&x` sehen.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Anhalten beim ersten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // Wir können immer noch `iter` verwenden, da es mehr Elemente gibt.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Beachten Sie, dass `iter.find(f)` `iter.filter(f).next()` entspricht.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Wendet die Funktion auf die Elemente des Iterators an und gibt das erste Nicht-Keine-Ergebnis zurück.
    ///
    ///
    /// `iter.find_map(f)` entspricht `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Wendet die Funktion auf die Elemente des Iterators an und gibt das erste wahre Ergebnis oder den ersten Fehler zurück.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Sucht nach einem Element in einem Iterator und gibt dessen Index zurück.
    ///
    /// `position()` nimmt einen Abschluss, der `true` oder `false` zurückgibt.
    /// Dieser Abschluss wird auf jedes Element des Iterators angewendet. Wenn eines von ihnen `true` zurückgibt, gibt `position()` [`Some(index)`] zurück.
    /// Wenn alle `false` zurückgeben, wird [`None`] zurückgegeben.
    ///
    /// `position()` ist kurzgeschlossen;Mit anderen Worten, die Verarbeitung wird beendet, sobald ein `true` gefunden wird.
    ///
    /// # Überlaufverhalten
    ///
    /// Die Methode schützt nicht vor Überläufen. Wenn also mehr als [`usize::MAX`] nicht übereinstimmende Elemente vorhanden sind, wird entweder das falsche Ergebnis oder panics erzeugt.
    ///
    /// Wenn Debug-Zusicherungen aktiviert sind, ist ein panic garantiert.
    ///
    /// # Panics
    ///
    /// Diese Funktion kann panic sein, wenn der Iterator mehr als `usize::MAX` nicht übereinstimmende Elemente enthält.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Anhalten beim ersten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // Wir können immer noch `iter` verwenden, da es mehr Elemente gibt.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Der zurückgegebene Index hängt vom Iteratorstatus ab
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Sucht von rechts nach einem Element in einem Iterator und gibt dessen Index zurück.
    ///
    /// `rposition()` nimmt einen Abschluss, der `true` oder `false` zurückgibt.
    /// Dieser Abschluss wird ab dem Ende auf jedes Element des Iterators angewendet. Wenn einer von ihnen `true` zurückgibt, gibt `rposition()` [`Some(index)`] zurück.
    ///
    /// Wenn alle `false` zurückgeben, wird [`None`] zurückgegeben.
    ///
    /// `rposition()` ist kurzgeschlossen;Mit anderen Worten, die Verarbeitung wird beendet, sobald ein `true` gefunden wird.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Anhalten beim ersten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // Wir können immer noch `iter` verwenden, da es mehr Elemente gibt.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Hier ist keine Überlaufprüfung erforderlich, da `ExactSizeIterator` impliziert, dass die Anzahl der Elemente in einen `usize` passt.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Gibt das maximale Element eines Iterators zurück.
    ///
    /// Wenn mehrere Elemente gleich maximal sind, wird das letzte Element zurückgegeben.
    /// Wenn der Iterator leer ist, wird [`None`] zurückgegeben.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Gibt das minimale Element eines Iterators zurück.
    ///
    /// Wenn mehrere Elemente gleich minimal sind, wird das erste Element zurückgegeben.
    /// Wenn der Iterator leer ist, wird [`None`] zurückgegeben.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Gibt das Element zurück, das den Maximalwert der angegebenen Funktion angibt.
    ///
    ///
    /// Wenn mehrere Elemente gleich maximal sind, wird das letzte Element zurückgegeben.
    /// Wenn der Iterator leer ist, wird [`None`] zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Gibt das Element zurück, das den Maximalwert in Bezug auf die angegebene Vergleichsfunktion angibt.
    ///
    ///
    /// Wenn mehrere Elemente gleich maximal sind, wird das letzte Element zurückgegeben.
    /// Wenn der Iterator leer ist, wird [`None`] zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Gibt das Element zurück, das den Mindestwert der angegebenen Funktion angibt.
    ///
    ///
    /// Wenn mehrere Elemente gleich minimal sind, wird das erste Element zurückgegeben.
    /// Wenn der Iterator leer ist, wird [`None`] zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Gibt das Element zurück, das den Mindestwert für die angegebene Vergleichsfunktion angibt.
    ///
    ///
    /// Wenn mehrere Elemente gleich minimal sind, wird das erste Element zurückgegeben.
    /// Wenn der Iterator leer ist, wird [`None`] zurückgegeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Kehrt die Richtung eines Iterators um.
    ///
    /// Normalerweise iterieren Iteratoren von links nach rechts.
    /// Nach der Verwendung von `rev()` iteriert stattdessen ein Iterator von rechts nach links.
    ///
    /// Dies ist nur möglich, wenn der Iterator ein Ende hat, sodass `rev()` nur auf [`DoubleEndedIterator`] funktioniert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konvertiert einen Iterator von Paaren in ein Paar von Containern.
    ///
    /// `unzip()` verbraucht einen ganzen Iterator von Paaren und erzeugt zwei Sammlungen: eine aus den linken Elementen der Paare und eine aus den rechten Elementen.
    ///
    ///
    /// Diese Funktion ist in gewissem Sinne das Gegenteil von [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Erstellt einen Iterator, der alle seine Elemente kopiert.
    ///
    /// Dies ist nützlich, wenn Sie einen Iterator über `&T` haben, aber einen Iterator über `T` benötigen.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopiert ist das gleiche wie .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Erstellt einen Iterator, der alle Elemente enthält.
    ///
    /// Dies ist nützlich, wenn Sie einen Iterator über `&T` haben, aber einen Iterator über `T` benötigen.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // geklont ist dasselbe wie .map(|&x| x) für ganze Zahlen
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Wiederholt einen Iterator endlos.
    ///
    /// Anstatt bei [`None`] anzuhalten, wird der Iterator stattdessen von vorne neu gestartet.Nach dem erneuten Durchlaufen beginnt es erneut am Anfang.Und wieder.
    /// Und wieder.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Summiert die Elemente eines Iterators.
    ///
    /// Nimmt jedes Element, addiert es und gibt das Ergebnis zurück.
    ///
    /// Ein leerer Iterator gibt den Nullwert des Typs zurück.
    ///
    /// # Panics
    ///
    /// Wenn `sum()` aufgerufen wird und ein primitiver Integer-Typ zurückgegeben wird, wird diese Methode panic, wenn die Berechnung überläuft und Debug-Zusicherungen aktiviert sind.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iteriert über den gesamten Iterator und multipliziert alle Elemente
    ///
    /// Ein leerer Iterator gibt den einen Wert des Typs zurück.
    ///
    /// # Panics
    ///
    /// Wenn `product()` aufgerufen wird und ein primitiver Integer-Typ zurückgegeben wird, wird die Methode panic verwendet, wenn die Berechnung überläuft und Debug-Zusicherungen aktiviert sind.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergleicht die Elemente dieses [`Iterator`] mit denen eines anderen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergleicht die Elemente dieses [`Iterator`] mit denen eines anderen in Bezug auf die angegebene Vergleichsfunktion.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergleicht die Elemente dieses [`Iterator`] mit denen eines anderen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergleicht die Elemente dieses [`Iterator`] mit denen eines anderen in Bezug auf die angegebene Vergleichsfunktion.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Legt fest, ob die Elemente dieses [`Iterator`] denen eines anderen [`Iterator`] entsprechen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bestimmt, ob die Elemente dieses [`Iterator`] in Bezug auf die angegebene Gleichheitsfunktion denen eines anderen X entsprechen.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bestimmt, ob die Elemente dieses [`Iterator`] nicht mit denen eines anderen [`Iterator`] übereinstimmen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Legt fest, ob die Elemente dieses [`Iterator`] [lexicographically](Ord#lexicographical-comparison) kleiner sind als die eines anderen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Legt fest, ob die Elemente dieses [`Iterator`] [lexicographically](Ord#lexicographical-comparison) kleiner oder gleich denen eines anderen sind.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Legt fest, ob die Elemente dieses [`Iterator`] [lexicographically](Ord#lexicographical-comparison) größer sind als die eines anderen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Legt fest, ob die Elemente dieses [`Iterator`] [lexicographically](Ord#lexicographical-comparison) größer oder gleich denen eines anderen sind.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Überprüft, ob die Elemente dieses Iterators sortiert sind.
    ///
    /// Das heißt, für jedes Element `a` und das folgende Element `b` muss `a <= b` gelten.Wenn der Iterator genau null oder ein Element liefert, wird `true` zurückgegeben.
    ///
    /// Beachten Sie, dass, wenn `Self::Item` nur `PartialOrd`, aber nicht `Ord` ist, die obige Definition impliziert, dass diese Funktion `false` zurückgibt, wenn zwei aufeinanderfolgende Elemente nicht vergleichbar sind.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Überprüft, ob die Elemente dieses Iterators mit der angegebenen Komparatorfunktion sortiert sind.
    ///
    /// Anstatt `PartialOrd::partial_cmp` zu verwenden, verwendet diese Funktion die angegebene `compare`-Funktion, um die Reihenfolge von zwei Elementen zu bestimmen.
    /// Abgesehen davon entspricht es [`is_sorted`];Weitere Informationen finden Sie in der Dokumentation.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Überprüft, ob die Elemente dieses Iterators mit der angegebenen Schlüsselextraktionsfunktion sortiert sind.
    ///
    /// Anstatt die Elemente des Iterators direkt zu vergleichen, vergleicht diese Funktion die Schlüssel der Elemente, wie von `f` bestimmt.
    /// Abgesehen davon entspricht es [`is_sorted`];Weitere Informationen finden Sie in der Dokumentation.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Siehe [TrustedRandomAccess]
    // Der ungewöhnliche Name ist, um Namenskollisionen bei der Methodenauflösung zu vermeiden, siehe #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}