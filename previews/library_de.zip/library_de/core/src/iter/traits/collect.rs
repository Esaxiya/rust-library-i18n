/// Konvertierung von einem [`Iterator`].
///
/// Indem Sie `FromIterator` für einen Typ implementieren, definieren Sie, wie es aus einem Iterator erstellt wird.
/// Dies ist häufig bei Typen der Fall, die eine Sammlung beschreiben.
///
/// [`FromIterator::from_iter()`] wird selten explizit aufgerufen und stattdessen über die [`Iterator::collect()`]-Methode verwendet.
///
/// Weitere Beispiele finden Sie in der [`Iterator::collect()`]'s-Dokumentation.
///
/// Siehe auch: [`IntoIterator`].
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Verwenden von [`Iterator::collect()`] zur impliziten Verwendung von `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementieren von `FromIterator` für Ihren Typ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Eine Beispielsammlung, die nur ein Wrapper über Vec ist<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Geben wir ihm einige Methoden, damit wir eine erstellen und Dinge hinzufügen können.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // und wir werden FromIterator implementieren
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Jetzt können wir einen neuen Iterator erstellen ...
/// let iter = (0..5).into_iter();
///
/// // ... und daraus eine MyCollection machen
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // sammle auch Werke!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Erstellt einen Wert aus einem Iterator.
    ///
    /// Weitere Informationen finden Sie im [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Umwandlung in einen [`Iterator`].
///
/// Durch die Implementierung von `IntoIterator` für einen Typ definieren Sie, wie dieser in einen Iterator konvertiert wird.
/// Dies ist häufig bei Typen der Fall, die eine Sammlung beschreiben.
///
/// Ein Vorteil der Implementierung von `IntoIterator` ist, dass Ihr Typ [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) wird.
///
///
/// Siehe auch: [`FromIterator`].
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementieren von `IntoIterator` für Ihren Typ:
///
/// ```
/// // Eine Beispielsammlung, die nur ein Wrapper über Vec ist<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Geben wir ihm einige Methoden, damit wir eine erstellen und Dinge hinzufügen können.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // und wir werden IntoIterator implementieren
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Jetzt können wir eine neue Kollektion machen ...
/// let mut c = MyCollection::new();
///
/// // ... füge ein paar Sachen hinzu ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... und dann in einen Iterator verwandeln:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Es ist üblich, `IntoIterator` als trait bound zu verwenden.Dadurch kann sich der Typ der Eingabesammlung ändern, solange es sich noch um einen Iterator handelt.
/// Zusätzliche Grenzen können durch Einschränken auf festgelegt werden
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Der Typ der Elemente, über die iteriert wird.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// In welche Art von Iterator verwandeln wir das?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Erstellt einen Iterator aus einem Wert.
    ///
    /// Weitere Informationen finden Sie im [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Erweitern Sie eine Sammlung mit dem Inhalt eines Iterators.
///
/// Iteratoren erzeugen eine Reihe von Werten, und Sammlungen können auch als eine Reihe von Werten betrachtet werden.
/// Der `Extend` trait schließt diese Lücke und ermöglicht es Ihnen, eine Sammlung um den Inhalt dieses Iterators zu erweitern.
/// Wenn Sie eine Sammlung mit einem bereits vorhandenen Schlüssel erweitern, wird dieser Eintrag aktualisiert, oder bei Sammlungen, die mehrere Einträge mit gleichen Schlüsseln zulassen, wird dieser Eintrag eingefügt.
///
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// // Sie können einen String mit einigen Zeichen erweitern:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementierung von `Extend`:
///
/// ```
/// // Eine Beispielsammlung, die nur ein Wrapper über Vec ist<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Geben wir ihm einige Methoden, damit wir eine erstellen und Dinge hinzufügen können.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // Da MyCollection eine Liste von i32s enthält, implementieren wir Extend für i32
/// impl Extend<i32> for MyCollection {
///
///     // Mit der konkreten Typensignatur ist dies etwas einfacher: Wir können expand auf alles aufrufen, was in einen Iterator umgewandelt werden kann, der uns i32s gibt.
///     // Weil wir i32s brauchen, um sie in MyCollection zu integrieren.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Die Implementierung ist sehr einfach: Durchlaufen Sie den Iterator und add() jedes Element für uns.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // Lassen Sie uns unsere Sammlung um drei weitere Nummern erweitern
/// c.extend(vec![1, 2, 3]);
///
/// // Wir haben diese Elemente am Ende hinzugefügt
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Erweitert eine Sammlung um den Inhalt eines Iterators.
    ///
    /// Da dies die einzige erforderliche Methode für diesen trait ist, enthalten die [trait-level]-Dokumente weitere Details.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // Sie können einen String mit einigen Zeichen erweitern:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Erweitert eine Sammlung um genau ein Element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserviert Kapazität in einer Sammlung für die angegebene Anzahl zusätzlicher Elemente.
    ///
    /// Die Standardimplementierung führt nichts aus.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}