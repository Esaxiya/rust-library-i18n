use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt einen Iterator, der genau einmal ein Element liefert.
///
/// Dies wird üblicherweise verwendet, um einen einzelnen Wert in ein [`chain()`] anderer Iterationsarten anzupassen.
/// Vielleicht haben Sie einen Iterator, der fast alles abdeckt, aber Sie benötigen einen besonderen Fall.
/// Möglicherweise haben Sie eine Funktion, die mit Iteratoren funktioniert, aber Sie müssen nur einen Wert verarbeiten.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::iter;
///
/// // eine ist die einsamste Zahl
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // Nur eine, das ist alles was wir bekommen
/// assert_eq!(None, one.next());
/// ```
///
/// Verkettung mit einem anderen Iterator.
/// Angenommen, wir möchten über jede Datei des `.foo`-Verzeichnisses, aber auch über eine Konfigurationsdatei iterieren.
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // Wir müssen von einem Iterator von DirEntry-s zu einem Iterator von PathBufs konvertieren, also verwenden wir map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // Jetzt unser Iterator nur für unsere Konfigurationsdatei
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // Verketten Sie die beiden Iteratoren zu einem großen Iterator
/// let files = dirs.chain(config);
///
/// // Dadurch erhalten wir alle Dateien in .foo sowie .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Ein Iterator, der genau einmal ein Element liefert.
///
/// Dieser `struct` wird von der [`once()`]-Funktion erstellt.Weitere Informationen finden Sie in der Dokumentation.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}