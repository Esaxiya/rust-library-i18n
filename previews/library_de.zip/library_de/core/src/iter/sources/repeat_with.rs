use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt einen neuen Iterator, der Elemente vom Typ `A` endlos wiederholt, indem der bereitgestellte Verschluss, der Repeater, angewendet wird. `F: FnMut() -> A`.
///
/// Die `repeat_with()`-Funktion ruft den Repeater immer wieder auf.
///
/// Unendliche Iteratoren wie `repeat_with()` werden häufig mit Adaptern wie [`Iterator::take()`] verwendet, um sie endlich zu machen.
///
/// Wenn der Elementtyp des benötigten Iterators [`Clone`] implementiert und es in Ordnung ist, das Quellelement im Speicher zu belassen, sollten Sie stattdessen die [`repeat()`]-Funktion verwenden.
///
///
/// Ein von `repeat_with()` erzeugter Iterator ist kein [`DoubleEndedIterator`].
/// Wenn Sie `repeat_with()` benötigen, um ein [`DoubleEndedIterator`] zurückzugeben, öffnen Sie bitte ein GitHub-Problem, in dem Ihr Anwendungsfall erläutert wird.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::iter;
///
/// // Nehmen wir an, wir haben einen Wert von einem Typ, der nicht `Clone` ist oder den wir noch nicht im Speicher haben möchten, weil er teuer ist:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ein bestimmter Wert für immer:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutation nutzen und endlich werden:
///
/// ```rust
/// use std::iter;
///
/// // Von der nullten bis zur dritten Zweierpotenz:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... und jetzt sind wir fertig
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ein Iterator, der Elemente vom Typ `A` endlos wiederholt, indem der bereitgestellte Abschluss `F: FnMut() -> A` angewendet wird.
///
///
/// Dieser `struct` wird von der [`repeat_with()`]-Funktion erstellt.
/// Weitere Informationen finden Sie in der Dokumentation.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}