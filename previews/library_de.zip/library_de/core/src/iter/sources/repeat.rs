use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt einen neuen Iterator, der ein einzelnes Element endlos wiederholt.
///
/// Die `repeat()`-Funktion wiederholt einen einzelnen Wert immer wieder.
///
/// Unendliche Iteratoren wie `repeat()` werden häufig mit Adaptern wie [`Iterator::take()`] verwendet, um sie endlich zu machen.
///
/// Wenn der Elementtyp des benötigten Iterators `Clone` nicht implementiert oder wenn Sie das wiederholte Element nicht im Speicher behalten möchten, können Sie stattdessen die [`repeat_with()`]-Funktion verwenden.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::iter;
///
/// // die Nummer vier 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Ja, immer noch vier
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Endlich mit [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // Das letzte Beispiel war zu viele vier.Lassen Sie uns nur vier vier haben.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... und jetzt sind wir fertig
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ein Iterator, der ein Element endlos wiederholt.
///
/// Dieser `struct` wird von der [`repeat()`]-Funktion erstellt.Weitere Informationen finden Sie in der Dokumentation.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}