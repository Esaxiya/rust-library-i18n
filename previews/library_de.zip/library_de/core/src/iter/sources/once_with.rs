use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt einen Iterator, der träge genau einmal einen Wert generiert, indem er den bereitgestellten Abschluss aufruft.
///
/// Dies wird üblicherweise verwendet, um einen Einzelwertgenerator an einen [`chain()`] anderer Iterationsarten anzupassen.
/// Vielleicht haben Sie einen Iterator, der fast alles abdeckt, aber Sie benötigen einen besonderen Fall.
/// Möglicherweise haben Sie eine Funktion, die mit Iteratoren funktioniert, aber Sie müssen nur einen Wert verarbeiten.
///
/// Im Gegensatz zu [`once()`] generiert diese Funktion den Wert auf Anfrage träge.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::iter;
///
/// // eine ist die einsamste Zahl
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // Nur eine, das ist alles was wir bekommen
/// assert_eq!(None, one.next());
/// ```
///
/// Verkettung mit einem anderen Iterator.
/// Angenommen, wir möchten über jede Datei des `.foo`-Verzeichnisses, aber auch über eine Konfigurationsdatei iterieren.
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // Wir müssen von einem Iterator von DirEntry-s zu einem Iterator von PathBufs konvertieren, also verwenden wir map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // Jetzt unser Iterator nur für unsere Konfigurationsdatei
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // Verketten Sie die beiden Iteratoren zu einem großen Iterator
/// let files = dirs.chain(config);
///
/// // Dadurch erhalten wir alle Dateien in .foo sowie .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ein Iterator, der durch Anwenden des bereitgestellten Verschlusses `F: FnOnce() -> A` ein einzelnes Element vom Typ `A` ergibt.
///
///
/// Dieser `struct` wird von der [`once_with()`]-Funktion erstellt.
/// Weitere Informationen finden Sie in der Dokumentation.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}