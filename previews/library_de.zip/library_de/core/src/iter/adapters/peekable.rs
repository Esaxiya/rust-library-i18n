use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Ein Iterator mit einem `peek()`, der einen optionalen Verweis auf das nächste Element zurückgibt.
///
///
/// Dieser `struct` wird von der [`peekable`]-Methode unter [`Iterator`] erstellt.
/// Weitere Informationen finden Sie in der Dokumentation.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Erinnern Sie sich an einen gespähten Wert, auch wenn es keiner war.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable muss sich daran erinnern, ob in der `.peek()`-Methode ein None angezeigt wurde.
// Es stellt sicher, dass `.peek();.peek();` oder `.peek();.next();` rückt den zugrunde liegenden Iterator höchstens einmal vor.
// Dies allein führt nicht dazu, dass der Iterator fusioniert.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Gibt einen Verweis auf den next()-Wert zurück, ohne den Iterator voranzutreiben.
    ///
    /// Wenn es wie bei [`next`] einen Wert gibt, wird dieser in einen `Some(T)` eingeschlossen.
    /// Wenn die Iteration jedoch beendet ist, wird `None` zurückgegeben.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Da `peek()` eine Referenz zurückgibt und viele Iteratoren über Referenzen iterieren, kann es zu einer möglicherweise verwirrenden Situation kommen, in der der Rückgabewert eine Doppelreferenz ist.
    /// Sie können diesen Effekt in den folgenden Beispielen sehen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() Lassen Sie uns in die future sehen
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Der Iterator rückt nicht vor, selbst wenn wir mehrmals `peek` verwenden
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Nachdem der Iterator beendet ist, ist es auch `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Gibt einen veränderlichen Verweis auf den next()-Wert zurück, ohne den Iterator voranzutreiben.
    ///
    /// Wenn es wie bei [`next`] einen Wert gibt, wird dieser in einen `Some(T)` eingeschlossen.
    /// Wenn die Iteration jedoch beendet ist, wird `None` zurückgegeben.
    ///
    /// Da `peek_mut()` eine Referenz zurückgibt und viele Iteratoren über Referenzen iterieren, kann es zu einer möglicherweise verwirrenden Situation kommen, in der der Rückgabewert eine Doppelreferenz ist.
    /// Sie können diesen Effekt in den folgenden Beispielen sehen.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Wie bei `peek()` können wir in die future sehen, ohne den Iterator voranzutreiben.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Schauen Sie in den Iterator und legen Sie den Wert hinter der veränderlichen Referenz fest.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Der Wert, den wir eingeben, wird wieder angezeigt, wenn der Iterator fortgesetzt wird.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Verbrauchen Sie den nächsten Wert dieses Iterators und geben Sie ihn zurück, wenn eine Bedingung erfüllt ist.
    /// Wenn `func` `true` für den nächsten Wert dieses Iterators zurückgibt, verbrauchen Sie ihn und geben Sie ihn zurück.
    /// Andernfalls geben Sie `None` zurück.
    /// # Examples
    /// Verbrauchen Sie eine Zahl, wenn sie gleich 0 ist.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Das erste Element des Iterators ist 0;konsumiere es.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Der nächste zurückgegebene Artikel ist jetzt 1, sodass `consume` `false` zurückgibt.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` Speichert den Wert des nächsten Elements, wenn er nicht gleich `expected` war.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Verbrauchen Sie eine beliebige Zahl unter 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Verbrauchen Sie alle Zahlen unter 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Der nächste zurückgegebene Wert ist 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Seit wir `self.next()` angerufen haben, haben wir `self.peeked` konsumiert.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Verbrauchen Sie das nächste Element und geben Sie es zurück, wenn es gleich `expected` ist.
    /// # Example
    /// Verbrauchen Sie eine Zahl, wenn sie gleich 0 ist.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Das erste Element des Iterators ist 0;konsumiere es.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Der nächste zurückgegebene Artikel ist jetzt 1, sodass `consume` `false` zurückgibt.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` Speichert den Wert des nächsten Elements, wenn er nicht gleich `expected` war.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SICHERHEIT: Weiterleitung unsicherer Funktionen an unsichere Funktionen mit denselben Anforderungen
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}