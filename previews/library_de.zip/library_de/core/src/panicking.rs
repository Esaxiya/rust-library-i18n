//! Panic-Unterstützung für libcore
//!
//! Die Kernbibliothek kann keine Panik definieren, deklariert jedoch Panik.
//! Dies bedeutet, dass die Funktionen in libcore für panic zulässig sind. Um jedoch nützlich zu sein, muss ein vorgelagertes crate die Panik definieren, damit libcore verwendet werden kann.
//! Die aktuelle Schnittstelle für Panik ist:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Diese Definition ermöglicht die Panik bei allgemeinen Nachrichten, lässt jedoch keinen Fehler bei einem `Box<Any>`-Wert zu.
//! (`PanicInfo` enthält nur ein `&(dyn Any + Send)`, für das wir in `PanicInfo: : internal_constructor` einen Dummy-Wert eingeben.) Der Grund dafür ist, dass libcore nicht zuordnen darf.
//!
//!
//! Dieses Modul enthält einige andere Panikfunktionen, die jedoch nur die für den Compiler erforderlichen Lang-Elemente sind.Alle panics werden durch diese eine Funktion geleitet.
//! Das tatsächliche Symbol wird über das `#[panic_handler]`-Attribut deklariert.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Die zugrunde liegende Implementierung des `panic!`-Makros von libcore, wenn keine Formatierung verwendet wird.
#[cold]
// Niemals inline, es sei denn, Panic_immediate_abort, um ein Aufblähen des Codes an den Anrufstellen so weit wie möglich zu vermeiden
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // Wird von Codegen für panic bei Überlauf und anderen `Assert` MIR-Terminatoren benötigt
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Verwenden Sie Arguments::new_v1 anstelle von format_args! ("{}", Ausdruck), um den Overhead möglicherweise zu reduzieren.
    // Die format_args!Das Makro verwendet die Anzeige trait von str, um expr zu schreiben, das Formatter::pad aufruft, das das Abschneiden und Auffüllen von Zeichenfolgen berücksichtigen muss (obwohl hier keine verwendet wird).
    //
    // Die Verwendung von Arguments::new_v1 kann es dem Compiler ermöglichen, Formatter::pad in der Ausgabe-Binärdatei wegzulassen, wodurch bis zu einigen Kilobyte eingespart werden.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // wird für const-evaluiertes panics benötigt
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // Wird von Codegen für panic beim OOB array/slice-Zugriff benötigt
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Die zugrunde liegende Implementierung des `panic!`-Makros von libcore bei der Formatierung wird verwendet.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // HINWEIS Diese Funktion überschreitet niemals die FFI-Grenze.Es ist ein Rust-zu-Rust-Aufruf, der in die `#[panic_handler]`-Funktion aufgelöst wird.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SICHERHEIT: `panic_impl` ist im sicheren Rust-Code definiert und kann daher sicher aufgerufen werden.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Interne Funktion für `assert_eq!`-und `assert_ne!`-Makros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}