#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Wird je nach Edition des Anrufers entweder auf `$crate::panic::panic_2015` oder `$crate::panic::panic_2021` erweitert.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Behauptet, dass zwei Ausdrücke gleich sind (unter Verwendung von [`PartialEq`]).
///
/// In panic druckt dieses Makro die Werte der Ausdrücke mit ihren Debug-Darstellungen.
///
///
/// Wie [`assert!`] hat dieses Makro eine zweite Form, in der eine benutzerdefinierte panic-Nachricht bereitgestellt werden kann.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Die folgenden Ausleihen sind beabsichtigt.
                    // Ohne sie wird der Stapelschlitz für das Ausleihen bereits vor dem Vergleich der Werte initialisiert, was zu einer spürbaren Verlangsamung führt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Die folgenden Ausleihen sind beabsichtigt.
                    // Ohne sie wird der Stapelschlitz für das Ausleihen bereits vor dem Vergleich der Werte initialisiert, was zu einer spürbaren Verlangsamung führt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Behauptet, dass zwei Ausdrücke nicht gleich sind (mit [`PartialEq`]).
///
/// In panic druckt dieses Makro die Werte der Ausdrücke mit ihren Debug-Darstellungen.
///
///
/// Wie [`assert!`] hat dieses Makro eine zweite Form, in der eine benutzerdefinierte panic-Nachricht bereitgestellt werden kann.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Die folgenden Ausleihen sind beabsichtigt.
                    // Ohne sie wird der Stapelschlitz für das Ausleihen bereits vor dem Vergleich der Werte initialisiert, was zu einer spürbaren Verlangsamung führt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Die folgenden Ausleihen sind beabsichtigt.
                    // Ohne sie wird der Stapelschlitz für das Ausleihen bereits vor dem Vergleich der Werte initialisiert, was zu einer spürbaren Verlangsamung führt.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Gibt an, dass ein boolescher Ausdruck zur Laufzeit `true` ist.
///
/// Dadurch wird das [`panic!`]-Makro aufgerufen, wenn der angegebene Ausdruck zur Laufzeit nicht für `true` ausgewertet werden kann.
///
/// Wie [`assert!`] verfügt auch dieses Makro über eine zweite Version, in der eine benutzerdefinierte panic-Nachricht bereitgestellt werden kann.
///
/// # Uses
///
/// Im Gegensatz zu [`assert!`] sind `debug_assert!`-Anweisungen standardmäßig nur in nicht optimierten Builds aktiviert.
/// Ein optimierter Build führt keine `debug_assert!`-Anweisungen aus, es sei denn, `-C debug-assertions` wird an den Compiler übergeben.
/// Dies macht `debug_assert!` nützlich für Überprüfungen, die zu teuer sind, um in einem Release-Build vorhanden zu sein, aber während der Entwicklung hilfreich sein können.
/// Das Ergebnis der Erweiterung von `debug_assert!` wird immer typgeprüft.
///
/// Eine ungeprüfte Zusicherung ermöglicht es einem Programm in einem inkonsistenten Zustand, weiter ausgeführt zu werden. Dies kann unerwartete Folgen haben, führt jedoch nicht zu Unsicherheit, solange dies nur in sicherem Code geschieht.
///
/// Die Leistungskosten von Behauptungen sind jedoch im Allgemeinen nicht messbar.
/// Das Ersetzen von [`assert!`] durch `debug_assert!` wird daher nur nach gründlicher Profilerstellung und vor allem nur in sicherem Code empfohlen!
///
/// # Examples
///
/// ```
/// // Die panic-Nachricht für diese Zusicherungen ist der Zeichenfolgenwert des angegebenen Ausdrucks.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // eine sehr einfache Funktion
/// debug_assert!(some_expensive_computation());
///
/// // mit einer benutzerdefinierten Nachricht bestätigen
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Behauptet, dass zwei Ausdrücke gleich sind.
///
/// In panic druckt dieses Makro die Werte der Ausdrücke mit ihren Debug-Darstellungen.
///
/// Im Gegensatz zu [`assert_eq!`] sind `debug_assert_eq!`-Anweisungen standardmäßig nur in nicht optimierten Builds aktiviert.
/// Ein optimierter Build führt keine `debug_assert_eq!`-Anweisungen aus, es sei denn, `-C debug-assertions` wird an den Compiler übergeben.
/// Dies macht `debug_assert_eq!` nützlich für Überprüfungen, die zu teuer sind, um in einem Release-Build vorhanden zu sein, aber während der Entwicklung hilfreich sein können.
///
/// Das Ergebnis der Erweiterung von `debug_assert_eq!` wird immer typgeprüft.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Behauptet, dass zwei Ausdrücke nicht gleich sind.
///
/// In panic druckt dieses Makro die Werte der Ausdrücke mit ihren Debug-Darstellungen.
///
/// Im Gegensatz zu [`assert_ne!`] sind `debug_assert_ne!`-Anweisungen standardmäßig nur in nicht optimierten Builds aktiviert.
/// Ein optimierter Build führt keine `debug_assert_ne!`-Anweisungen aus, es sei denn, `-C debug-assertions` wird an den Compiler übergeben.
/// Dies macht `debug_assert_ne!` nützlich für Überprüfungen, die zu teuer sind, um in einem Release-Build vorhanden zu sein, aber während der Entwicklung hilfreich sein können.
///
/// Das Ergebnis der Erweiterung von `debug_assert_ne!` wird immer typgeprüft.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Gibt zurück, ob der angegebene Ausdruck mit einem der angegebenen Muster übereinstimmt.
///
/// Wie in einem `match`-Ausdruck kann dem Muster optional `if` und ein Schutzausdruck folgen, der Zugriff auf durch das Muster gebundene Namen hat.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Packt ein Ergebnis aus oder verbreitet seinen Fehler.
///
/// Der `?`-Operator wurde hinzugefügt, um `try!` zu ersetzen, und sollte stattdessen verwendet werden.
/// Darüber hinaus ist `try` in Rust 2018 ein reserviertes Wort. Wenn Sie es also verwenden müssen, müssen Sie [raw-identifier syntax][ris] verwenden: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` entspricht dem angegebenen [`Result`].Bei der `Ok`-Variante hat der Ausdruck den Wert des umschlossenen Werts.
///
/// Bei der `Err`-Variante wird der innere Fehler abgerufen.`try!` führt dann eine Konvertierung mit `From` durch.
/// Dies ermöglicht die automatische Konvertierung zwischen speziellen und allgemeineren Fehlern.
/// Der resultierende Fehler wird dann sofort zurückgegeben.
///
/// Aufgrund der frühen Rückgabe kann `try!` nur in Funktionen verwendet werden, die [`Result`] zurückgeben.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Die bevorzugte Methode zur schnellen Rückgabe von Fehlern
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Die vorherige Methode zur schnellen Rückgabe von Fehlern
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dies entspricht:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Schreibt formatierte Daten in einen Puffer.
///
/// Dieses Makro akzeptiert ein 'writer', eine Formatzeichenfolge und eine Liste von Argumenten.
/// Argumente werden gemäß der angegebenen Formatzeichenfolge formatiert und das Ergebnis an den Writer übergeben.
/// Der Writer kann ein beliebiger Wert mit einer `write_fmt`-Methode sein.Im Allgemeinen stammt dies aus einer Implementierung des [`fmt::Write`] oder des [`io::Write`] trait.
/// Das Makro gibt alles zurück, was die `write_fmt`-Methode zurückgibt.üblicherweise ein [`fmt::Result`] oder ein [`io::Result`].
///
/// Weitere Informationen zur Format-String-Syntax finden Sie unter [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Ein Modul kann sowohl `std::fmt::Write` als auch `std::io::Write` importieren und `write!` für Objekte aufrufen, die beide implementieren, da Objekte normalerweise nicht beide implementieren.
///
/// Das Modul muss jedoch die qualifizierten traits importieren, damit ihre Namen nicht in Konflikt geraten:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // verwendet fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // verwendet io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Dieses Makro kann auch in `no_std`-Setups verwendet werden.
/// In einem `no_std`-Setup sind Sie für die Implementierungsdetails der Komponenten verantwortlich.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Schreiben Sie formatierte Daten in einen Puffer, an den eine neue Zeile angehängt ist.
///
/// Auf allen Plattformen ist die neue Zeile nur das LINE FEED-Zeichen (`\n`/`U+000A`) (keine zusätzliche CARRIAGE RETURN (`\r`/`U+000D`)).
///
/// Weitere Informationen finden Sie unter [`write!`].Informationen zur Formatzeichenfolgensyntax finden Sie unter [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Ein Modul kann sowohl `std::fmt::Write` als auch `std::io::Write` importieren und `write!` für Objekte aufrufen, die beide implementieren, da Objekte normalerweise nicht beide implementieren.
/// Das Modul muss jedoch die qualifizierten traits importieren, damit ihre Namen nicht in Konflikt geraten:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // verwendet fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // verwendet io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Zeigt nicht erreichbaren Code an.
///
/// Dies ist immer dann nützlich, wenn der Compiler nicht feststellen kann, dass Code nicht erreichbar ist.Beispielsweise:
///
/// * Passen Sie die Arme an die Schutzbedingungen an.
/// * Schleifen, die dynamisch enden.
/// * Iteratoren, die dynamisch enden.
///
/// Wenn sich herausstellt, dass der Code nicht erreichbar ist, wird das Programm sofort mit einem [`panic!`] beendet.
///
/// Das unsichere Gegenstück zu diesem Makro ist die [`unreachable_unchecked`]-Funktion, die bei Erreichen des Codes ein undefiniertes Verhalten verursacht.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dies wird immer [`panic!`].
///
/// # Examples
///
/// Matcharme:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // Kompilierungsfehler, wenn auskommentiert
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // eine der schlechtesten Implementierungen von x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Zeigt nicht implementierten Code an, indem er mit der Meldung "not implemented" in Panik gerät.
///
/// Auf diese Weise kann Ihr Code eine Typprüfung durchführen. Dies ist hilfreich, wenn Sie Prototypen erstellen oder einen trait implementieren, für den mehrere Methoden erforderlich sind, für die Sie nicht alle verwenden möchten.
///
/// Der Unterschied zwischen `unimplemented!` und [`todo!`] besteht darin, dass `todo!` zwar die Absicht vermittelt, die Funktionalität später zu implementieren, und die Nachricht "not yet implemented" lautet, `unimplemented!` jedoch keine derartigen Ansprüche geltend macht.
/// Die Nachricht lautet "not implemented".
/// Einige IDEs markieren auch "todo!".
///
/// # Panics
///
/// Dies ist immer [`panic!`], da `unimplemented!` nur eine Abkürzung für `panic!` mit einer festen, spezifischen Nachricht ist.
///
/// Wie `panic!` verfügt dieses Makro über eine zweite Form zum Anzeigen benutzerdefinierter Werte.
///
/// # Examples
///
/// Angenommen, wir haben einen trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Wir möchten `Foo` für 'MyStruct' implementieren, aber aus irgendeinem Grund ist es nur sinnvoll, die `bar()`-Funktion zu implementieren.
/// `baz()` und `qux()` müssen in unserer Implementierung von `Foo` noch definiert werden, aber wir können `unimplemented!` in ihren Definitionen verwenden, damit unser Code kompiliert werden kann.
///
/// Wir möchten weiterhin, dass unser Programm nicht mehr ausgeführt wird, wenn die nicht implementierten Methoden erreicht sind.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Es macht keinen Sinn, `baz` oder `MyStruct` zu verwenden, daher haben wir hier überhaupt keine Logik.
/////
///         // Dies zeigt "thread 'main' panicked at 'not implemented'" an.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Wir haben hier eine Logik. Wir können eine Nachricht zu nicht implementiert hinzufügen!um unsere Unterlassung anzuzeigen.
///         // Dies zeigt an: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Zeigt unfertigen Code an.
///
/// Dies kann nützlich sein, wenn Sie Prototypen erstellen und nur nach einer Überprüfung Ihres Code-Typs suchen.
///
/// Der Unterschied zwischen [`unimplemented!`] und `todo!` besteht darin, dass `todo!` zwar die Absicht vermittelt, die Funktionalität später zu implementieren, und die Nachricht "not yet implemented" lautet, `unimplemented!` jedoch keine derartigen Ansprüche geltend macht.
/// Die Nachricht lautet "not implemented".
/// Einige IDEs markieren auch "todo!".
///
/// # Panics
///
/// Dies wird immer [`panic!`].
///
/// # Examples
///
/// Hier ist ein Beispiel für einen in Bearbeitung befindlichen Code.Wir haben einen trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Wir möchten `Foo` auf einem unserer Typen implementieren, aber wir möchten auch zuerst nur an `bar()` arbeiten.Damit unser Code kompiliert werden kann, müssen wir `baz()` implementieren, damit wir `todo!` verwenden können:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // Implementierung geht hier
///     }
///
///     fn baz(&self) {
///         // Machen wir uns vorerst keine Gedanken über die Implementierung von baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // Wir verwenden nicht einmal baz(), also ist das in Ordnung.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definitionen von eingebauten Makros.
///
/// Die meisten Makroeigenschaften (Stabilität, Sichtbarkeit usw.) stammen aus dem Quellcode. Mit Ausnahme der Erweiterungsfunktionen, die Makroeingaben in Ausgaben umwandeln, werden diese Funktionen vom Compiler bereitgestellt.
///
///
pub(crate) mod builtin {

    /// Bewirkt, dass die Kompilierung mit der angegebenen Fehlermeldung fehlschlägt, wenn sie auftritt.
    ///
    /// Dieses Makro sollte verwendet werden, wenn ein crate eine bedingte Kompilierungsstrategie verwendet, um bessere Fehlermeldungen für fehlerhafte Bedingungen bereitzustellen.
    ///
    /// Es ist die Compiler-Form von [`panic!`], gibt jedoch einen Fehler während der *Kompilierung* und nicht zur *Laufzeit* aus.
    ///
    /// # Examples
    ///
    /// Zwei solche Beispiele sind Makros und `#[cfg]`-Umgebungen.
    ///
    /// Geben Sie einen besseren Compilerfehler aus, wenn einem Makro ungültige Werte übergeben werden.
    /// Ohne das endgültige branch würde der Compiler immer noch einen Fehler ausgeben, aber die Fehlermeldung würde die beiden gültigen Werte nicht erwähnen.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Compilerfehler ausgeben, wenn eine von mehreren Funktionen nicht verfügbar ist.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Erstellt Parameter für die anderen Zeichenfolgenformatierungsmakros.
    ///
    /// Dieses Makro funktioniert, indem für jedes weitere übergebene Argument ein Formatierungszeichenfolgenliteral mit `{}` verwendet wird.
    /// `format_args!` bereitet die zusätzlichen Parameter vor, um sicherzustellen, dass die Ausgabe als Zeichenfolge interpretiert werden kann, und kanonisiert die Argumente zu einem einzigen Typ.
    /// Jeder Wert, der [`Display`] trait implementiert, kann an `format_args!` übergeben werden, ebenso wie jede [`Debug`]-Implementierung innerhalb der Formatierungszeichenfolge an `{:?}` übergeben werden kann.
    ///
    ///
    /// Dieses Makro erzeugt einen Wert vom Typ [`fmt::Arguments`].Dieser Wert kann an die Makros in [`std::fmt`] übergeben werden, um eine nützliche Umleitung durchzuführen.
    /// Alle anderen Formatierungsmakros ([`format!`], [`write!`], [`println!`] usw.) werden über dieses Makro übertragen.
    /// `format_args!`, Im Gegensatz zu den abgeleiteten Makros werden Heap-Zuweisungen vermieden.
    ///
    /// Sie können den [`fmt::Arguments`]-Wert verwenden, den `format_args!` in `Debug`-und `Display`-Kontexten zurückgibt (siehe unten).
    /// Das Beispiel zeigt auch, dass `Debug` und `Display` dasselbe Format haben: die interpolierte Formatzeichenfolge in `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Weitere Informationen finden Sie in der Dokumentation zu [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Wie `format_args`, fügt jedoch am Ende eine neue Zeile hinzu.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Untersucht eine Umgebungsvariable zur Kompilierungszeit.
    ///
    /// Dieses Makro wird zur Kompilierungszeit auf den Wert der benannten Umgebungsvariablen erweitert und ergibt einen Ausdruck vom Typ `&'static str`.
    ///
    ///
    /// Wenn die Umgebungsvariable nicht definiert ist, wird ein Kompilierungsfehler ausgegeben.
    /// Verwenden Sie stattdessen das [`option_env!`]-Makro, um keinen Kompilierungsfehler auszugeben.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Sie können die Fehlermeldung anpassen, indem Sie eine Zeichenfolge als zweiten Parameter übergeben:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Wenn die Umgebungsvariable `documentation` nicht definiert ist, wird der folgende Fehler angezeigt:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Überprüft optional eine Umgebungsvariable zur Kompilierungszeit.
    ///
    /// Wenn die benannte Umgebungsvariable zur Kompilierungszeit vorhanden ist, wird dies zu einem Ausdruck vom Typ `Option<&'static str>` erweitert, dessen Wert `Some` des Werts der Umgebungsvariablen ist.
    /// Wenn die Umgebungsvariable nicht vorhanden ist, wird sie auf `None` erweitert.
    /// Weitere Informationen zu diesem Typ finden Sie unter [`Option<T>`][Option].
    ///
    /// Bei Verwendung dieses Makros wird niemals ein Kompilierungsfehler ausgegeben, unabhängig davon, ob die Umgebungsvariable vorhanden ist oder nicht.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Verkettet Bezeichner zu einem Bezeichner.
    ///
    /// Dieses Makro verwendet eine beliebige Anzahl von durch Kommas getrennten Bezeichnern und verkettet sie alle zu einem, wodurch ein Ausdruck erhalten wird, der ein neuer Bezeichner ist.
    /// Beachten Sie, dass die Hygiene dafür sorgt, dass dieses Makro keine lokalen Variablen erfassen kann.
    /// Außerdem sind Makros in der Regel nur in der Position von Elementen, Anweisungen oder Ausdrücken zulässig.
    /// Das heißt, während Sie dieses Makro verwenden können, um auf vorhandene Variablen, Funktionen oder Module usw. zu verweisen, können Sie damit kein neues definieren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (neu, lustig, name) { }//auf diese Weise nicht verwendbar!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Verkettet Literale zu einem statischen String-Slice.
    ///
    /// Dieses Makro verwendet eine beliebige Anzahl von durch Kommas getrennten Literalen und liefert einen Ausdruck vom Typ `&'static str`, der alle von links nach rechts verketteten Literale darstellt.
    ///
    ///
    /// Ganzzahl-und Gleitkomma-Literale werden zur Verkettung stringifiziert.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Erweitert sich auf die Zeilennummer, in der es aufgerufen wurde.
    ///
    /// Mit [`column!`] und [`file!`] bieten diese Makros Debugging-Informationen für Entwickler zum Speicherort in der Quelle.
    ///
    /// Der erweiterte Ausdruck hat den Typ `u32` und basiert auf 1, sodass die erste Zeile in jeder Datei mit 1, die zweite mit 2 usw. ausgewertet wird.
    /// Dies steht im Einklang mit Fehlermeldungen gängiger Compiler oder gängiger Editoren.
    /// Die zurückgegebene Zeile ist *nicht unbedingt* die Zeile des `line!`-Aufrufs selbst, sondern der erste Makroaufruf, der zum Aufruf des `line!`-Makros führt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Erweitert sich auf die Spaltennummer, unter der es aufgerufen wurde.
    ///
    /// Mit [`line!`] und [`file!`] bieten diese Makros Debugging-Informationen für Entwickler zum Speicherort in der Quelle.
    ///
    /// Der erweiterte Ausdruck hat den Typ `u32` und basiert auf 1, sodass die erste Spalte in jeder Zeile mit 1, die zweite mit 2 usw. ausgewertet wird.
    /// Dies steht im Einklang mit Fehlermeldungen gängiger Compiler oder gängiger Editoren.
    /// Die zurückgegebene Spalte ist *nicht unbedingt* die Zeile des `column!`-Aufrufs selbst, sondern der erste Makroaufruf, der zum Aufruf des `column!`-Makros führt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Erweitert sich auf den Dateinamen, in dem es aufgerufen wurde.
    ///
    /// Mit [`line!`] und [`column!`] bieten diese Makros Debugging-Informationen für Entwickler zum Speicherort in der Quelle.
    ///
    /// Der erweiterte Ausdruck hat den Typ `&'static str`, und die zurückgegebene Datei ist nicht der Aufruf des `file!`-Makros selbst, sondern der erste Makroaufruf, der zum Aufruf des `file!`-Makros führt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifiziert seine Argumente.
    ///
    /// Dieses Makro liefert einen Ausdruck vom Typ `&'static str`, der die Stringifizierung aller an das Makro übergebenen tokens darstellt.
    /// Die Syntax des Makroaufrufs selbst unterliegt keinen Einschränkungen.
    ///
    /// Beachten Sie, dass sich die erweiterten Ergebnisse der Eingabe tokens in future ändern können.Sie sollten vorsichtig sein, wenn Sie sich auf die Ausgabe verlassen.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Enthält eine UTF-8-codierte Datei als Zeichenfolge.
    ///
    /// Die Datei befindet sich relativ zur aktuellen Datei (ähnlich wie Module gefunden werden).
    /// Der angegebene Pfad wird zur Kompilierungszeit plattformspezifisch interpretiert.
    /// So würde beispielsweise ein Aufruf mit einem Windows-Pfad, der Backslashes `\` enthält, unter Unix nicht korrekt kompiliert.
    ///
    ///
    /// Dieses Makro liefert einen Ausdruck vom Typ `&'static str`, der den Inhalt der Datei darstellt.
    ///
    /// # Examples
    ///
    /// Angenommen, im selben Verzeichnis befinden sich zwei Dateien mit folgendem Inhalt:
    ///
    /// Datei 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Datei 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Wenn Sie 'main.rs' kompilieren und die resultierende Binärdatei ausführen, wird "adiós" gedruckt.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Enthält eine Datei als Referenz auf ein Byte-Array.
    ///
    /// Die Datei befindet sich relativ zur aktuellen Datei (ähnlich wie Module gefunden werden).
    /// Der angegebene Pfad wird zur Kompilierungszeit plattformspezifisch interpretiert.
    /// So würde beispielsweise ein Aufruf mit einem Windows-Pfad, der Backslashes `\` enthält, unter Unix nicht korrekt kompiliert.
    ///
    ///
    /// Dieses Makro liefert einen Ausdruck vom Typ `&'static [u8; N]`, der den Inhalt der Datei darstellt.
    ///
    /// # Examples
    ///
    /// Angenommen, im selben Verzeichnis befinden sich zwei Dateien mit folgendem Inhalt:
    ///
    /// Datei 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Datei 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Wenn Sie 'main.rs' kompilieren und die resultierende Binärdatei ausführen, wird "adiós" gedruckt.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Wird zu einer Zeichenfolge erweitert, die den aktuellen Modulpfad darstellt.
    ///
    /// Der aktuelle Modulpfad kann als Hierarchie von Modulen betrachtet werden, die zurück zum crate root führen.
    /// Die erste Komponente des zurückgegebenen Pfads ist der Name des crate, das gerade kompiliert wird.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Wertet boolesche Kombinationen von Konfigurationsflags zur Kompilierungszeit aus.
    ///
    /// Zusätzlich zum `#[cfg]`-Attribut wird dieses Makro bereitgestellt, um die Auswertung von Konfigurationsflags durch boolesche Ausdrücke zu ermöglichen.
    /// Dies führt häufig zu weniger dupliziertem Code.
    ///
    /// Die diesem Makro zugewiesene Syntax entspricht der des [`cfg`]-Attributs.
    ///
    /// `cfg!`, Im Gegensatz zu `#[cfg]` wird kein Code entfernt und nur als wahr oder falsch ausgewertet.
    /// Beispielsweise müssen alle Blöcke in einem if/else-Ausdruck gültig sein, wenn `cfg!` für die Bedingung verwendet wird, unabhängig davon, was `cfg!` auswertet.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analysiert eine Datei je nach Kontext als Ausdruck oder Element.
    ///
    /// Die Datei befindet sich relativ zur aktuellen Datei (ähnlich wie Module gefunden werden).Der angegebene Pfad wird zur Kompilierungszeit plattformspezifisch interpretiert.
    /// So würde beispielsweise ein Aufruf mit einem Windows-Pfad, der Backslashes `\` enthält, unter Unix nicht korrekt kompiliert.
    ///
    /// Die Verwendung dieses Makros ist oft eine schlechte Idee, denn wenn die Datei als Ausdruck analysiert wird, wird sie unhygienisch in den umgebenden Code eingefügt.
    /// Dies kann dazu führen, dass sich Variablen oder Funktionen von den Erwartungen der Datei unterscheiden, wenn die aktuelle Datei Variablen oder Funktionen mit demselben Namen enthält.
    ///
    ///
    /// # Examples
    ///
    /// Angenommen, im selben Verzeichnis befinden sich zwei Dateien mit folgendem Inhalt:
    ///
    /// Datei 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Datei 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Wenn Sie 'main.rs' kompilieren und die resultierende Binärdatei ausführen, wird "🙈🙊🙉🙈🙊🙉" gedruckt.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Gibt an, dass ein boolescher Ausdruck zur Laufzeit `true` ist.
    ///
    /// Dadurch wird das [`panic!`]-Makro aufgerufen, wenn der angegebene Ausdruck zur Laufzeit nicht für `true` ausgewertet werden kann.
    ///
    /// # Uses
    ///
    /// Zusicherungen werden sowohl in Debug-als auch in Release-Builds immer überprüft und können nicht deaktiviert werden.
    /// In [`debug_assert!`] finden Sie Zusicherungen, die in Release-Builds standardmäßig nicht aktiviert sind.
    ///
    /// Unsicherer Code kann sich auf `assert!` stützen, um Laufzeitinvarianten zu erzwingen, deren Verletzung zu Unsicherheit führen kann.
    ///
    /// Andere Anwendungsfälle von `assert!` umfassen das Testen und Erzwingen von Laufzeitinvarianten in sicherem Code (deren Verletzung nicht zu Unsicherheit führen kann).
    ///
    ///
    /// # Benutzerdefinierte Nachrichten
    ///
    /// Dieses Makro hat eine zweite Form, in der eine benutzerdefinierte panic-Nachricht mit oder ohne Argumente für die Formatierung bereitgestellt werden kann.
    /// Die Syntax für dieses Formular finden Sie unter [`std::fmt`].
    /// Ausdrücke, die als Formatargumente verwendet werden, werden nur ausgewertet, wenn die Zusicherung fehlschlägt.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // Die panic-Nachricht für diese Zusicherungen ist der Zeichenfolgenwert des angegebenen Ausdrucks.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // eine sehr einfache Funktion
    ///
    /// assert!(some_computation());
    ///
    /// // mit einer benutzerdefinierten Nachricht bestätigen
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline-Montage.
    ///
    /// Lesen Sie den [unstable book] für die Verwendung.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Inline-Baugruppe im LLVM-Stil.
    ///
    /// Lesen Sie den [unstable book] für die Verwendung.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline-Baugruppe auf Modulebene.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Drucke haben tokens an die Standardausgabe übergeben.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Aktiviert oder deaktiviert die Ablaufverfolgungsfunktion, die zum Debuggen anderer Makros verwendet wird.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Attributmakro zum Anwenden von Ableitungsmakros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro, das auf eine Funktion angewendet wird, um sie in einen Komponententest umzuwandeln.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro, das auf eine Funktion angewendet wird, um sie in einen Benchmark-Test umzuwandeln.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Ein Implementierungsdetail der `#[test]`-und `#[bench]`-Makros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro, das auf eine Statik angewendet wird, um sie als globalen Allokator zu registrieren.
    ///
    /// Siehe auch [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Behält das Element bei, auf das es angewendet wird, wenn auf den übergebenen Pfad zugegriffen werden kann, und entfernt es ansonsten.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Erweitert alle `#[cfg]`-und `#[cfg_attr]`-Attribute in dem Codefragment, auf das es angewendet wird.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Instabile Implementierungsdetails des `rustc`-Compilers nicht verwenden.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Instabile Implementierungsdetails des `rustc`-Compilers nicht verwenden.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}