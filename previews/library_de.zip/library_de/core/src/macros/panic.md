Panics der aktuelle Thread.

Dadurch kann ein Programm sofort beendet und dem Aufrufer des Programms eine Rückmeldung gegeben werden.
`panic!` sollte verwendet werden, wenn ein Programm einen nicht wiederherstellbaren Zustand erreicht.

Dieses Makro ist der perfekte Weg, um Bedingungen im Beispielcode und in Tests zu bestätigen.
`panic!` ist eng mit der `unwrap`-Methode von [`Option`][ounwrap]-und [`Result`][runwrap]-Aufzählungen verbunden.
Beide Implementierungen rufen `panic!` auf, wenn sie auf [`None`]-oder [`Err`]-Varianten eingestellt sind.

Bei Verwendung von `panic!()` können Sie eine Zeichenfolgennutzlast angeben, die mit der [`format!`]-Syntax erstellt wird.
Diese Nutzlast wird verwendet, wenn panic in den aufrufenden Rust-Thread injiziert wird, wodurch der Thread vollständig zu panic wird.

Das Verhalten des Standard-`std` hook, dh
Der Code, der direkt nach dem Aufrufen von panic ausgeführt wird, besteht darin, die Nachrichtennutzdaten zusammen mit den file/line/column-Informationen des `panic!()`-Aufrufs an `stderr` zu drucken.

Sie können den panic hook mit [`std::panic::set_hook()`] überschreiben.
Innerhalb des hook kann auf ein panic als `&dyn Any + Send` zugegriffen werden, das entweder `&str` oder `String` für reguläre `panic!()`-Aufrufe enthält.
Für panic mit einem Wert eines anderen Typs kann [`panic_any`] verwendet werden.

[`Result`] enum ist oft eine bessere Lösung für die Wiederherstellung nach Fehlern als die Verwendung des `panic!`-Makros.
Dieses Makro sollte verwendet werden, um zu vermeiden, dass falsche Werte verwendet werden, z. B. aus externen Quellen.
Detaillierte Informationen zur Fehlerbehandlung finden Sie im [book].

Siehe auch das Makro [`compile_error!`], um Fehler beim Kompilieren auszulösen.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Aktuelle Implementierung

Wenn der Hauptthread panics ist, werden alle Ihre Threads beendet und Ihr Programm mit dem Code `101` beendet.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





