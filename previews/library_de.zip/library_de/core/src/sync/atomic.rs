//! Atomtypen
//!
//! Atomtypen bieten primitive Shared-Memory-Kommunikation zwischen Threads und sind die Bausteine anderer gleichzeitiger Typen.
//!
//! Dieses Modul definiert atomare Versionen einer ausgewählten Anzahl primitiver Typen, einschließlich [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] usw.
//! Atomtypen stellen Operationen dar, die bei korrekter Verwendung Aktualisierungen zwischen Threads synchronisieren.
//!
//! Für jede Methode wird ein [`Ordering`] verwendet, der die Stärke der Speicherbarriere für diese Operation darstellt.Diese Bestellungen sind die gleichen wie beim [C++20 atomic orderings][1].Weitere Informationen finden Sie im [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomare Variablen können sicher zwischen Threads geteilt werden (sie implementieren [`Sync`]), bieten jedoch selbst nicht den Mechanismus für die gemeinsame Nutzung und folgen dem [threading model](../../../std/thread/index.html#the-threading-model) von Rust.
//!
//! Die gebräuchlichste Methode, eine atomare Variable gemeinsam zu nutzen, besteht darin, sie in einen [`Arc`][arc] (einen gemeinsam genutzten Zeiger mit Atomreferenzzählung) einzufügen.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomtypen können in statischen Variablen gespeichert werden, die mit konstanten Initialisierern wie [`AtomicBool::new`] initialisiert werden.Atomstatik wird häufig für eine verzögerte globale Initialisierung verwendet.
//!
//! # Portability
//!
//! Alle Atomtypen in diesem Modul sind garantiert [lock-free], wenn sie verfügbar sind.Dies bedeutet, dass sie intern keinen globalen Mutex erwerben.Es ist nicht garantiert, dass Atomtypen und Operationen wartungsfrei sind.
//! Dies bedeutet, dass Operationen wie `fetch_or` mit einer Compare-and-Swap-Schleife implementiert werden können.
//!
//! Atomoperationen können auf der Befehlsebene mit größeren Atomics implementiert werden.Beispielsweise verwenden einige Plattformen 4-Byte-Atomanweisungen, um `AtomicI8` zu implementieren.
//! Beachten Sie, dass diese Emulation keinen Einfluss auf die Korrektheit des Codes haben sollte. Es ist nur etwas, das Sie beachten sollten.
//!
//! Die Atomtypen in diesem Modul sind möglicherweise nicht auf allen Plattformen verfügbar.Die Atomtypen hier sind jedoch alle weit verbreitet und können im Allgemeinen auf existierende zurückgeführt werden.Einige bemerkenswerte Ausnahmen sind:
//!
//! * PowerPC und MIPS-Plattformen mit 32-Bit-Zeigern haben keine `AtomicU64`-oder `AtomicI64`-Typen.
//! * ARM Plattformen wie `armv5te`, die nicht für Linux geeignet sind, bieten nur `load`-und `store`-Vorgänge und unterstützen keine Compare-und Swap-(CAS)-Vorgänge wie `swap`, `fetch_add` usw.
//! Zusätzlich werden diese CAS-Vorgänge auf Linux über [operating system support] implementiert, was mit einer Leistungsbeeinträchtigung verbunden sein kann.
//! * ARM Ziele mit `thumbv6m` bieten nur `load`-und `store`-Vorgänge und unterstützen keine Compare-und Swap-(CAS)-Vorgänge wie `swap`, `fetch_add` usw.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Beachten Sie, dass möglicherweise future-Plattformen hinzugefügt werden, die auch einige atomare Operationen nicht unterstützen.Maximal portabler Code sollte darauf achten, welche Atomtypen verwendet werden.
//! `AtomicUsize` und `AtomicIsize` sind im Allgemeinen die tragbarsten, aber selbst dann sind sie nicht überall verfügbar.
//! Als Referenz benötigt die `std`-Bibliothek Atomics in Zeigergröße, `core` jedoch nicht.
//!
//! Derzeit müssen Sie `#[cfg(target_arch)]` hauptsächlich zum bedingten Kompilieren von Code mit Atomics verwenden.Es gibt auch ein instabiles `#[cfg(target_has_atomic)]`, das im future stabilisiert werden kann.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Ein einfacher Spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Warten Sie, bis der andere Thread die Sperre aufgehoben hat
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Führen Sie eine globale Anzahl von Live-Threads durch:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Ein boolescher Typ, der sicher von Threads gemeinsam genutzt werden kann.
///
/// Dieser Typ hat dieselbe speicherinterne Darstellung wie ein [`bool`].
///
/// **Hinweis**: Dieser Typ ist nur auf Plattformen verfügbar, die atomare Lasten und Speicher von `u8` unterstützen.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Erstellt einen `AtomicBool`, der auf `false` initialisiert ist.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Senden ist implizit für AtomicBool implementiert.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Ein roher Zeigertyp, der sicher von Threads gemeinsam genutzt werden kann.
///
/// Dieser Typ hat dieselbe speicherinterne Darstellung wie ein `*mut T`.
///
/// **Hinweis**: Dieser Typ ist nur auf Plattformen verfügbar, die atomare Lasten und Speicher von Zeigern unterstützen.
/// Seine Größe hängt von der Größe des Zielzeigers ab.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Erstellt eine Null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Ordnungen des atomaren Speichers
///
/// Speicherreihenfolgen geben an, wie atomare Operationen den Speicher synchronisieren.
/// In seinem schwächsten [`Ordering::Relaxed`] wird nur der Speicher synchronisiert, der direkt von der Operation berührt wird.
/// Andererseits synchronisiert ein Store-Load-Paar von [`Ordering::SeqCst`]-Operationen den anderen Speicher, während zusätzlich eine Gesamtreihenfolge solcher Operationen über alle Threads hinweg beibehalten wird.
///
///
/// Die Speicherreihenfolge von Rust ist [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Weitere Informationen finden Sie im [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Keine Ordnungsbeschränkungen, nur atomare Operationen.
    ///
    /// Entspricht [`memory_order_relaxed`] in C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// In Verbindung mit einem Geschäft werden alle vorherigen Vorgänge vor dem Laden dieses Werts mit [`Acquire`]-Bestellung (oder einer stärkeren Bestellung) bestellt.
    ///
    /// Insbesondere werden alle vorherigen Schreibvorgänge für alle Threads sichtbar, die eine [`Acquire`]-Last (oder eine stärkere Last) dieses Werts ausführen.
    ///
    /// Beachten Sie, dass die Verwendung dieser Reihenfolge für einen Vorgang, bei dem Lasten kombiniert und gespeichert werden, zu einem [`Relaxed`]-Ladevorgang führt!
    ///
    /// Diese Bestellung gilt nur für Vorgänge, die ein Geschäft ausführen können.
    ///
    /// Entspricht [`memory_order_release`] in C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Wenn in Verbindung mit einer Last der geladene Wert durch eine Speicheroperation mit [`Release`]-Reihenfolge (oder einer stärkeren Reihenfolge) geschrieben wurde, werden alle nachfolgenden Operationen nach dieser Speicherung sortiert.
    /// Insbesondere werden bei allen nachfolgenden Ladevorgängen Daten angezeigt, die vor dem Speicher geschrieben wurden.
    ///
    /// Beachten Sie, dass die Verwendung dieser Reihenfolge für einen Vorgang, bei dem Lasten und Speicher kombiniert werden, zu einem [`Relaxed`]-Speichervorgang führt!
    ///
    /// Diese Reihenfolge gilt nur für Vorgänge, die eine Last ausführen können.
    ///
    /// Entspricht [`memory_order_acquire`] in C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Hat die Auswirkungen von [`Acquire`] und [`Release`] zusammen:
    /// Für Lasten wird die [`Acquire`]-Bestellung verwendet.Für Geschäfte wird die [`Release`]-Bestellung verwendet.
    ///
    /// Beachten Sie, dass es im Fall von `compare_and_swap` möglich ist, dass der Vorgang keinen Speicher ausführt und daher nur die [`Acquire`]-Bestellung hat.
    ///
    /// `AcqRel` führt jedoch niemals [`Relaxed`]-Zugriffe durch.
    ///
    /// Diese Reihenfolge gilt nur für Vorgänge, bei denen sowohl Ladungen als auch Lager kombiniert werden.
    ///
    /// Entspricht [`memory_order_acq_rel`] in C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Wie [`Acquire`]/[`Release`]/[`AcqRel`](für Lade-, Speicher-und Lade-mit-Speicher-Operationen) mit der zusätzlichen Garantie, dass alle Threads alle sequentiell konsistenten Operationen in derselben Reihenfolge sehen .
    ///
    ///
    /// Entspricht [`memory_order_seq_cst`] in C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Ein [`AtomicBool`] wurde auf `false` initialisiert.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Erstellt einen neuen `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Gibt einen veränderlichen Verweis auf das zugrunde liegende [`bool`] zurück.
    ///
    /// Dies ist sicher, da die veränderbare Referenz garantiert, dass keine anderen Threads gleichzeitig auf die Atomdaten zugreifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SICHERHEIT: Die veränderbare Referenz garantiert ein einzigartiges Eigentum.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Erhalten Sie atomaren Zugriff auf einen `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SICHERHEIT: Die veränderbare Referenz garantiert ein einzigartiges Eigentum und
        // Die Ausrichtung von `bool` und `Self` ist 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Verbraucht das Atom und gibt den enthaltenen Wert zurück.
    ///
    /// Dies ist sicher, da die Übergabe von `self` als Wert garantiert, dass keine anderen Threads gleichzeitig auf die Atomdaten zugreifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Lädt einen Wert aus dem bool.
    ///
    /// `load` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
    /// Mögliche Werte sind [`SeqCst`], [`Acquire`] und [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, wenn `order` [`Release`] oder [`AcqRel`] ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SICHERHEIT: Datenrennen werden durch atomare Eigenheiten und Rohdaten verhindert
        // Der übergebene Zeiger ist gültig, da wir ihn von einer Referenz erhalten haben.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Speichert einen Wert im bool.
    ///
    /// `store` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
    /// Mögliche Werte sind [`SeqCst`], [`Release`] und [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, wenn `order` [`Acquire`] oder [`AcqRel`] ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SICHERHEIT: Datenrennen werden durch atomare Eigenheiten und Rohdaten verhindert
        // Der übergebene Zeiger ist gültig, da wir ihn von einer Referenz erhalten haben.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Speichert einen Wert im bool und gibt den vorherigen Wert zurück.
    ///
    /// `swap` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
    /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
    ///
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Speichert einen Wert im [`bool`], wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
    ///
    /// Der Rückgabewert ist immer der vorherige Wert.Wenn es gleich `current` ist, wurde der Wert aktualisiert.
    ///
    /// `compare_and_swap` verwendet auch ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
    /// Beachten Sie, dass der Vorgang selbst bei Verwendung von [`AcqRel`] möglicherweise fehlschlägt und daher nur einen `Acquire`-Ladevorgang ausführt, jedoch keine `Release`-Semantik aufweist.
    /// Wenn Sie [`Acquire`] verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], wenn dies geschieht, und wenn Sie [`Release`] verwenden, wird der Ladeteil [`Relaxed`].
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Migration auf `compare_exchange` und `compare_exchange_weak`
    ///
    /// `compare_and_swap` entspricht `compare_exchange` mit der folgenden Zuordnung für Speicherreihenfolgen:
    ///
    /// Original |Erfolg |Fehler
    /// -------- | ------- | -------
    /// Entspannt |Entspannt |Entspannt erwerben |Erwerben |Release erwerben |Release |Entspanntes AcqRel |AcqRel |Erwerben Sie SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` darf auch bei erfolgreichem Vergleich fälschlicherweise fehlschlagen, wodurch der Compiler besseren Assembler-Code generieren kann, wenn der Vergleich und der Austausch in einer Schleife verwendet werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Speichert einen Wert im [`bool`], wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
    ///
    /// Der Rückgabewert ist ein Ergebnis, das angibt, ob der neue Wert geschrieben wurde und den vorherigen Wert enthält.
    /// Bei Erfolg ist dieser Wert garantiert gleich `current`.
    ///
    /// `compare_exchange` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
    /// `success` beschreibt die erforderliche Reihenfolge für den Lese-, Änderungs-und Schreibvorgang, der ausgeführt wird, wenn der Vergleich mit `current` erfolgreich ist.
    /// `failure` beschreibt die erforderliche Reihenfolge für den Ladevorgang, der stattfindet, wenn der Vergleich fehlschlägt.
    /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] erfolgreich geladen.
    ///
    /// Die Fehlerreihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Speichert einen Wert im [`bool`], wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
    ///
    /// Im Gegensatz zu [`AtomicBool::compare_exchange`] kann diese Funktion auch bei erfolgreichem Vergleich fälschlicherweise fehlschlagen, was auf einigen Plattformen zu effizienterem Code führen kann.
    ///
    /// Der Rückgabewert ist ein Ergebnis, das angibt, ob der neue Wert geschrieben wurde und den vorherigen Wert enthält.
    ///
    /// `compare_exchange_weak` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
    /// `success` beschreibt die erforderliche Reihenfolge für den Lese-, Änderungs-und Schreibvorgang, der ausgeführt wird, wenn der Vergleich mit `current` erfolgreich ist.
    /// `failure` beschreibt die erforderliche Reihenfolge für den Ladevorgang, der stattfindet, wenn der Vergleich fehlschlägt.
    /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] erfolgreich geladen.
    /// Die Fehlerreihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logisches "and" mit einem booleschen Wert.
    ///
    /// Führt eine logische "and"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
    ///
    /// Gibt den vorherigen Wert zurück.
    ///
    /// `fetch_and` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
    /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
    ///
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisches "nand" mit einem booleschen Wert.
    ///
    /// Führt eine logische "nand"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
    ///
    /// Gibt den vorherigen Wert zurück.
    ///
    /// `fetch_nand` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
    /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
    ///
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Wir können atomic_nand hier nicht verwenden, da dies zu einem bool mit einem ungültigen Wert führen kann.
        // Dies geschieht, weil die atomare Operation intern mit einer 8-Bit-Ganzzahl ausgeführt wird, die die oberen 7 Bits setzen würde.
        //
        // Also verwenden wir stattdessen einfach fetch_xor oder swap.
        if val {
            // ! (x&true)== !x Wir müssen den bool invertieren.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Wir müssen bool auf true setzen.
            //
            self.swap(true, order)
        }
    }

    /// Logisches "or" mit einem booleschen Wert.
    ///
    /// Führt eine logische "or"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
    ///
    /// Gibt den vorherigen Wert zurück.
    ///
    /// `fetch_or` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
    /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
    ///
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisches "xor" mit einem booleschen Wert.
    ///
    /// Führt eine logische "xor"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
    ///
    /// Gibt den vorherigen Wert zurück.
    ///
    /// `fetch_xor` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
    /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
    ///
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Gibt einen veränderlichen Zeiger auf das zugrunde liegende [`bool`] zurück.
    ///
    /// Das Ausführen nichtatomarer Lese-und Schreibvorgänge für die resultierende Ganzzahl kann ein Datenrennen sein.
    /// Diese Methode ist vor allem für FFI nützlich, bei denen die Funktionssignatur möglicherweise `*mut bool` anstelle von `&AtomicBool` verwendet.
    ///
    /// Das Zurückgeben eines `*mut`-Zeigers von einem gemeinsamen Verweis auf dieses Atom ist sicher, da die Atomtypen mit innerer Veränderlichkeit arbeiten.
    /// Alle Änderungen eines Atoms ändern den Wert über eine gemeinsame Referenz und können dies sicher tun, solange sie atomare Operationen verwenden.
    /// Jede Verwendung des zurückgegebenen Rohzeigers erfordert einen `unsafe`-Block und muss dennoch dieselbe Einschränkung einhalten: Operationen daran müssen atomar sein.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Ruft den Wert ab und wendet eine Funktion darauf an, die einen optionalen neuen Wert zurückgibt.Gibt ein `Result` von `Ok(previous_value)` zurück, wenn die Funktion `Some(_)` zurückgegeben hat, andernfalls `Err(previous_value)`.
    ///
    /// Note: Dies kann die Funktion mehrmals aufrufen, wenn der Wert in der Zwischenzeit von anderen Threads geändert wurde, solange die Funktion `Some(_)` zurückgibt, die Funktion jedoch nur einmal auf den gespeicherten Wert angewendet wurde.
    ///
    ///
    /// `fetch_update` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
    /// Die erste beschreibt die erforderliche Reihenfolge, wenn der Vorgang endgültig erfolgreich ist, während die zweite die erforderliche Reihenfolge für Lasten beschreibt.
    /// Diese entsprechen den Erfolgs-und Fehlerreihenfolgen von [`AtomicBool::compare_exchange`].
    ///
    /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieses Vorgangs [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] endgültig erfolgreich geladen.
    /// Die (failed)-Ladereihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unter `u8` unterstützen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Erstellt einen neuen `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Gibt eine veränderbare Referenz auf den zugrunde liegenden Zeiger zurück.
    ///
    /// Dies ist sicher, da die veränderbare Referenz garantiert, dass keine anderen Threads gleichzeitig auf die Atomdaten zugreifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Erhalten Sie atomaren Zugriff auf einen Zeiger.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - Die veränderbare Referenz garantiert ein einzigartiges Eigentum.
        //  - Die Ausrichtung von `*mut T` und `Self` ist auf allen von rust unterstützten Plattformen gleich, wie oben überprüft.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Verbraucht das Atom und gibt den enthaltenen Wert zurück.
    ///
    /// Dies ist sicher, da die Übergabe von `self` als Wert garantiert, dass keine anderen Threads gleichzeitig auf die Atomdaten zugreifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Lädt einen Wert aus dem Zeiger.
    ///
    /// `load` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
    /// Mögliche Werte sind [`SeqCst`], [`Acquire`] und [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, wenn `order` [`Release`] oder [`AcqRel`] ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Speichert einen Wert im Zeiger.
    ///
    /// `store` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
    /// Mögliche Werte sind [`SeqCst`], [`Release`] und [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, wenn `order` [`Acquire`] oder [`AcqRel`] ist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Speichert einen Wert im Zeiger und gibt den vorherigen Wert zurück.
    ///
    /// `swap` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
    /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
    ///
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen an Zeigern unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Speichert einen Wert im Zeiger, wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
    ///
    /// Der Rückgabewert ist immer der vorherige Wert.Wenn es gleich `current` ist, wurde der Wert aktualisiert.
    ///
    /// `compare_and_swap` verwendet auch ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
    /// Beachten Sie, dass der Vorgang selbst bei Verwendung von [`AcqRel`] möglicherweise fehlschlägt und daher nur einen `Acquire`-Ladevorgang ausführt, jedoch keine `Release`-Semantik aufweist.
    /// Wenn Sie [`Acquire`] verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], wenn dies geschieht, und wenn Sie [`Release`] verwenden, wird der Ladeteil [`Relaxed`].
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen an Zeigern unterstützen.
    ///
    /// # Migration auf `compare_exchange` und `compare_exchange_weak`
    ///
    /// `compare_and_swap` entspricht `compare_exchange` mit der folgenden Zuordnung für Speicherreihenfolgen:
    ///
    /// Original |Erfolg |Fehler
    /// -------- | ------- | -------
    /// Entspannt |Entspannt |Entspannt erwerben |Erwerben |Release erwerben |Release |Entspanntes AcqRel |AcqRel |Erwerben Sie SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` darf auch bei erfolgreichem Vergleich fälschlicherweise fehlschlagen, wodurch der Compiler besseren Assembler-Code generieren kann, wenn der Vergleich und der Austausch in einer Schleife verwendet werden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Speichert einen Wert im Zeiger, wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
    ///
    /// Der Rückgabewert ist ein Ergebnis, das angibt, ob der neue Wert geschrieben wurde und den vorherigen Wert enthält.
    /// Bei Erfolg ist dieser Wert garantiert gleich `current`.
    ///
    /// `compare_exchange` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
    /// `success` beschreibt die erforderliche Reihenfolge für den Lese-, Änderungs-und Schreibvorgang, der ausgeführt wird, wenn der Vergleich mit `current` erfolgreich ist.
    /// `failure` beschreibt die erforderliche Reihenfolge für den Ladevorgang, der stattfindet, wenn der Vergleich fehlschlägt.
    /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] erfolgreich geladen.
    ///
    /// Die Fehlerreihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen an Zeigern unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Speichert einen Wert im Zeiger, wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
    ///
    /// Im Gegensatz zu [`AtomicPtr::compare_exchange`] kann diese Funktion auch bei erfolgreichem Vergleich fälschlicherweise fehlschlagen, was auf einigen Plattformen zu effizienterem Code führen kann.
    ///
    /// Der Rückgabewert ist ein Ergebnis, das angibt, ob der neue Wert geschrieben wurde und den vorherigen Wert enthält.
    ///
    /// `compare_exchange_weak` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
    /// `success` beschreibt die erforderliche Reihenfolge für den Lese-, Änderungs-und Schreibvorgang, der ausgeführt wird, wenn der Vergleich mit `current` erfolgreich ist.
    /// `failure` beschreibt die erforderliche Reihenfolge für den Ladevorgang, der stattfindet, wenn der Vergleich fehlschlägt.
    /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] erfolgreich geladen.
    /// Die Fehlerreihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen an Zeigern unterstützen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SICHERHEIT: Diese Eigenschaft ist unsicher, da sie mit einem Rohzeiger arbeitet
        // Wir wissen jedoch mit Sicherheit, dass der Zeiger gültig ist (wir haben ihn gerade von einem `UnsafeCell` erhalten, auf den wir als Referenz verweisen), und die atomare Operation selbst ermöglicht es uns, den `UnsafeCell`-Inhalt sicher zu mutieren.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Ruft den Wert ab und wendet eine Funktion darauf an, die einen optionalen neuen Wert zurückgibt.Gibt ein `Result` von `Ok(previous_value)` zurück, wenn die Funktion `Some(_)` zurückgegeben hat, andernfalls `Err(previous_value)`.
    ///
    /// Note: Dies kann die Funktion mehrmals aufrufen, wenn der Wert in der Zwischenzeit von anderen Threads geändert wurde, solange die Funktion `Some(_)` zurückgibt, die Funktion jedoch nur einmal auf den gespeicherten Wert angewendet wurde.
    ///
    ///
    /// `fetch_update` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
    /// Die erste beschreibt die erforderliche Reihenfolge, wenn der Vorgang endgültig erfolgreich ist, während die zweite die erforderliche Reihenfolge für Lasten beschreibt.
    /// Diese entsprechen den Erfolgs-und Fehlerreihenfolgen von [`AtomicPtr::compare_exchange`].
    ///
    /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieses Vorgangs [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] endgültig erfolgreich geladen.
    /// Die (failed)-Ladereihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
    ///
    /// **Note:** Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen an Zeigern unterstützen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Konvertiert einen `bool` in einen `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Dieses Makro wird auf einigen Architekturen nicht verwendet.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Ein ganzzahliger Typ, der sicher von Threads gemeinsam genutzt werden kann.
        ///
        /// Dieser Typ hat dieselbe speicherinterne Darstellung wie der zugrunde liegende Integer-Typ [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Weitere Informationen zu den Unterschieden zwischen Atomtypen und nichtatomaren Typen sowie Informationen zur Portabilität dieses Typs finden Sie im [module-level documentation].
        ///
        ///
        /// **Note:** Dieser Typ ist nur auf Plattformen verfügbar, die atomare Lasten und Speicher von [`unterstützen
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Eine atomare Ganzzahl, die auf `0` initialisiert wurde.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Senden ist implizit implementiert.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Erstellt eine neue atomare Ganzzahl.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Gibt einen veränderlichen Verweis auf die zugrunde liegende Ganzzahl zurück.
            ///
            /// Dies ist sicher, da die veränderbare Referenz garantiert, dass keine anderen Threads gleichzeitig auf die Atomdaten zugreifen.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - Die veränderbare Referenz garantiert ein einzigartiges Eigentum.
                //  - Die Ausrichtung von `$int_type` und `Self` ist dieselbe, wie von $cfg_align versprochen und oben überprüft.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Verbraucht das Atom und gibt den enthaltenen Wert zurück.
            ///
            /// Dies ist sicher, da die Übergabe von `self` als Wert garantiert, dass keine anderen Threads gleichzeitig auf die Atomdaten zugreifen.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Lädt einen Wert aus der atomaren Ganzzahl.
            ///
            /// `load` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
            /// Mögliche Werte sind [`SeqCst`], [`Acquire`] und [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, wenn `order` [`Release`] oder [`AcqRel`] ist.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Speichert einen Wert in der atomaren Ganzzahl.
            ///
            /// `store` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
            ///  Mögliche Werte sind [`SeqCst`], [`Release`] und [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, wenn `order` [`Acquire`] oder [`AcqRel`] ist.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Speichert einen Wert in der atomaren Ganzzahl und gibt den vorherigen Wert zurück.
            ///
            /// `swap` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Speichert einen Wert in der atomaren Ganzzahl, wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
            ///
            /// Der Rückgabewert ist immer der vorherige Wert.Wenn es gleich `current` ist, wurde der Wert aktualisiert.
            ///
            /// `compare_and_swap` verwendet auch ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.
            /// Beachten Sie, dass der Vorgang selbst bei Verwendung von [`AcqRel`] möglicherweise fehlschlägt und daher nur einen `Acquire`-Ladevorgang ausführt, jedoch keine `Release`-Semantik aufweist.
            ///
            /// Wenn Sie [`Acquire`] verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], wenn dies geschieht, und wenn Sie [`Release`] verwenden, wird der Ladeteil [`Relaxed`].
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migration auf `compare_exchange` und `compare_exchange_weak`
            ///
            /// `compare_and_swap` entspricht `compare_exchange` mit der folgenden Zuordnung für Speicherreihenfolgen:
            ///
            /// Original |Erfolg |Fehler
            /// -------- | ------- | -------
            /// Entspannt |Entspannt |Entspannt erwerben |Erwerben |Release erwerben |Release |Entspanntes AcqRel |AcqRel |Erwerben Sie SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` darf auch bei erfolgreichem Vergleich fälschlicherweise fehlschlagen, wodurch der Compiler besseren Assembler-Code generieren kann, wenn der Vergleich und der Austausch in einer Schleife verwendet werden.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Speichert einen Wert in der atomaren Ganzzahl, wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
            ///
            /// Der Rückgabewert ist ein Ergebnis, das angibt, ob der neue Wert geschrieben wurde und den vorherigen Wert enthält.
            /// Bei Erfolg ist dieser Wert garantiert gleich `current`.
            ///
            /// `compare_exchange` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
            /// `success` beschreibt die erforderliche Reihenfolge für den Lese-, Änderungs-und Schreibvorgang, der ausgeführt wird, wenn der Vergleich mit `current` erfolgreich ist.
            /// `failure` beschreibt die erforderliche Reihenfolge für den Ladevorgang, der stattfindet, wenn der Vergleich fehlschlägt.
            /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] erfolgreich geladen.
            ///
            /// Die Fehlerreihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Speichert einen Wert in der atomaren Ganzzahl, wenn der aktuelle Wert mit dem `current`-Wert übereinstimmt.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// Diese Funktion kann fälschlicherweise fehlschlagen, selbst wenn der Vergleich erfolgreich ist, was auf einigen Plattformen zu effizienterem Code führen kann.
            /// Der Rückgabewert ist ein Ergebnis, das angibt, ob der neue Wert geschrieben wurde und den vorherigen Wert enthält.
            ///
            /// `compare_exchange_weak` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
            /// `success` beschreibt die erforderliche Reihenfolge für den Lese-, Änderungs-und Schreibvorgang, der ausgeführt wird, wenn der Vergleich mit `current` erfolgreich ist.
            /// `failure` beschreibt die erforderliche Reihenfolge für den Ladevorgang, der stattfindet, wenn der Vergleich fehlschlägt.
            /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieser Operation [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] erfolgreich geladen.
            ///
            /// Die Fehlerreihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// Schleife {lass neu=alt * 2;
            ///     Übereinstimmung mit val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Fügt den aktuellen Wert hinzu und gibt den vorherigen Wert zurück.
            ///
            /// Dieser Vorgang wird beim Überlauf umgangen.
            ///
            /// `fetch_add` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Subtrahiert vom aktuellen Wert und gibt den vorherigen Wert zurück.
            ///
            /// Dieser Vorgang wird beim Überlauf umgangen.
            ///
            /// `fetch_sub` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitweises "and" mit dem aktuellen Wert.
            ///
            /// Führt eine bitweise "and"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
            ///
            /// Gibt den vorherigen Wert zurück.
            ///
            /// `fetch_and` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitweises "nand" mit dem aktuellen Wert.
            ///
            /// Führt eine bitweise "nand"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
            ///
            /// Gibt den vorherigen Wert zurück.
            ///
            /// `fetch_nand` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitweises "or" mit dem aktuellen Wert.
            ///
            /// Führt eine bitweise "or"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
            ///
            /// Gibt den vorherigen Wert zurück.
            ///
            /// `fetch_or` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitweises "xor" mit dem aktuellen Wert.
            ///
            /// Führt eine bitweise "xor"-Operation für den aktuellen Wert und das Argument `val` aus und setzt den neuen Wert auf das Ergebnis.
            ///
            /// Gibt den vorherigen Wert zurück.
            ///
            /// `fetch_xor` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Ruft den Wert ab und wendet eine Funktion darauf an, die einen optionalen neuen Wert zurückgibt.Gibt ein `Result` von `Ok(previous_value)` zurück, wenn die Funktion `Some(_)` zurückgegeben hat, andernfalls `Err(previous_value)`.
            ///
            /// Note: Dies kann die Funktion mehrmals aufrufen, wenn der Wert in der Zwischenzeit von anderen Threads geändert wurde, solange die Funktion `Some(_)` zurückgibt, die Funktion jedoch nur einmal auf den gespeicherten Wert angewendet wurde.
            ///
            ///
            /// `fetch_update` verwendet zwei [`Ordering`]-Argumente, um die Speicherreihenfolge dieser Operation zu beschreiben.
            /// Die erste beschreibt die erforderliche Reihenfolge, wenn der Vorgang endgültig erfolgreich ist, während die zweite die erforderliche Reihenfolge für Lasten beschreibt.Diese entsprechen den Erfolgs-und Misserfolgsreihenfolgen von
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Wenn Sie [`Acquire`] als Erfolgsreihenfolge verwenden, wird der Speicher Teil dieses Vorgangs [`Relaxed`], und wenn Sie [`Release`] verwenden, wird [`Relaxed`] endgültig erfolgreich geladen.
            /// Die (failed)-Ladereihenfolge kann nur [`SeqCst`], [`Acquire`] oder [`Relaxed`] sein und muss der Erfolgsreihenfolge entsprechen oder schwächer sein.
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximum mit dem aktuellen Wert.
            ///
            /// Findet das Maximum des aktuellen Werts und des Arguments `val` und setzt den neuen Wert auf das Ergebnis.
            ///
            /// Gibt den vorherigen Wert zurück.
            ///
            /// `fetch_max` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// sei bar=42;
            /// let max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// assert! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum mit dem aktuellen Wert.
            ///
            /// Findet das Minimum des aktuellen Werts und des Arguments `val` und setzt den neuen Wert auf das Ergebnis.
            ///
            /// Gibt den vorherigen Wert zurück.
            ///
            /// `fetch_min` Nimmt ein [`Ordering`]-Argument, das die Speicherreihenfolge dieser Operation beschreibt.Alle Bestellmodi sind möglich.
            /// Beachten Sie, dass die Verwendung von [`Acquire`] den Speicherteil dieser Operation zu [`Relaxed`] macht und die Verwendung von [`Release`] den Ladeteil zu [`Relaxed`] macht.
            ///
            ///
            /// **Hinweis**: Diese Methode ist nur auf Plattformen verfügbar, die atomare Operationen unterstützen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// sei bar=12;
            /// let min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICHERHEIT: Datenrennen werden durch atomare Intrinsics verhindert.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Gibt einen veränderlichen Zeiger auf die zugrunde liegende Ganzzahl zurück.
            ///
            /// Das Ausführen nichtatomarer Lese-und Schreibvorgänge für die resultierende Ganzzahl kann ein Datenrennen sein.
            /// Diese Methode ist vor allem für FFI nützlich, bei denen die Funktionssignatur verwendet werden kann
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Das Zurückgeben eines `*mut`-Zeigers von einem gemeinsamen Verweis auf dieses Atom ist sicher, da die Atomtypen mit innerer Veränderlichkeit arbeiten.
            /// Alle Änderungen eines Atoms ändern den Wert über eine gemeinsame Referenz und können dies sicher tun, solange sie atomare Operationen verwenden.
            /// Jede Verwendung des zurückgegebenen Rohzeigers erfordert einen `unsafe`-Block und muss dennoch dieselbe Einschränkung einhalten: Operationen daran müssen atomar sein.
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) ignorieren
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SICHERHEIT: Sicher, solange `my_atomic_op` atomar ist.
            /// unsicher {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_store` einhalten.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_load` einhalten.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_swap` einhalten.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Gibt den vorherigen Wert zurück (wie __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_add` einhalten.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Gibt den vorherigen Wert zurück (wie __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_sub` einhalten.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_compare_exchange` einhalten.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_compare_exchange_weak` einhalten.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_and` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_nand` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_or` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_xor` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// gibt den Maximalwert zurück (vorzeichenbehafteter Vergleich)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_max` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// gibt den Mindestwert zurück (vorzeichenbehafteter Vergleich)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_min` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// gibt den Maximalwert zurück (vorzeichenloser Vergleich)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_umax` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// gibt den Min-Wert zurück (vorzeichenloser Vergleich)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `atomic_umin` einhalten
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Ein Atomzaun.
///
/// Abhängig von der angegebenen Reihenfolge verhindert ein Zaun, dass der Compiler und die CPU bestimmte Arten von Speicheroperationen um ihn herum neu anordnen.
/// Dadurch werden Synchronisierungen mit Beziehungen zwischen ihm und atomaren Operationen oder Zäunen in anderen Threads erstellt.
///
/// Ein Zaun 'A' mit (mindestens) [`Release`]-Ordnungssemantik synchronisiert mit einem Zaun 'B' mit (mindestens) [`Acquire`]-Semantik, wenn und nur wenn Operationen X und Y existieren, die beide auf einem Atomobjekt 'M' arbeiten, so dass A zuvor sequenziert wird X, Y wird synchronisiert, bevor B und Y die Änderung zu M beobachten.
/// Dies liefert eine Abhängigkeit zwischen A und B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomische Operationen mit [`Release`]-oder [`Acquire`]-Semantik können auch mit einem Zaun synchronisiert werden.
///
/// Ein Zaun mit [`SeqCst`]-Reihenfolge sowie einer [`Acquire`]-und [`Release`]-Semantik nimmt an der globalen Programmreihenfolge der anderen [`SeqCst`]-Operationen und/oder-Zäune teil.
///
/// Akzeptiert [`Acquire`]-, [`Release`]-, [`AcqRel`]-und [`SeqCst`]-Bestellungen.
///
/// # Panics
///
/// Panics, wenn `order` [`Relaxed`] ist.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Ein auf Spinlock basierendes Grundelement für gegenseitigen Ausschluss.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Warten Sie, bis der alte Wert `false` ist.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Dieser Zaun wird mit dem Speicher in `unlock` synchronisiert.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SICHERHEIT: Die Verwendung eines Atomzauns ist sicher.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ein Compiler-Speicherzaun.
///
/// `compiler_fence` gibt keinen Maschinencode aus, schränkt jedoch die Art des Speichers ein, den der Compiler neu anordnen darf.Abhängig von der gegebenen [`Ordering`]-Semantik kann es dem Compiler insbesondere untersagt sein, Lese-oder Schreibvorgänge vor oder nach dem Aufruf auf die andere Seite des Aufrufs von `compiler_fence` zu verschieben.Beachten Sie, dass dies die *Hardware* nicht daran hindert, eine solche Nachbestellung durchzuführen.
///
/// Dies ist in einem Single-Thread-Ausführungskontext kein Problem. Wenn jedoch andere Threads gleichzeitig den Speicher ändern können, sind stärkere Synchronisationsprimitive wie [`fence`] erforderlich.
///
/// Die durch die unterschiedliche Ordnungssemantik verhinderte Neuordnung ist:
///
///  - Mit [`SeqCst`] ist keine Neuordnung von Lese-und Schreibvorgängen über diesen Punkt hinweg zulässig.
///  - Mit [`Release`] können vorhergehende Lese-und Schreibvorgänge nicht über nachfolgende Schreibvorgänge hinaus verschoben werden.
///  - Mit [`Acquire`] können nachfolgende Lese-und Schreibvorgänge nicht vor vorhergehenden Lesevorgängen verschoben werden.
///  - Mit [`AcqRel`] werden beide oben genannten Regeln durchgesetzt.
///
/// `compiler_fence` ist im Allgemeinen nur nützlich, um zu verhindern, dass ein Thread *mit sich selbst* rast.Das heißt, wenn ein bestimmter Thread einen Codeteil ausführt und dann unterbrochen wird und an anderer Stelle mit der Ausführung von Code beginnt (während er sich noch im selben Thread und konzeptionell immer noch im selben Kern befindet).In herkömmlichen Programmen kann dies nur auftreten, wenn ein Signalhandler registriert ist.
/// In Code auf niedrigerer Ebene können solche Situationen auch auftreten, wenn Interrupts behandelt werden, wenn grüne Threads mit Vorkaufsrecht implementiert werden usw.
/// Neugierige Leser werden ermutigt, die Diskussion des Linux-Kernels über [memory barriers] zu lesen.
///
/// # Panics
///
/// Panics, wenn `order` [`Relaxed`] ist.
///
/// # Examples
///
/// Ohne `compiler_fence` ist der Erfolg von `assert_eq!` im folgenden Code *nicht* garantiert, obwohl alles in einem einzigen Thread geschieht.
/// Um zu sehen, warum, denken Sie daran, dass der Compiler die Speicher frei auf `IMPORTANT_VARIABLE` und `IS_READ` tauschen kann, da beide `Ordering::Relaxed` sind.Wenn dies der Fall ist und der Signalhandler direkt nach der Aktualisierung von `IS_READY` aufgerufen wird, sieht der Signalhandler `IS_READY=1`, aber `IMPORTANT_VARIABLE=0`.
/// Die Verwendung eines `compiler_fence` behebt diese Situation.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // Verhindern Sie, dass frühere Schreibvorgänge über diesen Punkt hinaus verschoben werden
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SICHERHEIT: Die Verwendung eines Atomzauns ist sicher.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signalisiert dem Prozessor, dass er sich in einer Spin-Schleife mit Besetztwarte befindet ("Spin Lock").
///
/// Diese Funktion ist zugunsten von [`hint::spin_loop`] veraltet.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}