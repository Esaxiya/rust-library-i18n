//! Compiler-Eigenschaften.
//!
//! Die entsprechenden Definitionen sind in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Die entsprechenden const-Implementierungen befinden sich in `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: Änderungen an der Konstanz der Intrinsics sollten mit dem Sprachteam besprochen werden.
//! Dies schließt Änderungen in der Stabilität der Konstanz ein.
//!
//! Um ein Intrinsic zur Kompilierungszeit nutzbar zu machen, muss die Implementierung von <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> nach `compiler/rustc_mir/src/interpret/intrinsics.rs` kopiert und dem Intrinsic ein `#[rustc_const_unstable(feature = "foo", issue = "01234")]` hinzugefügt werden.
//!
//!
//! Wenn ein Intrinsic von einem `const fn` mit einem `rustc_const_stable`-Attribut verwendet werden soll, muss das Attribut des Intrinsic auch `rustc_const_stable` sein.
//! Eine solche Änderung sollte nicht ohne T-lang-Konsultation vorgenommen werden, da sie eine Funktion in die Sprache einbrennt, die ohne Compilerunterstützung nicht im Benutzercode repliziert werden kann.
//!
//! # Volatiles
//!
//! Die flüchtigen Intrinsics bieten Operationen, die auf den I/O-Speicher einwirken sollen und die vom Compiler garantiert nicht über andere flüchtige Intrinsics hinweg neu angeordnet werden.Weitere Informationen finden Sie in der LLVM-Dokumentation zu [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Die atomaren Intrinsics bieten gemeinsame atomare Operationen an Maschinenwörtern mit mehreren möglichen Speicherreihenfolgen.Sie befolgen dieselbe Semantik wie C++ 11.Weitere Informationen finden Sie in der LLVM-Dokumentation zu [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Eine kurze Auffrischung zur Speicherbestellung:
//!
//! * Acquire, eine Barriere für den Erwerb eines Schlosses.Nachfolgende Lese-und Schreibvorgänge finden nach der Barriere statt.
//! * Release, eine Barriere zum Lösen eines Schlosses.Vorhergehende Lese-und Schreibvorgänge finden vor der Barriere statt.
//! * Es wird garantiert, dass sequentiell konsistente, sequentiell konsistente Operationen in der richtigen Reihenfolge ausgeführt werden.Dies ist der Standardmodus für die Arbeit mit Atomtypen und entspricht dem `volatile` von Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Diese Importe werden zur Vereinfachung von Intra-Doc-Links verwendet
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SICHERHEIT: siehe `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Hinweis: Diese Intrinsics verwenden Rohzeiger, da sie den Alias-Speicher mutieren, der weder für `&` noch für `&mut` gültig ist.
    //

    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::SeqCst`] sowohl als `success`-als auch als `failure`-Parameter übergeben wird.
    ///
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::Acquire`] sowohl als `success`-als auch als `failure`-Parameter übergeben wird.
    ///
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::Release`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::AcqRel`] als `success` und [`Ordering::Acquire`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::Relaxed`] sowohl als `success`-als auch als `failure`-Parameter übergeben wird.
    ///
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::SeqCst`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::SeqCst`] als `success` und [`Ordering::Acquire`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::Acquire`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange`-Methode verfügbar, indem [`Ordering::AcqRel`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::SeqCst`] sowohl als `success`-als auch als `failure`-Parameter übergeben wird.
    ///
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::Acquire`] sowohl als `success`-als auch als `failure`-Parameter übergeben wird.
    ///
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::Release`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::AcqRel`] als `success` und [`Ordering::Acquire`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::Relaxed`] sowohl als `success`-als auch als `failure`-Parameter übergeben wird.
    ///
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::SeqCst`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::SeqCst`] als `success` und [`Ordering::Acquire`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::Acquire`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Speichert einen Wert, wenn der aktuelle Wert mit dem `old`-Wert übereinstimmt.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `compare_exchange_weak`-Methode verfügbar, indem [`Ordering::AcqRel`] als `success` und [`Ordering::Relaxed`] als `failure`-Parameter übergeben werden.
    /// Beispielsweise, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Lädt den aktuellen Wert des Zeigers.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `load`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Lädt den aktuellen Wert des Zeigers.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `load`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Lädt den aktuellen Wert des Zeigers.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `load`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Speichert den Wert am angegebenen Speicherort.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `store`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Speichert den Wert am angegebenen Speicherort.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `store`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Speichert den Wert am angegebenen Speicherort.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `store`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Speichert den Wert am angegebenen Speicherort und gibt den alten Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `swap`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Speichert den Wert am angegebenen Speicherort und gibt den alten Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `swap`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Speichert den Wert am angegebenen Speicherort und gibt den alten Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `swap`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Speichert den Wert am angegebenen Speicherort und gibt den alten Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `swap`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Speichert den Wert am angegebenen Speicherort und gibt den alten Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `swap`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Fügt den aktuellen Wert hinzu und gibt den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_add`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fügt den aktuellen Wert hinzu und gibt den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_add`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fügt den aktuellen Wert hinzu und gibt den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_add`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fügt den aktuellen Wert hinzu und gibt den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_add`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fügt den aktuellen Wert hinzu und gibt den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_add`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Subtrahieren Sie vom aktuellen Wert und geben Sie den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_sub`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahieren Sie vom aktuellen Wert und geben Sie den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_sub`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahieren Sie vom aktuellen Wert und geben Sie den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_sub`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahieren Sie vom aktuellen Wert und geben Sie den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_sub`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahieren Sie vom aktuellen Wert und geben Sie den vorherigen Wert zurück.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_sub`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweise und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_and`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_and`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_and`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_and`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_and`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweise n und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für den [`AtomicBool`]-Typ über die `fetch_nand`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise n und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für den [`AtomicBool`]-Typ über die `fetch_nand`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise n und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für den [`AtomicBool`]-Typ über die `fetch_nand`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise n und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für den [`AtomicBool`]-Typ über die `fetch_nand`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise n und mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für den [`AtomicBool`]-Typ über die `fetch_nand`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweise oder mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_or`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_or`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_or`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_or`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_or`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweises xor mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_xor`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweises xor mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_xor`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweises xor mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_xor`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweises xor mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_xor`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweises xor mit dem aktuellen Wert, wobei der vorherige Wert zurückgegeben wird.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Typen über die `fetch_xor`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenbehafteten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_max`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenbehafteten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_max`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenbehafteten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_max`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenbehafteten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_max`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_max`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum mit dem aktuellen Wert unter Verwendung eines signierten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_min`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines signierten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_min`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines signierten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_min`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines signierten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_min`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines signierten Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die [`atomic`]-Ganzzahltypen mit Vorzeichen über die `fetch_min`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_min`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_min`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_min`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_min`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_min`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_max`-Methode verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_max`-Methode verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_max`-Methode verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_max`-Methode verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mit dem aktuellen Wert unter Verwendung eines vorzeichenlosen Vergleichs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist für die vorzeichenlosen [`atomic`]-Integer-Typen über die `fetch_max`-Methode verfügbar, indem [`Ordering::Relaxed`] als `order` übergeben wird.
    /// Beispielsweise, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Das `prefetch`-Intrinsic ist ein Hinweis für den Codegenerator, eine Prefetch-Anweisung einzufügen, falls dies unterstützt wird.Ansonsten ist es ein No-Op.
    /// Prefetches haben keinen Einfluss auf das Verhalten des Programms, können jedoch dessen Leistungsmerkmale ändern.
    ///
    /// Das `locality`-Argument muss eine konstante Ganzzahl sein und ist ein zeitlicher Lokalitätsspezifizierer, der von (0) (keine Lokalität) bis (3) (extrem lokal im Cache bleiben) reicht.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Das `prefetch`-Intrinsic ist ein Hinweis für den Codegenerator, eine Prefetch-Anweisung einzufügen, falls dies unterstützt wird.Ansonsten ist es ein No-Op.
    /// Prefetches haben keinen Einfluss auf das Verhalten des Programms, können jedoch dessen Leistungsmerkmale ändern.
    ///
    /// Das `locality`-Argument muss eine konstante Ganzzahl sein und ist ein zeitlicher Lokalitätsspezifizierer, der von (0) (keine Lokalität) bis (3) (extrem lokal im Cache bleiben) reicht.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Das `prefetch`-Intrinsic ist ein Hinweis für den Codegenerator, eine Prefetch-Anweisung einzufügen, falls dies unterstützt wird.Ansonsten ist es ein No-Op.
    /// Prefetches haben keinen Einfluss auf das Verhalten des Programms, können jedoch dessen Leistungsmerkmale ändern.
    ///
    /// Das `locality`-Argument muss eine konstante Ganzzahl sein und ist ein zeitlicher Lokalitätsspezifizierer, der von (0) (keine Lokalität) bis (3) (extrem lokal im Cache bleiben) reicht.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Das `prefetch`-Intrinsic ist ein Hinweis für den Codegenerator, eine Prefetch-Anweisung einzufügen, falls dies unterstützt wird.Ansonsten ist es ein No-Op.
    /// Prefetches haben keinen Einfluss auf das Verhalten des Programms, können jedoch dessen Leistungsmerkmale ändern.
    ///
    /// Das `locality`-Argument muss eine konstante Ganzzahl sein und ist ein zeitlicher Lokalitätsspezifizierer, der von (0) (keine Lokalität) bis (3) (extrem lokal im Cache bleiben) reicht.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ein Atomzaun.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::fence`] verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    ///
    ///
    pub fn atomic_fence();
    /// Ein Atomzaun.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::fence`] verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ein Atomzaun.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::fence`] verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ein Atomzaun.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::fence`] verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Eine Nur-Compiler-Speicherbarriere.
    ///
    /// Speicherzugriffe werden vom Compiler niemals über diese Barriere hinweg neu angeordnet, es werden jedoch keine Anweisungen dafür ausgegeben.
    /// Dies ist für Vorgänge auf demselben Thread geeignet, die möglicherweise verhindert werden, z. B. bei der Interaktion mit Signalhandlern.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::compiler_fence`] verfügbar, indem [`Ordering::SeqCst`] als `order` übergeben wird.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Eine Nur-Compiler-Speicherbarriere.
    ///
    /// Speicherzugriffe werden vom Compiler niemals über diese Barriere hinweg neu angeordnet, es werden jedoch keine Anweisungen dafür ausgegeben.
    /// Dies ist für Vorgänge auf demselben Thread geeignet, die möglicherweise verhindert werden, z. B. bei der Interaktion mit Signalhandlern.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::compiler_fence`] verfügbar, indem [`Ordering::Acquire`] als `order` übergeben wird.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Eine Nur-Compiler-Speicherbarriere.
    ///
    /// Speicherzugriffe werden vom Compiler niemals über diese Barriere hinweg neu angeordnet, es werden jedoch keine Anweisungen dafür ausgegeben.
    /// Dies ist für Vorgänge auf demselben Thread geeignet, die möglicherweise verhindert werden, z. B. bei der Interaktion mit Signalhandlern.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::compiler_fence`] verfügbar, indem [`Ordering::Release`] als `order` übergeben wird.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Eine Nur-Compiler-Speicherbarriere.
    ///
    /// Speicherzugriffe werden vom Compiler niemals über diese Barriere hinweg neu angeordnet, es werden jedoch keine Anweisungen dafür ausgegeben.
    /// Dies ist für Vorgänge auf demselben Thread geeignet, die möglicherweise verhindert werden, z. B. bei der Interaktion mit Signalhandlern.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist in [`atomic::compiler_fence`] verfügbar, indem [`Ordering::AcqRel`] als `order` übergeben wird.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magische Eigenart, die ihre Bedeutung aus Attributen ableitet, die an die Funktion gebunden sind.
    ///
    /// Beispielsweise verwendet der Datenfluss dies, um statische Zusicherungen einzufügen, sodass `rustc_peek(potentially_uninitialized)` tatsächlich überprüfen würde, ob der Datenfluss tatsächlich berechnet hat, dass er zu diesem Zeitpunkt im Kontrollfluss nicht initialisiert ist.
    ///
    ///
    /// Diese Eigenschaft sollte nicht außerhalb des Compilers verwendet werden.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Bricht die Ausführung des Prozesses ab.
    ///
    /// Eine benutzerfreundlichere und stabilere Version dieses Vorgangs ist [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informiert den Optimierer darüber, dass dieser Punkt im Code nicht erreichbar ist, und ermöglicht weitere Optimierungen.
    ///
    /// Hinweis: Dies unterscheidet sich stark vom `unreachable!()`-Makro: Im Gegensatz zu dem Makro, das panics bei seiner Ausführung ausführt, ist es *undefiniertes Verhalten*, mit dieser Funktion gekennzeichneten Code zu erreichen.
    ///
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informiert den Optimierer, dass eine Bedingung immer erfüllt ist.
    /// Wenn die Bedingung falsch ist, ist das Verhalten undefiniert.
    ///
    /// Für diese Eigenschaft wird kein Code generiert, aber der Optimierer versucht, ihn (und seinen Zustand) zwischen den Durchläufen beizubehalten, was die Optimierung des umgebenden Codes beeinträchtigen und die Leistung verringern kann.
    /// Es sollte nicht verwendet werden, wenn die Invariante vom Optimierer selbst erkannt werden kann oder wenn keine wesentlichen Optimierungen möglich sind.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Hinweise an den Compiler, dass die branch-Bedingung wahrscheinlich wahr ist.
    /// Gibt den übergebenen Wert zurück.
    ///
    /// Eine andere Verwendung als mit `if`-Anweisungen hat wahrscheinlich keine Auswirkungen.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Hinweise an den Compiler, dass die branch-Bedingung wahrscheinlich falsch ist.
    /// Gibt den übergebenen Wert zurück.
    ///
    /// Eine andere Verwendung als mit `if`-Anweisungen hat wahrscheinlich keine Auswirkungen.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Führt einen Haltepunkt-Trap zur Überprüfung durch einen Debugger aus.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn breakpoint();

    /// Die Größe eines Typs in Bytes.
    ///
    /// Insbesondere ist dies der Versatz in Bytes zwischen aufeinanderfolgenden Elementen desselben Typs, einschließlich Ausrichtungsauffüllung.
    ///
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Die minimale Ausrichtung eines Typs.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Die bevorzugte Ausrichtung eines Typs.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Die Größe des referenzierten Werts in Bytes.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Die erforderliche Ausrichtung des referenzierten Werts.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Ruft ein statisches String-Slice ab, das den Namen eines Typs enthält.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ruft einen Bezeichner ab, der für den angegebenen Typ global eindeutig ist.
    /// Diese Funktion gibt den gleichen Wert für einen Typ zurück, unabhängig davon, in welchem crate er aufgerufen wird.
    ///
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Ein Schutz für unsichere Funktionen, die niemals ausgeführt werden können, wenn `T` unbewohnt ist:
    /// Dies wird statisch entweder panic oder nichts tun.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Ein Schutz für unsichere Funktionen, die niemals ausgeführt werden können, wenn `T` keine Nullinitialisierung zulässt: Dies führt statisch entweder zu panic oder zu nichts.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn assert_zero_valid<T>();

    /// Ein Schutz für unsichere Funktionen, die niemals ausgeführt werden können, wenn `T` ungültige Bitmuster aufweist: Dies wird statisch entweder panic oder nichts tun.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn assert_uninit_valid<T>();

    /// Ruft einen Verweis auf ein statisches `Location` ab, der angibt, wo es aufgerufen wurde.
    ///
    /// Verwenden Sie stattdessen [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Verschiebt einen Wert aus dem Gültigkeitsbereich, ohne Tropfenkleber auszuführen.
    ///
    /// Dies gilt ausschließlich für [`mem::forget_unsized`].normales `forget` verwendet stattdessen `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Interpretiert die Bits eines Werts eines Typs als einen anderen Typ.
    ///
    /// Beide Typen müssen gleich groß sein.
    /// Weder das Original noch das Ergebnis dürfen [invalid value](../../nomicon/what-unsafe-does.html) sein.
    ///
    /// `transmute` ist semantisch äquivalent zu einer bitweisen Verschiebung eines Typs in einen anderen.Es kopiert die Bits vom Quellwert in den Zielwert und vergisst dann das Original.
    /// Es entspricht dem `memcpy` von C unter der Haube, genau wie `transmute_copy`.
    ///
    /// Da es sich bei `transmute` um eine By-Value-Operation handelt, ist die Ausrichtung der *umgewandelten Werte selbst* kein Problem.
    /// Wie bei jeder anderen Funktion stellt der Compiler bereits sicher, dass sowohl `T` als auch `U` richtig ausgerichtet sind.
    /// Bei der Umwandlung von Werten, die *auf eine andere Stelle zeigen*(z. B. Zeiger, Referenzen, Kästchen usw.), muss der Aufrufer jedoch sicherstellen, dass die Werte, auf die verwiesen wird, ordnungsgemäß ausgerichtet sind.
    ///
    /// `transmute` ist **unglaublich** unsicher.Es gibt eine Vielzahl von Möglichkeiten, [undefined behavior][ub] mit dieser Funktion zu verursachen.`transmute` sollte der absolute letzte Ausweg sein.
    ///
    /// Der [nomicon](../../nomicon/transmutes.html) verfügt über zusätzliche Dokumentation.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Es gibt einige Dinge, für die `transmute` wirklich nützlich ist.
    ///
    /// Aus einem Zeiger einen Funktionszeiger machen.Dies ist *nicht* auf Maschinen portierbar, auf denen Funktionszeiger und Datenzeiger unterschiedliche Größen haben.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Verlängerung einer Lebensdauer oder Verkürzung einer unveränderlichen Lebensdauer.Dies ist fortgeschritten, sehr unsicher Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Verzweifeln Sie nicht: Viele Anwendungen von `transmute` können auf andere Weise erreicht werden.
    /// Im Folgenden finden Sie allgemeine Anwendungen von `transmute`, die durch sicherere Konstrukte ersetzt werden können.
    ///
    /// Verwandeln von rohem bytes(`&[u8]`) in `u32`, `f64` usw.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // Verwenden Sie stattdessen `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // oder verwenden Sie `u32::from_le_bytes` oder `u32::from_be_bytes`, um die Endianness anzugeben
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Aus einem Zeiger einen `usize` machen:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Verwenden Sie stattdessen eine `as`-Besetzung
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Aus einem `*mut T` einen `&mut T` machen:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Verwenden Sie stattdessen eine erneute Ausleihe
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Aus einem `&mut T` einen `&mut U` machen:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Stellen Sie nun `as` zusammen und leihen Sie es erneut aus. Beachten Sie, dass die Verkettung von `as` `as` nicht transitiv ist
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Aus einem `&str` einen `&[u8]` machen:
    ///
    /// ```
    /// // Dies ist kein guter Weg, dies zu tun.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Sie könnten `str::as_bytes` verwenden
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Oder verwenden Sie einfach eine Byte-Zeichenfolge, wenn Sie die Kontrolle über das Zeichenfolgenliteral haben
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Aus einem `Vec<&T>` einen `Vec<Option<&T>>` machen.
    ///
    /// Um den inneren Typ des Inhalts eines Containers umzuwandeln, müssen Sie sicherstellen, dass keine der Invarianten des Containers verletzt werden.
    /// Für `Vec` bedeutet dies, dass sowohl die Größe *als auch die Ausrichtung* der inneren Typen übereinstimmen müssen.
    /// Andere Container hängen möglicherweise von der Größe des Typs, der Ausrichtung oder sogar des `TypeId` ab. In diesem Fall wäre eine Umwandlung überhaupt nicht möglich, ohne die Containerinvarianten zu verletzen.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // Klonen Sie den vector, da wir ihn später wiederverwenden werden
    /// let v_clone = v_orig.clone();
    ///
    /// // Verwenden von Transmute: Dies hängt vom nicht angegebenen Datenlayout von `Vec` ab. Dies ist eine schlechte Idee und kann zu undefiniertem Verhalten führen.
    /////
    /// // Es ist jedoch keine Kopie.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dies ist der vorgeschlagene, sichere Weg.
    /// // Es kopiert jedoch den gesamten vector in ein neues Array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dies ist die richtige, nicht kopierbare, unsichere Methode von "transmuting" und `Vec`, ohne sich auf das Datenlayout zu verlassen.
    /// // Anstatt `transmute` buchstäblich aufzurufen, führen wir eine Zeigerumwandlung durch, aber in Bezug auf die Konvertierung des ursprünglichen inneren Typs (`&i32`) in den neuen (`Option<&i32>`) weist dies alle die gleichen Einschränkungen auf.
    /////
    /// // Lesen Sie neben den oben angegebenen Informationen auch die [`from_raw_parts`]-Dokumentation.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Aktualisieren Sie dies, wenn vec_into_raw_parts stabilisiert ist.
    ///     // Stellen Sie sicher, dass der ursprüngliche vector nicht fallen gelassen wird.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementierung von `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Es gibt mehrere Möglichkeiten, dies zu tun, und es gibt mehrere Probleme mit der folgenden (transmute)-Methode.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // Erstens: Transmute ist nicht typsicher.alles was es überprüft ist, dass T und
    ///         // U sind gleich groß.
    ///         // Zweitens haben Sie hier zwei veränderbare Referenzen, die auf denselben Speicher verweisen.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dadurch werden die Sicherheitsprobleme des Typs beseitigt.`&mut *` gibt Ihnen* nur *einen `&mut T` von einem `&mut T` oder `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Sie haben jedoch immer noch zwei veränderbare Referenzen, die auf denselben Speicher verweisen.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // So macht es die Standardbibliothek.
    /// // Dies ist die beste Methode, wenn Sie so etwas tun müssen
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dies hat jetzt drei veränderbare Referenzen, die auf denselben Speicher zeigen.`slice`, der rWert ret.0 und der rWert ret.1.
    ///         // `slice` wird nach `let ptr = ...` nie mehr verwendet und kann daher als "dead" behandelt werden. Daher haben Sie nur zwei echte veränderbare Slices.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Während dies die intrinsische Konstante stabil macht, haben wir einige benutzerdefinierte Codes in const fn
    // Überprüfungen, die die Verwendung in `const fn` verhindern.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Gibt `true` zurück, wenn für den als `T` angegebenen tatsächlichen Typ Tropfenkleber erforderlich ist.Gibt `false` zurück, wenn der für `T` bereitgestellte tatsächliche Typ `Copy` implementiert.
    ///
    ///
    /// Wenn der tatsächliche Typ weder Tropfenkleber benötigt noch `Copy` implementiert, ist der Rückgabewert dieser Funktion nicht angegeben.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Berechnet den Versatz von einem Zeiger.
    ///
    /// Dies wird als intrinsische Implementierung implementiert, um die Konvertierung in und von einer Ganzzahl zu vermeiden, da die Konvertierung Aliasing-Informationen wegwerfen würde.
    ///
    /// # Safety
    ///
    /// Sowohl der Startzeiger als auch der resultierende Zeiger müssen entweder in Grenzen oder ein Byte nach dem Ende eines zugewiesenen Objekts liegen.
    /// Wenn einer der Zeiger außerhalb der Grenzen liegt oder ein arithmetischer Überlauf auftritt, führt jede weitere Verwendung des zurückgegebenen Werts zu einem undefinierten Verhalten.
    ///
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Berechnet den Versatz von einem Zeiger, der möglicherweise umbrochen wird.
    ///
    /// Dies wird als intrinsische Implementierung implementiert, um die Konvertierung in und aus einer Ganzzahl zu vermeiden, da die Konvertierung bestimmte Optimierungen verhindert.
    ///
    /// # Safety
    ///
    /// Im Gegensatz zum `offset`-Intrinsic beschränkt dieses Intrinsic den resultierenden Zeiger nicht darauf, in oder ein Byte nach dem Ende eines zugewiesenen Objekts zu zeigen, und umschließt die Zweierkomplementarithmetik.
    /// Der resultierende Wert ist nicht unbedingt gültig, um tatsächlich auf den Speicher zuzugreifen.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Entspricht dem entsprechenden `llvm.memcpy.p0i8.0i8.*`-Eigenwert mit einer Größe von `count`*`size_of::<T>()` und einer Ausrichtung von
    ///
    /// `min_align_of::<T>()`
    ///
    /// Der flüchtige Parameter ist auf `true` eingestellt, sodass er nur optimiert wird, wenn die Größe gleich Null ist.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Entspricht dem entsprechenden `llvm.memmove.p0i8.0i8.*`-Eigenwert mit einer Größe von `count* size_of::<T>()` und einer Ausrichtung von
    ///
    /// `min_align_of::<T>()`
    ///
    /// Der flüchtige Parameter ist auf `true` eingestellt, sodass er nur optimiert wird, wenn die Größe gleich Null ist.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Entspricht dem entsprechenden `llvm.memset.p0i8.*`-Eigenwert mit einer Größe von `count* size_of::<T>()` und einer Ausrichtung von `min_align_of::<T>()`.
    ///
    ///
    /// Der flüchtige Parameter ist auf `true` eingestellt, sodass er nur optimiert wird, wenn die Größe gleich Null ist.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Führt eine flüchtige Last vom `src`-Zeiger aus.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Führt einen flüchtigen Speicher für den `dst`-Zeiger durch.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Führt eine flüchtige Last vom `src`-Zeiger aus. Der Zeiger muss nicht ausgerichtet sein.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Führt einen flüchtigen Speicher für den `dst`-Zeiger durch.
    /// Der Zeiger muss nicht ausgerichtet sein.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Gibt die Quadratwurzel eines `f32` zurück
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Gibt die Quadratwurzel eines `f64` zurück
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Erhöht einen `f32` auf eine ganzzahlige Potenz.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Erhöht einen `f64` auf eine ganzzahlige Potenz.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Gibt den Sinus eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Gibt den Sinus eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Gibt den Cosinus eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Gibt den Cosinus eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Erhöht einen `f32` auf eine `f32`-Leistung.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Erhöht einen `f64` auf eine `f64`-Leistung.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Gibt das Exponential eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Gibt das Exponential eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Gibt 2 zurück, die auf die Leistung eines `f32` angehoben wurden.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Gibt 2 zurück, die auf die Leistung eines `f64` angehoben wurden.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Gibt den natürlichen Logarithmus eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Gibt den natürlichen Logarithmus eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Gibt den Logarithmus zur Basis 10 eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Gibt den Logarithmus zur Basis 10 eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Gibt den Logarithmus zur Basis 2 eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Gibt den Logarithmus zur Basis 2 eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Gibt `a * b + c` für `f32`-Werte zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Gibt `a * b + c` für `f64`-Werte zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Gibt den absoluten Wert eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Gibt den absoluten Wert eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Gibt das Minimum von zwei `f32`-Werten zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Gibt das Minimum von zwei `f64`-Werten zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Gibt maximal zwei `f32`-Werte zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Gibt maximal zwei `f64`-Werte zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopiert das Vorzeichen für `f32`-Werte von `y` nach `x`.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopiert das Vorzeichen für `f64`-Werte von `y` nach `x`.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Gibt die größte Ganzzahl zurück, die kleiner oder gleich einem `f32` ist.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Gibt die größte Ganzzahl zurück, die kleiner oder gleich einem `f64` ist.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Gibt die kleinste Ganzzahl zurück, die größer oder gleich einem `f32` ist.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Gibt die kleinste Ganzzahl zurück, die größer oder gleich einem `f64` ist.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Gibt den ganzzahligen Teil eines `f32` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Gibt den ganzzahligen Teil eines `f64` zurück.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Gibt die nächste Ganzzahl an einen `f32` zurück.
    /// Kann eine ungenaue Gleitkomma-Ausnahme auslösen, wenn das Argument keine Ganzzahl ist.
    pub fn rintf32(x: f32) -> f32;
    /// Gibt die nächste Ganzzahl an einen `f64` zurück.
    /// Kann eine ungenaue Gleitkomma-Ausnahme auslösen, wenn das Argument keine Ganzzahl ist.
    pub fn rintf64(x: f64) -> f64;

    /// Gibt die nächste Ganzzahl an einen `f32` zurück.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Gibt die nächste Ganzzahl an einen `f64` zurück.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Gibt die nächste Ganzzahl an einen `f32` zurück.Rundet Fälle auf halbem Weg von Null ab.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Gibt die nächste Ganzzahl an einen `f64` zurück.Rundet Fälle auf halber Strecke von Null weg.
    ///
    /// Die stabilisierte Version dieses intrinsischen ist
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float-Addition, die Optimierungen basierend auf algebraischen Regeln ermöglicht.
    /// Kann davon ausgehen, dass die Eingaben endlich sind.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-Subtraktion, die Optimierungen basierend auf algebraischen Regeln ermöglicht.
    /// Kann davon ausgehen, dass die Eingaben endlich sind.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-Multiplikation, die Optimierungen basierend auf algebraischen Regeln ermöglicht.
    /// Kann davon ausgehen, dass die Eingaben endlich sind.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-Division, die Optimierungen basierend auf algebraischen Regeln ermöglicht.
    /// Kann davon ausgehen, dass die Eingaben endlich sind.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-Rest, der Optimierungen basierend auf algebraischen Regeln ermöglicht.
    /// Kann davon ausgehen, dass die Eingaben endlich sind.
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertieren Sie mit fptoui/fptosi von LLVM, das für Werte außerhalb des Bereichs möglicherweise undef zurückgibt
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilisiert als [`f32::to_int_unchecked`] und [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Gibt die Anzahl der in einem Integer-Typ `T` gesetzten Bits zurück
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `count_ones`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Gibt die Anzahl der führenden nicht gesetzten Bits (zeroes) in einem Integer-Typ `T` zurück.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `leading_zeros`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Ein `x` mit dem Wert `0` gibt die Bitbreite von `T` zurück.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Wie `ctlz`, jedoch besonders unsicher, da `undef` zurückgegeben wird, wenn ein `x` mit dem Wert `0` angegeben wird.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Gibt die Anzahl der nachgestellten nicht gesetzten Bits (zeroes) in einem Integer-Typ `T` zurück.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `trailing_zeros`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Ein `x` mit dem Wert `0` gibt die Bitbreite von `T` zurück:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Wie `cttz`, jedoch besonders unsicher, da `undef` zurückgegeben wird, wenn ein `x` mit dem Wert `0` angegeben wird.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Kehrt die Bytes in einem Integer-Typ `T` um.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `swap_bytes`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Kehrt die Bits in einer Ganzzahl vom Typ `T` um.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `reverse_bits`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Führt eine überprüfte Ganzzahladdition durch.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `overflowing_add`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Führt eine geprüfte Ganzzahlsubtraktion durch
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `overflowing_sub`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Führt eine geprüfte Ganzzahlmultiplikation durch
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `overflowing_mul`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Führt eine exakte Division durch, was zu einem undefinierten Verhalten bei `x % y != 0` oder `y == 0` oder `x == T::MIN && y == -1` führt
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Führt eine ungeprüfte Unterteilung durch, was zu einem undefinierten Verhalten bei `y == 0` oder `x == T::MIN && y == -1` führt
    ///
    ///
    /// Sichere Wrapper für diese Eigenschaft sind für die ganzzahligen Grundelemente über die `checked_div`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Gibt den Rest einer nicht aktivierten Division zurück, was zu einem undefinierten Verhalten bei `y == 0` oder `x == T::MIN && y == -1` führt
    ///
    ///
    /// Sichere Wrapper für diese Eigenschaft sind für die ganzzahligen Grundelemente über die `checked_rem`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Führt eine ungeprüfte Linksverschiebung durch, was zu einem undefinierten Verhalten bei `y < 0` oder `y >= N` führt, wobei N die Breite von T in Bits ist.
    ///
    ///
    /// Sichere Wrapper für diese Eigenschaft sind für die ganzzahligen Grundelemente über die `checked_shl`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Führt eine ungeprüfte Rechtsverschiebung durch, was zu einem undefinierten Verhalten bei `y < 0` oder `y >= N` führt, wobei N die Breite von T in Bits ist.
    ///
    ///
    /// Sichere Wrapper für diese Eigenschaft sind für die ganzzahligen Grundelemente über die `checked_shr`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Gibt das Ergebnis einer nicht aktivierten Addition zurück, was zu einem undefinierten Verhalten bei `x + y > T::MAX` oder `x + y < T::MIN` führt.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Gibt das Ergebnis einer nicht aktivierten Subtraktion zurück, was zu einem undefinierten Verhalten bei `x - y > T::MAX` oder `x - y < T::MIN` führt.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Gibt das Ergebnis einer ungeprüften Multiplikation zurück, was zu einem undefinierten Verhalten bei `x *y > T::MAX` oder `x* y < T::MIN` führt.
    ///
    ///
    /// Dieses intrinsische hat kein stabiles Gegenstück.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Führt die Drehung nach links durch.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `rotate_left`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Führt die Drehung nach rechts aus.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `rotate_right`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Gibt (a + b) mod 2 <sup>N zurück</sup>, wobei N die Breite von T in Bits ist.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `wrapping_add`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Gibt (a, b) mod 2 <sup>N zurück</sup>, wobei N die Breite von T in Bits ist.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `wrapping_sub`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Gibt (a * b) mod 2 <sup>N zurück</sup>, wobei N die Breite von T in Bits ist.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `wrapping_mul`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Berechnet `a + b`, gesättigt an numerischen Grenzen.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `saturating_add`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Berechnet `a - b`, gesättigt an numerischen Grenzen.
    ///
    /// Die stabilisierten Versionen dieses intrinsischen Elements sind für die ganzzahligen Grundelemente über die `saturating_sub`-Methode verfügbar.
    /// Beispielsweise,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Gibt den Wert der Diskriminante für die Variante in 'v' zurück.
    /// Wenn `T` keine Diskriminante hat, wird `0` zurückgegeben.
    ///
    /// Die stabilisierte Version dieses Intrinsic ist [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Gibt die Anzahl der Varianten des Typs `T` zurück, die auf einen `usize` übertragen wurden.
    /// Wenn `T` keine Varianten hat, wird `0` zurückgegeben.Unbewohnte Varianten werden gezählt.
    ///
    /// Die zu stabilisierende Version dieses Intrinsic ist [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Das "try catch"-Konstrukt von Rust, das den Funktionszeiger `try_fn` mit dem Datenzeiger `data` aufruft.
    ///
    /// Das dritte Argument ist eine Funktion, die aufgerufen wird, wenn ein panic auftritt.
    /// Diese Funktion verwendet den Datenzeiger und einen Zeiger auf das abgefangene zielspezifische Ausnahmeobjekt.
    ///
    /// Weitere Informationen finden Sie in der Quelle des Compilers sowie in der Catch-Implementierung von std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Gibt einen `!nontemporal`-Speicher gemäß LLVM aus (siehe deren Dokumente).
    /// Wird wahrscheinlich nie stabil werden.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Weitere Informationen finden Sie in der Dokumentation zu `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Weitere Informationen finden Sie in der Dokumentation zu `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Weitere Informationen finden Sie in der Dokumentation zu `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Zum Zeitpunkt der Kompilierung zuweisen.Sollte nicht zur Laufzeit aufgerufen werden.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Einige Funktionen werden hier definiert, weil sie versehentlich in diesem Modul auf Stable verfügbar gemacht wurden.
// Siehe <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` fällt ebenfalls in diese Kategorie, kann jedoch nicht umbrochen werden, da überprüft wird, ob `T` und `U` dieselbe Größe haben.)
//

/// Überprüft, ob `ptr` in Bezug auf `align_of::<T>()` richtig ausgerichtet ist.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopiert `count *size_of::<T>()`-Bytes von `src` nach `dst`.Quelle und Ziel dürfen sich* nicht * überlappen.
///
/// Verwenden Sie für Speicherbereiche, die sich möglicherweise überschneiden, stattdessen [`copy`].
///
/// `copy_nonoverlapping` ist semantisch äquivalent zu Cs [`memcpy`], jedoch mit vertauschter Argumentreihenfolge.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `src` muss [valid] für Lesevorgänge von `count * size_of::<T>()`-Bytes sein.
///
/// * `dst` muss [valid] für Schreibvorgänge von `count * size_of::<T>()`-Bytes sein.
///
/// * Sowohl `src` als auch `dst` müssen richtig ausgerichtet sein.
///
/// * Der Speicherbereich, der bei `src` mit einer Größe von `count beginnt *
///   Größe von: :<T>() `Bytes dürfen *nicht* mit dem Speicherbereich überlappen, der bei `dst` mit derselben Größe beginnt.
///
/// Wie [`read`] erstellt `copy_nonoverlapping` eine bitweise Kopie von `T`, unabhängig davon, ob `T` [`Copy`] ist.
/// Wenn `T` nicht [`Copy`] ist, können mit *beiden* die Werte in der Region, die bei `*src` beginnt, und in der Region, die bei `* dst` beginnt, [violate memory safety][read-ownership].
///
///
/// Beachten Sie, dass auch wenn die effektiv kopierte Größe (`count * size_of: :<T>()`) ist `0`, die Zeiger müssen nicht NULL sein und richtig ausgerichtet sein.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manuelles Implementieren von [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Verschiebt alle Elemente von `src` in `dst` und lässt `src` leer.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Stellen Sie sicher, dass `dst` über genügend Kapazität verfügt, um `src` vollständig aufzunehmen.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Der Aufruf des Offsets ist immer sicher, da `Vec` niemals mehr als `isize::MAX`-Bytes zuweist.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Schneiden Sie `src` ab, ohne den Inhalt zu löschen.
///         // Wir tun dies zuerst, um Probleme zu vermeiden, falls etwas weiter unten in panics liegt.
///         src.set_len(0);
///
///         // Die beiden Regionen können sich nicht überlappen, da veränderbare Referenzen keinen Alias haben und zwei verschiedene vectors nicht denselben Speicher besitzen können.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Benachrichtigen Sie `dst`, dass es jetzt den Inhalt von `src` enthält.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Führen Sie diese Überprüfungen nur zur Laufzeit durch
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Keine Panik, um die Auswirkungen von Codegen zu verringern.
        abort();
    }*/

    // SICHERHEIT: Der Sicherheitsvertrag für `copy_nonoverlapping` muss sein
    // vom Anrufer bestätigt.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopiert `count * size_of::<T>()`-Bytes von `src` nach `dst`.Die Quelle und das Ziel können sich überschneiden.
///
/// Wenn sich Quelle und Ziel *nie* überschneiden, kann stattdessen [`copy_nonoverlapping`] verwendet werden.
///
/// `copy` ist semantisch äquivalent zu Cs [`memmove`], jedoch mit vertauschter Argumentreihenfolge.
/// Das Kopieren erfolgt so, als ob die Bytes von `src` in ein temporäres Array und dann vom Array nach `dst` kopiert würden.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `src` muss [valid] für Lesevorgänge von `count * size_of::<T>()`-Bytes sein.
///
/// * `dst` muss [valid] für Schreibvorgänge von `count * size_of::<T>()`-Bytes sein.
///
/// * Sowohl `src` als auch `dst` müssen richtig ausgerichtet sein.
///
/// Wie [`read`] erstellt `copy` eine bitweise Kopie von `T`, unabhängig davon, ob `T` [`Copy`] ist.
/// Wenn `T` nicht [`Copy`] ist, kann die Verwendung sowohl der Werte in der Region, die bei `*src` beginnt, als auch der Region, die bei `* dst` beginnt, [violate memory safety][read-ownership].
///
///
/// Beachten Sie, dass auch wenn die effektiv kopierte Größe (`count * size_of: :<T>()`) ist `0`, die Zeiger müssen nicht NULL sein und richtig ausgerichtet sein.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Erstellen Sie effizient einen Rust vector aus einem unsicheren Puffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` muss für seinen Typ korrekt ausgerichtet sein und nicht Null sein.
/// /// * `ptr` muss für Lesevorgänge von `elts`-zusammenhängenden Elementen vom Typ `T` gültig sein.
/// /// * Diese Elemente dürfen nach dem Aufrufen dieser Funktion nur mit `T: Copy` verwendet werden.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SICHERHEIT: Unsere Voraussetzung stellt sicher, dass die Quelle ausgerichtet und gültig ist.
///     // und `Vec::with_capacity` stellt sicher, dass wir nutzbaren Speicherplatz zum Schreiben haben.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SICHERHEIT: Wir haben es früher mit so viel Kapazität erstellt.
///     // und der vorherige `copy` hat diese Elemente initialisiert.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Führen Sie diese Überprüfungen nur zur Laufzeit durch
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Keine Panik, um die Auswirkungen von Codegen zu verringern.
        abort();
    }*/

    // SICHERHEIT: Der Sicherheitsvertrag für `copy` muss vom Anrufer eingehalten werden.
    unsafe { copy(src, dst, count) }
}

/// Setzt `count * size_of::<T>()`-Bytes des Speichers ab `dst` auf `val`.
///
/// `write_bytes` ähnelt Cs [`memset`], setzt jedoch `count * size_of::<T>()`-Bytes auf `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `dst` muss [valid] für Schreibvorgänge von `count * size_of::<T>()`-Bytes sein.
///
/// * `dst` muss richtig ausgerichtet sein.
///
/// Darüber hinaus muss der Aufrufer sicherstellen, dass das Schreiben von `count * size_of::<T>()`-Bytes in den angegebenen Speicherbereich zu einem gültigen Wert von `T` führt.
/// Die Verwendung eines als `T` eingegebenen Speicherbereichs, der einen ungültigen Wert von `T` enthält, ist ein undefiniertes Verhalten.
///
/// Beachten Sie, dass auch wenn die effektiv kopierte Größe (`count * size_of: :<T>()`) ist `0`, der Zeiger darf nicht NULL sein und richtig ausgerichtet sein.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Erstellen eines ungültigen Werts:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Verliert den zuvor gehaltenen Wert, indem der `Box<T>` mit einem Nullzeiger überschrieben wird.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Zu diesem Zeitpunkt führt die Verwendung oder das Löschen von `v` zu einem undefinierten Verhalten.
/// // drop(v); // ERROR
///
/// // Sogar `v` "uses" leckt es und ist daher undefiniertes Verhalten.
/// // mem::forget(v); // ERROR
///
/// // Tatsächlich ist `v` gemäß den Layoutinvarianten des Basistyps ungültig, sodass *jede* Operation, die es berührt, ein undefiniertes Verhalten ist.
/////
/// // sei v2 =v;//ERROR
///
/// unsafe {
///     // Geben Sie stattdessen einen gültigen Wert ein
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Jetzt ist die Box in Ordnung
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SICHERHEIT: Der Sicherheitsvertrag für `write_bytes` muss vom Anrufer eingehalten werden.
    unsafe { write_bytes(dst, val, count) }
}