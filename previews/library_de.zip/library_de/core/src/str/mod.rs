//! String-Manipulation.
//!
//! Weitere Informationen finden Sie im [`std::str`]-Modul.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. außerhalb der Grenzen
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. begin <=end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. Zeichengrenze
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // finde den Charakter
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` muss kleiner als len und eine Zeichengrenze sein
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Gibt die Länge von `self` zurück.
    ///
    /// Diese Länge wird in Bytes angegeben, nicht in [`char`] oder Graphemen.
    /// Mit anderen Worten, es ist möglicherweise nicht das, was ein Mensch für die Länge der Zeichenfolge hält.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // Lust auf f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Gibt `true` zurück, wenn `self` eine Länge von null Bytes hat.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Überprüft, ob das Index-te Byte das erste Byte in einer UTF-8-Codepunktsequenz oder das Ende der Zeichenfolge ist.
    ///
    ///
    /// Der Anfang und das Ende der Zeichenfolge (wenn `index== self.len()`) als Grenzen betrachtet wird.
    ///
    /// Gibt `false` zurück, wenn `index` größer als `self.len()` ist.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // Start von `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // zweites Byte von `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // drittes Byte von `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 und len sind immer ok.
        // Testen Sie explizit auf 0, damit die Prüfung einfach optimiert und das Lesen von Zeichenfolgendaten für diesen Fall übersprungen werden kann.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Dies ist etwas magisches Äquivalent zu: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Konvertiert ein String-Slice in ein Byte-Slice.
    /// Verwenden Sie die [`from_utf8`]-Funktion, um das Byte-Slice wieder in ein String-Slice umzuwandeln.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SICHERHEIT: const sound, weil wir zwei Typen mit demselben Layout umwandeln
        unsafe { mem::transmute(self) }
    }

    /// Konvertiert einen veränderbaren String-Slice in einen veränderlichen Byte-Slice.
    ///
    /// # Safety
    ///
    /// Der Aufrufer muss sicherstellen, dass der Inhalt des Slice UTF-8 gültig ist, bevor das Ausleihen endet und das zugrunde liegende `str` verwendet wird.
    ///
    ///
    /// Die Verwendung eines `str`, dessen Inhalt nicht gültig ist, ist ein undefiniertes Verhalten.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SICHERHEIT: Die Besetzung von `&str` nach `&[u8]` ist seit `str` sicher
        // hat das gleiche Layout wie `&[u8]` (nur libstd kann diese Garantie übernehmen).
        // Die Zeiger-Dereferenzierung ist sicher, da sie von einer veränderlichen Referenz stammt, die garantiert für Schreibvorgänge gültig ist.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Konvertiert ein String-Slice in einen Rohzeiger.
    ///
    /// Da String-Slices ein Byte-Slice sind, zeigt der Rohzeiger auf ein [`u8`].
    /// Dieser Zeiger zeigt auf das erste Byte des String-Slice.
    ///
    /// Der Aufrufer muss sicherstellen, dass der zurückgegebene Zeiger niemals beschrieben wird.
    /// Wenn Sie den Inhalt des String-Slice mutieren müssen, verwenden Sie [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Konvertiert ein veränderbares String-Slice in einen Rohzeiger.
    ///
    /// Da String-Slices ein Byte-Slice sind, zeigt der Rohzeiger auf ein [`u8`].
    /// Dieser Zeiger zeigt auf das erste Byte des String-Slice.
    ///
    /// Es liegt in Ihrer Verantwortung sicherzustellen, dass das String-Slice nur so geändert wird, dass es UTF-8 gültig bleibt.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Gibt eine Unterscheibe von `str` zurück.
    ///
    /// Dies ist die nicht in Panik geratene Alternative zur Indizierung des `str`.
    /// Gibt [`None`] zurück, wenn eine entsprechende Indizierungsoperation panic ausführen würde.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // Indizes nicht an UTF-8-Sequenzgrenzen
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // außerhalb der Grenzen
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Gibt eine veränderbare Unterscheibe von `str` zurück.
    ///
    /// Dies ist die nicht in Panik geratene Alternative zur Indizierung des `str`.
    /// Gibt [`None`] zurück, wenn eine entsprechende Indizierungsoperation panic ausführen würde.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // richtige Länge
    /// assert!(v.get_mut(0..5).is_some());
    /// // außerhalb der Grenzen
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Gibt eine ungeprüfte Unterscheibe von `str` zurück.
    ///
    /// Dies ist die ungeprüfte Alternative zur Indizierung des `str`.
    ///
    /// # Safety
    ///
    /// Anrufer dieser Funktion sind dafür verantwortlich, dass diese Voraussetzungen erfüllt sind:
    ///
    /// * Der Startindex darf den Endindex nicht überschreiten.
    /// * Die Indizes müssen innerhalb der Grenzen des ursprünglichen Slice liegen.
    /// * Indizes müssen an UTF-8-Sequenzgrenzen liegen.
    ///
    /// Andernfalls kann das zurückgegebene String-Slice auf einen ungültigen Speicher verweisen oder die vom `str`-Typ übermittelten Invarianten verletzen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked` einhalten.
        // Das Slice ist dereferenzierbar, da `self` eine sichere Referenz ist.
        // Der zurückgegebene Zeiger ist sicher, da Impls von `SliceIndex` dies sicherstellen müssen.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Gibt eine veränderbare, nicht aktivierte Unterscheibe von `str` zurück.
    ///
    /// Dies ist die ungeprüfte Alternative zur Indizierung des `str`.
    ///
    /// # Safety
    ///
    /// Anrufer dieser Funktion sind dafür verantwortlich, dass diese Voraussetzungen erfüllt sind:
    ///
    /// * Der Startindex darf den Endindex nicht überschreiten.
    /// * Die Indizes müssen innerhalb der Grenzen des ursprünglichen Slice liegen.
    /// * Indizes müssen an UTF-8-Sequenzgrenzen liegen.
    ///
    /// Andernfalls kann das zurückgegebene String-Slice auf einen ungültigen Speicher verweisen oder die vom `str`-Typ übermittelten Invarianten verletzen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked_mut` einhalten.
        // Das Slice ist dereferenzierbar, da `self` eine sichere Referenz ist.
        // Der zurückgegebene Zeiger ist sicher, da Impls von `SliceIndex` dies sicherstellen müssen.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Erstellt ein String-Slice aus einem anderen String-Slice unter Umgehung der Sicherheitsüberprüfungen.
    ///
    /// Dies wird generell nicht empfohlen, Vorsicht walten lassen!Für eine sichere Alternative siehe [`str`] und [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Dieses neue Slice wechselt von `begin` zu `end`, einschließlich `begin`, jedoch ohne `end`.
    ///
    /// Informationen zum Abrufen eines veränderbaren String-Slice finden Sie in der [`slice_mut_unchecked`]-Methode.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Anrufer dieser Funktion sind dafür verantwortlich, dass drei Voraussetzungen erfüllt sind:
    ///
    /// * `begin` darf `end` nicht überschreiten.
    /// * `begin` und `end` müssen Bytepositionen innerhalb des String-Slice sein.
    /// * `begin` und `end` muss an den UTF-8-Sequenzgrenzen liegen.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked` einhalten.
        // Das Slice ist dereferenzierbar, da `self` eine sichere Referenz ist.
        // Der zurückgegebene Zeiger ist sicher, da Impls von `SliceIndex` dies sicherstellen müssen.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Erstellt ein String-Slice aus einem anderen String-Slice unter Umgehung der Sicherheitsüberprüfungen.
    /// Dies wird generell nicht empfohlen, Vorsicht walten lassen!Für eine sichere Alternative siehe [`str`] und [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Dieses neue Slice wechselt von `begin` zu `end`, einschließlich `begin`, jedoch ohne `end`.
    ///
    /// Informationen zum Abrufen eines unveränderlichen String-Slice finden Sie in der [`slice_unchecked`]-Methode.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Anrufer dieser Funktion sind dafür verantwortlich, dass drei Voraussetzungen erfüllt sind:
    ///
    /// * `begin` darf `end` nicht überschreiten.
    /// * `begin` und `end` müssen Bytepositionen innerhalb des String-Slice sein.
    /// * `begin` und `end` muss an den UTF-8-Sequenzgrenzen liegen.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked_mut` einhalten.
        // Das Slice ist dereferenzierbar, da `self` eine sichere Referenz ist.
        // Der zurückgegebene Zeiger ist sicher, da Impls von `SliceIndex` dies sicherstellen müssen.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Teilen Sie ein String-Slice an einem Index in zwei.
    ///
    /// Das Argument `mid` sollte ein Byte-Offset vom Anfang der Zeichenfolge sein.
    /// Es muss sich auch an der Grenze eines UTF-8-Codepunkts befinden.
    ///
    /// Die beiden zurückgegebenen Slices gehen vom Anfang des String-Slice zu `mid` und von `mid` zum Ende des String-Slice.
    ///
    /// Informationen zum Abrufen veränderbarer Zeichenfolgenschnitte finden Sie in der [`split_at_mut`]-Methode.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, wenn sich `mid` nicht an einer UTF-8-Codepunktgrenze befindet oder wenn das Ende des letzten Codepunkts des String-Slice überschritten wird.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary prüft, ob der Index in [0, .len()]
        if self.is_char_boundary(mid) {
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `mid` an einer Zeichengrenze befindet.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Teilen Sie ein veränderbares String-Slice an einem Index in zwei.
    ///
    /// Das Argument `mid` sollte ein Byte-Offset vom Anfang der Zeichenfolge sein.
    /// Es muss sich auch an der Grenze eines UTF-8-Codepunkts befinden.
    ///
    /// Die beiden zurückgegebenen Slices gehen vom Anfang des String-Slice zu `mid` und von `mid` zum Ende des String-Slice.
    ///
    /// Informationen zum Abrufen unveränderlicher String-Slices finden Sie in der [`split_at`]-Methode.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, wenn sich `mid` nicht an einer UTF-8-Codepunktgrenze befindet oder wenn das Ende des letzten Codepunkts des String-Slice überschritten wird.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary prüft, ob der Index in [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `mid` an einer Zeichengrenze befindet.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Gibt einen Iterator über die [`char`] eines String-Slice zurück.
    ///
    /// Da ein String-Slice aus gültigem UTF-8 besteht, können wir einen String-Slice mit [`char`] durchlaufen.
    /// Diese Methode gibt einen solchen Iterator zurück.
    ///
    /// Es ist wichtig, sich daran zu erinnern, dass [`char`] einen Unicode-Skalarwert darstellt und möglicherweise nicht mit Ihrer Vorstellung von einem 'character' übereinstimmt.
    ///
    /// Die Iteration über Graphemcluster kann das sein, was Sie tatsächlich wollen.
    /// Diese Funktionalität wird von der Standardbibliothek von Rust nicht bereitgestellt. Überprüfen Sie stattdessen crates.io.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Denken Sie daran, dass [`char`] möglicherweise nicht mit Ihrer Intuition für Charaktere übereinstimmt:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // nicht 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Gibt einen Iterator über die [`char`] eines String-Slice und deren Positionen zurück.
    ///
    /// Da ein String-Slice aus gültigem UTF-8 besteht, können wir einen String-Slice mit [`char`] durchlaufen.
    /// Diese Methode gibt einen Iterator sowohl dieser [`char`] als auch ihrer Bytepositionen zurück.
    ///
    /// Der Iterator liefert Tupel.Die Position ist zuerst, der [`char`] ist an zweiter Stelle.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Denken Sie daran, dass [`char`] möglicherweise nicht mit Ihrer Intuition für Charaktere übereinstimmt:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // nicht (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // Beachten Sie die 3 hier, das letzte Zeichen nahm zwei Bytes ein
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Ein Iterator über die Bytes eines String-Slice.
    ///
    /// Da ein String-Slice aus einer Folge von Bytes besteht, können wir einen String-Slice byteweise durchlaufen.
    /// Diese Methode gibt einen solchen Iterator zurück.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Teilt ein String-Slice nach Leerzeichen.
    ///
    /// Der zurückgegebene Iterator gibt String-Slices zurück, die Sub-Slices des ursprünglichen String-Slice sind, die durch eine beliebige Anzahl von Leerzeichen getrennt sind.
    ///
    ///
    /// 'Whitespace' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `White_Space` definiert.
    /// Wenn Sie stattdessen nur ASCII-Leerzeichen aufteilen möchten, verwenden Sie [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Alle Arten von Leerzeichen werden berücksichtigt:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Teilt ein String-Slice nach ASCII-Leerzeichen.
    ///
    /// Der zurückgegebene Iterator gibt String-Slices zurück, die Sub-Slices des ursprünglichen String-Slice sind und durch eine beliebige Anzahl von ASCII-Leerzeichen getrennt sind.
    ///
    ///
    /// Verwenden Sie [`split_whitespace`], um stattdessen nach Unicode `Whitespace` zu teilen.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Alle Arten von ASCII-Leerzeichen werden berücksichtigt:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ein Iterator über die Zeilen eines Strings als String-Slices.
    ///
    /// Zeilen werden entweder mit einer neuen Zeile (`\n`) oder einem Wagenrücklauf mit einem Zeilenvorschub (`\r\n`) beendet.
    ///
    /// Das letzte Zeilenende ist optional.
    /// Eine Zeichenfolge, die mit einem Ende der letzten Zeile endet, gibt dieselben Zeilen zurück wie eine ansonsten identische Zeichenfolge ohne Ende der letzten Zeile.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Das letzte Zeilenende ist nicht erforderlich:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Ein Iterator über die Zeilen einer Zeichenfolge.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Gibt einen Iterator von `u16` über die als UTF-16 codierte Zeichenfolge zurück.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Gibt `true` zurück, wenn das angegebene Muster mit einem Unter-Slice dieses String-Slice übereinstimmt.
    ///
    /// Gibt `false` zurück, wenn dies nicht der Fall ist.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Gibt `true` zurück, wenn das angegebene Muster mit einem Präfix dieses String-Slice übereinstimmt.
    ///
    /// Gibt `false` zurück, wenn dies nicht der Fall ist.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Gibt `true` zurück, wenn das angegebene Muster mit einem Suffix dieses String-Slice übereinstimmt.
    ///
    /// Gibt `false` zurück, wenn dies nicht der Fall ist.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Gibt den Byte-Index des ersten Zeichens dieses String-Slice zurück, der dem Muster entspricht.
    ///
    /// Gibt [`None`] zurück, wenn das Muster nicht übereinstimmt.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Komplexere Muster mit punktfreiem Stil und Verschlüssen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Das Muster nicht finden:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Gibt den Byte-Index für das erste Zeichen der Übereinstimmung ganz rechts des Musters in diesem String-Slice zurück.
    ///
    /// Gibt [`None`] zurück, wenn das Muster nicht übereinstimmt.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Komplexere Muster mit Verschlüssen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Das Muster nicht finden:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Ein Iterator über Teilzeichenfolgen dieses String-Slice, getrennt durch Zeichen, die durch ein Muster übereinstimmen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator ist ein [`DoubleEndedIterator`], wenn das Muster eine umgekehrte Suche zulässt und die forward/reverse-Suche dieselben Elemente liefert.
    /// Dies gilt beispielsweise für [`char`], nicht jedoch für `&str`.
    ///
    /// Wenn das Muster eine Rückwärtssuche zulässt, die Ergebnisse jedoch von einer Vorwärtssuche abweichen können, kann die [`rsplit`]-Methode verwendet werden.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Wenn es sich bei dem Muster um ein Stück Zeichen handelt, teilen Sie es bei jedem Auftreten eines der Zeichen auf:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Ein komplexeres Muster mit einem Verschluss:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Wenn eine Zeichenfolge mehrere zusammenhängende Trennzeichen enthält, werden in der Ausgabe leere Zeichenfolgen angezeigt:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Aneinandergrenzende Trennzeichen werden durch die leere Zeichenfolge getrennt.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Trennzeichen am Anfang oder Ende einer Zeichenfolge werden von leeren Zeichenfolgen benachbart.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Wenn die leere Zeichenfolge als Trennzeichen verwendet wird, werden alle Zeichen in der Zeichenfolge sowie der Anfang und das Ende der Zeichenfolge getrennt.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Aneinandergrenzende Trennzeichen können zu möglicherweise überraschendem Verhalten führen, wenn Leerzeichen als Trennzeichen verwendet werden.Dieser Code ist korrekt:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Es gibt Ihnen _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Verwenden Sie [`split_whitespace`] für dieses Verhalten.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Ein Iterator über Teilzeichenfolgen dieses String-Slice, getrennt durch Zeichen, die durch ein Muster übereinstimmen.
    /// Unterscheidet sich von dem von `split` erzeugten Iterator darin, dass `split_inclusive` den übereinstimmenden Teil als Terminator des Teilstrings belässt.
    ///
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Wenn das letzte Element der Zeichenfolge übereinstimmt, wird dieses Element als Terminator des vorhergehenden Teilstrings betrachtet.
    /// Diese Teilzeichenfolge ist das letzte vom Iterator zurückgegebene Element.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Ein Iterator über Teilzeichenfolgen des angegebenen String-Slice, getrennt durch Zeichen, die durch ein Muster übereinstimmen und in umgekehrter Reihenfolge ausgegeben werden.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator erfordert, dass das Muster eine umgekehrte Suche unterstützt, und es ist ein [`DoubleEndedIterator`], wenn eine forward/reverse-Suche dieselben Elemente liefert.
    ///
    ///
    /// Für die Iteration von vorne kann die [`split`]-Methode verwendet werden.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Ein komplexeres Muster mit einem Verschluss:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Ein Iterator über Teilzeichenfolgen des angegebenen String-Slice, getrennt durch Zeichen, die durch ein Muster übereinstimmen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Entspricht [`split`], außer dass der nachfolgende Teilstring übersprungen wird, wenn er leer ist.
    ///
    /// [`split`]: str::split
    ///
    /// Diese Methode kann für Zeichenfolgendaten verwendet werden, die _terminated_ und nicht _separated_ eines Musters sind.
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator ist ein [`DoubleEndedIterator`], wenn das Muster eine umgekehrte Suche zulässt und die forward/reverse-Suche dieselben Elemente liefert.
    /// Dies gilt beispielsweise für [`char`], nicht jedoch für `&str`.
    ///
    /// Wenn das Muster eine Rückwärtssuche zulässt, die Ergebnisse jedoch von einer Vorwärtssuche abweichen können, kann die [`rsplit_terminator`]-Methode verwendet werden.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Ein Iterator über Teilzeichenfolgen von `self`, getrennt durch Zeichen, die durch ein Muster übereinstimmen und in umgekehrter Reihenfolge ausgegeben werden.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Entspricht [`split`], außer dass der nachfolgende Teilstring übersprungen wird, wenn er leer ist.
    ///
    /// [`split`]: str::split
    ///
    /// Diese Methode kann für Zeichenfolgendaten verwendet werden, die _terminated_ und nicht _separated_ eines Musters sind.
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator erfordert, dass das Muster eine umgekehrte Suche unterstützt, und es wird doppelt beendet, wenn eine forward/reverse-Suche dieselben Elemente ergibt.
    ///
    ///
    /// Für die Iteration von vorne kann die [`split_terminator`]-Methode verwendet werden.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ein Iterator über Teilzeichenfolgen des angegebenen String-Slice, getrennt durch ein Muster, beschränkt sich auf die Rückgabe von höchstens `n`-Elementen.
    ///
    /// Wenn `n`-Teilzeichenfolgen zurückgegeben werden, enthält die letzte Teilzeichenfolge (die `n`te Teilzeichenfolge) den Rest der Zeichenfolge.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator wird nicht doppelt beendet, da seine Unterstützung nicht effizient ist.
    ///
    /// Wenn das Muster eine umgekehrte Suche zulässt, kann die [`rsplitn`]-Methode verwendet werden.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Ein komplexeres Muster mit einem Verschluss:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Ein Iterator über Teilzeichenfolgen dieses String-Slice, getrennt durch ein Muster, beginnend am Ende des Strings, beschränkt sich auf die Rückgabe von höchstens `n`-Elementen.
    ///
    ///
    /// Wenn `n`-Teilzeichenfolgen zurückgegeben werden, enthält die letzte Teilzeichenfolge (die `n`te Teilzeichenfolge) den Rest der Zeichenfolge.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator wird nicht doppelt beendet, da seine Unterstützung nicht effizient ist.
    ///
    /// Für die Aufteilung von vorne kann die [`splitn`]-Methode verwendet werden.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Ein komplexeres Muster mit einem Verschluss:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Teilt die Zeichenfolge beim ersten Auftreten des angegebenen Trennzeichens und gibt das Präfix vor dem Trennzeichen und das Suffix nach dem Trennzeichen zurück.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Teilt die Zeichenfolge beim letzten Auftreten des angegebenen Trennzeichens und gibt das Präfix vor dem Trennzeichen und das Suffix nach dem Trennzeichen zurück.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ein Iterator über die disjunkten Übereinstimmungen eines Musters innerhalb des angegebenen String-Slice.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator ist ein [`DoubleEndedIterator`], wenn das Muster eine umgekehrte Suche zulässt und die forward/reverse-Suche dieselben Elemente liefert.
    /// Dies gilt beispielsweise für [`char`], nicht jedoch für `&str`.
    ///
    /// Wenn das Muster eine Rückwärtssuche zulässt, die Ergebnisse jedoch von einer Vorwärtssuche abweichen können, kann die [`rmatches`]-Methode verwendet werden.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Ein Iterator über die disjunkten Übereinstimmungen eines Musters innerhalb dieses String-Slice, der in umgekehrter Reihenfolge ausgegeben wird.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator erfordert, dass das Muster eine umgekehrte Suche unterstützt, und es ist ein [`DoubleEndedIterator`], wenn eine forward/reverse-Suche dieselben Elemente liefert.
    ///
    ///
    /// Für die Iteration von vorne kann die [`matches`]-Methode verwendet werden.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Ein Iterator über die disjunkten Übereinstimmungen eines Musters innerhalb dieses String-Slice sowie über den Index, bei dem die Übereinstimmung beginnt.
    ///
    /// Für Übereinstimmungen von `pat` innerhalb von `self`, die sich überlappen, werden nur die Indizes zurückgegeben, die der ersten Übereinstimmung entsprechen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator ist ein [`DoubleEndedIterator`], wenn das Muster eine umgekehrte Suche zulässt und die forward/reverse-Suche dieselben Elemente liefert.
    /// Dies gilt beispielsweise für [`char`], nicht jedoch für `&str`.
    ///
    /// Wenn das Muster eine Rückwärtssuche zulässt, die Ergebnisse jedoch von einer Vorwärtssuche abweichen können, kann die [`rmatch_indices`]-Methode verwendet werden.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // nur der erste `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Ein Iterator über die disjunkten Übereinstimmungen eines Musters innerhalb von `self` ergab in umgekehrter Reihenfolge zusammen mit dem Index der Übereinstimmung.
    ///
    /// Für Übereinstimmungen von `pat` innerhalb von `self`, die sich überlappen, werden nur die Indizes zurückgegeben, die der letzten Übereinstimmung entsprechen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorverhalten
    ///
    /// Der zurückgegebene Iterator erfordert, dass das Muster eine umgekehrte Suche unterstützt, und es ist ein [`DoubleEndedIterator`], wenn eine forward/reverse-Suche dieselben Elemente liefert.
    ///
    ///
    /// Für die Iteration von vorne kann die [`match_indices`]-Methode verwendet werden.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // nur der letzte `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Gibt ein String-Slice zurück, bei dem führende und nachfolgende Leerzeichen entfernt sind.
    ///
    /// 'Whitespace' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `White_Space` definiert.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Gibt ein String-Slice mit entferntem führenden Leerzeichen zurück.
    ///
    /// 'Whitespace' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `White_Space` definiert.
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// `start` bedeutet in diesem Zusammenhang die erste Position dieser Bytezeichenfolge;Für eine Sprache von links nach rechts wie Englisch oder Russisch ist dies die linke Seite, und für Sprachen von rechts nach links wie Arabisch oder Hebräisch ist dies die rechte Seite.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Gibt ein String-Slice mit entferntem Leerzeichen zurück.
    ///
    /// 'Whitespace' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `White_Space` definiert.
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// `end` bedeutet in diesem Zusammenhang die letzte Position dieser Bytezeichenfolge;Für eine Sprache von links nach rechts wie Englisch oder Russisch ist dies die rechte Seite, und für Sprachen von rechts nach links wie Arabisch oder Hebräisch ist dies die linke Seite.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Gibt ein String-Slice mit entferntem führenden Leerzeichen zurück.
    ///
    /// 'Whitespace' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `White_Space` definiert.
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// 'Left' bedeutet in diesem Zusammenhang die erste Position dieser Bytezeichenfolge;Für eine Sprache wie Arabisch oder Hebräisch, die eher von rechts nach links als von links nach rechts ist, ist dies die _right_-Seite, nicht die linke.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Gibt ein String-Slice mit entferntem Leerzeichen zurück.
    ///
    /// 'Whitespace' wird gemäß den Bestimmungen der von Unicode abgeleiteten Kerneigenschaft `White_Space` definiert.
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// 'Right' bedeutet in diesem Zusammenhang die letzte Position dieser Bytezeichenfolge;Für eine Sprache wie Arabisch oder Hebräisch, die eher von rechts nach links als von links nach rechts ist, ist dies die _left_-Seite, nicht die rechte.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Gibt ein String-Slice mit allen Präfixen und Suffixen zurück, die mit einem wiederholt entfernten Muster übereinstimmen.
    ///
    /// Der [pattern] kann ein [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Ein komplexeres Muster mit einem Verschluss:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Denken Sie an die früheste bekannte Übereinstimmung. Korrigieren Sie sie unten, wenn
            // Das letzte Spiel ist anders
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SICHERHEIT: Es ist bekannt, dass `Searcher` gültige Indizes zurückgibt.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Gibt ein String-Slice mit allen Präfixen zurück, die mit einem wiederholt entfernten Muster übereinstimmen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// `start` bedeutet in diesem Zusammenhang die erste Position dieser Bytezeichenfolge;Für eine Sprache von links nach rechts wie Englisch oder Russisch ist dies die linke Seite, und für Sprachen von rechts nach links wie Arabisch oder Hebräisch ist dies die rechte Seite.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SICHERHEIT: Es ist bekannt, dass `Searcher` gültige Indizes zurückgibt.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Gibt ein String-Slice mit entferntem Präfix zurück.
    ///
    /// Wenn die Zeichenfolge mit dem Muster `prefix` beginnt, wird nach dem in `Some` eingeschlossenen Präfix eine Teilzeichenfolge zurückgegeben.
    /// Im Gegensatz zu `trim_start_matches` wird bei dieser Methode das Präfix genau einmal entfernt.
    ///
    /// Wenn die Zeichenfolge nicht mit `prefix` beginnt, wird `None` zurückgegeben.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Gibt ein String-Slice mit entferntem Suffix zurück.
    ///
    /// Wenn die Zeichenfolge mit dem Muster `suffix` endet, wird die Teilzeichenfolge vor dem in `Some` eingeschlossenen Suffix zurückgegeben.
    /// Im Gegensatz zu `trim_end_matches` wird bei dieser Methode das Suffix genau einmal entfernt.
    ///
    /// Wenn die Zeichenfolge nicht mit `suffix` endet, wird `None` zurückgegeben.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Gibt ein String-Slice mit allen Suffixen zurück, die mit einem wiederholt entfernten Muster übereinstimmen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// `end` bedeutet in diesem Zusammenhang die letzte Position dieser Bytezeichenfolge;Für eine Sprache von links nach rechts wie Englisch oder Russisch ist dies die rechte Seite, und für Sprachen von rechts nach links wie Arabisch oder Hebräisch ist dies die linke Seite.
    ///
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ein komplexeres Muster mit einem Verschluss:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SICHERHEIT: Es ist bekannt, dass `Searcher` gültige Indizes zurückgibt.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Gibt ein String-Slice mit allen Präfixen zurück, die mit einem wiederholt entfernten Muster übereinstimmen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// 'Left' bedeutet in diesem Zusammenhang die erste Position dieser Bytezeichenfolge;Für eine Sprache wie Arabisch oder Hebräisch, die eher von rechts nach links als von links nach rechts ist, ist dies die _right_-Seite, nicht die linke.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Gibt ein String-Slice mit allen Suffixen zurück, die mit einem wiederholt entfernten Muster übereinstimmen.
    ///
    /// Der [pattern] kann ein `&str`, [`char`], ein Slice von [`char`] s oder eine Funktion oder ein Abschluss sein, der bestimmt, ob ein Zeichen übereinstimmt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textrichtung
    ///
    /// Eine Zeichenfolge ist eine Folge von Bytes.
    /// 'Right' bedeutet in diesem Zusammenhang die letzte Position dieser Bytezeichenfolge;Für eine Sprache wie Arabisch oder Hebräisch, die eher von rechts nach links als von links nach rechts ist, ist dies die _left_-Seite, nicht die rechte.
    ///
    ///
    /// # Examples
    ///
    /// Einfache Muster:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ein komplexeres Muster mit einem Verschluss:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analysiert dieses String-Slice in einen anderen Typ.
    ///
    /// Da `parse` so allgemein ist, kann es zu Problemen mit der Typinferenz kommen.
    /// Daher ist `parse` eines der wenigen Male, dass Sie die Syntax 'turbofish' sehen: `::<>`.
    ///
    /// Dies hilft dem Inferenzalgorithmus, genau zu verstehen, in welchen Typ Sie analysieren möchten.
    ///
    /// `parse` kann in jeden Typ analysiert werden, der den [`FromStr`] trait implementiert.
    ///

    /// # Errors
    ///
    /// Gibt [`Err`] zurück, wenn es nicht möglich ist, dieses String-Slice in den gewünschten Typ zu analysieren.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Verwenden von 'turbofish' anstelle von Anmerkungen zu `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Fehler beim Parsen:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Überprüft, ob alle Zeichen in dieser Zeichenfolge innerhalb des ASCII-Bereichs liegen.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Wir können hier jedes Byte als Zeichen behandeln: Alle Multibyte-Zeichen beginnen mit einem Byte, das nicht im ASCII-Bereich liegt, daher werden wir dort bereits anhalten.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Überprüft, ob bei zwei Zeichenfolgen die Übereinstimmung zwischen Groß-und Kleinschreibung nicht berücksichtigt wird.
    ///
    /// Wie `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, jedoch ohne Zuweisen und Kopieren von Provisorien.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Konvertiert diese Zeichenfolge in das vorhandene ASCII-Großbuchstabenäquivalent.
    ///
    /// ASCII-Buchstaben 'a' bis 'z' werden 'A' bis 'Z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`to_ascii_uppercase()`], um einen neuen Wert in Großbuchstaben zurückzugeben, ohne den vorhandenen zu ändern.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SICHERHEIT: sicher, weil wir zwei Typen mit demselben Layout umwandeln.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Konvertiert diese Zeichenfolge in das vorhandene ASCII-Kleinbuchstabenäquivalent.
    ///
    /// ASCII-Buchstaben 'A' bis 'Z' werden 'a' bis 'z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`to_ascii_lowercase()`], um einen neuen Wert in Kleinbuchstaben zurückzugeben, ohne den vorhandenen zu ändern.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SICHERHEIT: sicher, weil wir zwei Typen mit demselben Layout umwandeln.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Gibt einen Iterator zurück, der mit [`char::escape_debug`] jedem Zeichen in `self` entgeht.
    ///
    ///
    /// Note: Es werden nur erweiterte Graphemcodepunkte maskiert, die mit der Zeichenfolge beginnen.
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Gibt einen Iterator zurück, der mit [`char::escape_default`] jedem Zeichen in `self` entgeht.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Gibt einen Iterator zurück, der mit [`char::escape_unicode`] jedem Zeichen in `self` entgeht.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Erstellt eine leere str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Erstellt eine leere veränderbare Str
    #[inline]
    fn default() -> Self {
        // SICHERHEIT: Die leere Zeichenfolge ist UTF-8 gültig.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Ein benennbarer, klonbarer fn-Typ
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SICHERHEIT: nicht sicher
        unsafe { from_utf8_unchecked(bytes) }
    };
}