//! Trait-Implementierungen für `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementiert die Reihenfolge von Zeichenfolgen.
///
/// Strings werden nach ihren Bytewerten [lexicographically](Ord#lexicographical-comparison) geordnet.
/// Dadurch werden Unicode-Codepunkte basierend auf ihren Positionen in den Codediagrammen angeordnet.
/// Dies entspricht nicht unbedingt der "alphabetical"-Reihenfolge, die je nach Sprache und Gebietsschema variiert.
/// Das Sortieren von Zeichenfolgen nach kulturell akzeptierten Standards erfordert länderspezifische Daten, die außerhalb des Bereichs des `str`-Typs liegen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementiert Vergleichsoperationen für Zeichenfolgen.
///
/// Zeichenfolgen werden [lexicographically](Ord#lexicographical-comparison) anhand ihrer Bytewerte verglichen.
/// Dadurch werden Unicode-Codepunkte anhand ihrer Positionen in den Codediagrammen verglichen.
/// Dies entspricht nicht unbedingt der "alphabetical"-Reihenfolge, die je nach Sprache und Gebietsschema variiert.
/// Der Vergleich von Zeichenfolgen nach kulturell akzeptierten Standards erfordert länderspezifische Daten, die außerhalb des Geltungsbereichs des `str`-Typs liegen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementiert das Schneiden von Teilzeichenfolgen mit der Syntax `&self[..]` oder `&mut self[..]`.
///
/// Gibt einen Slice der gesamten Zeichenfolge zurück, dh `&self` oder `&mut self`.Entspricht `&self [0 ..
/// len] `oder`&mut self [0 ..
/// len]`.
/// Im Gegensatz zu anderen Indizierungsvorgängen kann dies niemals panic sein.
///
/// Diese Operation ist *O*(1).
///
/// Vor 1.20.0 wurden diese Indizierungsvorgänge noch durch die direkte Implementierung von `Index` und `IndexMut` unterstützt.
///
/// Entspricht `&self[0 .. len]` oder `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementiert das Schneiden von Teilzeichenfolgen mit der Syntax `&self[begin .. end]` oder `&mut self[begin .. end]`.
///
/// Gibt einen Slice der angegebenen Zeichenfolge aus dem Bytebereich zurück [`begin`, `end`).
///
/// Diese Operation ist *O*(1).
///
/// Vor 1.20.0 wurden diese Indizierungsvorgänge noch durch die direkte Implementierung von `Index` und `IndexMut` unterstützt.
///
/// # Panics
///
/// Panics, wenn `begin` oder `end` nicht auf den Startbyte-Offset eines Zeichens (wie von `is_char_boundary` definiert) verweist, wenn `begin > end` oder `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // diese werden panic:
/// // Byte 2 liegt in `ö`:
/// // &s [2 ..3];
///
/// // Byte 8 liegt innerhalb von `老`&s [1 ..
/// // 8];
///
/// // Byte 100 befindet sich außerhalb des Strings&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SICHERHEIT: Ich habe gerade überprüft, ob `start` und `end` an einer Zeichengrenze liegen.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            // Wir haben auch die Zeichengrenzen überprüft, sodass dies für UTF-8 gültig ist.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SICHERHEIT: Ich habe gerade überprüft, ob `start` und `end` an einer Zeichengrenze liegen.
            // Wir wissen, dass der Zeiger einzigartig ist, weil wir ihn von `slice` erhalten haben.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SICHERHEIT: Der Anrufer garantiert, dass `self` innerhalb von `slice` liegt
        // Dies erfüllt alle Bedingungen für `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SICHERHEIT: Siehe Kommentare für `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary prüft, ob sich der Index in [0 befindet. .len()] kann `get` aufgrund von NLL-Problemen nicht wie oben beschrieben wiederverwenden
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SICHERHEIT: Ich habe gerade überprüft, ob `start` und `end` an einer Zeichengrenze liegen.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementiert das Schneiden von Teilzeichenfolgen mit der Syntax `&self[.. end]` oder `&mut self[.. end]`.
///
/// Gibt einen Slice der angegebenen Zeichenfolge aus dem Bytebereich [`0`, `end`) zurück.
/// Entspricht `&self[0 .. end]` oder `&mut self[0 .. end]`.
///
/// Diese Operation ist *O*(1).
///
/// Vor 1.20.0 wurden diese Indizierungsvorgänge noch durch die direkte Implementierung von `Index` und `IndexMut` unterstützt.
///
/// # Panics
///
/// Panics, wenn `end` nicht auf den Startbyte-Offset eines Zeichens zeigt (wie von `is_char_boundary` definiert), oder wenn `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `end` an einer Zeichengrenze befindet.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `end` an einer Zeichengrenze befindet.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `end` an einer Zeichengrenze befindet.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementiert das Schneiden von Teilzeichenfolgen mit der Syntax `&self[begin ..]` oder `&mut self[begin ..]`.
///
/// Gibt einen Slice der angegebenen Zeichenfolge aus dem Bytebereich zurück [`begin`, `len`).Entspricht `&self [begin ..
/// len] `oder`&mut self [begin ..
/// len]`.
///
/// Diese Operation ist *O*(1).
///
/// Vor 1.20.0 wurden diese Indizierungsvorgänge noch durch die direkte Implementierung von `Index` und `IndexMut` unterstützt.
///
/// # Panics
///
/// Panics, wenn `begin` nicht auf den Startbyte-Offset eines Zeichens zeigt (wie von `is_char_boundary` definiert), oder wenn `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `start` an einer Zeichengrenze befindet.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `start` an einer Zeichengrenze befindet.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SICHERHEIT: Der Anrufer garantiert, dass `self` innerhalb von `slice` liegt
        // Dies erfüllt alle Bedingungen für `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SICHERHEIT: identisch mit `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SICHERHEIT: Ich habe gerade überprüft, ob sich `start` an einer Zeichengrenze befindet.
            // und wir übergeben eine sichere Referenz, so dass der Rückgabewert auch eins sein wird.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementiert das Schneiden von Teilzeichenfolgen mit der Syntax `&self[begin ..= end]` oder `&mut self[begin ..= end]`.
///
/// Gibt einen Slice der angegebenen Zeichenfolge aus dem Bytebereich [`begin`, `end`] zurück.Entspricht `&self [begin .. end + 1]` oder `&mut self[begin .. end + 1]`, außer wenn `end` den Maximalwert für `usize` hat.
///
/// Diese Operation ist *O*(1).
///
/// # Panics
///
/// Panics, wenn `begin` nicht auf den Startbyte-Versatz eines Zeichens zeigt (wie durch `is_char_boundary` definiert), wenn `end` nicht auf den Endbyte-Versatz eines Zeichens zeigt (`end + 1` ist entweder ein Startbyte-Versatz oder gleich `len`), wenn `begin > end` oder wenn `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked` einhalten.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked_mut` einhalten.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementiert das Schneiden von Teilzeichenfolgen mit der Syntax `&self[..= end]` oder `&mut self[..= end]`.
///
/// Gibt einen Slice der angegebenen Zeichenfolge aus dem Bytebereich [0, `end`] zurück.
/// Entspricht `&self [0 .. end + 1]`, außer wenn `end` den Maximalwert für `usize` hat.
///
/// Diese Operation ist *O*(1).
///
/// # Panics
///
/// Panics, wenn `end` nicht auf den Endbyte-Offset eines Zeichens zeigt (`end + 1` ist entweder ein Startbyte-Offset gemäß `is_char_boundary` oder gleich `len`) oder wenn `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked` einhalten.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `get_unchecked_mut` einhalten.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analysieren Sie einen Wert aus einer Zeichenfolge
///
/// Die [`from_str`]-Methode von `FromStr` wird häufig implizit über die [`parse`]-Methode von [`str`] verwendet.
/// Beispiele finden Sie in der Dokumentation von [`parse`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` hat keinen Lebensdauerparameter, daher können Sie nur Typen analysieren, die selbst keinen Lebensdauerparameter enthalten.
///
/// Mit anderen Worten, Sie können einen `i32` mit `FromStr` analysieren, aber keinen `&i32`.
/// Sie können eine Struktur analysieren, die ein `i32` enthält, jedoch keine, die ein `&i32` enthält.
///
/// # Examples
///
/// Grundlegende Implementierung von `FromStr` auf einem Beispieltyp `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Der zugehörige Fehler, der beim Parsen zurückgegeben werden kann.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analysiert eine Zeichenfolge `s`, um einen Wert dieses Typs zurückzugeben.
    ///
    /// Wenn das Parsen erfolgreich ist, geben Sie den Wert in [`Ok`] zurück. Wenn die Zeichenfolge schlecht formatiert ist, wird ein Fehler zurückgegeben, der für [`Err`] spezifisch ist.
    /// Der Fehlertyp ist spezifisch für die Implementierung des trait.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung mit [`i32`], einem Typ, der `FromStr` implementiert:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analysieren Sie einen `bool` aus einer Zeichenfolge.
    ///
    /// Ergibt einen `Result<bool, ParseBoolError>`, da `s` möglicherweise tatsächlich analysiert werden kann oder nicht.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Beachten Sie, dass in vielen Fällen die `.parse()`-Methode unter `str` besser geeignet ist.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}