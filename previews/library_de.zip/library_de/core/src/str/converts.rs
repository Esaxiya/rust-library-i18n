//! Möglichkeiten zum Erstellen eines `str` aus einem Byte-Slice.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konvertiert ein Byte-Slice in ein String-Slice.
///
/// Ein String-Slice ([`&str`]) besteht aus Bytes ([`u8`]), und ein Byte-Slice ([`&[u8]`][byteslice]) besteht aus Bytes, sodass diese Funktion zwischen den beiden konvertiert.
/// Nicht alle Byte-Slices sind jedoch gültige String-Slices: [`&str`] setzt voraus, dass UTF-8 gültig ist.
/// `from_utf8()` prüft, ob die Bytes UTF-8 gültig sind, und führt dann die Konvertierung durch.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Wenn Sie sicher sind, dass das Byte-Slice UTF-8 gültig ist und Sie den Overhead der Gültigkeitsprüfung nicht verursachen möchten, gibt es eine unsichere Version dieser Funktion, [`from_utf8_unchecked`], die dasselbe Verhalten aufweist, die Prüfung jedoch überspringt.
///
///
/// Wenn Sie einen `String` anstelle eines `&str` benötigen, ziehen Sie [`String::from_utf8`][string] in Betracht.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Da Sie einen `[u8; N]` stapelweise zuweisen und einen [`&[u8]`][byteslice] davon nehmen können, ist diese Funktion eine Möglichkeit, eine vom Stapel zugewiesene Zeichenfolge zu erhalten.Ein Beispiel hierfür finden Sie im folgenden Beispielabschnitt.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Gibt `Err` zurück, wenn das Slice nicht UTF-8 ist, mit einer Beschreibung, warum das bereitgestellte Slice nicht UTF-8 ist.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::str;
///
/// // einige Bytes in einem vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Wir wissen, dass diese Bytes gültig sind, verwenden Sie also einfach `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Falsche Bytes:
///
/// ```
/// use std::str;
///
/// // einige ungültige Bytes in einem vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Weitere Informationen zu den Arten von Fehlern, die zurückgegeben werden können, finden Sie in den Dokumenten für [`Utf8Error`].
///
/// Ein "stack allocated string":
///
/// ```
/// use std::str;
///
/// // einige Bytes in einem vom Stapel zugewiesenen Array
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Wir wissen, dass diese Bytes gültig sind, verwenden Sie also einfach `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SICHERHEIT: Ich habe gerade die Validierung durchgeführt.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konvertiert ein veränderbares Byte-Slice in ein veränderbares String-Slice.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" als veränderlicher vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Da wir wissen, dass diese Bytes gültig sind, können wir `unwrap()` verwenden
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Falsche Bytes:
///
/// ```
/// use std::str;
///
/// // Einige ungültige Bytes in einem veränderlichen vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Weitere Informationen zu den Arten von Fehlern, die zurückgegeben werden können, finden Sie in den Dokumenten für [`Utf8Error`].
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SICHERHEIT: Ich habe gerade die Validierung durchgeführt.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konvertiert ein Byte-Slice in ein String-Slice, ohne zu überprüfen, ob der String gültiges UTF-8 enthält.
///
/// Weitere Informationen finden Sie in der sicheren Version [`from_utf8`].
///
/// # Safety
///
/// Diese Funktion ist unsicher, da nicht überprüft wird, ob die an sie übergebenen Bytes UTF-8 gültig sind.
/// Wenn diese Einschränkung verletzt wird, ergibt sich ein undefiniertes Verhalten, da der Rest von Rust davon ausgeht, dass [`&str`] s UTF-8 gültig sind.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::str;
///
/// // einige Bytes in einem vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SICHERHEIT: Der Aufrufer muss garantieren, dass die Bytes `v` UTF-8 gültig sind.
    // Verlässt sich auch darauf, dass `&str` und `&[u8]` das gleiche Layout haben.
    unsafe { mem::transmute(v) }
}

/// Konvertiert ein Byte-Slice in ein String-Slice, ohne zu überprüfen, ob der String gültiges UTF-8 enthält.veränderbare Version.
///
///
/// Weitere Informationen finden Sie in der unveränderlichen Version [`from_utf8_unchecked()`].
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SICHERHEIT: Der Aufrufer muss sicherstellen, dass die Bytes `v`
    // sind UTF-8 gültig, daher ist die Umwandlung in `*mut str` sicher.
    // Die Zeiger-Dereferenzierung ist auch sicher, da dieser Zeiger aus einer Referenz stammt, die garantiert für Schreibvorgänge gültig ist.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}