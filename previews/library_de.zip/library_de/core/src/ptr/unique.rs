use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Ein Wrapper um ein unformatiertes `*mut T` ungleich Null, der angibt, dass der Besitzer dieses Wrappers den Referenten besitzt.
/// Nützlich zum Erstellen von Abstraktionen wie `Box<T>`, `Vec<T>`, `String` und `HashMap<K, V>`.
///
/// Im Gegensatz zu `*mut T` verhält sich `Unique<T>` wie "as if", es war eine Instanz von `T`.
/// Es implementiert `Send`/`Sync`, wenn `T` `Send`/`Sync` ist.
/// Dies impliziert auch die Art von starkem Aliasing, die eine Instanz von `T` erwarten kann:
/// Der Referent des Zeigers sollte nicht ohne einen eindeutigen Pfad zu seinem eigenen Unique geändert werden.
///
/// Wenn Sie sich nicht sicher sind, ob es richtig ist, `Unique` für Ihre Zwecke zu verwenden, sollten Sie `NonNull` verwenden, das eine schwächere Semantik aufweist.
///
///
/// Im Gegensatz zu `*mut T` muss der Zeiger immer ungleich Null sein, auch wenn der Zeiger niemals dereferenziert wird.
/// Auf diese Weise können Enums diesen verbotenen Wert als Diskriminante verwenden-`Option<Unique<T>>` hat dieselbe Größe wie `Unique<T>`.
/// Der Zeiger kann jedoch weiterhin baumeln, wenn er nicht dereferenziert ist.
///
/// Im Gegensatz zu `*mut T` ist `Unique<T>` gegenüber `T` kovariant.
/// Dies sollte immer für jeden Typ korrekt sein, der die Aliasing-Anforderungen von Unique erfüllt.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: Dieser Marker hat keine Konsequenzen für die Varianz, ist aber notwendig
    // damit dropck versteht, dass wir logischerweise einen `T` besitzen.
    //
    // Einzelheiten finden Sie unter:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` Zeiger sind `Send`, wenn `T` `Send` ist, da die Daten, auf die sie verweisen, nicht verzerrt sind.
/// Beachten Sie, dass diese Aliasing-Invariante vom Typsystem nicht erzwungen wird.Die Abstraktion mit dem `Unique` muss dies erzwingen.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` Zeiger sind `Sync`, wenn `T` `Sync` ist, da die Daten, auf die sie verweisen, nicht vorgespannt sind.
/// Beachten Sie, dass diese Aliasing-Invariante vom Typsystem nicht erzwungen wird.Die Abstraktion mit dem `Unique` muss dies erzwingen.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Erstellt einen neuen `Unique`, der baumelt, aber gut ausgerichtet ist.
    ///
    /// Dies ist nützlich, um Typen zu initialisieren, die wie `Vec::new` träge zugeordnet werden.
    ///
    /// Beachten Sie, dass der Zeigerwert möglicherweise einen gültigen Zeiger auf einen `T` darstellt. Dies bedeutet, dass dieser Wert nicht als "not yet initialized"-Sentinel-Wert verwendet werden darf.
    /// Typen, die träge zuweisen, müssen die Initialisierung auf andere Weise verfolgen.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SICHERHEIT: mem::align_of() gibt einen gültigen Zeiger ungleich Null zurück.Das
        // Die Bedingungen zum Aufrufen von new_unchecked() werden somit eingehalten.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Erstellt einen neuen `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` muss nicht null sein.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `ptr` nicht null ist.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Erstellt ein neues `Unique`, wenn `ptr` nicht null ist.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SICHERHEIT: Der Zeiger wurde bereits überprüft und ist nicht null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Erfasst den zugrunde liegenden `*mut`-Zeiger.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Verweist auf den Inhalt.
    ///
    /// Die resultierende Lebensdauer ist an sich selbst gebunden, so dass sich "as if" verhält. Es handelt sich tatsächlich um eine Instanz von T, die ausgeliehen wird.
    /// Wenn eine längere (unbound)-Lebensdauer erforderlich ist, verwenden Sie `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine Referenz.
        unsafe { &*self.as_ptr() }
    }

    /// Der Inhalt wird gegenseitig dereferenziert.
    ///
    /// Die resultierende Lebensdauer ist an sich selbst gebunden, so dass sich "as if" verhält. Es handelt sich tatsächlich um eine Instanz von T, die ausgeliehen wird.
    /// Wenn eine längere (unbound)-Lebensdauer erforderlich ist, verwenden Sie `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine veränderbare Referenz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Wirkt auf einen Zeiger eines anderen Typs.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SICHERHEIT: Unique::new_unchecked() schafft ein neues Unikat und neue Bedürfnisse
        // Der angegebene Zeiger darf nicht null sein.
        // Da wir uns selbst als Zeiger übergeben, kann es nicht null sein.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SICHERHEIT: Eine veränderbare Referenz kann nicht null sein
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}