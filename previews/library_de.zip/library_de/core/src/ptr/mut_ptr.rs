use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Gibt `true` zurück, wenn der Zeiger null ist.
    ///
    /// Beachten Sie, dass nicht dimensionierte Typen viele mögliche Nullzeiger haben, da nur der Rohdatenzeiger berücksichtigt wird, nicht deren Länge, vtable usw.
    /// Daher sind zwei Zeiger, die null sind, möglicherweise immer noch nicht gleich miteinander vergleichbar.
    ///
    /// ## Verhalten während der Konstantenbewertung
    ///
    /// Wenn diese Funktion während der Konstantenauswertung verwendet wird, gibt sie möglicherweise `false` für Zeiger zurück, die sich zur Laufzeit als null herausstellen.
    /// Insbesondere wenn ein Zeiger auf einen Speicher über seine Grenzen hinaus so versetzt ist, dass der resultierende Zeiger null ist, gibt die Funktion weiterhin `false` zurück.
    ///
    /// CTFE kann die absolute Position dieses Speichers nicht ermitteln, daher können wir nicht feststellen, ob der Zeiger null ist oder nicht.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Vergleichen Sie über einen Cast mit einem dünnen Zeiger, sodass fette Zeiger ihren "data"-Teil nur auf Null prüfen.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Wirkt auf einen Zeiger eines anderen Typs.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Zerlegen Sie einen (möglicherweise breiten) Zeiger in Adress-und Metadatenkomponenten.
    ///
    /// Der Zeiger kann später mit [`from_raw_parts_mut`] rekonstruiert werden.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Gibt `None` zurück, wenn der Zeiger null ist, oder gibt einen gemeinsamen Verweis auf den in `Some` eingeschlossenen Wert zurück.Wenn der Wert möglicherweise nicht initialisiert ist, muss stattdessen [`as_uninit_ref`] verwendet werden.
    ///
    /// Für das veränderbare Gegenstück siehe [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass *entweder* der Zeiger NULL ist *oder* alle der folgenden Aussagen wahr sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Der Zeiger muss auf eine initialisierte Instanz von `T` zeigen.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///   Insbesondere darf für die Dauer dieser Lebensdauer der Speicher, auf den der Zeiger zeigt, nicht mutiert werden (außer innerhalb von `UnsafeCell`).
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    /// (Der Teil über die Initialisierung ist noch nicht vollständig entschieden, aber bis dahin besteht der einzig sichere Ansatz darin, sicherzustellen, dass sie tatsächlich initialisiert werden.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-ungeprüfte Version
    ///
    /// Wenn Sie sicher sind, dass der Zeiger niemals null sein kann und nach einer Art `as_ref_unchecked` suchen, die `&T` anstelle von `Option<&T>` zurückgibt, wissen Sie, dass Sie den Zeiger direkt dereferenzieren können.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` für a gültig ist
        // Referenz, wenn es nicht null ist.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Gibt `None` zurück, wenn der Zeiger null ist, oder gibt einen gemeinsamen Verweis auf den in `Some` eingeschlossenen Wert zurück.
    /// Im Gegensatz zu [`as_ref`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das veränderbare Gegenstück siehe [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass *entweder* der Zeiger NULL ist *oder* alle der folgenden Aussagen wahr sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///
    ///   Insbesondere darf für die Dauer dieser Lebensdauer der Speicher, auf den der Zeiger zeigt, nicht mutiert werden (außer innerhalb von `UnsafeCell`).
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine Referenz.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Berechnet den Versatz von einem Zeiger.
    ///
    /// `count` ist in Einheiten von T;Beispielsweise repräsentiert ein `count` von 3 einen Zeigerversatz von `3 * size_of::<T>()`-Bytes.
    ///
    /// # Safety
    ///
    /// Wenn eine der folgenden Bedingungen verletzt wird, lautet das Ergebnis Undefiniertes Verhalten:
    ///
    /// * Sowohl der Startzeiger als auch der resultierende Zeiger müssen entweder in Grenzen oder ein Byte nach dem Ende desselben zugewiesenen Objekts liegen.
    /// Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
    ///
    /// * Der berechnete Offset **in Bytes** kann einen `isize` nicht überlaufen lassen.
    ///
    /// * Der in Grenzen befindliche Offset kann sich nicht auf den Adressraum "wrapping around" verlassen.Das heißt, die Summe mit unendlicher Genauigkeit,**in Bytes**, muss in eine Usize passen.
    ///
    /// Der Compiler und die Standardbibliothek versuchen im Allgemeinen sicherzustellen, dass Zuordnungen niemals eine Größe erreichen, bei der ein Offset ein Problem darstellt.
    /// Beispielsweise stellen `Vec` und `Box` sicher, dass sie niemals mehr als `isize::MAX`-Bytes zuweisen, sodass `vec.as_ptr().add(vec.len())` immer sicher ist.
    ///
    /// Die meisten Plattformen können eine solche Zuordnung grundsätzlich nicht einmal erstellen.
    /// Beispielsweise kann keine bekannte 64-Bit-Plattform aufgrund von Einschränkungen der Seitentabelle oder der Aufteilung des Adressraums jemals eine Anforderung für 2 <sup>63</sup> Byte bedienen.
    /// Einige 32-Bit-und 16-Bit-Plattformen können jedoch erfolgreich eine Anforderung für mehr als `isize::MAX`-Bytes mit Dingen wie der physischen Adresserweiterung bedienen.
    ///
    /// Daher kann der direkt von Allokatoren oder Speicherzuordnungsdateien *erfasste* Speicher * zu groß sein, um mit dieser Funktion verarbeitet zu werden.
    ///
    /// Verwenden Sie stattdessen [`wrapping_offset`], wenn diese Einschränkungen nur schwer zu erfüllen sind.
    /// Der einzige Vorteil dieser Methode besteht darin, dass aggressivere Compileroptimierungen möglich sind.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `offset` einhalten.
        // Der erhaltene Zeiger ist für Schreibvorgänge gültig, da der Aufrufer sicherstellen muss, dass er auf dasselbe zugewiesene Objekt wie `self` zeigt.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Berechnet den Versatz eines Zeigers mithilfe der Umbrucharithmetik.
    /// `count` ist in Einheiten von T;Beispielsweise repräsentiert ein `count` von 3 einen Zeigerversatz von `3 * size_of::<T>()`-Bytes.
    ///
    /// # Safety
    ///
    /// Diese Operation selbst ist immer sicher, die Verwendung des resultierenden Zeigers jedoch nicht.
    ///
    /// Der resultierende Zeiger bleibt an dasselbe zugewiesene Objekt angehängt, auf das `self` zeigt.
    /// Es darf *nicht* verwendet werden, um auf ein anderes zugewiesenes Objekt zuzugreifen.Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
    ///
    /// Mit anderen Worten, `let z = x.wrapping_offset((y as isize) - (x as isize))` macht `z`*nicht* mit `y` identisch, selbst wenn wir davon ausgehen, dass `T` die Größe `1` hat und kein Überlauf vorliegt: `z` ist weiterhin an das Objekt angehängt, an das `x` angehängt ist, und dereferenziert es ist undefiniertes Verhalten, es sei denn, `x` und `y` zeigt auf dasselbe zugewiesene Objekt.
    ///
    /// Im Vergleich zu [`offset`] verzögert diese Methode im Wesentlichen die Anforderung, innerhalb desselben zugewiesenen Objekts zu bleiben: [`offset`] ist sofort undefiniertes Verhalten beim Überschreiten von Objektgrenzen;`wrapping_offset` erzeugt einen Zeiger, führt aber dennoch zu undefiniertem Verhalten, wenn ein Zeiger dereferenziert wird, wenn er außerhalb der Grenzen des Objekts liegt, an das er angehängt ist.
    /// [`offset`] kann besser optimiert werden und ist daher in leistungsempfindlichem Code vorzuziehen.
    ///
    /// Bei der verzögerten Prüfung wird nur der Wert des Zeigers berücksichtigt, der dereferenziert wurde, nicht die Zwischenwerte, die bei der Berechnung des Endergebnisses verwendet wurden.
    /// Beispielsweise ist `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` immer dasselbe wie `x`.Mit anderen Worten, es ist zulässig, das zugewiesene Objekt zu verlassen und es später erneut einzugeben.
    ///
    /// Wenn Sie Objektgrenzen überschreiten müssen, setzen Sie den Zeiger auf eine Ganzzahl und führen Sie dort die Arithmetik durch.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // Iterieren Sie mit einem Rohzeiger in Schritten von zwei Elementen
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SICHERHEIT: Für das `arith_offset`-Intrinsic müssen keine Voraussetzungen erfüllt werden.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Gibt `None` zurück, wenn der Zeiger null ist, oder gibt einen eindeutigen Verweis auf den in `Some` eingeschlossenen Wert zurück.Wenn der Wert möglicherweise nicht initialisiert ist, muss stattdessen [`as_uninit_mut`] verwendet werden.
    ///
    /// Für das gemeinsam genutzte Gegenstück siehe [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass *entweder* der Zeiger NULL ist *oder* alle der folgenden Aussagen wahr sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Der Zeiger muss auf eine initialisierte Instanz von `T` zeigen.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///   Insbesondere darf für die Dauer dieser Lebensdauer auf den Speicher, auf den der Zeiger zeigt, nicht über einen anderen Zeiger zugegriffen (gelesen oder geschrieben) werden.
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    /// (Der Teil über die Initialisierung ist noch nicht vollständig entschieden, aber bis dahin besteht der einzig sichere Ansatz darin, sicherzustellen, dass sie tatsächlich initialisiert werden.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Es wird gedruckt: "[4, 2, 3]".
    /// ```
    ///
    /// # Null-ungeprüfte Version
    ///
    /// Wenn Sie sicher sind, dass der Zeiger niemals null sein kann und nach einer Art `as_mut_unchecked` suchen, die `&mut T` anstelle von `Option<&mut T>` zurückgibt, wissen Sie, dass Sie den Zeiger direkt dereferenzieren können.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Es wird gedruckt: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` gültig ist für
        // eine veränderbare Referenz, wenn sie nicht null ist.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Gibt `None` zurück, wenn der Zeiger null ist, oder gibt einen eindeutigen Verweis auf den in `Some` eingeschlossenen Wert zurück.
    /// Im Gegensatz zu [`as_mut`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das gemeinsam genutzte Gegenstück siehe [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass *entweder* der Zeiger NULL ist *oder* alle der folgenden Aussagen wahr sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///
    ///   Insbesondere darf für die Dauer dieser Lebensdauer auf den Speicher, auf den der Zeiger zeigt, nicht über einen anderen Zeiger zugegriffen (gelesen oder geschrieben) werden.
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine Referenz.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Gibt zurück, ob zwei Zeiger garantiert gleich sind.
    ///
    /// Zur Laufzeit verhält sich diese Funktion wie `self == other`.
    /// In einigen Kontexten (z. B. Auswertung zur Kompilierungszeit) ist es jedoch nicht immer möglich, die Gleichheit von zwei Zeigern zu bestimmen, sodass diese Funktion möglicherweise fälschlicherweise `false` für Zeiger zurückgibt, die sich später tatsächlich als gleich herausstellen.
    ///
    /// Wenn jedoch `true` zurückgegeben wird, sind die Zeiger garantiert gleich.
    ///
    /// Diese Funktion ist der Spiegel von [`guaranteed_ne`], aber nicht umgekehrt.Es gibt Zeigervergleiche, für die beide Funktionen `false` zurückgeben.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Der Rückgabewert kann sich je nach Compilerversion ändern, und unsicherer Code hängt möglicherweise nicht vom Ergebnis dieser Funktion ab.
    /// Es wird empfohlen, diese Funktion nur für Leistungsoptimierungen zu verwenden, bei denen falsche `false`-Rückgabewerte dieser Funktion nicht das Ergebnis, sondern nur die Leistung beeinflussen.
    /// Die Konsequenzen der Verwendung dieser Methode für ein unterschiedliches Verhalten von Laufzeit-und Kompilierungscode wurden nicht untersucht.
    /// Diese Methode sollte nicht verwendet werden, um solche Unterschiede einzuführen, und sie sollte auch nicht stabilisiert werden, bevor wir dieses Problem besser verstehen.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Gibt zurück, ob zwei Zeiger garantiert ungleich sind.
    ///
    /// Zur Laufzeit verhält sich diese Funktion wie `self != other`.
    /// In einigen Kontexten (z. B. Auswertung zur Kompilierungszeit) ist es jedoch nicht immer möglich, die Ungleichung zweier Zeiger zu bestimmen, sodass diese Funktion möglicherweise fälschlicherweise `false` für Zeiger zurückgibt, die sich später tatsächlich als ungleich herausstellen.
    ///
    /// Wenn jedoch `true` zurückgegeben wird, sind die Zeiger garantiert ungleich.
    ///
    /// Diese Funktion ist der Spiegel von [`guaranteed_eq`], aber nicht umgekehrt.Es gibt Zeigervergleiche, für die beide Funktionen `false` zurückgeben.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Der Rückgabewert kann sich je nach Compilerversion ändern, und unsicherer Code hängt möglicherweise nicht vom Ergebnis dieser Funktion ab.
    /// Es wird empfohlen, diese Funktion nur für Leistungsoptimierungen zu verwenden, bei denen falsche `false`-Rückgabewerte dieser Funktion nicht das Ergebnis, sondern nur die Leistung beeinflussen.
    /// Die Konsequenzen der Verwendung dieser Methode für ein unterschiedliches Verhalten von Laufzeit-und Kompilierungscode wurden nicht untersucht.
    /// Diese Methode sollte nicht verwendet werden, um solche Unterschiede einzuführen, und sie sollte auch nicht stabilisiert werden, bevor wir dieses Problem besser verstehen.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Berechnet den Abstand zwischen zwei Zeigern.Der zurückgegebene Wert wird in Einheiten von T angegeben: Der Abstand in Bytes wird durch `mem::size_of::<T>()` geteilt.
    ///
    /// Diese Funktion ist die Umkehrung von [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Wenn eine der folgenden Bedingungen verletzt wird, lautet das Ergebnis Undefiniertes Verhalten:
    ///
    /// * Sowohl der Startzeiger als auch der andere Zeiger müssen entweder in Grenzen oder ein Byte nach dem Ende desselben zugewiesenen Objekts liegen.
    /// Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
    ///
    /// * Beide Zeiger müssen *von* einem Zeiger auf dasselbe Objekt abgeleitet sein.
    ///   (Ein Beispiel finden Sie weiter unten.)
    ///
    /// * Der Abstand zwischen den Zeigern in Bytes muss ein genaues Vielfaches der Größe von `T` sein.
    ///
    /// * Der Abstand zwischen den Zeigern,**in Bytes**, kann einen `isize` nicht überlaufen lassen.
    ///
    /// * Die Entfernung in Grenzen kann nicht vom "wrapping around"-Adressraum abhängen.
    ///
    /// Rust-Typen sind niemals größer als `isize::MAX`, und Rust-Zuweisungen werden niemals um den Adressraum gewickelt, sodass zwei Zeiger innerhalb eines Werts eines Rust-Typs `T` immer die letzten beiden Bedingungen erfüllen.
    ///
    /// Die Standardbibliothek stellt im Allgemeinen auch sicher, dass Zuordnungen niemals eine Größe erreichen, bei der ein Versatz ein Problem darstellt.
    /// Beispielsweise stellen `Vec` und `Box` sicher, dass sie niemals mehr als `isize::MAX`-Bytes zuweisen, sodass `ptr_into_vec.offset_from(vec.as_ptr())` immer die letzten beiden Bedingungen erfüllt.
    ///
    /// Die meisten Plattformen können grundsätzlich nicht einmal eine so große Zuordnung erstellen.
    /// Beispielsweise kann keine bekannte 64-Bit-Plattform aufgrund von Einschränkungen der Seitentabelle oder der Aufteilung des Adressraums jemals eine Anforderung für 2 <sup>63</sup> Byte bedienen.
    /// Einige 32-Bit-und 16-Bit-Plattformen können jedoch erfolgreich eine Anforderung für mehr als `isize::MAX`-Bytes mit Dingen wie der physischen Adresserweiterung bedienen.
    /// Daher kann der direkt von Allokatoren oder Speicherzuordnungsdateien *erfasste* Speicher * zu groß sein, um mit dieser Funktion verarbeitet zu werden.
    /// (Beachten Sie, dass [`offset`] und [`add`] ebenfalls eine ähnliche Einschränkung aufweisen und daher auch nicht für so große Zuordnungen verwendet werden können.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Diese Funktion panics, wenn `T` ein Typ ("ZST") mit Nullgröße ist.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Falsche* Verwendung:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Machen Sie ptr2_other zu einem "alias" von ptr2, das jedoch von ptr1 abgeleitet ist.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Da ptr2_other und ptr2 von Zeigern auf verschiedene Objekte abgeleitet werden, ist die Berechnung ihres Offsets ein undefiniertes Verhalten, obwohl sie auf dieselbe Adresse verweisen!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Undefiniertes Verhalten
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `offset_from` einhalten.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Berechnet den Versatz von einem Zeiger (Komfort für `.offset(count as isize)`).
    ///
    /// `count` ist in Einheiten von T;Beispielsweise repräsentiert ein `count` von 3 einen Zeigerversatz von `3 * size_of::<T>()`-Bytes.
    ///
    /// # Safety
    ///
    /// Wenn eine der folgenden Bedingungen verletzt wird, lautet das Ergebnis Undefiniertes Verhalten:
    ///
    /// * Sowohl der Startzeiger als auch der resultierende Zeiger müssen entweder in Grenzen oder ein Byte nach dem Ende desselben zugewiesenen Objekts liegen.
    /// Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
    ///
    /// * Der berechnete Offset **in Bytes** kann einen `isize` nicht überlaufen lassen.
    ///
    /// * Der in Grenzen befindliche Offset kann sich nicht auf den Adressraum "wrapping around" verlassen.Das heißt, die Summe mit unendlicher Genauigkeit muss in einen `usize` passen.
    ///
    /// Der Compiler und die Standardbibliothek versuchen im Allgemeinen sicherzustellen, dass Zuordnungen niemals eine Größe erreichen, bei der ein Offset ein Problem darstellt.
    /// Beispielsweise stellen `Vec` und `Box` sicher, dass sie niemals mehr als `isize::MAX`-Bytes zuweisen, sodass `vec.as_ptr().add(vec.len())` immer sicher ist.
    ///
    /// Die meisten Plattformen können eine solche Zuordnung grundsätzlich nicht einmal erstellen.
    /// Beispielsweise kann keine bekannte 64-Bit-Plattform aufgrund von Einschränkungen der Seitentabelle oder der Aufteilung des Adressraums jemals eine Anforderung für 2 <sup>63</sup> Byte bedienen.
    /// Einige 32-Bit-und 16-Bit-Plattformen können jedoch erfolgreich eine Anforderung für mehr als `isize::MAX`-Bytes mit Dingen wie der physischen Adresserweiterung bedienen.
    ///
    /// Daher kann der direkt von Allokatoren oder Speicherzuordnungsdateien *erfasste* Speicher * zu groß sein, um mit dieser Funktion verarbeitet zu werden.
    ///
    /// Verwenden Sie stattdessen [`wrapping_add`], wenn diese Einschränkungen nur schwer zu erfüllen sind.
    /// Der einzige Vorteil dieser Methode besteht darin, dass aggressivere Compileroptimierungen möglich sind.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `offset` einhalten.
        unsafe { self.offset(count as isize) }
    }

    /// Berechnet den Versatz von einem Zeiger (Bequemlichkeit für `.offset ((zählt als isize).wrapping_neg())`)).
    ///
    /// `count` ist in Einheiten von T;Beispielsweise repräsentiert ein `count` von 3 einen Zeigerversatz von `3 * size_of::<T>()`-Bytes.
    ///
    /// # Safety
    ///
    /// Wenn eine der folgenden Bedingungen verletzt wird, lautet das Ergebnis Undefiniertes Verhalten:
    ///
    /// * Sowohl der Startzeiger als auch der resultierende Zeiger müssen entweder in Grenzen oder ein Byte nach dem Ende desselben zugewiesenen Objekts liegen.
    /// Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
    ///
    /// * Der berechnete Offset darf `isize::MAX`**Bytes** nicht überschreiten.
    ///
    /// * Der in Grenzen befindliche Offset kann sich nicht auf den Adressraum "wrapping around" verlassen.Das heißt, die Summe mit unendlicher Genauigkeit muss in eine Usize passen.
    ///
    /// Der Compiler und die Standardbibliothek versuchen im Allgemeinen sicherzustellen, dass Zuordnungen niemals eine Größe erreichen, bei der ein Offset ein Problem darstellt.
    /// Beispielsweise stellen `Vec` und `Box` sicher, dass sie niemals mehr als `isize::MAX`-Bytes zuweisen, sodass `vec.as_ptr().add(vec.len()).sub(vec.len())` immer sicher ist.
    ///
    /// Die meisten Plattformen können eine solche Zuordnung grundsätzlich nicht einmal erstellen.
    /// Beispielsweise kann keine bekannte 64-Bit-Plattform aufgrund von Einschränkungen der Seitentabelle oder der Aufteilung des Adressraums jemals eine Anforderung für 2 <sup>63</sup> Byte bedienen.
    /// Einige 32-Bit-und 16-Bit-Plattformen können jedoch erfolgreich eine Anforderung für mehr als `isize::MAX`-Bytes mit Dingen wie der physischen Adresserweiterung bedienen.
    ///
    /// Daher kann der direkt von Allokatoren oder Speicherzuordnungsdateien *erfasste* Speicher * zu groß sein, um mit dieser Funktion verarbeitet zu werden.
    ///
    /// Verwenden Sie stattdessen [`wrapping_sub`], wenn diese Einschränkungen nur schwer zu erfüllen sind.
    /// Der einzige Vorteil dieser Methode besteht darin, dass aggressivere Compileroptimierungen möglich sind.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `offset` einhalten.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Berechnet den Versatz eines Zeigers mithilfe der Umbrucharithmetik.
    /// (Bequemlichkeit für `.wrapping_offset(count as isize)`)
    ///
    /// `count` ist in Einheiten von T;Beispielsweise repräsentiert ein `count` von 3 einen Zeigerversatz von `3 * size_of::<T>()`-Bytes.
    ///
    /// # Safety
    ///
    /// Diese Operation selbst ist immer sicher, die Verwendung des resultierenden Zeigers jedoch nicht.
    ///
    /// Der resultierende Zeiger bleibt an dasselbe zugewiesene Objekt angehängt, auf das `self` zeigt.
    /// Es darf *nicht* verwendet werden, um auf ein anderes zugewiesenes Objekt zuzugreifen.Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
    ///
    /// Mit anderen Worten, `let z = x.wrapping_add((y as usize) - (x as usize))` macht `z`*nicht* mit `y` identisch, selbst wenn wir davon ausgehen, dass `T` die Größe `1` hat und kein Überlauf vorliegt: `z` ist weiterhin an das Objekt angehängt, an das `x` angehängt ist, und dereferenziert, dass es sich um undefiniertes Verhalten handelt, es sei denn, `x` und `y` zeigt auf dasselbe zugewiesene Objekt.
    ///
    /// Im Vergleich zu [`add`] verzögert diese Methode im Wesentlichen die Anforderung, innerhalb desselben zugewiesenen Objekts zu bleiben: [`add`] ist sofort undefiniertes Verhalten beim Überschreiten von Objektgrenzen;`wrapping_add` erzeugt einen Zeiger, führt aber dennoch zu undefiniertem Verhalten, wenn ein Zeiger dereferenziert wird, wenn er außerhalb der Grenzen des Objekts liegt, an das er angehängt ist.
    /// [`add`] kann besser optimiert werden und ist daher in leistungsempfindlichem Code vorzuziehen.
    ///
    /// Bei der verzögerten Prüfung wird nur der Wert des Zeigers berücksichtigt, der dereferenziert wurde, nicht die Zwischenwerte, die bei der Berechnung des Endergebnisses verwendet wurden.
    /// Beispielsweise ist `x.wrapping_add(o).wrapping_sub(o)` immer dasselbe wie `x`.Mit anderen Worten, es ist zulässig, das zugewiesene Objekt zu verlassen und es später erneut einzugeben.
    ///
    /// Wenn Sie Objektgrenzen überschreiten müssen, setzen Sie den Zeiger auf eine Ganzzahl und führen Sie dort die Arithmetik durch.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // Iterieren Sie mit einem Rohzeiger in Schritten von zwei Elementen
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Diese Schleife druckt "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Berechnet den Versatz eines Zeigers mithilfe der Umbrucharithmetik.
    /// (Bequemlichkeit für `.wrapping_offset ((zählt als isize).wrapping_neg())`)
    ///
    /// `count` ist in Einheiten von T;Beispielsweise repräsentiert ein `count` von 3 einen Zeigerversatz von `3 * size_of::<T>()`-Bytes.
    ///
    /// # Safety
    ///
    /// Diese Operation selbst ist immer sicher, die Verwendung des resultierenden Zeigers jedoch nicht.
    ///
    /// Der resultierende Zeiger bleibt an dasselbe zugewiesene Objekt angehängt, auf das `self` zeigt.
    /// Es darf *nicht* verwendet werden, um auf ein anderes zugewiesenes Objekt zuzugreifen.Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
    ///
    /// Mit anderen Worten, `let z = x.wrapping_sub((x as usize) - (y as usize))` macht `z`*nicht* mit `y` identisch, selbst wenn wir davon ausgehen, dass `T` die Größe `1` hat und kein Überlauf vorliegt: `z` ist weiterhin an das Objekt angehängt, an das `x` angehängt ist, und dereferenziert, dass es sich um undefiniertes Verhalten handelt, es sei denn, `x` und `y` zeigt auf dasselbe zugewiesene Objekt.
    ///
    /// Im Vergleich zu [`sub`] verzögert diese Methode im Wesentlichen die Anforderung, innerhalb desselben zugewiesenen Objekts zu bleiben: [`sub`] ist sofort undefiniertes Verhalten beim Überschreiten von Objektgrenzen;`wrapping_sub` erzeugt einen Zeiger, führt aber dennoch zu undefiniertem Verhalten, wenn ein Zeiger dereferenziert wird, wenn er außerhalb der Grenzen des Objekts liegt, an das er angehängt ist.
    /// [`sub`] kann besser optimiert werden und ist daher in leistungsempfindlichem Code vorzuziehen.
    ///
    /// Bei der verzögerten Prüfung wird nur der Wert des Zeigers berücksichtigt, der dereferenziert wurde, nicht die Zwischenwerte, die bei der Berechnung des Endergebnisses verwendet wurden.
    /// Beispielsweise ist `x.wrapping_add(o).wrapping_sub(o)` immer dasselbe wie `x`.Mit anderen Worten, es ist zulässig, das zugewiesene Objekt zu verlassen und es später erneut einzugeben.
    ///
    /// Wenn Sie Objektgrenzen überschreiten müssen, setzen Sie den Zeiger auf eine Ganzzahl und führen Sie dort die Arithmetik durch.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // Iterieren Sie mit einem Rohzeiger in Schritten von zwei Elementen (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Diese Schleife druckt "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Setzt den Zeigerwert auf `ptr`.
    ///
    /// Wenn `self` ein (fat)-Zeiger auf einen Typ ohne Größe ist, wirkt sich diese Operation nur auf den Zeigerteil aus, während dies für (thin)-Zeiger auf Typen mit Größe den gleichen Effekt hat wie eine einfache Zuweisung.
    ///
    /// Der resultierende Zeiger hat die Herkunft `val`, dh für einen Fettzeiger entspricht diese Operation semantisch der Erstellung eines neuen Fettzeigers mit dem Datenzeigerwert `val`, jedoch den Metadaten von `self`.
    ///
    ///
    /// # Examples
    ///
    /// Diese Funktion ist in erster Linie nützlich, um byteweise Zeigerarithmetik für potenziell fette Zeiger zuzulassen:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // druckt "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SICHERHEIT: Bei einem dünnen Zeiger ist diese Operation identisch
        // zu einer einfachen Aufgabe.
        // Im Fall eines Fettzeigers ist bei der aktuellen Implementierung des Fettzeigerlayouts das erste Feld eines solchen Zeigers immer der Datenzeiger, der ebenfalls zugewiesen ist.
        //
        unsafe { *thin = val };
        self
    }

    /// Liest den Wert von `self`, ohne ihn zu verschieben.
    /// Dadurch bleibt der Speicher in `self` unverändert.
    ///
    /// Siehe [`ptr::read`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `` einhalten.
        unsafe { read(self) }
    }

    /// Führt einen flüchtigen Lesevorgang des Werts von `self` durch, ohne ihn zu verschieben.Dadurch bleibt der Speicher in `self` unverändert.
    ///
    /// Flüchtige Operationen sollen auf den I/O-Speicher einwirken und werden vom Compiler garantiert nicht über andere flüchtige Operationen hinweg entfernt oder neu angeordnet.
    ///
    ///
    /// Siehe [`ptr::read_volatile`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `read_volatile` einhalten.
        unsafe { read_volatile(self) }
    }

    /// Liest den Wert von `self`, ohne ihn zu verschieben.
    /// Dadurch bleibt der Speicher in `self` unverändert.
    ///
    /// Im Gegensatz zu `read` ist der Zeiger möglicherweise nicht ausgerichtet.
    ///
    /// Siehe [`ptr::read_unaligned`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `read_unaligned` einhalten.
        unsafe { read_unaligned(self) }
    }

    /// Kopiert `count * size_of<T>`-Bytes von `self` nach `dest`.
    /// Die Quelle und das Ziel können sich überschneiden.
    ///
    /// NOTE: Dies hat die *gleiche* Argumentreihenfolge wie [`ptr::copy`].
    ///
    /// Siehe [`ptr::copy`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `copy` einhalten.
        unsafe { copy(self, dest, count) }
    }

    /// Kopiert `count * size_of<T>`-Bytes von `self` nach `dest`.
    /// Die Quelle und das Ziel dürfen sich *nicht* überschneiden.
    ///
    /// NOTE: Dies hat die *gleiche* Argumentreihenfolge wie [`ptr::copy_nonoverlapping`].
    ///
    /// Siehe [`ptr::copy_nonoverlapping`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `copy_nonoverlapping` einhalten.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopiert `count * size_of<T>`-Bytes von `src` nach `self`.
    /// Die Quelle und das Ziel können sich überschneiden.
    ///
    /// NOTE: Dies hat die *entgegengesetzte* Argumentreihenfolge von [`ptr::copy`].
    ///
    /// Siehe [`ptr::copy`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `copy` einhalten.
        unsafe { copy(src, self, count) }
    }

    /// Kopiert `count * size_of<T>`-Bytes von `src` nach `self`.
    /// Die Quelle und das Ziel dürfen sich *nicht* überschneiden.
    ///
    /// NOTE: Dies hat die *entgegengesetzte* Argumentreihenfolge von [`ptr::copy_nonoverlapping`].
    ///
    /// Siehe [`ptr::copy_nonoverlapping`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `copy_nonoverlapping` einhalten.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Führt den Destruktor (falls vorhanden) des angegebenen Werts aus.
    ///
    /// Siehe [`ptr::drop_in_place`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `drop_in_place` einhalten.
        unsafe { drop_in_place(self) }
    }

    /// Überschreibt einen Speicherort mit dem angegebenen Wert, ohne den alten Wert zu lesen oder zu löschen.
    ///
    ///
    /// Siehe [`ptr::write`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `write` einhalten.
        unsafe { write(self, val) }
    }

    /// Ruft ein Memset für den angegebenen Zeiger auf und setzt `count * size_of::<T>()`-Bytes des Speichers ab `self` auf `val`.
    ///
    ///
    /// Siehe [`ptr::write_bytes`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `write_bytes` einhalten.
        unsafe { write_bytes(self, val, count) }
    }

    /// Führt ein flüchtiges Schreiben eines Speicherorts mit dem angegebenen Wert durch, ohne den alten Wert zu lesen oder zu löschen.
    ///
    /// Flüchtige Operationen sollen auf den I/O-Speicher einwirken und werden vom Compiler garantiert nicht über andere flüchtige Operationen hinweg entfernt oder neu angeordnet.
    ///
    ///
    /// Siehe [`ptr::write_volatile`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `write_volatile` einhalten.
        unsafe { write_volatile(self, val) }
    }

    /// Überschreibt einen Speicherort mit dem angegebenen Wert, ohne den alten Wert zu lesen oder zu löschen.
    ///
    ///
    /// Im Gegensatz zu `write` ist der Zeiger möglicherweise nicht ausgerichtet.
    ///
    /// Siehe [`ptr::write_unaligned`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `write_unaligned` einhalten.
        unsafe { write_unaligned(self, val) }
    }

    /// Ersetzt den Wert bei `self` durch `src` und gibt den alten Wert zurück, ohne ihn zu löschen.
    ///
    ///
    /// Siehe [`ptr::replace`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `replace` einhalten.
        unsafe { replace(self, src) }
    }

    /// Vertauscht die Werte an zwei veränderlichen Stellen desselben Typs, ohne sie zu deinitialisieren.
    /// Sie können sich überlappen, im Gegensatz zu `mem::swap`, das ansonsten gleichwertig ist.
    ///
    /// Siehe [`ptr::swap`] für Sicherheitsbedenken und Beispiele.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `swap` einhalten.
        unsafe { swap(self, with) }
    }

    /// Berechnet den Versatz, der auf den Zeiger angewendet werden muss, damit er an `align` ausgerichtet wird.
    ///
    /// Wenn der Zeiger nicht ausgerichtet werden kann, gibt die Implementierung `usize::MAX` zurück.
    /// Es ist zulässig, dass die Implementierung *immer*`usize::MAX` zurückgibt.
    /// Nur die Leistung Ihres Algorithmus kann davon abhängen, ob hier ein verwendbarer Offset erhalten wird, nicht von seiner Richtigkeit.
    ///
    /// Der Offset wird in Anzahl der `T`-Elemente und nicht in Bytes ausgedrückt.Der zurückgegebene Wert kann mit der `wrapping_add`-Methode verwendet werden.
    ///
    /// Es gibt keinerlei Garantie dafür, dass das Versetzen des Zeigers nicht überläuft oder über die Zuordnung hinausgeht, auf die der Zeiger zeigt.
    ///
    /// Es ist Sache des Anrufers, sicherzustellen, dass der zurückgegebene Offset in allen Begriffen außer der Ausrichtung korrekt ist.
    ///
    /// # Panics
    ///
    /// Die Funktion panics, wenn `align` keine Zweierpotenz ist.
    ///
    /// # Examples
    ///
    /// Zugriff auf das benachbarte `u8` als `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // Während der Zeiger über `offset` ausgerichtet werden kann, würde er außerhalb der Zuordnung zeigen
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SICHERHEIT: `align` wurde auf eine Potenz von 2 oben überprüft
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Gibt die Länge einer rohen Scheibe zurück.
    ///
    /// Der zurückgegebene Wert ist die Anzahl der **Elemente**, nicht die Anzahl der Bytes.
    ///
    /// Diese Funktion ist auch dann sicher, wenn das Roh-Slice nicht in eine Slice-Referenz umgewandelt werden kann, da der Zeiger null oder nicht ausgerichtet ist.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SICHERHEIT: Dies ist sicher, da `*const [T]` und `FatPtr<T>` das gleiche Layout haben.
            // Nur `std` kann diese Garantie übernehmen.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Gibt einen Rohzeiger auf den Puffer des Slice zurück.
    ///
    /// Dies entspricht dem Umwandeln von `self` in `*mut T`, ist jedoch typsicherer.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Gibt einen Rohzeiger auf ein Element oder eine Unterscheibe zurück, ohne die Grenzen zu überprüfen.
    ///
    /// Das Aufrufen dieser Methode mit einem Out-of-Bound-Index oder wenn `self` nicht dereferenzierbar ist, ist *[undefiniertes Verhalten]*, auch wenn der resultierende Zeiger nicht verwendet wird.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SICHERHEIT: Der Anrufer stellt sicher, dass `self` dereferenzierbar ist und `index` eingeholt wird.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Gibt `None` zurück, wenn der Zeiger null ist, oder gibt ein gemeinsames Slice auf den in `Some` eingeschlossenen Wert zurück.
    /// Im Gegensatz zu [`as_ref`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das veränderbare Gegenstück siehe [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass *entweder* der Zeiger NULL ist *oder* alle der folgenden Aussagen wahr sind:
    ///
    /// * Der Zeiger muss [valid] für Lesevorgänge für `ptr.len() * mem::size_of::<T>()` viele Bytes sein und muss richtig ausgerichtet sein.Dies bedeutet insbesondere:
    ///
    ///     * Der gesamte Speicherbereich dieses Slice muss in einem einzelnen zugewiesenen Objekt enthalten sein!
    ///       Slices können sich niemals über mehrere zugewiesene Objekte erstrecken.
    ///
    ///     * Der Zeiger muss auch für Slices mit der Länge Null ausgerichtet sein.
    ///     Ein Grund dafür ist, dass Optimierungen des Enum-Layouts davon abhängen können, dass Referenzen (einschließlich Slices beliebiger Länge) ausgerichtet und nicht null sind, um sie von anderen Daten zu unterscheiden.
    ///
    ///     Mit [`NonNull::dangling()`] können Sie einen Zeiger erhalten, der als `data` für Slices mit der Länge Null verwendet werden kann.
    ///
    /// * Die Gesamtgröße `ptr.len() * mem::size_of::<T>()` des Slice darf nicht größer als `isize::MAX` sein.
    ///   Siehe die Sicherheitsdokumentation von [`pointer::offset`].
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///   Insbesondere darf für die Dauer dieser Lebensdauer der Speicher, auf den der Zeiger zeigt, nicht mutiert werden (außer innerhalb von `UnsafeCell`).
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// Siehe auch [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `as_uninit_slice` einhalten.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Gibt `None` zurück, wenn der Zeiger null ist, oder gibt ein eindeutiges Slice für den in `Some` eingeschlossenen Wert zurück.
    /// Im Gegensatz zu [`as_mut`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das gemeinsam genutzte Gegenstück siehe [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass *entweder* der Zeiger NULL ist *oder* alle der folgenden Aussagen wahr sind:
    ///
    /// * Der Zeiger muss [valid] für Lese-und Schreibvorgänge für `ptr.len() * mem::size_of::<T>()` viele Bytes sein und muss richtig ausgerichtet sein.Dies bedeutet insbesondere:
    ///
    ///     * Der gesamte Speicherbereich dieses Slice muss in einem einzelnen zugewiesenen Objekt enthalten sein!
    ///       Slices können sich niemals über mehrere zugewiesene Objekte erstrecken.
    ///
    ///     * Der Zeiger muss auch für Slices mit der Länge Null ausgerichtet sein.
    ///     Ein Grund dafür ist, dass Optimierungen des Enum-Layouts davon abhängen können, dass Referenzen (einschließlich Slices beliebiger Länge) ausgerichtet und nicht null sind, um sie von anderen Daten zu unterscheiden.
    ///
    ///     Mit [`NonNull::dangling()`] können Sie einen Zeiger erhalten, der als `data` für Slices mit der Länge Null verwendet werden kann.
    ///
    /// * Die Gesamtgröße `ptr.len() * mem::size_of::<T>()` des Slice darf nicht größer als `isize::MAX` sein.
    ///   Siehe die Sicherheitsdokumentation von [`pointer::offset`].
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///   Insbesondere darf für die Dauer dieser Lebensdauer auf den Speicher, auf den der Zeiger zeigt, nicht über einen anderen Zeiger zugegriffen (gelesen oder geschrieben) werden.
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// Siehe auch [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `as_uninit_slice_mut` einhalten.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Gleichheit für Zeiger
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}