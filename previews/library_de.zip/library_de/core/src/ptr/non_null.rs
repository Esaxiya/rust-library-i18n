use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` aber nicht Null und kovariant.
///
/// Dies ist häufig die richtige Vorgehensweise beim Erstellen von Datenstrukturen mit Rohzeigern, ist jedoch aufgrund der zusätzlichen Eigenschaften letztendlich gefährlicher.Wenn Sie nicht sicher sind, ob Sie `NonNull<T>` verwenden sollen, verwenden Sie einfach `*mut T`!
///
/// Im Gegensatz zu `*mut T` muss der Zeiger immer ungleich Null sein, auch wenn der Zeiger niemals dereferenziert wird.Auf diese Weise können Enums diesen verbotenen Wert als Diskriminante verwenden-`Option<NonNull<T>>` hat dieselbe Größe wie `* mut T`.
/// Der Zeiger kann jedoch weiterhin baumeln, wenn er nicht dereferenziert ist.
///
/// Im Gegensatz zu `*mut T` wurde `NonNull<T>` als kovariant gegenüber `T` ausgewählt.Dies ermöglicht die Verwendung von `NonNull<T>` beim Erstellen kovarianter Typen, birgt jedoch das Risiko von Unklarheiten, wenn es in einem Typ verwendet wird, der eigentlich nicht kovariant sein sollte.
/// (Die entgegengesetzte Wahl wurde für `*mut T` getroffen, obwohl die Unklarheit technisch nur durch das Aufrufen unsicherer Funktionen verursacht werden konnte.)
///
/// Die Kovarianz ist für die meisten sicheren Abstraktionen wie `Box`, `Rc`, `Arc`, `Vec` und `LinkedList` korrekt.Dies ist der Fall, weil sie eine öffentliche API bereitstellen, die den normalen gemeinsam genutzten XOR-veränderbaren Regeln von Rust folgt.
///
/// Wenn Ihr Typ nicht sicher kovariant sein kann, müssen Sie sicherstellen, dass er ein zusätzliches Feld enthält, um die Invarianz bereitzustellen.Oft ist dieses Feld ein [`PhantomData`]-Typ wie `PhantomData<Cell<T>>` oder `PhantomData<&'a mut T>`.
///
/// Beachten Sie, dass `NonNull<T>` eine `From`-Instanz für `&T` hat.Dies ändert jedoch nichts an der Tatsache, dass das Mutieren durch eine (von einer abgeleiteten Zeiger abgeleitete) Referenz ein undefiniertes Verhalten ist, es sei denn, die Mutation erfolgt innerhalb eines [`UnsafeCell<T>`].Gleiches gilt für das Erstellen einer veränderlichen Referenz aus einer gemeinsam genutzten Referenz.
///
/// Wenn Sie diese `From`-Instanz ohne `UnsafeCell<T>` verwenden, müssen Sie sicherstellen, dass `as_mut` niemals aufgerufen wird und `as_ptr` niemals für Mutationen verwendet wird.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` Zeiger sind nicht `Send`, da die Daten, auf die sie verweisen, möglicherweise einen Alias aufweisen.
// NB, dieses Impl ist unnötig, sollte aber bessere Fehlermeldungen liefern.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` Zeiger sind nicht `Sync`, da die Daten, auf die sie verweisen, möglicherweise einen Alias aufweisen.
// NB, dieses Impl ist unnötig, sollte aber bessere Fehlermeldungen liefern.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Erstellt einen neuen `NonNull`, der baumelt, aber gut ausgerichtet ist.
    ///
    /// Dies ist nützlich, um Typen zu initialisieren, die wie `Vec::new` träge zugeordnet werden.
    ///
    /// Beachten Sie, dass der Zeigerwert möglicherweise einen gültigen Zeiger auf einen `T` darstellt. Dies bedeutet, dass dieser Wert nicht als "not yet initialized"-Sentinel-Wert verwendet werden darf.
    /// Typen, die träge zuweisen, müssen die Initialisierung auf andere Weise verfolgen.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SICHERHEIT: mem::align_of() gibt eine Nicht-Null-Usize zurück, die dann umgewandelt wird
        // zu einem * mut T.
        // Daher ist `ptr` nicht null und die Bedingungen für den Aufruf von new_unchecked() werden eingehalten.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Gibt einen gemeinsamen Verweis auf den Wert zurück.Im Gegensatz zu [`as_ref`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das veränderbare Gegenstück siehe [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass alle der folgenden Bedingungen erfüllt sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///
    ///   Insbesondere darf für die Dauer dieser Lebensdauer der Speicher, auf den der Zeiger zeigt, nicht mutiert werden (außer innerhalb von `UnsafeCell`).
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine Referenz.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Gibt eindeutige Verweise auf den Wert zurück.Im Gegensatz zu [`as_mut`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das gemeinsam genutzte Gegenstück siehe [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass alle der folgenden Bedingungen erfüllt sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///
    ///   Insbesondere darf für die Dauer dieser Lebensdauer auf den Speicher, auf den der Zeiger zeigt, nicht über einen anderen Zeiger zugegriffen (gelesen oder geschrieben) werden.
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine Referenz.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Erstellt einen neuen `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` muss nicht null sein.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `ptr` nicht null ist.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Erstellt ein neues `NonNull`, wenn `ptr` nicht null ist.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SICHERHEIT: Der Zeiger ist bereits überprüft und nicht null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Führt die gleiche Funktionalität wie [`std::ptr::from_raw_parts`] aus, außer dass ein `NonNull`-Zeiger zurückgegeben wird, im Gegensatz zu einem rohen `*const`-Zeiger.
    ///
    ///
    /// Weitere Informationen finden Sie in der Dokumentation zu [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SICHERHEIT: Das Ergebnis von `ptr::from::raw_parts_mut` ist nicht null, da `data_address` ist.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Zerlegen Sie einen (möglicherweise breiten) Zeiger in Adress-und Metadatenkomponenten.
    ///
    /// Der Zeiger kann später mit [`NonNull::from_raw_parts`] rekonstruiert werden.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Erfasst den zugrunde liegenden `*mut`-Zeiger.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Gibt einen gemeinsamen Verweis auf den Wert zurück.Wenn der Wert möglicherweise nicht initialisiert ist, muss stattdessen [`as_uninit_ref`] verwendet werden.
    ///
    /// Für das veränderbare Gegenstück siehe [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass alle der folgenden Bedingungen erfüllt sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Der Zeiger muss auf eine initialisierte Instanz von `T` zeigen.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///
    ///   Insbesondere darf für die Dauer dieser Lebensdauer der Speicher, auf den der Zeiger zeigt, nicht mutiert werden (außer innerhalb von `UnsafeCell`).
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    /// (Der Teil über die Initialisierung ist noch nicht vollständig entschieden, aber bis dahin besteht der einzig sichere Ansatz darin, sicherzustellen, dass sie tatsächlich initialisiert werden.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine Referenz.
        unsafe { &*self.as_ptr() }
    }

    /// Gibt einen eindeutigen Verweis auf den Wert zurück.Wenn der Wert möglicherweise nicht initialisiert ist, muss stattdessen [`as_uninit_mut`] verwendet werden.
    ///
    /// Für das gemeinsam genutzte Gegenstück siehe [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass alle der folgenden Bedingungen erfüllt sind:
    ///
    /// * Der Zeiger muss richtig ausgerichtet sein.
    ///
    /// * Es muss "dereferencable" im in [the module documentation] definierten Sinne sein.
    ///
    /// * Der Zeiger muss auf eine initialisierte Instanz von `T` zeigen.
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///
    ///   Insbesondere darf für die Dauer dieser Lebensdauer auf den Speicher, auf den der Zeiger zeigt, nicht über einen anderen Zeiger zugegriffen (gelesen oder geschrieben) werden.
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    /// (Der Teil über die Initialisierung ist noch nicht vollständig entschieden, aber bis dahin besteht der einzig sichere Ansatz darin, sicherzustellen, dass sie tatsächlich initialisiert werden.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` alle Anforderungen erfüllt
        // Anforderungen an eine veränderbare Referenz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Wirkt auf einen Zeiger eines anderen Typs.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SICHERHEIT: `self` ist ein `NonNull`-Zeiger, der notwendigerweise nicht null ist
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Erstellt aus einem dünnen Zeiger und einer Länge ein Nicht-Null-Roh-Slice.
    ///
    /// Das `len`-Argument ist die Anzahl der **Elemente**, nicht die Anzahl der Bytes.
    ///
    /// Diese Funktion ist sicher, aber die Dereferenzierung des Rückgabewerts ist nicht sicher.
    /// Informationen zu den Sicherheitsanforderungen für Slices finden Sie in der Dokumentation zu [`slice::from_raw_parts`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // Erstellen Sie einen Slice-Zeiger, wenn Sie mit einem Zeiger auf das erste Element beginnen
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Beachten Sie, dass dieses Beispiel eine Verwendung dieser Methode künstlich demonstriert, aber `let Slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SICHERHEIT: `data` ist ein `NonNull`-Zeiger, der notwendigerweise nicht null ist
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Gibt die Länge eines Roh-Slice ungleich Null zurück.
    ///
    /// Der zurückgegebene Wert ist die Anzahl der **Elemente**, nicht die Anzahl der Bytes.
    ///
    /// Diese Funktion ist sicher, auch wenn das Nicht-Null-Roh-Slice nicht auf ein Slice dereferenziert werden kann, da der Zeiger keine gültige Adresse hat.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Gibt einen Nicht-Null-Zeiger auf den Puffer des Slice zurück.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SICHERHEIT: Wir wissen, dass `self` nicht null ist.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Gibt einen Rohzeiger auf den Puffer des Slice zurück.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Gibt einen gemeinsamen Verweis auf ein Segment möglicherweise nicht initialisierter Werte zurück.Im Gegensatz zu [`as_ref`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das veränderbare Gegenstück siehe [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass alle der folgenden Bedingungen erfüllt sind:
    ///
    /// * Der Zeiger muss [valid] für Lesevorgänge für `ptr.len() * mem::size_of::<T>()` viele Bytes sein und muss richtig ausgerichtet sein.Dies bedeutet insbesondere:
    ///
    ///     * Der gesamte Speicherbereich dieses Slice muss in einem einzelnen zugewiesenen Objekt enthalten sein!
    ///       Slices können sich niemals über mehrere zugewiesene Objekte erstrecken.
    ///
    ///     * Der Zeiger muss auch für Slices mit der Länge Null ausgerichtet sein.
    ///     Ein Grund dafür ist, dass Optimierungen des Enum-Layouts davon abhängen können, dass Referenzen (einschließlich Slices beliebiger Länge) ausgerichtet und nicht null sind, um sie von anderen Daten zu unterscheiden.
    ///
    ///     Mit [`NonNull::dangling()`] können Sie einen Zeiger erhalten, der als `data` für Slices mit der Länge Null verwendet werden kann.
    ///
    /// * Die Gesamtgröße `ptr.len() * mem::size_of::<T>()` des Slice darf nicht größer als `isize::MAX` sein.
    ///   Siehe die Sicherheitsdokumentation von [`pointer::offset`].
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///   Insbesondere darf für die Dauer dieser Lebensdauer der Speicher, auf den der Zeiger zeigt, nicht mutiert werden (außer innerhalb von `UnsafeCell`).
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// Siehe auch [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `as_uninit_slice` einhalten.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Gibt einen eindeutigen Verweis auf ein Segment möglicherweise nicht initialisierter Werte zurück.Im Gegensatz zu [`as_mut`] muss der Wert hierfür nicht initialisiert werden.
    ///
    /// Für das gemeinsam genutzte Gegenstück siehe [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Wenn Sie diese Methode aufrufen, müssen Sie sicherstellen, dass alle der folgenden Bedingungen erfüllt sind:
    ///
    /// * Der Zeiger muss [valid] für Lese-und Schreibvorgänge für `ptr.len() * mem::size_of::<T>()` viele Bytes sein und muss richtig ausgerichtet sein.Dies bedeutet insbesondere:
    ///
    ///     * Der gesamte Speicherbereich dieses Slice muss in einem einzelnen zugewiesenen Objekt enthalten sein!
    ///       Slices können sich niemals über mehrere zugewiesene Objekte erstrecken.
    ///
    ///     * Der Zeiger muss auch für Slices mit der Länge Null ausgerichtet sein.
    ///     Ein Grund dafür ist, dass Optimierungen des Enum-Layouts davon abhängen können, dass Referenzen (einschließlich Slices beliebiger Länge) ausgerichtet und nicht null sind, um sie von anderen Daten zu unterscheiden.
    ///
    ///     Mit [`NonNull::dangling()`] können Sie einen Zeiger erhalten, der als `data` für Slices mit der Länge Null verwendet werden kann.
    ///
    /// * Die Gesamtgröße `ptr.len() * mem::size_of::<T>()` des Slice darf nicht größer als `isize::MAX` sein.
    ///   Siehe die Sicherheitsdokumentation von [`pointer::offset`].
    ///
    /// * Sie müssen die Aliasing-Regeln von Rust durchsetzen, da die zurückgegebene Lebensdauer `'a` willkürlich ausgewählt wird und nicht unbedingt die tatsächliche Lebensdauer der Daten widerspiegelt.
    ///   Insbesondere darf für die Dauer dieser Lebensdauer auf den Speicher, auf den der Zeiger zeigt, nicht über einen anderen Zeiger zugegriffen (gelesen oder geschrieben) werden.
    ///
    /// Dies gilt auch dann, wenn das Ergebnis dieser Methode nicht verwendet wird!
    ///
    /// Siehe auch [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dies ist sicher, da `memory` für Lese-und Schreibvorgänge für `memory.len()` viele Bytes gültig ist.
    /// // Beachten Sie, dass das Aufrufen von `memory.as_mut()` hier nicht zulässig ist, da der Inhalt möglicherweise nicht initialisiert ist.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `as_uninit_slice_mut` einhalten.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Gibt einen Rohzeiger auf ein Element oder eine Unterscheibe zurück, ohne die Grenzen zu überprüfen.
    ///
    /// Das Aufrufen dieser Methode mit einem Out-of-Bound-Index oder wenn `self` nicht dereferenzierbar ist, ist *[undefiniertes Verhalten]*, auch wenn der resultierende Zeiger nicht verwendet wird.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SICHERHEIT: Der Anrufer stellt sicher, dass `self` dereferenzierbar ist und `index` eingeholt wird.
        // Folglich kann der resultierende Zeiger nicht NULL sein.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SICHERHEIT: Ein eindeutiger Zeiger kann nicht null sein, daher die Bedingungen für
        // new_unchecked() respektiert werden.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SICHERHEIT: Eine veränderbare Referenz kann nicht null sein.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SICHERHEIT: Eine Referenz kann nicht null sein, daher die Bedingungen für
        // new_unchecked() respektiert werden.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}