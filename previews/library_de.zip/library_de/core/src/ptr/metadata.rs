#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Stellt den Zeiger-Metadatentyp eines beliebigen Typs bereit, auf den verwiesen wird.
///
/// # Zeiger-Metadaten
///
/// Rohe Zeigertypen und Referenztypen in Rust bestehen aus zwei Teilen:
/// Ein Datenzeiger, der die Speicheradresse des Werts und einige Metadaten enthält.
///
/// Für statisch große Typen (die `Sized` traits implementieren) sowie für `extern`-Typen werden Zeiger als "dünn" bezeichnet: Metadaten haben die Größe Null und der Typ ist `()`.
///
///
/// Zeiger auf [dynamically-sized types][dst] werden als "breit" oder "fett" bezeichnet. Sie haben Metadaten ungleich Null:
///
/// * Bei Strukturen, deren letztes Feld eine Sommerzeit ist, sind Metadaten die Metadaten für das letzte Feld
/// * Für den `str`-Typ sind Metadaten die Länge in Bytes als `usize`
/// * Bei Slice-Typen wie `[T]` sind Metadaten die Länge in Elementen als `usize`
/// * Für trait-Objekte wie `dyn SomeTrait` sind die Metadaten [`DynMetadata<Self>`][DynMetadata] (z. B. `DynMetadata<dyn SomeTrait>`).
///
/// In future kann die Sprache Rust neue Arten von Typen erhalten, die unterschiedliche Zeigermetadaten haben.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Der `Pointee` trait
///
/// Der Punkt dieses trait ist der `Metadata`-zugeordnete Typ, der wie oben beschrieben `()` oder `usize` oder `DynMetadata<_>` ist.
/// Es wird automatisch für jeden Typ implementiert.
/// Es kann davon ausgegangen werden, dass es in einem generischen Kontext implementiert ist, auch ohne eine entsprechende Grenze.
///
/// # Usage
///
/// Rohzeiger können mit ihrer [`to_raw_parts`]-Methode in Datenadressen-und Metadatenkomponenten zerlegt werden.
///
/// Alternativ können Metadaten allein mit der [`metadata`]-Funktion extrahiert werden.
/// Eine Referenz kann an [`metadata`] übergeben und implizit erzwungen werden.
///
/// Ein (possibly-wide)-Zeiger kann aus seiner Adresse und seinen Metadaten mit [`from_raw_parts`] oder [`from_raw_parts_mut`] wieder zusammengesetzt werden.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Der Typ für Metadaten in Zeigern und Verweisen auf `Self`.
    #[lang = "metadata_type"]
    // NOTE: Behalten Sie trait bounds in `static_assert_expected_bounds_for_metadata` bei
    //
    // in `library/core/src/ptr/metadata.rs` synchron mit denen hier:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Zeiger auf Typen, die diesen trait-Alias implementieren, sind "dünn".
///
/// Dies umfasst statisch dimensionierte Typen und `extern`-Typen.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: Stabilisieren Sie dies nicht, bevor trait-Aliase in der Sprache stabil sind?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrahieren Sie die Metadatenkomponente eines Zeigers.
///
/// Werte vom Typ `*mut T`, `&T` oder `&mut T` können direkt an diese Funktion übergeben werden, da sie implizit an `* const T` erzwingen.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SICHERHEIT: Der Zugriff auf den Wert über die `PtrRepr`-Union ist sicher, da * const T.
    // und PtrComponents<T>haben die gleichen Speicherlayouts.
    // Nur std kann diese Garantie übernehmen.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Bildet einen (possibly-wide)-Rohzeiger aus einer Datenadresse und Metadaten.
///
/// Diese Funktion ist sicher, aber der zurückgegebene Zeiger ist nicht unbedingt sicher zu dereferenzieren.
/// Informationen zu den Slices finden Sie in der Dokumentation zu [`slice::from_raw_parts`].
/// Bei trait-Objekten müssen die Metadaten von einem Zeiger auf denselben zugrunde liegenden gelöschten Typ stammen.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SICHERHEIT: Der Zugriff auf den Wert über die `PtrRepr`-Union ist sicher, da * const T.
    // und PtrComponents<T>haben die gleichen Speicherlayouts.
    // Nur std kann diese Garantie übernehmen.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Führt die gleiche Funktionalität wie [`from_raw_parts`] aus, außer dass ein roher `*mut`-Zeiger zurückgegeben wird, im Gegensatz zu einem rohen `* const`-Zeiger.
///
///
/// Weitere Informationen finden Sie in der Dokumentation zu [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SICHERHEIT: Der Zugriff auf den Wert über die `PtrRepr`-Union ist sicher, da * const T.
    // und PtrComponents<T>haben die gleichen Speicherlayouts.
    // Nur std kann diese Garantie übernehmen.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manuelles Gerät erforderlich, um `T: Copy`-Bindungen zu vermeiden.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manuelles Gerät erforderlich, um `T: Clone`-Bindungen zu vermeiden.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Die Metadaten für einen `Dyn = dyn SomeTrait` trait-Objekttyp.
///
/// Es ist ein Zeiger auf eine vtable (virtuelle Aufruftabelle), die alle erforderlichen Informationen darstellt, um den in einem trait-Objekt gespeicherten konkreten Typ zu bearbeiten.
/// Die vtable enthält insbesondere:
///
/// * Schriftgröße
/// * Typausrichtung
/// * ein Zeiger auf das `drop_in_place`-Impl des Typs (kann ein No-Op für einfache alte Daten sein)
/// * Zeiger auf alle Methoden zur Implementierung des trait durch den Typ
///
/// Beachten Sie, dass die ersten drei etwas Besonderes sind, da sie zum Zuweisen, Löschen und Freigeben von trait-Objekten erforderlich sind.
///
/// Es ist möglich, diese Struktur mit einem Typparameter zu benennen, der kein `dyn` trait-Objekt (z. B. `DynMetadata<u64>`) ist, aber keinen aussagekräftigen Wert dieser Struktur erhält.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Das gemeinsame Präfix aller vtables.Es folgen Funktionszeiger für trait-Methoden.
///
/// Private Implementierungsdetails von `DynMetadata::size_of` usw.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Gibt die Größe des Typs zurück, der dieser vtable zugeordnet ist.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Gibt die Ausrichtung des Typs zurück, der dieser vtable zugeordnet ist.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Gibt die Größe und Ausrichtung zusammen als `Layout` zurück
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SICHERHEIT: Der Compiler hat diese Tabelle für einen konkreten Rust-Typ ausgegeben, der
        // ist dafür bekannt, ein gültiges Layout zu haben.Gleiche Begründung wie in `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuelle Geräte erforderlich, um `Dyn: $Trait`-Grenzen zu vermeiden.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}