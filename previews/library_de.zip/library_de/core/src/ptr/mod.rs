//! Verwalten Sie den Speicher manuell über unformatierte Zeiger.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Viele Funktionen in diesem Modul verwenden Rohzeiger als Argumente und lesen von ihnen oder schreiben in sie.Damit dies sicher ist, müssen diese Zeiger *gültig* sein.
//! Ob ein Zeiger gültig ist, hängt von der Operation ab, für die er verwendet wird (Lesen oder Schreiben), und von der Ausdehnung des Speichers, auf den zugegriffen wird (dh wie viele Bytes read/written sind).
//! Die meisten Funktionen verwenden `*mut T` und `* const T`, um nur auf einen einzelnen Wert zuzugreifen. In diesem Fall wird in der Dokumentation die Größe weggelassen und implizit davon ausgegangen, dass es sich um `size_of::<T>()`-Bytes handelt.
//!
//! Die genauen Gültigkeitsregeln sind noch nicht festgelegt.Die Garantien, die an dieser Stelle gegeben werden, sind sehr gering:
//!
//! * Ein [null]-Zeiger ist *nie* gültig, auch nicht für Zugriffe auf [size zero][zst].
//! * Damit ein Zeiger gültig ist, ist es notwendig, aber nicht immer ausreichend, dass der Zeiger *dereferenzierbar* ist: Der Speicherbereich der angegebenen Größe, beginnend mit dem Zeiger, muss alle innerhalb der Grenzen eines einzelnen zugewiesenen Objekts liegen.
//!
//! Beachten Sie, dass in Rust jede (stack-allocated)-Variable als separates zugewiesenes Objekt betrachtet wird.
//! * Selbst für Operationen von [size zero][zst] darf der Zeiger nicht auf den freigegebenen Speicher zeigen, dh die Freigabe macht Zeiger selbst für Operationen mit der Größe Null ungültig.
//! Das Umwandeln einer Ganzzahl *Literal* ungleich Null in einen Zeiger gilt jedoch für Zugriffe mit der Größe Null, selbst wenn an dieser Adresse Speicher vorhanden ist und die Zuordnung aufgehoben wird.
//! Dies entspricht dem Schreiben eines eigenen Allokators: Das Zuweisen von Objekten mit der Größe Null ist nicht sehr schwierig.
//! Der kanonische Weg, um einen Zeiger zu erhalten, der für Zugriffe mit der Größe Null gültig ist, ist [`NonNull::dangling`].
//! * Alle Zugriffe, die von Funktionen in diesem Modul ausgeführt werden, sind *nicht atomar* im Sinne von [atomic operations], das zum Synchronisieren zwischen Threads verwendet wird.
//! Dies bedeutet, dass es ein undefiniertes Verhalten ist, zwei gleichzeitige Zugriffe von verschiedenen Threads auf denselben Speicherort durchzuführen, es sei denn, beide Zugriffe werden nur aus dem Speicher gelesen.
//! Beachten Sie, dass dies explizit [`read_volatile`] und [`write_volatile`] umfasst: Flüchtige Zugriffe können nicht für die Synchronisierung zwischen Threads verwendet werden.
//! * Das Ergebnis des Umsetzens einer Referenz auf einen Zeiger ist gültig, solange das zugrunde liegende Objekt aktiv ist und keine Referenz (nur Rohzeiger) verwendet wird, um auf denselben Speicher zuzugreifen.
//!
//! Diese Axiome reichen zusammen mit der sorgfältigen Verwendung von [`offset`] für die Zeigerarithmetik aus, um viele nützliche Dinge in unsicherem Code korrekt zu implementieren.
//! Stärkere Garantien werden schließlich gegeben, wenn die [aliasing]-Regeln festgelegt werden.
//! Weitere Informationen finden Sie im [book] sowie im Abschnitt in der Referenz zu [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Gültige Rohzeiger wie oben definiert sind nicht unbedingt richtig ausgerichtet (wobei die "proper"-Ausrichtung durch den Zeigertyp definiert ist, dh `*const T` muss an `mem::align_of::<T>()` ausgerichtet sein).
//! Die meisten Funktionen erfordern jedoch, dass ihre Argumente richtig ausgerichtet sind, und geben diese Anforderung in ihrer Dokumentation ausdrücklich an.
//! Bemerkenswerte Ausnahmen sind [`read_unaligned`] und [`write_unaligned`].
//!
//! Wenn eine Funktion eine ordnungsgemäße Ausrichtung erfordert, geschieht dies auch dann, wenn der Zugriff die Größe 0 hat, dh auch wenn der Speicher nicht tatsächlich berührt wird.Erwägen Sie in solchen Fällen die Verwendung von [`NonNull::dangling`].
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Führt den Destruktor (falls vorhanden) des angegebenen Werts aus.
///
/// Dies entspricht semantisch dem Aufrufen von [`ptr::read`] und dem Verwerfen des Ergebnisses, hat jedoch die folgenden Vorteile:
///
/// * Es ist *erforderlich*, `drop_in_place` zu verwenden, um nicht dimensionierte Typen wie trait-Objekte zu löschen, da sie nicht auf dem Stapel ausgelesen und normal gelöscht werden können.
///
/// * Für den Optimierer ist es freundlicher, dies über [`ptr::read`] zu tun, wenn manuell zugewiesener Speicher gelöscht wird (z. B. in den Implementierungen von `Box`/`Rc`/`Vec`), da der Compiler nicht beweisen muss, dass es einwandfrei ist, um die Kopie zu löschen.
///
///
/// * Es kann verwendet werden, um [pinned]-Daten zu löschen, wenn `T` nicht `repr(packed)` ist (angeheftete Daten dürfen nicht verschoben werden, bevor sie gelöscht werden).
///
/// Nicht ausgerichtete Werte können nicht an Ort und Stelle gelöscht werden. Sie müssen zuerst mit [`ptr::read_unaligned`] an eine ausgerichtete Position kopiert werden.Bei gepackten Strukturen wird diese Verschiebung automatisch vom Compiler ausgeführt.
/// Dies bedeutet, dass die Felder gepackter Strukturen nicht an Ort und Stelle gelöscht werden.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `to_drop` muss sowohl für Lese-als auch für Schreibvorgänge [valid] sein.
///
/// * `to_drop` muss richtig ausgerichtet sein.
///
/// * Der Wert, auf den `to_drop` zeigt, muss für das Löschen gültig sein. Dies kann bedeuten, dass zusätzliche Invarianten beibehalten werden müssen. Dies ist typabhängig.
///
/// Wenn `T` nicht [`Copy`] ist, kann die Verwendung des Verweiswerts nach dem Aufruf von `drop_in_place` zu undefiniertem Verhalten führen.Beachten Sie, dass `*to_drop = foo` als Verwendung zählt, da dadurch der Wert erneut gelöscht wird.
/// [`write()`] kann zum Überschreiben von Daten verwendet werden, ohne dass diese gelöscht werden.
///
/// Beachten Sie, dass der Zeiger, selbst wenn `T` die Größe `0` hat, nicht NULL sein und ordnungsgemäß ausgerichtet sein muss.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Entfernen Sie das letzte Element manuell aus einem vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Holen Sie sich einen Rohzeiger auf das letzte Element in `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Kürzen Sie `v`, um zu verhindern, dass der letzte Gegenstand fallen gelassen wird.
///     // Wir tun dies zuerst, um Probleme zu vermeiden, wenn der `drop_in_place` unter panics liegt.
///     v.set_len(1);
///     // Ohne einen Anruf `drop_in_place` würde das letzte Element niemals gelöscht und der von ihm verwaltete Speicher würde verloren gehen.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Stellen Sie sicher, dass das letzte Element gelöscht wurde.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Beachten Sie, dass der Compiler diese Kopie automatisch ausführt, wenn gepackte Strukturen gelöscht werden. Das heißt, Sie müssen sich normalerweise nicht um solche Probleme kümmern, es sei denn, Sie rufen `drop_in_place` manuell auf.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code spielt hier keine Rolle, dies wird durch den echten Tropfenkleber des Compilers ersetzt.
    //

    // SICHERHEIT: siehe Kommentar oben
    unsafe { drop_in_place(to_drop) }
}

/// Erstellt einen Null-Rohzeiger.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Erstellt einen null veränderlichen Rohzeiger.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manuelles Gerät erforderlich, um `T: Clone`-Bindungen zu vermeiden.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manuelles Gerät erforderlich, um `T: Copy`-Bindungen zu vermeiden.
impl<T> Copy for FatPtr<T> {}

/// Bildet aus einem Zeiger und einer Länge eine rohe Scheibe.
///
/// Das `len`-Argument ist die Anzahl der **Elemente**, nicht die Anzahl der Bytes.
///
/// Diese Funktion ist sicher, aber die tatsächliche Verwendung des Rückgabewerts ist unsicher.
/// Informationen zu den Sicherheitsanforderungen für Slices finden Sie in der Dokumentation zu [`slice::from_raw_parts`].
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // Erstellen Sie einen Slice-Zeiger, wenn Sie mit einem Zeiger auf das erste Element beginnen
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SICHERHEIT: Der Zugriff auf den Wert über die `Repr`-Union ist seit * const [T] sicher
        //
        // und FatPtr haben die gleichen Speicherlayouts.Nur std kann diese Garantie übernehmen.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Führt die gleiche Funktionalität wie [`slice_from_raw_parts`] aus, außer dass ein unveränderliches Roh-Slice zurückgegeben wird, im Gegensatz zu einem unveränderlichen Roh-Slice.
///
///
/// Weitere Informationen finden Sie in der Dokumentation zu [`slice_from_raw_parts`].
///
/// Diese Funktion ist sicher, aber die tatsächliche Verwendung des Rückgabewerts ist unsicher.
/// In der Dokumentation zu [`slice::from_raw_parts_mut`] finden Sie Informationen zu den Anforderungen an die Slice-Sicherheit.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // Weisen Sie einem Index im Slice einen Wert zu
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SICHERHEIT: Der Zugriff auf den Wert über die `Repr`-Union ist seit * mut [T] sicher
        // und FatPtr haben die gleichen Speicherlayouts
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Vertauscht die Werte an zwei veränderlichen Stellen desselben Typs, ohne sie zu deinitialisieren.
///
/// Für die folgenden zwei Ausnahmen entspricht diese Funktion jedoch semantisch [`mem::swap`]:
///
///
/// * Es werden Rohzeiger anstelle von Referenzen verwendet.
/// Wenn Referenzen verfügbar sind, sollte [`mem::swap`] bevorzugt werden.
///
/// * Die beiden Werte, auf die gezeigt wird, können sich überschneiden.
/// Wenn sich die Werte überschneiden, wird der überlappende Speicherbereich von `x` verwendet.
/// Dies wird im zweiten Beispiel unten gezeigt.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * Sowohl `x` als auch `y` müssen sowohl für Lese-als auch für Schreibvorgänge [valid] sein.
///
/// * Sowohl `x` als auch `y` müssen richtig ausgerichtet sein.
///
/// Beachten Sie, dass selbst wenn `T` die Größe `0` hat, die Zeiger nicht NULL sein und ordnungsgemäß ausgerichtet sein müssen.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Vertauschen von zwei nicht überlappenden Regionen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // Das ist `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // Das ist `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Vertauschen von zwei überlappenden Regionen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // Das ist `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // Das ist `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Die Indizes `1..3` des Slice überlappen sich zwischen `x` und `y`.
///     // Angemessene Ergebnisse wären für sie `[2, 3]`, so dass die Indizes `0..3` `[1, 2, 3]` sind (passend zu `y` vor `swap`);oder damit sie `[0, 1]` sind, so dass die Indizes `1..4` `[0, 1, 2]` sind (passend zu `x` vor `swap`).
/////
///     // Diese Implementierung ist definiert, um die letztere Wahl zu treffen.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Geben Sie uns etwas Platz zum Arbeiten.
    // Wir müssen uns keine Sorgen um Tropfen machen: `MaybeUninit` macht nichts, wenn es fallen gelassen wird.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Führen Sie den Swap SICHERHEIT durch: Der Anrufer muss sicherstellen, dass `x` und `y` für Schreibvorgänge gültig und richtig ausgerichtet sind.
    // `tmp` kann weder `x` noch `y` überlappen, da `tmp` nur als separat zugewiesenes Objekt auf dem Stapel zugewiesen wurde.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` und `y` können sich überlappen
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Vertauscht `count * size_of::<T>()`-Bytes zwischen den beiden Speicherbereichen, beginnend bei `x` und `y`.
/// Die beiden Regionen dürfen sich *nicht* überlappen.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * Sowohl `x` als auch `y` müssen [valid] für Lese-und Schreibvorgänge von `count sein *
///   Größe von: :<T>() `Bytes.
///
/// * Sowohl `x` als auch `y` müssen richtig ausgerichtet sein.
///
/// * Der Speicherbereich, der bei `x` mit einer Größe von `count beginnt *
///   Größe von: :<T>() `Bytes dürfen *nicht* mit dem Speicherbereich überlappen, der bei `y` mit derselben Größe beginnt.
///
/// Beachten Sie, dass auch wenn die effektiv kopierte Größe (`count * size_of: :<T>()`) ist `0`, die Zeiger müssen nicht NULL sein und richtig ausgerichtet sein.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SICHERHEIT: Der Anrufer muss garantieren, dass `x` und `y` sind
    // gültig für Schreibvorgänge und richtig ausgerichtet.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Bei Typen, die kleiner als die unten stehende Blockoptimierung sind, tauschen Sie einfach direkt aus, um eine Pessimierung des Codegens zu vermeiden.
    //
    if mem::size_of::<T>() < 32 {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `x` und `y` gültig sind
        // für Schreibvorgänge, richtig ausgerichtet und nicht überlappend.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `swap_nonoverlapping` einhalten.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Der Ansatz hier besteht darin, simd zu verwenden, um x&y effizient zu tauschen.
    // Tests haben ergeben, dass das gleichzeitige Austauschen von 32 oder 64 Byte für Intel Haswell E-Prozessoren am effizientesten ist.
    // LLVM kann besser optimieren, wenn wir einer Struktur eine #[repr(simd)] geben, auch wenn wir diese Struktur nicht direkt verwenden.
    //
    //
    // FIXME repr(simd) auf Emscripten und Redox kaputt
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Durchlaufen Sie x&y und kopieren Sie sie jeweils `Block`. Der Optimierer sollte die Schleife für die meisten Typen NB vollständig abrollen
    // Wir können keine for-Schleife verwenden, da das `range`-Impl `mem::swap` rekursiv aufruft
    //
    let mut i = 0;
    while i + block_size <= len {
        // Erstellen Sie einen nicht initialisierten Speicher als Arbeitsbereich. Wenn Sie hier `t` deklarieren, wird vermieden, dass der Stapel ausgerichtet wird, wenn diese Schleife nicht verwendet wird
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SICHERHEIT: Als `i < len` und als Anrufer muss garantiert werden, dass `x` und `y` gültig sind
        // Für `len`-Bytes müssen `x + i` und `y + i` gültige Adressen sein, die den Sicherheitsvertrag für `add` erfüllen.
        //
        // Außerdem muss der Anrufer sicherstellen, dass `x` und `y` für Schreibvorgänge gültig sind, ordnungsgemäß ausgerichtet und nicht überlappend, wodurch der Sicherheitsvertrag für `copy_nonoverlapping` erfüllt wird.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Tauschen Sie einen Byteblock von x&y aus und verwenden Sie t als temporären Puffer. Dies sollte, sofern verfügbar, für effiziente SIMD-Operationen optimiert werden
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Tauschen Sie alle verbleibenden Bytes aus
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SICHERHEIT: siehe vorherigen Sicherheitskommentar.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Verschiebt `src` in das spitze `dst` und gibt den vorherigen `dst`-Wert zurück.
///
/// Keiner der Werte wird gelöscht.
///
/// Diese Funktion ist semantisch äquivalent zu [`mem::replace`], außer dass sie mit Rohzeigern anstelle von Referenzen arbeitet.
/// Wenn Referenzen verfügbar sind, sollte [`mem::replace`] bevorzugt werden.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `dst` muss sowohl für Lese-als auch für Schreibvorgänge [valid] sein.
///
/// * `dst` muss richtig ausgerichtet sein.
///
/// * `dst` muss auf einen ordnungsgemäß initialisierten Wert vom Typ `T` verweisen.
///
/// Beachten Sie, dass der Zeiger, selbst wenn `T` die Größe `0` hat, nicht NULL sein und ordnungsgemäß ausgerichtet sein muss.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` hätte den gleichen Effekt, ohne den unsicheren Block zu benötigen.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SICHERHEIT: Der Anrufer muss garantieren, dass `dst` gültig ist
    // Wird in eine veränderbare Referenz umgewandelt (gültig für Schreibvorgänge, ausgerichtet, initialisiert) und kann `src` nicht überlappen, da `dst` auf ein bestimmtes zugewiesenes Objekt zeigen muss.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kann sich nicht überlappen
    }
    src
}

/// Liest den Wert von `src`, ohne ihn zu verschieben.Dadurch bleibt der Speicher in `src` unverändert.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `src` muss für Lesevorgänge [valid] sein.
///
/// * `src` muss richtig ausgerichtet sein.Verwenden Sie [`read_unaligned`], wenn dies nicht der Fall ist.
///
/// * `src` muss auf einen ordnungsgemäß initialisierten Wert vom Typ `T` verweisen.
///
/// Beachten Sie, dass der Zeiger, selbst wenn `T` die Größe `0` hat, nicht NULL sein und ordnungsgemäß ausgerichtet sein muss.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuelles Implementieren von [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Erstellen Sie eine bitweise Kopie des Werts bei `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Das Beenden an dieser Stelle (entweder durch explizites Zurückgeben oder durch Aufrufen einer Funktion, die panics enthält) würde dazu führen, dass der Wert in `tmp` gelöscht wird, während derselbe Wert weiterhin von `a` referenziert wird.
///         // Dies kann undefiniertes Verhalten auslösen, wenn `T` nicht `Copy` ist.
/////
/////
///
///         // Erstellen Sie eine bitweise Kopie des Werts bei `b` in `a`.
///         // Dies ist sicher, da veränderbare Referenzen keinen Alias haben können.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Wie oben kann das Beenden hier ein undefiniertes Verhalten auslösen, da `a` und `b` auf denselben Wert verweisen.
/////
///
///         // Verschieben Sie `tmp` in `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` wurde verschoben (`write` übernimmt das Eigentum an seinem zweiten Argument), daher wird hier nichts implizit gelöscht.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Eigentum am zurückgegebenen Wert
///
/// `read` Erstellt eine bitweise Kopie von `T`, unabhängig davon, ob `T` [`Copy`] ist.
/// Wenn `T` nicht [`Copy`] ist, kann die Verwendung des zurückgegebenen Werts und des Werts bei `*src` die Speichersicherheit verletzen.
/// Beachten Sie, dass die Zuweisung zu `*src` als Verwendung gilt, da versucht wird, den Wert bei `* src` zu löschen.
///
/// [`write()`] kann zum Überschreiben von Daten verwendet werden, ohne dass diese gelöscht werden.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` zeigt jetzt auf denselben zugrunde liegenden Speicher wie `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Durch die Zuweisung zu `s2` wird der ursprüngliche Wert gelöscht.
///     // Über diesen Punkt hinaus darf `s` nicht mehr verwendet werden, da der zugrunde liegende Speicher freigegeben wurde.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Das Zuweisen zu `s` würde dazu führen, dass der alte Wert erneut gelöscht wird, was zu einem undefinierten Verhalten führt.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` kann verwendet werden, um einen Wert zu überschreiben, ohne ihn zu löschen.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SICHERHEIT: Der Anrufer muss garantieren, dass `src` für Lesevorgänge gültig ist.
    // `src` `tmp` kann nicht überlappen, da `tmp` gerade als separates zugewiesenes Objekt auf dem Stapel zugewiesen wurde.
    //
    //
    // Da wir gerade einen gültigen Wert in `tmp` geschrieben haben, wird garantiert, dass er ordnungsgemäß initialisiert wird.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Liest den Wert von `src`, ohne ihn zu verschieben.Dadurch bleibt der Speicher in `src` unverändert.
///
/// Im Gegensatz zu [`read`] arbeitet `read_unaligned` mit nicht ausgerichteten Zeigern.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `src` muss für Lesevorgänge [valid] sein.
///
/// * `src` muss auf einen ordnungsgemäß initialisierten Wert vom Typ `T` verweisen.
///
/// Wie [`read`] erstellt `read_unaligned` eine bitweise Kopie von `T`, unabhängig davon, ob `T` [`Copy`] ist.
/// Wenn `T` nicht [`Copy`] ist, kann [violate memory safety][read-ownership] sowohl den zurückgegebenen Wert als auch den Wert bei `*src` verwenden.
///
/// Beachten Sie, dass der Zeiger nicht NULL sein darf, auch wenn `T` die Größe `0` hat.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Auf `packed`-Strukturen
///
/// Es ist derzeit unmöglich, Rohzeiger auf nicht ausgerichtete Felder einer gepackten Struktur zu erstellen.
///
/// Beim Versuch, einen Rohzeiger auf ein `unaligned`-Strukturfeld mit einem Ausdruck wie `&packed.unaligned as *const FieldType` zu erstellen, wird eine nicht ausgerichtete Zwischenreferenz erstellt, bevor dieser in einen Rohzeiger konvertiert wird.
///
/// Dass diese Referenz temporär ist und sofort umgewandelt wird, spielt keine Rolle, da der Compiler immer erwartet, dass die Referenzen richtig ausgerichtet sind.
/// Infolgedessen führt die Verwendung von `&packed.unaligned as *const FieldType` zu einem sofortigen* undefinierten Verhalten * in Ihrem Programm.
///
/// Ein Beispiel dafür, was nicht zu tun ist und wie dies mit `read_unaligned` zusammenhängt, ist:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hier versuchen wir, die Adresse einer 32-Bit-Ganzzahl zu übernehmen, die nicht ausgerichtet ist.
///     let unaligned =
///         // Hier wird eine temporäre nicht ausgerichtete Referenz erstellt, die zu einem undefinierten Verhalten führt, unabhängig davon, ob die Referenz verwendet wird oder nicht.
/////
///         &packed.unaligned
///         // Das Casting auf einen rohen Zeiger hilft nicht weiter.Der Fehler ist bereits passiert.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Der direkte Zugriff auf nicht ausgerichtete Felder mit z. B. `packed.unaligned` ist jedoch sicher.
///
///
///
///
///
///
// FIXME: Aktualisieren Sie die Dokumente basierend auf dem Ergebnis von RFC #2582 und Freunden.
/// # Examples
///
/// Lesen Sie einen Usize-Wert aus einem Bytepuffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SICHERHEIT: Der Anrufer muss garantieren, dass `src` für Lesevorgänge gültig ist.
    // `src` `tmp` kann nicht überlappen, da `tmp` gerade als separates zugewiesenes Objekt auf dem Stapel zugewiesen wurde.
    //
    //
    // Da wir gerade einen gültigen Wert in `tmp` geschrieben haben, wird garantiert, dass er ordnungsgemäß initialisiert wird.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Überschreibt einen Speicherort mit dem angegebenen Wert, ohne den alten Wert zu lesen oder zu löschen.
///
/// `write` löscht den Inhalt von `dst` nicht.
/// Dies ist sicher, kann jedoch zu Zuordnungen oder Ressourcen führen. Daher sollte darauf geachtet werden, dass ein Objekt, das fallengelassen werden soll, nicht überschrieben wird.
///
///
/// Außerdem wird `src` nicht gelöscht.Semantisch wird `src` an die Stelle verschoben, auf die `dst` zeigt.
///
/// Dies ist geeignet, um nicht initialisierten Speicher zu initialisieren oder Speicher zu überschreiben, von dem zuvor [`read`] stammt.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `dst` muss für Schreibvorgänge [valid] sein.
///
/// * `dst` muss richtig ausgerichtet sein.Verwenden Sie [`write_unaligned`], wenn dies nicht der Fall ist.
///
/// Beachten Sie, dass der Zeiger, selbst wenn `T` die Größe `0` hat, nicht NULL sein und ordnungsgemäß ausgerichtet sein muss.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuelles Implementieren von [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Erstellen Sie eine bitweise Kopie des Werts bei `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Das Beenden an dieser Stelle (entweder durch explizites Zurückgeben oder durch Aufrufen einer Funktion, die panics enthält) würde dazu führen, dass der Wert in `tmp` gelöscht wird, während derselbe Wert weiterhin von `a` referenziert wird.
///         // Dies kann undefiniertes Verhalten auslösen, wenn `T` nicht `Copy` ist.
/////
/////
///
///         // Erstellen Sie eine bitweise Kopie des Werts bei `b` in `a`.
///         // Dies ist sicher, da veränderbare Referenzen keinen Alias haben können.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Wie oben kann das Beenden hier ein undefiniertes Verhalten auslösen, da `a` und `b` auf denselben Wert verweisen.
/////
///
///         // Verschieben Sie `tmp` in `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` wurde verschoben (`write` übernimmt das Eigentum an seinem zweiten Argument), daher wird hier nichts implizit gelöscht.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Wir rufen die Intrinsics direkt auf, um Funktionsaufrufe im generierten Code zu vermeiden, da `intrinsics::copy_nonoverlapping` eine Wrapper-Funktion ist.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SICHERHEIT: Der Anrufer muss garantieren, dass `dst` für Schreibvorgänge gültig ist.
    // `dst` `src` kann nicht überlappen, da der Anrufer veränderlichen Zugriff auf `dst` hat, während `src` dieser Funktion gehört.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Überschreibt einen Speicherort mit dem angegebenen Wert, ohne den alten Wert zu lesen oder zu löschen.
///
/// Im Gegensatz zu [`write()`] ist der Zeiger möglicherweise nicht ausgerichtet.
///
/// `write_unaligned` löscht den Inhalt von `dst` nicht.Dies ist sicher, kann jedoch zu Zuordnungen oder Ressourcen führen. Daher sollte darauf geachtet werden, dass ein Objekt, das fallengelassen werden soll, nicht überschrieben wird.
///
/// Außerdem wird `src` nicht gelöscht.Semantisch wird `src` an die Stelle verschoben, auf die `dst` zeigt.
///
/// Dies ist geeignet, um nicht initialisierten Speicher zu initialisieren oder Speicher zu überschreiben, der zuvor mit [`read_unaligned`] gelesen wurde.
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `dst` muss für Schreibvorgänge [valid] sein.
///
/// Beachten Sie, dass der Zeiger nicht NULL sein darf, auch wenn `T` die Größe `0` hat.
///
/// [valid]: self#safety
///
/// ## Auf `packed`-Strukturen
///
/// Es ist derzeit unmöglich, Rohzeiger auf nicht ausgerichtete Felder einer gepackten Struktur zu erstellen.
///
/// Beim Versuch, einen Rohzeiger auf ein `unaligned`-Strukturfeld mit einem Ausdruck wie `&packed.unaligned as *const FieldType` zu erstellen, wird eine nicht ausgerichtete Zwischenreferenz erstellt, bevor dieser in einen Rohzeiger konvertiert wird.
///
/// Dass diese Referenz temporär ist und sofort umgewandelt wird, spielt keine Rolle, da der Compiler immer erwartet, dass die Referenzen richtig ausgerichtet sind.
/// Infolgedessen führt die Verwendung von `&packed.unaligned as *const FieldType` zu einem sofortigen* undefinierten Verhalten * in Ihrem Programm.
///
/// Ein Beispiel dafür, was nicht zu tun ist und wie dies mit `write_unaligned` zusammenhängt, ist:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hier versuchen wir, die Adresse einer 32-Bit-Ganzzahl zu übernehmen, die nicht ausgerichtet ist.
///     let unaligned =
///         // Hier wird eine temporäre nicht ausgerichtete Referenz erstellt, die zu einem undefinierten Verhalten führt, unabhängig davon, ob die Referenz verwendet wird oder nicht.
/////
///         &mut packed.unaligned
///         // Das Casting auf einen rohen Zeiger hilft nicht weiter.Der Fehler ist bereits passiert.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Der direkte Zugriff auf nicht ausgerichtete Felder mit z. B. `packed.unaligned` ist jedoch sicher.
///
///
///
///
///
///
///
///
///
// FIXME: Aktualisieren Sie die Dokumente basierend auf dem Ergebnis von RFC #2582 und Freunden.
/// # Examples
///
/// Schreiben Sie einen Usize-Wert in einen Byte-Puffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SICHERHEIT: Der Anrufer muss garantieren, dass `dst` für Schreibvorgänge gültig ist.
    // `dst` `src` kann nicht überlappen, da der Anrufer veränderlichen Zugriff auf `dst` hat, während `src` dieser Funktion gehört.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Wir rufen das Intrinsic direkt auf, um Funktionsaufrufe im generierten Code zu vermeiden.
        intrinsics::forget(src);
    }
}

/// Führt einen flüchtigen Lesevorgang des Werts von `src` durch, ohne ihn zu verschieben.Dadurch bleibt der Speicher in `src` unverändert.
///
/// Flüchtige Operationen sollen auf den I/O-Speicher einwirken und werden vom Compiler garantiert nicht über andere flüchtige Operationen hinweg entfernt oder neu angeordnet.
///
/// # Notes
///
/// Rust verfügt derzeit nicht über ein streng und formal definiertes Speichermodell, sodass sich die genaue Semantik dessen, was "volatile" hier bedeutet, im Laufe der Zeit ändern kann.
/// Davon abgesehen wird die Semantik fast immer [C11's definition of volatile][c11] ziemlich ähnlich sein.
///
/// Der Compiler sollte die relative Reihenfolge oder Anzahl der flüchtigen Speicheroperationen nicht ändern.
/// Flüchtige Speicheroperationen für Typen mit der Größe Null (z. B. wenn ein Typ mit der Größe Null an `read_volatile` übergeben wird) sind jedoch Noops und können ignoriert werden.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `src` muss für Lesevorgänge [valid] sein.
///
/// * `src` muss richtig ausgerichtet sein.
///
/// * `src` muss auf einen ordnungsgemäß initialisierten Wert vom Typ `T` verweisen.
///
/// Wie [`read`] erstellt `read_volatile` eine bitweise Kopie von `T`, unabhängig davon, ob `T` [`Copy`] ist.
/// Wenn `T` nicht [`Copy`] ist, kann [violate memory safety][read-ownership] sowohl den zurückgegebenen Wert als auch den Wert bei `*src` verwenden.
/// Das Speichern von Nicht-[`Kopieren`]-Typen im flüchtigen Speicher ist jedoch mit ziemlicher Sicherheit falsch.
///
/// Beachten Sie, dass der Zeiger, selbst wenn `T` die Größe `0` hat, nicht NULL sein und ordnungsgemäß ausgerichtet sein muss.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Genau wie in C hat die Frage, ob eine Operation flüchtig ist, keinerlei Einfluss auf Fragen, die den gleichzeitigen Zugriff von mehreren Threads betreffen.Flüchtige Zugriffe verhalten sich in dieser Hinsicht genau wie nichtatomare Zugriffe.
///
/// Insbesondere ein Wettlauf zwischen einem `read_volatile` und einem Schreibvorgang an denselben Speicherort ist ein undefiniertes Verhalten.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Keine Panik, um die Auswirkungen von Codegen zu verringern.
        abort();
    }
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `volatile_load` einhalten.
    unsafe { intrinsics::volatile_load(src) }
}

/// Führt ein flüchtiges Schreiben eines Speicherorts mit dem angegebenen Wert durch, ohne den alten Wert zu lesen oder zu löschen.
///
/// Flüchtige Operationen sollen auf den I/O-Speicher einwirken und werden vom Compiler garantiert nicht über andere flüchtige Operationen hinweg entfernt oder neu angeordnet.
///
/// `write_volatile` löscht den Inhalt von `dst` nicht.Dies ist sicher, kann jedoch zu Zuordnungen oder Ressourcen führen. Daher sollte darauf geachtet werden, dass ein Objekt, das fallengelassen werden soll, nicht überschrieben wird.
///
/// Außerdem wird `src` nicht gelöscht.Semantisch wird `src` an die Stelle verschoben, auf die `dst` zeigt.
///
/// # Notes
///
/// Rust verfügt derzeit nicht über ein streng und formal definiertes Speichermodell, sodass sich die genaue Semantik dessen, was "volatile" hier bedeutet, im Laufe der Zeit ändern kann.
/// Davon abgesehen wird die Semantik fast immer [C11's definition of volatile][c11] ziemlich ähnlich sein.
///
/// Der Compiler sollte die relative Reihenfolge oder Anzahl der flüchtigen Speicheroperationen nicht ändern.
/// Flüchtige Speicheroperationen für Typen mit der Größe Null (z. B. wenn ein Typ mit der Größe Null an `write_volatile` übergeben wird) sind jedoch Noops und können ignoriert werden.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Das Verhalten ist undefiniert, wenn eine der folgenden Bedingungen verletzt wird:
///
/// * `dst` muss für Schreibvorgänge [valid] sein.
///
/// * `dst` muss richtig ausgerichtet sein.
///
/// Beachten Sie, dass der Zeiger, selbst wenn `T` die Größe `0` hat, nicht NULL sein und ordnungsgemäß ausgerichtet sein muss.
///
/// [valid]: self#safety
///
/// Genau wie in C hat die Frage, ob eine Operation flüchtig ist, keinerlei Einfluss auf Fragen, die den gleichzeitigen Zugriff von mehreren Threads betreffen.Flüchtige Zugriffe verhalten sich in dieser Hinsicht genau wie nichtatomare Zugriffe.
///
/// Insbesondere ein Rennen zwischen einem `write_volatile` und einer anderen Operation (Lesen oder Schreiben) am selben Ort ist ein undefiniertes Verhalten.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Keine Panik, um die Auswirkungen von Codegen zu verringern.
        abort();
    }
    // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `volatile_store` einhalten.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Zeiger `p` ausrichten.
///
/// Berechnen Sie den Versatz (in Bezug auf Elemente des `stride`-Schrittes), der auf den Zeiger `p` angewendet werden muss, damit der Zeiger `p` auf `a` ausgerichtet wird.
///
/// Note: Diese Implementierung wurde sorgfältig auf panic zugeschnitten.Es ist UB dafür zu panic.
/// Die einzige wirkliche Änderung, die hier vorgenommen werden kann, ist die Änderung von `INV_TABLE_MOD_16` und den zugehörigen Konstanten.
///
/// Wenn wir uns jemals dazu entschließen, das Intrinsic mit `a` aufzurufen, das keine Zweierpotenz ist, ist es wahrscheinlich klüger, nur auf eine naive Implementierung umzusteigen, als zu versuchen, dies anzupassen, um dieser Änderung Rechnung zu tragen.
///
///
/// Bei Fragen wenden Sie sich bitte an@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Die direkte Verwendung dieser Intrinsics verbessert das Codegen auf opt-Ebene <=signifikant
    // 1, wobei die Methodenversionen dieser Operationen nicht inline sind.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Berechnen Sie die multiplikative modulare Inverse von `x` modulo `m`.
    ///
    /// Diese Implementierung ist auf `align_offset` zugeschnitten und hat folgende Voraussetzungen:
    ///
    /// * `m` ist eine Zweierpotenz;
    /// * `x < m`; (Wenn `x ≥ m`, übergeben Sie stattdessen `x % m`)
    ///
    /// Die Implementierung dieser Funktion darf nicht panic sein.Je.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikative modulare inverse Tabelle modulo 2⁴=16.
        ///
        /// Beachten Sie, dass diese Tabelle keine Werte enthält, bei denen keine Umkehrung vorhanden ist (dh für `0⁻¹ mod 16`, `2⁻¹ mod 16` usw.).
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, für das der `INV_TABLE_MOD_16` vorgesehen ist.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SICHERHEIT: `m` muss eine Zweierpotenz sein, also nicht Null.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Wir iterieren "up" mit der folgenden Formel:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // bis 2²ⁿ ≥ m.Dann können wir auf unser gewünschtes `m` reduzieren, indem wir das Ergebnis `mod m` nehmen.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Beachten Sie, dass wir hier absichtlich Umbruchoperationen verwenden-die ursprüngliche Formel verwendet z. B. die Subtraktion `mod n`.
                // Es ist völlig in Ordnung, sie stattdessen `mod usize::MAX` zu machen, da wir das Ergebnis `mod n` sowieso am Ende nehmen.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SICHERHEIT: `a` ist eine Zweierpotenz, daher ungleich Null.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case kann einfacher über `-p (mod a)` berechnet werden, verhindert jedoch, dass LLVM Anweisungen wie `lea` auswählen kann.Stattdessen berechnen wir
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // Dies verteilt den Betrieb auf die tragende Person, pessimiert jedoch `and` so weit, dass LLVM die verschiedenen ihm bekannten Optimierungen nutzen kann.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Bereits ausgerichtet.Yay!
        return 0;
    } else if stride == 0 {
        // Wenn der Zeiger nicht ausgerichtet ist und das Element die Größe Null hat, wird der Zeiger niemals von einer Anzahl von Elementen ausgerichtet.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SICHERHEIT: a ist eine Zweierpotenz und daher ungleich Null.Schritt==0 Fall wird oben behandelt.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SICHERHEIT: gcdpow hat eine Obergrenze, die höchstens der Anzahl der Bits in einer Usize entspricht.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SICHERHEIT: gcd ist immer größer oder gleich 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Dieses branch löst die folgende lineare Kongruenzgleichung auf:
        //
        // ` p + so = 0 mod a `
        //
        // `p` Hier ist der Zeigerwert `s`, der Schritt von `T`, der `o`-Versatz in `T`s und `a` die angeforderte Ausrichtung.
        //
        // Mit `g = gcd(a, s)` und der obigen Bedingung, dass `p` auch durch `g` teilbar ist, können wir `a' = a/g`, `s' = s/g`, `p' = p/g` bezeichnen, dann wird dies äquivalent zu:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Der erste Term ist "the relative alignment of `p` to `a`" (geteilt durch `g`), der zweite Term ist "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (wiederum geteilt durch `g`).
        //
        // Die Division durch `g` ist erforderlich, um die Umkehrung gut zu formen, wenn `a` und `s` nicht koprimieren.
        //
        // Darüber hinaus ist das mit dieser Lösung erzeugte Ergebnis nicht "minimal", sodass das Ergebnis `o mod lcm(s, a)` verwendet werden muss.Wir können `lcm(s, a)` durch nur einen `a'` ersetzen.
        //
        //
        //
        //
        //

        // SICHERHEIT: `gcdpow` hat eine Obergrenze, die nicht größer ist als die Anzahl der nachfolgenden 0-Bits in `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SICHERHEIT: `a2` ist ungleich Null.Durch Verschieben von `a` um `gcdpow` kann keines der gesetzten Bits verschoben werden
        // in `a` (von denen es genau eine hat).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SICHERHEIT: `gcdpow` hat eine Obergrenze, die nicht größer ist als die Anzahl der nachfolgenden 0-Bits in `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SICHERHEIT: `gcdpow` hat eine Obergrenze, die nicht größer als die Anzahl der nachfolgenden 0-Bits ist
        // `a`.
        // Darüber hinaus kann die Subtraktion nicht überlaufen, da `a2 = a >> gcdpow` immer streng größer als `(p % a) >> gcdpow` ist.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SICHERHEIT: `a2` ist eine Zweierpotenz, wie oben gezeigt.`s2` ist strikt kleiner als `a2`
        // weil `(s % a) >> gcdpow` streng weniger als `a >> gcdpow` ist.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Kann überhaupt nicht ausgerichtet werden.
    usize::MAX
}

/// Vergleicht Rohzeiger auf Gleichheit.
///
/// Dies entspricht der Verwendung des `==`-Operators, ist jedoch weniger allgemein:
/// Die Argumente müssen `*const T`-Rohzeiger sein, nichts, was `PartialEq` implementiert.
///
/// Dies kann verwendet werden, um `&T`-Referenzen (die implizit zu `*const T` zwingen) anhand ihrer Adresse zu vergleichen, anstatt die Werte zu vergleichen, auf die sie verweisen (was die `PartialEq for &T`-Implementierung tut).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Scheiben werden auch nach ihrer Länge verglichen (Fettzeiger):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits werden auch anhand ihrer Implementierung verglichen:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Zeiger haben gleiche Adressen.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekte haben gleiche Adressen, aber `Trait` hat unterschiedliche Implementierungen.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Das Konvertieren der Referenz in einen `*const u8` wird nach Adresse verglichen.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash einen rohen Zeiger.
///
/// Dies kann verwendet werden, um eine `&T`-Referenz (die implizit zu `*const T` erzwingt) anhand ihrer Adresse und nicht anhand des Werts, auf den sie verweist (was die `Hash for &T`-Implementierung tut), zu hashen.
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impliziert für Funktionszeiger
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Die Zwischenbesetzung als Usize ist für AVR erforderlich
                // Damit bleibt der Adressraum des Quellfunktionszeigers im endgültigen Funktionszeiger erhalten.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Die Zwischenbesetzung als Usize ist für AVR erforderlich
                // Damit bleibt der Adressraum des Quellfunktionszeigers im endgültigen Funktionszeiger erhalten.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Keine variadischen Funktionen mit 0 Parametern
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Erstellen Sie einen `const`-Rohzeiger auf eine Stelle, ohne eine Zwischenreferenz zu erstellen.
///
/// Das Erstellen einer Referenz mit `&`/`&mut` ist nur zulässig, wenn der Zeiger richtig ausgerichtet ist und auf initialisierte Daten zeigt.
/// In Fällen, in denen diese Anforderungen nicht gelten, sollten stattdessen Rohzeiger verwendet werden.
/// `&expr as *const _` erstellt jedoch eine Referenz, bevor sie in einen Rohzeiger umgewandelt wird, und diese Referenz unterliegt denselben Regeln wie alle anderen Referenzen.
///
/// Dieses Makro kann einen Rohzeiger erstellen,*ohne* zuerst eine Referenz zu erstellen.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` würde eine nicht ausgerichtete Referenz erstellen und somit undefiniertes Verhalten sein!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Erstellen Sie einen `mut`-Rohzeiger auf eine Stelle, ohne eine Zwischenreferenz zu erstellen.
///
/// Das Erstellen einer Referenz mit `&`/`&mut` ist nur zulässig, wenn der Zeiger richtig ausgerichtet ist und auf initialisierte Daten zeigt.
/// In Fällen, in denen diese Anforderungen nicht gelten, sollten stattdessen Rohzeiger verwendet werden.
/// `&mut expr as *mut _` erstellt jedoch eine Referenz, bevor sie in einen Rohzeiger umgewandelt wird, und diese Referenz unterliegt denselben Regeln wie alle anderen Referenzen.
///
/// Dieses Makro kann einen Rohzeiger erstellen,*ohne* zuerst eine Referenz zu erstellen.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` würde eine nicht ausgerichtete Referenz erstellen und somit undefiniertes Verhalten sein!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` erzwingt das Kopieren des Feldes, anstatt eine Referenz zu erstellen.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}