//! Benutzerdefinierte (bignum)-Implementierung mit beliebiger Genauigkeit.
//!
//! Dies soll die Heap-Zuordnung auf Kosten des Stapelspeichers vermeiden.
//! Der am häufigsten verwendete Bignum-Typ `Big32x40` ist auf 32 × 40=1.280 Bit begrenzt und benötigt höchstens 160 Byte Stapelspeicher.
//! Dies ist mehr als genug, um alle möglichen endlichen `f64`-Werte auszulösen.
//!
//! Im Prinzip ist es möglich, mehrere Bignum-Typen für verschiedene Eingaben zu haben, aber wir tun dies nicht, um das Aufblähen des Codes zu vermeiden.
//!
//! Jedes Bignum wird immer noch für die tatsächlichen Verwendungen verfolgt, daher spielt es normalerweise keine Rolle.
//!

// Dieses Modul ist nur für dec2flt und flt2dec und aufgrund von Coretests nur öffentlich.
// Es ist nicht beabsichtigt, jemals stabilisiert zu werden.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Arithmetische Operationen, die von Bignums benötigt werden.
pub trait FullOps: Sized {
    /// Gibt `(carry', v')` so zurück, dass `carry' * 2^W + v' = self + other + carry`, wobei `W` die Anzahl der Bits in `Self` ist.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Gibt `(carry', v')` so zurück, dass `carry'*2^W + v' = self* other + carry`, wobei `W` die Anzahl der Bits in `Self` ist.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Gibt `(carry', v')` so zurück, dass `carry'*2^W + v' = self* other + other2 + carry`, wobei `W` die Anzahl der Bits in `Self` ist.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Gibt `(quo, rem)` so zurück, dass `borrow *2^W + self = quo* other + rem` und `0 <= rem < other`, wobei `W` die Anzahl der Bits in `Self` ist.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Dies kann nicht überlaufen;Die Ausgabe liegt zwischen `0` und `2 * 2^nbits - 1`.
                    // FIXME: Wird LLVM dies in ADC oder ähnlichem optimieren?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Dies kann nicht überlaufen;
                    // Die Ausgabe liegt zwischen `0` und `2^nbits * (2^nbits - 1)`.
                    // FIXME: Wird LLVM dies in ADC oder ähnlichem optimieren?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Dies kann nicht überlaufen;
                    // Die Ausgabe liegt zwischen `0` und `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Dies kann nicht überlaufen;Die Ausgabe liegt zwischen `0` und `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Informationen zum Aktivieren finden Sie unter RFC #521.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Tabelle der Potenzen von 5 in Ziffern darstellbar.Insbesondere der größte {u8, u16, u32}-Wert, der eine Potenz von fünf ist, plus der entsprechende Exponent.
/// Wird in `mul_pow5` verwendet.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Ganzzahl mit beliebiger Genauigkeit (bis zu einem bestimmten Grenzwert) mit Stapelzuweisung.
        ///
        /// Dies wird durch ein Array mit fester Größe des angegebenen Typs ("digit") unterstützt.
        /// Während das Array nicht sehr groß ist (normalerweise einige hundert Bytes), kann das rücksichtslose Kopieren zu Leistungseinbußen führen.
        ///
        /// Somit ist dies absichtlich nicht `Copy`.
        ///
        /// Alle Operationen, die bignums panic bei Überläufen zur Verfügung stehen.
        /// Der Anrufer ist dafür verantwortlich, ausreichend große Bignumtypen zu verwenden.
        pub struct $name {
            /// Eins plus den Versatz zum maximal verwendeten "digit".
            /// Dies nimmt nicht ab. Beachten Sie daher die Berechnungsreihenfolge.
            /// `base[size..]` sollte Null sein.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` stellt `a + b *2^W + c* 2^(2W) + ...` dar, wobei `W` die Anzahl der Bits im Zifferntyp ist.
            base: [$ty; $n],
        }

        impl $name {
            /// Macht ein Bignum aus einer Ziffer.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Erstellt ein Bignum aus dem `u64`-Wert.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Gibt die internen Ziffern als Slice `[a, b, c, ...]` zurück, sodass der numerische Wert `a + b *2^W + c* 2^(2W) + ...` ist, wobei `W` die Anzahl der Bits im Zifferntyp ist.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Gibt das i-te Bit zurück, wobei Bit 0 das niedrigstwertige ist.
            /// Mit anderen Worten, das Bit mit dem Gewicht `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Gibt `true` zurück, wenn das Bignum Null ist.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Gibt die Anzahl der Bits zurück, die zur Darstellung dieses Werts erforderlich sind.
            /// Beachten Sie, dass Null 0 Bits benötigt.
            pub fn bit_length(&self) -> usize {
                // Überspringen Sie die wichtigsten Ziffern, die Null sind.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Es gibt keine Ziffern ungleich Null, dh die Zahl ist Null.
                    return 0;
                }
                // Dies könnte mit leading_zeros() und Bitverschiebungen optimiert werden, aber das ist den Aufwand wahrscheinlich nicht wert.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Fügt `other` zu sich selbst hinzu und gibt seine eigene veränderbare Referenz zurück.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Subtrahiert `other` von sich selbst und gibt seine eigene veränderbare Referenz zurück.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Multipliziert sich mit einem `other` in Zifferngröße und gibt seine eigene veränderbare Referenz zurück.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Multipliziert sich mit `2^bits` und gibt seine eigene veränderbare Referenz zurück.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // Verschiebung um `digits * digitbits`-Bits
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // Verschiebung um `bits`-Bits
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. Ziffern] ist Null, keine Notwendigkeit zu verschieben
                }

                self.size = sz;
                self
            }

            /// Multipliziert sich mit `5^e` und gibt seine eigene veränderbare Referenz zurück.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Es gibt genau n nachgestellte Nullen auf 2 ^ n, und die einzigen relevanten Zifferngrößen sind aufeinanderfolgende Zweierpotenzen, so dass dies ein gut geeigneter Index für die Tabelle ist.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Multiplizieren Sie so lange wie möglich mit der größten einstelligen Leistung ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... dann den Rest erledigen.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Multipliziert sich mit einer von `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` beschriebenen Zahl (wobei `W` die Anzahl der Bits im Zifferntyp ist) und gibt eine eigene veränderbare Referenz zurück.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // die interne Routine.funktioniert am besten, wenn aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Teilt sich durch ein `other` in Zifferngröße und gibt seine eigene veränderbare Referenz *und* den Rest zurück.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Teilen Sie sich durch ein anderes Bignum und überschreiben Sie `q` mit dem Quotienten und `r` mit dem Rest.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Dumme langsame base-2 lange Division aus
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME verwendet eine größere Basis ($ty) für die lange Division.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Setzen Sie das Bit `i` von q auf 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Der Zifferntyp für `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// Dieser wird nur zum Testen verwendet.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}