//! Fehlertypen für die Konvertierung in Integraltypen.

use crate::convert::Infallible;
use crate::fmt;

/// Der Fehlertyp wird zurückgegeben, wenn eine überprüfte Konvertierung des integralen Typs fehlschlägt.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Passen Sie an, anstatt sicherzustellen, dass Code wie `From<Infallible> for TryFromIntError` oben weiterhin funktioniert, wenn `Infallible` zu einem Alias für `!` wird.
        //
        //
        match never {}
    }
}

/// Ein Fehler, der beim Parsen einer Ganzzahl zurückgegeben werden kann.
///
/// Dieser Fehler wird als Fehlertyp für die `from_str_radix()`-Funktionen für primitive Ganzzahltypen wie [`i8::from_str_radix`] verwendet.
///
/// # Mögliche Ursachen
///
/// Unter anderem kann `ParseIntError` aufgrund von führenden oder nachfolgenden Leerzeichen in der Zeichenfolge ausgelöst werden, z. B. wenn es von der Standardeingabe abgerufen wird.
///
/// Durch die Verwendung der [`str::trim()`]-Methode wird sichergestellt, dass vor dem Parsen kein Leerzeichen mehr vorhanden ist.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum, um die verschiedenen Arten von Fehlern zu speichern, die dazu führen können, dass das Parsen einer Ganzzahl fehlschlägt.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Der zu analysierende Wert ist leer.
    ///
    /// Diese Variante wird unter anderem beim Parsen einer leeren Zeichenfolge erstellt.
    Empty,
    /// Enthält eine ungültige Ziffer in ihrem Kontext.
    ///
    /// Diese Variante wird unter anderem beim Parsen einer Zeichenfolge erstellt, die ein Nicht-ASCII-Zeichen enthält.
    ///
    /// Diese Variante wird auch konstruiert, wenn ein `+` oder `-` innerhalb einer Zeichenfolge entweder alleine oder in der Mitte einer Zahl falsch platziert ist.
    ///
    ///
    InvalidDigit,
    /// Die Ganzzahl ist zu groß, um sie im Ganzzahlentyp des Ziels zu speichern.
    PosOverflow,
    /// Die Ganzzahl ist zu klein, um im Ziel-Ganzzahltyp gespeichert zu werden.
    NegOverflow,
    /// Wert war Null
    ///
    /// Diese Variante wird ausgegeben, wenn die Analysezeichenfolge den Wert Null hat, was für Typen ungleich Null unzulässig wäre.
    ///
    Zero,
}

impl ParseIntError {
    /// Gibt die detaillierte Ursache für das Parsen einer fehlgeschlagenen Ganzzahl aus.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}