//! Konstanten für den 8-Bit-Integer-Typ ohne Vorzeichen.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Neuer Code sollte die zugehörigen Konstanten direkt für den primitiven Typ verwenden.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }