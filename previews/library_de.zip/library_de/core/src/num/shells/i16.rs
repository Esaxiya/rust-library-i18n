//! Konstanten für den 16-Bit-Integer-Typ mit Vorzeichen.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Neuer Code sollte die zugehörigen Konstanten direkt für den primitiven Typ verwenden.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }