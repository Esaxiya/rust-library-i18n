macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Der kleinste Wert, der durch diesen Ganzzahltyp dargestellt werden kann.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Der größte Wert, der durch diesen Ganzzahltyp dargestellt werden kann.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Die Größe dieses Integer-Typs in Bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konvertiert ein String-Slice in einer bestimmten Basis in eine Ganzzahl.
        ///
        /// Es wird erwartet, dass die Zeichenfolge ein optionales `+`-Zeichen gefolgt von Ziffern ist.
        ///
        /// Führende und nachfolgende Leerzeichen stellen einen Fehler dar.
        /// Ziffern sind eine Teilmenge dieser Zeichen, abhängig von `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Diese Funktion panics, wenn `radix` nicht im Bereich von 2 bis 36 liegt.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Gibt die Anzahl der Einsen in der Binärdarstellung von `self` zurück.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Gibt die Anzahl der Nullen in der Binärdarstellung von `self` zurück.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Gibt die Anzahl der führenden Nullen in der Binärdarstellung von `self` zurück.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Gibt die Anzahl der nachgestellten Nullen in der Binärdarstellung von `self` zurück.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Gibt die Anzahl der führenden in der Binärdarstellung von `self` zurück.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Gibt die Anzahl der nachfolgenden in der Binärdarstellung von `self` zurück.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Verschiebt die Bits um einen bestimmten Betrag, `n`, nach links und umschließt die abgeschnittenen Bits bis zum Ende der resultierenden Ganzzahl.
        ///
        ///
        /// Bitte beachten Sie, dass dies nicht der gleiche Vorgang wie beim `<<`-Schaltoperator ist!
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Verschiebt die Bits um einen bestimmten Betrag, `n`, nach rechts und umschließt die abgeschnittenen Bits mit dem Anfang der resultierenden Ganzzahl.
        ///
        ///
        /// Bitte beachten Sie, dass dies nicht der gleiche Vorgang wie beim `>>`-Schaltoperator ist!
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Kehrt die Bytereihenfolge der Ganzzahl um.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// sei m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Kehrt die Reihenfolge der Bits in der Ganzzahl um.
        /// Das niedrigstwertige Bit wird zum höchstwertigen Bit, das zweitniedrigste Bit wird zum zweithöchsten Bit usw.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// sei m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Konvertiert eine Ganzzahl von Big Endian in die Endianness des Ziels.
        ///
        /// Auf Big Endian ist dies ein No-Op.
        /// Auf Little Endian werden die Bytes ausgetauscht.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvertiert eine Ganzzahl von Little Endian in die Endianness des Ziels.
        ///
        /// Auf Little Endian ist dies ein No-Op.
        /// Auf Big Endian werden die Bytes ausgetauscht.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvertiert `self` von der Endianness des Ziels in Big Endian.
        ///
        /// Auf Big Endian ist dies ein No-Op.
        /// Auf Little Endian werden die Bytes ausgetauscht.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } sonst { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // oder nicht sein?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konvertiert `self` von der Endianness des Ziels in Little Endian.
        ///
        /// Auf Little Endian ist dies ein No-Op.
        /// Auf Big Endian werden die Bytes ausgetauscht.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } sonst { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Geprüfte Ganzzahladdition.
        /// Berechnet `self + rhs` und gibt `None` zurück, wenn ein Überlauf aufgetreten ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Deaktivierte Ganzzahladdition.Berechnet `self + rhs` unter der Annahme, dass kein Überlauf auftreten kann.
        /// Dies führt zu undefiniertem Verhalten, wenn
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `unchecked_add` einhalten.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Überprüfte Ganzzahlsubtraktion.
        /// Berechnet `self - rhs` und gibt `None` zurück, wenn ein Überlauf aufgetreten ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Deaktivierte Ganzzahlsubtraktion.Berechnet `self - rhs` unter der Annahme, dass kein Überlauf auftreten kann.
        /// Dies führt zu undefiniertem Verhalten, wenn
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `unchecked_sub` einhalten.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Überprüfte Ganzzahlmultiplikation.
        /// Berechnet `self * rhs` und gibt `None` zurück, wenn ein Überlauf aufgetreten ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Deaktivierte Ganzzahlmultiplikation.Berechnet `self * rhs` unter der Annahme, dass kein Überlauf auftreten kann.
        /// Dies führt zu undefiniertem Verhalten, wenn
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `unchecked_mul` einhalten.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Geprüfte Ganzzahldivision.
        /// Berechnet `self / rhs` und gibt `None` zurück, wenn `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SICHERHEIT: div by zero wurde oben überprüft und vorzeichenlose Typen haben keine anderen
                // Fehlermodi für die Teilung
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Überprüfte euklidische Teilung.
        /// Berechnet `self.div_euclid(rhs)` und gibt `None` zurück, wenn `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Geprüfter ganzzahliger Rest.
        /// Berechnet `self % rhs` und gibt `None` zurück, wenn `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SICHERHEIT: div by zero wurde oben überprüft und vorzeichenlose Typen haben keine anderen
                // Fehlermodi für die Teilung
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Überprüftes euklidisches Modulo.
        /// Berechnet `self.rem_euclid(rhs)` und gibt `None` zurück, wenn `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Negation geprüft.Berechnet `-self` und gibt `None` zurück, es sei denn, `self==
        /// 0`.
        ///
        /// Beachten Sie, dass das Negieren einer positiven Ganzzahl überläuft.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Geprüfte Verschiebung nach links.
        /// Berechnet `self << rhs` und gibt `None` zurück, wenn `rhs` größer oder gleich der Anzahl der Bits in `self` ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Geprüfte Verschiebung nach rechts.
        /// Berechnet `self >> rhs` und gibt `None` zurück, wenn `rhs` größer oder gleich der Anzahl der Bits in `self` ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Überprüfte Potenzierung.
        /// Berechnet `self.pow(exp)` und gibt `None` zurück, wenn ein Überlauf aufgetreten ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // da exp!=0, muss die exp schließlich 1 sein.
            // Behandeln Sie das letzte Bit des Exponenten separat, da ein anschließendes Quadrieren der Basis nicht erforderlich ist und einen unnötigen Überlauf verursachen kann.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Sättigende Ganzzahladdition.
        /// Berechnet `self + rhs`, wobei an den numerischen Grenzen gesättigt wird, anstatt überzulaufen.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Sättigende Ganzzahlsubtraktion.
        /// Berechnet `self - rhs`, wobei an den numerischen Grenzen gesättigt wird, anstatt überzulaufen.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Sättigende Ganzzahlmultiplikation.
        /// Berechnet `self * rhs`, wobei an den numerischen Grenzen gesättigt wird, anstatt überzulaufen.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Sättigende ganzzahlige Potenzierung.
        /// Berechnet `self.pow(exp)`, wobei an den numerischen Grenzen gesättigt wird, anstatt überzulaufen.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Verpackung (modular) zusätzlich.
        /// Berechnet `self + rhs` und umschließt die Grenze des Typs.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Umschließen der (modular)-Subtraktion.
        /// Berechnet `self - rhs` und umschließt die Grenze des Typs.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular)-Multiplikation einwickeln.
        /// Berechnet `self * rhs` und umschließt die Grenze des Typs.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// Bitte beachten Sie, dass dieses Beispiel von ganzzahligen Typen gemeinsam genutzt wird.
        /// Das erklärt, warum hier `u8` verwendet wird.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) Division einwickeln.Berechnet `self / rhs`.
        /// Die umbrochene Teilung bei vorzeichenlosen Typen ist nur eine normale Teilung.
        /// Es gibt keine Möglichkeit, dass das Wickeln jemals passieren könnte.
        /// Diese Funktion ist vorhanden, sodass alle Vorgänge in den Umhüllungsvorgängen berücksichtigt werden.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Umhüllung der euklidischen Teilung.Berechnet `self.div_euclid(rhs)`.
        /// Die umbrochene Teilung bei vorzeichenlosen Typen ist nur eine normale Teilung.
        /// Es gibt keine Möglichkeit, dass das Wickeln jemals passieren könnte.
        /// Diese Funktion ist vorhanden, sodass alle Vorgänge in den Umhüllungsvorgängen berücksichtigt werden.
        /// Da für die positiven ganzen Zahlen alle gängigen Definitionen der Division gleich sind, ist dies genau gleich `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) Rest einwickeln.Berechnet `self % rhs`.
        /// Die Berechnung des umschlossenen Restes für vorzeichenlose Typen ist nur die reguläre Restberechnung.
        ///
        /// Es gibt keine Möglichkeit, dass das Wickeln jemals passieren könnte.
        /// Diese Funktion ist vorhanden, sodass alle Vorgänge in den Umhüllungsvorgängen berücksichtigt werden.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Euklidisches Modulo einwickeln.Berechnet `self.rem_euclid(rhs)`.
        /// Die Wrapped-Modulo-Berechnung für vorzeichenlose Typen ist nur die reguläre Restberechnung.
        /// Es gibt keine Möglichkeit, dass das Wickeln jemals passieren könnte.
        /// Diese Funktion ist vorhanden, sodass alle Vorgänge in den Umhüllungsvorgängen berücksichtigt werden.
        /// Da für die positiven ganzen Zahlen alle gängigen Definitionen der Division gleich sind, ist dies genau gleich `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular)-Negation einpacken.
        /// Berechnet `-self` und umschließt die Grenze des Typs.
        ///
        /// Da vorzeichenlose Typen keine negativen Entsprechungen haben, werden alle Anwendungen dieser Funktion umbrochen (außer `-0`).
        /// Bei Werten, die kleiner als das Maximum des entsprechenden vorzeichenbehafteten Typs sind, entspricht das Ergebnis dem Umwandeln des entsprechenden vorzeichenbehafteten Werts.
        ///
        /// Alle größeren Werte entsprechen `MAX + 1 - (val - MAX - 1)`, wobei `MAX` das Maximum des entsprechenden vorzeichenbehafteten Typs ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// Bitte beachten Sie, dass dieses Beispiel von ganzzahligen Typen gemeinsam genutzt wird.
        /// Das erklärt, warum hier `i8` verwendet wird.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-freie bitweise Verschiebung nach links;
        /// ergibt `self << mask(rhs)`, wobei `mask` alle höherwertigen Bits von `rhs` entfernt, die dazu führen würden, dass die Verschiebung die Bitbreite des Typs überschreitet.
        ///
        /// Beachten Sie, dass dies nicht mit einer Drehung nach links identisch ist.Die RHS einer Umhüllung nach links ist auf den Bereich des Typs beschränkt, anstatt dass die aus der LHS verschobenen Bits an das andere Ende zurückgegeben werden.
        /// Die primitiven Ganzzahltypen implementieren alle eine [`rotate_left`](Self::rotate_left)-Funktion, die möglicherweise stattdessen gewünscht wird.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SICHERHEIT: Die Maskierung durch die Bitgröße des Typs stellt sicher, dass wir nicht verschieben
            // außerhalb der Grenzen
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-freie bitweise Verschiebung nach rechts;
        /// ergibt `self >> mask(rhs)`, wobei `mask` alle höherwertigen Bits von `rhs` entfernt, die dazu führen würden, dass die Verschiebung die Bitbreite des Typs überschreitet.
        ///
        /// Beachten Sie, dass dies nicht mit einer Rechtsdrehung identisch ist.Die RHS einer Umhüllungsverschiebung nach rechts ist auf den Bereich des Typs beschränkt, anstatt dass die aus der LHS verschobenen Bits an das andere Ende zurückgegeben werden.
        /// Die primitiven Ganzzahltypen implementieren alle eine [`rotate_right`](Self::rotate_right)-Funktion, die möglicherweise stattdessen gewünscht wird.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SICHERHEIT: Die Maskierung durch die Bitgröße des Typs stellt sicher, dass wir nicht verschieben
            // außerhalb der Grenzen
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular)-Potenzierung einschließen.
        /// Berechnet `self.pow(exp)` und umschließt die Grenze des Typs.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // da exp!=0, muss die exp schließlich 1 sein.
            // Behandeln Sie das letzte Bit des Exponenten separat, da ein anschließendes Quadrieren der Basis nicht erforderlich ist und einen unnötigen Überlauf verursachen kann.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Berechnet `self` + `rhs`
        ///
        /// Gibt ein Tupel der Addition zusammen mit einem Booleschen Wert zurück, der angibt, ob ein arithmetischer Überlauf auftreten würde.
        /// Wenn ein Überlauf aufgetreten wäre, wird der umschlossene Wert zurückgegeben.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berechnet `self`, `rhs`
        ///
        /// Gibt ein Tupel der Subtraktion zusammen mit einem Booleschen Wert zurück, der angibt, ob ein arithmetischer Überlauf auftreten würde.
        /// Wenn ein Überlauf aufgetreten wäre, wird der umschlossene Wert zurückgegeben.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berechnet die Multiplikation von `self` und `rhs`.
        ///
        /// Gibt ein Tupel der Multiplikation zusammen mit einem Booleschen Wert zurück, der angibt, ob ein arithmetischer Überlauf auftreten würde.
        /// Wenn ein Überlauf aufgetreten wäre, wird der umschlossene Wert zurückgegeben.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// Bitte beachten Sie, dass dieses Beispiel von ganzzahligen Typen gemeinsam genutzt wird.
        /// Das erklärt, warum hier `u32` verwendet wird.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Berechnet den Divisor, wenn `self` durch `rhs` geteilt wird.
        ///
        /// Gibt ein Tupel des Divisors zusammen mit einem Booleschen Wert zurück, der angibt, ob ein arithmetischer Überlauf auftreten würde.
        /// Beachten Sie, dass bei Ganzzahlen ohne Vorzeichen niemals ein Überlauf auftritt, sodass der zweite Wert immer `false` ist.
        ///
        /// # Panics
        ///
        /// Diese Funktion wird panic, wenn `rhs` 0 ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Berechnet den Quotienten der euklidischen Division `self.div_euclid(rhs)`.
        ///
        /// Gibt ein Tupel des Divisors zusammen mit einem Booleschen Wert zurück, der angibt, ob ein arithmetischer Überlauf auftreten würde.
        /// Beachten Sie, dass bei Ganzzahlen ohne Vorzeichen niemals ein Überlauf auftritt, sodass der zweite Wert immer `false` ist.
        /// Da für die positiven ganzen Zahlen alle gängigen Definitionen der Division gleich sind, ist dies genau gleich `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Diese Funktion wird panic, wenn `rhs` 0 ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Berechnet den Rest, wenn `self` durch `rhs` geteilt wird.
        ///
        /// Gibt nach dem Teilen ein Tupel des Restes zusammen mit einem Booleschen Wert zurück, der angibt, ob ein arithmetischer Überlauf auftreten würde.
        /// Beachten Sie, dass bei Ganzzahlen ohne Vorzeichen niemals ein Überlauf auftritt, sodass der zweite Wert immer `false` ist.
        ///
        /// # Panics
        ///
        /// Diese Funktion wird panic, wenn `rhs` 0 ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Berechnet den Rest `self.rem_euclid(rhs)` wie nach euklidischer Division.
        ///
        /// Gibt nach dem Teilen ein Tupel des Modulos zusammen mit einem Booleschen Wert zurück, der angibt, ob ein arithmetischer Überlauf auftreten würde.
        /// Beachten Sie, dass bei Ganzzahlen ohne Vorzeichen niemals ein Überlauf auftritt, sodass der zweite Wert immer `false` ist.
        /// Da für die positiven ganzen Zahlen alle gängigen Definitionen der Division gleich sind, ist diese Operation genau gleich `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Diese Funktion wird panic, wenn `rhs` 0 ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negiert sich selbst überfüllt.
        ///
        /// Gibt `!self + 1` mithilfe von Umbruchoperationen zurück, um den Wert zurückzugeben, der die Negation dieses vorzeichenlosen Werts darstellt.
        /// Beachten Sie, dass bei positiven vorzeichenlosen Werten immer ein Überlauf auftritt, das Negieren von 0 jedoch nicht überläuft.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Verschiebt sich um `rhs`-Bits nach links.
        ///
        /// Gibt ein Tupel der verschobenen Version von self zusammen mit einem Booleschen Wert zurück, der angibt, ob der Verschiebungswert größer oder gleich der Anzahl der Bits war.
        /// Wenn der Verschiebungswert zu groß ist, wird der Wert (N-1) maskiert, wobei N die Anzahl der Bits ist, und dieser Wert wird dann verwendet, um die Verschiebung durchzuführen.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Verschiebt sich um `rhs`-Bits nach rechts.
        ///
        /// Gibt ein Tupel der verschobenen Version von self zusammen mit einem Booleschen Wert zurück, der angibt, ob der Verschiebungswert größer oder gleich der Anzahl der Bits war.
        /// Wenn der Verschiebungswert zu groß ist, wird der Wert (N-1) maskiert, wobei N die Anzahl der Bits ist, und dieser Wert wird dann verwendet, um die Verschiebung durchzuführen.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Erhöht sich selbst auf die Kraft von `exp`, indem Exponentiation durch Quadrieren verwendet wird.
        ///
        /// Gibt ein Tupel der Potenzierung zusammen mit einem bool zurück, das angibt, ob ein Überlauf aufgetreten ist.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, wahr));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Scratch Space zum Speichern der Ergebnisse von overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // da exp!=0, muss die exp schließlich 1 sein.
            // Behandeln Sie das letzte Bit des Exponenten separat, da ein anschließendes Quadrieren der Basis nicht erforderlich ist und einen unnötigen Überlauf verursachen kann.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Erhöht sich selbst auf die Kraft von `exp`, indem Exponentiation durch Quadrieren verwendet wird.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // da exp!=0, muss die exp schließlich 1 sein.
            // Behandeln Sie das letzte Bit des Exponenten separat, da ein anschließendes Quadrieren der Basis nicht erforderlich ist und einen unnötigen Überlauf verursachen kann.
            //
            //
            acc * base
        }

        /// Führt eine euklidische Teilung durch.
        ///
        /// Da für die positiven ganzen Zahlen alle gängigen Definitionen der Division gleich sind, ist dies genau gleich `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Diese Funktion wird panic, wenn `rhs` 0 ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Berechnet den kleinsten Rest von `self (mod rhs)`.
        ///
        /// Da für die positiven ganzen Zahlen alle gängigen Definitionen der Division gleich sind, ist dies genau gleich `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Diese Funktion wird panic, wenn `rhs` 0 ist.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Gibt `true` genau dann zurück, wenn `self == 2^k` für einige `k`.
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Gibt eins weniger als die nächste Zweierpotenz zurück.
        // (Für 8u8 ist die nächste Zweierpotenz 8u8 und für 6u8 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Diese Methode kann nicht überlaufen, da sie in den `next_power_of_two`-Überlauffällen stattdessen den Maximalwert des Typs zurückgibt und 0 für 0 zurückgeben kann.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SICHERHEIT: Da `p > 0` nicht vollständig aus führenden Nullen bestehen kann.
            // Das bedeutet, dass die Verschiebung immer in Grenzen liegt und einige Prozessoren (wie z. B. Intel Pre-Haswell) effizientere ctlz-Intrinsics haben, wenn das Argument nicht Null ist.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Gibt die kleinste Potenz von zwei zurück, die größer oder gleich `self` ist.
        ///
        /// Wenn der Rückgabewert überläuft (dh `self > (1 << (N-1))` für Typ `uN`), wird panics im Debug-Modus und der Rückgabewert im Freigabemodus auf 0 gesetzt (die einzige Situation, in der die Methode 0 zurückgeben kann).
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Gibt die kleinste Potenz von zwei zurück, die größer oder gleich `n` ist.
        /// Wenn die nächste Zweierpotenz größer als der Maximalwert des Typs ist, wird `None` zurückgegeben, andernfalls wird die Zweierpotenz in `Some` eingeschlossen.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Gibt die kleinste Potenz von zwei zurück, die größer oder gleich `n` ist.
        /// Wenn die nächste Zweierpotenz größer als der Maximalwert des Typs ist, wird der Rückgabewert in `0` eingeschlossen.
        ///
        ///
        /// # Examples
        ///
        /// Grundlegende Verwendung:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Gibt die Speicherdarstellung dieser Ganzzahl als Bytearray in der Big-Endian-(network)-Bytereihenfolge zurück.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Gibt die Speicherdarstellung dieser Ganzzahl als Bytearray in Little-Endian-Bytereihenfolge zurück.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Gibt die Speicherdarstellung dieser Ganzzahl als Bytearray in nativer Bytereihenfolge zurück.
        ///
        /// Da die native Endianness der Zielplattform verwendet wird, sollte portabler Code stattdessen [`to_be_bytes`] oder [`to_le_bytes`] verwenden.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     Bytes, wenn cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SICHERHEIT: const sound, weil Ganzzahlen einfache alte Datentypen sind, so dass wir es immer können
        // wandeln sie in Arrays von Bytes um
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SICHERHEIT: Ganzzahlen sind einfache alte Datentypen, in die wir sie jederzeit umwandeln können
            // Arrays von Bytes
            unsafe { mem::transmute(self) }
        }

        /// Gibt die Speicherdarstellung dieser Ganzzahl als Bytearray in nativer Bytereihenfolge zurück.
        ///
        ///
        /// [`to_ne_bytes`] sollte, wann immer möglich, diesem vorgezogen werden.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     Bytes, wenn cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SICHERHEIT: Ganzzahlen sind einfache alte Datentypen, in die wir sie jederzeit umwandeln können
            // Arrays von Bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Erstellen Sie einen nativen Endian-Integer-Wert aus seiner Darstellung als Byte-Array in Big Endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// benutze std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * Eingabe=Ruhe;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Erstellen Sie einen nativen Endian-Integer-Wert aus seiner Darstellung als Byte-Array in Little Endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// benutze std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * Eingabe=Ruhe;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Erstellen Sie einen nativen Endian-Integer-Wert aus seiner Speicherdarstellung als Byte-Array in nativer Endianness.
        ///
        /// Da die native Endianness der Zielplattform verwendet wird, möchte portabler Code wahrscheinlich stattdessen [`from_be_bytes`] oder [`from_le_bytes`] verwenden.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// benutze std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * Eingabe=Ruhe;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SICHERHEIT: const sound, weil Ganzzahlen einfache alte Datentypen sind, so dass wir es immer können
        // zu ihnen verwandeln
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SICHERHEIT: Ganzzahlen sind einfache alte Datentypen, sodass wir sie jederzeit umwandeln können
            unsafe { mem::transmute(bytes) }
        }

        /// Neuer Code sollte lieber verwendet werden
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Gibt den kleinsten Wert zurück, der durch diesen Ganzzahltyp dargestellt werden kann.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Neuer Code sollte lieber verwendet werden
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Gibt den größten Wert zurück, der durch diesen Ganzzahltyp dargestellt werden kann.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}