//! Dienstprogrammfunktionen für Bignums, die nicht allzu sinnvoll sind, um in Methoden umgewandelt zu werden.

// FIXME Der Name dieses Moduls ist etwas unglücklich, da andere Module ebenfalls `core::num` importieren.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Testen Sie, ob das Abschneiden aller weniger signifikanten Bits als `ones_place` zu einem relativen Fehler führt, der kleiner, gleich oder größer als 0.5 ULP ist.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Wenn alle verbleibenden Bits Null sind, ist es= 0.5 ULP, andernfalls> 0.5. Wenn keine Bits mehr vorhanden sind (half_bit==0), gibt das Folgende ebenfalls korrekt Equal zurück.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konvertiert eine ASCII-Zeichenfolge, die nur Dezimalstellen enthält, in eine `u64`-Zeichenfolge.
///
/// Führt keine Überprüfungen auf Überlauf oder ungültige Zeichen durch. Wenn der Anrufer also nicht vorsichtig ist, ist das Ergebnis falsch und kann panic (obwohl es nicht `unsafe` ist).
/// Außerdem werden leere Zeichenfolgen als Null behandelt.
/// Diese Funktion existiert weil
///
/// 1. Für die Verwendung von `FromStr` unter `&[u8]` ist `from_utf8_unchecked` erforderlich, was schlecht ist
/// 2. Das Zusammensetzen der Ergebnisse von `integral.parse()` und `fractional.parse()` ist komplizierter als diese gesamte Funktion.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konvertiert eine Folge von ASCII-Ziffern in ein Bignum.
///
/// Wie bei `from_str_unchecked` ist diese Funktion darauf angewiesen, dass der Parser nicht-Ziffern aussortiert.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Packt ein Bignum in eine 64-Bit-Ganzzahl aus.Panics wenn die Anzahl zu groß ist.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrahiert einen Bereich von Bits.

/// Index 0 ist das niedrigstwertige Bit und der Bereich ist wie üblich halb offen.
/// Panics, wenn Sie aufgefordert werden, mehr Bits zu extrahieren, als in den Rückgabetyp passen.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}