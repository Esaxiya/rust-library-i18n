//! Die verschiedenen Algorithmen aus dem Papier.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Anzahl der Signifikantenbits in Fp
const P: u32 = 64;

// Wir speichern einfach die beste Näherung für *alle* Exponenten, sodass die Variable "h" und die zugehörigen Bedingungen weggelassen werden können.
// Dies tauscht Leistung gegen ein paar Kilobyte Platz.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// In den meisten Architekturen haben Gleitkommaoperationen eine explizite Bitgröße, daher wird die Genauigkeit der Berechnung pro Operation bestimmt.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Unter x86 wird die x87-FPU für Float-Vorgänge verwendet, wenn die SSE/SSE2-Erweiterungen nicht verfügbar sind.
// Die x87-FPU arbeitet standardmäßig mit einer Genauigkeit von 80 Bit. Dies bedeutet, dass Operationen auf 80 Bit gerundet werden, was zu einer doppelten Rundung führt, wenn Werte schließlich als dargestellt werden
//
// 32/64 Bit-Float-Werte.Um dies zu überwinden, kann das FPU-Steuerwort so eingestellt werden, dass die Berechnungen mit der gewünschten Genauigkeit ausgeführt werden.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Eine Struktur, die verwendet wird, um den ursprünglichen Wert des FPU-Steuerworts beizubehalten, damit er wiederhergestellt werden kann, wenn die Struktur gelöscht wird.
    ///
    ///
    /// Die x87-FPU ist ein 16-Bit-Register, dessen Felder wie folgt lauten:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Die Dokumentation für alle Felder finden Sie im IA-32 Architectures Software Developer's Manual (Band 1).
    ///
    /// Das einzige Feld, das für den folgenden Code relevant ist, ist PC, Precision Control.
    /// Dieses Feld bestimmt die Genauigkeit der von der FPU ausgeführten Operationen.
    /// Es kann eingestellt werden auf:
    ///  - 0b00, einfache Genauigkeit, dh 32 Bit
    ///  - 0b10, doppelte Genauigkeit, dh 64 Bit
    ///  - 0b11, doppelte erweiterte Genauigkeit, dh 80 Bit (Standardzustand) Der Wert 0b01 ist reserviert und sollte nicht verwendet werden.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SICHERHEIT: Die `fldcw`-Anweisung wurde geprüft, um ordnungsgemäß arbeiten zu können
        // jedes `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Wir verwenden die ATT-Syntax, um LLVM 8 und LLVM 9 zu unterstützen.
                options(att_syntax, nostack),
            )
        }
    }

    /// Setzt das Genauigkeitsfeld der FPU auf `T` und gibt `FPUControlWord` zurück.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Berechnen Sie den Wert für das Feld Präzisionssteuerung, der für `T` geeignet ist.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 Bit
            8 => 0x0200, // 64 Bit
            _ => 0x0300, // Standard 80 Bit
        };

        // Rufen Sie den ursprünglichen Wert des Steuerworts ab, um es später wiederherzustellen, wenn die `FPUControlWord`-Struktur gelöscht wird. SICHERHEIT: Die `fnstcw`-Anweisung wurde überprüft, um mit jedem `u16` ordnungsgemäß arbeiten zu können
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Wir verwenden die ATT-Syntax, um LLVM 8 und LLVM 9 zu unterstützen.
                options(att_syntax, nostack),
            )
        }

        // Stellen Sie das Steuerwort auf die gewünschte Genauigkeit ein.
        // Dies wird erreicht, indem die alte Genauigkeit (Bits 8 und 9, 0x300) maskiert und durch das oben berechnete Genauigkeitsflag ersetzt wird.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Der schnelle Weg von Bellerophon mit maschinengroßen Ganzzahlen und Gleitkommazahlen.
///
/// Dies wird in eine separate Funktion extrahiert, damit versucht werden kann, bevor ein Bignum erstellt wird.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Wir vergleichen den genauen Wert gegen Ende mit MAX_SIG. Dies ist nur eine schnelle, kostengünstige Ablehnung (und befreit auch den Rest des Codes von der Sorge um einen Unterlauf).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Der schnelle Pfad hängt entscheidend davon ab, dass die Arithmetik ohne Zwischenrundung auf die richtige Anzahl von Bits gerundet wird.
    // Unter x86 (ohne SSE oder SSE2) muss die Genauigkeit des x87-FPU-Stacks so geändert werden, dass er direkt auf das 64/32-Bit rundet.
    // Die `set_precision`-Funktion sorgt dafür, dass die Genauigkeit von Architekturen festgelegt wird, für die eine Einstellung erforderlich ist, indem der globale Status geändert wird (wie das Steuerwort der x87-FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Der Fall e <0 kann nicht in die andere branch gefaltet werden.
    // Negative Potenzen führen zu einem sich wiederholenden Bruchteil in Binärform, der gerundet ist, was zu echten (und gelegentlich sehr signifikanten!) Fehlern im Endergebnis führt.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Der Algorithmus Bellerophon ist ein trivialer Code, der durch eine nicht triviale numerische Analyse gerechtfertigt ist.
///
/// Es rundet ``f`` auf ein Float mit 64-Bit-Signifikand und multipliziert es mit der besten Näherung von `10^e` (im gleichen Gleitkommaformat).Dies reicht oft aus, um das richtige Ergebnis zu erzielen.
/// Wenn sich das Ergebnis jedoch fast auf halber Strecke zwischen zwei benachbarten (ordinary)-Floats befindet, bedeutet der zusammengesetzte Rundungsfehler durch Multiplizieren von zwei Näherungswerten, dass das Ergebnis möglicherweise um einige Bits abweicht.
/// Wenn dies geschieht, repariert der iterative Algorithmus R die Dinge.
///
/// Der handgewellte "close to halfway" wird durch die numerische Analyse im Papier präzisiert.
/// Mit den Worten von Clinger:
///
/// > Slop, ausgedrückt in Einheiten des niedrigstwertigen Bits, ist eine inklusive Grenze für den Fehler
/// > akkumuliert während der Gleitkommaberechnung der Näherung an f * 10 ^ e.(Slop ist
/// > keine Grenze für den wahren Fehler, sondern begrenzt die Differenz zwischen der Näherung z und
/// > die bestmögliche Näherung, bei der p Bits von Bedeutung verwendet werden.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Die Fälle abs(e) <log5(2^N) sind in fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ist der Slop groß genug, um beim Runden auf n Bits einen Unterschied zu machen?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Ein iterativer Algorithmus, der eine Gleitkomma-Approximation von `f * 10^e` verbessert.
///
/// Jede Iteration bringt eine Einheit an der letzten Stelle näher zusammen, was natürlich furchtbar lange dauert, um zu konvergieren, wenn `z0` auch nur geringfügig ausgeschaltet ist.
/// Glücklicherweise ist die Startnäherung bei Verwendung als Fallback für Bellerophon um höchstens einen ULP verschoben.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Finden Sie positive ganze Zahlen `x`, `y`, so dass `x / y` genau `(f *10^e) / (m* 2^k)` ist.
        // Dies vermeidet nicht nur den Umgang mit den Vorzeichen von `e` und `k`, sondern eliminiert auch die Potenz von zwei, die `10^e` und `2^k` gemeinsam haben, um die Zahlen zu verkleinern.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Dies ist etwas umständlich geschrieben, da unsere Bignums keine negativen Zahlen unterstützen. Daher verwenden wir die Informationen zu Absolutwert + Vorzeichen.
        // Die Multiplikation mit m_digits kann nicht überlaufen.
        // Wenn `x` oder `y` groß genug sind, um sich über einen Überlauf Gedanken zu machen, sind sie auch groß genug, dass `make_ratio` den Anteil um den Faktor 2 ^ 64 oder mehr reduziert hat.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Benötige kein x mehr, speichere ein clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Benötigen Sie noch y, machen Sie eine Kopie.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Wenn `x = f` und `y = m` wie üblich `f` Eingangs-Dezimalstellen darstellen und `m` die Bedeutung einer Gleitkommanäherung ist, muss das Verhältnis `x / y` gleich `(f *10^e) / (m* 2^k)` sein, möglicherweise reduziert durch eine Zweierpotenz, die beide gemeinsam haben.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, außer dass wir den Bruch um eine Zweierpotenz reduzieren.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Dies kann nicht überlaufen, da positive `e` und negative `k` erforderlich sind, was nur bei Werten nahe 1 möglich ist, was bedeutet, dass `e` und `k` vergleichsweise klein sind.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Dies kann auch nicht überlaufen, siehe oben.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), wiederum um eine gemeinsame Zweierpotenz reduzierend.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konzeptionell ist Algorithmus M der einfachste Weg, eine Dezimalstelle in einen Gleitkommawert umzuwandeln.
///
/// Wir bilden ein Verhältnis, das gleich `f * 10^e` ist, und werfen dann Zweierpotenzen ein, bis sich ein gültiger Float-Signifikant ergibt.
/// Der binäre Exponent `k` gibt an, wie oft wir Zähler oder Nenner mit zwei multipliziert haben, dh zu allen Zeiten ist `f *10^e` gleich `(u / v)* 2^k`.
/// Wenn wir den Signifikanten herausgefunden haben, müssen wir nur noch den Rest der Division untersuchen, was in den weiter unten aufgeführten Hilfsfunktionen erfolgt.
///
///
/// Dieser Algorithmus ist trotz der in `quick_start()` beschriebenen Optimierung sehr langsam.
/// Es ist jedoch der einfachste Algorithmus, der sich an Überlauf-, Unterlauf-und subnormale Ergebnisse anpasst.
/// Diese Implementierung übernimmt, wenn Bellerophon und Algorithmus R überfordert sind.
/// Das Erkennen von Unterlauf und Überlauf ist einfach: Das Verhältnis ist immer noch kein In-Range-Signifikant, aber der minimum/maximum-Exponent wurde erreicht.
/// Im Falle eines Überlaufs geben wir einfach unendlich zurück.
///
/// Der Umgang mit Unterlauf und Subnormalen ist schwieriger.
/// Ein großes Problem ist, dass mit dem minimalen Exponenten das Verhältnis möglicherweise immer noch zu groß für einen Signifikanten ist.
/// Siehe underflow() für Details.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME mögliche Optimierung: Verallgemeinern Sie big_to_fp, so dass wir hier das Äquivalent von fp_to_float(big_to_fp(u)) machen können, nur ohne die doppelte Rundung.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Wir müssen am minimalen Exponenten anhalten. Wenn wir bis `k < T::MIN_EXP_INT` warten, sind wir um den Faktor zwei versetzt.
            // Leider bedeutet dies, dass wir normale Zahlen mit dem minimalen Exponenten als Sonderfall verwenden müssen.
            // FIXME findet eine elegantere Formulierung, aber führen Sie den `tiny-pow10`-Test durch, um sicherzustellen, dass er tatsächlich korrekt ist!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Überspringt die meisten Algorithmus-M-Iterationen, indem die Bitlänge überprüft wird.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Die Bitlänge ist eine Schätzung des Logarithmus der Basis zwei und log(u / v) = log(u), log(v).
    // Die Schätzung ist um höchstens 1 verschoben, aber immer unterschätzt, sodass der Fehler bei log(u) und log(v) das gleiche Vorzeichen hat und sich aufhebt (wenn beide groß sind).
    // Daher ist der Fehler für log(u / v) ebenfalls höchstens einer.
    // Das Zielverhältnis ist eines, bei dem u/v in einem signifikanten Bereich liegt.Somit ist unsere Beendigungsbedingung, dass log2(u / v) die signifikanten Bits sind, plus/minus eins.
    // FIXME Ein Blick auf das zweite Bit könnte die Schätzung verbessern und weitere Unterteilungen vermeiden.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Unterlauf oder subnormal.Überlassen Sie es der Hauptfunktion.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Überlauf.Überlassen Sie es der Hauptfunktion.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Das Verhältnis ist kein In-Range-Signifikant mit dem minimalen Exponenten, daher müssen wir überschüssige Bits abrunden und den Exponenten entsprechend anpassen.
    // Der wahre Wert sieht jetzt so aus:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q abschneiden.(vertreten durch rem)
    //
    // Wenn die abgerundeten Bits!= 0.5 ULP sind, entscheiden sie daher selbst über die Rundung.
    // Wenn sie gleich sind und der Rest nicht Null ist, muss der Wert noch aufgerundet werden.
    // Nur wenn die abgerundeten Bits 1/2 sind und der Rest Null ist, haben wir eine halb-zu-gerade-Situation.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Gewöhnliche Runde zu gerade, verschleiert durch das Runden auf der Grundlage des Restes einer Division.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}