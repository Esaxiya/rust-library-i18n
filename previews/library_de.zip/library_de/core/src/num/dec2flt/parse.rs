//! Überprüfen und Zerlegen einer Dezimalzeichenfolge des Formulars:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Mit anderen Worten, Standard-Gleitkommasyntax, mit zwei Ausnahmen: Kein Vorzeichen und keine Behandlung von "inf" und "NaN".Diese werden von der Treiberfunktion (super::dec2flt) übernommen.
//!
//! Obwohl das Erkennen gültiger Eingaben relativ einfach ist, muss dieses Modul auch die unzähligen ungültigen Variationen, niemals panic, ablehnen und zahlreiche Überprüfungen durchführen, auf die sich die anderen Module verlassen, um nicht panic (oder Überlauf) zu sein.
//!
//! Um die Sache noch schlimmer zu machen, geschieht alles in einem einzigen Durchgang über die Eingabe.
//! Seien Sie also vorsichtig, wenn Sie etwas ändern, und überprüfen Sie dies mit den anderen Modulen.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Die interessanten Teile einer Dezimalzeichenfolge.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Der Dezimalexponent hat garantiert weniger als 18 Dezimalstellen.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Überprüft, ob die Eingabezeichenfolge eine gültige Gleitkommazahl ist, und suchen Sie in diesem Fall den Integralteil, den Bruchteil und den Exponenten darin.
/// Behandelt keine Schilder.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Keine Ziffern vor 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Wir benötigen mindestens eine einzelne Ziffer vor oder nach dem Punkt.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Nachlaufender Müll nach Bruchteil
            }
        }
        _ => Invalid, // Nachlaufender Junk nach der ersten Ziffernfolge
    }
}

/// Schneidet Dezimalstellen bis zum ersten nichtstelligen Zeichen ab.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Exponentenextraktion und Fehlerprüfung.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Nachlaufender Müll nach Exponent
    }
    if number.is_empty() {
        return Invalid; // Exponent leeren
    }
    // Zu diesem Zeitpunkt haben wir sicherlich eine gültige Ziffernfolge.Es mag zu lang sein, um es in ein `i64` zu stecken, aber wenn es so groß ist, ist die Eingabe mit Sicherheit Null oder unendlich.
    // Da jede Null in den Dezimalstellen den Exponenten nur um +/-1 anpasst, müsste bei exp=10 ^ 18 die Eingabe 17 Exabyte (!) von Nullen sein, um auch nur annähernd endlich zu sein.
    //
    // Dies ist nicht gerade ein Anwendungsfall, dem wir gerecht werden müssen.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}