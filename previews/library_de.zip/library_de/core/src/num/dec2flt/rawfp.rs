//! Ein bisschen Fummeln an positiven IEEE 754-Floats.Negative Zahlen werden und müssen nicht behandelt werden.
//! Normale Gleitkommazahlen haben eine kanonische Darstellung als (frac, exp), so dass der Wert 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) ist, wobei N die Anzahl der Bits ist.
//!
//! Subnormen sind etwas anders und seltsam, aber das gleiche Prinzip gilt.
//!
//! Hier stellen wir sie jedoch als (sig, k) mit f positiv dar, so dass der Wert f * ist
//! 2 <sup>e</sup> .Dies macht den "hidden bit" nicht nur explizit, sondern ändert auch den Exponenten durch die sogenannte Mantissenverschiebung.
//!
//! Anders ausgedrückt, normalerweise werden Floats als (1) geschrieben, aber hier werden sie als (2) geschrieben:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Wir nennen (1) die **Bruchdarstellung** und (2) die **Integraldarstellung**.
//!
//! Viele Funktionen in diesem Modul verarbeiten nur normale Zahlen.Die dec2flt-Routinen verwenden konservativ den universell korrekten langsamen Pfad (Algorithmus M) für sehr kleine und sehr große Zahlen.
//! Dieser Algorithmus benötigt nur next_float(), das Subnormen und Nullen verarbeitet.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Ein Helfer trait, um zu vermeiden, dass grundsätzlich der gesamte Konvertierungscode für `f32` und `f64` dupliziert wird.
///
/// Im Dokumentkommentar des übergeordneten Moduls erfahren Sie, warum dies erforderlich ist.
///
/// Sollte **niemals** für andere Typen implementiert oder außerhalb des dec2flt-Moduls verwendet werden.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Typ, der von `to_bits` und `from_bits` verwendet wird.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Führt eine rohe Transmutation in eine Ganzzahl durch.
    fn to_bits(self) -> Self::Bits;

    /// Führt eine Rohtransmutation aus einer Ganzzahl durch.
    fn from_bits(v: Self::Bits) -> Self;

    /// Gibt die Kategorie zurück, in die diese Nummer fällt.
    fn classify(self) -> FpCategory;

    /// Gibt die Mantisse, den Exponenten und das Vorzeichen als Ganzzahlen zurück.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekodiert den Schwimmer.
    fn unpack(self) -> Unpacked;

    /// Wirkt aus einer kleinen Ganzzahl, die genau dargestellt werden kann.
    /// Panic Wenn die Ganzzahl nicht dargestellt werden kann, stellt der andere Code in diesem Modul sicher, dass dies niemals zugelassen wird.
    fn from_int(x: u64) -> Self;

    /// Ruft den Wert 10 <sup>e</sup> aus einer vorberechneten Tabelle ab.
    /// Panics für `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Was der Name sagt.
    /// Es ist einfacher, Code hart zu schreiben, als Intrinsics zu jonglieren und zu hoffen, dass die LLVM-Konstante ihn faltet.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Eine konservative Grenze für die Dezimalstellen von Eingaben, die keinen Überlauf oder Null oder erzeugen können
    /// Subnormen.Wahrscheinlich der Dezimalexponent des maximalen Normalwerts, daher der Name.
    const MAX_NORMAL_DIGITS: usize;

    /// Wenn die höchstwertige Dezimalstelle einen größeren Stellenwert als diesen hat, wird die Zahl sicherlich auf unendlich gerundet.
    ///
    const INF_CUTOFF: i64;

    /// Wenn die höchstwertige Dezimalstelle einen kleineren Stellenwert als diesen hat, wird die Zahl sicherlich auf Null gerundet.
    ///
    const ZERO_CUTOFF: i64;

    /// Die Anzahl der Bits im Exponenten.
    const EXP_BITS: u8;

    /// Die Anzahl der Bits im Signifikanten,*einschließlich* des versteckten Bits.
    const SIG_BITS: u8;

    /// Die Anzahl der Bits im Signifikanten,*ohne* das versteckte Bit.
    const EXPLICIT_SIG_BITS: u8;

    /// Der maximale rechtliche Exponent in gebrochener Darstellung.
    const MAX_EXP: i16;

    /// Der minimale gesetzliche Exponent in der gebrochenen Darstellung, ausgenommen Subnormen.
    const MIN_EXP: i16;

    /// `MAX_EXP` für die integrale Darstellung, dh mit der angewendeten Verschiebung.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` codiert (dh mit Offset-Vorspannung)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` für die integrale Darstellung, dh mit der angewendeten Verschiebung.
    const MIN_EXP_INT: i16;

    /// Der maximal normalisierte Signifikant in integraler Darstellung.
    const MAX_SIG: u64;

    /// Der minimale normalisierte Signifikant in der Integraldarstellung.
    const MIN_SIG: u64;
}

// Meistens eine Problemumgehung für #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Gibt die Mantisse, den Exponenten und das Vorzeichen als Ganzzahlen zurück.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Exponentenvorspannung + Mantissenverschiebung
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ist sich nicht sicher, ob `as` auf allen Plattformen korrekt rundet.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Gibt die Mantisse, den Exponenten und das Vorzeichen als Ganzzahlen zurück.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Exponentenvorspannung + Mantissenverschiebung
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ist sich nicht sicher, ob `as` auf allen Plattformen korrekt rundet.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konvertiert einen `Fp` in den nächstgelegenen Maschinenschwimmertyp.
/// Behandelt keine subnormalen Ergebnisse.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ist 64 Bit, also hat xe eine Mantissenverschiebung von 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Runden Sie den 64-Bit-Signifikanten auf T::SIG_BITS-Bits mit der Hälfte bis gerade.
/// Behandelt keinen Exponentenüberlauf.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Passen Sie die Mantissenverschiebung an
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverse von `RawFloat::unpack()` für normalisierte Zahlen.
/// Panics, wenn der Signifikand oder Exponent für normalisierte Zahlen nicht gültig ist.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Entfernen Sie das versteckte Bit
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Stellen Sie den Exponenten auf Exponentenvorspannung und Mantissenverschiebung ein
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lassen Sie das Vorzeichenbit bei 0 ("+"), unsere Zahlen sind alle positiv
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstruieren Sie eine Subnormalität.Eine Mantisse von 0 ist erlaubt und konstruiert Null.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Der codierte Exponent ist 0, das Vorzeichenbit ist 0, daher müssen wir nur die Bits neu interpretieren.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Näherungsweise ein Bignum mit einem Fp.Runden innerhalb von 0.5 ULP mit Half-to-Even.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Wir schneiden alle Bits vor dem Index `start` ab, dh wir verschieben effektiv um einen Betrag von `start` nach rechts, sodass dies auch der Exponent ist, den wir benötigen.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Runde (half-to-even) abhängig von den abgeschnittenen Bits.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Findet die größte Gleitkommazahl, die streng kleiner als das Argument ist.
/// Behandelt keine Subnormalen, Nullen oder Exponentenunterläufe.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Suchen Sie die kleinste Gleitkommazahl, die streng größer als das Argument ist.
// Diese Operation ist gesättigt, dh next_float(inf) ==inf.
// Im Gegensatz zu den meisten Codes in diesem Modul verarbeitet diese Funktion Nullen, Subnormen und Unendlichkeiten.
// Wie jeder andere Code hier behandelt er jedoch nicht NaN und negative Zahlen.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Das scheint zu schön um wahr zu sein, aber es funktioniert.
        // 0.0 wird als All-Null-Wort codiert.Subnormen sind 0x000m ... m, wobei m die Mantisse ist.
        // Insbesondere ist die kleinste Subnormalität 0x0 ... 01 und die größte 0x000F ... F.
        // Die kleinste normale Zahl ist 0x0010 ... 0, daher funktioniert auch dieser Eckfall.
        // Wenn das Inkrement die Mantisse überläuft, erhöht das Übertragsbit den Exponenten wie gewünscht, und die Mantissenbits werden Null.
        // Aufgrund der Hidden-Bit-Konvention ist auch dies genau das, was wir wollen!
        // Schließlich ist f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}