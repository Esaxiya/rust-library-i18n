//! Dekodiert einen Gleitkommawert in einzelne Teile und Fehlerbereiche.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodierter endlicher Wert ohne Vorzeichen, so dass:
///
/// - Der ursprüngliche Wert entspricht `mant * 2^exp`.
///
/// - Jede Zahl von `(mant - minus)*2^exp` bis `(mant + plus)* 2^exp` wird auf den ursprünglichen Wert gerundet.
/// Der Bereich ist nur inklusive, wenn `inclusive` `true` ist.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Die skalierte Mantisse.
    pub mant: u64,
    /// Der untere Fehlerbereich.
    pub minus: u64,
    /// Der obere Fehlerbereich.
    pub plus: u64,
    /// Der gemeinsame Exponent in Basis 2.
    pub exp: i16,
    /// True, wenn der Fehlerbereich inklusive ist.
    ///
    /// In IEEE 754 ist dies der Fall, wenn die ursprüngliche Mantisse gerade war.
    pub inclusive: bool,
}

/// Dekodierter vorzeichenloser Wert.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Unendlichkeiten, entweder positiv oder negativ.
    Infinite,
    /// Null, entweder positiv oder negativ.
    Zero,
    /// Endliche Zahlen mit weiteren dekodierten Feldern.
    Finite(Decoded),
}

/// Ein Gleitkommatyp, der dekodiert werden kann.
pub trait DecodableFloat: RawFloat + Copy {
    /// Der minimale positive normalisierte Wert.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Gibt ein Vorzeichen (wahr, wenn negativ) und einen `FullDecoded`-Wert von der angegebenen Gleitkommazahl zurück.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // Nachbarn: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode Der Exponent bleibt immer erhalten, daher wird die Mantisse für Subnormen skaliert.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // Nachbarn: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // wobei maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // Nachbarn: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}