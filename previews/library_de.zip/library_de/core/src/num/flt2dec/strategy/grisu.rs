//! Rust Anpassung des Grisu3-Algorithmus, beschrieben unter "Schnelles und genaues Drucken von Gleitkommazahlen mit ganzen Zahlen" [^ 1].
//! Es verwendet ungefähr 1 KB vorberechnete Tabelle und ist wiederum für die meisten Eingaben sehr schnell.
//!
//! [^1]: Florian Loitsch.2010. Drucken von Gleitkommazahlen schnell und
//!   genau mit ganzen Zahlen.SIGPLAN Nicht.45, 6 (Juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// Weitere Informationen finden Sie in den Kommentaren in `format_shortest_opt`.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4・i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Gibt bei `x > 0` `(k, 10^k)` zurück, sodass `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Die kürzeste Modusimplementierung für Grisu.
///
/// Es gibt `None` zurück, wenn es sonst eine ungenaue Darstellung zurückgeben würde.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // Wir brauchen mindestens drei Bits zusätzliche Präzision

    // Beginnen Sie mit den normalisierten Werten mit dem gemeinsamen Exponenten
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // Finden Sie ein `cached = 10^minusk`, so dass `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // Da `plus` normalisiert ist, bedeutet dies `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`.
    // Aufgrund unserer Auswahl an `ALPHA` und `GAMMA` wird `plus * cached` in `[4, 2^32)` integriert.
    //
    // Es ist offensichtlich wünschenswert, `GAMMA - ALPHA` zu maximieren, damit wir nicht viele zwischengespeicherte Potenzen von 10 benötigen, aber es gibt einige Überlegungen:
    //
    //
    // 1. Wir möchten `floor(plus * cached)` innerhalb von `u32` halten, da es eine kostspielige Aufteilung erfordert.
    //    (Dies ist nicht wirklich vermeidbar, der Rest ist für die Genauigkeitsschätzung erforderlich.)
    // 2.
    // Der Rest von `floor(plus * cached)` wird wiederholt mit 10 multipliziert und sollte nicht überlaufen.
    //
    // der erste gibt `64 + GAMMA <= 32`, während der zweite `10 * 2^-ALPHA <= 2^64` gibt;
    // -60 und -32 ist der maximale Bereich mit dieser Einschränkung, und V8 verwendet sie auch.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // Skala fps.Dies ergibt den maximalen Fehler von 1 ulp (bewiesen aus Satz 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-tatsächlicher Bereich von Minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // über `minus`, `v` und `plus` sind *quantisierte* Näherungen (Fehler <1 ulp).
    // Da wir nicht wissen, dass der Fehler positiv oder negativ ist, verwenden wir zwei Näherungen mit gleichem Abstand und haben den maximalen Fehler von 2 ulps.
    //
    // Das "unsafe region" ist ein liberales Intervall, das wir zunächst generieren.
    // Das "safe region" ist ein konservatives Intervall, das wir nur akzeptieren.
    // Wir beginnen mit dem richtigen Repräsentanten in der unsicheren Region und versuchen, den Repräsentanten zu finden, der `v` am nächsten kommt, der sich auch in der sicheren Region befindet.
    // Wenn wir nicht können, geben wir auf.
    //
    let plus1 = plus.f + 1;
    // sei plus0 = plus.f, 1;//nur zur Erklärung sei minus0 = minus.f + 1;//nur zur Erklärung
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // gemeinsamer Exponent

    // Teilen Sie `plus1` in integrale und gebrochene Teile.
    // Integrierte Teile passen garantiert in u32, da die zwischengespeicherte Leistung `plus < 2^32` garantiert und normalisiertes `plus.f` aufgrund der Genauigkeitsanforderungen immer kleiner als `2^64 - 2^4` ist.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // Berechnen Sie den größten `10^max_kappa` nicht mehr als `plus1` (also `plus1 < 10^(max_kappa+1)`).
    // Dies ist eine Obergrenze von `kappa` unten.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Satz 6.2: wenn `k` die größte ganze Zahl st ist
    // `0 <= y mod 10^k <= y - x`,              dann ist `V = floor(y / 10^k) * 10^k` in `[x, y]` und eine der kürzesten Darstellungen (mit der minimalen Anzahl signifikanter Ziffern) in diesem Bereich.
    //
    //
    // Finden Sie die Ziffernlänge `kappa` zwischen `(minus1, plus1)` gemäß Satz 6.2.
    // Satz 6.2 kann übernommen werden, um `x` auszuschließen, indem stattdessen `y mod 10^k < y - x` benötigt wird.
    // (z. B. `x` =32000, `y` =32777; `kappa` =2, da "y mod 10 ^ 3=777 <y, x=777".) Der Algorithmus stützt sich auf die spätere Überprüfungsphase, um `y` auszuschließen.
    //
    let delta1 = plus1 - minus1;
    // sei delta1int=(delta1>> e) als usize;//nur zur Erklärung
    let delta1frac = delta1 & ((1 << e) - 1);

    // Rendern Sie integrale Teile, während Sie bei jedem Schritt die Genauigkeit überprüfen.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // noch zu rendernde Ziffern
    loop {
        // Wir müssen immer mindestens eine Ziffer als `plus1 >= 10^kappa`-Invarianten rendern:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (Daraus folgt, dass `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // Teilen Sie `remainder` durch `10^kappa`.beide sind mit `2^-e` skaliert.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; Wir haben das richtige `kappa` gefunden.
            let ten_kappa = (ten_kappa as u64) << e; // skaliere 10 ^ kappa zurück zum gemeinsamen Exponenten
            return round_and_weed(
                // SICHERHEIT: Wir haben diesen Speicher oben initialisiert.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // Brechen Sie die Schleife, wenn wir alle ganzzahligen Ziffern gerendert haben.
        // Die genaue Anzahl der Ziffern ist `max_kappa + 1` als `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // Invarianten wiederherstellen
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // Rendern von Bruchteilen, während bei jedem Schritt die Genauigkeit überprüft wird.
    // Dieses Mal verlassen wir uns auf wiederholte Multiplikationen, da die Division an Präzision verliert.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // Die nächste Ziffer sollte signifikant sein, da wir dies getestet haben, bevor wir Invarianten ausbrechen, wobei `m = max_kappa + 1` (Anzahl der Ziffern im integralen Teil):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // wird nicht überlaufen, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // Teilen Sie `remainder` durch `10^kappa`.
        // beide sind mit `2^e / 10^kappa` skaliert, so dass letzteres hier implizit ist.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // impliziter Teiler
            return round_and_weed(
                // SICHERHEIT: Wir haben diesen Speicher oben initialisiert.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // Invarianten wiederherstellen
        kappa -= 1;
        remainder = r;
    }

    // Wir haben alle wichtigen Ziffern von `plus1` generiert, sind uns aber nicht sicher, ob es die optimale ist.
    // Wenn beispielsweise `minus1` 3.14153 ... und `plus1` 3.14158 ... ist, gibt es 5 verschiedene kürzeste Darstellungen von 3.14154 bis 3.14158, aber wir haben nur die größte.
    // Wir müssen nacheinander die letzte Ziffer verringern und prüfen, ob dies der optimale Repräsentant ist.
    // Es gibt höchstens 9 Kandidaten (..1 bis ..9), das ist also ziemlich schnell.("rounding"-Phase)
    //
    // Die Funktion prüft, ob dieser "optimal"-Repr tatsächlich innerhalb der ulp-Bereiche liegt, und es ist auch möglich, dass der "second-to-optimal"-Repr aufgrund des Rundungsfehlers tatsächlich optimal ist.
    // In beiden Fällen wird `None` zurückgegeben.
    // ("weeding"-Phase)
    //
    // Alle Argumente hier werden mit dem gemeinsamen (aber impliziten) Wert `k` skaliert, so dass:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (und auch `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (und auch `threshold > plus1v` von früheren Invarianten)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // Erzeugen Sie innerhalb von 1.5 ulps zwei Annäherungen an `v` (tatsächlich `plus1 - v`).
        // Die resultierende Darstellung sollte beiden am nächsten kommen.
        //
        // Hier wird `plus1 - v` verwendet, da Berechnungen in Bezug auf `plus1` durchgeführt werden, um overflow/underflow zu vermeiden (daher die scheinbar vertauschten Namen).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // Verringern Sie die letzte Ziffer und halten Sie an der `v + 1 ulp` am nächsten liegenden Darstellung an.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // Wir arbeiten mit den ungefähren Ziffern `w(n)`, die anfänglich gleich `plus1 - plus1 % 10^kappa` sind.nach dem Ausführen des Schleifenkörpers `n` mal, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // Wir setzen `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (also `rest= plus1w(0)`), um die Überprüfungen zu vereinfachen.
            // Beachten Sie, dass `plus1w(n)` immer größer wird.
            //
            // Wir haben drei Bedingungen zu kündigen.Bei jedem von ihnen kann die Schleife nicht fortgesetzt werden, aber wir haben dann mindestens eine gültige Darstellung, von der bekannt ist, dass sie `v + 1 ulp` am nächsten kommt.
            // Wir werden sie der Kürze halber als TC1 bis TC3 bezeichnen.
            //
            // TC1: `w(n) <= v + 1 ulp`, dh dies ist der letzte Repräsentant, der der nächste sein kann.
            // Dies entspricht `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kombiniert mit TC2 (das prüft, ob `w(n+1)` is valid), verhindert dies den möglichen Überlauf bei der Berechnung von `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, dh der nächste Repräsentant rundet definitiv nicht auf `v`.
            // Dies entspricht `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // Die linke Seite kann überlaufen, aber wir kennen `threshold > plus1v`. Wenn also TC1 falsch ist, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` und wir können sicher testen, ob `threshold - plus1w(n) < 10^kappa` stattdessen ist.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, dh der nächste Repräsentant ist
            // nicht näher an `v + 1 ulp` als der aktuelle Repr.
            // Bei `z(n) = plus1v_up - plus1w(n)` wird dies zu `abs(z(n)) <= abs(z(n+1))`.Unter der Annahme, dass TC1 falsch ist, haben wir `z(n) > 0`.Wir müssen zwei Fälle berücksichtigen:
            //
            // - wenn `z(n+1) >= 0`: TC3 wird `z(n) <= z(n+1)`.
            // Wenn `plus1w(n)` zunimmt, sollte `z(n)` abnehmen, und dies ist eindeutig falsch.
            // - wenn `z(n+1) < 0`:
            //   - TC3a: Voraussetzung ist `plus1v_up < plus1w(n) + 10^kappa`.Angenommen, TC2 ist falsch, `threshold >= plus1w(n) + 10^kappa` kann nicht überlaufen.
            //   - TC3b: TC3 wird zu `z(n) <= -z(n+1)`, dh `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   Das negierte TC1 ergibt `plus1v_up > plus1w(n)`, sodass es in Kombination mit TC3a nicht über-oder unterlaufen kann.
            //
            // Folglich sollten wir aufhören, wenn `TC1 || TC2 || (TC3a && TC3b)`.das Folgende ist gleich seiner Umkehrung, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // Der kürzeste Repr kann nicht mit `0` enden
                plus1w += ten_kappa;
            }
        }

        // Überprüfen Sie, ob diese Darstellung auch der `v - 1 ulp` am nächsten kommt.
        //
        // Dies entspricht einfach den Abschlussbedingungen für `v + 1 ulp`, wobei stattdessen alle `plus1v_up` durch `plus1v_down` ersetzt werden.
        // Überlaufanalyse gilt gleichermaßen.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Jetzt haben wir die `v` am nächsten liegende Darstellung zwischen `plus1` und `minus1`.
        // Dies ist jedoch zu liberal, sodass wir `w(n)` ablehnen, das nicht zwischen `plus0` und `minus0` liegt, dh `plus1 - plus1w(n) <= minus0` oder `plus1 - plus1w(n) >= plus0`.
        // Wir nutzen die Fakten `threshold = plus1 - minus1` und `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Die kürzeste Modusimplementierung für Grisu mit Dragon Fallback.
///
/// Dies sollte in den meisten Fällen verwendet werden.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SICHERHEIT: Der Kreditprüfer ist nicht intelligent genug, um `buf` verwenden zu können
    // im zweiten branch, also waschen wir hier das Leben.
    // Wir verwenden `buf` jedoch nur wieder, wenn `format_shortest_opt` `None` zurückgegeben hat. Dies ist also in Ordnung.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Die genaue und feste Implementierung für Grisu.
///
/// Es gibt `None` zurück, wenn es sonst eine ungenaue Darstellung zurückgeben würde.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // Wir brauchen mindestens drei Bits zusätzliche Präzision
    assert!(!buf.is_empty());

    // `v` normalisieren und skalieren.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // Teilen Sie `v` in integrale und gebrochene Teile.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // Sowohl das alte `v` als auch das neue `v` (skaliert mit `10^-k`) weisen einen Fehler von <1 ulp auf (Satz 5.1).
    // Da wir nicht wissen, dass der Fehler positiv oder negativ ist, verwenden wir zwei Näherungen mit gleichem Abstand und haben den maximalen Fehler von 2 ulps (gleich im kürzesten Fall).
    //
    //
    // Das Ziel ist es, die genau gerundeten Ziffernreihen zu finden, die sowohl für `v - 1 ulp` als auch für `v + 1 ulp` gleich sind, damit wir ein Höchstmaß an Sicherheit haben.
    // Wenn dies nicht möglich ist, wissen wir nicht, welches die richtige Ausgabe für `v` ist, also geben wir auf und fallen zurück.
    //
    // `err` wird hier als `1 ulp * 2^e` definiert (wie bei ulp in `vfrac`), und wir werden es skalieren, wenn `v` skaliert wird.
    //
    //
    //
    let mut err = 1;

    // Berechnen Sie den größten `10^max_kappa` nicht mehr als `v` (also `v < 10^(max_kappa+1)`).
    // Dies ist eine Obergrenze von `kappa` unten.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Wenn wir mit der Beschränkung der letzten Ziffer arbeiten, müssen wir den Puffer vor dem eigentlichen Rendern verkürzen, um Doppelrundungen zu vermeiden.
    //
    // Beachten Sie, dass wir den Puffer erneut vergrößern müssen, wenn eine Aufrundung erfolgt!
    let len = if exp <= limit {
        // Hoppla, wir können nicht einmal *eine* Ziffer produzieren.
        // Dies ist möglich, wenn wir beispielsweise so etwas wie 9.5 haben und es auf 10 gerundet wird.
        //
        // Im Prinzip können wir `possibly_round` sofort mit einem leeren Puffer aufrufen, aber die Skalierung von `max_ten_kappa << e` um 10 kann zu einem Überlauf führen.
        //
        // Daher sind wir hier schlampig und erweitern den Fehlerbereich um den Faktor 10.
        // dies erhöht die falsch negative Rate, aber nur sehr,*sehr* leicht;
        // es kann nur merklich von Bedeutung sein, wenn die Mantisse größer als 60 Bit ist.
        //
        // SICHERHEIT: `len=0`, daher ist die Verpflichtung, diesen Speicher initialisiert zu haben, trivial.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // integrale Teile rendern.
    // Der Fehler ist nur ein Bruchteil, daher müssen wir ihn in diesem Teil nicht überprüfen.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // noch zu rendernde Ziffern
    loop {
        // Wir haben immer mindestens eine Ziffer, um Invarianten zu rendern:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (Daraus folgt, dass `remainder = vint % 10^(kappa+1)`)
        //
        //

        // Teilen Sie `remainder` durch `10^kappa`.beide sind mit `2^-e` skaliert.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // Ist der Puffer voll?Führen Sie den Rundungspass mit dem Rest aus.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SICHERHEIT: Wir haben `len` viele Bytes initialisiert.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // Brechen Sie die Schleife, wenn wir alle ganzzahligen Ziffern gerendert haben.
        // Die genaue Anzahl der Ziffern ist `max_kappa + 1` als `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // Invarianten wiederherstellen
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // Bruchteile rendern.
    //
    // Im Prinzip können wir bis zur letzten verfügbaren Ziffer fortfahren und die Richtigkeit überprüfen.
    // Leider arbeiten wir mit endlichen Ganzzahlen, daher benötigen wir ein Kriterium, um den Überlauf zu erkennen.
    // V8 verwendet `remainder > err`, was falsch wird, wenn sich die ersten `i`-signifikanten Ziffern von `v - 1 ulp` und `v` unterscheiden.
    // Dies lehnt jedoch zu viele ansonsten gültige Eingaben ab.
    //
    // Da die spätere Phase eine korrekte Überlauferkennung aufweist, verwenden wir stattdessen ein strengeres Kriterium:
    // Wir fahren fort, bis `err` `10^kappa / 2` überschreitet, sodass der Bereich zwischen `v - 1 ulp` und `v + 1 ulp` definitiv zwei oder mehr gerundete Darstellungen enthält.
    //
    // Dies entspricht den ersten beiden Vergleichen von `possibly_round` als Referenz.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // Invarianten, wobei `m = max_kappa + 1` (Anzahl der Ziffern im integralen Teil):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // wird nicht überlaufen, `2^e * 10 < 2^64`
        err *= 10; // wird nicht überlaufen, `err * 10 < 2^e * 5 < 2^64`

        // Teilen Sie `remainder` durch `10^kappa`.
        // beide sind mit `2^e / 10^kappa` skaliert, so dass letzteres hier implizit ist.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // Ist der Puffer voll?Führen Sie den Rundungspass mit dem Rest aus.
        if i == len {
            // SICHERHEIT: Wir haben `len` viele Bytes initialisiert.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // Invarianten wiederherstellen
        remainder = r;
    }

    // Eine weitere Berechnung ist nutzlos (`possibly_round` schlägt definitiv fehl), also geben wir auf.
    return None;

    // Wir haben alle angeforderten Ziffern von `v` generiert, die auch mit den entsprechenden Ziffern von `v - 1 ulp` identisch sein sollten.
    // Jetzt prüfen wir, ob es eine eindeutige Darstellung gibt, die sowohl von `v - 1 ulp` als auch von `v + 1 ulp` gemeinsam genutzt wird.Dies kann entweder für generierte Ziffern oder für die aufgerundete Version dieser Ziffern gleich sein.
    //
    // Wenn der Bereich mehrere Darstellungen derselben Länge enthält, können wir nicht sicher sein und sollten stattdessen `None` zurückgeben.
    //
    // Alle Argumente hier werden mit dem gemeinsamen (aber impliziten) Wert `k` skaliert, so dass:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SICHERHEIT: Die ersten `len`-Bytes von `buf` müssen initialisiert werden.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |::
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (Als Referenz gibt die gepunktete Linie den genauen Wert für mögliche Darstellungen in einer bestimmten Anzahl von Ziffern an.)
        //
        //
        // Der Fehler ist zu groß, als dass zwischen `v - 1 ulp` und `v + 1 ulp` mindestens drei Darstellungen möglich sind.
        // wir können nicht feststellen, welches richtig ist.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // Tatsächlich reicht 1/2 ulp aus, um zwei mögliche Darstellungen einzuführen.
        // (Denken Sie daran, dass wir eine eindeutige Darstellung für `v - 1 ulp` und `v + 1 ulp` benötigen.) Dies wird nicht überlaufen, wie `ulp < ten_kappa` von der ersten Prüfung an.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |: :
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // Wenn `v + 1 ulp` näher an der abgerundeten Darstellung liegt (die bereits in `buf` enthalten ist), können wir sicher zurückkehren.
        // Beachten Sie, dass `v - 1 ulp` * kleiner als die aktuelle Darstellung sein kann. Als `1 ulp < 10^kappa / 2` reicht diese Bedingung jedoch aus:
        // Der Abstand zwischen `v - 1 ulp` und der aktuellen Darstellung darf `10^kappa / 2` nicht überschreiten.
        //
        // Die Bedingung entspricht `remainder + ulp < 10^kappa / 2`.
        // Da dies leicht überlaufen kann, prüfen Sie zunächst, ob `remainder < 10^kappa / 2` vorhanden ist.
        // Wir haben bereits überprüft, dass `ulp < 10^kappa / 2`, solange `10^kappa` doch nicht übergelaufen ist, ist die zweite Überprüfung in Ordnung.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SICHERHEIT: Unser Anrufer hat diesen Speicher initialisiert.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------Rest------> |::
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // Wenn `v - 1 ulp` hingegen näher an der aufgerundeten Darstellung liegt, sollten wir aufrunden und zurückkehren.
        // Aus dem gleichen Grund müssen wir `v + 1 ulp` nicht überprüfen.
        //
        // Die Bedingung entspricht `remainder - ulp >= 10^kappa / 2`.
        // Wieder prüfen wir zuerst, ob `remainder > ulp` (beachten Sie, dass dies nicht `remainder >= ulp` ist, da `10^kappa` niemals Null ist).
        //
        // Beachten Sie auch, dass `remainder - ulp <= 10^kappa`, damit die zweite Prüfung nicht überläuft.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SICHERHEIT: Unser Anrufer muss diesen Speicher initialisiert haben.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // Fügen Sie nur dann eine zusätzliche Ziffer hinzu, wenn wir die feste Genauigkeit angefordert haben.
                // Wir müssen auch überprüfen, ob die zusätzliche Ziffer nur hinzugefügt werden kann, wenn der ursprüngliche Puffer leer war, wenn `exp == limit` (Fall edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SICHERHEIT: Wir und unser Anrufer haben diese Erinnerung initialisiert.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // Andernfalls sind wir zum Scheitern verurteilt (dh einige Werte zwischen `v - 1 ulp` und `v + 1 ulp` werden abgerundet und andere werden aufgerundet) und geben auf.
        //
        None
    }
}

/// Die genaue und feste Modusimplementierung für Grisu mit Dragon Fallback.
///
/// Dies sollte in den meisten Fällen verwendet werden.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SICHERHEIT: Der Kreditprüfer ist nicht intelligent genug, um `buf` verwenden zu können
    // im zweiten branch, also waschen wir hier das Leben.
    // Wir verwenden `buf` jedoch nur wieder, wenn `format_exact_opt` `None` zurückgegeben hat. Dies ist also in Ordnung.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}