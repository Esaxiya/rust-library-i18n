//! Fast direkte (aber leicht optimierte) Rust-Übersetzung von Abbildung 3 von "Schnelles und genaues Drucken von Gleitkommazahlen" [^ 1].
//!
//!
//! [^1]: Burger, RG und Dybvig, RK 1996. Drucken von Gleitkommazahlen
//!   schnell und genau.SIGPLAN Nicht.31, 5 (Mai 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// vorberechnete Arrays von "Ziffern" für 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// nur verwendbar bei `x < 16 * scale`;`scaleN` sollte `scale.mul_small(N)` sein
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Die kürzeste Modusimplementierung für Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // Es ist bekannt, dass die zu formatierende Nummer `v` wie folgt lautet:
    // - gleich `mant * 2^exp`;
    // - im ursprünglichen Typ `(mant - 2 *minus)* 2^exp` vorangestellt;und
    // - gefolgt von `(mant + 2 *plus)* 2^exp` im Originaltyp.
    //
    // Offensichtlich können `minus` und `plus` nicht Null sein.(Für Unendlichkeiten verwenden wir Werte außerhalb des Bereichs.) Außerdem gehen wir davon aus, dass mindestens eine Ziffer generiert wird, dh `mant` kann nicht auch Null sein.
    //
    // Dies bedeutet auch, dass jede Zahl zwischen `low = (mant - minus)*2^exp` und `high = (mant + plus)* 2^exp` genau dieser Gleitkommazahl zugeordnet wird, wobei die Grenzen enthalten sind, wenn die ursprüngliche Mantisse gerade war (dh `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` ist `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // Schätzen Sie `k_0` anhand der ursprünglichen Eingaben, die `10^(k_0-1) < high <= 10^(k_0+1)` erfüllen.
    // Das fest gebundene `k`, das `10^(k-1) < high <= 10^k` erfüllt, wird später berechnet.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // konvertieren Sie `{mant, plus, minus} * 2^exp` in die Bruchform, so dass:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // Teilen Sie `mant` durch `10^k`.jetzt `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // Korrektur bei `mant + plus > scale` (oder `>=`).
    // Wir ändern `scale` nicht wirklich, da wir stattdessen die anfängliche Multiplikation überspringen können.
    // Jetzt `scale < mant + plus <= scale * 10` und wir sind bereit, Ziffern zu generieren.
    //
    // Beachten Sie, dass `d[0]`*bei `scale - plus < mant < scale`* Null sein kann.
    // In diesem Fall wird sofort eine Aufrundungsbedingung (`up` unten) ausgelöst.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // entspricht der Skalierung von `scale` um 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // Cache `(2, 4, 8) * scale` zur Zifferngenerierung.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // Invarianten, bei denen `d[0..n-1]` Ziffern sind, die bisher generiert wurden:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (also `mant / scale < 10`) wobei `d[i..j]` eine Abkürzung für `d [i] * 10 ^ (ji) + ... ist.
        // + d [j-1] * 10 + d[j]`.

        // eine Ziffer generieren: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // Dies ist eine vereinfachte Beschreibung des modifizierten Dragon-Algorithmus.
        // Viele Zwischenableitungen und Vollständigkeitsargumente werden der Einfachheit halber weggelassen.
        //
        // Beginnen Sie mit geänderten Invarianten, da wir `n` aktualisiert haben:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // Angenommen, `d[0..n-1]` ist die kürzeste Darstellung zwischen `low` und `high`, dh `d[0..n-1]` erfüllt beide der folgenden Anforderungen, `d[0..n-2]` jedoch nicht:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (Bijektivität: Ziffern rund auf `v`);und
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (Die letzte Ziffer ist korrekt).
        //
        // Die zweite Bedingung vereinfacht sich zu `2 * mant <= scale`.
        // Das Lösen von Invarianten in Bezug auf `mant`, `low` und `high` ergibt eine einfachere Version der ersten Bedingung: `-plus < mant < minus`.
        // seit `-plus < 0 <= mant` haben wir die richtige kürzeste Darstellung bei `mant < minus` und `2 * mant <= scale`.
        // (Ersteres wird zu `mant <= minus`, wenn die ursprüngliche Mantisse gerade ist.)
        //
        // Wenn die Sekunde nicht gilt (`2 * mant> scale`), müssen wir die letzte Ziffer erhöhen.
        // Dies reicht aus, um diesen Zustand wiederherzustellen: Wir wissen bereits, dass die Zifferngenerierung `0 <= v / 10^(k-n) - d[0..n-1] < 1` garantiert.
        // In diesem Fall wird die erste Bedingung `-plus < mant - scale < minus`.
        // seit `mant < scale` nach der Generierung haben wir `scale < mant + plus`.
        // (Dies wird wieder `scale <= mant + plus`, wenn die ursprüngliche Mantisse gerade ist.)
        //
        // Zusamenfassend:
        // - Stoppen und runden Sie `down` (halten Sie die Ziffern unverändert), wenn `mant < minus` (oder `<=`).
        // - Stoppen und runden Sie `up` (erhöhen Sie die letzte Ziffer), wenn `scale < mant + plus` (oder `<=`).
        // - generiere weiter anders.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // Wir haben die kürzeste Darstellung, fahren Sie mit der Rundung fort

        // Stellen Sie die Invarianten wieder her.
        // Dadurch wird der Algorithmus immer beendet: `minus` und `plus` werden immer erhöht, aber `mant` wird modulo abgeschnitten. `scale` und `scale` sind fest.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // Das Aufrunden erfolgt, wenn i) nur die Aufrundungsbedingung ausgelöst wurde oder ii) beide Bedingungen ausgelöst wurden und das Aufbrechen des Gleichstands das Aufrunden bevorzugt.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // Wenn durch Aufrunden die Länge geändert wird, sollte sich auch der Exponent ändern.
        // Es scheint, dass diese Bedingung sehr schwer zu erfüllen ist (möglicherweise unmöglich), aber wir sind hier nur sicher und konsequent.
        //
        // SICHERHEIT: Wir haben diesen Speicher oben initialisiert.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SICHERHEIT: Wir haben diesen Speicher oben initialisiert.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Die genaue und feste Implementierung für Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // Schätzen Sie `k_0` anhand der ursprünglichen Eingaben, die `10^(k_0-1) < v <= 10^(k_0+1)` erfüllen.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // Teilen Sie `mant` durch `10^k`.jetzt `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // Fixup bei `mant + plus >= scale`, wo `plus / scale = 10^-buf.len() / 2`.
    // Um das Bignum mit fester Größe beizubehalten, verwenden wir tatsächlich `mant + floor(plus) >= scale`.
    // Wir ändern `scale` nicht wirklich, da wir stattdessen die anfängliche Multiplikation überspringen können.
    // Auch mit dem kürzesten Algorithmus kann `d[0]` Null sein, wird aber schließlich aufgerundet.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // entspricht der Skalierung von `scale` um 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // Wenn wir mit der Beschränkung der letzten Ziffer arbeiten, müssen wir den Puffer vor dem eigentlichen Rendern verkürzen, um Doppelrundungen zu vermeiden.
    //
    // Beachten Sie, dass wir den Puffer erneut vergrößern müssen, wenn eine Aufrundung erfolgt!
    let mut len = if k < limit {
        // Hoppla, wir können nicht einmal *eine* Ziffer produzieren.
        // Dies ist möglich, wenn wir beispielsweise so etwas wie 9.5 haben und es auf 10 gerundet wird.
        // Wir geben einen leeren Puffer zurück, mit Ausnahme des späteren Aufrundungsfalls, der bei `k == limit` auftritt und genau eine Ziffer erzeugen muss.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // Cache `(2, 4, 8) * scale` zur Zifferngenerierung.
        // (Dies kann teuer sein. Berechnen Sie sie daher nicht, wenn der Puffer leer ist.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // Die folgenden Ziffern sind alle Nullen. Wir hören hier auf. Versuchen Sie nicht, eine Rundung durchzuführen.Füllen Sie stattdessen die verbleibenden Ziffern aus.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SICHERHEIT: Wir haben diesen Speicher oben initialisiert.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // Aufrunden, wenn wir in der Mitte der Ziffern anhalten, wenn die folgenden Ziffern genau 5000 sind ..., überprüfen Sie die vorherige Ziffer und versuchen Sie, auf gerade zu runden (dh vermeiden Sie das Aufrunden, wenn die vorherige Ziffer gerade ist).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SICHERHEIT: `buf[len-1]` wird initialisiert.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // Wenn durch Aufrunden die Länge geändert wird, sollte sich auch der Exponent ändern.
        // Es wurde jedoch eine feste Anzahl von Ziffern angefordert. Ändern Sie daher nicht den Puffer ...
        // SICHERHEIT: Wir haben diesen Speicher oben initialisiert.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... es sei denn, wir wurden stattdessen um die feste Genauigkeit gebeten.
            // Wir müssen auch überprüfen, ob die zusätzliche Ziffer nur hinzugefügt werden kann, wenn der ursprüngliche Puffer leer war, wenn `k == limit` (Fall edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SICHERHEIT: Wir haben diesen Speicher oben initialisiert.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}