use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Ein Speicherzuweiser, der über das `#[global_allocator]`-Attribut als Standard für die Standardbibliothek registriert werden kann.
///
/// Einige der Methoden erfordern, dass ein Speicherblock *derzeit* über einen Allokator zugewiesen wird.Dies bedeutet, dass:
///
/// * Die Startadresse für diesen Speicherblock wurde zuvor durch einen vorherigen Aufruf einer Zuordnungsmethode wie `alloc` und zurückgegeben
///
/// * Der Speicherblock wurde anschließend nicht freigegeben, wobei die Zuweisung von Blöcken entweder durch Übergabe an eine Freigabemethode wie `dealloc` oder durch Übergabe an eine Neuzuweisungsmethode, die einen Nicht-Null-Zeiger zurückgibt, aufgehoben wird.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Der `GlobalAlloc` trait ist aus mehreren Gründen ein `unsafe` trait, und Implementierer müssen sicherstellen, dass sie diese Verträge einhalten:
///
/// * Es ist ein undefiniertes Verhalten, wenn sich globale Allokatoren abwickeln.Diese Einschränkung kann im future aufgehoben werden, aber derzeit kann ein panic von einer dieser Funktionen zu Speichersicherheit führen.
///
/// * `Layout` Abfragen und Berechnungen müssen im Allgemeinen korrekt sein.Aufrufer dieses trait dürfen sich auf die für jede Methode definierten Verträge verlassen, und die Implementierer müssen sicherstellen, dass diese Verträge wahr bleiben.
///
/// * Sie können sich möglicherweise nicht darauf verlassen, dass Zuweisungen tatsächlich stattfinden, selbst wenn die Quelle explizite Heap-Zuweisungen enthält.
/// Der Optimierer erkennt möglicherweise nicht verwendete Zuordnungen, die er entweder vollständig entfernen oder in den Stapel verschieben kann, und ruft daher niemals den Zuweiser auf.
/// Das Optimierungsprogramm kann ferner davon ausgehen, dass die Zuweisung unfehlbar ist, sodass Code, der früher aufgrund von Zuordnungsfehlern fehlschlug, plötzlich funktioniert, da das Optimierungsprogramm die Notwendigkeit einer Zuweisung umgangen hat.
/// Genauer gesagt ist das folgende Codebeispiel nicht stichhaltig, unabhängig davon, ob Ihr benutzerdefinierter Zuweiser das Zählen der Anzahl der Zuordnungen zulässt.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Beachten Sie, dass die oben genannten Optimierungen nicht die einzige Optimierung sind, die angewendet werden kann.Sie können sich im Allgemeinen nicht auf Heap-Zuweisungen verlassen, wenn diese entfernt werden können, ohne das Programmverhalten zu ändern.
///   Ob Zuweisungen stattfinden oder nicht, ist nicht Teil des Programmverhaltens, selbst wenn dies über einen Zuweiser erkannt werden könnte, der Zuordnungen durch Drucken verfolgt oder auf andere Weise Nebenwirkungen hat.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Ordnen Sie den Speicher wie vom angegebenen `layout` beschrieben zu.
    ///
    /// Gibt einen Zeiger auf den neu zugewiesenen Speicher zurück oder null, um einen Zuordnungsfehler anzuzeigen.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher, da ein undefiniertes Verhalten auftreten kann, wenn der Aufrufer nicht sicherstellt, dass `layout` eine Größe ungleich Null hat.
    ///
    /// (Erweiterungs-Subtraits können spezifischere Verhaltensgrenzen festlegen, z. B. eine Sentinel-Adresse oder einen Nullzeiger als Antwort auf eine Zuweisungsanforderung mit einer Größe von Null garantieren.)
    ///
    /// Der zugewiesene Speicherblock kann initialisiert werden oder nicht.
    ///
    /// # Errors
    ///
    /// Die Rückgabe eines Nullzeigers zeigt an, dass entweder der Speicher erschöpft ist oder `layout` die Größen-oder Ausrichtungsbeschränkungen dieses Allokators nicht erfüllt.
    ///
    /// Implementierungen werden empfohlen, bei Speicherauslastung null zurückzugeben, anstatt abzubrechen. Dies ist jedoch keine strenge Anforderung.
    /// (Insbesondere: Es ist *legal*, dieses trait auf einer zugrunde liegenden nativen Zuordnungsbibliothek zu implementieren, die bei Speicherauslastung abgebrochen wird.)
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Zuordnungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Geben Sie den Speicherblock am angegebenen `ptr`-Zeiger mit dem angegebenen `layout` frei.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher, da ein undefiniertes Verhalten auftreten kann, wenn der Anrufer nicht alle folgenden Punkte sicherstellt:
    ///
    ///
    /// * `ptr` muss einen Speicherblock bezeichnen, der aktuell über diesen Allokator zugewiesen ist,
    ///
    /// * `layout` muss dasselbe Layout sein, das zum Zuweisen dieses Speicherblocks verwendet wurde.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Verhält sich wie `alloc`, stellt aber auch sicher, dass der Inhalt vor der Rückgabe auf Null gesetzt wird.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist aus den gleichen Gründen wie `alloc` nicht sicher.
    /// Es wird jedoch garantiert, dass der zugewiesene Speicherblock initialisiert wird.
    ///
    /// # Errors
    ///
    /// Die Rückgabe eines Nullzeigers zeigt an, dass entweder der Speicher erschöpft ist oder `layout` nicht wie in `alloc` die Größen-oder Ausrichtungsbeschränkungen des Allokators erfüllt.
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Zuordnungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SICHERHEIT: Der Sicherheitsvertrag für `alloc` muss vom Anrufer eingehalten werden.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SICHERHEIT: Als die Zuordnung erfolgreich war, wurde die Region von `ptr`
            // der Größe `size` ist garantiert für Schreibvorgänge gültig.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Verkleinern oder vergrößern Sie einen Speicherblock auf das angegebene `new_size`.
    /// Der Block wird durch den angegebenen `ptr`-Zeiger und `layout` beschrieben.
    ///
    /// Wenn dies einen Nicht-Null-Zeiger zurückgibt, wurde das Eigentum an dem von `ptr` referenzierten Speicherblock auf diesen Allokator übertragen.
    /// Der Speicher wurde möglicherweise freigegeben oder nicht und sollte als unbrauchbar angesehen werden (es sei denn, er wurde natürlich über den Rückgabewert dieser Methode erneut an den Anrufer übertragen).
    /// Der neue Speicherblock wird mit `layout` zugewiesen, aber mit `size` auf `new_size` aktualisiert.
    /// Dieses neue Layout sollte verwendet werden, wenn die Zuordnung des neuen Speicherblocks zu `dealloc` aufgehoben wird.
    /// Der Bereich `0..min(layout.size(), new_size) `des neuen Speicherblocks hat garantiert die gleichen Werte wie der ursprüngliche Block.
    ///
    /// Wenn diese Methode null zurückgibt, wurde der Besitz des Speicherblocks nicht auf diesen Allokator übertragen, und der Inhalt des Speicherblocks bleibt unverändert.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher, da ein undefiniertes Verhalten auftreten kann, wenn der Anrufer nicht alle folgenden Punkte sicherstellt:
    ///
    /// * `ptr` muss aktuell über diesen Allokator vergeben werden,
    ///
    /// * `layout` muss das gleiche Layout sein, das zum Zuweisen dieses Speicherblocks verwendet wurde.
    ///
    /// * `new_size` muss größer als Null sein.
    ///
    /// * `new_size`, Wenn es auf das nächste Vielfache von `layout.align()` aufgerundet wird, darf es nicht überlaufen (dh der gerundete Wert muss kleiner als `usize::MAX` sein).
    ///
    /// (Erweiterungs-Subtraits können spezifischere Verhaltensgrenzen festlegen, z. B. eine Sentinel-Adresse oder einen Nullzeiger als Antwort auf eine Zuweisungsanforderung mit einer Größe von Null garantieren.)
    ///
    /// # Errors
    ///
    /// Gibt null zurück, wenn das neue Layout die Größen-und Ausrichtungsbeschränkungen des Allokators nicht erfüllt oder wenn die Neuzuweisung anderweitig fehlschlägt.
    ///
    /// Implementierungen werden empfohlen, bei Speicherauslastung null zurückzugeben, anstatt in Panik zu geraten oder abzubrechen. Dies ist jedoch keine strenge Anforderung.
    /// (Insbesondere: Es ist *legal*, dieses trait auf einer zugrunde liegenden nativen Zuordnungsbibliothek zu implementieren, die bei Speicherauslastung abgebrochen wird.)
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Neuzuweisungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SICHERHEIT: Der Anrufer muss sicherstellen, dass der `new_size` nicht überläuft.
        // `layout.align()` kommt von einem `Layout` und ist somit garantiert gültig.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SICHERHEIT: Der Anrufer muss sicherstellen, dass `new_layout` größer als Null ist.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SICHERHEIT: Der zuvor zugewiesene Block kann den neu zugewiesenen Block nicht überlappen.
            // Der Sicherheitsvertrag für `dealloc` muss vom Anrufer eingehalten werden.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}