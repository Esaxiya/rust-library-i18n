use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Während diese Funktion an einer Stelle verwendet wird und ihre Implementierung inline sein könnte, haben die vorherigen Versuche rustc langsamer gemacht:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout eines Speicherblocks.
///
/// Eine Instanz von `Layout` beschreibt ein bestimmtes Speicherlayout.
/// Sie bauen einen `Layout` als Eingabe für einen Allokator auf.
///
/// Allen Layouts ist eine Größe und eine Zweierpotenz-Ausrichtung zugeordnet.
///
/// (Beachten Sie, dass Layouts *nicht* für eine Größe ungleich Null erforderlich sind, obwohl `GlobalAlloc` erfordert, dass alle Speicheranforderungen eine Größe ungleich Null haben.
/// Ein Anrufer muss entweder sicherstellen, dass solche Bedingungen erfüllt sind, bestimmte Allokatoren mit geringeren Anforderungen verwenden oder die mildere `Allocator`-Schnittstelle verwenden.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // Größe des angeforderten Speicherblocks, gemessen in Bytes.
    size_: usize,

    // Ausrichtung des angeforderten Speicherblocks, gemessen in Bytes.
    // Wir stellen sicher, dass dies immer eine Zweierpotenz ist, da APIs wie `posix_memalign` dies erfordern und es eine vernünftige Einschränkung ist, Layoutkonstruktoren aufzuerlegen.
    //
    //
    // (Analog benötigen wir jedoch nicht `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruiert ein `Layout` aus einem bestimmten `size` und `align` oder gibt `LayoutError` zurück, wenn eine der folgenden Bedingungen nicht erfüllt ist:
    ///
    /// * `align` darf nicht Null sein,
    ///
    /// * `align` muss eine Zweierpotenz sein,
    ///
    /// * `size`, Wenn es auf das nächste Vielfache von `align` aufgerundet wird, darf es nicht überlaufen (dh der gerundete Wert muss kleiner oder gleich `usize::MAX` sein).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Zweierpotenz bedeutet ausrichten!=0.)

        // Aufgerundete Größe ist:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Wir wissen von oben, dass ausrichten!=0.
        // Wenn das Hinzufügen (Ausrichten, 1) nicht überläuft, ist das Aufrunden in Ordnung.
        //
        // Umgekehrt subtrahiert&-masking mit! (Align, 1) nur Bits niedriger Ordnung.
        // Wenn also mit der Summe ein Überlauf auftritt, kann die&-Maske nicht genug subtrahieren, um diesen Überlauf rückgängig zu machen.
        //
        //
        // Oben impliziert, dass die Überprüfung auf Summationsüberlauf sowohl notwendig als auch ausreichend ist.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SICHERHEIT: Die Bedingungen für `from_size_align_unchecked` waren
        // oben geprüft.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Erstellt ein Layout unter Umgehung aller Überprüfungen.
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher, da sie die Voraussetzungen von [`Layout::from_size_align`] nicht überprüft.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SICHERHEIT: Der Anrufer muss sicherstellen, dass `align` größer als Null ist.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Die Mindestgröße in Byte für einen Speicherblock dieses Layouts.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Die minimale Byte-Ausrichtung für einen Speicherblock dieses Layouts.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruiert einen `Layout`, der zum Halten eines Werts vom Typ `T` geeignet ist.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SICHERHEIT: Die Ausrichtung wird durch Rust als Zweierpotenz und garantiert
        // Die Kombination aus Größe und Ausrichtung passt garantiert in unseren Adressraum.
        // Verwenden Sie daher hier den nicht aktivierten Konstruktor, um zu vermeiden, dass Code panics eingefügt wird, wenn er nicht gut genug optimiert ist.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Erzeugt ein Layout, das einen Datensatz beschreibt, der zum Zuweisen der Hintergrundstruktur für `T` verwendet werden kann (dies kann ein trait oder ein anderer Typ ohne Größe wie ein Slice sein).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SICHERHEIT: Siehe Begründung in `new`, warum hier die unsichere Variante verwendet wird
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Erzeugt ein Layout, das einen Datensatz beschreibt, der zum Zuweisen der Hintergrundstruktur für `T` verwendet werden kann (dies kann ein trait oder ein anderer Typ ohne Größe wie ein Slice sein).
    ///
    /// # Safety
    ///
    /// Diese Funktion kann nur sicher aufgerufen werden, wenn die folgenden Bedingungen erfüllt sind:
    ///
    /// - Wenn `T` `Sized` ist, kann diese Funktion immer sicher aufgerufen werden.
    /// - Wenn der nicht dimensionierte Schwanz von `T` ist:
    ///     - Bei einem [slice] muss die Länge des Slice-Endes eine initialisierte Ganzzahl sein, und die Größe des *gesamten Werts*(dynamische Schwanzlänge + statisch großes Präfix) muss in `isize` passen.
    ///     - a [trait object], dann muss der vtable-Teil des Zeigers auf eine gültige vtable für den Typ `T` zeigen, der durch eine nicht dimensionierte Koersion erfasst wurde, und die Größe des *gesamten Werts*(dynamische Schwanzlänge + statisch dimensioniertes Präfix) muss in `isize` passen.
    ///
    ///     - ein (unstable) [extern type], dann ist diese Funktion immer sicher aufzurufen, kann aber panic oder auf andere Weise den falschen Wert zurückgeben, da das Layout des externen Typs nicht bekannt ist.
    ///     Dies ist das gleiche Verhalten wie bei [`Layout::for_value`] bei einem Verweis auf ein externes Tail.
    ///     - Andernfalls darf diese Funktion konservativ nicht aufgerufen werden.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SICHERHEIT: Wir geben die Voraussetzungen dieser Funktionen an den Anrufer weiter
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SICHERHEIT: Siehe Begründung in `new`, warum hier die unsichere Variante verwendet wird
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Erstellt einen `NonNull`, der baumelt, aber für dieses Layout gut ausgerichtet ist.
    ///
    /// Beachten Sie, dass der Zeigerwert möglicherweise einen gültigen Zeiger darstellt. Dies bedeutet, dass dieser Wert nicht als "not yet initialized"-Sentinel-Wert verwendet werden darf.
    /// Typen, die träge zuweisen, müssen die Initialisierung auf andere Weise verfolgen.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SICHERHEIT: Die Ausrichtung ist garantiert ungleich Null
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Erstellt ein Layout, das den Datensatz beschreibt, der einen Wert des gleichen Layouts wie `self` enthalten kann, der jedoch auch an der Ausrichtung `align` ausgerichtet ist (gemessen in Byte).
    ///
    ///
    /// Wenn `self` bereits die vorgeschriebene Ausrichtung erfüllt, wird `self` zurückgegeben.
    ///
    /// Beachten Sie, dass diese Methode der Gesamtgröße keine Auffüllung hinzufügt, unabhängig davon, ob das zurückgegebene Layout eine andere Ausrichtung aufweist.
    /// Mit anderen Worten, wenn `K` die Größe 16 hat, hat `K.align_to(32)`*immer noch* die Größe 16.
    ///
    /// Gibt einen Fehler zurück, wenn die Kombination von `self.size()` und dem angegebenen `align` die in [`Layout::from_size_align`] aufgeführten Bedingungen verletzt.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Gibt die Auffüllmenge zurück, die nach `self` eingefügt werden muss, um sicherzustellen, dass die folgende Adresse `align` erfüllt (gemessen in Byte).
    ///
    /// Wenn `self.size()` beispielsweise 9 ist, gibt `self.padding_needed_for(4)` 3 zurück, da dies die minimale Anzahl von Auffüllbytes ist, die erforderlich sind, um eine 4-ausgerichtete Adresse zu erhalten (vorausgesetzt, der entsprechende Speicherblock beginnt bei einer 4-ausgerichteten Adresse).
    ///
    ///
    /// Der Rückgabewert dieser Funktion hat keine Bedeutung, wenn `align` keine Zweierpotenz ist.
    ///
    /// Beachten Sie, dass für die Nützlichkeit des zurückgegebenen Werts `align` kleiner oder gleich der Ausrichtung der Startadresse für den gesamten zugewiesenen Speicherblock sein muss.Eine Möglichkeit, diese Einschränkung zu erfüllen, besteht darin, `align <= self.align()` sicherzustellen.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Der aufgerundete Wert ist:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // und dann geben wir den Polsterungsunterschied zurück: `len_rounded_up - len`.
        //
        // Wir verwenden durchweg modulare Arithmetik:
        //
        // 1. Align ist garantiert> 0, also ist Align, 1 immer gültig.
        //
        // 2.
        // `len + align - 1` kann höchstens `align - 1` überlaufen, daher stellt die&-Maske mit `!(align - 1)` sicher, dass `len_rounded_up` im Falle eines Überlaufs selbst 0 ist.
        //
        //    Somit ergibt die zurückgegebene Auffüllung, wenn sie zu `len` hinzugefügt wird, 0, was die Ausrichtung `align` trivial erfüllt.
        //
        // (Natürlich sollten Versuche, Speicherblöcke zuzuweisen, deren Größe und Füllungsüberlauf auf die oben beschriebene Weise überlaufen, dazu führen, dass der Zuweiser ohnehin einen Fehler liefert.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Erstellt ein Layout, indem die Größe dieses Layouts auf ein Vielfaches der Ausrichtung des Layouts gerundet wird.
    ///
    ///
    /// Dies entspricht dem Hinzufügen des Ergebnisses von `padding_needed_for` zur aktuellen Größe des Layouts.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Dies kann nicht überlaufen.Zitat aus der Invariante von Layout:
        // > `size`, wenn auf das nächste Vielfache von `align` aufgerundet,
        // > darf nicht überlaufen (dh der gerundete Wert muss kleiner sein als
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Erstellt ein Layout, das den Datensatz für `n`-Instanzen von `self` beschreibt, mit einem geeigneten Abstand zwischen den einzelnen Instanzen, um sicherzustellen, dass jeder Instanz die gewünschte Größe und Ausrichtung zugewiesen wird.
    /// Gibt bei Erfolg `(k, offs)` zurück, wobei `k` das Layout des Arrays und `offs` der Abstand zwischen dem Anfang jedes Elements im Array ist.
    ///
    /// Gibt bei arithmetischem Überlauf `LayoutError` zurück.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Dies kann nicht überlaufen.Zitat aus der Invariante von Layout:
        // > `size`, wenn auf das nächste Vielfache von `align` aufgerundet,
        // > darf nicht überlaufen (dh der gerundete Wert muss kleiner sein als
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SICHERHEIT: self.align ist bereits als gültig bekannt und alloc_size wurde verwendet
        // schon gepolstert.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Erstellt ein Layout, das den Datensatz für `self` gefolgt von `next` beschreibt, einschließlich aller erforderlichen Auffüllungen, um sicherzustellen, dass `next` richtig ausgerichtet ist, jedoch *keine nachfolgenden Auffüllungen*.
    ///
    /// Um dem C-Darstellungslayout `repr(C)` zu entsprechen, sollten Sie `pad_to_align` aufrufen, nachdem Sie das Layout mit allen Feldern erweitert haben.
    /// (Es gibt keine Möglichkeit, das Standard-Darstellungslayout `repr(Rust)`, as it is unspecified.) für Rust anzupassen
    ///
    /// Beachten Sie, dass die Ausrichtung des resultierenden Layouts maximal der von `self` und `next` entspricht, um die Ausrichtung beider Teile sicherzustellen.
    ///
    /// Gibt `Ok((k, offset))` zurück, wobei `k` das Layout des verketteten Datensatzes und `offset` die relative Position des Starts des in den verketteten Datensatz eingebetteten `next` in Byte ist (vorausgesetzt, der Datensatz selbst beginnt bei Offset 0).
    ///
    ///
    /// Gibt bei arithmetischem Überlauf `LayoutError` zurück.
    ///
    /// # Examples
    ///
    /// So berechnen Sie das Layout einer `#[repr(C)]`-Struktur und die Offsets der Felder aus den Layouts ihrer Felder:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Denken Sie daran, mit `pad_to_align` abzuschließen!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // Testen Sie, ob es funktioniert
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Erstellt ein Layout, das den Datensatz für `n`-Instanzen von `self` beschreibt, ohne Auffüllung zwischen den einzelnen Instanzen.
    ///
    /// Beachten Sie, dass `repeat_packed` im Gegensatz zu `repeat` nicht garantiert, dass die wiederholten Instanzen von `self` richtig ausgerichtet werden, selbst wenn eine bestimmte Instanz von `self` richtig ausgerichtet ist.
    /// Mit anderen Worten, wenn das von `repeat_packed` zurückgegebene Layout zum Zuweisen eines Arrays verwendet wird, kann nicht garantiert werden, dass alle Elemente im Array ordnungsgemäß ausgerichtet sind.
    ///
    /// Gibt bei arithmetischem Überlauf `LayoutError` zurück.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Erstellt ein Layout, das den Datensatz für `self` beschreibt, gefolgt von `next`, ohne zusätzliche Auffüllung zwischen den beiden.
    /// Da keine Polsterung eingefügt wird, ist die Ausrichtung von `next` irrelevant und wird *überhaupt* nicht in das resultierende Layout einbezogen.
    ///
    ///
    /// Gibt bei arithmetischem Überlauf `LayoutError` zurück.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Erstellt ein Layout, das den Datensatz für einen `[T; n]` beschreibt.
    ///
    /// Gibt bei arithmetischem Überlauf `LayoutError` zurück.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Die Parameter, die `Layout::from_size_align` oder einem anderen `Layout`-Konstruktor zugewiesen wurden, erfüllen nicht die dokumentierten Einschränkungen.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (Wir brauchen dies für Downstream-Impl von trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}