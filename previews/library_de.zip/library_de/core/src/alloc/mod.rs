//! Speicherzuweisungs-APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Der `AllocError`-Fehler weist auf einen Zuordnungsfehler hin, der auf eine Erschöpfung der Ressourcen oder auf einen Fehler beim Kombinieren der angegebenen Eingabeargumente mit diesem Zuweiser zurückzuführen sein kann.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (Wir brauchen dies für Downstream-Impl von trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Eine Implementierung von `Allocator` kann beliebige Datenblöcke, die über [`Layout`][] beschrieben werden, zuweisen, vergrößern, verkleinern und freigeben.
///
/// `Allocator` wurde für die Implementierung in ZSTs, Referenzen oder intelligenten Zeigern entwickelt, da ein Allokator wie `MyAlloc([u8; N])` nicht verschoben werden kann, ohne die Zeiger auf den zugewiesenen Speicher zu aktualisieren.
///
/// Im Gegensatz zu [`GlobalAlloc`][] sind in `Allocator` Zuordnungen mit der Größe Null zulässig.
/// Wenn ein zugrunde liegender Allokator dies nicht unterstützt (wie jemalloc) oder einen Nullzeiger (wie `libc::malloc`) zurückgibt, muss dies von der Implementierung abgefangen werden.
///
/// ### Derzeit zugewiesener Speicher
///
/// Einige der Methoden erfordern, dass ein Speicherblock *derzeit* über einen Allokator zugewiesen wird.Dies bedeutet, dass:
///
/// * Die Startadresse für diesen Speicherblock wurde zuvor von [`allocate`], [`grow`] oder [`shrink`] zurückgegeben
///
/// * Der Speicherblock wurde anschließend nicht freigegeben, wobei Blöcke entweder direkt freigegeben werden, indem sie an [`deallocate`] übergeben werden, oder geändert wurden, indem sie an [`grow`] oder [`shrink`] übergeben werden, die `Ok` zurückgeben.
///
/// Wenn `grow` oder `shrink` `Err` zurückgegeben haben, bleibt der übergebene Zeiger gültig.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Speicheranpassung
///
/// Einige der Methoden erfordern, dass ein Layout zu einem Speicherblock passt.
/// Für ein Layout für "fit" bedeutet ein Speicherblock (oder für einen Speicherblock für "fit" ein Layout), dass die folgenden Bedingungen erfüllt sein müssen:
///
/// * Der Block muss mit der gleichen Ausrichtung wie [`layout.align()`] und zugewiesen werden
///
/// * Der mitgelieferte [`layout.size()`] muss in den Bereich `min ..= max` fallen, wobei:
///   - `min` ist die Größe des Layouts, das zuletzt zum Zuweisen des Blocks verwendet wurde, und
///   - `max` ist die letzte tatsächliche Größe, die von [`allocate`], [`grow`] oder [`shrink`] zurückgegeben wird.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Von einem Allokator zurückgegebene Speicherblöcke müssen auf einen gültigen Speicher verweisen und ihre Gültigkeit behalten, bis die Instanz und alle ihre Klone gelöscht werden.
///
/// * Das Klonen oder Verschieben des Allokators darf die von diesem Allokator zurückgegebenen Speicherblöcke nicht ungültig machen.Ein geklonter Allokator muss sich wie der gleiche Allokator verhalten, und
///
/// * Jeder Zeiger auf einen Speicherblock, der [*currently allocated*] ist, kann an jede andere Methode des Allokators übergeben werden.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Versuche, einen Speicherblock zuzuweisen.
    ///
    /// Gibt bei Erfolg einen [`NonNull<[u8]>`][NonNull] zurück, der die Größen-und Ausrichtungsgarantien von `layout` erfüllt.
    ///
    /// Der zurückgegebene Block hat möglicherweise eine größere Größe als von `layout.size()` angegeben und kann initialisiert werden oder nicht.
    ///
    /// # Errors
    ///
    /// Die Rückgabe von `Err` zeigt an, dass entweder der Speicher erschöpft ist oder `layout` die Größen-oder Ausrichtungsbeschränkungen des Allokators nicht erfüllt.
    ///
    /// Implementierungen werden empfohlen, `Err` bei Speicherauslastung zurückzugeben, anstatt in Panik zu geraten oder abzubrechen. Dies ist jedoch keine strenge Anforderung.
    /// (Insbesondere: Es ist *legal*, dieses trait auf einer zugrunde liegenden nativen Zuordnungsbibliothek zu implementieren, die bei Speicherauslastung abgebrochen wird.)
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Zuordnungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Verhält sich wie `allocate`, stellt aber auch sicher, dass der zurückgegebene Speicher mit Null initialisiert ist.
    ///
    /// # Errors
    ///
    /// Die Rückgabe von `Err` zeigt an, dass entweder der Speicher erschöpft ist oder `layout` die Größen-oder Ausrichtungsbeschränkungen des Allokators nicht erfüllt.
    ///
    /// Implementierungen werden empfohlen, `Err` bei Speicherauslastung zurückzugeben, anstatt in Panik zu geraten oder abzubrechen. Dies ist jedoch keine strenge Anforderung.
    /// (Insbesondere: Es ist *legal*, dieses trait auf einer zugrunde liegenden nativen Zuordnungsbibliothek zu implementieren, die bei Speicherauslastung abgebrochen wird.)
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Zuordnungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SICHERHEIT: `alloc` gibt einen gültigen Speicherblock zurück
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Hebt die Zuordnung des von `ptr` referenzierten Speichers auf.
    ///
    /// # Safety
    ///
    /// * `ptr` muss über diesen Allokator einen Speicherblock [*currently allocated*] bezeichnen, und
    /// * `layout` muss [*fit*] diesen Speicherblock.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Versuche, den Speicherblock zu erweitern.
    ///
    /// Gibt einen neuen [`NonNull<[u8]>`][NonNull] zurück, der einen Zeiger und die tatsächliche Größe des zugewiesenen Speichers enthält.Der Zeiger eignet sich zum Speichern von Daten, die von `new_layout` beschrieben werden.
    /// Um dies zu erreichen, kann der Allokator die von `ptr` referenzierte Zuordnung erweitern, um sie an das neue Layout anzupassen.
    ///
    /// Wenn dies `Ok` zurückgibt, wurde das Eigentum an dem von `ptr` referenzierten Speicherblock auf diesen Allokator übertragen.
    /// Der Speicher wurde möglicherweise freigegeben oder nicht und sollte als unbrauchbar angesehen werden, es sei denn, er wurde über den Rückgabewert dieser Methode erneut an den Anrufer übertragen.
    ///
    /// Wenn diese Methode `Err` zurückgibt, wurde der Besitz des Speicherblocks nicht auf diesen Allokator übertragen, und der Inhalt des Speicherblocks bleibt unverändert.
    ///
    /// # Safety
    ///
    /// * `ptr` muss über diesen Allokator einen Speicherblock [*currently allocated*] bezeichnen.
    /// * `old_layout` muss [*fit*] diesen Speicherblock (Das `new_layout`-Argument muss nicht passen.).
    /// * `new_layout.size()` muss größer oder gleich `old_layout.size()` sein.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Gibt `Err` zurück, wenn das neue Layout nicht den Größen-und Ausrichtungsbeschränkungen des Allokators des Allokators entspricht oder wenn das Wachstum anderweitig fehlschlägt.
    ///
    /// Implementierungen werden empfohlen, `Err` bei Speicherauslastung zurückzugeben, anstatt in Panik zu geraten oder abzubrechen. Dies ist jedoch keine strenge Anforderung.
    /// (Insbesondere: Es ist *legal*, dieses trait auf einer zugrunde liegenden nativen Zuordnungsbibliothek zu implementieren, die bei Speicherauslastung abgebrochen wird.)
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Zuordnungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SICHERHEIT: weil `new_layout.size()` größer oder gleich sein muss
        // `old_layout.size()`, Sowohl die alte als auch die neue Speicherzuordnung gelten für Lese-und Schreibvorgänge für `old_layout.size()`-Bytes.
        // Da die alte Zuordnung noch nicht freigegeben wurde, kann sie `new_ptr` nicht überlappen.
        // Somit ist der Anruf bei `copy_nonoverlapping` sicher.
        // Der Sicherheitsvertrag für `dealloc` muss vom Anrufer eingehalten werden.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Verhält sich wie `grow`, stellt aber auch sicher, dass der neue Inhalt vor der Rückgabe auf Null gesetzt wird.
    ///
    /// Der Speicherblock enthält nach einem erfolgreichen Aufruf von den folgenden Inhalt
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` bleiben von der ursprünglichen Zuordnung erhalten.
    ///   * Bytes `old_layout.size()..old_size` bleiben abhängig von der Allokatorimplementierung entweder erhalten oder werden auf Null gesetzt.
    ///   `old_size` bezieht sich auf die Größe des Speicherblocks vor dem `grow_zeroed`-Aufruf, die möglicherweise größer ist als die Größe, die ursprünglich bei der Zuweisung angefordert wurde.
    ///   * Bytes `old_size..new_size` werden auf Null gesetzt.`new_size` bezieht sich auf die Größe des vom `grow_zeroed`-Aufruf zurückgegebenen Speicherblocks.
    ///
    /// # Safety
    ///
    /// * `ptr` muss über diesen Allokator einen Speicherblock [*currently allocated*] bezeichnen.
    /// * `old_layout` muss [*fit*] diesen Speicherblock (Das `new_layout`-Argument muss nicht passen.).
    /// * `new_layout.size()` muss größer oder gleich `old_layout.size()` sein.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Gibt `Err` zurück, wenn das neue Layout nicht den Größen-und Ausrichtungsbeschränkungen des Allokators des Allokators entspricht oder wenn das Wachstum anderweitig fehlschlägt.
    ///
    /// Implementierungen werden empfohlen, `Err` bei Speicherauslastung zurückzugeben, anstatt in Panik zu geraten oder abzubrechen. Dies ist jedoch keine strenge Anforderung.
    /// (Insbesondere: Es ist *legal*, dieses trait auf einer zugrunde liegenden nativen Zuordnungsbibliothek zu implementieren, die bei Speicherauslastung abgebrochen wird.)
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Zuordnungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SICHERHEIT: weil `new_layout.size()` größer oder gleich sein muss
        // `old_layout.size()`, Sowohl die alte als auch die neue Speicherzuordnung gelten für Lese-und Schreibvorgänge für `old_layout.size()`-Bytes.
        // Da die alte Zuordnung noch nicht freigegeben wurde, kann sie `new_ptr` nicht überlappen.
        // Somit ist der Anruf bei `copy_nonoverlapping` sicher.
        // Der Sicherheitsvertrag für `dealloc` muss vom Anrufer eingehalten werden.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Versuche, den Speicherblock zu verkleinern.
    ///
    /// Gibt einen neuen [`NonNull<[u8]>`][NonNull] zurück, der einen Zeiger und die tatsächliche Größe des zugewiesenen Speichers enthält.Der Zeiger eignet sich zum Speichern von Daten, die von `new_layout` beschrieben werden.
    /// Um dies zu erreichen, kann der Allokator die von `ptr` referenzierte Zuordnung verkleinern, um sie an das neue Layout anzupassen.
    ///
    /// Wenn dies `Ok` zurückgibt, wurde das Eigentum an dem von `ptr` referenzierten Speicherblock auf diesen Allokator übertragen.
    /// Der Speicher wurde möglicherweise freigegeben oder nicht und sollte als unbrauchbar angesehen werden, es sei denn, er wurde über den Rückgabewert dieser Methode erneut an den Anrufer übertragen.
    ///
    /// Wenn diese Methode `Err` zurückgibt, wurde der Besitz des Speicherblocks nicht auf diesen Allokator übertragen, und der Inhalt des Speicherblocks bleibt unverändert.
    ///
    /// # Safety
    ///
    /// * `ptr` muss über diesen Allokator einen Speicherblock [*currently allocated*] bezeichnen.
    /// * `old_layout` muss [*fit*] diesen Speicherblock (Das `new_layout`-Argument muss nicht passen.).
    /// * `new_layout.size()` muss kleiner oder gleich `old_layout.size()` sein.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Gibt `Err` zurück, wenn das neue Layout nicht den Größen-und Ausrichtungsbeschränkungen des Allokators des Allokators entspricht oder wenn das Verkleinern andernfalls fehlschlägt.
    ///
    /// Implementierungen werden empfohlen, `Err` bei Speicherauslastung zurückzugeben, anstatt in Panik zu geraten oder abzubrechen. Dies ist jedoch keine strenge Anforderung.
    /// (Insbesondere: Es ist *legal*, dieses trait auf einer zugrunde liegenden nativen Zuordnungsbibliothek zu implementieren, die bei Speicherauslastung abgebrochen wird.)
    ///
    /// Clients, die die Berechnung als Reaktion auf einen Zuordnungsfehler abbrechen möchten, werden aufgefordert, die [`handle_alloc_error`]-Funktion aufzurufen, anstatt `panic!` oder ähnliches direkt aufzurufen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SICHERHEIT: weil `new_layout.size()` kleiner oder gleich sein muss
        // `old_layout.size()`, Sowohl die alte als auch die neue Speicherzuordnung gelten für Lese-und Schreibvorgänge für `new_layout.size()`-Bytes.
        // Da die alte Zuordnung noch nicht freigegeben wurde, kann sie `new_ptr` nicht überlappen.
        // Somit ist der Anruf bei `copy_nonoverlapping` sicher.
        // Der Sicherheitsvertrag für `dealloc` muss vom Anrufer eingehalten werden.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Erstellt einen "by reference"-Adapter für diese Instanz von `Allocator`.
    ///
    /// Der zurückgegebene Adapter implementiert auch `Allocator` und leiht dies einfach aus.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SICHERHEIT: Der Sicherheitsvertrag muss vom Anrufer eingehalten werden
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICHERHEIT: Der Sicherheitsvertrag muss vom Anrufer eingehalten werden
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICHERHEIT: Der Sicherheitsvertrag muss vom Anrufer eingehalten werden
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICHERHEIT: Der Sicherheitsvertrag muss vom Anrufer eingehalten werden
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}