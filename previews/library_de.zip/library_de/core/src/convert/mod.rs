//! Traits für Konvertierungen zwischen Typen.
//!
//! Die traits in diesem Modul bieten eine Möglichkeit, von einem Typ in einen anderen Typ zu konvertieren.
//! Jeder trait dient einem anderen Zweck:
//!
//! - Implementieren Sie den [`AsRef`] trait für kostengünstige Referenz-zu-Referenz-Konvertierungen
//! - Implementieren Sie den [`AsMut`] trait für kostengünstige Konvertierungen von veränderbar zu veränderlich
//! - Implementieren Sie den [`From`] trait, um Wert-zu-Wert-Konvertierungen durchzuführen
//! - Implementieren Sie den [`Into`] trait, um Wert-zu-Wert-Konvertierungen in Typen außerhalb des aktuellen crate durchzuführen
//! - [`TryFrom`] und [`TryInto`] traits verhalten sich wie [`From`] und [`Into`], sollten jedoch implementiert werden, wenn die Konvertierung fehlschlagen kann.
//!
//! Die traits in diesem Modul werden häufig als trait bounds für generische Funktionen verwendet, sodass Argumente mehrerer Typen unterstützt werden.Beispiele finden Sie in der Dokumentation der einzelnen trait.
//!
//! Als Bibliotheksautor sollten Sie immer lieber [`From<T>`][`From`] oder [`TryFrom<T>`][`TryFrom`] als [`Into<U>`][`Into`] oder [`TryInto<U>`][`TryInto`] implementieren, da [`From`] und [`TryFrom`] dank einer umfassenden Implementierung in der Standardbibliothek eine größere Flexibilität bieten und gleichwertige [`Into`]-oder [`TryInto`]-Implementierungen kostenlos anbieten.
//! Wenn Sie auf eine Version vor Rust 1.41 abzielen, muss [`Into`] oder [`TryInto`] möglicherweise direkt implementiert werden, wenn Sie in einen Typ außerhalb des aktuellen crate konvertieren.
//!
//! # Generische Implementierungen
//!
//! - [`AsRef`] und [`AsMut`]-Auto-Dereferenzierung, wenn der innere Typ eine Referenz ist
//! - [`From`]`<U>for T` impliziert [`Into`]`</u><T><U>für U`</u>
//! - [`TryFrom`]`<U>für T` impliziert [`TryInto`]`</u><T><U>für U`</u>
//! - [`From`] und [`Into`] sind reflexiv, was bedeutet, dass alle Typen `into` selbst und `from` selbst können
//!
//! Anwendungsbeispiele finden Sie in jedem trait.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Die Identitätsfunktion.
///
/// Bei dieser Funktion sind zwei Dinge zu beachten:
///
/// - Es ist nicht immer gleichbedeutend mit einem Verschluss wie `|x| x`, da der Verschluss `x` in einen anderen Typ zwingen kann.
///
/// - Es verschiebt den an die Funktion übergebenen Eingang `x`.
///
/// Während es seltsam erscheinen mag, eine Funktion zu haben, die nur die Eingabe zurückgibt, gibt es einige interessante Verwendungszwecke.
///
///
/// # Examples
///
/// Verwenden von `identity`, um in einer Folge anderer interessanter Funktionen nichts zu tun:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Stellen wir uns vor, dass das Hinzufügen einer Funktion eine interessante Funktion ist.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Verwenden von `identity` als "do nothing"-Basisfall unter folgenden Bedingungen:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Mach mehr interessante Sachen ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Verwenden von `identity`, um die `Some`-Varianten eines `Option<T>`-Iterators beizubehalten:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Wird verwendet, um eine kostengünstige Referenz-zu-Referenz-Konvertierung durchzuführen.
///
/// Dieser trait ähnelt [`AsMut`], der zum Konvertieren zwischen veränderlichen Referenzen verwendet wird.
/// Wenn Sie eine kostspielige Konvertierung durchführen müssen, ist es besser, [`From`] mit Typ `&T` zu implementieren oder eine benutzerdefinierte Funktion zu schreiben.
///
/// `AsRef` hat die gleiche Signatur wie [`Borrow`], aber [`Borrow`] unterscheidet sich in einigen Aspekten:
///
/// - Im Gegensatz zu `AsRef` verfügt [`Borrow`] über ein Blanket-Impl für jedes `T` und kann verwendet werden, um entweder eine Referenz oder einen Wert zu akzeptieren.
/// - [`Borrow`] erfordert auch, dass [`Hash`], [`Eq`] und [`Ord`] für den geliehenen Wert denen des eigenen Wertes entsprechen.
/// Wenn Sie nur ein einzelnes Feld einer Struktur ausleihen möchten, können Sie aus diesem Grund `AsRef` implementieren, nicht jedoch [`Borrow`].
///
/// **Note: Dieser trait darf nicht ausfallen **.Wenn die Konvertierung fehlschlagen kann, verwenden Sie eine dedizierte Methode, die einen [`Option<T>`] oder einen [`Result<T, E>`] zurückgibt.
///
/// # Generische Implementierungen
///
/// - `AsRef` automatische Dereferenzen, wenn der innere Typ eine Referenz oder eine veränderbare Referenz ist (z. B.: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Mit trait bounds können wir Argumente unterschiedlichen Typs akzeptieren, sofern sie in den angegebenen Typ `T` konvertiert werden können.
///
/// Beispiel: Durch Erstellen einer generischen Funktion, die ein `AsRef<str>` verwendet, drücken wir aus, dass wir alle Referenzen akzeptieren möchten, die als Argument in [`&str`] konvertiert werden können.
/// Da sowohl [`String`] als auch [`&str`] `AsRef<str>` implementieren, können wir beide als Eingabeargument akzeptieren.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Führt die Konvertierung durch.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Wird verwendet, um eine billige Referenzkonvertierung von veränderbar zu veränderlich durchzuführen.
///
/// Dieser trait ähnelt [`AsRef`], wird jedoch zum Konvertieren zwischen veränderlichen Referenzen verwendet.
/// Wenn Sie eine kostspielige Konvertierung durchführen müssen, ist es besser, [`From`] mit dem Typ `&mut T` zu implementieren oder eine benutzerdefinierte Funktion zu schreiben.
///
/// **Note: Dieser trait darf nicht ausfallen **.Wenn die Konvertierung fehlschlagen kann, verwenden Sie eine dedizierte Methode, die einen [`Option<T>`] oder einen [`Result<T, E>`] zurückgibt.
///
/// # Generische Implementierungen
///
/// - `AsMut` Auto-Dereferenzen, wenn der innere Typ eine veränderbare Referenz ist (z. B.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Mit `AsMut` als trait bound für eine generische Funktion können wir alle veränderlichen Referenzen akzeptieren, die in den Typ `&mut T` konvertiert werden können.
/// Da [`Box<T>`] `AsMut<T>` implementiert, können wir eine Funktion `add_one` schreiben, die alle Argumente akzeptiert, die in `&mut u64` konvertiert werden können.
/// Da [`Box<T>`] `AsMut<T>` implementiert, akzeptiert `add_one` auch Argumente vom Typ `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Führt die Konvertierung durch.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Eine Wert-zu-Wert-Konvertierung, die den Eingabewert verbraucht.Das Gegenteil von [`From`].
///
/// Man sollte die Implementierung von [`Into`] vermeiden und stattdessen [`From`] implementieren.
/// Durch die automatische Implementierung von [`From`] wird dank der umfassenden Implementierung in der Standardbibliothek automatisch [`Into`] implementiert.
///
/// Verwenden Sie lieber [`Into`] als [`From`], wenn Sie trait bounds für eine generische Funktion angeben, um sicherzustellen, dass auch Typen verwendet werden können, die nur [`Into`] implementieren.
///
/// **Note: Dieser trait darf nicht ausfallen **.Wenn die Konvertierung fehlschlagen kann, verwenden Sie [`TryInto`].
///
/// # Generische Implementierungen
///
/// - [`From`]`<T>für U` impliziert `Into<U> for T`
/// - [`Into`] ist reflexiv, was bedeutet, dass `Into<T> for T` implementiert ist
///
/// # Implementierung von [`Into`] für Konvertierungen in externe Typen in alten Versionen von Rust
///
/// Wenn der Zieltyp vor Rust 1.41 nicht Teil des aktuellen crate war, konnten Sie [`From`] nicht direkt implementieren.
/// Nehmen Sie zum Beispiel diesen Code:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// In älteren Versionen der Sprache kann dies nicht kompiliert werden, da die Waisenregeln von Rust früher etwas strenger waren.
/// Um dies zu umgehen, können Sie [`Into`] direkt implementieren:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Es ist wichtig zu verstehen, dass [`Into`] keine [`From`]-Implementierung bietet (wie [`From`] mit [`Into`]).
/// Daher sollten Sie immer versuchen, [`From`] zu implementieren, und dann auf [`Into`] zurückgreifen, wenn [`From`] nicht implementiert werden kann.
///
/// # Examples
///
/// [`String`] implementiert [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Um auszudrücken, dass eine generische Funktion alle Argumente annehmen soll, die in einen angegebenen Typ `T` konvertiert werden können, können wir ein trait bound von [`Into`]`verwenden<T>`.
///
/// Zum Beispiel: Die Funktion `is_hello` akzeptiert alle Argumente, die in ein [`Vec`]`<`[`u8`] `>` konvertiert werden können.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Führt die Konvertierung durch.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Wird verwendet, um Wert-zu-Wert-Konvertierungen durchzuführen, während der Eingabewert verbraucht wird.Es ist das Gegenteil von [`Into`].
///
/// Man sollte immer die Implementierung von `From` gegenüber [`Into`] vorziehen, da die Implementierung von `From` dank der pauschalen Implementierung in der Standardbibliothek automatisch eine Implementierung von [`Into`] ermöglicht.
///
///
/// Implementieren Sie [`Into`] nur, wenn Sie auf eine Version vor Rust 1.41 abzielen und in einen Typ außerhalb des aktuellen crate konvertieren.
/// `From` war in früheren Versionen aufgrund der verwaisten Regeln von Rust nicht in der Lage, diese Art von Konvertierungen durchzuführen.
/// Weitere Informationen finden Sie unter [`Into`].
///
/// Verwenden Sie lieber [`Into`] als `From`, wenn Sie trait bounds für eine generische Funktion angeben.
/// Auf diese Weise können auch Typen, die [`Into`] direkt implementieren, als Argumente verwendet werden.
///
/// Der `From` ist auch sehr nützlich bei der Fehlerbehandlung.Wenn Sie eine Funktion erstellen, die fehlschlagen kann, hat der Rückgabetyp im Allgemeinen die Form `Result<T, E>`.
/// Der `From` trait vereinfacht die Fehlerbehandlung, indem eine Funktion einen einzelnen Fehlertyp zurückgeben kann, der mehrere Fehlertypen enthält.Weitere Informationen finden Sie im Abschnitt "Examples" und [the book][book].
///
/// **Note: Dieser trait darf nicht ausfallen **.Wenn die Konvertierung fehlschlagen kann, verwenden Sie [`TryFrom`].
///
/// # Generische Implementierungen
///
/// - `From<T> for U` impliziert [`Into`]`<U>für T`</u>
/// - `From` ist reflexiv, was bedeutet, dass `From<T> for T` implementiert ist
///
/// # Examples
///
/// [`String`] implementiert `From<&str>`:
///
/// Eine explizite Konvertierung von einem `&str` in einen String erfolgt wie folgt:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Bei der Fehlerbehandlung ist es häufig hilfreich, `From` für Ihren eigenen Fehlertyp zu implementieren.
/// Durch Konvertieren der zugrunde liegenden Fehlertypen in unseren eigenen benutzerdefinierten Fehlertyp, der den zugrunde liegenden Fehlertyp kapselt, können wir einen einzelnen Fehlertyp zurückgeben, ohne Informationen über die zugrunde liegende Ursache zu verlieren.
/// Der '?'-Operator konvertiert den zugrunde liegenden Fehlertyp automatisch in unseren benutzerdefinierten Fehlertyp, indem er `Into<CliError>::into` aufruft, das bei der Implementierung von `From` automatisch bereitgestellt wird.
/// Der Compiler leitet dann ein, welche Implementierung von `Into` verwendet werden soll.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Führt die Konvertierung durch.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ein Konvertierungsversuch, der `self` verbraucht, was teuer sein kann oder nicht.
///
/// Bibliotheksautoren sollten dieses trait normalerweise nicht direkt implementieren, sondern lieber das [`TryFrom`] trait implementieren, das dank einer pauschalen Implementierung in der Standardbibliothek eine größere Flexibilität und eine entsprechende kostenlose `TryInto`-Implementierung bietet.
/// Weitere Informationen hierzu finden Sie in der Dokumentation zu [`Into`].
///
/// # `TryInto` implementieren
///
/// Dies unterliegt den gleichen Einschränkungen und Überlegungen wie die Implementierung von [`Into`]. Weitere Informationen finden Sie dort.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Der Typ, der im Falle eines Konvertierungsfehlers zurückgegeben wird.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Führt die Konvertierung durch.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Einfache und sichere Typkonvertierungen, die unter bestimmten Umständen kontrolliert fehlschlagen können.Es ist das Gegenteil von [`TryInto`].
///
/// Dies ist nützlich, wenn Sie eine Typkonvertierung durchführen, die möglicherweise trivial erfolgreich ist, aber möglicherweise auch eine spezielle Behandlung erfordert.
/// Beispielsweise gibt es keine Möglichkeit, einen [`i64`] mit dem [`From`] trait in einen [`i32`] zu konvertieren, da ein [`i64`] möglicherweise einen Wert enthält, den ein [`i32`] nicht darstellen kann, sodass bei der Konvertierung Daten verloren gehen.
///
/// Dies kann durch Abschneiden des [`i64`] auf einen [`i32`] (im Wesentlichen unter Angabe des Wertes modulo [`i32::MAX`] des [`i64`]]) oder durch einfaches Zurückgeben von [`i32::MAX`] oder durch eine andere Methode erfolgen.
/// Der [`From`] trait ist für perfekte Konvertierungen vorgesehen. Der `TryFrom` trait informiert den Programmierer daher, wenn eine Typkonvertierung fehlschlagen könnte, und lässt ihn entscheiden, wie er damit umgehen soll.
///
/// # Generische Implementierungen
///
/// - `TryFrom<T> for U` impliziert [`TryInto`]`<U>für T`</u>
/// - [`try_from`] ist reflexiv, was bedeutet, dass `TryFrom<T> for T` implementiert ist und nicht fehlschlagen kann-der zugehörige `Error`-Typ zum Aufrufen von `T::try_from()` für einen Wert vom Typ `T` ist [`Infallible`].
/// Wenn der [`!`]-Typ stabilisiert ist, sind [`Infallible`] und [`!`] gleichwertig.
///
/// `TryFrom<T>` kann wie folgt implementiert werden:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Wie beschrieben implementiert [`i32`] TryFrom <`[` i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Kürzt `big_number` stillschweigend ab, erfordert das nachträgliche Erkennen und Behandeln des Abschneidens.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Gibt einen Fehler zurück, da `big_number` zu groß ist, um in ein `i32` zu passen.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Gibt `Ok(3)` zurück.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Der Typ, der im Falle eines Konvertierungsfehlers zurückgegeben wird.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Führt die Konvertierung durch.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ALLGEMEINE IMPLISSE
////////////////////////////////////////////////////////////////////////////////

// Da hebt über&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Da hebt über &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): Ersetzen Sie die obigen Impls für&/&mut durch die folgenden allgemeineren:
// // Als Aufzüge über Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U :? Sized> AsRef <U>für D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut hebt über &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): Ersetzen Sie das obige Gerät für &mut durch das folgende allgemeinere:
// // AsMut hebt über DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? Sized> AsMut <U>für D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Von impliziert in
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (und damit Into) ist reflexiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabilitätshinweis:** Dieses Impl existiert noch nicht, aber wir sind "reserving space", um es in die future aufzunehmen.
/// Siehe [rust-lang/rust#64715][#64715] für Details.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): Führen Sie stattdessen eine prinzipielle Korrektur durch.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom impliziert TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Unfehlbare Konvertierungen entsprechen semantisch fehlbaren Konvertierungen mit einem unbewohnten Fehlertyp.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// DER FEHLERFREIE TYP
////////////////////////////////////////////////////////////////////////////////

/// Der Fehlertyp für Fehler, die niemals auftreten können.
///
/// Da diese Aufzählung keine Variante hat, kann ein Wert dieses Typs niemals tatsächlich existieren.
/// Dies kann für generische APIs nützlich sein, die [`Result`] verwenden und den Fehlertyp parametrisieren, um anzuzeigen, dass das Ergebnis immer [`Ok`] ist.
///
/// Beispielsweise verfügt die [`TryFrom`] trait (Konvertierung, die eine [`Result`] zurückgibt) über eine Pauschalimplementierung für alle Typen, bei denen eine umgekehrte [`Into`]-Implementierung vorhanden ist.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future-Kompatibilität
///
/// Diese Aufzählung hat dieselbe Rolle wie [the `!`“never”type][never], das in dieser Version von Rust instabil ist.
/// Wenn `!` stabilisiert ist, planen wir, `Infallible` zu einem Typalias zu machen:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Und veralten `Infallible` schließlich.
///
/// Es gibt jedoch einen Fall, in dem die `!`-Syntax verwendet werden kann, bevor `!` als vollwertiger Typ stabilisiert wird: an der Position des Rückgabetyps einer Funktion.
/// Insbesondere sind Implementierungen für zwei verschiedene Funktionszeigertypen möglich:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Da `Infallible` eine Aufzählung ist, ist dieser Code gültig.
/// Wenn `Infallible` jedoch zu einem Alias für never type wird, beginnen sich die beiden `impl`s zu überlappen und werden daher von den trait-Kohärenzregeln der Sprache nicht zugelassen.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}