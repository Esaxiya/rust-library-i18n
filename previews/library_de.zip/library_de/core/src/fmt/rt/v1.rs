//! Dies ist ein internes Modul, das vom ifmt!Laufzeit.Diese Strukturen werden an statische Arrays ausgegeben, um Formatzeichenfolgen vorab zu kompilieren.
//!
//! Diese Definitionen ähneln ihren `ct`-Entsprechungen, unterscheiden sich jedoch darin, dass diese statisch zugeordnet werden können und für die Laufzeit leicht optimiert sind
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mögliche Ausrichtungen, die im Rahmen einer Formatierungsanweisung angefordert werden können.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Hinweis, dass der Inhalt linksbündig sein sollte.
    Left,
    /// Hinweis, dass der Inhalt rechtsbündig sein sollte.
    Right,
    /// Anzeige, dass der Inhalt mittig ausgerichtet sein sollte.
    Center,
    /// Es wurde keine Ausrichtung angefordert.
    Unknown,
}

/// Wird von [width](https://doc.rust-lang.org/std/fmt/#width)-und [precision](https://doc.rust-lang.org/std/fmt/#precision)-Spezifizierern verwendet.
#[derive(Copy, Clone)]
pub enum Count {
    /// Mit einer Literalzahl angegeben, speichert den Wert
    Is(usize),
    /// Wird mit den Syntaxen `$` und `*` angegeben und speichert den Index in `args`
    Param(usize),
    /// Unbestimmt
    Implied,
}