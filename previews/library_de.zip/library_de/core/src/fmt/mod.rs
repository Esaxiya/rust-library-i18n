//! Dienstprogramme zum Formatieren und Drucken von Zeichenfolgen.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Mögliche von `Formatter::align` zurückgegebene Ausrichtungen
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Hinweis, dass der Inhalt linksbündig sein sollte.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Hinweis, dass der Inhalt rechtsbündig sein sollte.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Anzeige, dass der Inhalt mittig ausgerichtet sein sollte.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Der von Formatierungsmethoden zurückgegebene Typ.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Der Fehlertyp, der beim Formatieren einer Nachricht in einen Stream zurückgegeben wird.
///
/// Dieser Typ unterstützt keine Übertragung eines anderen Fehlers als dem, dass ein Fehler aufgetreten ist.
/// Alle zusätzlichen Informationen müssen so angeordnet werden, dass sie auf andere Weise übertragen werden können.
///
/// Es ist wichtig zu wissen, dass der Typ `fmt::Error` nicht mit [`std::io::Error`] oder [`std::error::Error`] verwechselt werden darf, die Sie möglicherweise auch im Geltungsbereich haben.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Ein trait zum Schreiben oder Formatieren in Unicode-akzeptierende Puffer oder Streams.
///
/// Dieser trait akzeptiert nur UTF-8-codierte Daten und ist nicht [flushable].
/// Wenn Sie nur Unicode akzeptieren möchten und kein Spülen benötigen, sollten Sie dieses trait implementieren.
/// Andernfalls sollten Sie [`std::io::Write`] implementieren.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Schreibt einen String-Slice in diesen Writer und gibt zurück, ob der Schreibvorgang erfolgreich war.
    ///
    /// Diese Methode kann nur erfolgreich sein, wenn das gesamte String-Slice erfolgreich geschrieben wurde. Diese Methode wird erst zurückgegeben, wenn alle Daten geschrieben wurden oder ein Fehler auftritt.
    ///
    ///
    /// # Errors
    ///
    /// Diese Funktion gibt bei einem Fehler eine Instanz von [`Error`] zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Schreibt einen [`char`] in diesen Writer und gibt zurück, ob der Schreibvorgang erfolgreich war.
    ///
    /// Ein einzelnes [`char`] kann als mehr als ein Byte codiert werden.
    /// Diese Methode kann nur erfolgreich sein, wenn die gesamte Bytesequenz erfolgreich geschrieben wurde. Diese Methode wird erst zurückgegeben, wenn alle Daten geschrieben wurden oder ein Fehler auftritt.
    ///
    ///
    /// # Errors
    ///
    /// Diese Funktion gibt bei einem Fehler eine Instanz von [`Error`] zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Kleber für die Verwendung des [`write!`]-Makros mit Implementierern dieses trait.
    ///
    /// Diese Methode sollte im Allgemeinen nicht manuell aufgerufen werden, sondern über das [`write!`]-Makro selbst.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Konfiguration zur Formatierung.
///
/// Ein `Formatter` bietet verschiedene Optionen für die Formatierung.
/// Benutzer erstellen `Formatter`s nicht direkt;Ein veränderbarer Verweis auf eins wird an die `fmt`-Methode aller Formatierungen von traits wie [`Debug`] und [`Display`] übergeben.
///
///
/// Um mit einem `Formatter` zu interagieren, rufen Sie verschiedene Methoden auf, um die verschiedenen Optionen für die Formatierung zu ändern.
/// Beispiele finden Sie in der Dokumentation der unter `Formatter` definierten Methoden.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Argument ist im Wesentlichen eine optimierte, teilweise angewendete Formatierungsfunktion, die `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` entspricht.

extern "C" {
    type Opaque;
}

/// Diese Struktur stellt das generische "argument" dar, das von der Xprintf-Funktionsfamilie verwendet wird.Es enthält eine Funktion zum Formatieren des angegebenen Werts.
/// Bei der Kompilierung wird sichergestellt, dass die Funktion und der Wert die richtigen Typen haben. Anschließend wird diese Struktur verwendet, um Argumente für einen Typ zu kanonisieren.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Dies garantiert einen einzelnen stabilen Wert für den mit indices/counts verknüpften Funktionszeiger in der Formatierungsinfrastruktur.
//
// Beachten Sie, dass eine als solche definierte Funktion nicht korrekt wäre, da Funktionen immer mit unnamed_addr mit der aktuellen Absenkung auf LLVM IR gekennzeichnet sind, sodass ihre Adresse für LLVM nicht als wichtig angesehen wird und die as_usize-Umwandlung daher möglicherweise falsch kompiliert wurde.
//
// In der Praxis rufen wir niemals as_usize für Daten auf, die nicht usize enthalten (als eine Frage der statischen Generierung der Formatierungsargumente), daher ist dies lediglich eine zusätzliche Überprüfung.
//
// Wir möchten in erster Linie sicherstellen, dass der Funktionszeiger bei `USIZE_MARKER` eine Adresse hat, die *nur* Funktionen entspricht, die auch `&usize` als erstes Argument verwenden.
// Das read_volatile hier stellt sicher, dass wir eine Usize sicher aus der übergebenen Referenz bereitstellen können und dass diese Adresse nicht auf eine Nicht-Usize-Übernahmefunktion verweist.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SICHERHEIT: ptr ist eine Referenz
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // SICHERHEIT: `mem::transmute(x)` ist sicher, weil
        //     1. `&'b T` behält die Lebensdauer bei, die mit `'b` entstanden ist (um keine unbegrenzte Lebensdauer zu haben)
        //     2.
        //     `&'b T` und `&'b Opaque` haben das gleiche Speicherlayout (wenn `T` wie hier `Sized` ist). `mem::transmute(f)` ist sicher, da `fn(&T, &mut Formatter<'_>) -> Result` und `fn(&Opaque, &mut Formatter<'_>) -> Result` den gleichen ABI haben (solange `T` `Sized` ist).
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SICHERHEIT: Das `formatter`-Feld wird nur dann auf USIZE_MARKER gesetzt, wenn
            // Der Wert ist ein Usize, also ist dies sicher
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// Flags im v1-Format von format_args verfügbar
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Bei Verwendung des Makros format_args! () Wird diese Funktion zum Generieren der Argumentstruktur verwendet.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Diese Funktion wird verwendet, um nicht standardmäßige Formatierungsparameter anzugeben.
    /// Das `pieces`-Array muss mindestens so lang wie `fmt` sein, um eine gültige Argumentstruktur zu erstellen.
    /// Außerdem muss jedes `Count` in `fmt`, das `CountIsParam` oder `CountIsNextParam` ist, auf ein mit `argumentusize` erstelltes Argument verweisen.
    ///
    /// Wenn Sie dies nicht tun, wird dies jedoch nicht unsicher, sondern ungültig ignoriert.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Schätzt die Länge des formatierten Textes.
    ///
    /// Dies ist zum Einstellen der anfänglichen `String`-Kapazität bei Verwendung von `format!` vorgesehen.
    /// Note: Dies ist weder die Unter-noch die Obergrenze.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Wenn die Formatzeichenfolge mit einem Argument beginnt, weisen Sie nichts vorab zu, es sei denn, die Länge der Teile ist signifikant.
            //
            //
            0
        } else {
            // Es gibt einige Argumente, sodass bei jedem zusätzlichen Push die Zeichenfolge neu zugewiesen wird.
            //
            // Um dies zu vermeiden, haben wir hier die "pre-doubling"-Kapazität.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Diese Struktur stellt eine sicher vorkompilierte Version einer Formatzeichenfolge und ihrer Argumente dar.
/// Dies kann zur Laufzeit nicht generiert werden, da dies nicht sicher möglich ist. Daher werden keine Konstruktoren angegeben und die Felder sind privat, um Änderungen zu verhindern.
///
///
/// Das [`format_args!`]-Makro erstellt sicher eine Instanz dieser Struktur.
/// Das Makro überprüft die Formatzeichenfolge zur Kompilierungszeit, sodass die Verwendung der Funktionen [`write()`] und [`format()`] sicher ausgeführt werden kann.
///
/// Sie können das `Arguments<'a>` verwenden, das [`format_args!`] in `Debug`-und `Display`-Kontexten zurückgibt (siehe unten).
/// Das Beispiel zeigt auch, dass `Debug` und `Display` dasselbe Format haben: die interpolierte Formatzeichenfolge in `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Formatieren Sie die zu druckenden Zeichenfolgen.
    pieces: &'a [&'static str],

    // Platzhalter-Spezifikationen oder `None`, wenn alle Spezifikationen Standard sind (wie in "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dynamische Argumente für die Interpolation, die mit Zeichenfolgen verschachtelt werden sollen.
    // (Vor jedem Argument steht ein String.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Rufen Sie die formatierte Zeichenfolge ab, wenn keine zu formatierenden Argumente vorhanden sind.
    ///
    /// Dies kann verwendet werden, um Zuweisungen im trivialsten Fall zu vermeiden.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` sollte die Ausgabe in einem programmiererorientierten Debugging-Kontext formatieren.
///
/// Im Allgemeinen sollten Sie nur `derive` eine `Debug`-Implementierung.
///
/// Bei Verwendung mit dem alternativen Formatbezeichner `#?` wird die Ausgabe hübsch gedruckt.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Dieser trait kann mit `#[derive]` verwendet werden, wenn alle Felder `Debug` implementieren.
/// Wenn für Strukturen abgeleitet, wird der Name des `struct`, dann `{`, dann eine durch Kommas getrennte Liste des Feldnamens und des `Debug`-Werts sowie `}` verwendet.
/// Für `enum`s wird der Name der Variante und gegebenenfalls `(`, dann die `Debug`-Werte der Felder und dann `)` verwendet.
///
/// # Stability
///
/// Abgeleitete `Debug`-Formate sind nicht stabil und können sich daher mit den future Rust-Versionen ändern.
/// Darüber hinaus sind `Debug`-Implementierungen von Typen, die von der Standardbibliothek bereitgestellt werden (`libstd`, `libcore`, `liballoc` usw.), nicht stabil und können sich auch mit future Rust-Versionen ändern.
///
///
/// # Examples
///
/// Ableiten einer Implementierung:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manuelles Implementieren:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// In der [`Formatter`]-Struktur gibt es eine Reihe von Hilfsmethoden, die Sie bei manuellen Implementierungen unterstützen, z. B. [`debug_struct`].
///
/// `Debug` Implementierungen, die entweder `derive` oder die Debug Builder-API unter [`Formatter`] verwenden, unterstützen das hübsche Drucken mit dem alternativen Flag: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Hübsches Drucken mit `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Separates Modul zum erneuten Exportieren des Makros `Debug` von prelude ohne trait `Debug`.
pub(crate) mod macros {
    /// Leiten Sie ein Makro ab, das ein Impl des trait `Debug` generiert.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Format trait für ein leeres Format, `{}`.
///
/// `Display` ähnelt [`Debug`], `Display` ist jedoch für die benutzerbezogene Ausgabe vorgesehen und kann daher nicht abgeleitet werden.
///
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Implementieren von `Display` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Der `Octal` trait sollte seine Ausgabe als Zahl in base-8 formatieren.
///
/// Für primitive vorzeichenbehaftete Ganzzahlen (`i8` bis `i128` und `isize`) werden negative Werte als Komplementdarstellung der beiden formatiert.
///
///
/// Das alternative Flag `#` fügt vor dem Ausgang ein `0o` hinzu.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Grundlegende Verwendung mit `i32`:
///
/// ```
/// let x = 42; // 42 ist '52' im Oktal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Implementieren von `Octal` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // an die Implementierung von i32 delegieren
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Der `Binary` trait sollte seine Ausgabe als Binärzahl formatieren.
///
/// Für primitive vorzeichenbehaftete Ganzzahlen ([`i8`] bis [`i128`] und [`isize`]) werden negative Werte als Komplementdarstellung der beiden formatiert.
///
///
/// Das alternative Flag `#` fügt vor dem Ausgang ein `0b` hinzu.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Grundlegende Verwendung mit [`i32`]:
///
/// ```
/// let x = 42; // 42 ist '101010' in binär
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Implementieren von `Binary` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // an die Implementierung von i32 delegieren
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Der `LowerHex` trait sollte seine Ausgabe als hexadezimale Zahl formatieren, wobei `a` bis `f` in Kleinbuchstaben geschrieben sind.
///
/// Für primitive vorzeichenbehaftete Ganzzahlen (`i8` bis `i128` und `isize`) werden negative Werte als Komplementdarstellung der beiden formatiert.
///
///
/// Das alternative Flag `#` fügt vor dem Ausgang ein `0x` hinzu.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Grundlegende Verwendung mit `i32`:
///
/// ```
/// let x = 42; // 42 ist '2a' in hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Implementieren von `LowerHex` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // an die Implementierung von i32 delegieren
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Der `UpperHex` trait sollte seine Ausgabe als hexadezimale Zahl formatieren, wobei `A` bis `F` in Großbuchstaben geschrieben sind.
///
/// Für primitive vorzeichenbehaftete Ganzzahlen (`i8` bis `i128` und `isize`) werden negative Werte als Komplementdarstellung der beiden formatiert.
///
///
/// Das alternative Flag `#` fügt vor dem Ausgang ein `0x` hinzu.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Grundlegende Verwendung mit `i32`:
///
/// ```
/// let x = 42; // 42 ist '2A' in hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Implementieren von `UpperHex` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // an die Implementierung von i32 delegieren
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Der `Pointer` trait sollte seine Ausgabe als Speicherort formatieren.
/// Dies wird üblicherweise als hexadezimal dargestellt.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Grundlegende Verwendung mit `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // Dies erzeugt so etwas wie '0x7f06092ac6d0'
/// ```
///
/// Implementieren von `Pointer` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // Verwenden Sie `as`, um in einen `*const T` zu konvertieren, der den Zeiger implementiert, den wir verwenden können
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Der `LowerExp` trait sollte seine Ausgabe in wissenschaftlicher Notation mit einem `e` in Kleinbuchstaben formatieren.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Grundlegende Verwendung mit `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ist '4.2e1' in wissenschaftlicher Notation
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Implementieren von `LowerExp` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // an die Implementierung von f64 delegieren
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Der `UpperExp` trait sollte seine Ausgabe in wissenschaftlicher Notation mit einem `E` in Großbuchstaben formatieren.
///
/// Weitere Informationen zu Formatierern finden Sie unter [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Grundlegende Verwendung mit `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ist '4.2E1' in wissenschaftlicher Notation
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Implementieren von `UpperExp` auf einem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // an die Implementierung von f64 delegieren
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Formatiert den Wert mit dem angegebenen Formatierer.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Die `write`-Funktion verwendet einen Ausgabestream und eine `Arguments`-Struktur, die mit dem `format_args!`-Makro vorkompiliert werden kann.
///
///
/// Die Argumente werden gemäß der angegebenen Formatzeichenfolge in den bereitgestellten Ausgabestream formatiert.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Bitte beachten Sie, dass die Verwendung von [`write!`] möglicherweise vorzuziehen ist.Beispiel:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Wir können Standardformatierungsparameter für alle Argumente verwenden.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Jede Spezifikation hat ein entsprechendes Argument, dem ein String-Stück vorangestellt ist.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SICHERHEIT: arg und args.args stammen aus denselben Argumenten.
                // Dies garantiert, dass die Indizes immer in Grenzen liegen.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Es kann nur noch ein hinteres Saitenstück übrig sein.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SICHERHEIT: arg und args stammen aus denselben Argumenten,
    // Dies garantiert, dass die Indizes immer in Grenzen liegen.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Extrahieren Sie das richtige Argument
    debug_assert!(arg.position < args.len());
    // SICHERHEIT: arg und args stammen aus denselben Argumenten,
    // was garantiert, dass sein Index immer in Grenzen liegt.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Dann drucken Sie tatsächlich
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SICHERHEIT: cnt und args stammen aus denselben Argumenten.
            // Dies garantiert, dass dieser Index immer in Grenzen liegt.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Polsterung nach dem Ende von etwas.Von `Formatter::padding` zurückgegeben.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Schreiben Sie diesen Beitrag Polsterung.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Wir wollen das ändern
            buf: wrap(self.buf),

            // Und bewahren Sie diese
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Hilfsmethoden zum Auffüllen und Verarbeiten von Formatierungsargumenten, die alle Formatierungen von traits verwenden können.
    //

    /// Führt das korrekte Auffüllen für eine Ganzzahl aus, die bereits in eine str ausgegeben wurde.
    /// Der str sollte *nicht* das Vorzeichen für die Ganzzahl enthalten, die durch diese Methode hinzugefügt wird.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, ob die ursprüngliche Ganzzahl entweder positiv oder null war.
    /// * Präfix: Wenn das '#'-Zeichen (Alternate) angegeben ist, ist dies das Präfix, das vor die Nummer gesetzt werden soll.
    ///
    /// * buf, das Byte-Array, in das die Nummer formatiert wurde
    ///
    /// Diese Funktion berücksichtigt korrekt die bereitgestellten Flags sowie die Mindestbreite.
    /// Präzision wird nicht berücksichtigt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Wir müssen "-" aus der Zahlenausgabe entfernen.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Schreibt das Zeichen, falls vorhanden, und dann das Präfix, wenn es angefordert wurde
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Das `width`-Feld ist zu diesem Zeitpunkt eher ein `min-width`-Parameter.
        match self.width {
            // Wenn es keine Mindestlängenanforderungen gibt, können wir einfach die Bytes schreiben.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Überprüfen Sie, ob wir die Mindestbreite überschritten haben. Wenn ja, können wir auch nur die Bytes schreiben.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Das Vorzeichen und das Präfix stehen vor dem Auffüllen, wenn das Füllzeichen Null ist
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Andernfalls werden das Vorzeichen und das Präfix nach dem Auffüllen angezeigt
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Diese Funktion nimmt ein String-Slice und gibt es nach Anwenden der angegebenen relevanten Formatierungsflags an den internen Puffer aus.
    /// Die für generische Zeichenfolgen erkannten Flags sind:
    ///
    /// * width, die minimale Breite dessen, was ausgegeben werden soll
    /// * fill/align - Was und wo soll es ausgegeben werden, wenn die bereitgestellte Zeichenfolge aufgefüllt werden muss?
    /// * Genauigkeit, die maximale Länge, die ausgegeben werden soll. Die Zeichenfolge wird abgeschnitten, wenn sie länger als diese Länge ist
    ///
    /// Insbesondere ignoriert diese Funktion die `flag`-Parameter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Stellen Sie sicher, dass es vorne einen schnellen Weg gibt
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Das `precision`-Feld kann als `max-width` für die zu formatierende Zeichenfolge interpretiert werden.
        //
        let s = if let Some(max) = self.precision {
            // Wenn unsere Zeichenfolge länger als die Genauigkeit ist, müssen wir sie abschneiden.
            // Andere Flags wie `fill`, `width` und `align` müssen jedoch wie immer funktionieren.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM hier kann nicht beweisen, dass `..i` nicht panic `&s[..i]` wird, aber wir wissen, dass es nicht panic kann.
                // Verwenden Sie `get` + `unwrap_or`, um `unsafe` zu vermeiden, und geben Sie andernfalls hier keinen panic-bezogenen Code aus.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Das `width`-Feld ist zu diesem Zeitpunkt eher ein `min-width`-Parameter.
        match self.width {
            // Wenn wir unter der maximalen Länge sind und es keine Mindestlängenanforderungen gibt, können wir einfach die Zeichenfolge ausgeben
            //
            None => self.buf.write_str(s),
            // Wenn wir unter der maximalen Breite sind, prüfen Sie, ob wir über der minimalen Breite sind. Wenn ja, ist es so einfach, wie nur die Zeichenfolge auszugeben.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Wenn wir sowohl unter der maximalen als auch unter der minimalen Breite sind, füllen Sie die minimale Breite mit der angegebenen Zeichenfolge + einer gewissen Ausrichtung.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Schreiben Sie das Pre-Padding und geben Sie das ungeschriebene Post-Padding zurück.
    /// Anrufer sind dafür verantwortlich, dass das Auffüllen nach dem Auffüllen geschrieben wird.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Nimmt die formatierten Teile und wendet die Polsterung an.
    /// Angenommen, der Aufrufer hat die Teile bereits mit der erforderlichen Genauigkeit gerendert, sodass `self.precision` ignoriert werden kann.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // Für die vorzeichenbewusste Null-Auffüllung rendern wir zuerst das Vorzeichen und verhalten uns so, als hätten wir von Anfang an kein Vorzeichen.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // Ein Zeichen steht immer an erster Stelle
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // Entfernen Sie das Schild von den formatierten Teilen
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // Die restlichen Teile durchlaufen den normalen Polsterprozess.
            let len = formatted.len();
            let ret = if width <= len {
                // keine Polsterung
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // Dies ist der übliche Fall und wir nehmen eine Abkürzung
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SICHERHEIT: Dies wird für `flt2dec::Part::Num` und `flt2dec::Part::Copy` verwendet.
            // Die Verwendung für `flt2dec::Part::Num` ist sicher, da jedes Zeichen `c` zwischen `b'0'` und `b'9'` liegt, was bedeutet, dass `s` für UTF-8 gültig ist.
            // In der Praxis ist es wahrscheinlich auch sicher, `flt2dec::Part::Copy(buf)` zu verwenden, da `buf` einfach ASCII sein sollte, aber es ist möglich, dass jemand einen schlechten Wert für `buf` an `flt2dec::to_shortest_str` übergibt, da es sich um eine öffentliche Funktion handelt.
            //
            // FIXME: Bestimmen Sie, ob dies zu UB führen kann.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 Nullen
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Schreibt einige Daten in den zugrunde liegenden Puffer, der in diesem Formatierer enthalten ist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Dies entspricht:
    ///         // schreiben! (Formatierer, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Schreibt einige formatierte Informationen in diese Instanz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Flags zur Formatierung
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Zeichen, das bei jeder Ausrichtung als 'fill' verwendet wird.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Wir stellen die Ausrichtung mit ">" nach rechts ein.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Flag, das angibt, welche Form der Ausrichtung angefordert wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Optional angegebene Ganzzahlbreite, die die Ausgabe sein soll.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Wenn wir eine Breite erhalten haben, verwenden wir sie
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Ansonsten machen wir nichts Besonderes
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Optional angegebene Genauigkeit für numerische Typen.
    /// Alternativ die maximale Breite für Zeichenfolgentypen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Wenn wir eine Präzision erhalten haben, verwenden wir sie.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Andernfalls wird standardmäßig 2 verwendet.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Legt fest, ob das `+`-Flag angegeben wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Legt fest, ob das `-`-Flag angegeben wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Du willst ein Minuszeichen?Habe eine!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Legt fest, ob das `#`-Flag angegeben wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Legt fest, ob das `0`-Flag angegeben wurde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Wir ignorieren die Optionen des Formatierers.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Entscheiden Sie, welche öffentliche API für diese beiden Flags gewünscht wird.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Erstellt einen [`DebugStruct`]-Builder, der die Erstellung von [`fmt::Debug`]-Implementierungen für Strukturen unterstützt.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Erstellt einen `DebugTuple`-Builder, der die Erstellung von `fmt::Debug`-Implementierungen für Tupelstrukturen unterstützt.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Erstellt einen `DebugList`-Builder, der die Erstellung von `fmt::Debug`-Implementierungen für listenähnliche Strukturen unterstützt.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Erstellt einen `DebugSet`-Builder, der die Erstellung von `fmt::Debug`-Implementierungen für satzartige Strukturen unterstützt.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// In diesem komplexeren Beispiel verwenden wir [`format_args!`] und `.debug_set()`, um eine Liste von Match Arms zu erstellen:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Erstellt einen `DebugMap`-Builder, der die Erstellung von `fmt::Debug`-Implementierungen für kartenähnliche Strukturen unterstützt.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Implementierungen der Kernformatierung traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Wenn char entkommen muss, leeren Sie den Rückstand und schreiben Sie, sonst überspringen Sie
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Das alternative Flag wird von LowerHex bereits als speziell behandelt. Es gibt an, ob 0x vorangestellt werden soll.
        // Wir verwenden es, um herauszufinden, ob die Erweiterung auf Null gesetzt ist oder nicht, und setzen es dann bedingungslos, um das Präfix zu erhalten.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Implementierung von Display/Debug für verschiedene Kerntypen

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Die RefCell ist veränderlich ausgeliehen, daher können wir ihren Wert hier nicht betrachten.
                // Zeigen Sie stattdessen einen Platzhalter an.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Wenn Sie erwartet haben, dass hier Tests stattfinden, sehen Sie sich stattdessen die core/tests/fmt.rs-Datei an. Dies ist viel einfacher als das Erstellen aller rt::Piece-Strukturen hier.
//
// Es gibt auch Tests in der Zuordnung crate für diejenigen, die Zuordnungen benötigen.