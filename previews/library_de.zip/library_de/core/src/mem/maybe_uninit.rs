use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Ein Wrapper-Typ zum Erstellen nicht initialisierter Instanzen von `T`.
///
/// # Initialisierungsinvariante
///
/// Der Compiler geht im Allgemeinen davon aus, dass eine Variable gemäß den Anforderungen des Variablentyps ordnungsgemäß initialisiert wird.Beispielsweise muss eine Variable vom Referenztyp ausgerichtet und nicht NULL sein.
/// Dies ist eine Invariante, die *immer* eingehalten werden muss, auch in unsicherem Code.
/// Infolgedessen führt die Nullinitialisierung einer Variablen vom Referenztyp zu einem sofortigen [undefined behavior][ub], unabhängig davon, ob diese Referenz jemals für den Zugriff auf den Speicher verwendet wird:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefiniertes Verhalten!⚠️
/// // Der entsprechende Code mit `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefiniertes Verhalten!⚠️
/// ```
///
/// Dies wird vom Compiler für verschiedene Optimierungen ausgenutzt, z. B. zum Eliminieren von Laufzeitprüfungen und zum Optimieren des `enum`-Layouts.
///
/// In ähnlicher Weise kann ein vollständig nicht initialisierter Speicher einen beliebigen Inhalt haben, während ein `bool` immer `true` oder `false` sein muss.Daher ist das Erstellen eines nicht initialisierten `bool` ein undefiniertes Verhalten:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefiniertes Verhalten!⚠️
/// // Der entsprechende Code mit `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefiniertes Verhalten!⚠️
/// ```
///
/// Darüber hinaus ist nicht initialisierter Speicher insofern besonders, als er keinen festen Wert hat ("fixed" bedeutet "it won't change without being written to").Das mehrmalige Lesen desselben nicht initialisierten Bytes kann zu unterschiedlichen Ergebnissen führen.
/// Dies macht es zu einem undefinierten Verhalten, nicht initialisierte Daten in einer Variablen zu haben, selbst wenn diese Variable einen ganzzahligen Typ hat, der ansonsten jedes *feste* Bitmuster enthalten kann:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefiniertes Verhalten!⚠️
/// // Der entsprechende Code mit `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefiniertes Verhalten!⚠️
/// ```
/// (Beachten Sie, dass die Regeln für nicht initialisierte Ganzzahlen noch nicht endgültig sind. Bis dahin ist es jedoch ratsam, sie zu vermeiden.)
///
/// Denken Sie außerdem daran, dass die meisten Typen zusätzliche Invarianten aufweisen, die nicht nur als auf Initialebene initialisiert betrachtet werden.
/// Beispielsweise wird ein mit 1 initialisierter [`Vec<T>`] als initialisiert betrachtet (unter der aktuellen Implementierung; dies stellt keine stabile Garantie dar), da der Compiler nur weiß, dass der Datenzeiger nicht null sein muss.
/// Das Erstellen eines solchen `Vec<T>` verursacht kein *sofortiges* undefiniertes Verhalten, sondern ein undefiniertes Verhalten bei den meisten sicheren Vorgängen (einschließlich des Löschens).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` dient dazu, unsicheren Code für den Umgang mit nicht initialisierten Daten zu aktivieren.
/// Es ist ein Signal an den Compiler, das angibt, dass die Daten hier möglicherweise *nicht* initialisiert wurden:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Erstellen Sie eine explizit nicht initialisierte Referenz.
/// // Der Compiler weiß, dass Daten in einem `MaybeUninit<T>` möglicherweise ungültig sind, und daher ist dies nicht UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Stellen Sie einen gültigen Wert ein.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extrahieren Sie die initialisierten Daten-dies ist nur *nach* ordnungsgemäßer Initialisierung von `x` zulässig!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Der Compiler weiß dann, dass er keine falschen Annahmen oder Optimierungen für diesen Code vornehmen muss.
///
/// Sie können sich `MaybeUninit<T>` als ein bisschen wie `Option<T>` vorstellen, jedoch ohne Laufzeitverfolgung und ohne Sicherheitsüberprüfungen.
///
/// ## out-pointers
///
/// Sie können `MaybeUninit<T>` verwenden, um "out-pointers" zu implementieren: Anstatt Daten von einer Funktion zurückzugeben, übergeben Sie ihm einen Zeiger auf einen (uninitialized)-Speicher, in den das Ergebnis eingefügt werden soll.
/// Dies kann nützlich sein, wenn es für den Anrufer wichtig ist, zu steuern, wie der Speicher, in dem das Ergebnis gespeichert ist, zugewiesen wird, und Sie unnötige Verschiebungen vermeiden möchten.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` löscht nicht den alten Inhalt, was wichtig ist.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Jetzt wissen wir, dass `v` initialisiert ist!Dies stellt auch sicher, dass der vector ordnungsgemäß fallen gelassen wird.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initialisieren eines Arrays Element für Element
///
/// `MaybeUninit<T>` kann verwendet werden, um ein großes Array Element für Element zu initialisieren:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Erstellen Sie ein nicht initialisiertes Array von `MaybeUninit`.
///     // Der `assume_init` ist sicher, da der Typ, von dem wir behaupten, dass er hier initialisiert wurde, eine Reihe von "MaybeUninit" ist, für die keine Initialisierung erforderlich ist.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Das Löschen eines `MaybeUninit` bewirkt nichts.
///     // Die Verwendung der Rohzeigerzuweisung anstelle von `ptr::write` führt daher nicht dazu, dass der alte nicht initialisierte Wert gelöscht wird.
/////
///     // Auch wenn während dieser Schleife ein panic vorhanden ist, liegt ein Speicherverlust vor, es gibt jedoch kein Problem mit der Speichersicherheit.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Alles ist initialisiert.
///     // Wandeln Sie das Array in den initialisierten Typ um.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Sie können auch mit teilweise initialisierten Arrays arbeiten, die in Datenstrukturen auf niedriger Ebene zu finden sind.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Erstellen Sie ein nicht initialisiertes Array von `MaybeUninit`.
/// // Der `assume_init` ist sicher, da der Typ, von dem wir behaupten, dass er hier initialisiert wurde, eine Reihe von "MaybeUninit" ist, für die keine Initialisierung erforderlich ist.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Zählen Sie die Anzahl der Elemente, die wir zugewiesen haben.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Löschen Sie für jedes Element im Array, wenn wir es zugewiesen haben.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Feld für Feld eine Struktur initialisieren
///
/// Sie können `MaybeUninit<T>` und das [`std::ptr::addr_of_mut`]-Makro verwenden, um Strukturen Feld für Feld zu initialisieren:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initialisieren des `name`-Feldes
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initialisieren des `list`-Feldes Wenn hier ein panic vorhanden ist, ist das `String` im `name`-Feld undicht.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Alle Felder werden initialisiert, daher rufen wir `assume_init` auf, um ein initialisiertes Foo zu erhalten.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` hat garantiert die gleiche Größe, Ausrichtung und ABI wie `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Denken Sie jedoch daran, dass ein Typ *, der* einen `MaybeUninit<T>` enthält, nicht unbedingt dasselbe Layout hat.Rust garantiert im Allgemeinen nicht, dass die Felder eines `Foo<T>` dieselbe Reihenfolge wie ein `Foo<U>` haben, auch wenn `T` und `U` dieselbe Größe und Ausrichtung haben.
///
/// Da ein beliebiger Bitwert für ein `MaybeUninit<T>` gültig ist, kann der Compiler keine non-zero/niche-filling-Optimierungen anwenden, was möglicherweise zu einer größeren Größe führt:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Wenn `T` FFI-sicher ist, ist dies auch `MaybeUninit<T>`.
///
/// Während `MaybeUninit` `#[repr(transparent)]` ist (was anzeigt, dass es die gleiche Größe, Ausrichtung und ABI wie `T` garantiert), ändert dies *nichts* an den vorherigen Einschränkungen.
/// `Option<T>` und `Option<MaybeUninit<T>>` können immer noch unterschiedliche Größen haben, und Typen, die ein Feld vom Typ `T` enthalten, können anders angeordnet (und dimensioniert) sein, als wenn dieses Feld `MaybeUninit<T>` wäre.
/// `MaybeUninit` ist ein Gewerkschaftstyp und `#[repr(transparent)]` bei Gewerkschaften ist instabil (siehe [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Im Laufe der Zeit können sich die genauen Garantien von `#[repr(transparent)]` für Gewerkschaften weiterentwickeln, und `MaybeUninit` kann `#[repr(transparent)]` bleiben oder nicht.
/// Das heißt, `MaybeUninit<T>` garantiert *immer*, dass es die gleiche Größe, Ausrichtung und ABI wie `T` hat.Es ist nur so, dass sich die Art und Weise, wie `MaybeUninit` diese Garantie implementiert, möglicherweise weiterentwickelt.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang Artikel, damit wir andere Typen darin einwickeln können.Dies ist nützlich für Generatoren.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Wenn wir `T::clone()` nicht aufrufen, können wir nicht wissen, ob wir dafür ausreichend initialisiert sind.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Erstellt einen neuen `MaybeUninit<T>`, der mit dem angegebenen Wert initialisiert wurde.
    /// Es ist sicher, [`assume_init`] für den Rückgabewert dieser Funktion aufzurufen.
    ///
    /// Beachten Sie, dass beim Löschen eines `MaybeUninit<T>` niemals der Drop-Code von `T` aufgerufen wird.
    /// Es liegt in Ihrer Verantwortung, sicherzustellen, dass `T` gelöscht wird, wenn es initialisiert wird.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Erstellt einen neuen `MaybeUninit<T>` in einem nicht initialisierten Zustand.
    ///
    /// Beachten Sie, dass beim Löschen eines `MaybeUninit<T>` niemals der Drop-Code von `T` aufgerufen wird.
    /// Es liegt in Ihrer Verantwortung, sicherzustellen, dass `T` gelöscht wird, wenn es initialisiert wird.
    ///
    /// Im [type-level documentation][MaybeUninit] finden Sie einige Beispiele.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Erstellen Sie ein neues Array von `MaybeUninit<T>`-Elementen in einem nicht initialisierten Zustand.
    ///
    /// Note: In einer future Rust-Version kann diese Methode unnötig werden, wenn die Array-Literal-Syntax [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) zulässt.
    ///
    /// Das folgende Beispiel könnte dann `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` verwenden.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Gibt einen (möglicherweise kleineren) Datenabschnitt zurück, der tatsächlich gelesen wurde
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SICHERHEIT: Ein nicht initialisierter `[MaybeUninit<_>; LEN]` ist gültig.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Erstellt ein neues `MaybeUninit<T>` in einem nicht initialisierten Zustand, wobei der Speicher mit `0`-Bytes gefüllt ist.Es hängt von `T` ab, ob dies bereits zu einer ordnungsgemäßen Initialisierung führt.
    ///
    /// Beispielsweise wird `MaybeUninit<usize>::zeroed()` initialisiert, `MaybeUninit<&'static i32>::zeroed()` jedoch nicht, da Referenzen nicht null sein dürfen.
    ///
    /// Beachten Sie, dass beim Löschen eines `MaybeUninit<T>` niemals der Drop-Code von `T` aufgerufen wird.
    /// Es liegt in Ihrer Verantwortung, sicherzustellen, dass `T` gelöscht wird, wenn es initialisiert wird.
    ///
    /// # Example
    ///
    /// Richtige Verwendung dieser Funktion: Initialisieren einer Struktur mit Null, wobei alle Felder der Struktur das Bitmuster 0 als gültigen Wert enthalten können.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Falsche* Verwendung dieser Funktion: Aufruf von `x.zeroed().assume_init()`, wenn `0` kein gültiges Bitmuster für den Typ ist:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Innerhalb eines Paares erstellen wir einen `NotZero`, der keine gültige Diskriminante hat.
    /// // Dies ist undefiniertes Verhalten.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SICHERHEIT: `u.as_mut_ptr()` zeigt auf den zugewiesenen Speicher.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Legt den Wert des `MaybeUninit<T>` fest.
    /// Dadurch wird jeder vorherige Wert überschrieben, ohne ihn zu löschen. Verwenden Sie diesen Wert daher nicht zweimal, es sei denn, Sie möchten die Ausführung des Destruktors überspringen.
    ///
    /// Für Ihre Bequemlichkeit gibt dies auch einen veränderlichen Verweis auf den (jetzt sicher initialisierten) Inhalt von `self` zurück.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SICHERHEIT: Wir haben diesen Wert gerade initialisiert.
        unsafe { self.assume_init_mut() }
    }

    /// Ruft einen Zeiger auf den enthaltenen Wert ab.
    /// Das Lesen von diesem Zeiger oder das Verwandeln in eine Referenz ist ein undefiniertes Verhalten, es sei denn, der `MaybeUninit<T>` wird initialisiert.
    /// Das Schreiben in den Speicher, auf das dieser Zeiger (non-transitively) zeigt, ist ein undefiniertes Verhalten (außer in einem `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Richtige Verwendung dieser Methode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Erstellen Sie eine Referenz im `MaybeUninit<T>`.Das ist okay, weil wir es initialisiert haben.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Falsche* Verwendung dieser Methode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Wir haben einen Verweis auf einen nicht initialisierten vector erstellt!Dies ist undefiniertes Verhalten.⚠️
    /// ```
    ///
    /// (Beachten Sie, dass die Regeln für Verweise auf nicht initialisierte Daten noch nicht endgültig sind. Bis dahin sollten Sie sie jedoch vermeiden.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` und `ManuallyDrop` sind beide `repr(transparent)`, sodass wir den Zeiger umwandeln können.
        self as *const _ as *const T
    }

    /// Ruft einen veränderlichen Zeiger auf den enthaltenen Wert ab.
    /// Das Lesen von diesem Zeiger oder das Verwandeln in eine Referenz ist ein undefiniertes Verhalten, es sei denn, der `MaybeUninit<T>` wird initialisiert.
    ///
    /// # Examples
    ///
    /// Richtige Verwendung dieser Methode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Erstellen Sie eine Referenz im `MaybeUninit<Vec<u32>>`.
    /// // Das ist okay, weil wir es initialisiert haben.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Falsche* Verwendung dieser Methode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Wir haben einen Verweis auf einen nicht initialisierten vector erstellt!Dies ist undefiniertes Verhalten.⚠️
    /// ```
    ///
    /// (Beachten Sie, dass die Regeln für Verweise auf nicht initialisierte Daten noch nicht endgültig sind. Bis dahin sollten Sie sie jedoch vermeiden.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` und `ManuallyDrop` sind beide `repr(transparent)`, sodass wir den Zeiger umwandeln können.
        self as *mut _ as *mut T
    }

    /// Extrahiert den Wert aus dem `MaybeUninit<T>`-Container.Dies ist eine großartige Möglichkeit, um sicherzustellen, dass die Daten gelöscht werden, da der resultierende `T` der üblichen Drop-Behandlung unterliegt.
    ///
    /// # Safety
    ///
    /// Es ist Sache des Anrufers, sicherzustellen, dass sich der `MaybeUninit<T>` wirklich in einem initialisierten Zustand befindet.Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, tritt sofort undefiniertes Verhalten auf.
    /// Der [type-level documentation][inv] enthält weitere Informationen zu dieser Initialisierungsinvariante.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Denken Sie außerdem daran, dass die meisten Typen zusätzliche Invarianten aufweisen, die nicht nur als auf Initialebene initialisiert betrachtet werden.
    /// Beispielsweise wird ein mit 1 initialisierter [`Vec<T>`] als initialisiert betrachtet (unter der aktuellen Implementierung; dies stellt keine stabile Garantie dar), da der Compiler nur weiß, dass der Datenzeiger nicht null sein muss.
    ///
    /// Das Erstellen eines solchen `Vec<T>` verursacht kein *sofortiges* undefiniertes Verhalten, sondern ein undefiniertes Verhalten bei den meisten sicheren Vorgängen (einschließlich des Löschens).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Richtige Verwendung dieser Methode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Falsche* Verwendung dieser Methode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` war noch nicht initialisiert worden, daher verursachte diese letzte Zeile undefiniertes Verhalten.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SICHERHEIT: Der Anrufer muss sicherstellen, dass `self` initialisiert wird.
        // Dies bedeutet auch, dass `self` eine `value`-Variante sein muss.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Liest den Wert aus dem `MaybeUninit<T>`-Container.Der resultierende `T` unterliegt der üblichen Drop-Handhabung.
    ///
    /// Wann immer möglich, ist es vorzuziehen, stattdessen [`assume_init`] zu verwenden, um zu verhindern, dass der Inhalt des `MaybeUninit<T>` dupliziert wird.
    ///
    /// # Safety
    ///
    /// Es ist Sache des Anrufers, sicherzustellen, dass sich der `MaybeUninit<T>` wirklich in einem initialisierten Zustand befindet.Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, führt dies zu undefiniertem Verhalten.
    /// Der [type-level documentation][inv] enthält weitere Informationen zu dieser Initialisierungsinvariante.
    ///
    /// Darüber hinaus bleibt im `MaybeUninit<T>` eine Kopie derselben Daten zurück.
    /// Wenn Sie mehrere Kopien der Daten verwenden (indem Sie `assume_init_read` mehrmals aufrufen oder zuerst `assume_init_read` und dann [`assume_init`] aufrufen), liegt es in Ihrer Verantwortung, sicherzustellen, dass diese Daten tatsächlich dupliziert werden.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Richtige Verwendung dieser Methode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ist `Copy`, daher können wir mehrmals lesen.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Das Duplizieren eines `None`-Werts ist in Ordnung, daher können wir mehrmals lesen.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Falsche* Verwendung dieser Methode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Wir haben jetzt zwei Kopien desselben vector erstellt, was zu einem doppelten freien ⚠️ führt, wenn beide fallen gelassen werden!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SICHERHEIT: Der Anrufer muss sicherstellen, dass `self` initialisiert wird.
        // Das Lesen von `self.as_ptr()` ist sicher, da `self` initialisiert werden sollte.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Löscht den enthaltenen Wert.
    ///
    /// Wenn Sie Eigentümer des `MaybeUninit` sind, können Sie stattdessen [`assume_init`] verwenden.
    ///
    /// # Safety
    ///
    /// Es ist Sache des Anrufers, sicherzustellen, dass sich der `MaybeUninit<T>` wirklich in einem initialisierten Zustand befindet.Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, führt dies zu undefiniertem Verhalten.
    ///
    /// Darüber hinaus müssen alle zusätzlichen Invarianten vom Typ `T` erfüllt sein, da die `Drop`-Implementierung von `T` (oder seinen Mitgliedern) davon abhängen kann.
    /// Beispielsweise wird ein mit 1 initialisierter [`Vec<T>`] als initialisiert betrachtet (unter der aktuellen Implementierung; dies stellt keine stabile Garantie dar), da der Compiler nur weiß, dass der Datenzeiger nicht null sein muss.
    ///
    /// Das Löschen eines solchen `Vec<T>` führt jedoch zu undefiniertem Verhalten.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SICHERHEIT: Der Anrufer muss garantieren, dass `self` initialisiert wird und
        // erfüllt alle Invarianten von `T`.
        // In diesem Fall ist es sicher, den Wert zu löschen.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ruft einen gemeinsamen Verweis auf den enthaltenen Wert ab.
    ///
    /// Dies kann nützlich sein, wenn wir auf einen `MaybeUninit` zugreifen möchten, der initialisiert wurde, aber keinen Besitz des `MaybeUninit` besitzt (wodurch die Verwendung von `.assume_init()`) verhindert wird).
    ///
    /// # Safety
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, führt dies zu undefiniertem Verhalten: Es ist Sache des Anrufers, sicherzustellen, dass sich der `MaybeUninit<T>` tatsächlich in einem initialisierten Zustand befindet.
    ///
    ///
    /// # Examples
    ///
    /// ### Richtige Verwendung dieser Methode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` initialisieren:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nachdem bekannt ist, dass unser `MaybeUninit<_>` initialisiert ist, ist es in Ordnung, einen gemeinsamen Verweis darauf zu erstellen:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SICHERHEIT: `x` wurde initialisiert.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Falsche* Verwendungen dieser Methode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Wir haben einen Verweis auf einen nicht initialisierten vector erstellt!Dies ist undefiniertes Verhalten.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialisieren Sie den `MaybeUninit` mit `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Verweis auf ein nicht initialisiertes `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SICHERHEIT: Der Anrufer muss sicherstellen, dass `self` initialisiert wird.
        // Dies bedeutet auch, dass `self` eine `value`-Variante sein muss.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ruft eine veränderbare (unique)-Referenz auf den enthaltenen Wert ab.
    ///
    /// Dies kann nützlich sein, wenn wir auf einen `MaybeUninit` zugreifen möchten, der initialisiert wurde, aber keinen Besitz des `MaybeUninit` besitzt (wodurch die Verwendung von `.assume_init()`) verhindert wird).
    ///
    /// # Safety
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, führt dies zu undefiniertem Verhalten: Es ist Sache des Anrufers, sicherzustellen, dass sich der `MaybeUninit<T>` tatsächlich in einem initialisierten Zustand befindet.
    /// Beispielsweise kann `.assume_init_mut()` nicht zum Initialisieren eines `MaybeUninit` verwendet werden.
    ///
    /// # Examples
    ///
    /// ### Richtige Verwendung dieser Methode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initialisiert *alle* Bytes des Eingabepuffers.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` initialisieren:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Jetzt wissen wir, dass `buf` initialisiert wurde, sodass wir es `.assume_init()` können.
    /// // Die Verwendung von `.assume_init()` kann jedoch ein `memcpy` der 2048 Bytes auslösen.
    /// // Um sicherzustellen, dass unser Puffer initialisiert wurde, ohne ihn zu kopieren, aktualisieren wir den `&mut MaybeUninit<[u8; 2048]>` auf einen `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SICHERHEIT: `buf` wurde initialisiert.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Jetzt können wir `buf` als normales Slice verwenden:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Falsche* Verwendungen dieser Methode:
    ///
    /// Sie können `.assume_init_mut()` nicht zum Initialisieren eines Werts verwenden:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Wir haben einen (mutable)-Verweis auf einen nicht initialisierten `bool` erstellt!
    ///     // Dies ist undefiniertes Verhalten.⚠️
    /// }
    /// ```
    ///
    /// Beispielsweise können Sie [`Read`] nicht in einen nicht initialisierten Puffer verschieben:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) Verweis auf nicht initialisierten Speicher!
    ///                             // Dies ist undefiniertes Verhalten.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Sie können den direkten Feldzugriff auch nicht verwenden, um eine schrittweise Initialisierung von Feld zu Feld durchzuführen:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Verweis auf nicht initialisierten Speicher!
    ///                  // Dies ist undefiniertes Verhalten.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Verweis auf nicht initialisierten Speicher!
    ///                  // Dies ist undefiniertes Verhalten.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Wir verlassen uns derzeit darauf, dass das oben Gesagte falsch ist, dh wir haben Verweise auf nicht initialisierte Daten (z. B. in `libcore/fmt/float.rs`).
    // Wir sollten vor der Stabilisierung eine endgültige Entscheidung über die Regeln treffen.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SICHERHEIT: Der Anrufer muss sicherstellen, dass `self` initialisiert wird.
        // Dies bedeutet auch, dass `self` eine `value`-Variante sein muss.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrahiert die Werte aus einem Array von `MaybeUninit`-Containern.
    ///
    /// # Safety
    ///
    /// Es ist Sache des Aufrufers, sicherzustellen, dass sich alle Elemente des Arrays in einem initialisierten Zustand befinden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SICHERHEIT: Jetzt sicher, da wir alle Elemente initialisiert haben
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Der Aufrufer garantiert, dass alle Elemente des Arrays initialisiert werden
        // * `MaybeUninit<T>` und T haben garantiert das gleiche Layout
        // * Vielleicht fällt Unint nicht ab, es gibt also keine doppelten Freiheiten. Somit ist die Konvertierung sicher
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Angenommen, alle Elemente sind initialisiert, erhalten Sie ein Slice.
    ///
    /// # Safety
    ///
    /// Es ist Sache des Aufrufers, sicherzustellen, dass sich die `MaybeUninit<T>`-Elemente tatsächlich in einem initialisierten Zustand befinden.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, führt dies zu undefiniertem Verhalten.
    ///
    /// Weitere Details und Beispiele finden Sie unter [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SICHERHEIT: Das Casting von Slice auf einen `*const [T]` ist sicher, da der Anrufer dies garantiert
        // `slice` wird initialisiert und`MaybeUninit` hat garantiert das gleiche Layout wie `T`.
        // Der erhaltene Zeiger ist gültig, da er sich auf den Speicher von `slice` bezieht, der eine Referenz ist und somit garantiert für Lesevorgänge gültig ist.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Angenommen, alle Elemente sind initialisiert, erhalten Sie ein veränderbares Slice.
    ///
    /// # Safety
    ///
    /// Es ist Sache des Aufrufers, sicherzustellen, dass sich die `MaybeUninit<T>`-Elemente tatsächlich in einem initialisierten Zustand befinden.
    ///
    /// Wenn Sie dies aufrufen, wenn der Inhalt noch nicht vollständig initialisiert ist, führt dies zu undefiniertem Verhalten.
    ///
    /// Weitere Details und Beispiele finden Sie unter [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SICHERHEIT: Ähnlich wie die Sicherheitshinweise für `slice_get_ref`, aber wir haben eine
        // veränderbare Referenz, die garantiert auch für Schreibvorgänge gültig ist.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ruft einen Zeiger auf das erste Element des Arrays ab.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ruft einen veränderlichen Zeiger auf das erste Element des Arrays ab.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopiert die Elemente von `src` nach `this` und gibt einen veränderlichen Verweis auf den jetzt initialisierten Inhalt von `this` zurück.
    ///
    /// Wenn `T` `Copy` nicht implementiert, verwenden Sie [`write_slice_cloned`]
    ///
    /// Dies ähnelt [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn die beiden Slices unterschiedliche Längen haben.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SICHERHEIT: Wir haben gerade alle Elemente von len in die freie Kapazität kopiert
    /// // Die ersten src.len()-Elemente des VEC sind jetzt gültig.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SICHERHEIT: &[T] und&[MaybeUninit<T>] haben das gleiche Layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SICHERHEIT: Gültige Elemente wurden gerade in `this` kopiert, damit sie initialisiert werden
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klont die Elemente von `src` auf `this` und gibt einen veränderlichen Verweis auf den jetzt initialisierten Inhalt von `this` zurück.
    /// Bereits initialisierte Elemente werden nicht gelöscht.
    ///
    /// Wenn `T` `Copy` implementiert, verwenden Sie [`write_slice`]
    ///
    /// Dies ähnelt [`slice::clone_from_slice`], löscht jedoch keine vorhandenen Elemente.
    ///
    /// # Panics
    ///
    /// Diese Funktion wird panic, wenn die beiden Slices unterschiedliche Längen haben oder wenn die Implementierung von `Clone` panics.
    ///
    /// Wenn es ein panic gibt, werden die bereits geklonten Elemente gelöscht.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SICHERHEIT: Wir haben gerade alle Elemente von len in die freie Kapazität geklont
    /// // Die ersten src.len()-Elemente des VEC sind jetzt gültig.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Im Gegensatz zu copy_from_slice wird hier nicht clone_from_slice auf dem Slice aufgerufen, da `MaybeUninit<T: Clone>` Clone nicht implementiert.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SICHERHEIT: Diese Rohscheibe enthält nur initialisierte Objekte
                // deshalb darf es fallen gelassen werden.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Wir müssen sie explizit auf die gleiche Länge schneiden
        // Damit die Überprüfung der Grenzen aufgehoben wird, generiert der Optimierer Memcpy für einfache Fälle (z. B. T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Schutz wird benötigt b/c panic kann während eines Klons auftreten
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SICHERHEIT: Gültige Elemente wurden gerade in `this` geschrieben, sodass es initialisiert wird
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}