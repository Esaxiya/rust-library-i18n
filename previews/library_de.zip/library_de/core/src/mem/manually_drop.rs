use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Ein Wrapper, der den Compiler daran hindert, den Destruktor von `T` automatisch aufzurufen.
/// Dieser Wrapper ist 0-Kosten.
///
/// `ManuallyDrop<T>` unterliegt den gleichen Layoutoptimierungen wie `T`.
/// Infolgedessen hat es *keine Auswirkung* auf die Annahmen, die der Compiler über seinen Inhalt macht.
/// Das Initialisieren eines `ManuallyDrop<&mut T>` mit [`mem::zeroed`] ist beispielsweise ein undefiniertes Verhalten.
/// Wenn Sie nicht initialisierte Daten verarbeiten müssen, verwenden Sie stattdessen [`MaybeUninit<T>`].
///
/// Beachten Sie, dass der Zugriff auf den Wert in einem `ManuallyDrop<T>` sicher ist.
/// Dies bedeutet, dass ein `ManuallyDrop<T>`, dessen Inhalt gelöscht wurde, nicht über eine öffentlich sichere API verfügbar gemacht werden darf.
/// Entsprechend ist `ManuallyDrop::drop` unsicher.
///
/// # `ManuallyDrop` und Bestellung aufgeben.
///
/// Rust hat ein genau definiertes [drop order] von Werten.
/// Um sicherzustellen, dass Felder oder Einheimische in einer bestimmten Reihenfolge gelöscht werden, ordnen Sie die Deklarationen so an, dass die implizite Löschreihenfolge die richtige ist.
///
/// Es ist möglich, `ManuallyDrop` zur Steuerung der Abwurfreihenfolge zu verwenden. Dies erfordert jedoch unsicheren Code und ist bei Abwicklung nur schwer korrekt durchzuführen.
///
///
/// Wenn Sie beispielsweise sicherstellen möchten, dass ein bestimmtes Feld nach den anderen gelöscht wird, machen Sie es zum letzten Feld einer Struktur:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` wird nach `children` gelöscht.
///     // Rust garantiert, dass Felder in der Reihenfolge der Deklaration gelöscht werden.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Wickeln Sie einen Wert ein, der manuell gelöscht werden soll.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Sie können den Wert weiterhin sicher bearbeiten
    /// assert_eq!(*x, "Hello");
    /// // Aber `Drop` wird hier nicht ausgeführt
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrahiert den Wert aus dem `ManuallyDrop`-Container.
    ///
    /// Dadurch kann der Wert wieder gelöscht werden.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dies lässt den `Box` fallen.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Nimmt den Wert aus dem `ManuallyDrop<T>`-Container heraus.
    ///
    /// Diese Methode ist hauptsächlich zum Verschieben von Drop-Werten vorgesehen.
    /// Anstatt [`ManuallyDrop::drop`] zum manuellen Löschen des Werts zu verwenden, können Sie diese Methode verwenden, um den Wert zu übernehmen und ihn wie gewünscht zu verwenden.
    ///
    /// Wann immer möglich, ist es vorzuziehen, stattdessen [`into_inner`][`ManuallyDrop::into_inner`] zu verwenden, um zu verhindern, dass der Inhalt des `ManuallyDrop<T>` dupliziert wird.
    ///
    ///
    /// # Safety
    ///
    /// Diese Funktion verschiebt den enthaltenen Wert semantisch, ohne eine weitere Verwendung zu verhindern, und lässt den Status dieses Containers unverändert.
    /// Es liegt in Ihrer Verantwortung sicherzustellen, dass dieser `ManuallyDrop` nicht wieder verwendet wird.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SICHERHEIT: Wir lesen aus einer Referenz, die garantiert ist
        // für Lesevorgänge gültig sein.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Löscht den enthaltenen Wert manuell.Dies entspricht genau dem Aufruf von [`ptr::drop_in_place`] mit einem Zeiger auf den enthaltenen Wert.
    /// Sofern der enthaltene Wert keine gepackte Struktur ist, wird der Destruktor an Ort und Stelle aufgerufen, ohne den Wert zu verschieben, und kann daher zum sicheren Löschen von [pinned]-Daten verwendet werden.
    ///
    /// Wenn Sie Eigentümer des Werts sind, können Sie stattdessen [`ManuallyDrop::into_inner`] verwenden.
    ///
    /// # Safety
    ///
    /// Diese Funktion führt den Destruktor des enthaltenen Werts aus.
    /// Abgesehen von Änderungen, die vom Destruktor selbst vorgenommen wurden, bleibt der Speicher unverändert, und für den Compiler enthält er immer noch ein Bitmuster, das für den Typ `T` gültig ist.
    ///
    ///
    /// Dieser "zombie"-Wert sollte jedoch keinem sicheren Code ausgesetzt werden, und diese Funktion sollte nicht mehr als einmal aufgerufen werden.
    /// Die Verwendung eines Werts nach dem Löschen oder das mehrfache Löschen eines Werts kann zu undefiniertem Verhalten führen (abhängig davon, was `drop` tut).
    /// Dies wird normalerweise vom Typsystem verhindert, aber Benutzer von `ManuallyDrop` müssen diese Garantien ohne Unterstützung des Compilers einhalten.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SICHERHEIT: Wir löschen den Wert, auf den eine veränderbare Referenz zeigt
        // Dies ist garantiert für Schreibvorgänge gültig.
        // Es ist Sache des Anrufers, sicherzustellen, dass `slot` nicht erneut gelöscht wird.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}