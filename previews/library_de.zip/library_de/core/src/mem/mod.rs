//! Grundfunktionen für den Umgang mit dem Gedächtnis.
//!
//! Dieses Modul enthält Funktionen zum Abfragen der Größe und Ausrichtung von Typen sowie zum Initialisieren und Bearbeiten des Speichers.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Übernimmt den Besitz und "forgets" über den Wert **, ohne den Destruktor** auszuführen.
///
/// Alle Ressourcen, die der Wert verwaltet, wie z. B. Heapspeicher oder ein Dateihandle, bleiben für immer in einem nicht erreichbaren Zustand.Es kann jedoch nicht garantiert werden, dass Zeiger auf diesen Speicher gültig bleiben.
///
/// * Wenn Sie Speicher verlieren möchten, lesen Sie [`Box::leak`].
/// * Wenn Sie einen Rohzeiger auf den Speicher erhalten möchten, lesen Sie [`Box::into_raw`].
/// * Wenn Sie einen Wert ordnungsgemäß entsorgen möchten, indem Sie seinen Destruktor ausführen, lesen Sie [`mem::drop`].
///
/// # Safety
///
/// `forget` ist nicht als `unsafe` gekennzeichnet, da die Sicherheitsgarantien von Rust keine Garantie enthalten, dass Destruktoren immer ausgeführt werden.
/// Ein Programm kann beispielsweise einen Referenzzyklus mit [`Rc`][rc] erstellen oder [`process::exit`][exit] aufrufen, um das Programm zu beenden, ohne Destruktoren auszuführen.
/// Das Zulassen von `mem::forget` aus sicherem Code ändert daher die Sicherheitsgarantien von Rust nicht grundlegend.
///
/// Das Auslaufen von Ressourcen wie Speicher oder I/O-Objekten ist jedoch normalerweise unerwünscht.
/// Der Bedarf tritt in einigen speziellen Anwendungsfällen für FFI oder unsicheren Code auf, aber selbst dann wird [`ManuallyDrop`] normalerweise bevorzugt.
///
/// Da das Vergessen eines Werts zulässig ist, muss jeder von Ihnen geschriebene `unsafe`-Code diese Möglichkeit berücksichtigen.Sie können keinen Wert zurückgeben und erwarten, dass der Aufrufer unbedingt den Destruktor des Werts ausführt.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Die kanonisch sichere Verwendung von `mem::forget` besteht darin, den vom `Drop` trait implementierten Destruktor eines Werts zu umgehen.Dies führt beispielsweise dazu, dass ein `File` ausläuft, d. H.
/// Stellen Sie den von der Variablen belegten Speicherplatz wieder her, schließen Sie jedoch niemals die zugrunde liegende Systemressource:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dies ist nützlich, wenn der Besitz der zugrunde liegenden Ressource zuvor auf Code außerhalb von Rust übertragen wurde, z. B. durch Übertragen des Rohdateideskriptors an C-Code.
///
/// # Beziehung zu `ManuallyDrop`
///
/// Während `mem::forget` auch zum Übertragen von *Speicher*-Eigentum verwendet werden kann, ist dies fehleranfällig.
/// [`ManuallyDrop`] sollte stattdessen verwendet werden.Betrachten Sie zum Beispiel diesen Code:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Erstellen Sie einen `String` mit dem Inhalt von `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // Leck `v`, weil sein Speicher jetzt von `s` verwaltet wird
/// mem::forget(v);  // ERROR, v ist ungültig und darf nicht an eine Funktion übergeben werden
/// assert_eq!(s, "Az");
/// // `s` wird implizit gelöscht und sein Speicher freigegeben.
/// ```
///
/// Beim obigen Beispiel gibt es zwei Probleme:
///
/// * Wenn zwischen der Konstruktion von `String` und dem Aufruf von `mem::forget()` mehr Code hinzugefügt würde, würde ein darin enthaltenes panic eine doppelte Freigabe verursachen, da sowohl `v` als auch `s` denselben Speicher verarbeiten.
/// * Nach dem Aufruf von `v.as_mut_ptr()` und der Übertragung des Eigentums an den Daten an `s` ist der `v`-Wert ungültig.
/// Selbst wenn ein Wert nur auf `mem::forget` verschoben wird (was ihn nicht überprüft), stellen einige Typen strenge Anforderungen an ihre Werte, die sie ungültig machen, wenn sie baumeln oder nicht mehr im Besitz sind.
/// Die Verwendung ungültiger Werte in irgendeiner Weise, einschließlich der Übergabe an oder der Rückgabe von Funktionen, stellt ein undefiniertes Verhalten dar und kann die vom Compiler getroffenen Annahmen verletzen.
///
/// Durch den Wechsel zu `ManuallyDrop` werden beide Probleme vermieden:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Bevor wir `v` in seine Rohteile zerlegen, stellen Sie sicher, dass es nicht fallen gelassen wird!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Zerlegen Sie nun `v`.Diese Vorgänge können nicht panic ausführen, daher kann kein Leck vorliegen.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Erstellen Sie schließlich einen `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` wird implizit gelöscht und sein Speicher freigegeben.
/// ```
///
/// `ManuallyDrop` Verhindert das Doppelte frei, da wir den Destruktor von "v" deaktivieren, bevor wir etwas anderes tun.
/// `mem::forget()` erlaubt dies nicht, weil es sein Argument verbraucht und uns zwingt, es erst aufzurufen, nachdem wir alles extrahiert haben, was wir von `v` benötigen.
/// Selbst wenn ein panic zwischen der Erstellung von `ManuallyDrop` und dem Erstellen des Strings eingeführt würde (was im Code nicht wie gezeigt vorkommen kann), würde dies zu einem Leck und nicht zu einem doppelten freien Ergebnis führen.
/// Mit anderen Worten, `ManuallyDrop` irrt auf der Seite des Lecks, anstatt sich auf der Seite des (Doppel-) Fallens zu irren.
///
/// Außerdem verhindert `ManuallyDrop`, dass wir nach der Übertragung des Eigentums an `s` "touch" `v` benötigen-der letzte Schritt der Interaktion mit `v`, um es zu entsorgen, ohne den Destruktor auszuführen, wird vollständig vermieden.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Wie [`forget`], akzeptiert aber auch nicht dimensionierte Werte.
///
/// Diese Funktion ist nur eine Unterlegscheibe, die entfernt werden soll, wenn sich die `unsized_locals`-Funktion stabilisiert.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Gibt die Größe eines Typs in Bytes zurück.
///
/// Insbesondere ist dies der Versatz in Bytes zwischen aufeinanderfolgenden Elementen in einem Array mit diesem Elementtyp einschließlich Ausrichtungsauffüllung.
///
/// Somit hat `[T; n]` für jeden Typ `T` und jede Länge `n` eine Größe von `n * size_of::<T>()`.
///
/// Im Allgemeinen ist die Größe eines Typs über Kompilierungen hinweg nicht stabil, bestimmte Typen wie Grundelemente jedoch.
///
/// Die folgende Tabelle gibt die Größe für Grundelemente an.
///
/// Geben Sie | einGröße von: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Darüber hinaus haben `usize` und `isize` die gleiche Größe.
///
/// Die Typen `*const T`, `&T`, `Box<T>`, `Option<&T>` und `Option<Box<T>>` haben alle dieselbe Größe.
/// Wenn `T` die Größe hat, haben alle diese Typen dieselbe Größe wie `usize`.
///
/// Die Veränderbarkeit eines Zeigers ändert seine Größe nicht.Daher haben `&T` und `&mut T` die gleiche Größe.
/// Ebenso für `*const T` und `* mut T`.
///
/// # Größe der `#[repr(C)]`-Artikel
///
/// Die `C`-Darstellung für Elemente hat ein definiertes Layout.
/// Bei diesem Layout ist die Größe der Elemente auch stabil, solange alle Felder eine stabile Größe haben.
///
/// ## Größe der Strukturen
///
/// Für `structs` wird die Größe durch den folgenden Algorithmus bestimmt.
///
/// Für jedes Feld in der Struktur, sortiert nach Deklarationsreihenfolge:
///
/// 1. Fügen Sie die Größe des Feldes hinzu.
/// 2. Runden Sie die aktuelle Größe auf das nächste Vielfache des [alignment] des nächsten Felds auf.
///
/// Runden Sie abschließend die Größe der Struktur auf das nächste Vielfache ihres [alignment].
/// Die Ausrichtung der Struktur ist normalerweise die größte Ausrichtung aller ihrer Felder.Dies kann mit `repr(align(N))` geändert werden.
///
/// Im Gegensatz zu `C` werden Strukturen mit der Größe Null nicht auf ein Byte aufgerundet.
///
/// ## Größe der Aufzählungen
///
/// Aufzählungen, die keine anderen Daten als die Diskriminante enthalten, haben dieselbe Größe wie C-Aufzählungen auf der Plattform, für die sie kompiliert wurden.
///
/// ## Größe der Gewerkschaften
///
/// Die Größe einer Gewerkschaft entspricht der Größe ihres größten Feldes.
///
/// Im Gegensatz zu `C` werden Gewerkschaften mit der Größe Null nicht auf ein Byte aufgerundet.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Einige Grundelemente
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Einige Arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Zeigergrößengleichheit
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Verwenden von `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Die Größe des ersten Feldes ist 1, also addieren Sie 1 zur Größe.Größe ist 1.
/// // Die Ausrichtung des zweiten Felds ist 2, also addieren Sie 1 zur Größe für das Auffüllen.Größe ist 2.
/// // Die Größe des zweiten Feldes beträgt 2, also addieren Sie 2 zur Größe.Größe ist 4.
/// // Die Ausrichtung des dritten Felds ist 1, also addieren Sie 0 zur Größe für das Auffüllen.Größe ist 4.
/// // Die Größe des dritten Feldes ist 1, also addieren Sie 1 zur Größe.Größe ist 5.
/// // Schließlich ist die Ausrichtung der Struktur 2 (da die größte Ausrichtung unter ihren Feldern 2 ist), also addieren Sie 1 zur Größe für das Auffüllen.
/// // Größe ist 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tupelstrukturen folgen denselben Regeln.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Beachten Sie, dass das Neuanordnen der Felder die Größe verringern kann.
/// // Wir können beide Füllbytes entfernen, indem wir `third` vor `second` setzen.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Die Größe der Union ist die Größe des größten Feldes.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Gibt die Größe des Verweiswerts in Byte zurück.
///
/// Dies ist normalerweise dasselbe wie bei `size_of::<T>()`.
/// Wenn `T` * keine statisch bekannte Größe hat, z. B. ein Slice [`[T]`][slice] oder ein [trait object], kann `size_of_val` verwendet werden, um die dynamisch bekannte Größe zu erhalten.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SICHERHEIT: `val` ist eine Referenz, also ein gültiger Rohzeiger
    unsafe { intrinsics::size_of_val(val) }
}

/// Gibt die Größe des Verweiswerts in Byte zurück.
///
/// Dies ist normalerweise dasselbe wie bei `size_of::<T>()`.Wenn `T` * keine statisch bekannte Größe hat, z. B. ein Slice [`[T]`][slice] oder ein [trait object], kann `size_of_val_raw` verwendet werden, um die dynamisch bekannte Größe zu erhalten.
///
/// # Safety
///
/// Diese Funktion kann nur sicher aufgerufen werden, wenn die folgenden Bedingungen erfüllt sind:
///
/// - Wenn `T` `Sized` ist, kann diese Funktion immer sicher aufgerufen werden.
/// - Wenn der nicht dimensionierte Schwanz von `T` ist:
///     - Bei einem [slice] muss die Länge des Slice-Endes eine initialisierte Ganzzahl sein, und die Größe des *gesamten Werts*(dynamische Schwanzlänge + statisch großes Präfix) muss in `isize` passen.
///     - a [trait object], dann muss der vtable-Teil des Zeigers auf eine gültige vtable zeigen, die durch einen nicht dimensionierten Zwang erfasst wurde, und die Größe des *gesamten Werts*(dynamische Schwanzlänge + statisch dimensioniertes Präfix) muss in `isize` passen.
///
///     - ein (unstable) [extern type], dann ist diese Funktion immer sicher aufzurufen, kann aber panic oder auf andere Weise den falschen Wert zurückgeben, da das Layout des externen Typs nicht bekannt ist.
///     Dies ist das gleiche Verhalten wie bei [`size_of_val`] bei einem Verweis auf einen Typ mit einem externen Typende.
///     - Andernfalls darf diese Funktion konservativ nicht aufgerufen werden.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SICHERHEIT: Der Aufrufer muss einen gültigen Rohzeiger bereitstellen
    unsafe { intrinsics::size_of_val(val) }
}

/// Gibt die von [ABI] erforderliche Mindestausrichtung eines Typs zurück.
///
/// Jeder Verweis auf einen Wert vom Typ `T` muss ein Vielfaches dieser Zahl sein.
///
/// Dies ist die Ausrichtung, die für Strukturfelder verwendet wird.Sie kann kleiner als die bevorzugte Ausrichtung sein.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Gibt die von [ABI] erforderliche Mindestausrichtung des Werttyps zurück, auf den `val` zeigt.
///
/// Jeder Verweis auf einen Wert vom Typ `T` muss ein Vielfaches dieser Zahl sein.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SICHERHEIT: val ist eine Referenz, also ein gültiger Rohzeiger
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Gibt die von [ABI] erforderliche Mindestausrichtung eines Typs zurück.
///
/// Jeder Verweis auf einen Wert vom Typ `T` muss ein Vielfaches dieser Zahl sein.
///
/// Dies ist die Ausrichtung, die für Strukturfelder verwendet wird.Sie kann kleiner als die bevorzugte Ausrichtung sein.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Gibt die von [ABI] erforderliche Mindestausrichtung des Werttyps zurück, auf den `val` zeigt.
///
/// Jeder Verweis auf einen Wert vom Typ `T` muss ein Vielfaches dieser Zahl sein.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SICHERHEIT: val ist eine Referenz, also ein gültiger Rohzeiger
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Gibt die von [ABI] erforderliche Mindestausrichtung des Werttyps zurück, auf den `val` zeigt.
///
/// Jeder Verweis auf einen Wert vom Typ `T` muss ein Vielfaches dieser Zahl sein.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Diese Funktion kann nur sicher aufgerufen werden, wenn die folgenden Bedingungen erfüllt sind:
///
/// - Wenn `T` `Sized` ist, kann diese Funktion immer sicher aufgerufen werden.
/// - Wenn der nicht dimensionierte Schwanz von `T` ist:
///     - Bei einem [slice] muss die Länge des Slice-Endes eine initialisierte Ganzzahl sein, und die Größe des *gesamten Werts*(dynamische Schwanzlänge + statisch großes Präfix) muss in `isize` passen.
///     - a [trait object], dann muss der vtable-Teil des Zeigers auf eine gültige vtable zeigen, die durch einen nicht dimensionierten Zwang erfasst wurde, und die Größe des *gesamten Werts*(dynamische Schwanzlänge + statisch dimensioniertes Präfix) muss in `isize` passen.
///
///     - ein (unstable) [extern type], dann ist diese Funktion immer sicher aufzurufen, kann aber panic oder auf andere Weise den falschen Wert zurückgeben, da das Layout des externen Typs nicht bekannt ist.
///     Dies ist das gleiche Verhalten wie bei [`align_of_val`] bei einem Verweis auf einen Typ mit einem externen Typende.
///     - Andernfalls darf diese Funktion konservativ nicht aufgerufen werden.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SICHERHEIT: Der Aufrufer muss einen gültigen Rohzeiger bereitstellen
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Gibt `true` zurück, wenn das Löschen von Werten vom Typ `T` von Bedeutung ist.
///
/// Dies ist lediglich ein Optimierungshinweis und kann konservativ implementiert werden:
/// Möglicherweise wird `true` für Typen zurückgegeben, die nicht gelöscht werden müssen.
/// Daher wäre die Rückgabe von `true` eine gültige Implementierung dieser Funktion.Wenn diese Funktion jedoch tatsächlich `false` zurückgibt, können Sie sicher sein, dass das Löschen von `T` keine Nebenwirkungen hat.
///
/// Low-Level-Implementierungen von Dingen wie Sammlungen, die ihre Daten manuell löschen müssen, sollten diese Funktion verwenden, um zu vermeiden, dass unnötig versucht wird, ihren gesamten Inhalt zu löschen, wenn sie zerstört werden.
///
/// Dies macht möglicherweise keinen Unterschied bei Release-Builds (bei denen eine Schleife ohne Nebenwirkungen leicht erkannt und beseitigt werden kann), ist jedoch häufig ein großer Gewinn für Debug-Builds.
///
/// Beachten Sie, dass [`drop_in_place`] diese Prüfung bereits durchführt. Wenn Ihre Arbeitslast auf eine geringe Anzahl von [`drop_in_place`]-Aufrufen reduziert werden kann, ist dies nicht erforderlich.
/// Beachten Sie insbesondere, dass Sie ein Slice [`drop_in_place`]-fähig machen können und dass dadurch eine einzige Needs_drop-Prüfung für alle Werte durchgeführt wird.
///
/// Typen wie Vec sind daher nur `drop_in_place(&mut self[..])` ohne explizite Verwendung von `needs_drop`.
/// Typen wie [`HashMap`] müssen dagegen nacheinander Werte löschen und sollten diese API verwenden.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hier ist ein Beispiel, wie eine Sammlung `needs_drop` verwenden kann:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // Löschen Sie die Daten
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Gibt den Wert vom Typ `T` zurück, der durch das All-Zero-Byte-Muster dargestellt wird.
///
/// Dies bedeutet, dass beispielsweise das Füllbyte in `(u8, u16)` nicht unbedingt auf Null gesetzt wird.
///
/// Es gibt keine Garantie dafür, dass ein All-Null-Byte-Muster einen gültigen Wert eines Typs `T` darstellt.
/// Beispielsweise ist das All-Null-Byte-Muster kein gültiger Wert für Referenztypen (`&T`, `&mut T`) und Funktionszeiger.
/// Die Verwendung von `zeroed` bei solchen Typen führt zu sofortigem [undefined behavior][ub], da [the Rust compiler assumes][inv] immer einen gültigen Wert in einer Variablen enthält, die als initialisiert betrachtet wird.
///
///
/// Dies hat den gleichen Effekt wie [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Es ist manchmal nützlich für FFI, sollte aber generell vermieden werden.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Richtige Verwendung dieser Funktion: Initialisieren einer Ganzzahl mit Null.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Falsche* Verwendung dieser Funktion: Initialisieren einer Referenz mit Null.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Undefiniertes Verhalten!
/// let _y: fn() = unsafe { mem::zeroed() }; // Und wieder!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SICHERHEIT: Der Anrufer muss garantieren, dass für `T` ein Wert ungleich Null gültig ist.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Umgeht die normalen Speicherinitialisierungsprüfungen von Rust, indem es vorgibt, einen Wert vom Typ `T` zu erzeugen, ohne etwas zu tun.
///
/// **Diese Funktion ist veraltet.** Verwenden Sie stattdessen [`MaybeUninit<T>`].
///
/// Der Grund für die Ablehnung ist, dass die Funktion grundsätzlich nicht richtig verwendet werden kann: Sie hat den gleichen Effekt wie [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Wie der [`assume_init` documentation][assume_init] erklärt, [the Rust compiler assumes][inv], werden diese Werte ordnungsgemäß initialisiert.
/// Infolgedessen wird z
/// `mem::uninitialized::<bool>()` Verursacht sofort undefiniertes Verhalten bei der Rückgabe eines `bool`, das weder `true` noch `false` ist.
/// Schlimmer noch, wirklich nicht initialisierter Speicher, wie er hier zurückgegeben wird, ist insofern besonders, als der Compiler weiß, dass er keinen festen Wert hat.
/// Dies macht es zu einem undefinierten Verhalten, nicht initialisierte Daten in einer Variablen zu haben, selbst wenn diese Variable einen ganzzahligen Typ hat.
/// (Beachten Sie, dass die Regeln für nicht initialisierte Ganzzahlen noch nicht endgültig sind. Bis dahin ist es jedoch ratsam, sie zu vermeiden.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SICHERHEIT: Der Anrufer muss garantieren, dass ein einheitlicher Wert für `T` gültig ist.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Vertauscht die Werte an zwei veränderlichen Stellen, ohne eine zu deinitialisieren.
///
/// * Wenn Sie mit einem Standard-oder Dummy-Wert tauschen möchten, lesen Sie [`take`].
/// * Wenn Sie mit einem übergebenen Wert tauschen und den alten Wert zurückgeben möchten, lesen Sie [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SICHERHEIT: Die Rohzeiger wurden aus sicheren veränderlichen Referenzen erstellt, die alle Anforderungen erfüllen
    // Einschränkungen für `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ersetzt `dest` durch den Standardwert `T` und gibt den vorherigen `dest`-Wert zurück.
///
/// * Wenn Sie die Werte von zwei Variablen ersetzen möchten, lesen Sie [`swap`].
/// * Wenn Sie anstelle des Standardwerts einen übergebenen Wert ersetzen möchten, lesen Sie [`replace`].
///
/// # Examples
///
/// Ein einfaches Beispiel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` Ermöglicht die Übernahme des Besitzes eines Strukturfelds durch Ersetzen durch einen "empty"-Wert.
/// Ohne `take` können folgende Probleme auftreten:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Beachten Sie, dass `T` [`Clone`] nicht unbedingt implementiert, sodass `self.buf` nicht einmal geklont und zurückgesetzt werden kann.
/// Mit `take` kann der ursprüngliche Wert von `self.buf` von `self` getrennt werden, sodass er zurückgegeben werden kann:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Verschiebt `src` in das referenzierte `dest` und gibt den vorherigen `dest`-Wert zurück.
///
/// Keiner der Werte wird gelöscht.
///
/// * Wenn Sie die Werte von zwei Variablen ersetzen möchten, lesen Sie [`swap`].
/// * Wenn Sie durch einen Standardwert ersetzen möchten, lesen Sie [`take`].
///
/// # Examples
///
/// Ein einfaches Beispiel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` Ermöglicht die Verwendung eines Strukturfelds durch Ersetzen durch einen anderen Wert.
/// Ohne `replace` können folgende Probleme auftreten:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Beachten Sie, dass `T` nicht unbedingt [`Clone`] implementiert, sodass wir `self.buf[i]` nicht einmal klonen können, um die Verschiebung zu vermeiden.
/// Mit `replace` kann der ursprüngliche Wert an diesem Index jedoch von `self` getrennt werden, sodass er zurückgegeben werden kann:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SICHERHEIT: Wir lesen von `dest`, schreiben danach aber direkt `src` hinein.
    // so dass der alte Wert nicht dupliziert wird.
    // Nichts wird fallen gelassen und nichts hier kann panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Entsorgt über einen Wert.
///
/// Dies geschieht durch Aufrufen der Implementierung von [`Drop`][drop] durch das Argument.
///
/// Dies bewirkt effektiv nichts für Typen, die `Copy` implementieren, z
/// integers.
/// Solche Werte werden kopiert und _then_ in die Funktion verschoben, sodass der Wert nach diesem Funktionsaufruf erhalten bleibt.
///
///
/// Diese Funktion ist keine Magie;es ist wörtlich definiert als
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Da `_x` in die Funktion verschoben wird, wird es automatisch gelöscht, bevor die Funktion zurückkehrt.
///
/// [drop]: Drop
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // Lassen Sie den vector explizit fallen
/// ```
///
/// Da [`RefCell`] die Ausleihregeln zur Laufzeit erzwingt, kann `drop` eine [`RefCell`]-Ausleihe freigeben:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // Geben Sie den veränderlichen Kredit auf diesem Slot auf
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ganzzahlen und andere Typen, die [`Copy`] implementieren, sind von `drop` nicht betroffen.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // Eine Kopie von `x` wird verschoben und gelöscht
/// drop(y); // Eine Kopie von `y` wird verschoben und gelöscht
///
/// println!("x: {}, y: {}", x, y.0); // noch verfügbar
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretiert `src` als Typ `&U` und liest dann `src`, ohne den enthaltenen Wert zu verschieben.
///
/// Diese Funktion geht unsicher davon aus, dass der Zeiger `src` für [`size_of::<U>`][size_of]-Bytes gültig ist, indem `&T` in `&U` umgewandelt und dann `&U` gelesen wird (außer dass dies auf eine Weise erfolgt, die auch dann korrekt ist, wenn `&U` strengere Ausrichtungsanforderungen als `&T` stellt).
/// Außerdem wird eine Kopie des enthaltenen Werts unsicher erstellt, anstatt `src` zu verlassen.
///
/// Es ist kein Fehler bei der Kompilierung, wenn `T` und `U` unterschiedliche Größen haben. Es wird jedoch dringend empfohlen, diese Funktion nur aufzurufen, wenn `T` und `U` dieselbe Größe haben.Diese Funktion löst [undefined behavior][ub] aus, wenn `U` größer als `T` ist.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopieren Sie die Daten von 'foo_array' und behandeln Sie sie als 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Ändern Sie die kopierten Daten
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Der Inhalt von 'foo_array' sollte sich nicht geändert haben
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Wenn U eine höhere Ausrichtungsanforderung hat, ist src möglicherweise nicht geeignet ausgerichtet.
    if align_of::<U>() > align_of::<T>() {
        // SICHERHEIT: `src` ist eine Referenz, die garantiert für Lesevorgänge gültig ist.
        // Der Anrufer muss garantieren, dass die tatsächliche Umwandlung sicher ist.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SICHERHEIT: `src` ist eine Referenz, die garantiert für Lesevorgänge gültig ist.
        // Wir haben gerade überprüft, ob `src as *const U` richtig ausgerichtet ist.
        // Der Anrufer muss garantieren, dass die tatsächliche Umwandlung sicher ist.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Undurchsichtiger Typ, der die Diskriminante einer Aufzählung darstellt.
///
/// Weitere Informationen finden Sie in der [`discriminant`]-Funktion in diesem Modul.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Diese trait-Implementierungen können nicht abgeleitet werden, da wir keine Grenzen für T haben wollen.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Gibt einen Wert zurück, der die Enum-Variante in `v` eindeutig identifiziert.
///
/// Wenn `T` keine Aufzählung ist, führt das Aufrufen dieser Funktion nicht zu einem undefinierten Verhalten, aber der Rückgabewert ist nicht angegeben.
///
///
/// # Stability
///
/// Die Diskriminante einer Aufzählungsvariante kann sich ändern, wenn sich die Aufzählungsdefinition ändert.
/// Eine Diskriminante einer Variante ändert sich nicht zwischen Kompilierungen mit demselben Compiler.
///
/// # Examples
///
/// Dies kann verwendet werden, um Aufzählungen zu vergleichen, die Daten enthalten, ohne die tatsächlichen Daten zu berücksichtigen:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Gibt die Anzahl der Varianten im Aufzählungstyp `T` zurück.
///
/// Wenn `T` keine Aufzählung ist, führt das Aufrufen dieser Funktion nicht zu einem undefinierten Verhalten, aber der Rückgabewert ist nicht angegeben.
/// Wenn `T` eine Aufzählung mit mehr Varianten als `usize::MAX` ist, ist der Rückgabewert ebenfalls nicht angegeben.
/// Unbewohnte Varianten werden gezählt.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}