//! Der `Clone` trait für Typen, die nicht implizit kopiert werden können.
//!
//! In Rust sind einige einfache Typen "implicitly copyable". Wenn Sie sie zuweisen oder als Argumente übergeben, erhält der Empfänger eine Kopie, wobei der ursprüngliche Wert erhalten bleibt.
//! Diese Typen erfordern keine Zuordnung zum Kopieren und verfügen nicht über Finalizer (dh sie enthalten keine eigenen Boxen oder implementieren [`Drop`]), sodass der Compiler sie für billig und sicher zum Kopieren hält.
//!
//! Für andere Typen müssen Kopien explizit erstellt werden, indem der [`Clone`] trait implementiert und die [`clone`]-Methode aufgerufen wird.
//!
//! [`clone`]: Clone::clone
//!
//! Grundlegendes Anwendungsbeispiel:
//!
//! ```
//! let s = String::new(); // Der String-Typ implementiert Clone
//! let copy = s.clone(); // damit wir es klonen können
//! ```
//!
//! Um den Clone trait einfach zu implementieren, können Sie auch `#[derive(Clone)]` verwenden.Beispiel:
//!
//! ```
//! #[derive(Clone)] // Wir fügen den Klon trait zur Morpheus-Struktur hinzu
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // und jetzt können wir es klonen!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Ein allgemeines trait für die Fähigkeit, ein Objekt explizit zu duplizieren.
///
/// Unterscheidet sich von [`Copy`] darin, dass [`Copy`] implizit und äußerst kostengünstig ist, während `Clone` immer explizit ist und möglicherweise teuer ist oder nicht.
/// Um diese Eigenschaften zu erzwingen, können Sie in Rust [`Copy`] nicht erneut implementieren. Sie können jedoch `Clone` erneut implementieren und beliebigen Code ausführen.
///
/// Da `Clone` allgemeiner als [`Copy`] ist, können Sie automatisch festlegen, dass [`Copy`] auch `Clone` ist.
///
/// ## Derivable
///
/// Dieser trait kann mit `#[derive]` verwendet werden, wenn alle Felder `Clone` sind.Die "abgeleitete" Implementierung von [`Clone`] ruft [`clone`] für jedes Feld auf.
///
/// [`clone`]: Clone::clone
///
/// Für eine generische Struktur implementiert `#[derive]` `Clone` bedingt, indem gebundenes `Clone` für generische Parameter hinzugefügt wird.
///
/// ```
/// // `derive` implementiert Clone for Reading<T>wenn T Klon ist.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Wie kann ich `Clone` implementieren?
///
/// [`Copy`]-Typen sollten eine einfache Implementierung von `Clone` haben.Formeller:
/// Wenn `T: Copy`, `x: T` und `y: &T`, entspricht `let x = y.clone();` `let x = *y;`.
/// Manuelle Implementierungen sollten darauf achten, diese Invariante aufrechtzuerhalten.Unsicherer Code darf jedoch nicht darauf angewiesen sein, um die Speichersicherheit zu gewährleisten.
///
/// Ein Beispiel ist eine generische Struktur, die einen Funktionszeiger enthält.In diesem Fall kann die Implementierung von `Clone` nicht abgeleitet werden, sondern kann wie folgt implementiert werden:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Zusätzliche Implementierer
///
/// Neben dem [implementors listed below][impls] implementieren die folgenden Typen auch `Clone`:
///
/// * Funktionselementtypen (dh die für jede Funktion definierten unterschiedlichen Typen)
/// * Funktionszeigertypen (z. `fn() -> i32`)
/// * Array-Typen für alle Größen, wenn der Elementtyp auch `Clone` implementiert (z. B. `[i32; 123456]`)
/// * Tupeltypen, wenn jede Komponente auch `Clone` implementiert (z. B. `()`, `(i32, bool)`)
/// * Abschlussarten, wenn sie keinen Wert aus der Umgebung erfassen oder wenn alle erfassten Werte `Clone` selbst implementieren.
///   Beachten Sie, dass Variablen, die von einer gemeinsam genutzten Referenz erfasst werden, immer `Clone` implementieren (auch wenn der Referent dies nicht tut), während Variablen, die von einer veränderlichen Referenz erfasst werden, niemals `Clone` implementieren.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Gibt eine Kopie des Werts zurück.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementiert Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Führt eine Kopierzuweisung von `source` aus.
    ///
    /// `a.clone_from(&b)` Entspricht der Funktionalität von `a = b.clone()`, kann jedoch überschrieben werden, um die Ressourcen von `a` wiederzuverwenden und unnötige Zuordnungen zu vermeiden.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Leiten Sie ein Makro ab, das ein Impl des trait `Clone` generiert.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): Diese Strukturen werden ausschließlich von#[derive] verwendet, um zu behaupten, dass jede Komponente eines Typs Clone oder Copy implementiert.
//
//
// Diese Strukturen sollten niemals im Benutzercode erscheinen.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementierungen von `Clone` für primitive Typen.
///
/// Implementierungen, die in Rust nicht beschrieben werden können, sind in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection` implementiert.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gemeinsame Referenzen können geklont werden, veränderbare Referenzen jedoch nicht *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gemeinsame Referenzen können geklont werden, veränderbare Referenzen jedoch nicht *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}