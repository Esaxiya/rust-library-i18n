#![stable(feature = "core_hint", since = "1.27.0")]

//! Hinweise für den Compiler, die sich darauf auswirken, wie Code ausgegeben oder optimiert werden soll.
//! Hinweise können Kompilierungszeit oder Laufzeit sein.

use crate::intrinsics;

/// Informiert den Compiler darüber, dass dieser Punkt im Code nicht erreichbar ist, und ermöglicht weitere Optimierungen.
///
/// # Safety
///
/// Das Erreichen dieser Funktion ist völlig *undefiniertes Verhalten*(UB).Insbesondere geht der Compiler davon aus, dass niemals alle UB auftreten dürfen, und eliminiert daher alle Zweige, die zu einem Aufruf von `unreachable_unchecked()` führen.
///
/// Wie bei allen Instanzen von UB wendet der Compiler, wenn sich diese Annahme als falsch herausstellt, dh der `unreachable_unchecked()`-Aufruf tatsächlich unter allen möglichen Kontrollabläufen erreichbar ist, die falsche Optimierungsstrategie an und kann manchmal sogar scheinbar nicht zusammenhängenden Code beschädigen, was zu Schwierigkeiten führt. Probleme zu debuggen.
///
///
/// Verwenden Sie diese Funktion nur, wenn Sie nachweisen können, dass der Code sie niemals aufruft.
/// Andernfalls sollten Sie das [`unreachable!`]-Makro verwenden, das keine Optimierungen zulässt, bei Ausführung jedoch panic ausführt.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` ist immer positiv (nicht Null), daher gibt `checked_div` niemals `None` zurück.
/////
///     // Daher ist das else branch nicht erreichbar.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SICHERHEIT: Der Sicherheitsvertrag für `intrinsics::unreachable` muss
    // vom Anrufer bestätigt werden.
    unsafe { intrinsics::unreachable() }
}

/// Gibt eine Maschinenanweisung aus, um dem Prozessor zu signalisieren, dass er in einer Spin-Schleife mit Besetztwarte ausgeführt wird ("Spin Lock").
///
/// Beim Empfang des Spin-Loop-Signals kann der Prozessor sein Verhalten optimieren, indem er beispielsweise Strom spart oder hyper-Threads wechselt.
///
/// Diese Funktion unterscheidet sich von [`thread::yield_now`], das direkt dem Scheduler des Systems übergeben wird, während `spin_loop` nicht mit dem Betriebssystem interagiert.
///
/// Ein häufiger Anwendungsfall für `spin_loop` ist die Implementierung eines begrenzten optimistischen Spinnens in einer CAS-Schleife in Synchronisationsprimitiven.
/// Um Probleme wie die Prioritätsinversion zu vermeiden, wird dringend empfohlen, die Spin-Schleife nach einer begrenzten Anzahl von Iterationen zu beenden und einen geeigneten Blockierungs-Systemaufruf durchzuführen.
///
///
/// **Hinweis**: Auf Plattformen, die das Empfangen von Spin-Loop-Hinweisen nicht unterstützen, führt diese Funktion überhaupt nichts aus.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Ein gemeinsamer Atomwert, den Threads zur Koordinierung verwenden
/// let live = Arc::new(AtomicBool::new(false));
///
/// // In einem Hintergrund-Thread werden wir schließlich den Wert festlegen
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Arbeiten Sie und machen Sie den Wert dann lebendig
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Zurück in unserem aktuellen Thread warten wir, bis der Wert festgelegt ist
/// while !live.load(Ordering::Acquire) {
///     // Die Spin-Schleife ist ein Hinweis auf die CPU, auf die wir warten, aber wahrscheinlich nicht sehr lange
/////
///     hint::spin_loop();
/// }
///
/// // Der Wert ist jetzt eingestellt
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SICHERHEIT: Das `cfg`-Attribut stellt sicher, dass dies nur auf x86-Zielen ausgeführt wird.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SICHERHEIT: Das `cfg`-Attribut stellt sicher, dass dies nur auf x86_64-Zielen ausgeführt wird.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SICHERHEIT: Das `cfg`-Attribut stellt sicher, dass dies nur auf aarch64-Zielen ausgeführt wird.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SICHERHEIT: Der `cfg` attr stellt sicher, dass wir dies nur auf Armzielen ausführen
            // mit Unterstützung für die v6-Funktion.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Eine Identitätsfunktion, die dem Compiler *__ anweist, __* maximal pessimistisch zu sein, was `black_box` tun könnte.
///
/// Im Gegensatz zu [`std::convert::identity`] sollte ein Rust-Compiler davon ausgehen, dass `black_box` `dummy` auf jede mögliche gültige Weise verwenden kann, die Rust-Code zulässt, ohne undefiniertes Verhalten in den aufrufenden Code einzuführen.
///
/// Diese Eigenschaft macht `black_box` zum Schreiben von Code nützlich, bei dem bestimmte Optimierungen nicht erwünscht sind, z. B. Benchmarks.
///
/// Beachten Sie jedoch, dass `black_box` nur auf "best-effort"-Basis bereitgestellt wird (und nur bereitgestellt werden kann).Das Ausmaß, in dem Optimierungen blockiert werden können, hängt von der verwendeten Plattform und dem verwendeten Code-Gen-Backend ab.
/// Programme können sich in keiner Weise auf `black_box` verlassen, um *Korrektheit* zu gewährleisten.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Wir müssen das Argument in irgendeiner Weise "use"-fähig machen, und LLVM kann es nicht überprüfen, und bei Zielen, die es unterstützen, können wir normalerweise die Inline-Assembly nutzen, um dies zu tun.
    // LLVMs Interpretation der Inline-Montage lautet, dass es sich um eine Black Box handelt.
    // Dies ist nicht die beste Implementierung, da sie wahrscheinlich mehr deoptimiert als wir wollen, aber sie ist bisher gut genug.
    //
    //

    #[cfg(not(miri))] // Dies ist nur ein Hinweis, daher ist es in Ordnung, in Miri zu überspringen.
    // SICHERHEIT: Die Inline-Baugruppe ist ein No-Op.
    unsafe {
        // FIXME: `asm!` kann nicht verwendet werden, da MIPS und andere Architekturen nicht unterstützt werden.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}