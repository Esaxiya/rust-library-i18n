//! Zeichenkonvertierungen.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Konvertiert einen `u32` in einen `char`.
///
/// Beachten Sie, dass alle [`char`] gültige [`u32`] sind und mit eins in eins umgewandelt werden können
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Das Gegenteil ist jedoch nicht der Fall: Nicht alle gültigen [`u32`] sind gültige [`char`].
/// `from_u32()` gibt `None` zurück, wenn die Eingabe kein gültiger Wert für einen [`char`] ist.
///
/// Eine unsichere Version dieser Funktion, bei der diese Überprüfungen ignoriert werden, finden Sie unter [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Rückgabe von `None`, wenn die Eingabe kein gültiges [`char`] ist:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Konvertiert einen `u32` in einen `char`, wobei die Gültigkeit ignoriert wird.
///
/// Beachten Sie, dass alle [`char`] gültige [`u32`] sind und mit eins in eins umgewandelt werden können
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Das Gegenteil ist jedoch nicht der Fall: Nicht alle gültigen [`u32`] sind gültige [`char`].
/// `from_u32_unchecked()` wird dies ignorieren und blind auf [`char`] übertragen, wodurch möglicherweise eine ungültige erstellt wird.
///
///
/// # Safety
///
/// Diese Funktion ist unsicher, da sie möglicherweise ungültige `char`-Werte erstellt.
///
/// Eine sichere Version dieser Funktion finden Sie in der [`from_u32`]-Funktion.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SICHERHEIT: Der Anrufer muss garantieren, dass `i` ein gültiger Zeichenwert ist.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Konvertiert einen [`char`] in einen [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Konvertiert einen [`char`] in einen [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Das Zeichen wird auf den Wert des Codepunkts umgewandelt und dann auf 64 Bit auf Null erweitert.
        // Siehe [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Konvertiert einen [`char`] in einen [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Das Zeichen wird auf den Wert des Codepunkts umgewandelt und dann auf 128 Bit auf Null erweitert.
        // Siehe [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Ordnet ein Byte in 0x00 ..=0xFF einem `char` zu, dessen Codepunkt den gleichen Wert hat, in U + 0000 ..=U + 00FF.
///
/// Unicode ist so konzipiert, dass Bytes effektiv mit der von IANA als ISO-8859-1 bezeichneten Zeichenkodierung dekodiert werden.
/// Diese Codierung ist mit ASCII kompatibel.
///
/// Beachten Sie, dass sich dies von ISO/IEC 8859-1 aka unterscheidet
/// ISO 8859-1 (mit einem Bindestrich weniger), bei dem einige "blanks"-Bytewerte verbleiben, die keinem Zeichen zugewiesen sind.
/// ISO-8859-1 (die IANA) weist sie den Steuercodes C0 und C1 zu.
///
/// Beachten Sie, dass dies *auch* anders ist als Windows-1252 aka
/// Codepage 1252, eine Obermenge ISO/IEC 8859-1, die Interpunktion und verschiedenen lateinischen Zeichen einige (nicht alle!) Leerzeichen zuweist.
///
/// Um die Sache noch weiter zu verwirren, sind [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` und `windows-1252` Aliase für eine Obermenge von Windows-1252, die die verbleibenden Lücken mit den entsprechenden C0-und C1-Steuercodes füllt.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Konvertiert einen [`u8`] in einen [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Ein Fehler, der beim Parsen eines Zeichens zurückgegeben werden kann.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SICHERHEIT: Es wurde überprüft, ob es sich um einen legalen Unicode-Wert handelt
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Der Fehlertyp wird zurückgegeben, wenn eine Konvertierung von u32 nach char fehlschlägt.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Konvertiert eine Ziffer im angegebenen Radix in eine `char`.
///
/// Ein 'radix' wird hier manchmal auch als 'base' bezeichnet.
/// Ein Radix von zwei gibt eine Binärzahl an, ein Radix von zehn dezimal und ein Radix von sechzehn hexadezimal, um einige gemeinsame Werte zu erhalten.
///
/// Beliebige Radices werden unterstützt.
///
/// `from_digit()` gibt `None` zurück, wenn die Eingabe keine Ziffer im angegebenen Radix ist.
///
/// # Panics
///
/// Panics bei einem Radix größer als 36.
///
/// # Examples
///
/// Grundlegende Verwendung:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Dezimal 11 ist eine einzelne Ziffer in Basis 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Rückgabe von `None`, wenn die Eingabe keine Ziffer ist:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Übergeben eines großen Radix, wodurch ein panic verursacht wird:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}