//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Der höchste gültige Codepunkt, den ein `char` haben kann.
    ///
    /// Ein `char` ist ein [Unicode Scalar Value], was bedeutet, dass es ein [Code Point] ist, aber nur solche innerhalb eines bestimmten Bereichs.
    /// `MAX` ist der höchste gültige Codepunkt, der ein gültiger [Unicode Scalar Value] ist.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () wird in Unicode verwendet, um einen Decodierungsfehler darzustellen.
    ///
    /// Dies kann beispielsweise auftreten, wenn [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) schlecht geformte UTF-8-Bytes zugewiesen werden.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Die Version von [Unicode](http://www.unicode.org/), auf der die Unicode-Teile der `char`-und `str`-Methoden basieren.
    ///
    /// Neue Versionen von Unicode werden regelmäßig veröffentlicht und anschließend werden alle Methoden in der Standardbibliothek abhängig von Unicode aktualisiert.
    /// Daher ändert sich das Verhalten einiger `char`-und `str`-Methoden und der Wert dieser Konstante im Laufe der Zeit.
    /// Dies wird *nicht* als bahnbrechende Änderung angesehen.
    ///
    /// Das Versionsnummerierungsschema wird in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) erläutert.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Erstellt einen Iterator über die UTF-16-codierten Codepunkte in `iter` und gibt ungepaarte Ersatzzeichen als "Err" zurück.
    ///
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Ein verlustbehafteter Decoder kann erhalten werden, indem `Err`-Ergebnisse durch das Ersetzungszeichen ersetzt werden:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konvertiert einen `u32` in einen `char`.
    ///
    /// Beachten Sie, dass alle Zeichen gültige [`u32`] sind und mit eins in eins umgewandelt werden können
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Das Gegenteil ist jedoch nicht der Fall: Nicht alle gültigen [`u32`] sind gültige`char`s.
    /// `from_u32()` gibt `None` zurück, wenn die Eingabe kein gültiger Wert für einen `char` ist.
    ///
    /// Eine unsichere Version dieser Funktion, bei der diese Überprüfungen ignoriert werden, finden Sie unter [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Rückgabe von `None`, wenn die Eingabe kein gültiges `char` ist:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konvertiert einen `u32` in einen `char`, wobei die Gültigkeit ignoriert wird.
    ///
    /// Beachten Sie, dass alle Zeichen gültige [`u32`] sind und mit eins in eins umgewandelt werden können
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Das Gegenteil ist jedoch nicht der Fall: Nicht alle gültigen [`u32`] sind gültige`char`s.
    /// `from_u32_unchecked()` wird dies ignorieren und blind auf `char` übertragen, wodurch möglicherweise eine ungültige erstellt wird.
    ///
    ///
    /// # Safety
    ///
    /// Diese Funktion ist unsicher, da sie möglicherweise ungültige `char`-Werte erstellt.
    ///
    /// Eine sichere Version dieser Funktion finden Sie in der [`from_u32`]-Funktion.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SICHERHEIT: Der Sicherheitsvertrag muss vom Anrufer eingehalten werden.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konvertiert eine Ziffer im angegebenen Radix in eine `char`.
    ///
    /// Ein 'radix' wird hier manchmal auch als 'base' bezeichnet.
    /// Ein Radix von zwei gibt eine Binärzahl an, ein Radix von zehn dezimal und ein Radix von sechzehn hexadezimal, um einige gemeinsame Werte zu erhalten.
    ///
    /// Beliebige Radices werden unterstützt.
    ///
    /// `from_digit()` gibt `None` zurück, wenn die Eingabe keine Ziffer im angegebenen Radix ist.
    ///
    /// # Panics
    ///
    /// Panics bei einem Radix größer als 36.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Dezimal 11 ist eine einzelne Ziffer in Basis 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Rückgabe von `None`, wenn die Eingabe keine Ziffer ist:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Übergeben eines großen Radix, wodurch ein panic verursacht wird:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Überprüft, ob ein `char` eine Ziffer im angegebenen Radix ist.
    ///
    /// Ein 'radix' wird hier manchmal auch als 'base' bezeichnet.
    /// Ein Radix von zwei gibt eine Binärzahl an, ein Radix von zehn dezimal und ein Radix von sechzehn hexadezimal, um einige gemeinsame Werte zu erhalten.
    ///
    /// Beliebige Radices werden unterstützt.
    ///
    /// Im Vergleich zu [`is_numeric()`] erkennt diese Funktion nur die Zeichen `0-9`, `a-z` und `A-Z`.
    ///
    /// 'Digit' ist definiert als nur die folgenden Zeichen:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Ein umfassenderes Verständnis von 'digit' finden Sie unter [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics bei einem Radix größer als 36.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Übergeben eines großen Radix, wodurch ein panic verursacht wird:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Konvertiert einen `char` in eine Ziffer im angegebenen Radix.
    ///
    /// Ein 'radix' wird hier manchmal auch als 'base' bezeichnet.
    /// Ein Radix von zwei gibt eine Binärzahl an, ein Radix von zehn dezimal und ein Radix von sechzehn hexadezimal, um einige gemeinsame Werte zu erhalten.
    ///
    /// Beliebige Radices werden unterstützt.
    ///
    /// 'Digit' ist definiert als nur die folgenden Zeichen:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Gibt `None` zurück, wenn sich `char` nicht auf eine Ziffer im angegebenen Radix bezieht.
    ///
    /// # Panics
    ///
    /// Panics bei einem Radix größer als 36.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Das Übergeben einer nichtstelligen Zahl führt zu einem Fehler:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Übergeben eines großen Radix, wodurch ein panic verursacht wird:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // Der Code wird hier aufgeteilt, um die Ausführungsgeschwindigkeit in Fällen zu verbessern, in denen der `radix` konstant und 10 oder kleiner ist
        //
        let val = if likely(radix <= 10) {
            // Wenn keine Ziffer vorhanden ist, wird eine Zahl größer als radix erstellt.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Gibt einen Iterator zurück, der das hexadezimale Unicode-Escapezeichen eines Zeichens als `char`s ergibt.
    ///
    /// Dadurch werden Zeichen mit der Rust-Syntax der Form `\u{NNNNNN}` ausgeblendet, wobei `NNNNNN` eine hexadezimale Darstellung ist.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // oring 1 stellt sicher, dass für c==0 der Code berechnet, dass eine Ziffer gedruckt werden soll, und (was dasselbe ist) den (31, 32) Unterlauf vermeidet
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // der Index der höchstwertigen hexadezimalen Ziffer
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Eine erweiterte Version von `escape_debug`, mit der optional Extended Grapheme-Codepunkte ausgeblendet werden können.
    /// Auf diese Weise können wir Zeichen wie nicht räumliche Markierungen besser formatieren, wenn sie am Anfang einer Zeichenfolge stehen.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Gibt einen Iterator zurück, der den wörtlichen Escape-Code eines Zeichens als `char`s ergibt.
    ///
    /// Dadurch werden die Zeichen ausgeblendet, die den `Debug`-Implementierungen von `str` oder `char` ähneln.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Gibt einen Iterator zurück, der den wörtlichen Escape-Code eines Zeichens als `char`s ergibt.
    ///
    /// Die Standardeinstellung wird mit der Tendenz gewählt, Literale zu erstellen, die in einer Vielzahl von Sprachen legal sind, einschließlich C++ 11 und ähnlichen Sprachen der C-Familie.
    /// Die genauen Regeln sind:
    ///
    /// * Tab wird als `\t` maskiert.
    /// * Wagenrücklauf wird als `\r` maskiert.
    /// * Der Zeilenvorschub wird als `\n` maskiert.
    /// * Ein einfaches Anführungszeichen wird als `\'` maskiert.
    /// * Doppelte Anführungszeichen werden als `\"` maskiert.
    /// * Backslash wird als `\\` maskiert.
    /// * Zeichen im Bereich 'printable ASCII' `0x20` .. `0x7e` einschließlich werden nicht maskiert.
    /// * Alle anderen Zeichen erhalten hexadezimale Unicode-Escapezeichen.siehe [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Gibt die Anzahl der Bytes zurück, die `char` benötigen würde, wenn es in UTF-8 codiert wäre.
    ///
    /// Diese Anzahl von Bytes liegt immer zwischen 1 und 4 einschließlich.
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Der Typ `&str` garantiert, dass sein Inhalt UTF-8 ist. Daher können wir die Länge vergleichen, die erforderlich wäre, wenn jeder Codepunkt als `char` dargestellt würde, im Vergleich zum `&str` selbst:
    ///
    ///
    /// ```
    /// // als Zeichen
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // beide können als drei Bytes dargestellt werden
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // Als &str sind diese beiden in UTF-8 codiert
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // wir können sehen, dass sie insgesamt sechs Bytes benötigen ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... genau wie beim &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Gibt die Anzahl der 16-Bit-Codeeinheiten zurück, die dieser `char` benötigen würde, wenn er in UTF-16 codiert wäre.
    ///
    ///
    /// Weitere Erläuterungen zu diesem Konzept finden Sie in der Dokumentation zu [`len_utf8()`].
    /// Diese Funktion ist ein Spiegel, jedoch für UTF-16 anstelle von UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Codiert dieses Zeichen als UTF-8 in den bereitgestellten Bytepuffer und gibt dann die Unterscheibe des Puffers zurück, der das codierte Zeichen enthält.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn der Puffer nicht groß genug ist.
    /// Ein Puffer mit der Länge vier ist groß genug, um jedes `char` zu codieren.
    ///
    /// # Examples
    ///
    /// In beiden Beispielen benötigt 'ß' zwei Bytes zum Codieren.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Ein zu kleiner Puffer:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SICHERHEIT: `char` ist kein Ersatz, daher ist dies UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Codiert dieses Zeichen als UTF-16 in den bereitgestellten `u16`-Puffer und gibt dann die Unterscheibe des Puffers zurück, der das codierte Zeichen enthält.
    ///
    ///
    /// # Panics
    ///
    /// Panics, wenn der Puffer nicht groß genug ist.
    /// Ein Puffer der Länge 2 ist groß genug, um `char` zu codieren.
    ///
    /// # Examples
    ///
    /// In diesen beiden Beispielen benötigt '𝕊' zwei "u16" zum Codieren.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Ein zu kleiner Puffer:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Gibt `true` zurück, wenn dieser `char` die `Alphabetic`-Eigenschaft hat.
    ///
    /// `Alphabetic` wird in Kapitel 4 (Zeicheneigenschaften) des [Unicode Standard] beschrieben und im [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] angegeben.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // Liebe ist vieles, aber nicht alphabetisch
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Gibt `true` zurück, wenn dieser `char` die `Lowercase`-Eigenschaft hat.
    ///
    /// `Lowercase` wird in Kapitel 4 (Zeicheneigenschaften) des [Unicode Standard] beschrieben und im [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] angegeben.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Die verschiedenen chinesischen Skripte und Interpunktionen haben keine Groß-und Kleinschreibung und so:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Gibt `true` zurück, wenn dieser `char` die `Uppercase`-Eigenschaft hat.
    ///
    /// `Uppercase` wird in Kapitel 4 (Zeicheneigenschaften) des [Unicode Standard] beschrieben und im [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] angegeben.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Die verschiedenen chinesischen Skripte und Interpunktionen haben keine Groß-und Kleinschreibung und so:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Gibt `true` zurück, wenn dieser `char` die `White_Space`-Eigenschaft hat.
    ///
    /// `White_Space` wird im [Unicode Character Database][ucd] [`PropList.txt`] angegeben.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ein nicht brechender Raum
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Gibt `true` zurück, wenn dieser `char` entweder [`is_alphabetic()`] oder [`is_numeric()`] erfüllt.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Gibt `true` zurück, wenn dieser `char` die allgemeine Kategorie für Steuercodes hat.
    ///
    /// Steuercodes (Codepunkte mit der allgemeinen Kategorie `Cc`) werden in Kapitel 4 (Zeicheneigenschaften) des [Unicode Standard] beschrieben und im [Unicode Character Database][ucd] [`UnicodeData.txt`] angegeben.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Gibt `true` zurück, wenn dieser `char` die `Grapheme_Extend`-Eigenschaft hat.
    ///
    /// `Grapheme_Extend` wird in [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] beschrieben und in [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] angegeben.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Gibt `true` zurück, wenn dieser `char` eine der allgemeinen Kategorien für Zahlen hat.
    ///
    /// Die allgemeinen Kategorien für Zahlen (`Nd` für Dezimalstellen, `Nl` für buchstabenähnliche numerische Zeichen und `No` für andere numerische Zeichen) sind im [Unicode Character Database][ucd] [`UnicodeData.txt`] angegeben.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Grundlegende Verwendung:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Gibt einen Iterator zurück, der die Zuordnung dieses `char` in Kleinbuchstaben als einen oder mehrere ergibt
    /// `char`s.
    ///
    /// Wenn dieser `char` keine Zuordnung in Kleinbuchstaben hat, liefert der Iterator denselben `char`.
    ///
    /// Wenn dieser `char` eine Eins-zu-Eins-Zuordnung in Kleinbuchstaben hat, die vom [Unicode Character Database][ucd] [`UnicodeData.txt`] angegeben wird, gibt der Iterator diesen `char` aus.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Wenn dieser `char` spezielle Überlegungen erfordert (z. B. mehrere Zeichen), liefert der Iterator die von [`SpecialCasing.txt`] angegebenen Zeichen.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Diese Operation führt eine bedingungslose Zuordnung ohne Anpassung durch.Das heißt, die Konvertierung ist unabhängig von Kontext und Sprache.
    ///
    /// In [Unicode Standard] wird in Kapitel 4 (Zeicheneigenschaften) die Fallzuordnung im Allgemeinen und in Kapitel 3 in (Conformance) der Standardalgorithmus für die Fallkonvertierung erläutert.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Manchmal ist das Ergebnis mehr als ein Zeichen:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Zeichen, die nicht sowohl Groß-als auch Kleinbuchstaben enthalten, werden in sich selbst konvertiert.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Gibt einen Iterator zurück, der die Zuordnung dieses `char` in Großbuchstaben als einen oder mehrere ergibt
    /// `char`s.
    ///
    /// Wenn dieses `char` keine Zuordnung in Großbuchstaben hat, liefert der Iterator dasselbe `char`.
    ///
    /// Wenn dieser `char` eine Eins-zu-Eins-Zuordnung in Großbuchstaben hat, die vom [Unicode Character Database][ucd] [`UnicodeData.txt`] angegeben wird, gibt der Iterator diesen `char` aus.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Wenn dieser `char` spezielle Überlegungen erfordert (z. B. mehrere Zeichen), liefert der Iterator die von [`SpecialCasing.txt`] angegebenen Zeichen.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Diese Operation führt eine bedingungslose Zuordnung ohne Anpassung durch.Das heißt, die Konvertierung ist unabhängig von Kontext und Sprache.
    ///
    /// In [Unicode Standard] wird in Kapitel 4 (Zeicheneigenschaften) die Fallzuordnung im Allgemeinen und in Kapitel 3 in (Conformance) der Standardalgorithmus für die Fallkonvertierung erläutert.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt verwenden:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Beide sind gleichbedeutend mit:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Verwenden von `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Manchmal ist das Ergebnis mehr als ein Zeichen:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Zeichen, die nicht sowohl Groß-als auch Kleinbuchstaben enthalten, werden in sich selbst konvertiert.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Hinweis zum Gebietsschema
    ///
    /// Auf Türkisch hat das Äquivalent von 'i' auf Latein fünf statt zwei Formen:
    ///
    /// * 'Dotless': Ich/ı, manchmal geschrieben ï
    /// * 'Dotted': İ/i
    ///
    /// Beachten Sie, dass der in Kleinbuchstaben gepunktete 'i' mit dem lateinischen identisch ist.Deshalb:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Der Wert von `upper_i` hängt hier von der Sprache des Textes ab: Wenn wir in `en-US` sind, sollte es `"I"` sein, aber wenn wir in `tr_TR` sind, sollte es `"İ"` sein.
    /// `to_uppercase()` berücksichtigt dies nicht und so:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// gilt über Sprachen.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Überprüft, ob der Wert innerhalb des ASCII-Bereichs liegt.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Erstellt eine Kopie des Werts in seiner ASCII-Großbuchstabenäquivalent.
    ///
    /// ASCII-Buchstaben 'a' bis 'z' werden 'A' bis 'Z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`make_ascii_uppercase()`], um den Wert direkt in Großbuchstaben zu setzen.
    ///
    /// Verwenden Sie [`to_uppercase()`], um ASCII-Zeichen zusätzlich zu Nicht-ASCII-Zeichen in Großbuchstaben zu schreiben.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Erstellt eine Kopie des Werts in ASCII-Kleinbuchstaben.
    ///
    /// ASCII-Buchstaben 'A' bis 'Z' werden 'a' bis 'z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`make_ascii_lowercase()`], um den Wert an Ort und Stelle in Kleinbuchstaben zu schreiben.
    ///
    /// Verwenden Sie [`to_lowercase()`], um ASCII-Zeichen zusätzlich zu Nicht-ASCII-Zeichen in Kleinbuchstaben zu schreiben.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Überprüft, ob bei zwei Werten die Übereinstimmung zwischen ASCII und Groß-und Kleinschreibung nicht berücksichtigt wird.
    ///
    /// Entspricht `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konvertiert diesen Typ in das vorhandene ASCII-Großbuchstabenäquivalent.
    ///
    /// ASCII-Buchstaben 'a' bis 'z' werden 'A' bis 'Z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`to_ascii_uppercase()`], um einen neuen Wert in Großbuchstaben zurückzugeben, ohne den vorhandenen zu ändern.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konvertiert diesen Typ in sein vorhandenes ASCII-Kleinbuchstabenäquivalent.
    ///
    /// ASCII-Buchstaben 'A' bis 'Z' werden 'a' bis 'z' zugeordnet, Nicht-ASCII-Buchstaben bleiben jedoch unverändert.
    ///
    /// Verwenden Sie [`to_ascii_lowercase()`], um einen neuen Wert in Kleinbuchstaben zurückzugeben, ohne den vorhandenen zu ändern.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Überprüft, ob der Wert ein ASCII-Alphabet ist:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' oder
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Überprüft, ob der Wert ein ASCII-Großbuchstabe ist:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Überprüft, ob der Wert ein ASCII-Kleinbuchstabe ist:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Überprüft, ob der Wert ein alphanumerisches ASCII-Zeichen ist:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' oder
    /// - U + 0061 'a' ..=U + 007A 'z' oder
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Überprüft, ob der Wert eine ASCII-Dezimalstelle ist:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Überprüft, ob der Wert eine hexadezimale ASCII-Ziffer ist:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' oder
    /// - U + 0041 'A' ..=U + 0046 'F' oder
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Überprüft, ob der Wert ein ASCII-Interpunktionszeichen ist:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` oder
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` oder
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, oder
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Überprüft, ob der Wert ein ASCII-Grafikzeichen ist:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Überprüft, ob der Wert ein ASCII-Leerzeichen ist:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED oder U + 000D CARRIAGE RETURN.
    ///
    /// Rust verwendet den [definition of ASCII whitespace][infra-aw] des WhatWG Infra Standard.Es gibt mehrere andere Definitionen, die weit verbreitet sind.
    /// Zum Beispiel enthält [the POSIX locale][pct] U + 000B VERTICAL TAB sowie alle oben genannten Zeichen, aber-aus derselben Spezifikation-[die Standardregel für "field splitting" in der Bourne shell][bfs] berücksichtigt *nur* SPACE, HORIZONTAL TAB und LINE FEED als Leerzeichen.
    ///
    ///
    /// Wenn Sie ein Programm schreiben, das ein vorhandenes Dateiformat verarbeitet, überprüfen Sie die Definition des Leerzeichens in diesem Format, bevor Sie diese Funktion verwenden.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Überprüft, ob der Wert ein ASCII-Steuerzeichen ist:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR oder U + 007F DELETE.
    /// Beachten Sie, dass die meisten ASCII-Leerzeichen Steuerzeichen sind, SPACE jedoch nicht.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Codiert einen rohen u32-Wert als UTF-8 in den bereitgestellten Bytepuffer und gibt dann die Unterscheibe des Puffers zurück, der das codierte Zeichen enthält.
///
///
/// Im Gegensatz zu `char::encode_utf8` verarbeitet diese Methode auch Codepunkte im Ersatzbereich.
/// (Das Erstellen eines `char` im Ersatzbereich ist UB.) Das Ergebnis ist gültiges [generalized UTF-8], aber kein gültiges UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, wenn der Puffer nicht groß genug ist.
/// Ein Puffer mit der Länge vier ist groß genug, um jedes `char` zu codieren.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Codiert einen rohen u32-Wert als UTF-16 in den bereitgestellten `u16`-Puffer und gibt dann die Unterscheibe des Puffers zurück, der das codierte Zeichen enthält.
///
///
/// Im Gegensatz zu `char::encode_utf16` verarbeitet diese Methode auch Codepunkte im Ersatzbereich.
/// (Das Erstellen eines `char` im Ersatzbereich ist UB.)
///
/// # Panics
///
/// Panics, wenn der Puffer nicht groß genug ist.
/// Ein Puffer der Länge 2 ist groß genug, um `char` zu codieren.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SICHERHEIT: Jeder Arm prüft, ob genügend Bits zum Schreiben vorhanden sind
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Der BMP fällt durch
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ergänzungsflugzeuge brechen in Ersatzflugzeuge ein.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}