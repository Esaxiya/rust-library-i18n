#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Dienstprogramme für (FFI)-Bindungen der Fremdfunktionsschnittstelle.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Entspricht dem `void`-Typ von C, wenn er als [pointer] verwendet wird.
///
/// Im Wesentlichen entspricht `*const c_void` dem `const void*` von C und `*mut c_void` dem `void*` von C.
/// Dies ist jedoch *nicht* derselbe wie der `void`-Rückgabetyp von C, der der `()`-Typ von Rust ist.
///
/// Um Zeiger auf undurchsichtige Typen in FFI zu modellieren, wird empfohlen, bis zur Stabilisierung von `extern type` einen newtype-Wrapper um ein leeres Byte-Array zu verwenden.
///
/// Einzelheiten finden Sie im [Nomicon].
///
/// Man könnte `std::os::raw::c_void` verwenden, wenn man den alten Rust-Compiler bis 1.1.0 unterstützen möchte.
/// Nach Rust 1.30.0 wurde es durch diese Definition erneut exportiert.
/// Weitere Informationen finden Sie unter [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// Hinweis: Damit LLVM den Void-Zeigertyp erkennt und durch Erweiterungsfunktionen wie malloc() als i8 * im LLVM-Bitcode dargestellt werden muss.
// Die hier verwendete Aufzählung stellt dies sicher und verhindert den Missbrauch des "raw"-Typs, indem nur private Varianten vorhanden sind.
// Wir brauchen zwei Varianten, weil sich der Compiler ansonsten über das repr-Attribut beschwert und wir mindestens eine Variante benötigen, da sonst die Aufzählung unbewohnt wäre und zumindest die Dereferenzierung solcher Zeiger UB wäre.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Grundlegende Implementierung eines `va_list`.
// Der Name ist WIP und verwendet derzeit `VaListImpl`.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariante über `'f`, sodass jedes `VaListImpl<'f>`-Objekt an den Bereich der Funktion gebunden ist, in der es definiert ist
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI-Implementierung eines `va_list`.
/// Weitere Informationen finden Sie im [AArch64 Procedure Call Standard].
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI-Implementierung eines `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI-Implementierung eines `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Ein Wrapper für einen `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertieren Sie einen `VaListImpl` in einen `VaList`, der mit dem `va_list` von C binär kompatibel ist.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertieren Sie einen `VaListImpl` in einen `VaList`, der mit dem `va_list` von C binär kompatibel ist.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Der VaArgSafe trait muss in öffentlichen Schnittstellen verwendet werden. Der trait selbst darf jedoch nicht außerhalb dieses Moduls verwendet werden.
// Wenn Benutzer trait für einen neuen Typ implementieren können (wodurch die Eigenart va_arg für einen neuen Typ verwendet werden kann), kann dies zu undefiniertem Verhalten führen.
//
// FIXME(dlrobertson): Um das VaArgSafe trait in einer öffentlichen Schnittstelle zu verwenden, aber auch sicherzustellen, dass es nicht anderweitig verwendet werden kann, muss das trait in einem privaten Modul öffentlich sein.
// Sobald RFC 2145 implementiert wurde, versuchen Sie dies zu verbessern.
//
//
//
//
mod sealed_trait {
    /// Trait, mit dem die zulässigen Typen mit [super::VaListImpl::arg] verwendet werden können.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Weiter zum nächsten Argument.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `va_arg` einhalten.
        unsafe { va_arg(self) }
    }

    /// Kopiert den `va_list` an den aktuellen Speicherort.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SICHERHEIT: Der Anrufer muss den Sicherheitsvertrag für `va_end` einhalten.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SICHERHEIT: Wir schreiben auf das `MaybeUninit`, daher wird es initialisiert und `assume_init` ist legal
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: Dies sollte `va_end` aufrufen, aber es gibt keinen sauberen Weg dazu
        // Stellen Sie sicher, dass `drop` immer in seinen Aufrufer eingebunden wird, damit der `va_end` direkt von derselben Funktion wie der entsprechende `va_copy` aufgerufen wird.
        // `man va_end` gibt an, dass C dies erfordert und LLVM im Wesentlichen der C-Semantik folgt. Daher müssen wir sicherstellen, dass `va_end` immer von derselben Funktion wie `va_copy` aufgerufen wird.
        //
        // Für mehr Details, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Dies funktioniert vorerst, da `va_end` bei allen aktuellen LLVM-Zielen ein No-Op ist.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Zerstören Sie die Arglist `ap` nach der Initialisierung mit `va_start` oder `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Kopiert den aktuellen Speicherort der Arglist `src` in die Arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Lädt ein Argument vom Typ `T` aus dem `va_list` `ap` und erhöht das Argument, auf das `ap` zeigt.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}