# Der `rustc-std-workspace-core` crate

Dieses crate ist ein leeres und leeres crate, das einfach von `libcore` abhängt und seinen gesamten Inhalt erneut exportiert.
Das crate ist der Kern der Befähigung der Standardbibliothek, von crates von crates.io abhängig zu sein

Crates auf crates.io, von dem die Standardbibliothek abhängt, muss vom `rustc-std-workspace-core` crate von crates.io abhängen, das leer ist.

Wir verwenden `[patch]`, um es in diesem crate in diesem Repository zu überschreiben.
Infolgedessen zeichnet crates unter crates.io eine Abhängigkeit edge von `libcore`, der in diesem Repository definierten Version.
Das sollte alle Abhängigkeitskanten zeichnen, um sicherzustellen, dass Cargo crates erfolgreich erstellt!

Beachten Sie, dass crates unter crates.io von diesem crate mit dem Namen `core` abhängen muss, damit alles ordnungsgemäß funktioniert.Dazu können sie Folgendes verwenden:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Durch die Verwendung des `package`-Schlüssels wird das crate in `core` umbenannt, was bedeutet, dass es so aussieht

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Wenn Cargo den Compiler aufruft und die implizite `extern crate core`-Direktive erfüllt, die vom Compiler injiziert wurde.




