// rsbegin.o und rsend.o sind die sogenannten "compiler runtime startup objects".
// Sie enthalten Code, der zum korrekten Initialisieren der Compiler-Laufzeit erforderlich ist.
//
// Wenn eine ausführbare Datei oder ein Dylib-Image verknüpft ist, sind alle Benutzercodes und Bibliotheken "sandwiched" zwischen diesen beiden Objektdateien, sodass Code oder Daten von rsbegin.o in den jeweiligen Abschnitten des Images an erster Stelle stehen, während Code und Daten von rsend.o die letzten sind.
// Dieser Effekt kann verwendet werden, um Symbole am Anfang oder am Ende eines Abschnitts zu platzieren sowie erforderliche Kopf-oder Fußzeilen einzufügen.
//
// Beachten Sie, dass sich der eigentliche Moduleinstiegspunkt im Startobjekt der C-Laufzeit befindet (normalerweise als `crtX.o` bezeichnet), das dann Initialisierungsrückrufe anderer Laufzeitkomponenten aufruft (registriert über einen weiteren speziellen Image-Abschnitt).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Markiert den Anfang des Info-Abschnitts zum Abwickeln des Stapelrahmens
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Kratzraum für die interne Buchhaltung des Abwicklers.
    // Dies ist in $ GCC/unwind-dw2-fde.h als `struct object` definiert.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Entspannen Sie Info registration/deregistration-Routinen.
    // Siehe die Dokumente von libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // Registrieren Sie die Abwicklungsinformationen beim Start des Moduls
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // Beim Herunterfahren die Registrierung aufheben
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-spezifische init/uninit-Routine-Registrierung
    pub mod mingw_init {
        // Die Startobjekte von MinGW (crt0.o/dllcrt0.o) rufen beim Starten und Beenden globale Konstruktoren in den Abschnitten .ctors und .dtors auf.
        // Bei DLLs erfolgt dies, wenn die DLL geladen und entladen wird.
        //
        // Der Linker sortiert die Abschnitte, um sicherzustellen, dass sich unsere Rückrufe am Ende der Liste befinden.
        // Da Konstruktoren in umgekehrter Reihenfolge ausgeführt werden, wird sichergestellt, dass unsere Rückrufe die ersten und letzten sind, die ausgeführt werden.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C-Initialisierungsrückrufe
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C-Terminierungsrückrufe
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}