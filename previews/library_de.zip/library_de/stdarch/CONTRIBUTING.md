# Beitrag zu stdarch

Der `stdarch` crate ist mehr als bereit, Beiträge anzunehmen!Zuerst möchten Sie wahrscheinlich das Repository überprüfen und sicherstellen, dass die Tests für Sie erfolgreich sind:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Wobei `<your-target-arch>` das von `rustup` verwendete Zieltripel ist, z. B. `x86_x64-unknown-linux-gnu` (ohne vorhergehendes `nightly-` oder ähnliches).
Denken Sie auch daran, dass dieses Repository den nächtlichen Kanal von Rust benötigt!
Die obigen Tests erfordern in der Tat, dass nächtliches rust die Standardeinstellung auf Ihrem System ist, um festzulegen, dass `rustup default nightly` (und `rustup default stable` zum Zurücksetzen) verwendet werden.

Wenn einer der oben genannten Schritte nicht funktioniert, [please let us know][new]!

Als nächstes können Sie mit [find an issue][issues] helfen. Wir haben einige mit den Tags [`help wanted`][help] und [`impl-period`][impl] ausgewählt, die besonders hilfreich sein könnten. 
Möglicherweise interessieren Sie sich am meisten für [#40][vendor], indem Sie alle Herstellermerkmale auf x86 implementieren.Diese Ausgabe enthält einige gute Hinweise, wo Sie anfangen sollen!

Wenn Sie allgemeine Fragen haben, wenden Sie sich an [join us on gitter][gitter] und fragen Sie nach!Bei Fragen können Sie entweder@BurntSushi oder@alexcrichton anpingen.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Wie schreibe ich Beispiele für stdarch intrinsics

Es gibt einige Funktionen, die aktiviert sein müssen, damit das angegebene Intrinsic ordnungsgemäß funktioniert, und das Beispiel darf nur von `cargo test --doc` ausgeführt werden, wenn die Funktion von der CPU unterstützt wird.

Infolgedessen funktioniert das von `rustdoc` generierte Standard-`fn main` (in den meisten Fällen) nicht.
Verwenden Sie das Folgende als Leitfaden, um sicherzustellen, dass Ihr Beispiel wie erwartet funktioniert.

```rust
/// # // Wir benötigen cfg_target_feature, um sicherzustellen, dass nur das Beispiel vorhanden ist
/// # // Wird von `cargo test --doc` ausgeführt, wenn die CPU die Funktion unterstützt
/// # #![feature(cfg_target_feature)]
/// # // Wir brauchen target_feature, damit das Intrinsic funktioniert
/// # #![feature(target_feature)]
/// #
/// # // rustdoc verwendet standardmäßig `extern crate stdarch`, aber wir brauchen das
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Die eigentliche Hauptfunktion
/// # fn main() {
/// #     // Führen Sie dies nur aus, wenn `<target feature>` unterstützt wird
/// #     wenn cfg_feature_enabled! ("<target feature>"){
/// #         // Erstellen Sie eine `worker`-Funktion, die nur ausgeführt wird, wenn die Zielfunktion vorhanden ist
/// #         // wird unterstützt und stellen Sie sicher, dass `target_feature` für Ihren Mitarbeiter aktiviert ist
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         unsicher fn worker() {
/// // Schreiben Sie hier Ihr Beispiel.Feature-spezifische Eigenschaften werden hier funktionieren!Dreh durch!
///
/// #         }
///
/// #         unsicheres { worker(); }
/// #     }
/// # }
```

Wenn einige der oben genannten Syntax nicht bekannt sind, beschreibt der [Documentation as tests]-Abschnitt des [Rust Book] die `rustdoc`-Syntax recht gut.
Wenden Sie sich wie immer an [join us on gitter][gitter] und fragen Sie uns, ob Sie Probleme haben. Vielen Dank, dass Sie zur Verbesserung der Dokumentation von `stdarch` beigetragen haben!

# Alternative Testanweisungen

Es wird allgemein empfohlen, `ci/run.sh` zum Ausführen der Tests zu verwenden.
Dies funktioniert jedoch möglicherweise nicht für Sie, z. B. wenn Sie mit Windows arbeiten.

In diesem Fall können Sie zum Testen der Codegenerierung auf `cargo +nightly test` und `cargo +nightly test --release -p core_arch` zurückgreifen.
Beachten Sie, dass hierfür die nächtliche Toolchain installiert sein muss und `rustc` über Ihr Ziel-Triple und dessen CPU Bescheid wissen muss.
Insbesondere müssen Sie die Umgebungsvariable `TARGET` wie für `ci/run.sh` festlegen.
Außerdem müssen Sie `RUSTCFLAGS` einstellen (benötigen Sie `C`), um Zielfunktionen anzugeben, z `RUSTCFLAGS="-C -target-features=+avx2"`.
Sie können `-C -target-cpu=native` auch einstellen, wenn Sie "just" für Ihre aktuelle CPU entwickeln.

Seien Sie gewarnt, dass bei Verwendung dieser alternativen Anweisungen [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], z
Befehlsgenerierungstests können fehlschlagen, weil der Disassembler sie anders benannt hat, z
Es kann `vaesenc` anstelle von `aesenc`-Anweisungen generieren, obwohl sie sich gleich verhalten.
Außerdem führen diese Anweisungen weniger Tests aus als normalerweise. Seien Sie also nicht überrascht, dass bei einer eventuellen Pull-Anforderung einige Fehler bei Tests auftreten können, die hier nicht behandelt werden.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






