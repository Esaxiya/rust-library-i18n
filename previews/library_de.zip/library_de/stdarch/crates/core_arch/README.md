`core::arch` - Die Architektur-spezifischen Eigenschaften von Rust für die Kernbibliothek
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Das `core::arch`-Modul implementiert architekturabhängige Intrinsics (z. B. SIMD).

# Usage 

`core::arch` ist als Teil von `libcore` verfügbar und wird von `libstd` erneut exportiert.Verwenden Sie es lieber über `core::arch` oder `std::arch` als über dieses crate.
Instabile Funktionen sind im nächtlichen Rust häufig über den `feature(stdsimd)` verfügbar.

Die Verwendung von `core::arch` über dieses crate erfordert nächtliches Rust und kann (und wird) häufig unterbrochen.Die einzigen Fälle, in denen Sie in Betracht ziehen sollten, es über dieses crate zu verwenden, sind:

* Wenn Sie `core::arch` selbst neu kompilieren müssen, z. B. mit bestimmten aktivierten Zielfunktionen, die für `libcore`/`libstd` nicht aktiviert sind.
Note: Wenn Sie es für ein nicht standardmäßiges Ziel neu kompilieren müssen, ziehen Sie es vor, `xargo` zu verwenden und `libcore`/`libstd` entsprechend neu zu kompilieren, anstatt dieses crate zu verwenden.
  
* Verwenden einiger Funktionen, die möglicherweise auch hinter instabilen Rust-Funktionen nicht verfügbar sind.Wir versuchen diese auf ein Minimum zu beschränken.
Wenn Sie einige dieser Funktionen verwenden müssen, öffnen Sie bitte ein Problem, damit wir sie im nächtlichen Rust verfügbar machen können und Sie sie von dort aus verwenden können.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` wird hauptsächlich unter den Bedingungen der MIT-Lizenz und der Apache-Lizenz (Version 2.0) vertrieben, wobei Teile von verschiedenen BSD-ähnlichen Lizenzen abgedeckt werden.

Weitere Informationen finden Sie unter LICENSE-APACHE und LICENSE-MIT.

# Contribution

Sofern Sie nicht ausdrücklich etwas anderes angeben, wird jeder Beitrag, den Sie absichtlich zur Aufnahme in `core_arch` eingereicht haben, wie in der Apache-2.0-Lizenz definiert, wie oben beschrieben ohne zusätzliche Bedingungen doppelt lizenziert.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












