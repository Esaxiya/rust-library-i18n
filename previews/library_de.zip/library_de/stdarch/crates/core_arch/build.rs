use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Wird verwendet, um unseren `#[assert_instr]`-Annotationen mitzuteilen, dass alle Simd-Intrinsics zum Testen ihres Codegens verfügbar sind, da einige hinter einem zusätzlichen `-Ctarget-feature=+unimplemented-simd128` stehen, das derzeit in `#[target_feature]` kein Äquivalent hat.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}