# Der `rustc-std-workspace-std` crate

Siehe Dokumentation zum `rustc-std-workspace-core` crate.