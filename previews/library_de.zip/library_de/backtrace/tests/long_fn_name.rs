use backtrace::Backtrace;

// 50-stelliger Modulname
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-stelliger Strukturname
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Lange Funktionsnamen müssen auf (MAX_SYM_NAME, 1) Zeichen gekürzt werden.
// Führen Sie diesen Test nur für msvc aus, da gnu "<no info>" für alle Frames druckt.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 Wiederholungen des Strukturnamens, sodass der vollqualifizierte Funktionsname mindestens 10 *(50 + 50)* 2=2000 Zeichen lang ist.
    //
    // Es ist tatsächlich länger, da es auch `::`, `<>` und den Namen des aktuellen Moduls enthält
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}