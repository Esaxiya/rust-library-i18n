use backtrace::Backtrace;

// Dieser Test funktioniert nur auf Plattformen mit einer funktionierenden `symbol_address`-Funktion für Frames, die die Startadresse eines Symbols melden.
// Daher ist es nur auf wenigen Plattformen aktiviert.
//
const ENABLED: bool = cfg!(all(
    // Windows wurde nicht wirklich getestet und OSX unterstützt das Auffinden eines umschließenden Frames nicht. Deaktivieren Sie dies
    //
    target_os = "linux",
    // Wenn ARM gefunden wird, gibt die einschließende Funktion einfach die IP selbst zurück.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}