use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Lösen Sie eine Adresse in ein Symbol auf und übergeben Sie das Symbol an den angegebenen Abschluss.
///
/// Diese Funktion sucht die angegebene Adresse in Bereichen wie der lokalen Symboltabelle, der dynamischen Symboltabelle oder den DWARF-Debug-Informationen (abhängig von der aktivierten Implementierung), um Symbole zu finden, die ausgegeben werden sollen.
///
///
/// Das Schließen kann nicht aufgerufen werden, wenn die Auflösung nicht durchgeführt werden konnte, und es kann auch mehr als einmal bei Inline-Funktionen aufgerufen werden.
///
/// Die angegebenen Symbole stellen die Ausführung am angegebenen `addr` dar und geben file/line-Paare für diese Adresse zurück (falls verfügbar).
///
/// Beachten Sie, dass bei einem `Frame` empfohlen wird, anstelle dieser Funktion die `resolve_frame`-Funktion zu verwenden.
///
/// # Erforderliche Funktionen
///
/// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
///
/// # Panics
///
/// Diese Funktion ist bestrebt, niemals panic zu verwenden. Wenn der `cb` jedoch panics bereitstellt, erzwingen einige Plattformen ein doppeltes panic, um den Vorgang abzubrechen.
/// Einige Plattformen verwenden eine C-Bibliothek, die intern Rückrufe verwendet, die nicht abgewickelt werden können. Eine Panik von `cb` kann daher einen Prozessabbruch auslösen.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // schau nur auf den oberen Rahmen
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Lösen Sie einen zuvor erfassten Frame in ein Symbol auf und übergeben Sie das Symbol an den angegebenen Abschluss.
///
/// Diese Funktion hat dieselbe Funktion wie `resolve`, außer dass anstelle einer Adresse ein `Frame` als Argument verwendet wird.
/// Dies kann es einigen Plattformimplementierungen der Rückverfolgung ermöglichen, beispielsweise genauere Symbolinformationen oder Informationen zu Inline-Frames bereitzustellen.
///
/// Es wird empfohlen, dies zu verwenden, wenn Sie können.
///
/// # Erforderliche Funktionen
///
/// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
///
/// # Panics
///
/// Diese Funktion ist bestrebt, niemals panic zu verwenden. Wenn der `cb` jedoch panics bereitstellt, erzwingen einige Plattformen ein doppeltes panic, um den Vorgang abzubrechen.
/// Einige Plattformen verwenden eine C-Bibliothek, die intern Rückrufe verwendet, die nicht abgewickelt werden können. Eine Panik von `cb` kann daher einen Prozessabbruch auslösen.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // schau nur auf den oberen Rahmen
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-Werte von Stapelrahmen sind normalerweise (always?) die Anweisung *nach* dem Aufruf, der die eigentliche Stapelverfolgung darstellt.
// Wenn Sie dies aktivieren, ist die filename/line-Nummer eins voraus und möglicherweise leer, wenn sie sich dem Ende der Funktion nähert.
//
// Dies scheint im Grunde immer auf allen Plattformen der Fall zu sein, daher subtrahieren wir immer eine von einer aufgelösten IP, um sie in die vorherige Aufrufanweisung aufzulösen, anstatt an die Anweisung, an die zurückgegeben wird.
//
//
// Im Idealfall würden wir dies nicht tun.
// Im Idealfall müssen Aufrufer der `resolve`-APIs hier das -1 manuell ausführen und angeben, dass sie Standortinformationen für die *vorherige* Anweisung und nicht für die aktuelle Anweisung wünschen.
// Idealerweise würden wir auch auf `Frame` belichten, wenn wir tatsächlich die Adresse des nächsten Befehls oder des aktuellen Befehls sind.
//
// Im Moment ist dies jedoch ein ziemliches Nischenproblem, daher subtrahieren wir nur intern immer eines.
// Die Verbraucher sollten weiterarbeiten und ziemlich gute Ergebnisse erzielen, also sollten wir gut genug sein.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Wie `resolve`, nur unsicher, da es nicht synchronisiert ist.
///
/// Diese Funktion hat keine Synchronisationsgarantien, ist jedoch verfügbar, wenn die `std`-Funktion dieses crate nicht kompiliert ist.
/// Weitere Dokumentation und Beispiele finden Sie in der `resolve`-Funktion.
///
/// # Panics
///
/// In den Informationen zu `resolve` finden Sie Informationen zu Vorsichtsmaßnahmen bei der Panik von `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Wie `resolve_frame`, nur unsicher, da es nicht synchronisiert ist.
///
/// Diese Funktion hat keine Synchronisationsgarantien, ist jedoch verfügbar, wenn die `std`-Funktion dieses crate nicht kompiliert ist.
/// Weitere Dokumentation und Beispiele finden Sie in der `resolve_frame`-Funktion.
///
/// # Panics
///
/// In den Informationen zu `resolve_frame` finden Sie Informationen zu Vorsichtsmaßnahmen bei der Panik von `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Ein trait, der die Auflösung eines Symbols in einer Datei darstellt.
///
/// Dieses trait wird als trait-Objekt für den Abschluss der `backtrace::resolve`-Funktion ausgegeben und praktisch versendet, da nicht bekannt ist, welche Implementierung dahinter steht.
///
///
/// Ein Symbol kann Kontextinformationen zu einer Funktion enthalten, z. B. Name, Dateiname, Zeilennummer, genaue Adresse usw.
/// Es sind jedoch nicht immer alle Informationen in einem Symbol verfügbar, sodass alle Methoden einen `Option` zurückgeben.
///
///
pub struct Symbol {
    // TODO: Diese lebenslange Bindung muss schließlich auf `Symbol` beibehalten werden.
    // Aber das ist derzeit eine bahnbrechende Veränderung.
    // Im Moment ist dies sicher, da `Symbol` immer nur als Referenz ausgegeben wird und nicht geklont werden kann.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Gibt den Namen dieser Funktion zurück.
    ///
    /// Die zurückgegebene Struktur kann verwendet werden, um verschiedene Eigenschaften nach dem Symbolnamen abzufragen:
    ///
    ///
    /// * Die `Display`-Implementierung druckt das entwirrte Symbol aus.
    /// * Auf den `str`-Rohwert des Symbols kann zugegriffen werden (sofern er für utf-8 gültig ist).
    /// * Auf die Rohbytes für den Symbolnamen kann zugegriffen werden.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Gibt die Startadresse dieser Funktion zurück.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Gibt den Rohdateinamen als Slice zurück.
    /// Dies ist hauptsächlich für `no_std`-Umgebungen nützlich.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Gibt die Spaltennummer zurück, für die dieses Symbol gerade ausgeführt wird.
    ///
    /// Derzeit liefert nur gimli hier und auch dann nur dann einen Wert, wenn `filename` `Some` zurückgibt, und unterliegt daher ähnlichen Einschränkungen.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Gibt die Zeilennummer zurück, für die dieses Symbol gerade ausgeführt wird.
    ///
    /// Dieser Rückgabewert ist normalerweise `Some`, wenn `filename` `Some` zurückgibt, und unterliegt daher ähnlichen Einschränkungen.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Gibt den Dateinamen zurück, in dem diese Funktion definiert wurde.
    ///
    /// Dies ist derzeit nur verfügbar, wenn libbacktrace oder gimli verwendet werden (z
    /// unix andere Plattformen) und wenn eine Binärdatei mit debuginfo kompiliert wird.
    /// Wenn keine dieser Bedingungen erfüllt ist, wird wahrscheinlich `None` zurückgegeben.
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Möglicherweise ein analysiertes C++ -Symbol, wenn das Parsen des verstümmelten Symbols als Rust fehlgeschlagen ist.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Stellen Sie sicher, dass diese Größe Null bleibt, damit die `cpp_demangle`-Funktion bei Deaktivierung keine Kosten verursacht.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Ein Wrapper um einen Symbolnamen, um ergonomische Accessoren für den entwirrten Namen, die Rohbytes, die Rohzeichenfolge usw. bereitzustellen.
///
// Erlaube toten Code, wenn die `cpp_demangle`-Funktion nicht aktiviert ist.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Erstellt einen neuen Symbolnamen aus den zugrunde liegenden Rohbytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Gibt den rohen (mangled)-Symbolnamen als `str` zurück, wenn das Symbol utf-8 gültig ist.
    ///
    /// Verwenden Sie die `Display`-Implementierung, wenn Sie die entwirrte Version möchten.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Gibt den Namen des Rohsymbols als Liste von Bytes zurück
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dies kann gedruckt werden, wenn das entwirrte Symbol nicht wirklich gültig ist. Behandeln Sie den Fehler hier also ordnungsgemäß, indem Sie ihn nicht nach außen weitergeben.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Versuchen Sie, den zwischengespeicherten Speicher zurückzugewinnen, der zum Symbolisieren von Adressen verwendet wird.
///
/// Diese Methode versucht, alle globalen Datenstrukturen freizugeben, die ansonsten global oder im Thread zwischengespeichert wurden und normalerweise analysierte DWARF-Informationen oder ähnliches darstellen.
///
///
/// # Caveats
///
/// Obwohl diese Funktion immer verfügbar ist, führt sie bei den meisten Implementierungen nichts aus.
/// Bibliotheken wie dbghelp oder libbacktrace bieten keine Möglichkeit, den Status aufzuheben und den zugewiesenen Speicher zu verwalten.
/// Derzeit ist die `gimli-symbolize`-Funktion dieses crate die einzige Funktion, bei der diese Funktion Auswirkungen hat.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}