// Wird derzeit nur auf Linux verwendet. Lassen Sie daher toten Code an anderer Stelle zu
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Ein einfacher Arena-Allokator für Byte-Puffer.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Weist einen Puffer der angegebenen Größe zu und gibt einen veränderbaren Verweis darauf zurück.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SICHERHEIT: Dies ist die einzige Funktion, die jemals eine veränderbare Struktur erstellt
        // Verweis auf `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SICHERHEIT: Wir entfernen niemals Elemente aus `self.buffers`, also eine Referenz
        // Die Daten in einem Puffer bleiben so lange erhalten wie `self`.
        &mut buffers[i]
    }
}