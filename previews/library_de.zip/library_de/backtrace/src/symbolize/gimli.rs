//! Unterstützung für die Symbolisierung mit `gimli` crate auf crates.io
//!
//! Dies ist die Standardsymbolisierungsimplementierung für Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Statische Lebensdauer ist eine Lüge, um mangelnde Unterstützung für selbstreferenzielle Strukturen zu hacken.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konvertieren Sie in 'statische Lebensdauern, da die Symbole nur `map` und `stash` ausleihen sollten und wir sie unten beibehalten.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Informationen zum Laden nativer Bibliotheken auf Windows finden Sie in den folgenden Strategien zu rust-lang/rust#71060.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW-Bibliotheken unterstützen derzeit keine ASLR (rust-lang/rust#16514), aber DLLs können weiterhin im Adressraum verschoben werden.
            // Es scheint, dass Adressen in Debug-Informationen alle so sind, als ob diese Bibliothek an ihrem "image base" geladen worden wäre, einem Feld in ihren COFF-Datei-Headern.
            // Da debuginfo dies aufzulisten scheint, analysieren wir die Symboltabelle und speichern Adressen, als ob die Bibliothek auch bei "image base" geladen worden wäre.
            //
            // Die Bibliothek kann jedoch möglicherweise nicht unter "image base" geladen werden.
            // (Vermutlich wird dort etwas anderes geladen?) Hier kommt das `bias`-Feld ins Spiel, und wir müssen hier den Wert von `bias` herausfinden.Leider ist nicht klar, wie man dies von einem geladenen Modul erhält.
            // Was wir jedoch haben, ist die tatsächliche Ladeadresse (`modBaseAddr`).
            //
            // Als kleine Ausrede für den Moment zeichnen wir die Datei mmap ab, lesen die Datei-Header-Informationen und löschen dann die mmap.Dies ist verschwenderisch, da wir die mmap wahrscheinlich später wieder öffnen werden, aber dies sollte vorerst gut genug funktionieren.
            //
            // Sobald wir den `image_base` (gewünschter Ladeort) und den `base_addr` (tatsächlicher Ladeort) haben, können wir den `bias` (Differenz zwischen dem tatsächlichen und dem gewünschten) ausfüllen, und dann ist die angegebene Adresse jedes Segments der `image_base`, da dies in der Datei angegeben ist.
            //
            //
            // Im Moment scheint es, dass wir im Gegensatz zu ELF/MachO mit einem Segment pro Bibliothek auskommen können, wobei `modBaseSize` als Gesamtgröße verwendet wird.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Verwendet das Mach-O-Dateiformat und verwendet DYLD-spezifische APIs, um eine Liste nativer Bibliotheken zu laden, die Teil der Anwendung sind.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Rufen Sie den Namen dieser Bibliothek ab, der dem Pfad entspricht, in den sie ebenfalls geladen werden soll.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Laden Sie den Image-Header dieser Bibliothek und delegieren Sie ihn an `object`, um alle Ladebefehle zu analysieren, damit wir alle hier beteiligten Segmente herausfinden können.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Durchlaufen Sie die Segmente und registrieren Sie bekannte Regionen für Segmente, die wir finden.
            // Zeichnen Sie außerdem Informationen zu Textsegmenten zur späteren Verarbeitung auf (siehe Kommentare unten).
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bestimmen Sie den "slide" für diese Bibliothek, der letztendlich die Verzerrung ist, mit der wir herausfinden, wo im Speicher Objekte geladen werden.
            // Dies ist jedoch eine etwas seltsame Berechnung und das Ergebnis davon, ein paar Dinge in freier Wildbahn auszuprobieren und zu sehen, was steckt.
            //
            // Die allgemeine Idee ist, dass sich das `bias` plus `stated_virtual_memory_address` eines Segments dort befindet, wo sich das Segment im tatsächlichen Adressraum befindet.
            // Die andere Sache, auf die wir uns verlassen, ist, dass eine echte Adresse minus `bias` der Index ist, der in der Symboltabelle und in der Debuginfo nachgeschlagen werden muss.
            //
            // Es stellt sich jedoch heraus, dass diese Berechnungen für systemgeladene Bibliotheken falsch sind.Für native ausführbare Dateien erscheint dies jedoch korrekt.
            // Wenn Sie eine Logik aus der LLDB-Quelle entfernen, verfügt sie über ein spezielles Gehäuse für den ersten `__TEXT`-Abschnitt, der aus dem Dateiversatz 0 mit einer Größe ungleich Null geladen wird.
            // Aus welchem Grund auch immer, wenn dies vorhanden ist, scheint dies zu bedeuten, dass sich die Symboltabelle nur auf die vmaddr-Folie für die Bibliothek bezieht.
            // Wenn es *nicht* vorhanden ist, bezieht sich die Symboltabelle auf die vmaddr-Folie plus die angegebene Adresse des Segments.
            //
            // Um mit dieser Situation umzugehen, erhöhen wir die Abweichung um die angegebene Adresse des ersten Textabschnitts und verringern alle angegebenen Adressen ebenfalls um diesen Betrag, wenn wir keinen Textabschnitt bei Dateiversatz Null finden.
            //
            // Auf diese Weise wird die Symboltabelle immer relativ zum Bias-Betrag der Bibliothek angezeigt.
            // Dies scheint die richtigen Ergebnisse für die Symbolisierung über die Symboltabelle zu haben.
            //
            // Ehrlich gesagt bin ich mir nicht ganz sicher, ob dies richtig ist oder ob es noch etwas gibt, das darauf hinweisen sollte, wie das geht.
            // Im Moment scheint dies (?) gut genug zu funktionieren, und wir sollten dies bei Bedarf im Laufe der Zeit immer optimieren können.
            //
            // Weitere Informationen finden Sie unter #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Andere Unix (z
        // Linux-Plattformen verwenden ELF als Objektdateiformat und implementieren normalerweise eine API namens `dl_iterate_phdr`, um native Bibliotheken zu laden.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` sollte ein gültiger Zeiger sein.
        // `vec` sollte ein gültiger Zeiger auf einen `std::Vec` sein.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 unterstützt nativ keine Debug-Informationen, aber das Build-System platziert Debug-Informationen im Pfad `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Alles andere sollte ELF verwenden, weiß aber nicht, wie native Bibliotheken geladen werden sollen.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Alle bekannten gemeinsam genutzten Bibliotheken, die geladen wurden.
    libraries: Vec<Library>,

    /// Mappings-Cache, in dem geparste Zwerginformationen gespeichert werden.
    ///
    /// Diese Liste hat eine feste Kapazität für die gesamte Laufzeit, die sich nie erhöht.
    /// Das `usize`-Element jedes Paares ist ein Index in `libraries`, wobei `usize::max_value()` die aktuelle ausführbare Datei darstellt.
    ///
    /// Der `Mapping` entspricht den analysierten Zwerginformationen.
    ///
    /// Beachten Sie, dass dies im Grunde ein LRU-Cache ist und wir die Dinge hier verschieben werden, wenn wir Adressen symbolisieren.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmente dieser Bibliothek werden in den Speicher geladen und wo sie geladen werden.
    segments: Vec<LibrarySegment>,
    /// Das "bias" dieser Bibliothek, normalerweise dort, wo es in den Speicher geladen wird.
    /// Dieser Wert wird zu der angegebenen Adresse jedes Segments addiert, um die tatsächliche Adresse des virtuellen Speichers zu erhalten, in die das Segment geladen wird.
    /// Zusätzlich wird diese Verzerrung von realen virtuellen Speicheradressen subtrahiert, um sie in debuginfo und die Symboltabelle zu indizieren.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Die angegebene Adresse dieses Segments in der Objektdatei.
    /// Hier wird das Segment nicht geladen, sondern in dieser Adresse und im `bias` der enthaltenen Bibliothek befindet es sich.
    ///
    stated_virtual_memory_address: usize,
    /// Die Größe dieses Segments im Speicher.
    len: usize,
}

// unsicher, da dies extern synchronisiert werden muss
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // unsicher, da dies extern synchronisiert werden muss
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Ein sehr kleiner, sehr einfacher LRU-Cache für Debug-Info-Mappings.
        //
        // Die Trefferquote sollte sehr hoch sein, da der typische Stapel nicht zwischen vielen gemeinsam genutzten Bibliotheken wechselt.
        //
        // Die `addr2line::Context`-Strukturen sind ziemlich teuer in der Erstellung.
        // Es wird erwartet, dass sich die Kosten durch nachfolgende `locate`-Abfragen amortisieren, die die Strukturen nutzen, die beim Erstellen von "addr2line: : Context" erstellt wurden, um eine gute Beschleunigung zu erzielen.
        //
        // Wenn wir diesen Cache nicht hätten, würde diese Amortisation niemals stattfinden, und das Symbolisieren von Rückverfolgungen wäre ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Testen Sie zunächst, ob dieser `lib` ein Segment enthält, das den `addr` enthält (Handling Relocation).Wenn diese Prüfung bestanden ist, können wir unten fortfahren und die Adresse tatsächlich übersetzen.
                //
                // Beachten Sie, dass wir hier `wrapping_add` verwenden, um Überlaufprüfungen zu vermeiden.In freier Wildbahn wurde festgestellt, dass die SVMA+- Bias-Berechnung überläuft.
                // Es scheint ein bisschen seltsam, dass das passieren würde, aber wir können nicht viel dagegen tun, außer diese Segmente wahrscheinlich einfach zu ignorieren, da sie wahrscheinlich in den Weltraum weisen.
                //
                // Dies kam ursprünglich in rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Jetzt, da wir wissen, dass `lib` `addr` enthält, können wir mit der Vorspannung versetzen, um die angegebene virutale Speicheradresse zu finden.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariante: Nach Abschluss dieser Bedingung ohne vorzeitige Rückkehr
        // Aufgrund eines Fehlers befindet sich der Cache-Eintrag für diesen Pfad auf Index 0.

        if let Some(idx) = idx {
            // Wenn sich das Mapping bereits im Cache befindet, verschieben Sie es nach vorne.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Wenn sich die Zuordnung nicht im Cache befindet, erstellen Sie eine neue Zuordnung, fügen Sie sie vorne im Cache ein und entfernen Sie gegebenenfalls den ältesten Cache-Eintrag.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // Lassen Sie die `'static`-Lebensdauer nicht aus, stellen Sie sicher, dass sie nur für uns selbst bestimmt ist
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Verlängern Sie die Lebensdauer von `sym` auf `'static`, da dies hier leider erforderlich ist, aber es wird immer nur als Referenz ausgegeben, sodass über diesen Frame hinaus ohnehin kein Verweis darauf beibehalten werden sollte.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Holen Sie sich schließlich eine zwischengespeicherte Zuordnung oder erstellen Sie eine neue Zuordnung für diese Datei und werten Sie die DWARF-Informationen aus, um den file/line/name für diese Adresse zu finden.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Wir konnten Frame-Informationen für dieses Symbol finden, und der Frame von `addr2line` enthält intern alle wichtigen Details.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Debug-Informationen konnten nicht gefunden werden, aber wir haben sie in der Symboltabelle der ausführbaren Elf-Datei gefunden.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}