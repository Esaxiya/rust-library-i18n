use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr nimmt einen Rückruf entgegen, der für jedes DSO, das mit dem Prozess verknüpft wurde, einen dl_phdr_info-Zeiger erhält.
    // dl_iterate_phdr stellt außerdem sicher, dass der dynamische Linker vom Anfang bis zum Ende der Iteration gesperrt ist.
    // Wenn der Rückruf einen Wert ungleich Null zurückgibt, wird die Iteration vorzeitig beendet.
    // 'data' wird bei jedem Aufruf als drittes Argument an den Rückruf übergeben.
    // 'size' gibt die Größe der dl_phdr_info an.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Wir müssen die Build-ID und einige grundlegende Programm-Header-Daten analysieren, was bedeutet, dass wir auch ein paar Dinge aus der ELF-Spezifikation benötigen.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Jetzt müssen wir Bit für Bit die Struktur des Typs dl_phdr_info replizieren, der vom aktuellen dynamischen Linker von fuchsia verwendet wird.
// Chromium hat auch diese ABI-Grenze sowie ein Crashpad.
// Schließlich möchten wir diese Fälle verschieben, um die Elfensuche zu verwenden, aber wir müssten dies im SDK bereitstellen, und das wurde noch nicht getan.
//
// Daher müssen wir (und sie) diese Methode anwenden, die eine enge Kopplung mit der Fuchsia libc bewirkt.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Wir können nicht wissen, ob e_phoff und e_phnum gültig sind.
    // libc sollte dies jedoch für uns sicherstellen, damit es sicher ist, hier ein Slice zu bilden.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr repräsentiert einen 64-Bit-ELF-Programm-Header in der Endianness der Zielarchitektur.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr repräsentiert einen gültigen ELF-Programm-Header und dessen Inhalt.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Wir können nicht überprüfen, ob p_addr oder p_memsz gültig sind.
    // Fuchsias libc analysiert jedoch zuerst die Noten, daher müssen diese Überschriften gültig sein, da sie hier sind.
    //
    // NoteIter erfordert nicht, dass die zugrunde liegenden Daten gültig sind, aber dass die Grenzen gültig sind.
    // Wir vertrauen darauf, dass libc dafür gesorgt hat, dass dies bei uns hier der Fall ist.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Der Notiztyp für Build-IDs.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr repräsentiert einen ELF-Notenkopf in der Endianness des Ziels.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Note repräsentiert eine ELF-Note (Header + Inhalt).
// Der Name bleibt als u8-Slice erhalten, da er nicht immer nullterminiert ist und rust es einfach genug macht, zu überprüfen, ob die Bytes in beiden Fällen übereinstimmen.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Mit NoteIter können Sie sicher über ein Notensegment iterieren.
// Es wird beendet, sobald ein Fehler auftritt oder keine Notizen mehr vorhanden sind.
// Wenn Sie über ungültige Daten iterieren, funktioniert dies so, als ob keine Notizen gefunden wurden.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Es ist eine Funktionsinvariante, dass der angegebene Zeiger und die angegebene Größe einen gültigen Bereich von Bytes bezeichnen, die alle gelesen werden können.
    // Der Inhalt dieser Bytes kann alles sein, aber der Bereich muss gültig sein, damit dies sicher ist.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to richtet 'x' auf 'To'-Byte-Ausrichtung aus, vorausgesetzt, 'to' ist eine Potenz von 2.
// Dies folgt einem Standardmuster im C/C ++ ELF-Parsing-Code, in dem (x + bis, 1) und -to verwendet werden.
// Mit Rust kannst du usize nicht negieren, also benutze ich
// 2-Komplement-Konvertierung, um dies wiederherzustellen.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 verbraucht num Bytes aus dem Slice (falls vorhanden) und stellt zusätzlich sicher, dass das endgültige Slice richtig ausgerichtet ist.
// Wenn entweder die Anzahl der angeforderten Bytes zu groß ist oder das Slice danach nicht neu ausgerichtet werden kann, weil nicht genügend verbleibende Bytes vorhanden sind, wird None zurückgegeben und das Slice wird nicht geändert.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Diese Funktion hat keine echten Invarianten, die der Aufrufer einhalten muss, außer vielleicht, dass 'bytes' auf Leistung ausgerichtet sein sollte (und bei einigen Architekturen auf Richtigkeit).
// Die Werte in den Elf_Nhdr-Feldern mögen Unsinn sein, aber diese Funktion stellt sicher, dass dies nicht der Fall ist.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dies ist sicher, solange genügend Speicherplatz vorhanden ist, und wir haben dies gerade in der obigen if-Anweisung bestätigt, damit dies nicht unsicher ist.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Beachten Sie, dass sice_of: :<Elf_Nhdr>() ist immer 4 Byte ausgerichtet.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Überprüfen Sie, ob wir das Ende erreicht haben.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Wir wandeln ein nhdr um, aber wir betrachten die resultierende Struktur sorgfältig.
        // Wir vertrauen den Namenz oder Deszsz nicht und treffen keine unsicheren Entscheidungen basierend auf dem Typ.
        //
        // Selbst wenn wir den kompletten Müll rausholen, sollten wir trotzdem in Sicherheit sein.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Gibt an, dass ein Segment ausführbar ist.
const PERM_X: u32 = 0b00000001;
/// Gibt an, dass ein Segment beschreibbar ist.
const PERM_W: u32 = 0b00000010;
/// Zeigt an, dass ein Segment lesbar ist.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Repräsentiert ein ELF-Segment zur Laufzeit.
struct Segment {
    /// Gibt die virtuelle Laufzeitadresse des Inhalts dieses Segments an.
    addr: usize,
    /// Gibt die Speichergröße des Inhalts dieses Segments an.
    size: usize,
    /// Gibt die virtuelle Adresse des Moduls dieses Segments mit der ELF-Datei an.
    mod_rel_addr: usize,
    /// Gibt die in der ELF-Datei gefundenen Berechtigungen an.
    /// Diese Berechtigungen sind jedoch nicht unbedingt die zur Laufzeit vorhandenen Berechtigungen.
    flags: Perm,
}

/// Lässt einen über Segmente von einem DSO iterieren.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Stellt ein ELF-DSO (Dynamic Shared Object) dar.
/// Dieser Typ verweist auf die im tatsächlichen DSO gespeicherten Daten, anstatt eine eigene Kopie zu erstellen.
struct Dso<'a> {
    /// Der dynamische Linker gibt uns immer einen Namen, auch wenn der Name leer ist.
    /// Bei der ausführbaren Hauptdatei ist dieser Name leer.
    /// Bei einem gemeinsam genutzten Objekt ist dies der Soname (siehe DT_SONAME).
    name: &'a str,
    /// Auf Fuchsia haben praktisch alle Binärdateien Build-IDs, dies ist jedoch keine strenge Anforderung.
    /// Es gibt keine Möglichkeit, DSO-Informationen anschließend mit einer echten ELF-Datei abzugleichen, wenn keine build_id vorhanden ist. Daher benötigen wir, dass jedes DSO hier eine hat.
    ///
    /// DSOs ohne build_id werden ignoriert.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Gibt einen Iterator über Segmente in diesem DSO zurück.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Diese Fehler codieren Probleme, die beim Analysieren von Informationen zu jedem DSO auftreten.
///
enum Error {
    /// NameError bedeutet, dass beim Konvertieren einer Zeichenfolge im C-Stil in eine Zeichenfolge vom Typ rust ein Fehler aufgetreten ist.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError bedeutet, dass wir keine Build-ID gefunden haben.
    /// Dies kann entweder daran liegen, dass das DSO keine Build-ID hatte oder dass das Segment, das die Build-ID enthält, fehlerhaft war.
    ///
    BuildIDError,
}

/// Ruft entweder 'dso' oder 'error' für jedes DSO auf, das vom dynamischen Linker in den Prozess eingebunden wird.
///
///
/// # Arguments
///
/// * `visitor` - Ein DsoPrinter mit einer der Essmethoden, die für jedes DSO aufgerufen werden.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr stellt sicher, dass info.name auf einen gültigen Speicherort verweist.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Diese Funktion druckt das Fuchsia-Symbolisierungs-Markup für alle in einem DSO enthaltenen Informationen.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}