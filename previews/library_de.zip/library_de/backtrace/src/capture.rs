use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Darstellung einer eigenen und in sich geschlossenen Rückverfolgung.
///
/// Diese Struktur kann verwendet werden, um eine Rückverfolgung an verschiedenen Punkten in einem Programm zu erfassen und später, um zu überprüfen, was die Rückverfolgung zu diesem Zeitpunkt war.
///
///
/// `Backtrace` unterstützt das hübsche Drucken von Backtraces durch die `Debug`-Implementierung.
///
/// # Erforderliche Funktionen
///
/// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Die Frames hier werden von oben nach unten im Stapel aufgelistet
    frames: Vec<BacktraceFrame>,
    // Der Index, von dem wir glauben, dass er der eigentliche Beginn des Backtraces ist, wobei Frames wie `Backtrace::new` und `backtrace::trace` weggelassen werden.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Erfasste Version eines Frames in einer Rückverfolgung.
///
/// Dieser Typ wird von `Backtrace::frames` als Liste zurückgegeben und repräsentiert einen Stapelrahmen in einer erfassten Rückverfolgung.
///
/// # Erforderliche Funktionen
///
/// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Erfasste Version eines Symbols in einer Rückverfolgung.
///
/// Dieser Typ wird von `BacktraceFrame::symbols` als Liste zurückgegeben und repräsentiert die Metadaten für ein Symbol in einer Rückverfolgung.
///
/// # Erforderliche Funktionen
///
/// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Erfasst eine Rückverfolgung an der Aufrufstelle dieser Funktion und gibt eine eigene Darstellung zurück.
    ///
    /// Diese Funktion ist nützlich, um eine Rückverfolgung als Objekt in Rust darzustellen.Dieser zurückgegebene Wert kann über Threads gesendet und an anderer Stelle gedruckt werden. Der Zweck dieses Werts besteht darin, vollständig in sich geschlossen zu sein.
    ///
    /// Beachten Sie, dass es auf einigen Plattformen extrem teuer sein kann, eine vollständige Rückverfolgung zu erwerben und diese aufzulösen.
    /// Wenn die Kosten für Ihre Anwendung zu hoch sind, wird empfohlen, stattdessen `Backtrace::new_unresolved()` zu verwenden, wodurch der Schritt der Symbolauflösung (der normalerweise am längsten dauert) vermieden wird und dieser auf einen späteren Zeitpunkt verschoben werden kann.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // Ich möchte sicherstellen, dass hier ein Rahmen zum Entfernen vorhanden ist
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Ähnlich wie bei `new`, außer dass dadurch keine Symbole aufgelöst werden, wird die Rückverfolgung einfach als Adressliste erfasst.
    ///
    /// Zu einem späteren Zeitpunkt kann die `resolve`-Funktion aufgerufen werden, um die Symbole dieser Rückverfolgung in lesbare Namen aufzulösen.
    /// Diese Funktion ist vorhanden, da der Auflösungsprozess manchmal sehr viel Zeit in Anspruch nehmen kann, während eine einzelne Rückverfolgung möglicherweise nur selten gedruckt wird.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // Keine Symbolnamen
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // Symbolnamen jetzt vorhanden
    /// ```
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    ///
    #[inline(never)] // Ich möchte sicherstellen, dass hier ein Rahmen zum Entfernen vorhanden ist
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Gibt die Frames zurück, von denen diese Rückverfolgung erfasst wurde.
    ///
    /// Der erste Eintrag dieses Slice ist wahrscheinlich die Funktion `Backtrace::new`, und der letzte Frame ist wahrscheinlich etwas darüber, wie dieser Thread oder die Hauptfunktion gestartet wurde.
    ///
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Wenn diese Rückverfolgung aus `new_unresolved` erstellt wurde, löst diese Funktion alle Adressen in der Rückverfolgung in ihre symbolischen Namen auf.
    ///
    ///
    /// Wenn diese Rückverfolgung zuvor aufgelöst wurde oder über `new` erstellt wurde, führt diese Funktion nichts aus.
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Gleich wie `Frame::ip`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Gleich wie `Frame::symbol_address`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Gleich wie `Frame::module_base_address`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Gibt die Liste der Symbole zurück, denen dieser Frame entspricht.
    ///
    /// Normalerweise gibt es nur ein Symbol pro Frame. Wenn jedoch mehrere Funktionen in einem Frame zusammengefasst sind, werden manchmal mehrere Symbole zurückgegeben.
    /// Das erste aufgeführte Symbol ist das "innermost function", während das letzte Symbol das äußerste (letzter Anrufer) ist.
    ///
    /// Beachten Sie, dass, wenn dieser Frame von einer nicht aufgelösten Rückverfolgung stammt, eine leere Liste zurückgegeben wird.
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Gleich wie `Symbol::name`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Gleich wie `Symbol::addr`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Gleich wie `Symbol::filename`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Gleich wie `Symbol::lineno`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Gleich wie `Symbol::colno`
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Beim Drucken von Pfaden versuchen wir, den cwd zu entfernen, falls vorhanden, andernfalls drucken wir den Pfad einfach so, wie er ist.
        // Beachten Sie, dass wir dies auch nur für das Kurzformat tun, denn wenn es voll ist, möchten wir vermutlich alles drucken.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}