#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Ein Formatierer für Rückverfolgungen.
///
/// Dieser Typ kann verwendet werden, um eine Rückverfolgung zu drucken, unabhängig davon, woher die Rückverfolgung selbst stammt.
/// Wenn Sie einen `Backtrace`-Typ haben, verwendet die `Debug`-Implementierung bereits dieses Druckformat.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Die Druckstile, die wir drucken können
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Druckt eine Terser-Rückverfolgung, die im Idealfall nur relevante Informationen enthält
    Short,
    /// Druckt eine Rückverfolgung, die alle möglichen Informationen enthält
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Erstellen Sie ein neues `BacktraceFmt`, das die Ausgabe auf das bereitgestellte `fmt` schreibt.
    ///
    /// Das `format`-Argument steuert den Stil, in dem die Rückverfolgung gedruckt wird, und das `print_path`-Argument wird zum Drucken der `BytesOrWideString`-Instanzen von Dateinamen verwendet.
    /// Dieser Typ selbst druckt keine Dateinamen, aber dieser Rückruf ist dazu erforderlich.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Druckt eine Präambel für die zu druckende Rückverfolgung.
    ///
    /// Dies ist auf einigen Plattformen erforderlich, damit Backtraces später vollständig symbolisiert werden können. Andernfalls sollte dies nur die erste Methode sein, die Sie nach dem Erstellen eines `BacktraceFmt` aufrufen.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Fügt der Backtrace-Ausgabe einen Frame hinzu.
    ///
    /// Dieses Commit gibt eine RAII-Instanz eines `BacktraceFrameFmt` zurück, mit der ein Frame tatsächlich gedruckt werden kann. Bei Zerstörung wird der Frame-Zähler erhöht.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Vervollständigt die Backtrace-Ausgabe.
    ///
    /// Dies ist derzeit ein No-Op, wird jedoch aus Gründen der future-Kompatibilität mit Backtrace-Formaten hinzugefügt.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Derzeit ein No-Op-einschließlich dieses hook, um future-Ergänzungen zu ermöglichen.
        Ok(())
    }
}

/// Ein Formatierer für nur einen Frame einer Rückverfolgung.
///
/// Dieser Typ wird von der `BacktraceFmt::frame`-Funktion erstellt.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Druckt einen `BacktraceFrame` mit diesem Rahmenformatierer.
    ///
    /// Dadurch werden alle `BacktraceSymbol`-Instanzen innerhalb des `BacktraceFrame` rekursiv gedruckt.
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Druckt einen `BacktraceSymbol` innerhalb eines `BacktraceFrame`.
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: Das ist nicht so toll, dass wir am Ende nichts drucken
            // mit Nicht-utf8-Dateinamen.
            // Zum Glück ist fast alles utf8, also sollte das nicht so schlimm sein.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Druckt ein Raw-Traced `Frame` und `Symbol`, normalerweise aus den Raw-Rückrufen dieses crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Fügt der Backtrace-Ausgabe einen Rohrahmen hinzu.
    ///
    /// Diese Methode verwendet im Gegensatz zur vorherigen Methode die Rohargumente, falls sie von verschiedenen Orten stammen.
    /// Beachten Sie, dass dies für einen Frame mehrmals aufgerufen werden kann.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Fügt der Backtrace-Ausgabe einen Rohrahmen hinzu, einschließlich Spalteninformationen.
    ///
    /// Diese Methode verwendet wie die vorherige die Rohargumente, falls sie von verschiedenen Orten stammen.
    /// Beachten Sie, dass dies für einen Frame mehrmals aufgerufen werden kann.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia kann innerhalb eines Prozesses nicht symbolisieren, daher verfügt es über ein spezielles Format, das später zum Symbolisieren verwendet werden kann.
        // Drucken Sie das aus, anstatt hier Adressen in unserem eigenen Format zu drucken.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Es ist nicht erforderlich, "null"-Frames zu drucken. Dies bedeutet im Grunde nur, dass die System-Rückverfolgung ein wenig darauf bedacht war, sehr weit zurückzuverfolgen.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Um die TCB-Größe in der Sgx-Enklave zu verringern, möchten wir keine Symbolauflösungsfunktion implementieren.
        // Vielmehr können wir hier den Versatz der Adresse drucken, der später der korrekten Funktion zugeordnet werden könnte.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Drucken Sie den Index des Frames sowie den optionalen Anweisungszeiger des Frames.
        // Wenn wir uns jenseits des ersten Symbols dieses Rahmens befinden, drucken wir nur das entsprechende Leerzeichen.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Schreiben Sie als Nächstes den Symbolnamen aus und verwenden Sie die alternative Formatierung, um weitere Informationen zu erhalten, wenn es sich um eine vollständige Rückverfolgung handelt.
        // Hier behandeln wir auch Symbole, die keinen Namen haben,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Drucken Sie zum Schluss die filename/line-Nummer aus, falls verfügbar.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line werden in Zeilen unter dem Symbolnamen gedruckt. Drucken Sie daher ein geeignetes Leerzeichen aus, um uns selbst nach rechts auszurichten.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegieren Sie an unseren internen Rückruf, um den Dateinamen auszudrucken und dann die Zeilennummer auszudrucken.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Fügen Sie die Spaltennummer hinzu, falls verfügbar.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Wir kümmern uns nur um das erste Symbol eines Rahmens
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}