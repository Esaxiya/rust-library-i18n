use core::ffi::c_void;
use core::fmt;

/// Überprüft den aktuellen Aufrufstapel und übergibt alle aktiven Frames an den bereitgestellten Abschluss, um eine Stapelverfolgung zu berechnen.
///
/// Diese Funktion ist das Arbeitspferd dieser Bibliothek bei der Berechnung der Stapelspuren für ein Programm.Der gegebene Abschluss `cb` ergibt Instanzen eines `Frame`, die Informationen über diesen Aufrufrahmen auf dem Stapel darstellen.
/// Der Verschluss ergibt Frames von oben nach unten (zuletzt zuerst als Funktionen bezeichnet).
///
/// Der Rückgabewert des Abschlusses gibt an, ob die Rückverfolgung fortgesetzt werden soll.Ein Rückgabewert von `false` beendet die Rückverfolgung und kehrt sofort zurück.
///
/// Sobald ein `Frame` erworben wurde, möchten Sie wahrscheinlich `backtrace::resolve` aufrufen, um den `ip` (Anweisungszeiger) oder die Symboladresse in einen `Symbol` umzuwandeln, über den der Name und/oder der Dateiname/die Zeilennummer gelernt werden können.
///
///
/// Beachten Sie, dass dies eine Funktion auf relativ niedriger Ebene ist. Wenn Sie beispielsweise eine Rückverfolgung erfassen möchten, die später überprüft werden soll, ist der Typ `Backtrace` möglicherweise besser geeignet.
///
/// # Erforderliche Funktionen
///
/// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
///
/// # Panics
///
/// Diese Funktion ist bestrebt, niemals panic zu verwenden. Wenn der `cb` jedoch panics bereitstellt, erzwingen einige Plattformen ein doppeltes panic, um den Vorgang abzubrechen.
/// Einige Plattformen verwenden eine C-Bibliothek, die intern Rückrufe verwendet, die nicht abgewickelt werden können. Eine Panik von `cb` kann daher einen Prozessabbruch auslösen.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // Setzen Sie die Rückverfolgung fort
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Wie `trace`, nur unsicher, da es nicht synchronisiert ist.
///
/// Diese Funktion hat keine Synchronisationsgarantien, ist jedoch verfügbar, wenn die `std`-Funktion dieses crate nicht kompiliert ist.
/// Weitere Dokumentation und Beispiele finden Sie in der `trace`-Funktion.
///
/// # Panics
///
/// In den Informationen zu `trace` finden Sie Informationen zu Vorsichtsmaßnahmen bei der Panik von `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Ein trait, das einen Frame einer Rückverfolgung darstellt, ergab die `trace`-Funktion dieses crate.
///
/// Der Abschluss der Ablaufverfolgungsfunktion führt zu Frames, und der Frame wird praktisch versendet, da die zugrunde liegende Implementierung erst zur Laufzeit bekannt ist.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Gibt den aktuellen Befehlszeiger dieses Frames zurück.
    ///
    /// Dies ist normalerweise die nächste Anweisung, die im Frame ausgeführt wird, aber nicht alle Implementierungen listen dies mit 100% iger Genauigkeit auf (aber es ist im Allgemeinen ziemlich nah).
    ///
    ///
    /// Es wird empfohlen, diesen Wert an `backtrace::resolve` zu übergeben, um ihn in einen Symbolnamen umzuwandeln.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Gibt den aktuellen Stapelzeiger dieses Frames zurück.
    ///
    /// Für den Fall, dass ein Backend den Stapelzeiger für diesen Frame nicht wiederherstellen kann, wird ein Nullzeiger zurückgegeben.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Gibt die Startsymboladresse des Frames dieser Funktion zurück.
    ///
    /// Dadurch wird versucht, den von `ip` zurückgegebenen Anweisungszeiger zum Start der Funktion zurückzuspulen und diesen Wert zurückzugeben.
    ///
    /// In einigen Fällen geben Backends jedoch nur `ip` von dieser Funktion zurück.
    ///
    /// Der zurückgegebene Wert kann manchmal verwendet werden, wenn `backtrace::resolve` auf dem oben angegebenen `ip` fehlgeschlagen ist.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Gibt die Basisadresse des Moduls zurück, zu dem der Frame gehört.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dies muss an erster Stelle stehen, um sicherzustellen, dass Miri Vorrang vor der Host-Plattform hat
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // nur in dbghelp verwendet symbolisieren
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}