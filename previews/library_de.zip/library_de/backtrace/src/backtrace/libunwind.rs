//! Backtrace-Unterstützung mithilfe von libunwind/gcc_s/etc-APIs.
//!
//! Dieses Modul enthält die Möglichkeit, den Stapel mithilfe von APIs im libunwind-Stil abzuwickeln.
//! Beachten Sie, dass es eine ganze Reihe von Implementierungen der libunwind-ähnlichen API gibt, und dies versucht nur, mit den meisten auf einmal kompatibel zu sein, anstatt wählerisch zu sein.
//!
//!
//! Die libunwind-API wird von `_Unwind_Backtrace` unterstützt und ist in der Praxis sehr zuverlässig beim Generieren eines Backtraces.
//! Es ist nicht ganz klar, wie es funktioniert (Frame-Zeiger? Eh_frame-Info? Beide?), Aber es scheint zu funktionieren!
//!
//! Der größte Teil der Komplexität dieses Moduls besteht darin, die verschiedenen Plattformunterschiede zwischen libunwind-Implementierungen zu behandeln.
//! Ansonsten ist dies eine ziemlich einfache Rust-Bindung an die libunwind-APIs.
//!
//! Dies ist derzeit die Standard-Abwicklungs-API für alle Nicht-Windows-Plattformen.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Mit einem rohen libunwind-Zeiger sollte der Zugriff immer nur schreibgeschützt sein, also ist es `Sync`.
// Wenn wir über `Clone` an andere Threads senden, wechseln wir immer zu einer Version, die keine inneren Zeiger enthält, daher sollten wir auch `Send` sein.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Es scheint, dass `_Unwind_FindEnclosingFunction` unter OSX einen Zeiger auf ... etwas zurückgibt, das unklar ist.
        // Es ist definitiv nicht immer die einschließende Funktion aus irgendeinem Grund.
        // Mir ist nicht ganz klar, was hier los ist. Pessimieren Sie dies vorerst und geben Sie einfach immer die IP zurück.
        //
        // Beachten Sie, dass der `skip_inner_frames.rs`-Test unter OSX aufgrund dieser Klausel übersprungen wird. Wenn dies behoben ist, kann dieser Test theoretisch unter OSX ausgeführt werden!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Entspannen Sie die für Backtraces verwendete Bibliotheksschnittstelle
///
/// Beachten Sie, dass toter Code zulässig ist, da hier nur Bindungen verwendet werden. IOS verwendet nicht alle, aber das Hinzufügen weiterer plattformspezifischer Konfigurationen verschmutzt den Code zu sehr
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // wird nur von ARM EABI verwendet
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Kein nativer_Unwind_Backtrace unter iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // verfügbar seit GCC 4.2.0, sollte für unseren Zweck in Ordnung sein
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Diese Funktion ist eine Fehlbezeichnung: Anstatt die kanonische Frame-Adresse dieses Frames (auch bekannt als SP des Anrufer-Frames) abzurufen, wird der SP dieses Frames zurückgegeben.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x verwendet einen voreingenommenen CFA-Wert, daher müssen wir_Unwind_GetGR verwenden, um das Stapelzeigerregister (%r15) zu erhalten, anstatt uns auf_Unwind_GetCFA zu verlassen.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Auf android und Arm sind die Funktion `_Unwind_GetIP` und einige andere Makros. Daher definieren wir Funktionen, die die Erweiterung der Makros enthalten.
    //
    //
    // TODO: Link zu der Header-Datei, die diese Makros definiert, wenn Sie sie finden können.
    // (Ich, fitzgen, kann die Header-Datei nicht finden, von der einige dieser Makroerweiterungen ursprünglich ausgeliehen wurden.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 ist der Stapelzeiger am Arm.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Diese Funktion ist auch auf Android oder ARM/Linux nicht vorhanden. Machen Sie sie daher zu einem No-Op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}