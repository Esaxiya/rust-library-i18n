//! Plattformabhängige Typen.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Eine plattformunabhängige Darstellung eines Strings.
/// Wenn Sie mit aktiviertem `std` arbeiten, werden die praktischen Methoden zum Bereitstellen von Konvertierungen in `std`-Typen empfohlen.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Ein Slice, das normalerweise auf Unix-Plattformen bereitgestellt wird.
    Bytes(&'a [u8]),
    /// Breite Zeichenfolgen normalerweise von Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy konvertiert in einen `Cow<str>`, wird zugewiesen, wenn `Bytes` nicht gültig ist UTF-8 oder wenn `BytesOrWideString` `Wide` ist.
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Bietet eine `Path`-Darstellung von `BytesOrWideString`.
    ///
    /// # Erforderliche Funktionen
    ///
    /// Für diese Funktion muss die `std`-Funktion des `backtrace` crate aktiviert sein, und die `std`-Funktion ist standardmäßig aktiviert.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}