//! Ein Modul zur Verwaltung der dbghelp-Bindungen unter Windows
//!
//! Backtraces auf Windows (zumindest für MSVC) werden größtenteils über `dbghelp.dll` und die verschiedenen darin enthaltenen Funktionen bereitgestellt.
//! Diese Funktionen werden derzeit *dynamisch* geladen, anstatt statisch mit `dbghelp.dll` zu verknüpfen.
//! Dies wird derzeit von der Standardbibliothek durchgeführt (und ist dort theoretisch erforderlich), ist jedoch ein Versuch, die statischen DLL-Abhängigkeiten einer Bibliothek zu verringern, da Rückverfolgungen normalerweise ziemlich optional sind.
//!
//! Trotzdem wird `dbghelp.dll` fast immer erfolgreich auf Windows geladen.
//!
//! Beachten Sie jedoch, dass wir, da wir all diese Unterstützung dynamisch laden, die Rohdefinitionen in `winapi` nicht verwenden können, sondern die Funktionszeigertypen selbst definieren und diese verwenden müssen.
//! Wir möchten nicht wirklich Winapi duplizieren, daher haben wir eine Cargo-Funktion `verify-winapi`, die bestätigt, dass alle Bindungen mit denen in Winapi übereinstimmen und diese Funktion in CI aktiviert ist.
//!
//! Schließlich werden Sie hier feststellen, dass die DLL für `dbghelp.dll` niemals entladen wird, und das ist derzeit beabsichtigt.
//! Der Gedanke ist, dass wir es global zwischenspeichern und zwischen Aufrufen der API verwenden können, um teures loads/unloads zu vermeiden.
//! Wenn dies ein Problem für Lecksucher oder ähnliches ist, können wir die Brücke überqueren, wenn wir dort ankommen.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Arbeiten Sie daran, dass `SymGetOptions` und `SymSetOptions` in Winapi selbst nicht vorhanden sind.
// Andernfalls wird dies nur verwendet, wenn wir Typen gegen Winapi überprüfen.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Noch nicht in Winapi definiert
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Dies ist in winapi definiert, aber es ist falsch (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Noch nicht in Winapi definiert
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Dieses Makro wird verwendet, um eine `Dbghelp`-Struktur zu definieren, die intern alle Funktionszeiger enthält, die wir möglicherweise laden.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Die geladene DLL für `dbghelp.dll`
            dll: HMODULE,

            // Jeder Funktionszeiger für jede Funktion, die wir verwenden könnten
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Anfangs haben wir die DLL nicht geladen
            dll: 0 as *mut _,
            // Zu Beginn werden alle Funktionen auf Null gesetzt, um anzuzeigen, dass sie dynamisch geladen werden müssen.
            //
            $($name: 0,)*
        };

        // Convenience typedef für jeden Funktionstyp.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Versuche, `dbghelp.dll` zu öffnen.
            /// Gibt Erfolg zurück, wenn es funktioniert, oder Fehler, wenn `LoadLibraryW` fehlschlägt.
            ///
            /// Panics, wenn die Bibliothek bereits geladen ist.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funktion für jede Methode, die wir verwenden möchten.
            // Beim Aufruf liest es entweder den zwischengespeicherten Funktionszeiger oder lädt ihn und gibt den geladenen Wert zurück.
            // Es wird behauptet, dass Lasten erfolgreich sind.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Praktischer Proxy zur Verwendung der Bereinigungssperren zum Verweisen auf dbghelp-Funktionen.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialisieren Sie die gesamte Unterstützung, die für den Zugriff auf `dbghelp`-API-Funktionen von diesem crate aus erforderlich ist.
///
///
/// Beachten Sie, dass diese Funktion **sicher** ist und intern eine eigene Synchronisation hat.
/// Beachten Sie auch, dass es sicher ist, diese Funktion mehrmals rekursiv aufzurufen.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Als erstes müssen wir diese Funktion synchronisieren.Dies kann gleichzeitig von anderen Threads oder rekursiv innerhalb eines Threads aufgerufen werden.
        // Beachten Sie jedoch, dass dies schwieriger ist, da das, was wir hier verwenden, `dbghelp`,*auch* in diesem Prozess mit allen anderen Anrufern von `dbghelp` synchronisiert werden muss.
        //
        // Normalerweise gibt es nicht wirklich so viele Aufrufe von `dbghelp` innerhalb desselben Prozesses, und wir können wahrscheinlich davon ausgehen, dass wir die einzigen sind, die darauf zugreifen.
        // Es gibt jedoch einen primären anderen Benutzer, über den wir uns Sorgen machen müssen, der ironischerweise wir selbst sind, aber in der Standardbibliothek.
        // Die Standardbibliothek Rust hängt von dieser crate für die Backtrace-Unterstützung ab, und diese crate ist auch auf crates.io vorhanden.
        // Dies bedeutet, dass die Standardbibliothek, wenn sie eine panic-Rückverfolgung druckt, möglicherweise mit dieser crate von crates.io konkurriert und Segfaults verursacht.
        //
        // Um dieses Synchronisationsproblem zu lösen, verwenden wir hier einen Windows-spezifischen Trick (es handelt sich schließlich um eine Windows-spezifische Einschränkung der Synchronisation).
        // Wir erstellen einen *session-local* mit dem Namen mutex, um diesen Aufruf zu schützen.
        // Die Absicht hierbei ist, dass die Standardbibliothek und dieses crate keine APIs auf Rust-Ebene gemeinsam nutzen müssen, um hier zu synchronisieren, sondern hinter den Kulissen arbeiten können, um sicherzustellen, dass sie miteinander synchronisiert werden.
        //
        // Auf diese Weise können wir beim Aufrufen dieser Funktion über die Standardbibliothek oder über crates.io sicher sein, dass derselbe Mutex erfasst wird.
        //
        // Das heißt also, dass wir hier als erstes atomar einen `HANDLE` erstellen, der auf Windows als Mutex bezeichnet wird.
        // Wir synchronisieren ein wenig mit anderen Threads, die diese Funktion speziell nutzen, und stellen sicher, dass nur ein Handle pro Instanz dieser Funktion erstellt wird.
        // Beachten Sie, dass das Handle niemals geschlossen wird, wenn es im globalen Speicher gespeichert ist.
        //
        // Nachdem wir das Schloss tatsächlich geöffnet haben, erwerben wir es einfach und unser `Init`-Griff, den wir verteilen, ist dafür verantwortlich, dass es schließlich gelöscht wird.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, Puh!Nachdem wir alle sicher synchronisiert sind, können wir nun mit der Verarbeitung beginnen.
        // Zunächst müssen wir sicherstellen, dass `dbghelp.dll` in diesem Prozess tatsächlich geladen wird.
        // Wir tun dies dynamisch, um eine statische Abhängigkeit zu vermeiden.
        // Dies wurde in der Vergangenheit getan, um seltsame Verknüpfungsprobleme zu umgehen, und soll Binärdateien ein bisschen portabler machen, da dies größtenteils nur ein Debugging-Dienstprogramm ist.
        //
        //
        // Sobald wir `dbghelp.dll` geöffnet haben, müssen wir einige Initialisierungsfunktionen darin aufrufen. Weitere Informationen finden Sie weiter unten.
        // Wir machen das jedoch nur einmal, also haben wir einen globalen Booleschen Wert, der angibt, ob wir noch fertig sind oder nicht.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Stellen Sie sicher, dass das `SYMOPT_DEFERRED_LOADS`-Flag gesetzt ist, denn laut MSVC-eigenen Dokumenten dazu: "This is the fastest, most efficient way to use the symbol handler.", also machen wir das!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Initialisieren Sie Symbole tatsächlich mit MSVC.Beachten Sie, dass dies fehlschlagen kann, wir es jedoch ignorieren.
        // Es gibt an sich nicht viel Stand der Technik, aber LLVM scheint den Rückgabewert hier intern zu ignorieren, und eine der Desinfektionsbibliotheken in LLVM gibt eine beängstigende Warnung aus, wenn dies fehlschlägt, ignoriert sie jedoch auf lange Sicht im Grunde.
        //
        //
        // Ein Fall, der für Rust häufig vorkommt, ist, dass sowohl die Standardbibliothek als auch diese crate auf crates.io um `SymInitializeW` konkurrieren möchten.
        // Die Standardbibliothek wollte in der Vergangenheit die meiste Zeit initialisieren und dann bereinigen, aber jetzt, da sie diese crate verwendet, bedeutet dies, dass jemand zuerst zur Initialisierung gelangt und der andere diese Initialisierung übernimmt.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}