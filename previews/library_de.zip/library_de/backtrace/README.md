# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Eine Bibliothek zum Erfassen von Backtraces zur Laufzeit für Rust.
Diese Bibliothek zielt darauf ab, die Unterstützung der Standardbibliothek zu verbessern, indem eine programmatische Schnittstelle für die Arbeit bereitgestellt wird. Sie unterstützt jedoch auch das einfache Drucken des aktuellen Backtraces wie z0panics0Z von libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Um einfach eine Rückverfolgung zu erfassen und die Bearbeitung bis zu einem späteren Zeitpunkt zu verschieben, können Sie den `Backtrace`-Typ der obersten Ebene verwenden.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Wenn Sie jedoch mehr Zugriff auf die eigentliche Ablaufverfolgungsfunktion wünschen, können Sie die Funktionen `trace` und `resolve` direkt verwenden.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Lösen Sie diesen Anweisungszeiger auf einen Symbolnamen auf
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // Fahren Sie mit dem nächsten Frame fort
    });
}
```

# License

Dieses Projekt ist unter einer der beiden lizenziert

 * Apache-Lizenz, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) oder http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-Lizenz ([LICENSE-MIT](LICENSE-MIT) oder http://opensource.org/licenses/MIT)

nach Ihrer Wahl.

### Contribution

Sofern Sie nicht ausdrücklich etwas anderes angeben, wird jeder Beitrag, der von Ihnen absichtlich zur Aufnahme in Backtrace-Rs eingereicht wurde, wie in der Apache-2.0-Lizenz definiert, wie oben beschrieben ohne zusätzliche Bedingungen doppelt lizenziert.







