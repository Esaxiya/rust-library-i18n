//! Implementierung von panics mit Unterstützung von libgcc/libunwind (in irgendeiner Form).
//!
//! Hintergrundinformationen zur Ausnahmebehandlung und zum Abwickeln von Stapeln finden Sie unter "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) und den daraus verknüpften Dokumenten.
//! Dies sind auch gute Lektüren:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Eine kurze Zusammenfassung
//!
//! Die Ausnahmebehandlung erfolgt in zwei Phasen: einer Suchphase und einer Bereinigungsphase.
//!
//! In beiden Phasen wandert der Abwickler Stapelrahmen von oben nach unten unter Verwendung von Informationen aus den Abwicklungsabschnitten des Stapelrahmens der Module des aktuellen Prozesses ("module" bezieht sich hier auf ein Betriebssystemmodul, dh eine ausführbare Datei oder eine dynamische Bibliothek).
//!
//!
//! Für jeden Stapelrahmen wird der zugehörige "personality routine" aufgerufen, dessen Adresse auch im Abschnitt zum Abwickeln von Informationen gespeichert ist.
//!
//! In der Suchphase besteht die Aufgabe einer Persönlichkeitsroutine darin, das ausgelöste Ausnahmeobjekt zu untersuchen und zu entscheiden, ob es an diesem Stapelrahmen abgefangen werden soll.Sobald der Handler-Frame identifiziert wurde, beginnt die Bereinigungsphase.
//!
//! In der Bereinigungsphase ruft der Abwickler jede Persönlichkeitsroutine erneut auf.
//! Dieses Mal wird entschieden, welcher (falls vorhanden) Bereinigungscode für den aktuellen Stapelrahmen ausgeführt werden muss.In diesem Fall wird die Steuerung an einen speziellen branch im Funktionskörper, den "landing pad", übertragen, der Destruktoren aufruft, Speicher frei macht usw.
//! Am Ende des Landeplatzes wird die Steuerung wieder auf den Abwickler übertragen und das Abwickeln fortgesetzt.
//!
//! Sobald der Stapel auf die Ebene des Handler-Frames abgewickelt wurde, stoppt das Abwickeln und die letzte Persönlichkeitsroutine überträgt die Kontrolle auf den Catch-Block.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Ausnahmeklassen-ID von Rust.
// Dies wird von Persönlichkeitsroutinen verwendet, um zu bestimmen, ob die Ausnahme durch ihre eigene Laufzeit ausgelöst wurde.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-Anbieter, Sprache
    0x4d4f5a_00_52555354
}

// Register-IDs wurden für jede Architektur von LLVMs TargetLowering::getExceptionPointerRegister() und TargetLowering::getExceptionSelectorRegister() entfernt und dann über Registerdefinitionstabellen (normalerweise) DWARF-Registernummern zugeordnet<arch>RegisterInfo.td, Suche nach "DwarfRegNum").
//
// Siehe auch http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Der folgende Code basiert auf den C-und C++ -Persönlichkeitsroutinen von GCC.Als Referenz siehe:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI Persönlichkeitsroutine.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS Verwendet stattdessen die Standardroutine, da das Abwickeln von SjLj verwendet wird.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces auf ARM rufen die Persönlichkeitsroutine mit dem Status==_US_VIRTUAL_UNWIND_FRAME | auf_US_FORCE_UNWIND.
                // In diesen Fällen möchten wir den Stapel weiter abwickeln, andernfalls würden alle unsere Rückverfolgungen bei __rust_try enden
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Der DWARF-Abwickler geht davon aus, dass_Unwind_Context Dinge wie die Funktion und LSDA-Zeiger enthält, ARM EHABI platziert sie jedoch im Ausnahmeobjekt.
            // Um Signaturen von Funktionen wie _Unwind_GetLanguageSpecificData() beizubehalten, die nur den Kontextzeiger verwenden, speichern die Persönlichkeitsroutinen von GCC einen Zeiger auf exception_object im Kontext unter Verwendung des für "scratch register" (r12) von ARM reservierten Speicherorts.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Ein prinzipiellerer Ansatz wäre, die vollständige Definition des_Unwind_Context von ARM in unseren libunwind-Bindungen bereitzustellen und die erforderlichen Daten direkt von dort abzurufen, wobei die DWARF-Kompatibilitätsfunktionen umgangen werden.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI erfordert, dass die Persönlichkeitsroutine den SP-Wert im Barriere-Cache des Ausnahmeobjekts aktualisiert.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Bei ARM EHABI ist die Persönlichkeitsroutine dafür verantwortlich, einen einzelnen Stapelrahmen vor der Rückkehr tatsächlich abzuwickeln (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // definiert in libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Standard-Persönlichkeitsroutine, die direkt auf den meisten Zielen und indirekt auf Windows x86_64 über SEH verwendet wird.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Bei x86_64 MinGW-Zielen ist der Abwicklungsmechanismus SEH. Die Abwicklungshandlerdaten (auch bekannt als LSDA) verwenden jedoch eine GCC-kompatible Codierung.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Die Persönlichkeitsroutine für die meisten unserer Ziele.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Die Rücksprungadresse zeigt 1 Byte nach dem Aufrufbefehl, der sich im nächsten IP-Bereich in der LSDA-Bereichstabelle befinden könnte.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Frame Unwind Info Registrierung
//
// Das Bild jedes Moduls enthält einen Frame-Unwind-Info-Bereich (normalerweise ".eh_frame").Wenn sich ein Modul in loaded/unloaded befindet, muss der Abwickler über die Position dieses Abschnitts im Speicher informiert werden.Die Methoden, um dies zu erreichen, variieren je nach Plattform.
// Bei einigen (z. B. Linux) kann der Abwickler Abwicklungsinformationsabschnitte selbst erkennen (indem er aktuell geladene Module über den dl_iterate_phdr() API and finding their ".eh_frame" sections) dynamisch auflistet; bei anderen, wie Windows, müssen Module ihre Abwicklungsinfoabschnitte über die Abwicklungs-API aktiv registrieren.
//
//
// Dieses Modul definiert zwei Symbole, die von rsbegin.rs referenziert und aufgerufen werden, um unsere Informationen bei der GCC-Laufzeit zu registrieren.
// Die Implementierung des Abwickelns des Stapels wird (vorerst) auf libgcc_eh verschoben. Rust crates verwendet jedoch diese Rust-spezifischen Einstiegspunkte, um mögliche Konflikte mit einer GCC-Laufzeit zu vermeiden.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}