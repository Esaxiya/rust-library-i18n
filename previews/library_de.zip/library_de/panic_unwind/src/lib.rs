//! Implementierung von panics über Stack-Abwicklung
//!
//! Dieses crate ist eine Implementierung von panics in Rust unter Verwendung des "most native"-Stapelabwicklungsmechanismus der Plattform, für die es kompiliert wird.
//! Dies wird derzeit im Wesentlichen in drei Eimer eingeteilt:
//!
//! 1. MSVC-Ziele verwenden SEH in der `seh.rs`-Datei.
//! 2. Emscripten verwendet C++ -Ausnahmen in der `emcc.rs`-Datei.
//! 3. Alle anderen Ziele verwenden libunwind/libgcc in der `gcc.rs`-Datei.
//!
//! Weitere Dokumentationen zu den einzelnen Implementierungen finden Sie im jeweiligen Modul.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` wird bei Miri nicht verwendet, also Schweigewarnungen.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Die Startobjekte der Laufzeit von Rust hängen von diesen Symbolen ab. Machen Sie sie daher öffentlich.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ziele, die das Abwickeln nicht unterstützen.
        // - arch=wasm32
        // - os=keine ("bare metal"-Ziele)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Verwenden Sie die Miri-Laufzeit.
        // Wir müssen weiterhin auch die oben angegebene normale Laufzeit laden, da rustc erwartet, dass bestimmte lang-Elemente von dort definiert werden.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Verwenden Sie die reale Laufzeit.
        use real_imp as imp;
    }
}

extern "C" {
    /// Der Handler in libstd wird aufgerufen, wenn ein panic-Objekt außerhalb von `catch_unwind` abgelegt wird.
    ///
    fn __rust_drop_panic() -> !;

    /// Der Handler in libstd wird aufgerufen, wenn eine fremde Ausnahme abgefangen wird.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Einstiegspunkt für das Auslösen einer Ausnahme: Delegieren Sie einfach an die plattformspezifische Implementierung.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}