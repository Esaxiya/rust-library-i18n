//! panics für Miri abwickeln.
use alloc::boxed::Box;
use core::any::Any;

// Die Art der Nutzlast, die der Miri-Motor durch Abwickeln für uns verbreitet.
// Muss zeigergroß sein.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Von Miri bereitgestellte externe Funktion zum Abwickeln.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Die Nutzlast, die wir an `miri_start_panic` übergeben, ist genau das Argument, das wir in `cleanup` unten erhalten.
    // Also packen wir es einfach einmal ein, um etwas Zeigergroßes zu bekommen.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Stellen Sie das zugrunde liegende `Box` wieder her.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}