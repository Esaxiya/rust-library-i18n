//! Dienstprogramme zum Parsen von DWARF-codierten Datenströmen.
//! Siehe <http://www.dwarfstd.org>, DWARF-4-Standard, Abschnitt 7, "Data Representation"
//!

// Dieses Modul wird derzeit nur von x86_64-pc-windows-gnu verwendet, aber wir kompilieren es überall, um Regressionen zu vermeiden.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF-Streams sind gepackt, sodass beispielsweise ein u32 nicht unbedingt an einer 4-Byte-Grenze ausgerichtet sein muss.
    // Dies kann auf Plattformen mit strengen Ausrichtungsanforderungen zu Problemen führen.
    // Durch das Umschließen von Daten in eine "packed"-Struktur weisen wir das Backend an, "misalignment-safe"-Code zu generieren.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128-und SLEB128-Codierungen sind in Abschnitt 7.6, "Variable Length Data" definiert.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}