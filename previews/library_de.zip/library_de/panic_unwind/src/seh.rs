//! Windows SEH
//!
//! Unter Windows (derzeit nur unter MSVC) ist der Standardmechanismus für die Ausnahmebehandlung die strukturierte Ausnahmebehandlung (SEH).
//! Dies unterscheidet sich erheblich von der zwergenbasierten Ausnahmebehandlung (z. B. was andere unix-Plattformen verwenden) in Bezug auf Compiler-Interna. Daher muss LLVM eine Menge zusätzlicher Unterstützung für SEH haben.
//!
//! Kurz gesagt, was hier passiert, ist:
//!
//! 1. Die `panic`-Funktion ruft die Standard-Windows-Funktion `_CxxThrowException` auf, um eine C++ -ähnliche Ausnahme auszulösen und den Abwicklungsprozess auszulösen.
//! 2.
//! Alle vom Compiler generierten Landeplätze verwenden die Persönlichkeitsfunktion `__CxxFrameHandler3`, eine Funktion in der CRT, und der Abwicklungscode in Windows verwendet diese Persönlichkeitsfunktion, um den gesamten Bereinigungscode auf dem Stapel auszuführen.
//!
//! 3. Für alle vom Compiler generierten Aufrufe von `invoke` ist ein Landeplatz als `cleanuppad` LLVM-Befehl festgelegt, der den Start der Bereinigungsroutine anzeigt.
//! Die Persönlichkeit (in Schritt 2, definiert in der CRT) ist für die Ausführung der Bereinigungsroutinen verantwortlich.
//! 4. Schließlich wird der "catch"-Code im `try`-Intrinsic (vom Compiler generiert) ausgeführt und gibt an, dass die Steuerung auf Rust zurückgesetzt werden soll.
//! Dies erfolgt über einen `catchswitch` plus einen `catchpad`-Befehl in LLVM-IR-Begriffen, wodurch schließlich die normale Steuerung mit einem `catchret`-Befehl an das Programm zurückgegeben wird.
//!
//! Einige spezifische Unterschiede zur auf gcc basierenden Ausnahmebehandlung sind:
//!
//! * Rust hat keine benutzerdefinierte Persönlichkeitsfunktion, sondern ist *immer*`__CxxFrameHandler3`.Darüber hinaus wird keine zusätzliche Filterung durchgeführt, sodass wir am Ende alle C++ -Ausnahmen abfangen, die zufällig so aussehen, wie wir sie auslösen.
//! Beachten Sie, dass das Auslösen einer Ausnahme in Rust ohnehin ein undefiniertes Verhalten ist. Dies sollte also in Ordnung sein.
//! * Wir müssen einige Daten über die Abwicklungsgrenze übertragen, insbesondere einen `Box<dyn Any + Send>`.Wie bei Dwarf-Ausnahmen werden diese beiden Zeiger als Nutzlast in der Ausnahme selbst gespeichert.
//! Unter MSVC ist jedoch keine zusätzliche Heap-Zuordnung erforderlich, da der Aufrufstapel erhalten bleibt, während Filterfunktionen ausgeführt werden.
//! Dies bedeutet, dass die Zeiger direkt an `_CxxThrowException` übergeben werden, die dann in der Filterfunktion wiederhergestellt werden, um in den Stapelrahmen des `try`-Intrinsic geschrieben zu werden.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Dies muss eine Option sein, da wir die Ausnahme als Referenz abfangen und ihr Destruktor von der C++ -Laufzeit ausgeführt wird.
    // Wenn wir die Box aus der Ausnahme entfernen, müssen wir die Ausnahme in einem gültigen Zustand belassen, damit ihr Destruktor ausgeführt werden kann, ohne die Box doppelt zu löschen.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Zunächst eine ganze Reihe von Typdefinitionen.Hier gibt es einige plattformspezifische Besonderheiten und viele, die nur offensichtlich von LLVM kopiert wurden.Der Zweck all dessen besteht darin, die folgende `panic`-Funktion durch einen Aufruf von `_CxxThrowException` zu implementieren.
//
// Diese Funktion akzeptiert zwei Argumente.Der erste ist ein Zeiger auf die Daten, die wir übergeben, in diesem Fall unser trait-Objekt.Ziemlich leicht zu finden!Der nächste ist jedoch komplizierter.
// Dies ist ein Zeiger auf eine `_ThrowInfo`-Struktur und soll im Allgemeinen nur die ausgelöste Ausnahme beschreiben.
//
// Derzeit ist die Definition dieses Typs [1] etwas haarig, und die größte Kuriosität (und der Unterschied zum Online-Artikel) besteht darin, dass bei 32-Bit die Zeiger Zeiger sind, bei 64-Bit jedoch die Zeiger als 32-Bit-Offsets von der `__ImageBase`-Symbol.
//
// Das `ptr_t`-und `ptr!`-Makro in den folgenden Modulen wird verwendet, um dies auszudrücken.
//
// Das Labyrinth der Typdefinitionen folgt auch genau dem, was LLVM für diese Art von Operation ausgibt.Wenn Sie beispielsweise diesen C++ -Code in MSVC kompilieren und die LLVM-IR ausgeben:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          Werfen Sie einen;}}
//
// Das ist im Wesentlichen das, was wir zu emulieren versuchen.Die meisten der folgenden konstanten Werte wurden nur aus LLVM kopiert.
//
// In jedem Fall sind diese Strukturen alle auf ähnliche Weise aufgebaut und für uns nur etwas ausführlich.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Beachten Sie, dass wir hier absichtlich die Regeln für die Namensverknüpfung ignorieren: Wir möchten nicht, dass C++ Rust panics durch einfaches Deklarieren eines `struct rust_panic` abfangen kann.
//
//
// Stellen Sie beim Ändern sicher, dass die Typnamenzeichenfolge genau mit der in `compiler/rustc_codegen_llvm/src/intrinsic.rs` verwendeten übereinstimmt.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Das führende `\x01`-Byte hier ist tatsächlich ein magisches Signal an LLVM, keine anderen Mangeln wie das Präfixieren eines `_`-Zeichens anzuwenden.
    //
    //
    // Dieses Symbol ist die von X++ X von C++ verwendete vtable.
    // Objekte vom Typ `std::type_info`, Typdeskriptoren, haben einen Zeiger auf diese Tabelle.
    // Typdeskriptoren werden von den oben definierten und unten konstruierten C++ EH-Strukturen referenziert.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Dieser Typdeskriptor wird nur verwendet, wenn eine Ausnahme ausgelöst wird.
// Der catch-Teil wird vom try intrinsic behandelt, der seinen eigenen TypeDescriptor generiert.
//
// Dies ist in Ordnung, da die MSVC-Laufzeit einen Zeichenfolgenvergleich für den Typnamen verwendet, um mit TypeDescriptors und nicht mit der Zeigergleichheit übereinzustimmen.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktor, der verwendet wird, wenn der C++ -Code beschließt, die Ausnahme zu erfassen und zu löschen, ohne sie weiterzugeben.
// Der catch-Teil des try intrinsic setzt das erste Wort des Ausnahmeobjekts auf 0, sodass es vom Destruktor übersprungen wird.
//
// Beachten Sie, dass x86 Windows die "thiscall"-Aufrufkonvention für C++ -Mitgliedsfunktionen anstelle der Standard-"C"-Aufrufkonvention verwendet.
//
// Die Funktion exception_copy ist hier etwas Besonderes: Sie wird von der MSVC-Laufzeit unter einem try/catch-Block aufgerufen, und die hier generierte panic wird als Ergebnis der Ausnahmekopie verwendet.
//
// Dies wird von der C++ -Laufzeit verwendet, um das Erfassen von Ausnahmen mit std::exception_ptr zu unterstützen, die wir aufgrund von Box nicht unterstützen können<dyn Any>ist nicht klonbar.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException wird vollständig auf diesem Stapelrahmen ausgeführt, sodass `data` nicht anderweitig auf den Heap übertragen werden muss.
    // Wir übergeben dieser Funktion nur einen Stapelzeiger.
    //
    // Der ManuallyDrop wird hier benötigt, da die Ausnahme beim Abwickeln nicht gelöscht werden soll.
    // Stattdessen wird es von exception_cleanup gelöscht, das von der C++ -Laufzeit aufgerufen wird.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dies ... mag zu Recht überraschend erscheinen.Bei 32-Bit-MSVC sind die Zeiger zwischen diesen Strukturen genau das, Zeiger.
    // Bei 64-Bit-MSVC werden die Zeiger zwischen Strukturen jedoch eher als 32-Bit-Offsets von `__ImageBase` ausgedrückt.
    //
    // Folglich können wir auf 32-Bit-MSVC alle diese Zeiger in den obigen "statischen" deklarieren.
    // Bei 64-Bit-MSVC müssten wir die Subtraktion von Zeigern in der Statik ausdrücken, was Rust derzeit nicht zulässt, daher können wir das eigentlich nicht tun.
    //
    // Das nächstbeste ist dann, diese Strukturen zur Laufzeit auszufüllen (Panik ist ohnehin schon beim "slow path").
    // Hier interpretieren wir alle diese Zeigerfelder als 32-Bit-Ganzzahlen neu und speichern dann den relevanten Wert darin (atomar, da gleichzeitig panics auftreten kann).
    //
    // Technisch gesehen wird die Laufzeit diese Felder wahrscheinlich nichtatomar lesen, aber theoretisch lesen sie nie den *falschen* Wert, also sollte es nicht so schlimm sein ...
    //
    // In jedem Fall müssen wir so etwas grundsätzlich tun, bis wir mehr Operationen in der Statik ausdrücken können (und dies möglicherweise nie können).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Eine NULL-Nutzlast hier bedeutet, dass wir vom Fang (...) von __rust_try hierher gekommen sind.
    // Dies geschieht, wenn eine Nicht-Rust-Fremdausnahme abgefangen wird.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dies muss vom Compiler vorhanden sein (z. B. ist es ein langes Element), wird jedoch vom Compiler nie aufgerufen, da __C_specific_handler oder_except_handler3 die Persönlichkeitsfunktion ist, die immer verwendet wird.
//
// Daher ist dies nur ein Abbruchstummel.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}