//! Implementierung von Rust panics über Prozessabbrüche
//!
//! Im Vergleich zur Implementierung über das Abwickeln ist dieses crate *viel* einfacher!Davon abgesehen ist es nicht ganz so vielseitig, aber los geht's!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" die Nutzlast und Shim zum jeweiligen Abbruch auf der betreffenden Plattform.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // Rufen Sie std::sys::abort_internal an
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Verwenden Sie unter Windows den prozessorspezifischen __fastfail-Mechanismus.In Windows 8 und höher wird der Prozess sofort beendet, ohne dass prozessbegleitende Ausnahmebehandlungsroutinen ausgeführt werden.
            // In früheren Versionen von Windows wird diese Befehlsfolge als Zugriffsverletzung behandelt, wodurch der Prozess beendet wird, ohne dass unbedingt alle Ausnahmebehandlungsroutinen umgangen werden müssen.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: Dies ist die gleiche Implementierung wie in libstds `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Das ... ist ein bisschen seltsam.Die tl; dr;ist, dass dies erforderlich ist, um richtig zu verlinken, ist die längere Erklärung unten.
//
// Derzeit werden alle von uns gelieferten Binärdateien von libcore/libstd mit `-C panic=unwind` kompiliert.Dies geschieht, um sicherzustellen, dass die Binärdateien mit möglichst vielen Situationen maximal kompatibel sind.
// Der Compiler benötigt jedoch ein "personality function" für alle mit `-C panic=unwind` kompilierten Funktionen.Diese Persönlichkeitsfunktion ist fest mit dem Symbol `rust_eh_personality` codiert und wird durch das Element `eh_personality` lang definiert.
//
// So...
// Warum nicht einfach dieses lang-Element hier definieren?Gute Frage!Die Art und Weise, in der panic-Laufzeiten verknüpft sind, ist insofern etwas subtil, als sie im crate-Speicher des Compilers "sort of" sind, aber nur dann tatsächlich verknüpft, wenn eine andere nicht tatsächlich verknüpft ist.
//
// Dies bedeutet, dass sowohl dieses crate als auch das panic_unwind crate im crate-Speicher des Compilers angezeigt werden können. Wenn beide das `eh_personality` lang-Element definieren, tritt ein Fehler auf.
//
// Um dies zu handhaben, muss der Compiler nur dann `eh_personality` definieren, wenn die verknüpfte panic-Laufzeit die Abwicklungslaufzeit ist, und andernfalls muss sie nicht definiert werden (zu Recht).
// In diesem Fall definiert diese Bibliothek dieses Symbol jedoch nur, sodass zumindest irgendwo eine gewisse Persönlichkeit vorhanden ist.
//
// Im Wesentlichen ist dieses Symbol nur so definiert, dass es mit libcore/libstd-Binärdateien verbunden wird. Es sollte jedoch niemals aufgerufen werden, da wir in einer sich abwickelnden Laufzeit überhaupt keine Verknüpfung herstellen.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Unter x86_64-pc-windows-gnu verwenden wir unsere eigene Persönlichkeitsfunktion, die `ExceptionContinueSearch` zurückgeben muss, wenn wir alle unsere Frames weitergeben.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Ähnlich wie oben entspricht dies dem `eh_catch_typeinfo`-Lang-Element, das derzeit nur in Emscripten verwendet wird.
    //
    // Da panics keine Ausnahmen generiert und fremde Ausnahmen derzeit UB mit -C panic=abort sind (obwohl dies Änderungen vorbehalten sein kann), wird bei catch_unwind-Aufrufen dieser Typ niemals verwendet.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Diese beiden werden von unseren Startobjekten auf i686-pc-windows-gnu aufgerufen, aber sie müssen nichts tun, damit die Körper Nops sind.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}