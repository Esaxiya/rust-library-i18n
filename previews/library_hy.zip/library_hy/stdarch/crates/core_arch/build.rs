use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Օգտագործվում է մեր `#[assert_instr]` անոտացիաներին ասելու համար, որ բոլոր SIMD ներքինները հասանելի են իրենց կոդեգենը ստուգելու համար, քանի որ ոմանք պատված են հետևյալ `-Ctarget-feature=+unimplemented-simd128`-ի հետ, որն այժմ չունի `#[target_feature]`-ի համարժեք:
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}