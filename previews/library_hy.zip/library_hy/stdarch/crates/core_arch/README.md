`core::arch` - Rust-ի հիմնական գրադարանի ճարտարապետությանը բնորոշ ներքին հատկություններ
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` մոդուլը իրականացնում է ճարտարապետությունից կախված ներքին հատկություններ (օրինակ ՝ SIMD):

# Usage 

`core::arch` հասանելի է որպես `libcore` մաս, և այն վերաարտահանվում է `libstd`-ի կողմից: Նախընտրեք օգտագործել այն `core::arch`-ի կամ `std::arch`-ի միջոցով, քան այս crate-ի միջոցով:
Անկայուն հատկությունները հաճախ հասանելի են գիշերային Rust-ում `feature(stdsimd)`-ի միջոցով:

`core::arch`-ի օգտագործումն այս crate-ի միջոցով պահանջում է գիշերային Rust, և այն կարող է (և կա) հաճախ կոտրվել: Միակ դեպքերը, երբ դուք պետք է հաշվի առնեք այն օգտագործել այս crate-ի միջոցով,

* եթե Ձեզ անհրաժեշտ է վերամշակել `core::arch`-ը, օրինակ `միացված հատուկ թիրախային հատկանիշներով, որոնք միացված չեն `libcore`/`libstd`-ի համար:
Note: եթե անհրաժեշտ է այն կրկին կազմել ոչ ստանդարտ թիրախի համար, նախընտրեք օգտագործել այս crate-ի փոխարեն `xargo` և համապատասխանաբար վերակազմակերպել `libcore`/`libstd`:
  
* օգտագործելով որոշ հատկություններ, որոնք հնարավոր է մատչելի չլինեն նույնիսկ անկայուն Rust հատկությունների ետևում: Մենք փորձում ենք դրանք նվազագույնի հասցնել:
Եթե ձեզ հարկավոր է օգտագործել այս հատկություններից մի քանիսը, խնդրում ենք բացել խնդիր, որպեսզի մենք կարողանանք դրանք բացահայտել գիշերային Rust-ում, և դուք կարող եք դրանք օգտագործել այնտեղից:

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` հիմնականում բաշխվում է ինչպես MIT լիցենզիայի, այնպես էլ Apache լիցենզիայի (2.0 տարբերակ) պայմանների համաձայն, մասեր, որոնք ծածկված են տարբեր BSD նման լիցենզիաներով:

Մանրամասների համար տե՛ս LICENSE-APACHE և LICENSE-MIT:

# Contribution

Քանի դեռ հստակորեն այլ բան չեք նշել, ձեր կողմից `core_arch`-ում ներառելու համար դիտավորյալ ներկայացված ցանկացած ներդրում, ինչպես սահմանված է Apache-2.0 լիցենզիայում, պետք է ունենա կրկնակի լիցենզիա, ինչպես վերը նշված, առանց որևէ լրացուցիչ պայմանների:


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












