# `rustc-std-workspace-std` crate

Տե՛ս `rustc-std-workspace-core` crate-ի փաստաթղթերը: