//! Նոր մակրոներ սահմանելիս մակրո հեղինակների աջակցության գրադարան:
//!
//! Ստանդարտ բաշխման միջոցով տրամադրված այս գրադարանն ապահովում է ընթացակարգերով սահմանված մակրո սահմանումների միջերեսներում սպառված տեսակները, ինչպիսիք են ֆունկցիայի նման մակրոները `#[proc_macro]`, մակրո հատկանիշները `#[proc_macro_attribute]` և հատուկ ածանցյալ հատկանիշները `#[proc_macro_derive]":
//!
//!
//! Տե՛ս [the book] ավելին:
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Որոշում է, թե արդյո՞ք proc_macro-ն հասանելի է դարձել ներկայումս գործող ծրագրին:
///
/// Proc_macro crate-ը նախատեսված է միայն ընթացակարգային մակրոների իրականացման ընթացքում օգտագործելու համար: Այս crate panic-ի բոլոր գործառույթները, եթե կանչված են ընթացակարգային մակրոի դրսից, օրինակ, կառուցման սցենարից կամ միավորի փորձարկումից կամ սովորական Rust երկուականից:
///
/// Հաշվի առնելով Rust գրադարանները, որոնք նախատեսված են ինչպես մակրո, այնպես էլ ոչ մակրո օգտագործման դեպքերին աջակցելու համար, `proc_macro::is_available()`-ը տրամադրում է ոչ թե խուճապային եղանակ `պարզելու, թե արդյո՞ք ներկայումս առկա է proc_macro API-ի օգտագործման համար անհրաժեշտ ենթակառուցվածքը:
/// Վերադառնում է ճշմարիտ, եթե կանչվում է ընթացակարգային մակրոյի ներսից, կեղծ է, եթե կանչվում է ցանկացած այլ երկուականից:
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Այս տիպի crate-ի կողմից տրամադրված հիմնական տեսակը, որը ներկայացնում է tokens-ի վերացական հոսքը կամ, ավելի կոնկրետ, token ծառերի հաջորդականությունը:
/// Տեսակը տրամադրում է այդ token ծառերի վրա կրկնվող միջերեսներ և, ընդհակառակը, մի շարք token ծառեր մեկ հոսքի մեջ հավաքելու համար:
///
///
/// Սա և՛ `#[proc_macro]`, `#[proc_macro_attribute]` և `#[proc_macro_derive]` սահմանումների մուտքն է և ելքը:
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str`-ից վերադարձված սխալ:
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Վերադարձնում է դատարկ `TokenStream`, որը չի պարունակում token ծառ:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Ստուգում է արդյոք այս `TokenStream`-ը դատարկ է:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Լարը tokens-ի մեջ ճեղքելու և այդ tokens-ի վերլուծելու token հոսքի փորձեր:
/// Կարող է ձախողվել մի շարք պատճառներով, օրինակ, եթե տողը պարունակում է անհավասարակշռված սահմանազատիչներ կամ լեզվով գոյություն չունեցող նիշեր:
///
/// Վերծանված հոսքի բոլոր tokens-ն ստանում է `Span::call_site()` տարածություն:
///
/// NOTE: որոշ սխալներ կարող են առաջացնել panics ՝ `LexError`-ը վերադարձնելու փոխարեն: Մենք մեզ իրավունք ենք վերապահում հետագայում այդ սխալները վերածել `LexError` ի:
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, կամուրջը տրամադրում է միայն `to_string`, դրա հիման վրա իրականացնում է `fmt::Display` (երկուսի սովորական հարաբերությունների հակադարձումը):
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Տպում է token հոսքը որպես տող, որը ենթադրաբար կորուստներով փոխարկվում է նույն token հոսքի (մոդուլի տևողություններ), բացառությամբ `TokenTree: : Group` `Delimiter::None` սահմանաչափերի և բացասական թվային բառերի:
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token-ը տպում է կարգաբերման համար հարմար ձևով:
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Ստեղծում է token հոսք, որը պարունակում է մեկ token մեկ ծառ:
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Հավաքում է մի շարք token ծառեր մեկ հոսքի մեջ:
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening" գործողությունը token հոսքերի վրա, token ծառերը հավաքում է բազմաթիվ token հոսքերից մեկ հոսքի մեջ:
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Օգտագործեք հնարավոր օպտիմիզացված if/when ներդրում:
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` տիպի հանրային իրականացման մանրամասները, ինչպիսիք են կրկնիչները:
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// «TokenStream»-ի «TokenTree`s»-ի կրկնիչ:
    /// Կրկնությունը "shallow" է, օրինակ ՝ կրկնիչը չի վերադառնում սահմանազատված խմբերի և ամբողջ խմբերը վերադարձնում է որպես token ծառեր:
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ընդունում է կամայական tokens և ընդլայնվում է `TokenStream`-ի մեջ ՝ նկարագրելով մուտքը:
/// Օրինակ, `quote!(a + b)`-ը կստեղծի արտահայտություն, որը գնահատելիս կառուցում է `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Արհամարհումն արվում է `$`-ի հետ և աշխատում է վերցնելով հաջորդ հաջորդ նույնականությունը որպես չակերտ մեջբերում:
/// `$`-ը մեջբերելու համար օգտագործեք `$$`:
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Սկզբնաղբյուրի տարածաշրջան ՝ մակրո ընդլայնման տեղեկատվության հետ միասին:
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Տրված `message`-ի հետ ստեղծում է նոր `Diagnostic` `self` տողում:
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Մակրո սահմանման կայքում լուծվող տող:
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Ընթացիկ ընթացակարգային մակրո կոչման տևողությունը:
    /// Այս ժամանակահատվածով ստեղծված նույնացուցիչները կլուծվեն այնպես, կարծես դրանք գրված են ուղղակիորեն մակրո զանգի վայրում (զանգի կայքերի հիգիենա), իսկ մակրո զանգի կայքում տեղադրված այլ ծածկագիրը կկարողանա նաև դրանց վկայակոչել:
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Մի տող, որը ներկայացնում է `macro_rules` հիգիենան, և երբեմն լուծվում է մակրո սահմանման վայրում (տեղական փոփոխականներ, պիտակներ, `$crate`) և երբեմն մակրո զանգերի կայքում (մնացած ամեն ինչ):
    ///
    /// Խմբի գտնվելու վայրը վերցված է զանգի կայքից:
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Սկզբնաղբյուրի ֆայլը, որի վրա նշված է այս տարածությունը:
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span`-ը tokens-ի համար նախորդ մակրո ընդլայնման մեջ, որից ստեղծվել է `self`, եթե այդպիսիք կան:
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Սկզբնաղբյուրի կոդի ժամանակահատվածը, որից ստեղծվել է `self`:
    /// Եթե այս `Span`-ը չի ստեղծվել մակրո այլ ընդլայնումներից, ապա վերադարձի արժեքը նույնն է, ինչ `*self`:
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ստանում է սկզբնական line/column-ը այս տարածքի աղբյուրի ֆայլում:
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Ստանում է line/column ավարտը աղբյուրի ֆայլում այս ժամանակահատվածի համար:
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Ստեղծում է նոր ժամանակահատված ՝ ներառելով `self` և `other`:
    ///
    /// Վերադարձնում է `None`, եթե `self` և `other` տարբեր ֆայլերից են:
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Ստեղծում է նոր ժամանակահատված `նույն line/column տեղեկատվությամբ, ինչ `self`-ը, բայց այն լուծում է խորհրդանիշները, կարծես `other`-ում լիներ:
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Ստեղծում է նոր տարածություն `նույն անվանման լուծման վարքով, ինչպես `self`-ը, բայց `other`-ի line/column տեղեկատվության հետ:
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Համեմատվում է տարածությունների հետ `տեսնելու համար, թե դրանք հավասար են:
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Վերադարձնում է աղբյուրի տեքստը տարածության ետևում:
    /// Սա պահպանում է սկզբնական աղբյուրի կոդը, ներառյալ տարածություններն ու մեկնաբանությունները:
    /// Այն միայն արդյունք է վերադարձնում, եթե տողերը համապատասխանում են իրական աղբյուրին:
    ///
    /// Note: Մակրո-ի դիտելի արդյունքը պետք է ապավինել միայն tokens-ին, այլ ոչ թե այս աղբյուրի տեքստին:
    ///
    /// Այս գործառույթի արդյունքը լավագույն ջանքն է `օգտագործելու միայն ախտորոշման համար:
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Տպում է տարածքը սխալի կարգաբերման համար հարմար ձևով:
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span`-ի սկիզբը կամ ավարտը ներկայացնող գծային սյունների զույգ:
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Աղբյուրի ֆայլում 1 ինդեքսավորված տողը, որի վրա բացումը սկսվում կամ ավարտվում է (inclusive):
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-ինդեքսավորված սյունը (UTF-8 նիշով) սկզբնաղբյուրի ֆայլում, որի տարածքը սկսվում կամ ավարտվում է (inclusive):
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Տվյալ `Span`-ի աղբյուրի ֆայլը:
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ստանում է այս աղբյուրի ֆայլի ուղին:
    ///
    /// ### Note
    /// Եթե այս `SourceFile`-ի հետ կապված ծածկույթի տարածքը գեներացվել է արտաքին մակրոտնտեսության, այս մակրոտնտեսության կողմից, դա չի կարող լինել ֆայլային համակարգի իրական ուղի:
    /// Ստուգելու համար օգտագործեք [`is_real`]:
    ///
    /// Նաև նկատեք, որ նույնիսկ եթե `is_real`-ը վերադարձնում է `true`, եթե `--remap-path-prefix` փոխանցվեց հրամանի տողում, տրված ուղին կարող է իրականում անվավեր լինել:
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Վերադարձնում է `true`, եթե այս աղբյուրի ֆայլը իրական աղբյուր է, և չի ստեղծվել արտաքին մակրոների ընդլայնման արդյունքում:
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Սա կոտրվածք է, քանի դեռ չեն իրականացվել միջկրոտային տողերը, և մենք կարող ենք ունենալ իրական աղբյուրի ֆայլեր արտաքին մակրոներում առաջացած տարածքների համար:
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Մեկ token կամ token ծառերի սահմանազատված հաջորդականություն (օրինակ ՝ `[1, (), ..]`):
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token հոսք, որը շրջապատված է փակագծերի բաժանարարներով:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Նույնացուցիչ:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Միակ կետադրության նիշ («+», `,`, `$` և այլն):
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Բառացի նիշ (`'a'`), տող (`"hello"`), թիվ (`2.3`) և այլն:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Վերադարձնում է այս ծառի տարածքը `պատվիրելով պարունակվող token-ի կամ սահմանազատված հոսքի `span` մեթոդին:
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Կազմաձևում է տևողությունը *միայն այս token*-ի համար:
    ///
    /// Ուշադրություն դարձրեք, որ եթե այս token-ը `Group` է, ապա այս մեթոդը չի կազմաձևի tokens-ի յուրաքանչյուր ներքին տարածքը, սա պարզապես պատվիրելու է յուրաքանչյուր տարբերակի `set_span` եղանակին:
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// token ծառը տպում է կարգաբերման համար հարմար ձևով:
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Սրանցից յուրաքանչյուրը ստացված վրիպակում անունն ունի կառուցվածքային տիպում, այնպես որ մի անհանգստացեք անուղղակիության լրացուցիչ շերտով
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, կամուրջը տրամադրում է միայն `to_string`, դրա հիման վրա իրականացնում է `fmt::Display` (երկուսի սովորական հարաբերությունների հակադարձումը):
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Տպում է token ծառը որպես տող, որը ենթադրաբար կորուստներով փոխարկվում է նույն token ծառի (մոդուլի ընդգրկույթներ), բացառությամբ `« TokenTree: : Group` `Delimiter::None` սահմանաչափերով և բացասական թվային տառերով:
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Սահմանազատված token հոսք:
///
/// `Group`-ն իր մեջ պարունակում է `TokenStream`, որը շրջապատված է `Delimiter-ով:
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Նկարագրում է, թե ինչպես է token ծառերի հաջորդականությունը սահմանազատվում:
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Անուղղակի սահմանազատող, որը, օրինակ, կարող է հայտնվել "macro variable" `$var`-ից եկող tokens-ի շուրջ:
    /// Կարևոր է պահպանել օպերատորի առաջնահերթությունները `$var * 3`-ի նման դեպքերում, երբ `$var`-ը `1 + 2` է:
    /// Անուղղակի սահմանազատողները կարող են գոյատևել token հոսքի հետադարձ տողով լարի միջոցով:
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Տրված բաժանարարով և token հոսքով ստեղծում է նոր `Group`:
    ///
    /// Այս կոնստրուկտորը այս խմբի համար կտա տևողությունը `Span::call_site()`:
    /// Տևողությունը փոխելու համար կարող եք օգտագործել ստորև բերված `set_span` մեթոդը:
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Վերադարձնում է այս `Group`-ի բաժանարարը
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Վերադարձնում է tokens-ի `TokenStream`-ը, որը սահմանազատված է այս `Group`-ում:
    ///
    /// Նշենք, որ վերադարձված token հոսքը չի ներառում վերևում վերադարձված սահմանազատիչը:
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Վերադարձնում է տարածությունը այս token հոսքի բաժանարարների համար `ընդգրկելով ամբողջ `Group`-ը:
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Վերադարձնում է տարածությունը `ցույց տալով այս խմբի բացման սահմանը:
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Վերադարձնում է տարածությունը `ցույց տալով այս խմբի փակման սահմանը:
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Կազմաձևում է տևողությունը այս `Խմբի` բաժանարարների համար, բայց ոչ դրա ներքին tokens-ի:
    ///
    /// Այս մեթոդը **չի** սահմանելու այս խմբի կողմից տարածված բոլոր ներքին tokens-ների տևողությունը, բայց ավելի շուտ այն սահմանելու է tokens սահմանազատիչի տևողությունը `Group` մակարդակի վրա:
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, կամուրջը տրամադրում է միայն `to_string`, դրա հիման վրա իրականացնում է `fmt::Display` (երկուսի սովորական հարաբերությունների հակադարձումը):
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Տպում է խումբը որպես տող, որը պետք է կորուստներով փոխարկվի նույն խմբին (մոդուլի ընդգրկույթները), բացառությամբ `TokenTree: : Group` `Delimiter::None` սահմանազատիչների:
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct`-ը մեկ կետադրության նիշ է, ինչպիսին է `+`, `-` կամ `#`:
///
/// `+=`-ի նման բազմաբնույթ նիշերի օպերատորները ներկայացված են որպես `Punct`-ի երկու դեպք `վերադարձված `Spacing` տարբեր ձևերով:
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Անկախ նրանից, թե `Punct`-ին անմիջապես հաջորդում է մեկ այլ `Punct`, թե հաջորդում է մեկ այլ token կամ սպիտակ տարածք:
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// օրինակ, `+`-ը `Alone` է `+ =`-ում, `+ident`-ում կամ `+()`-ում:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// օրինակ, `+`-ը `Joint` է `+=`-ում կամ `'#`-ում:
    /// Բացի այդ, `'` մեկ գնանշումը կարող է միանալ նույնացուցիչներին ՝ `'ident` կյանքի տևողություններ կազմելու համար:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Տրված բնույթից և տարածությունից ստեղծում է նոր `Punct`:
    /// `ch` փաստարկը պետք է լինի լեզվի կողմից թույլատրված վավեր կետադրության նիշ, հակառակ դեպքում գործառույթը կլինի panic:
    ///
    /// Վերադարձված `Punct`-ը կունենա `Span::call_site()`-ի լռելյայն տևողությունը, որը հետագայում կարող է կազմաձևվել ստորև բերված `set_span` մեթոդով:
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Վերադարձնում է այս կետադրության բնույթի արժեքը որպես `char`:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Վերադարձնում է այս կետադրության նիշի տարածությունը `ցույց տալով, թե արդյոք այն անմիջապես հաջորդում է մեկ այլ `Punct`-ի token հոսքում, այնպես որ դրանք հնարավոր է համատեղել բազմաբնույթ (`Joint`) օպերատորի մեջ, կամ դրան հետևում է որոշ այլ token կամ (`Alone`) սպիտակ տարածք, այնպես որ օպերատորը հաստատ ունի ավարտվեց:
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Վերադարձնում է այս կետադրական բնույթի տողերը:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Կարգավորեք տողերը այս կետադրական բնույթի համար:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, կամուրջը տրամադրում է միայն `to_string`, դրա հիման վրա իրականացնում է `fmt::Display` (երկուսի սովորական հարաբերությունների հակադարձումը):
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Կետադրական նիշը տպում է որպես տող, որը պետք է անվնաս փոխարկվի նույն նիշի:
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Նույնացուցիչ (`ident`):
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Տրված `string`-ի, ինչպես նաև նշված `span`-ի հետ ստեղծում է նոր `Ident`:
    /// `string` փաստարկը պետք է լինի լեզվի կողմից թույլատրված վավեր նույնացուցիչ (ներառյալ հիմնաբառեր, օրինակ ՝ `self` կամ `fn`): Հակառակ դեպքում գործառույթը կլինի panic:
    ///
    /// Նշենք, որ `span`-ը, որը ներկայումս գտնվում է rustc-ում, կարգավորում է այս նույնացուցիչի հիգիենայի տվյալները:
    ///
    /// Այս պահի դրությամբ `Span::call_site()`-ը բացահայտորեն հրաժարվում է "call-site" հիգիենայից, ինչը նշանակում է, որ այս ժամանակահատվածով ստեղծված նույնացուցիչները կլուծվեն այնպես, կարծես դրանք գրված են ուղղակիորեն մակրո զանգի վայրում, և մակրո զանգի կայքի այլ ծածկագիրը կկարողանա վկայակոչել դրանք նույնպես:
    ///
    ///
    /// `Span::def_site()`-ի նման հետագա տարածքները թույլ կտան հրաժարվել "definition-site" հիգիենայից, ինչը նշանակում է, որ այս տողերով ստեղծված նույնացուցիչները կլուծվեն մակրո սահմանման վայրում, իսկ մակրո զանգի կայքում այլ ծածկագիրը չի կարողանա վկայակոչել դրանք:
    ///
    /// Հիգիենայի ներկա կարևորության պատճառով այս կոնստրուկտորը, ի տարբերություն մյուս tokens-ի, պահանջում է `Span`-ի ճշգրտում շինարարության ընթացքում:
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Նույնն է, ինչ `Ident::new`-ը, բայց ստեղծում է հում XIDX նույնացուցիչ:
    /// `string` արգումենտը լինելու է լեզվի կողմից թույլատրված վավեր նույնացուցիչ (ներառյալ հիմնաբառեր, օրինակ ՝ `fn`):
    /// Հիմնաբառեր, որոնք օգտագործելի են ուղու հատվածներում (օրինակ
    /// `self`, `super`) չեն ապահովվում, և կհանգեցնի panic-ի:
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Վերադարձնում է այս `Ident`-ի բացվածքը `ներառելով [`to_string`](Self::to_string)-ի կողմից վերադարձված ամբողջ տողը:
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Կազմաձևում է այս `Ident`-ի տևողությունը, հնարավոր է փոխելով դրա հիգիենայի համատեքստը:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, կամուրջը տրամադրում է միայն `to_string`, դրա հիման վրա իրականացնում է `fmt::Display` (երկուսի սովորական հարաբերությունների հակադարձումը):
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Նույնացուցիչը տպում է որպես տող, որը պետք է կորուստներով փոխարկվի նույն նույնացուցիչի:
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Բառացի տող (`"hello"`), բայթ տող (`b"hello"`), նիշ (`'a'`), բայտ նիշ (`b'a'`), ամբողջ թիվ կամ լողացող կետ թիվ ՝ ածանցով կամ առանց դրան («1», `1u8`, `2.3`, `2.3f32`):
///
/// `true`-ի և `false`-ի նման բուլյան բառակապակցությունները այստեղ չեն պատկանում, դրանք `նույնական են:
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Նշված արժեքով ստեղծում է բառացի նոր վերջածանց բառացի ՝ բառացիորեն:
        ///
        /// Այս ֆունկցիան կստեղծի `1u32`-ի նման մի ամբողջ թիվ, որտեղ նշված ամբողջ թվային արժեքը token-ի առաջին մասն է, իսկ ինտեգրալը նույնպես վերջում ածանցվում է:
        /// Բացասական թվերից ստեղծված տառերը կարող են գոյատևել `TokenStream`-ի կամ տողերի միջոցով կատարված պտույտներով և կարող են բաժանվել երկու tokens (`-` և դրական բառացի):
        ///
        ///
        /// Այս մեթոդի միջոցով ստեղծված տառերը լռելյայնորեն ունեն `Span::call_site()` տող, որը կարող է կազմաձևվել ստորև նշված `set_span` մեթոդի հետ:
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Նշված արժեքով ստեղծում է նոր չսխալված ամբողջ բառացի:
        ///
        /// Այս ֆունկցիան կստեղծի `1`-ի նման մի ամբողջ թիվ, որտեղ նշված ամբողջ թվային արժեքը token-ի առաջին մասն է:
        /// Այս token-ի վրա ոչ մի ածանց նշված չէ, ինչը նշանակում է, որ `Literal::i8_unsuffixed(1)`-ի նման կոչումները համարժեք են `Literal::u32_unsuffixed(1)`-ին:
        /// Բացասական թվերից ստեղծված տառերը կարող են գոյատևել `TokenStream`-ի կամ տողերի միջոցով վերահաշվարկներից և կարող են բաժանվել երկու tokens (`-` և դրական բառացի):
        ///
        ///
        /// Այս մեթոդի միջոցով ստեղծված տառերը լռելյայնորեն ունեն `Span::call_site()` տող, որը կարող է կազմաձևվել ստորև նշված `set_span` մեթոդի հետ:
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Ստեղծում է նոր չսպված լողացող կետ բառացի:
    ///
    /// Այս կոնստրուկտորը նման է նրանց, ինչպիսին է `Literal::i8_unsuffixed`-ը, երբ բոցի արժեքը արտանետվում է ուղղակիորեն token-ի մեջ, բայց չի օգտագործվում որևէ ածանց, ուստի գուցե եզրակացվի, որ կազմողը հետագայում `f64` է:
    ///
    /// Բացասական թվերից ստեղծված տառերը կարող են գոյատևել `TokenStream`-ի կամ տողերի միջոցով վերահաշվարկներից և կարող են բաժանվել երկու tokens (`-` և դրական բառացի):
    ///
    /// # Panics
    ///
    /// Այս գործառույթը պահանջում է, որ նշված բոցը վերջավոր լինի, օրինակ, եթե այն անվերջություն է կամ NaN, այս ֆունկցիան կլինի panic:
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Ստեղծում է նոր վերջածանց լողացող կետ բառացի:
    ///
    /// Այս կոնստրուկտորը կստեղծի բառացի `1.0f32`-ի նման, որտեղ նշված արժեքը token-ի նախորդ մասն է, իսկ `f32`-ը token վերջածանց:
    /// Այս token-ը միշտ եզրակացվելու է, որ կազմողի մեջ `f32` է:
    /// Բացասական թվերից ստեղծված տառերը կարող են գոյատևել `TokenStream`-ի կամ տողերի միջոցով վերահաշվարկներից և կարող են բաժանվել երկու tokens (`-` և դրական բառացի):
    ///
    ///
    /// # Panics
    ///
    /// Այս գործառույթը պահանջում է, որ նշված բոցը վերջավոր լինի, օրինակ, եթե այն անվերջություն է կամ NaN, այս ֆունկցիան կլինի panic:
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Ստեղծում է նոր չսպված լողացող կետ բառացի:
    ///
    /// Այս կոնստրուկտորը նման է նրանց, ինչպիսին է `Literal::i8_unsuffixed`-ը, երբ բոցի արժեքը արտանետվում է ուղղակիորեն token-ի մեջ, բայց չի օգտագործվում որևէ ածանց, ուստի գուցե եզրակացվի, որ կազմողը հետագայում `f64` է:
    ///
    /// Բացասական թվերից ստեղծված տառերը կարող են գոյատևել `TokenStream`-ի կամ տողերի միջոցով վերահաշվարկներից և կարող են բաժանվել երկու tokens (`-` և դրական բառացի):
    ///
    /// # Panics
    ///
    /// Այս գործառույթը պահանջում է, որ նշված բոցը վերջավոր լինի, օրինակ, եթե այն անվերջություն է կամ NaN, այս ֆունկցիան կլինի panic:
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Ստեղծում է նոր վերջածանց լողացող կետ բառացի:
    ///
    /// Այս կոնստրուկտորը կստեղծի բառացի `1.0f64`-ի նման, որտեղ նշված արժեքը token-ի նախորդ մասն է, իսկ `f64`-ը token վերջածանց:
    /// Այս token-ը միշտ եզրակացվելու է, որ կազմողի մեջ `f64` է:
    /// Բացասական թվերից ստեղծված տառերը կարող են գոյատևել `TokenStream`-ի կամ տողերի միջոցով վերահաշվարկներից և կարող են բաժանվել երկու tokens (`-` և դրական բառացի):
    ///
    ///
    /// # Panics
    ///
    /// Այս գործառույթը պահանջում է, որ նշված բոցը վերջավոր լինի, օրինակ, եթե այն անվերջություն է կամ NaN, այս ֆունկցիան կլինի panic:
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Լարը բառացիորեն:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Նիշ բառացի:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Բայտ տողը բառացի է:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Վերադարձնում է այս բառացիքը ներառող տևողությունը:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Կազմաձևում է այս բառի բառի համար ասոցացված տարածությունը:
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Վերադարձնում է `Span`, որը `self.span()` ենթաբազմություն է, որը պարունակում է միայն աղբյուրի բայթ `range` տիրույթում:
    /// Վերադարձնում է `None`-ը, եթե ենթադրելի կտրված տարածքը `self`-ի սահմաններից դուրս է:
    ///
    // FIXME(SergioBenitez): ստուգեք, որ բայտի տիրույթը սկսվում և ավարտվում է աղբյուրի UTF-8 սահմանում:
    // հակառակ դեպքում, հավանական է, որ panic-ն այլ վայրում տեղի ունենա, երբ աղբյուրի տեքստը տպվի:
    // FIXME(SergioBenitez): օգտագործողի համար ոչ մի կերպ չի կարող իմանալ, թե իրականում ինչ է քարտեզագրում `self.span()`-ը, այնպես որ այս մեթոդը ներկայումս կարելի է անվանել միայն կուրորեն:
    // Օրինակ, `to_string()` նիշի համար `to_string()` վերադարձնում է "'\u{63}'";Օգտագործողի համար ոչ մի եղանակ չկա իմանալու ՝ աղբյուրի տեքստը 'c' է, թե '\u{63}':
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned`-ի նման մի բան, բայց `Bound<&T>`-ի համար:
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, կամուրջը տրամադրում է միայն `to_string`, դրա հիման վրա իրականացնում է `fmt::Display` (երկուսի սովորական հարաբերությունների հակադարձումը):
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Տպագրում է բառացիան որպես տող, որը պետք է կորուստներով փոխարկվի նույն բառի մեջ (բացառությամբ լողացող կետի բառերի հնարավոր կլորացման):
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Հետևյալ հասանելիություն շրջակա միջավայրի փոփոխականներին:
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Առբերեք շրջակա միջավայրի փոփոխական և ավելացրեք այն ՝ կախվածության տեղեկատվություն կառուցելու համար:
    /// Կազմողն իրականացնող Build համակարգը կիմանա, որ փոփոխականին մուտք են գործել կազմման ընթացքում, և կկարողանա վերստեղծել կառուցումը, երբ այդ փոփոխականի արժեքը փոխվի:
    ///
    /// Բացի կախվածության հետևմանը, այս գործառույթը պետք է համարժեք լինի ստանդարտ գրադարանից `env::var`-ին, բացառությամբ, որ փաստարկը պետք է լինի UTF-8:
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}