use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Իտերատորի խողովակաշարը Vec-ի մեջ հավաքելու մասնագիտացման նշիչ աղբյուրի հատկացումը վերաօգտագործելու ժամանակ, այսինքն
/// գազատարը տեղում կատարելը:
///
/// SourceIter ծնող trait-ն անհրաժեշտ է մասնագիտացման գործառույթի համար `հատկացումը մուտք գործելու համար, որը պետք է վերաօգտագործվի:
/// Բայց բավարար չէ, որ մասնագիտացումը վավեր լինի:
/// Տեսեք լրացուցիչ սահմանները ենթադրյալի վերաբերյալ:
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-ներքին SourceIter/InPlaceIterable traits-ն իրականացվում են միայն ադապտերի շղթաներով <Adapter<Adapter<IntoIter>>> (բոլորը պատկանում են core/std-ին):
// Ադապտերների իրականացման լրացուցիչ սահմանները (`impl<I: Trait> Trait for Adapter<I>`-ից այն կողմ) կախված են միայն այլ traits-ից, որոնք արդեն նշվել են որպես traits մասնագիտացում (Պատճեն, TrustedRandomAccess, FusedIterator):
//
// I.e. նշիչը կախված չէ օգտագործողի կողմից տրամադրվող տեսակների կյանքի տևողությունից: Modulo Պատճենահանման փոսը, որից արդեն կախված են մի քանի այլ մասնագիտացումներ:
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Լրացուցիչ պահանջներ, որոնք չեն կարող արտահայտվել trait bounds միջոցով: Փոխարենը մենք ապավինում ենք կազմվածքին.
        // ա) ոչ մի ZST, քանի որ չի լինի հատկացում վերաօգտագործման և ցուցիչի թվաբանությունը panic-ի համար. բ) չափի համընկնում, ինչպես պահանջում է Alloc պայմանագիրը, գ) հավասարեցում, ինչպես պահանջում է Alloc պայմանագրով:
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // վերադարձ դեպի ավելի ընդհանուր ներդրումներ
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // օգտագործեք փորձեք
        // - այն ավելի լավ է վեկտորացվում որոշ իտերատոր հարմարեցիչների համար
        // - ի տարբերություն ներքին կրկնության մեթոդների մեծամասնության, այն տանում է միայն &mut ինքնուրույնություն
        // - այն թույլ է տալիս մեզ պտտեցնել գրիչի ցուցիչը իր ներսից և վերջում ստանալ այն
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // կրկնությունը հաջողվեց, գլուխ մի գցիր
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // ստուգեք SourceIter-ի պայմանագիրը պահպանվել է որպես նախազգուշացում. եթե դրանք չլինեին, մենք կարող ենք նույնիսկ չհասցնել այս կետը
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ստուգեք InPlaceIterable պայմանագիրը: Դա հնարավոր է միայն այն դեպքում, երբ կրկնիչը ընդհանրապես առաջ է մղել աղբյուրի ցուցիչը:
        // Եթե այն օգտագործում է չստուգված մուտք TrustedRandomAccess-ի միջոցով, ապա աղբյուրի ցուցիչը կմնա իր նախնական դիրքում, և մենք չենք կարող այն օգտագործել որպես հղում
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // թողեք մնացած արժեքները աղբյուրի պոչում, բայց կանխենք հատկացումների անկումը, երբ IntoIter-ը դուրս գա շրջանակից, եթե panics անկումը, ապա մենք նաև արտահոսում ենք dst_buf-ի մեջ հավաքված ցանկացած տարր
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable պայմանագիրը հնարավոր չէ ճշգրտորեն ստուգել այստեղ, քանի որ try_fold-ը բացառիկ հղում ունի աղբյուրի ցուցիչին, մեզ մնում է միայն ստուգել, արդյոք այն դեռ միջակայքում է
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}