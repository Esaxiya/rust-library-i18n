// Սահմանեք վեկի երկարությունը, երբ `SetLenOnDrop` արժեքը դուրս կգա շրջանակից:
//
// Գաղափարը հետևյալն է. SetLenOnDrop-ի երկարության դաշտը տեղական փոփոխական է, որը կտեսնի օպտիմիզատորը այլևս ոչ մի խանութի հետ Vec-ի տվյալների ցուցիչի միջոցով:
// Սա #32155 կեղծանունի վերլուծության համար լուծում է
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}