use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter-ի համար օգտագործվող մասնագիտացում trait
///
/// ## Պատվիրակության գրաֆիկը.
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ընդհանուր դեպք է vector-ի ֆունկցիայի տեղափոխումը, որն անմիջապես կրկին հավաքվում է vector-ի մեջ:
        // Մենք կարող ենք դա կարճ միացնել, եթե IntoIter-ը ընդհանրապես չի առաջադիմվել:
        // Երբ այն առաջադեմ է, մենք կարող ենք նաև վերաօգտագործել հիշողությունը և տվյալները տեղափոխել ճակատ:
        // Բայց մենք դա անում ենք միայն այն ժամանակ, երբ արդյունքում Vec-ն ավելի շատ չօգտագործված կարողություն ունենա, քան այն ստեղծելու FromIterator-ի ընդհանուր ներդրման միջոցով:
        //
        // Այդ սահմանափակումը խիստ անհրաժեշտ չէ, քանի որ Vec-ի հատկացման վարքագիծը միտումնավորորեն հստակեցված չէ:
        // Բայց դա պահպանողական ընտրություն է:
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // պետք է պատվիրակի spec_extend()-ին, քանի որ extend()-ն ինքը պատվիրում է spec_from-ին դատարկ Vec-ների համար
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Սա օգտագործում է `iterator.as_slice().to_vec()`-ը, քանի որ spec_extend-ը պետք է ավելի շատ քայլեր ձեռնարկի վերջնական հզորության + երկարության մասին տրամաբանելու համար և, այդպիսով, ավելի շատ աշխատանք կատարի:
// `to_vec()` ուղղակիորեն հատկացնում է ճիշտ գումարը և լրացնում այն ճշգրտորեն:
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test)-ի հետ առկա չէ `[T]::to_vec` բնորոշ մեթոդը, որը պահանջվում է այս մեթոդի սահմանման համար, մատչելի չէ:
    // Փոխարենը օգտագործեք `slice::to_vec` գործառույթը, որը հասանելի է միայն cfg(test) NB-ով, տե՛ս slice::hack մոդուլը slice.rs-ում ՝ հավելյալ տեղեկություններ ստանալու համար
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}