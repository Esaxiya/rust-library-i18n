use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Vec::from_iter-ի համար trait-ի մեկ այլ մասնագիտացում, որն անհրաժեշտ է համընկնող մասնագիտությունների ձեռքով առաջնահերթության համար, մանրամասների համար տես [`SpecFromIter`](super::SpecFromIter):
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Բացեք առաջին կրկնությունը, քանի որ vector-ն ընդլայնվելու է այս կրկնության վրա ամեն դեպքում, երբ կրկնվողը դատարկ չէ, բայց extend_desugared()-ի օղակը չի պատրաստվում տեսնել vector-ի ամբողջական լինելը մի քանի հաջորդ օղակի կրկնություններում:
        //
        // Այսպիսով, մենք ստանում ենք ավելի լավ branch կանխատեսում:
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // պետք է պատվիրակի spec_extend()-ին, քանի որ extend()-ն ինքը պատվիրում է spec_from-ին դատարկ Vec-ների համար
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // պետք է պատվիրակի spec_extend()-ին, քանի որ extend()-ն ինքը պատվիրում է spec_from-ին դատարկ Vec-ների համար
        //
        vector.spec_extend(iterator);
        vector
    }
}