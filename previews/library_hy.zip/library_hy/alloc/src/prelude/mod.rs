//! Հատկացումը Prelude
//!
//! Այս մոդուլի նպատակն է մեղմել `alloc` crate-ի սովորաբար օգտագործվող իրերի ներմուծումը ՝ մոդուլների վերևում գլոբալ ներմուծում ավելացնելով.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;