//! Մեկ թելերով տեղեկանք-հաշվիչ ցուցիչներ: 'Rc' նշանակում է «Հղում»
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] տեսակը ապահովում է կույտով բաշխված `T` տիպի արժեքի ընդհանուր սեփականություն:
//! [`Rc`]-ի վրա [`clone`][clone]-ի վրա կանչելը առաջացնում է նոր ցուցիչ կույտի նույն տեղաբաշխման համար:
//! Երբ տվյալ բաշխման վերջին [`Rc`] ցուցիչը ոչնչացվում է, այդ հատկացման մեջ պահվող արժեքը (հաճախ անվանում են "inner value") նույնպես իջնում է:
//!
//! Rust-ի համօգտագործված հղումները լռելյայնորեն արգելում են մուտացիան, և [`Rc`]-ը բացառություն չէ. Ընդհանուր առմամբ չի կարելի փոխել հղում [`Rc`]-ի ինչ-որ բանի վերաբերյալ:
//! Եթե փոփոխականության կարիք ունեք, [`Rc`]-ի ներսում դրեք [`Cell`] կամ [`RefCell`];տես [an example of mutability inside an `Rc`][mutability]:
//!
//! [`Rc`] օգտագործում է ոչ ատոմային տեղեկանքի հաշվարկ:
//! Սա նշանակում է, որ գլխավերևը շատ ցածր է, բայց [`Rc`]-ը հնարավոր չէ ուղարկել թելերի միջև, և հետևաբար [`Rc`]-ը չի իրականացնում [`Send`][send]:
//! Արդյունքում, Rust կազմողը ստուգելու է *կազմման ժամանակ*, որ դուք չեք ուղարկում [«Rc»]-ներ թելերի միջև:
//! Եթե Ձեզ անհրաժեշտ է բազմաշերտ, ատոմային տեղեկանքների հաշվարկ, օգտագործեք [`sync::Arc`][arc]:
//!
//! [`downgrade`][downgrade] մեթոդը կարող է օգտագործվել ոչ սեփականատեր [`Weak`] ցուցիչ ստեղծելու համար:
//! [`Weak`] ցուցիչը կարող է [«արդիականացնել»][արդիականացնել] d [`Rc`]-ով, բայց դա կվերադարձնի [`None`], եթե բաշխման մեջ պահված արժեքն արդեն իջել է:
//! Այլ կերպ ասած, `Weak` ցուցիչները կենդանի չեն պահում բաշխման արժեքը: այնուամենայնիվ, նրանք * պահպանում են հատկացումը (ներքին արժեքի պահուստային խանութը) կենդանի:
//!
//! [`Rc`] ցուցիչների միջեւ ցիկլը երբեք չի բաշխվի:
//! Այդ պատճառով [`Weak`]-ն օգտագործվում է ցիկլերը կոտրելու համար:
//! Օրինակ ՝ ծառը կարող է ունենալ ուժեղ [`Rc`] ցուցիչներ ծնողական հանգույցներից մինչև երեխաներ, և [`Weak`] ցուցիչներ երեխաներից ՝ իրենց ծնողներին:
//!
//! `Rc<T>` ավտոմատ կերպով հետ կանչել `T`-ը ([`Deref`] trait-ի միջոցով), այնպես որ կարող եք զանգահարել «T»-ի մեթոդները [`Rc<T>`][`Rc`] տիպի արժեքի վրա:
//! «T»-ի մեթոդների հետ անունների բախումներից խուսափելու համար [`Rc<T>`][`Rc`]-ի մեթոդներն ինքնին զուգակցված գործառույթներ են, որոնք կոչվում են `օգտագործելով [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Ռկ<T>`Clone`-ի նման traits-ի ներդրումները կարող են նաև կոչվել`օգտագործելով լիովին որակավորված շարահյուսություն:
//! Որոշ մարդիկ նախընտրում են օգտագործել լիովին որակավորված շարահյուսություն, իսկ ոմանք էլ նախընտրում են օգտագործել մեթոդ զանգի շարահյուսություն:
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Մեթոդ-զանգի շարահյուսություն
//! let rc2 = rc.clone();
//! // Լիովին որակավորված շարահյուսություն
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] չի ավտոմատ կերպով վերահեռնում `T`-ին, քանի որ ներքին արժեքը կարող է արդեն իջել:
//!
//! # Կլոնավորման հղումներ
//!
//! Նույն հատկացմանը նոր հղում ստեղծելը, ինչպես առկա հղումով հաշվարկված ցուցիչը, կատարվում է [`Rc<T>`][`Rc`] և [`Weak<T>`][`Weak`]-ի համար ներդրված `Clone` trait-ի միջոցով:
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ստորև ներկայացված երկու շարահյուսությունները համարժեք են:
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a և b երկուսն էլ մատնանշում են հիշողության նույն վայրը, ինչ foo-ն:
//! ```
//!
//! `Rc::clone(&from)` շարահյուսությունը առավել իդիոմատիկ է, քանի որ այն ավելի հստակ է փոխանցում ծածկագրի իմաստը:
//! Վերոնշյալ օրինակում այս շարահյուսությունը ավելի հեշտ է դարձնում տեսնել, որ այս կոդը ստեղծում է նոր հղում, այլ ոչ թե պատճենում է foo-ի ամբողջ բովանդակությունը:
//!
//! # Examples
//!
//! Հաշվի առեք մի սցենար, երբ մի շարք «հարմարանքներ» պատկանում են տվյալ `Owner`-ին:
//! Մենք ուզում ենք ունենալ մեր `Gadget-ի կետը դեպի իրենց `Owner`: Մենք չենք կարող դա անել եզակի սեփականությամբ, քանի որ մեկից ավելի հարմարանքներ կարող են պատկանել նույն `Owner`-ին:
//! [`Rc`] թույլ է տալիս մեզ կիսել `Owner` բազմաթիվ «Գործիքների» միջև և թողնել, որ `Owner`-ը մնա բաշխված այնքան ժամանակ, որքան դրանում կան ցանկացած `Gadget` կետեր:
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... այլ ոլորտներ
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... այլ ոլորտներ
//! }
//!
//! fn main() {
//!     // Ստեղծեք տեղեկանքով հաշվարկված `Owner`:
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Ստեղծեք `հարմարանք` `gadget_owner`-ին պատկանող:
//!     // `Rc<Owner>`-ի կլոնավորումը մեզ տալիս է նոր ցուցիչ նույն `Owner` հատկացմանը, գործընթացում ավելացնելով հղումների քանակը:
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Վերացրեք մեր տեղական `gadget_owner` փոփոխականը:
//!     drop(gadget_owner);
//!
//!     // Չնայած `gadget_owner`-ին գցելուն, մենք դեռ կարող ենք տպել «Gadget's»-ի `Owner`-ի անունը:
//!     // Սա այն պատճառով է, որ մենք թողել ենք միայն մեկ `Rc<Owner>`, այլ ոչ թե այն `Owner`, որի մասին նա մատնանշում է:
//!     // Քանի դեռ կան այլ `Rc<Owner>` մատնանշող նույն `Owner` հատկացում, այն կմնա ուղիղ:
//!     // Դաշտի նախագծումը `gadget1.owner.name` աշխատում է այն պատճառով, որ `Rc<Owner>` ավտոմատ կերպով հետ է մղում `Owner`-ը:
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Գործառույթի ավարտին `gadget1` և `gadget2` ոչնչացվում են, և դրանց հետ միասին վերջին հաշվարկված հղումները մեր `Owner`-ին:
//!     // Gadget Man-ը հիմա նույնպես ոչնչանում է:
//!     //
//! }
//! ```
//!
//! Եթե մեր պահանջները փոխվեն, և մենք նաև պետք է կարողանանք `Owner`-ից `Gadget` անցնել, մենք խնդիրներ կառաջանան:
//! `Owner`-ից `Gadget`-ի [`Rc`] ցուցիչը ներկայացնում է ցիկլ:
//! Սա նշանակում է, որ դրանց հղումների քանակը երբեք չի կարող հասնել 0-ի, և բաշխումը երբեք չի ոչնչացվի.
//! հիշողության արտահոսք: Դրանից շրջանցելու համար մենք կարող ենք օգտագործել [`Weak`] ցուցիչներ:
//!
//! Rust-ն իրականում որոշակիորեն դժվարացնում է նախ և առաջ այս օղակի արտադրությունը: Որպեսզի ավարտվեն միմյանց ուղղված երկու արժեքներ, դրանցից մեկը պետք է փոփոխական լինի:
//! Դա դժվար է, քանի որ [`Rc`]-ը խստորեն պահպանում է հիշողության անվտանգությունը `տարածելով միայն իր կողմից փաթաթված արժեքի ընդհանուր հղումներ, և դրանք թույլ չեն տալիս ուղղակի մուտացիա:
//! Մենք պետք է փաթեթավորենք արժեքի այն մասը, որը ցանկանում ենք մուտացիայի ենթարկել [`RefCell`]-ով, որն ապահովում է *ներքին փոփոխականություն*. Ընդհանուր հղման միջոցով փոփոխականությանը հասնելու մեթոդ:
//! [`RefCell`] գործարկում է Rust-ի փոխառության կանոնները:
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... այլ ոլորտներ
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... այլ ոլորտներ
//! }
//!
//! fn main() {
//!     // Ստեղծեք տեղեկանքով հաշվարկված `Owner`:
//!     // Նշենք, որ մենք տեղադրել ենք «Սեփականատիրոջ» vector-ը `« Գործիքների »`RefCell`-ի ներսում, որպեսզի այն կարողանանք մուտացիայի ենթարկել ընդհանուր տեղեկանքի միջոցով:
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Ստեղծեք `gadget_owner`-ին պատկանող `Գործիք` ինչպես նախկինում:
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Ավելացրեք `Gadget`-ը իրենց `Owner`-ին:
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` դինամիկ փոխառությունն այստեղ ավարտվում է:
//!     }
//!
//!     // Կրկնեք մեր `« Գործիքը »` տպելով դրանց մանրամասները:
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` է:
//!         // Քանի որ `Weak` ցուցիչները չեն կարող երաշխավորել, որ բաշխումը դեռ գոյություն ունի, մենք պետք է զանգահարենք `upgrade`, որը վերադարձնում է `Option<Rc<Gadget>>`:
//!         //
//!         //
//!         // Այս պարագայում մենք գիտենք, որ հատկացումը դեռ գոյություն ունի, ուստի մենք պարզապես `unwrap` `Option`-ն ենք:
//!         // Ավելի բարդ ծրագրում `None` արդյունքի համար ձեզ կարող է անհրաժեշտ լինել սխալների նրբագեղ մշակում:
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Գործառույթի ավարտին `gadget_owner`, `gadget1` և `gadget2` ոչնչացվում են:
//!     // Այժմ հարմարանքների վրա չկա ուժեղ (`Rc`) ցուցիչ, ուստի դրանք ոչնչացվում են:
//!     // Սա զրոացնում է Gadget Man-ի տեղեկանքի հաշիվը, այնպես որ նա նույնպես ոչնչանում է:
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Սա repr(C)-ից future-ի դիմացկուն է հնարավոր դաշտի վերադասավորման դեմ, ինչը խոչընդոտում է այլ կերպ անվտանգ [into|from]_raw() փոփոխական ներքին տեսակների:
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Մեկ թելքով տեղեկանք հաշվիչ ցուցիչ: 'Rc' նշանակում է «Հղում»
/// Counted'.
///
/// Տեսեք [module-level documentation](./index.html)-ը ՝ ավելի մանրամասն:
///
/// `Rc`-ի բնորոշ մեթոդները բոլորը կապված գործառույթներ են, ինչը նշանակում է, որ դուք պետք է դրանք կանչեք, օրինակ, [`Rc::get_mut(&mut value)`][get_mut] `value.get_mut()`-ի փոխարեն:
/// Սա խուսափում է `T` ներքին տիպի մեթոդների հետ բախումներից:
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Այս անապահովությունը կարգին է, քանի որ մինչ այս Rc-ն կենդանի է, մենք երաշխավորված ենք, որ ներքին ցուցիչը վավեր է:
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Կառուցում է նոր `Rc<T>`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Բոլոր ուժեղ ցուցիչները պատկանում են անուղղակի թույլ ցուցիչին, որը երաշխավորում է, որ թույլ կործանիչը երբեք չի ազատի բաշխումը մինչ ուժեղ կործանիչը աշխատում է, նույնիսկ եթե թույլ ցուցիչը պահված է ուժեղի մեջ:
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Կառուցում է նոր `Rc<T>` ՝ օգտագործելով ինքն իրեն թույլ հղում:
    /// Այս ֆունկցիայի վերադարձից առաջ թույլ հղումը թարմացնելու փորձը կհանգեցնի `None` արժեքի:
    ///
    /// Այնուամենայնիվ, թույլ տեղեկանքը կարող է ազատ կլոնավորվել և պահվել ավելի ուշ օգտագործման համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... ավելի շատ ոլորտներ
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ներքինը կառուցեք "uninitialized" վիճակում ՝ մեկ թույլ հղումով:
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Կարևոր է, որ մենք չհրաժարվենք թույլ ցուցիչի սեփականությունից, հակառակ դեպքում հիշողությունը կարող է ազատվել մինչ `data_fn`-ի վերադարձը:
        // Եթե մենք իսկապես ուզում էինք փոխանցել սեփականությունը, ապա կարող էինք ստեղծել մեզ համար թույլ թույլ ցուցիչ, բայց դա կհանգեցներ թույլ տեղեկանքի թույլատրելի հաշվարկի լրացուցիչ թարմացումների, որոնք այլապես կարող էին անհրաժեշտ չլինել:
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Ուժեղ հղումները պետք է հավաքականորեն ունենան ընդհանուր թույլ հղում, այնպես որ մի օգտագործեք քայքայիչը մեր հին թույլ տեղեկանքի համար:
        //
        mem::forget(weak);
        strong
    }

    /// Կառուցում է նոր `Rc` ՝ ոչ սկզբնական բովանդակությամբ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Կառուցում է նոր `Rc` ՝ ոչ սկզբնական բովանդակությամբ, հիշողությունը լցված է `0` բայթով:
    ///
    ///
    /// Տե՛ս [`MaybeUninit::zeroed`][zeroed] ՝ այս մեթոդի ճիշտ և սխալ օգտագործման օրինակների համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Կառուցում է նոր `Rc<T>` ՝ սխալը վերադարձնելով, եթե բաշխումը ձախողվի
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Բոլոր ուժեղ ցուցիչները պատկանում են անուղղակի թույլ ցուցիչին, որը երաշխավորում է, որ թույլ կործանիչը երբեք չի ազատի բաշխումը մինչ ուժեղ կործանիչը աշխատում է, նույնիսկ եթե թույլ ցուցիչը պահված է ուժեղի մեջ:
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Կառուցում է նոր `Rc` ՝ ոչ նախնականացված բովանդակությամբ, եթե բաշխումը ձախողվում է, սխալ է վերադարձնում
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Կառուցում է նոր `Rc` ոչ նախնականացված բովանդակությամբ, հիշողությունը լցվում է `0` բայթով, եթե բաշխումը ձախողվում է, սխալ է վերադարձնում
    ///
    ///
    /// Տե՛ս [`MaybeUninit::zeroed`][zeroed] ՝ այս մեթոդի ճիշտ և սխալ օգտագործման օրինակների համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Կառուցում է նոր `Pin<Rc<T>>`:
    /// Եթե `T`-ը չի իրականացնում `Unpin`, ապա `value`-ը կապվում է հիշողության մեջ և չի կարող տեղափոխվել:
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Վերադարձնում է ներքին արժեքը, եթե `Rc`-ն ունի մեկ ուժեղ հղում:
    ///
    /// Հակառակ դեպքում, [`Err`]-ը վերադարձվում է նույն `Rc`-ով, որը փոխանցվել է:
    ///
    ///
    /// Դա հաջողության կհասնի նույնիսկ եթե կան ակնառու թույլ հղումներ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // պատճենել պարունակվող օբյեկտը

                // Նշեք Թուլություններին, որ դրանք հնարավոր չէ խթանել ուժեղ քանակի նվազեցմամբ, ապա հեռացնել անուղղակի "strong weak" ցուցիչը, միևնույն ժամանակ վարվելով կաթիլային տրամաբանության վրա, պարզապես պատրաստելով կեղծ Թույլ:
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Կառուցում է նոր սկզբնաղբյուրով հաշվարկված հատված ՝ ոչ նախնական բովանդակությամբ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Կառուցում է նոր սկզբնաղբյուրով հաշվարկված հատված ՝ ոչ նախնական բովանդակությամբ, հիշողությունը լցված `0` բայթով:
    ///
    ///
    /// Տե՛ս [`MaybeUninit::zeroed`][zeroed] ՝ այս մեթոդի ճիշտ և սխալ օգտագործման օրինակների համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Փոխակերպվում է `Rc<T>`-ի:
    ///
    /// # Safety
    ///
    /// Ինչպես [`MaybeUninit::assume_init`]-ի դեպքում, զանգահարողը մնում է երաշխավորել, որ ներքին արժեքն իսկապես գտնվում է նախաստորագրված վիճակում:
    ///
    /// Այս մասին զանգելը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է անհապաղ անորոշ վարք:
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Փոխակերպվում է `Rc<[T]>`-ի:
    ///
    /// # Safety
    ///
    /// Ինչպես [`MaybeUninit::assume_init`]-ի դեպքում, զանգահարողը մնում է երաշխավորել, որ ներքին արժեքն իսկապես գտնվում է նախաստորագրված վիճակում:
    ///
    /// Այս մասին զանգելը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է անհապաղ անորոշ վարք:
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Սպառում է `Rc`-ը ՝ վերադարձնելով փաթաթված ցուցիչը:
    ///
    /// Հիշողության արտահոսքից խուսափելու համար ցուցիչը պետք է վերափոխվի `Rc` ՝ օգտագործելով [`Rc::from_raw`][from_raw]:
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Տրամադրում է տվյալների հում ցուցիչ:
    ///
    /// Հաշվարկները ոչ մի կերպ չեն ազդում, և `Rc`-ը չի սպառվում:
    /// Սլաքը վավեր է այնքան ժամանակ, քանի դեռ `Rc`-ում ուժեղ հաշվարկներ կան:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա չի կարող անցնել Deref::deref կամ Rc::inner, քանի որ
        // սա պահանջվում է raw/mut ծագումը պահպանելու համար այնպես, որ օր
        // `get_mut` կարող է գրել ցուցիչի միջոցով Rc-ի `from_raw`-ի վերականգնումից հետո:
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Կառուցում է `Rc<T>` հում ցուցիչից:
    ///
    /// Հում ցուցիչը պետք է նախկինում վերադարձված լիներ [`Rc<U>::into_raw`][into_raw]-ի զանգով, որտեղ `U`-ը պետք է ունենա նույն չափը և հավասարեցումը, ինչպես `T`-ը:
    /// Սա տրիվիալ է, եթե `U`-ը `T` է:
    /// Նկատի ունեցեք, որ եթե `U`-ը `T` չէ, բայց ունի նույն չափը և հավասարեցումը, դա հիմնականում նման է տարբեր տեսակի հղումների փոխակերպմանը:
    /// Տե՛ս [`mem::transmute`][transmute] ՝ հավելյալ տեղեկություններ ստանալու համար, թե ինչ սահմանափակումներ են կիրառվում այս դեպքում:
    ///
    /// `from_raw` օգտագործողը պետք է համոզվի, որ `T`-ի որոշակի արժեքը միայն մեկ անգամ է ընկնում:
    ///
    /// Այս գործառույթն անապահով է, քանի որ ոչ պատշաճ օգտագործումը կարող է հանգեցնել հիշողության անապահովության, նույնիսկ եթե վերադարձված `Rc<T>`-ին երբեք մուտք չեն գործել:
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Վերադարձեք `Rc` ՝ արտահոսքը կանխելու համար:
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Հետագա զանգերը դեպի `Rc::from_raw(x_ptr)` կլինեն հիշողություն անվտանգ:
    /// }
    ///
    /// // Հիշողությունը ազատվեց, երբ `x`-ը դուրս եկավ վերը նշված տիրույթից, ուստի `x_ptr`-ն այժմ կախված է:
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Հակադարձեք օֆսեթը `գտնելու բնօրինակ RcBox-ը:
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Այս բաշխման համար ստեղծում է նոր [`Weak`] ցուցիչ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Համոզվեք, որ մենք չենք ստեղծում կախովի թույլ
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ստանում է այս բաշխման [`Weak`] ցուցիչների քանակը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ստանում է այս տեղաբաշխման ուժեղ (`Rc`) ցուցիչների քանակը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Վերադառնում է `true`, եթե այս բաշխմանը `Rc` կամ [`Weak`] այլ ցուցիչներ չկան:
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Վերադարձնում է փոփոխվող հղումը տվյալ `Rc`-ին, եթե նույն տեղաբաշխման այլ `Rc` կամ [`Weak`] ցուցիչներ չկան:
    ///
    ///
    /// Հակառակ դեպքում վերադարձնում է [`None`], քանի որ ընդհանուր արժեքը փոխելու համար անվտանգ չէ:
    ///
    /// Տես նաև [`make_mut`][make_mut], որը [`clone`][clone] կլինի ներքին արժեքը, երբ կան այլ ցուցիչներ:
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Վերադարձնում է փոփոխվող հղումը տվյալ `Rc`-ին ՝ առանց որևէ ստուգման:
    ///
    /// Տես նաև [`get_mut`], որն անվտանգ է և համապատասխան ստուգումներ է կատարում:
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Նույն հատկացման ցանկացած այլ `Rc` կամ [`Weak`] ցուցիչներ չպետք է վկայակոչվեն վերադարձված վարկի տևողության համար:
    ///
    /// Սա աննշան է, եթե այդպիսի ցուցիչներ գոյություն չունեն, օրինակ ՝ `Rc::new`-ից անմիջապես հետո:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Մենք ուշադիր ենք * չստեղծելու "count" դաշտերը ծածկող տեղեկանք, քանի որ դա հակասում է հղումների քանակի մուտքերին (օրինակ
        // `Weak`-ի կողմից):
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Վերադարձնում է `true`, եթե երկու Rc-ները նշում են միևնույն բաշխումը ([`ptr::eq`]-ի նման երակից):
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Փոփոխական հղում է կատարում տվյալ `Rc`-ին:
    ///
    /// Եթե կան նույն բաշխման այլ `Rc` ցուցիչներ, ապա `make_mut`-ը [`clone`]-ը կտա ներքին նշանակությունը նոր բաշխման `եզակի սեփականություն ապահովելու համար:
    /// Սա նաև անվանվում է գրելու կլոն:
    ///
    /// Եթե այս տեղաբաշխման այլ `Rc` ցուցիչներ չկան, ապա այս հատկացման [`Weak`] ցուցիչները կբաժանվեն:
    ///
    /// Տես նաև [`get_mut`], որը ձախողվելու է և ոչ կլոնավորմամբ:
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ոչինչ չի կլոնավորելու
    /// let mut other_data = Rc::clone(&data);    // Չի կլոնավորելու ներքին տվյալները
    /// *Rc::make_mut(&mut data) += 1;        // Կլոնավորում է ներքին տվյալները
    /// *Rc::make_mut(&mut data) += 1;        // Ոչինչ չի կլոնավորելու
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ոչինչ չի կլոնավորելու
    ///
    /// // Այժմ `data`-ը և `other_data`-ը մատնանշում են տարբեր բաշխումներ:
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ցուցիչները բաժանվելու են.
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta-ն կլոնավորեց տվյալները, կան նաև այլ Rcs:
            // Նախապես հատկացրեք հիշողությունը ՝ կլոնավորված արժեքն ուղղակիորեն գրելու հնարավորություն տալու համար:
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Կարող է պարզապես գողանալ տվյալները, մնում է միայն Թուլություններ
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Հեռացնել անուղղակի ուժեղ-թույլ հղումը (այստեղ կեղծ Թուլություն մշակելու անհրաժեշտություն չկա. Մենք գիտենք, որ այլ թույլ մարդիկ կարող են մաքրել մեզ համար)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Այս անապահովությունը կարգին է, քանի որ մենք երաշխավորված ենք, որ վերադարձված ցուցիչը * ** ցուցիչն է, որը երբևէ կվերադարձվի Տ:
        // Մեր հղումների քանակն այս պահին երաշխավորված է 1, և մենք պահանջեցինք, որ `Rc<T>`-ն ինքը `mut` լինի, այնպես որ մենք վերադարձնում ենք հատկացման միակ հնարավոր հղումը:
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>`-ը բետոնե տիպի իջեցնելու փորձ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Հատկացնում է `RcBox<T>`-ը ՝ բավարար տարածություն ունենալով հնարավոր չափի չհամապատասխանող ներքին արժեքի համար, որտեղ արժեքն ունի տրամադրված դասավորությունը:
    ///
    /// `mem_to_rcbox` գործառույթը կանչվում է տվյալների ցուցիչի հետ և պետք է հետ վերադարձնի (պոտենցիալ ճարպի) ցուցիչ `RcBox<T>`-ի համար:
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Հաշվիր դասավորությունը ՝ օգտագործելով տրված արժեքի դասավորությունը:
        // Նախկինում դասավորությունը հաշվարկվում էր `&*(ptr as* const RcBox<T>)` արտահայտության վրա, բայց դա ստեղծեց սխալ շարված հղում (տես #54908):
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Բաշխում է `RcBox<T>`-ը `բավարար տարածություն հավանական չափի չհամապատասխանող ներքին արժեքի համար, որտեղ արժեքը տրամադրում է դասավորությունը, եթե բաշխումը ձախողվում է, վերադարձնում է սխալ:
    ///
    ///
    /// `mem_to_rcbox` գործառույթը կանչվում է տվյալների ցուցիչի հետ և պետք է հետ վերադարձնի (պոտենցիալ ճարպի) ցուցիչ `RcBox<T>`-ի համար:
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Հաշվիր դասավորությունը ՝ օգտագործելով տրված արժեքի դասավորությունը:
        // Նախկինում դասավորությունը հաշվարկվում էր `&*(ptr as* const RcBox<T>)` արտահայտության վրա, բայց դա ստեղծեց սխալ շարված հղում (տես #54908):
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Հատկացրեք դասավորությունը:
        let ptr = allocate(layout)?;

        // Նախաձեռնեք RcBox-ը
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Հատկացում է `RcBox<T>` ՝ բավարար տարածություն անխափան ներքին արժեքի համար
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Հատկացրեք `RcBox<T>`-ի համար ՝ օգտագործելով տրված արժեքը:
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Պատճենել արժեքը որպես բայթ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Ազատեք հատկացումը ՝ առանց դրա բովանդակությունը գցելու
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Տրված երկարությամբ հատկացնում է `RcBox<[T]>`:
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Պատճենել տարրերը կտորից նոր հատկացված Rc <\[T\]>-ում
    ///
    /// Անվտանգ, քանի որ զանգահարողը կամ պետք է տիրանա սեփականությանը, կամ կապի `T: Copy`-ին
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// `Rc<[T]>`-ը կառուցում է որոշակի չափի հայտնի կրկնիչից:
    ///
    /// Վարքի պահպանումը սահմանված չէ, եթե չափը սխալ լինի:
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Z տարրերը կլոնավորելու ժամանակ Panic պահակ:
        // panic-ի դեպքում նոր RcBox-ում գրված տարրերը կթողարկվեն, ապա հիշողությունը կազատվի:
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Poուցանակ առաջին տարրից
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Ամեն ինչ պարզ է.Մոռացեք պահակին, որպեսզի այն չազատագրի նոր RcBox-ը:
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>`-ի համար օգտագործվող մասնագիտացում trait:
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Նետում է `Rc`-ը:
    ///
    /// Սա կնվազեցնի ուժեղ տեղեկանքի քանակը:
    /// Եթե ուժեղ հղումների քանակը հասնում է զրոյի, ապա միակ այլ հղումները (եթե այդպիսիք կան) [`Weak`] են, ուստի մենք `drop` ներքին արժեքը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ոչինչ չի տպում
    /// drop(foo2);   // Տպում է "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ոչնչացնել պարունակվող օբյեկտը
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // հեռացրեք անուղղակի "strong weak" ցուցիչը հիմա, երբ մենք ոչնչացրել ենք բովանդակությունը:
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Կատարում է `Rc` ցուցիչի կլոն:
    ///
    /// Սա ստեղծում է նույն բաշխման մեկ այլ ցուցիչ ՝ ավելացնելով ուժեղ տեղեկանքի քանակը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Ստեղծում է նոր `Rc<T>` ՝ `T`-ի համար `Default` արժեքով:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack-ը թույլ է տալիս մասնագիտանալ `Eq`-ի վրա, չնայած որ `Eq`-ն ունի մեթոդ:
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Մենք այս մասնագիտացումը կատարում ենք այստեղ, և ոչ թե որպես ավելի ընդհանուր օպտիմալացում `&T`-ի վրա, քանի որ այն այլ կերպ ծախսեր կավելացնի refs-ների հավասարության բոլոր ստուգումներին:
/// Ենթադրում ենք, որ `Rc-ն օգտագործվում է մեծ արժեքներ պահելու համար, որոնք դանդաղ են կլոնավորվում, բայց նաև ծանր են հավասարությունը ստուգելու համար` պատճառաբանելով, որ այդ ծախսն ավելի հեշտ է մարել:
///
/// Հավանական է նաև, որ երկու `Rc` կլոն ունենան, որոնք նույն արժեքն են նշում, քան երկու `&T`:
///
/// Մենք դա կարող ենք անել միայն այն դեպքում, երբ `T: Eq`-ը որպես `PartialEq` կարող է միտումնավոր անթափանցիկ լինել:
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Հավասարություն երկու `Rc-ի համար:
    ///
    /// Երկու `Rc` հավասար են, եթե նրանց ներքին արժեքները հավասար են, նույնիսկ եթե դրանք պահվում են տարբեր բաշխման մեջ:
    ///
    /// Եթե `T`-ը իրականացնում է նաև `Eq` (հավասարության ռեֆլեկտիվություն ենթադրող), ապա երկու `Rc, որոնք նշում են նույն բաշխումը, միշտ հավասար են:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Անհավասարություն երկու `Rc-ի համար:
    ///
    /// Երկու `Rc` անհավասար են, եթե նրանց ներքին արժեքները անհավասար են:
    ///
    /// Եթե `T`-ը իրականացնում է նաև `Eq` (հավասարության ռեֆլեկտիվություն ենթադրող), ապա երկու `Rc, որոնք նշում են նույն բաշխումը, երբեք անհավասար են:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Մասնակի համեմատություն երկու `Rc-ի համար:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `partial_cmp()` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ավելի քիչ, քան համեմատություն երկու `Rc-ի համար:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `<` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Երկու «Rc»-ի համեմատությունը «պակաս է կամ հավասար»:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `<=` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Ավելի մեծ, քան համեմատությունը երկու `Rc-ի համար:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `>` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Երկուից ավելի Rc-ի 'ավելի մեծ կամ հավասար' համեմատություն:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `>=` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Համեմատություն երկու `Rc-ի համար:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `cmp()` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Բաշխեք տեղեկանքով հաշվարկված կտոր և լրացրեք այն `կլոնավորելով« v »կետերը:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Հատկացրեք տեղեկանքով հաշվարկված տողի կտորը և պատճենեք `v`-ը դրա մեջ:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Հատկացրեք տեղեկանքով հաշվարկված տողի կտորը և պատճենեք `v`-ը դրա մեջ:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Տեղափոխեք տուփերով առարկան նոր, տեղեկանքով հաշվարկված, բաշխման:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Բաշխեք տեղեկանքով հաշվարկված հատված և տեղափոխեք «v»-ի իրերը դրա մեջ:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Թույլ տվեք Vec-ին ազատել իր հիշողությունը, բայց ոչնչացնել դրա պարունակությունը
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Վերցնում է յուրաքանչյուր տարր `Iterator`-ում և հավաքում այն `Rc<[T]>`-ի մեջ:
    ///
    /// # Կատարման բնութագրերը
    ///
    /// ## Ընդհանուր գործը
    ///
    /// Ընդհանուր դեպքում, `Rc<[T]>`-ի մեջ հավաքումը կատարվում է նախ `հավաքելով `Vec<T>`-ի մեջ: Այսինքն ՝ հետևյալը գրելիս.
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// սա իրեն պահում է այնպես, կարծես գրել ենք.
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Հատկացումների առաջին փաթեթը տեղի է ունենում այստեղ:
    ///     .into(); // `Rc<[T]>`-ի երկրորդ հատկացումը տեղի է ունենում այստեղ:
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Սա հատկացնելու է այնքան անգամ, որքան անհրաժեշտ է `Vec<T>`-ի կառուցման համար, իսկ հետո այն հատկացվելու է մեկ անգամ `Vec<T>`-ը `Rc<[T]>`-ի վերածելու համար:
    ///
    ///
    /// ## Հայտնի երկարության կրկնիչներ
    ///
    /// Երբ ձեր `Iterator`-ն իրականացնում է `TrustedLen`-ը և ունի ճշգրիտ չափսեր, `Rc<[T]>`-ի համար մեկ հատկացում կկատարվի: Օրինակ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Պարզապես այստեղ կատարվում է մեկ հատկացում:
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// trait մասնագիտացումը, որն օգտագործվում է `Rc<[T]>`-ում հավաքելու համար:
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Այս դեպքը `TrustedLen` կրկնիչի դեպքում է:
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պետք է համոզվենք, որ կրկնիչը ունի ճշգրիտ երկարություն, և մենք ունենք:
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Վերադառնանք բնականոն իրականացմանը:
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`]-ի մի տարբերակ է, որը պահպանում է կառավարվող բաշխումը ոչ սեփականատեր: Հատկացումը հասանելի է [`upgrade`] `Weak` ցուցիչի վրա զանգահարելով, որը վերադարձնում է ["Տարբերակ"] "<" ["Rc"]<T>> "
///
/// Քանի որ `Weak` տեղեկանքը չի համարվում սեփականության իրավունքը, դա չի խանգարի հատկացման մեջ պահված արժեքի իջեցմանը, և `Weak`-ը ինքը երաշխիքներ չի տալիս այն արժեքի վերաբերյալ, որը դեռ առկա է:
/// Այսպիսով, այն կարող է վերադարձնել [`None`], երբ [«արդիականացնել»] դ.
/// Այնուամենայնիվ, նշեք, որ `Weak` հղումը *չի* թույլ տալիս բաշխումը (պահուստային խանութը) տեղաբաշխել:
///
/// `Weak` ցուցիչը օգտակար է [`Rc`]-ի կողմից կառավարվող հատկացմանը ժամանակավոր տեղեկանք պահելու համար `առանց կանխելու դրա ներքին արժեքի անկումը:
/// Այն նաև օգտագործվում է կանխելու [`Rc`] ցուցիչների շրջանաձև հղումները, քանի որ փոխադարձ սեփականության հղումները երբեք թույլ չեն տա որևէ [`Rc`] իջնել:
/// Օրինակ ՝ ծառը կարող է ունենալ ուժեղ [`Rc`] ցուցիչներ ծնողական հանգույցներից մինչև երեխաներ, և `Weak` ցուցիչներ երեխաներից ՝ իրենց ծնողներին:
///
/// `Weak` ցուցիչ ձեռք բերելու բնորոշ եղանակը [`Rc::downgrade`] զանգահարելն է:
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Սա `NonNull` է ՝ թույլ տալու համար այս տեսակի չափերը օպտիմալացնել հաշվարկներում, բայց պարտադիր չէ, որ այն վավեր ցուցիչ լինի:
    //
    // `Weak::new` սա սահմանում է `usize::MAX`, այնպես, որ անհրաժեշտ լինի կույտի վրա տարածք հատկացնել:
    // Դա արժեք չէ, որ իսկական ցուցիչը երբևէ ունենա, քանի որ RcBox-ն ունի հավասարեցում առնվազն 2-ի:
    // Դա հնարավոր է միայն այն դեպքում, երբ `T: Sized`;մեծ չափսի `T`-ը երբեք չի կախվում:
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Կառուցում է նոր `Weak<T>` ՝ առանց որևէ հիշողություն հատկացնելու:
    /// Վերադարձի արժեքով [`upgrade`] զանգելը միշտ տալիս է [`None`]:
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Օգնականի տեսակը `թույլ տալով մուտք գործել հղումների հաշվարկներ` առանց տվյալների դաշտի վերաբերյալ որևէ պնդում կատարելու:
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Վերադառնում է հում ցուցիչ այս `Weak<T>`-ի կողմից մատնանշված `T` օբյեկտին:
    ///
    /// Սլաքը վավեր է միայն այն դեպքում, եթե կան մի քանի ուժեղ հղումներ:
    /// Հակառակ դեպքում ցուցիչը կարող է կախվել, չհարված լինել կամ նույնիսկ [`null`]:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Երկուսն էլ մատնանշում են նույն օբյեկտը
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Այստեղ ուժեղը այն կենդանի է պահում, ուստի մենք դեռ կարող ենք մուտք գործել օբյեկտ:
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Բայց ոչ ավելին:
    /// // Մենք կարող ենք անել weak.as_ptr(), բայց ցուցիչ մուտք գործելը կհանգեցնի չսահմանված վարքի:
    /// // assert_eq! («բարև», անապահով {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Եթե ցուցիչը կախված է, մենք պահակախումբը ուղիղ վերադարձնում ենք:
            // Սա չի կարող վավեր բեռի հասցե լինել, քանի որ բեռի բեռը հավասարեցված է առնվազն RcBox (usize)-ին:
            ptr as *const T
        } else {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Եթե is_dangling-ը կեղծ է վերադառնում, ապա ցուցիչը դյուրագրվող է:
            // Այս պահին բեռը կարող է իջնել, և մենք պետք է պահպանենք ծագումը, այնպես որ օգտագործեք ցուցիչի հում մանիպուլյացիա:
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Սպառում է `Weak<T>`-ը և այն վերածում հում ցուցիչի:
    ///
    /// Սա թույլ ցուցիչը վերածում է հում ցուցիչի, մինչդեռ դեռ պահպանում է մեկ թույլ տեղեկանքի պատկանելությունը (թույլ գործողությունը չի փոխվում այս գործողության միջոցով):
    /// Այն կարելի է վերափոխել `Weak<T>`-ի [`from_raw`]-ով:
    ///
    /// Theուցանիշի թիրախին հասանելիության նույն սահմանափակումները, ինչ [`as_ptr`]-ի դեպքում, կիրառվում են:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`]-ի կողմից նախկինում ստեղծված հում ցուցիչը վերափոխում է `Weak<T>`-ի:
    ///
    /// Սա կարող է օգտագործվել ուժեղ հղում ապահով ստանալու համար (ավելի ուշ զանգահարելով [`upgrade`]) կամ թույլ թվաքանակը տեղաբաշխել ՝ թողնելով `Weak<T>`:
    ///
    /// Այն տանում է մեկ թույլ տեղեկանքի սեփականություն (բացառությամբ [`new`]-ի կողմից ստեղծված ցուցիչների, քանի որ դրանք ոչ մի բանի չեն տիրապետում. Մեթոդը մինչ այժմ գործում է դրանց վրա):
    ///
    /// # Safety
    ///
    /// Սլաքը պետք է որ առաջացած լիներ [`into_raw`]-ից և դեռ պետք է տիրապետեր իր հավանական թույլ տեղեկանքին:
    ///
    /// Թույլատրվում է, որ ուժեղ զանգը 0 լինի սա կանչելու պահին:
    /// Այնուամենայնիվ, սա տիրապետում է մեկ թույլ տեղեկանքի, որը ներկայումս ներկայացված է որպես հում ցուցիչ (թույլ գործողությունը չի փոփոխվում այս գործողության միջոցով) և, հետևաբար, այն պետք է զուգակցվի [`into_raw`]-ի նախորդ զանգի հետ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Նվազեցնել վերջին թույլ հաշվարկը:
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Տե՛ս Weak::as_ptr ՝ համատեքստում, թե ինչպես է ստացվում մուտքային ցուցիչը:

        let ptr = if is_dangling(ptr as *mut T) {
            // Սա կախովի թույլ է:
            ptr as *mut RcBox<T>
        } else {
            // Հակառակ դեպքում, մենք երաշխավորված ենք, որ ցուցիչը եկել է անհանգիստ Թուլից:
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Data_offset-ը անվտանգ է զանգահարելու համար, քանի որ ptr հղումները իրական (պոտենցիալ անկված) T են:
            let offset = unsafe { data_offset(ptr) };
            // Այսպիսով, մենք հակադարձում ենք օֆսեթը `ամբողջ RcBox-ը ստանալու համար:
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ցուցիչը առաջացել է Թույլից, ուստի այս փոխհատուցումն անվտանգ է:
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք այժմ վերականգնել ենք բնօրինակ Թույլ ցուցիչը, այնպես որ կարող ենք ստեղծել Թույլ:
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` ցուցիչը [`Rc`]-ով արդիականացնելու փորձեր ՝ հաջողության դեպքում հետաձգելով ներքին արժեքի անկումը:
    ///
    ///
    /// Վերադարձնում է [`None`], եթե ներքին արժեքը իջել է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ոչնչացրեք բոլոր ուժեղ ցուցիչները:
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ստանում է ուժեղ տեղակայման (`Rc`) ցուցիչների քանակը, որը մատնանշում է այս բաշխումը:
    ///
    /// Եթե `self`-ը ստեղծվել է [`Weak::new`]-ի միջոցով, դա կվերադարձնի 0:
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ստանում է այս բաշխումը մատնանշող `Weak` ցուցիչների քանակը:
    ///
    /// Եթե ուժեղ ցուցիչներ չմնան, սա կվերադարձնի զրոյի:
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // հանել անուղղակի թույլ ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Վերադարձնում է `None`, երբ ցուցիչը կախված է, և չկա հատկացված `RcBox`, (այսինքն, երբ այս `Weak`-ը ստեղծվել է `Weak::new`-ի կողմից):
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Մենք ուշադիր ենք * չստեղծելու "data" դաշտը ծածկող տեղեկանք, քանի որ դաշտը միաժամանակ կարող է մուտացիայի ենթարկվել (օրինակ, եթե վերջին `Rc`-ն ընկնի, տվյալների դաշտը տեղում կգցվի):
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Վերադարձնում է `true`, եթե երկու «Թույլ» կետերը մատնանշում են նույն բաշխումը (նման է [`ptr::eq`]-ին), կամ եթե երկուսն էլ չեն նշում որևէ բաշխում (քանի որ դրանք ստեղծվել են `Weak::new()`)-ով):
    ///
    ///
    /// # Notes
    ///
    /// Քանի որ սա համեմատում է ցուցիչները, դա նշանակում է, որ `Weak::new()`-ը հավասար կլինի միմյանց, չնայած որ դրանք չեն նշում որևէ բաշխման:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Համեմատելով `Weak::new`-ը:
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Նետում է `Weak` ցուցիչը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ոչինչ չի տպում
    /// drop(foo);        // Տպում է "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // թույլ հաշվարկը սկսվում է 1-ից, և զրոյի կհասնի միայն այն դեպքում, եթե բոլոր ուժեղ ցուցիչները անհետանան:
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Կատարում է `Weak` ցուցիչի կլոն, որը մատնանշում է նույն բաշխումը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Կառուցում է նոր `Weak<T>` ՝ հատկացնելով հիշողություն `T`-ի համար ՝ առանց դրա նախաստորագրման:
    /// Վերադարձի արժեքով [`upgrade`] զանգելը միշտ տալիս է [`None`]:
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Մենք ստուգեցինք_ավելացնել այստեղ mem::forget-ով անվտանգ գործ ունենալու համար: Մասնավորապես
// եթե դուք ունեք mem::forget Rc (կամ թույլ կողմեր), վերահաշվարկը կարող է լցվել, և այնուհետև կարող եք ազատել հատկացումը, մինչ գոյություն ունեն չմարված Rcs (կամ թույլ կողմեր):
//
// Մենք վիժեցնում ենք, քանի որ սա այնքան այլասերված սցենար է, որ մեզ չի հետաքրքրում կատարվածը. Ոչ մի իրական ծրագիր դա երբեք չպետք է զգա:
//
// Սա պետք է ունենա աննշան գլխավերև, քանի որ իրականում ձեզ հարկավոր չէ այդքան կլոնավորել Rust-ում ՝ սեփականության և տեղափոխման իմաստաբանության շնորհիվ:
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Մենք ուզում ենք վիժեցնել ջրհեղեղի վրա `արժեքը գցելու փոխարեն:
        // Երբ կանչվի, հղումների քանակը երբեք չի զրո:
        // այնուամենայնիվ, մենք այստեղ ընդհատում ենք տեղադրում ՝ LLVM-ին այլապես բաց թողնված օպտիմալացման մասին ակնարկելու համար:
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Մենք ուզում ենք վիժեցնել ջրհեղեղի վրա `արժեքը գցելու փոխարեն:
        // Երբ կանչվի, հղումների քանակը երբեք չի զրո:
        // այնուամենայնիվ, մենք այստեղ ընդհատում ենք տեղադրում ՝ LLVM-ին այլապես բաց թողնված օպտիմալացման մասին ակնարկելու համար:
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Ստացեք փոխհատուցում `RcBox`-ի սահմաններում ՝ ցուցիչի ետևում գտնվող ծանրաբեռնվածության համար:
///
/// # Safety
///
/// Սլաքը պետք է մատնանշի (և ունենա վավեր մետատվյալներ) T-ի նախկինում վավեր օրինակի, բայց T-ն թույլատրվում է թողնել:
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Անխափան արժեքը հավասարեցրեք RcBox-ի ավարտին:
    // Քանի որ RcBox-ը repr(C) է, այն միշտ հիշողության մեջ կլինի վերջին դաշտը:
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Քանի որ միակ չնչին տեսակները հնարավոր են կտորները, trait օբյեկտները,
    // և արտաքին տեսակների, մուտքային անվտանգության պահանջը ներկայումս բավարար է ՝ գրաֆիկի_վ_ազարդի պահանջները բավարարելու համար.սա լեզվի իրականացման մանրամասնություն է, որը հնարավոր չէ ապավինել std-ից դուրս:
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}