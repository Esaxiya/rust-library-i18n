//! Կրկնակի կապակցված ցուցակ `պատկանող հանգույցներով:
//!
//! `LinkedList`-ը թույլ է տալիս որևէ վերջում տարրերը մղել և դուրս գալ մշտական ժամանակում:
//!
//! NOTE: Գրեթե միշտ ավելի լավ է օգտագործել [`Vec`] կամ [`VecDeque`], քանի որ զանգվածի վրա հիմնված բեռնարկղերն ընդհանուր առմամբ ավելի արագ են, ավելի արդյունավետ են հիշողությամբ և ավելի լավ են օգտագործում պրոցեսորի քեշը:
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Կրկնակի կապակցված ցուցակ `պատկանող հանգույցներով:
///
/// `LinkedList`-ը թույլ է տալիս որևէ վերջում տարրերը մղել և դուրս գալ մշտական ժամանակում:
///
/// NOTE: Գրեթե միշտ ավելի լավ է օգտագործել `Vec` կամ `VecDeque`, քանի որ զանգվածի վրա հիմնված բեռնարկղերն ընդհանուր առմամբ ավելի արագ են, ավելի արդյունավետ են հիշողությամբ և ավելի լավ են օգտագործում պրոցեսորի քեշը:
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Կրկնիչ `LinkedList`-ի տարրերի վրա:
///
/// Այս `struct`-ը ստեղծվել է [`LinkedList::iter()`]-ի կողմից:
/// Տեսեք դրա փաստաթղթերը ավելին:
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Հեռացրեք հօգուտ `#[derive(Clone)]`-ի
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Փոփոխական կրկնիչ `LinkedList`-ի տարրերի նկատմամբ:
///
/// Այս `struct`-ը ստեղծվել է [`LinkedList::iter_mut()`]-ի կողմից:
/// Տեսեք դրա փաստաթղթերը ավելին:
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Մենք այստեղ * բացառապես չենք տիրապետում ամբողջ ցուցակին, հանգույցի `element`-ին հղումները տարածվել են կրկնիչի կողմից: Ուստի զգույշ եղեք սա օգտագործելիս;կոչված մեթոդները պետք է տեղյակ լինեն, որ կարող են լինել `element`-ի այլընտրանքային ցուցիչներ:
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// `LinkedList`-ի տարրերի նկատմամբ սեփական կրկնօրինակը:
///
/// Այս `struct`-ը ստեղծվում է [`into_iter`] մեթոդով [`LinkedList`]-ի վրա (տրամադրված է `IntoIterator` trait-ի կողմից):
/// Տեսեք դրա փաստաթղթերը ավելին:
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// մասնավոր մեթոդներ
impl<T> LinkedList<T> {
    /// Theուցակի առջևում ավելացնում է տրված հանգույցը:
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Այս մեթոդը հոգ է տանում, որ չստեղծվեն փոփոխական հղումներ ամբողջ հանգույցներին, պահպանվի `element`-ի այլընտրանքային ցուցիչների վավերությունը:
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Չստեղծել նոր փոփոխվող (unique!) հղումներ, որոնք համընկնում են `element`-ի հետ:
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Հեռացնում և վերադարձնում է հանգույցը ցուցակի առջևում:
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Այս մեթոդը հոգ է տանում, որ չստեղծվեն փոփոխական հղումներ ամբողջ հանգույցներին, պահպանվի `element`-ի այլընտրանքային ցուցիչների վավերությունը:
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Չստեղծել նոր փոփոխվող (unique!) հղումներ, որոնք համընկնում են `element`-ի հետ:
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Տրված հանգույցը ավելացնում է ցուցակի հետևում:
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Այս մեթոդը հոգ է տանում, որ չստեղծվեն փոփոխական հղումներ ամբողջ հանգույցներին, պահպանվի `element`-ի այլընտրանքային ցուցիչների վավերությունը:
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Չստեղծել նոր փոփոխվող (unique!) հղումներ, որոնք համընկնում են `element`-ի հետ:
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Հեռացնում և վերադարձնում է ցուցակի հետևում գտնվող հանգույցը:
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Այս մեթոդը հոգ է տանում, որ չստեղծվեն փոփոխական հղումներ ամբողջ հանգույցներին, պահպանվի `element`-ի այլընտրանքային ցուցիչների վավերությունը:
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Չստեղծել նոր փոփոխվող (unique!) հղումներ, որոնք համընկնում են `element`-ի հետ:
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Ընթացիկ ցուցակից ապակցում է նշված հանգույցը:
    ///
    /// Arnգուշացում. Սա չի ստուգելու, որ տրամադրված հանգույցը պատկանում է ընթացիկ ցուցակին:
    ///
    /// Այս մեթոդը հոգ է տանում `element`-ի փոփոխական հղումներ չստեղծելու, այլընտրանքային ցուցիչների վավերությունը պահպանելու համար:
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // սա հիմա մերն է, մենք կարող ենք ստեղծել &mut:

        // Չստեղծել նոր փոփոխվող (unique!) հղումներ, որոնք համընկնում են `element`-ի հետ:
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // այս հանգույցը գլխի հանգույցն է
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // այս հանգույցը պոչային հանգույցն է
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Երկու գոյություն ունեցող հանգույցների միջով միացնում է մի շարք հանգույցներ:
    ///
    /// Arnգուշացում. Սա չի ստուգելու, որ տրամադրված հանգույցը պատկանում է գոյություն ունեցող երկու ցուցակներին:
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Այս մեթոդը հոգ է տանում միաժամանակ չստեղծել բազմաթիվ փոփոխական հղումներ ամբողջ հանգույցներին, պահպանել `element`-ի այլընտրանքային ցուցիչների վավերությունը:
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Բոլոր հանգույցները բաժանվում են կապված ցուցակից որպես հանգույցների շարք:
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Պառակտված հանգույցը երկրորդ մասի նոր գլխի հանգույցն է
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Ուղղեք երկրորդ մասի գլուխը ptr
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Պառակտված հանգույցը առաջին մասի նոր պոչային հանգույցն է և պատկանում է երկրորդ մասի գլխին:
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Ուղղեք առաջին մասի պոչը
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Ստեղծում է դատարկ `LinkedList<T>`:
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Ստեղծում է դատարկ `LinkedList`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Բոլոր տարրերը `other`-ից տեղափոխում է ցուցակի վերջ:
    ///
    /// Սա վերօգտագործում է բոլոր հանգույցները `other`-ից և տեղափոխում դրանք `self`:
    /// Այս գործողությունից հետո `other`-ը դատարկվում է:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(1) ժամանակ և *O*(1) հիշողության մեջ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` այստեղ նորմալ է, քանի որ մենք բացառիկ մուտք ունենք երկու ցուցակների ամբողջության վրա:
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Բոլոր տարրերը `other`-ից տեղափոխում է ցուցակի սկիզբ:
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` այստեղ նորմալ է, քանի որ մենք բացառիկ մուտք ունենք երկու ցուցակների ամբողջության վրա:
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Ապահովում է փոխանցման կրկնիչ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Ապահովում է փոխանցվող կրկնօրինակը փոփոխական հղումներով:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Theակատային տարրի կուրսորը ապահովում է:
    ///
    /// Կուրսորը ցույց է տալիս "ghost" ոչ տարրը, եթե ցուցակը դատարկ է:
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Կուրսորը ապահովում է առջևի տարրի խմբագրման գործողություններով:
    ///
    /// Կուրսորը ցույց է տալիս "ghost" ոչ տարրը, եթե ցուցակը դատարկ է:
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Հետևի տարրի կուրսորը ապահովում է:
    ///
    /// Կուրսորը ցույց է տալիս "ghost" ոչ տարրը, եթե ցուցակը դատարկ է:
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Կուրսորը ապահովում է հետին տարրի խմբագրման գործողություններով:
    ///
    /// Կուրսորը ցույց է տալիս "ghost" ոչ տարրը, եթե ցուցակը դատարկ է:
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Վերադարձնում է `true`, եթե `LinkedList`-ը դատարկ է:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(1) ժամանակում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Վերադարձնում է `LinkedList`-ի երկարությունը:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(1) ժամանակում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Հեռացնում է բոլոր տարրերը `LinkedList`-ից:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(*n*) ժամանակում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Վերադարձնում է `true`, եթե `LinkedList` պարունակում է տվյալ արժեքին հավասար տարր:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Հղում է տալիս դիմային տարրին կամ `None`-ին, եթե ցուցակը դատարկ է:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Ապահովում է փոփոխական հղում առջևի տարրի կամ `None`-ի, եթե ցուցակը դատարկ է:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Հղում է տալիս հետին տարրի կամ `None`-ին, եթե ցուցակը դատարկ է:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Ապահովում է անփոփոխ հղում հետևի տարրին կամ `None`-ին, եթե ցուցակը դատարկ է:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Firstուցակում նախ տարր է ավելացնում:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(1) ժամանակում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Հեռացնում է առաջին տարրը և վերադարձնում այն, կամ `None`, եթե ցուցակը դատարկ է:
    ///
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(1) ժամանակում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Elementանկի հետևում մի տարր է կցվում:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(1) ժամանակում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Elementուցակից հանում է վերջին տարրը և վերադարձնում այն, կամ `None`, եթե այն դատարկ է:
    ///
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(1) ժամանակում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Տվյալ ինդեքսում ցուցակը բաժանվում է երկու մասի:
    /// Վերադարձնում է ամեն ինչ տվյալ ցուցանիշից հետո, ներառյալ ինդեքսը:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(*n*) ժամանակում:
    ///
    /// # Panics
    ///
    /// Panics եթե `at > len`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Ստորև մենք կրկնում ենք դեպի «i-1» հանգույցը ՝ սկզբից կամ վերջից, կախված նրանից, թե որն է ավելի արագ:
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip()-ի (ինչը նոր կառուցվածք է ստեղծում) օգտագործումը բաց թողնելու փոխարեն, մենք ձեռքով բաց ենք թողնում, որպեսզի կարողանանք մուտք գործել գլխի դաշտ ՝ առանց կախված
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // ավելի լավ է սկսել վերջից
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Հեռացնում է տվյալ ցուցանիշի տարրը և վերադարձնում այն:
    ///
    /// Այս գործողությունը պետք է հաշվարկի *O*(*n*) ժամանակում:
    ///
    /// # Panics
    /// Panics եթե>=len-ում է
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Ստորև, մենք կրկնում ենք տվյալ ցուցանիշի հանգույցը ՝ սկզբից կամ վերջից, կախված նրանից, թե որն է ավելի արագ:
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Ստեղծում է կրկնիչ, որն օգտագործում է փակումը ՝ որոշելու համար, թե արդյոք տարրը պետք է հեռացվի:
    ///
    /// Եթե փակումը վերադառնա ճիշտ, ապա տարրը հանվում և զիջվում է:
    /// Եթե փակումը կեղծ վերադառնա, տարրը կմնա ցուցակում և չի կրկնվի կրկնիչի կողմից:
    ///
    /// Նկատի ունեցեք, որ `drain_filter`-ը հնարավորություն է տալիս մուտացիայի ենթարկելու զտիչի փակման յուրաքանչյուր տարր `անկախ այն բանից` ընտրելու եք այն պահել կամ հեռացնել:
    ///
    ///
    /// # Examples
    ///
    /// Aանկը բաժանելով զուգերի և գործակիցների, օգտագործելով սկզբնական ցուցակը.
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // խուսափել պարտքերի թողարկումներից:
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Շարունակեք նույն օղակը, որը մենք անում ենք ստորև: Սա գործում է միայն այն ժամանակ, երբ ոչնչացումը խուճապի է մատնվել:
                // Եթե մեկ այլ panics սա վիժեցնի:
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Անհրաժեշտ է անսահման կյանքի ողջ ընթացքում `ա
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Անհրաժեշտ է անսահման կյանքի ողջ ընթացքում `ա
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Անհրաժեշտ է անսահման կյանքի ողջ ընթացքում `ա
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Անհրաժեշտ է անսահման կյանքի ողջ ընթացքում `ա
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Կուրսորը `LinkedList`-ի վրա:
///
/// `Cursor`-ը նման է կրկնիչի, բացառությամբ այն բանի, որ այն կարող է ազատորեն հետ ու առաջ փնտրել:
///
/// Կուրսորը միշտ կանգ է առնում ցուցակի երկու տարրերի միջև և ինդեքսավորվում է տրամաբանորեն շրջանաձեւ:
/// Դա տեղավորելու համար կա "ghost" ոչ տարր, որը տալիս է `None` ցուցակի գլխի և պոչի միջև:
///
///
/// Ստեղծվելիս ցուցիչները սկսվում են ցուցակի առջևում, կամ "ghost" ոչ տարրը, եթե ցուցակը դատարկ է:
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// `LinkedList`-ի կուրսորը խմբագրման գործողություններով:
///
/// `Cursor`-ը նման է կրկնիչի, բացառությամբ այն բանի, որ այն կարող է ազատորեն հետ ու առաջ փնտրել, և կրկնությունը կատարելու ընթացքում կարող է ապահով կերպով փոխել ցուցակը:
/// Դա պայմանավորված է նրանով, որ իր բերած հղումների կյանքի տևողությունը կապված է հենց իր կյանքի հետ, այլ ոչ թե պարզապես հիմքում ընկած ցուցակը:
/// Սա նշանակում է, որ կուրսորը չի կարող միանգամից մի քանի տարր տալ:
///
/// Կուրսորը միշտ կանգ է առնում ցուցակի երկու տարրերի միջև և ինդեքսավորվում է տրամաբանորեն շրջանաձեւ:
/// Դա տեղավորելու համար կա "ghost" ոչ տարր, որը տալիս է `None` ցուցակի գլխի և պոչի միջև:
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Վերադարձնում է կուրսորի դիրքի ցուցիչը `LinkedList`-ի սահմաններում:
    ///
    /// Սա վերադարձնում է `None`, եթե կուրսորը ներկայումս ցույց է տալիս "ghost" ոչ տարրը:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Կուրսորը տեղափոխում է `LinkedList`-ի հաջորդ տարր:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա դա այն կտեղափոխի `LinkedList` առաջին տարր:
    /// Եթե այն մատնանշում է `LinkedList`-ի վերջին տարրը, ապա դա այն կտեղափոխի "ghost" ոչ էլեմենտ:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Մենք ներկայիս տարր չունեինք.կուրսորը նստած էր մեկնարկի դիրքում Հաջորդ տարրը պետք է լինի ցուցակի գլխավորը
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Մենք ունեցել ենք նախորդ տարր, ուստի եկեք գնանք դրա հաջորդին
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Կուրսորը տեղափոխում է `LinkedList`-ի նախորդ տարրը:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա դա այն կտեղափոխվի `LinkedList`-ի վերջին տարր:
    /// Եթե այն մատնանշում է `LinkedList`-ի առաջին տարրը, ապա դա այն կտեղափոխի "ghost" ոչ էլեմենտ:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ոչ հոսանք: Մենք ցուցակի սկզբում ենք:Ոչ մի եկամտաբերություն և ցատկիր մինչև վերջ:
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Ունեն նախ.Yիջեք այն և անցեք նախորդ տարրի:
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Վերադարձնում է տեղեկանք այն տարրին, որը ներկայումս ցույց է տալիս կուրսորը:
    ///
    /// Սա վերադարձնում է `None`, եթե կուրսորը ներկայումս ցույց է տալիս "ghost" ոչ տարրը:
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Վերադարձնում է հղումը հաջորդ տարրի:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա սա վերադարձնում է `LinkedList`-ի առաջին տարրը:
    /// Եթե այն ցույց է տալիս `LinkedList`-ի վերջին տարրը, ապա սա վերադարձնում է `None`:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Վերադարձնում է հղումը նախորդ տարրի:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա սա վերադարձնում է `LinkedList`-ի վերջին տարրը:
    /// Եթե այն մատնանշում է `LinkedList`-ի առաջին տարրը, ապա սա վերադարձնում է `None`:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Վերադարձնում է կուրսորի դիրքի ցուցիչը `LinkedList`-ի սահմաններում:
    ///
    /// Սա վերադարձնում է `None`, եթե կուրսորը ներկայումս ցույց է տալիս "ghost" ոչ տարրը:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Կուրսորը տեղափոխում է `LinkedList`-ի հաջորդ տարր:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա դա այն կտեղափոխի `LinkedList` առաջին տարր:
    /// Եթե այն մատնանշում է `LinkedList`-ի վերջին տարրը, ապա դա այն կտեղափոխի "ghost" ոչ էլեմենտ:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Մենք ներկայիս տարր չունեինք.կուրսորը նստած էր մեկնարկի դիրքում Հաջորդ տարրը պետք է լինի ցուցակի գլխավորը
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Մենք ունեցել ենք նախորդ տարր, ուստի եկեք գնանք դրա հաջորդին
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Կուրսորը տեղափոխում է `LinkedList`-ի նախորդ տարրը:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա դա այն կտեղափոխվի `LinkedList`-ի վերջին տարր:
    /// Եթե այն մատնանշում է `LinkedList`-ի առաջին տարրը, ապա դա այն կտեղափոխի "ghost" ոչ էլեմենտ:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ոչ հոսանք: Մենք ցուցակի սկզբում ենք:Ոչ մի եկամտաբերություն և ցատկիր մինչև վերջ:
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Ունեն նախ.Yիջեք այն և անցեք նախորդ տարրի:
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Վերադարձնում է տեղեկանք այն տարրին, որը ներկայումս ցույց է տալիս կուրսորը:
    ///
    /// Սա վերադարձնում է `None`, եթե կուրսորը ներկայումս ցույց է տալիս "ghost" ոչ տարրը:
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Վերադարձնում է հղումը հաջորդ տարրի:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա սա վերադարձնում է `LinkedList`-ի առաջին տարրը:
    /// Եթե այն ցույց է տալիս `LinkedList`-ի վերջին տարրը, ապա սա վերադարձնում է `None`:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Վերադարձնում է հղումը նախորդ տարրի:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա սա վերադարձնում է `LinkedList`-ի վերջին տարրը:
    /// Եթե այն մատնանշում է `LinkedList`-ի առաջին տարրը, ապա սա վերադարձնում է `None`:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Վերադարձնում է միայն ընթերցման կուրսորը ՝ ցույց տալով ընթացիկ տարրը:
    ///
    /// Վերադարձված `Cursor`-ի կյանքի տևողությունը կապված է `CursorMut`-ի հետ, ինչը նշանակում է, որ այն չի կարող գոյատևել `CursorMut`-ից և `CursorMut`-ը սառեցվել է `Cursor`-ի ողջ կյանքի ընթացքում:
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Այժմ ցուցակի խմբագրման գործողությունները

impl<'a, T> CursorMut<'a, T> {
    /// Ընթացիկից հետո `LinkedList`-ի մեջ տեղադրում է նոր տարր:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա նոր տարրը տեղադրվում է `LinkedList`-ի առջևում:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" ոչ տարրի ինդեքսը փոխվել է:
                self.index = self.list.len;
            }
        }
    }

    /// `LinkedList`-ի մեջ ներդնում է նոր տարր `մինչ ընթացիկը:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա նոր տարրը տեղադրվում է `LinkedList` վերջում:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Հեռացնում է ընթացիկ տարրը `LinkedList`-ից:
    ///
    /// Վերացված տարրը հետ է վերադարձվում, և կուրսորը տեղափոխվում է `LinkedList`-ի հաջորդ տարրը ցույց տալու համար:
    ///
    ///
    /// Եթե կուրսորը ներկայումս ցույց է տալիս "ghost" ոչ տարրը, ապա ոչ մի տարր չի հանվում, և `None` վերադարձվում է:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Հեռացնում է ընթացիկ տարրը `LinkedList`-ից ՝ առանց ցուցակի հանգույցը տեղաբաշխելու:
    ///
    /// Հեռացված հանգույցը վերադարձվում է որպես նոր `LinkedList`, որը պարունակում է միայն այս հանգույցը:
    /// Կուրսորը տեղափոխվում է ներկայիս `LinkedList`-ի հաջորդ տարրը ցույց տալու համար:
    ///
    /// Եթե կուրսորը ներկայումս ցույց է տալիս "ghost" ոչ տարրը, ապա ոչ մի տարր չի հանվում, և `None` վերադարձվում է:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Տեղադրում է տրված `LinkedList`-ի տարրերը ընթացիկից հետո:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա նոր տարրերը տեղադրվում են `LinkedList`-ի սկզբում:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" ոչ տարրի ինդեքսը փոխվել է:
                self.index = self.list.len;
            }
        }
    }

    /// Տեղադրում է տրված `LinkedList`-ի տարրերը ընթացիկից առաջ:
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա նոր տարրերը տեղադրվում են `LinkedList` վերջում:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Ընթացիկ տարրից հետո ցուցակը բաժանվում է երկու մասի:
    /// Սա կվերադարձնի նոր ցուցակը, որը կազմված է կուրսորը հաջորդող ամեն ինչից, իսկ սկզբնական ցուցակը կպահի նախկինում առկա ամեն ինչ:
    ///
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա `LinkedList`-ի ամբողջ բովանդակությունը տեղափոխվում է:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" ոչ տարրի ինդեքսը փոխվել է ՝ դառնալով 0:
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Theանկը բաժանում է երկու մասի ՝ մինչև ընթացիկ տարրը:
    /// Սա կվերադարձնի նոր ցուցակ, որը բաղկացած է կուրսորը ներկայացնող ամեն ինչից, իսկ սկզբնական ցուցակը կպահի ամեն ինչ դրանից հետո:
    ///
    ///
    /// Եթե կուրսորը ցույց է տալիս "ghost" ոչ տարրը, ապա `LinkedList`-ի ամբողջ բովանդակությունը տեղափոխվում է:
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// LinkedList-ով `drain_filter` զանգահարելու միջոցով արտադրող կրկնիչ:
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` նորմալ է `element` հղումների կեղծանունով:
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Theուցակը սպառում է կրկնիչի, որն ըստ արժեքի տարրեր է տալիս:
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Համոզվեք, որ `LinkedList`-ը և դրա միայն կարդալու կրկնիչները փոխվում են իրենց տեսակի պարամետրերով:
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}