use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Ներառական պարտավոր է փնտրել, ճիշտ այնպես, ինչպես `Bound::Included(T)`-ը:
    Included(T),
    /// Բացառիկ որոնում, ինչպես `Bound::Excluded(T)`-ը:
    Excluded(T),
    /// Անվերապահ ներառական կապ, ճիշտ այնպես, ինչպես `Bound::Unbounded`-ը:
    AllIncluded,
    /// Անվերապահ բացառիկ պարտավորված:
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Տրված բանալին որոնում է հանգույցի գլխավորությամբ գտնվող (ենթ) ծառի մեջ ՝ հետադարձաբար:
    /// Վերադարձնում է `Found` համապատասխան KV բռնակի հետ, եթե այդպիսին կա:
    /// Հակառակ դեպքում, վերադարձնում է `GoDown` edge տերեւի բռնակով, որտեղ պատկանում է բանալին:
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է տալիս բանալին, ինչպես դա `BTreeMap`-ի ծառն է:
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Իջնում է մոտակա հանգույց, որտեղ edge-ը, որը համապատասխանում է տիրույթի ստորին սահմանին, տարբերվում է վերին սահմանին համապատասխանող edge-ից, այսինքն `ամենամոտ հանգույցից, որի տիրույթում կա առնվազն մեկ բանալի:
    ///
    ///
    /// Գտնվելու դեպքում վերադարձնում է `Ok` այդ հանգույցով, դրա մեջ edge ցուցանիշների զույգը սահմանազատում է տիրույթը, և համապատասխան զույգ սահմանները `մանկական հանգույցներում որոնումը շարունակելու համար, այն դեպքում, երբ հանգույցը ներքին է:
    ///
    /// Եթե չի գտնվել, վերադարձնում է `Err`, որի տերևը edge համապատասխանում է ամբողջ տիրույթին:
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է բանալին:
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Այս փոփոխականները նշելուց պետք է խուսափել:
        // Ենթադրում ենք, որ `range`-ի կողմից հաղորդված սահմանները մնում են նույնը, բայց հակառակորդի իրականացումը կարող է փոխվել (#81138) զանգերի միջև:
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Գտնում է edge հանգույցում, որը սահմանազատում է տիրույթի ստորին սահմանը:
    /// Նաև վերադարձնում է ստորին սահմանը, որն օգտագործվում է համապատասխան մանկական հանգույցում որոնումը շարունակելու համար, եթե `self`-ը ներքին հանգույց է:
    ///
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է բանալին:
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// `find_lower_bound_edge`-ի կլոն `վերին սահմանի համար:
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Առանց հետադարձի փնտրում է հանգույցում տրված բանալին:
    /// Վերադարձնում է `Found` համապատասխան KV բռնակի հետ, եթե այդպիսին կա:
    /// Հակառակ դեպքում, վերադարձնում է `GoDown` edge-ի բռնակով, որտեղ հնարավոր է գտնել բանալին (եթե հանգույցը ներքին է) կամ որտեղ կարող է տեղադրվել բանալին:
    ///
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է տալիս բանալին, ինչպես դա `BTreeMap`-ի ծառն է:
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Վերադարձնում է կամ KV ինդեքսը այն հանգույցում, որի բանալին (կամ դրան համարժեք) գոյություն ունի, կամ edge ինդեքսը, որտեղ պատկանում է բանալին:
    ///
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է տալիս բանալին, ինչպես դա `BTreeMap`-ի ծառն է:
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Գտնում է edge ինդեքս ՝ միջակայքի ստորին սահմանը սահմանափակող հանգույցում:
    /// Նաև վերադարձնում է ստորին սահմանը, որն օգտագործվում է համապատասխան մանկական հանգույցում որոնումը շարունակելու համար, եթե `self`-ը ներքին հանգույց է:
    ///
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է բանալին:
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// `find_lower_bound_index`-ի կլոն `վերին սահմանի համար:
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}