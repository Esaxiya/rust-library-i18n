use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Հատուկ իրադարձություններին հետեւող վթարի փորձարկման կեղծ դետալների նախագիծ:
/// Որոշ ատյաններ ինչ-որ պահի կարող են կազմաձեւվել panic:
/// Իրադարձությունները `clone`, `drop` կամ որոշ անանուն `query` են:
///
/// Crash test dummies-ը նույնականացվում և պատվիրվում է ID-ի կողմից, ուստի դրանք կարող են օգտագործվել որպես ստեղներ BTreeMap-ում:
/// Իրականացումը միտումնավոր օգտագործմամբ չի հենվում crate-ում սահմանված որևէ բանի, բացի `Debug` trait-ից:
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Ստեղծում է վթարի փորձարկման կեղծ դիզայն: `id`-ը որոշում է ատյանների կարգը և հավասարությունը:
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Ստեղծում է վթարի փորձարկման կեղծիքի օրինակ, որն արձանագրում է, թե ինչ իրադարձություններ է ունենում և, ըստ ցանկության, panics:
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Վերադարձնում է, թե քանի անգամ է կեղծվածի կեղծանոցի օրինակներ կլոնավորվել:
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Վերադարձնում է, թե քանի անգամ է կեղծ դրվագները հանվել:
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Վերադարձնում է, թե քանի անգամ կեղծիքի դեպքեր են կանչվել իրենց `query` անդամի վրա:
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Որոշ անանուն հարցում, որի արդյունքն արդեն տրված է:
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}