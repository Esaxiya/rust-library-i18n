use core::intrinsics;
use core::mem;
use core::ptr;

/// Սա փոխարինում է `v` եզակի տեղեկանքի հիմքում ընկած արժեքին ՝ զանգահարելով համապատասխան գործառույթ:
///
///
/// Եթե `change` փակման ժամանակ panic տեղի ունենա, ամբողջ գործընթացը կդադարեցվի:
#[allow(dead_code)] // պահել որպես պատկերազարդ և future օգտագործման համար
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Սա փոխարինում է `v` եզակի հղման հետևյալ արժեքին ՝ զանգահարելով համապատասխան գործառույթ և վերադարձնելով ճանապարհին ստացված արդյունքը:
///
///
/// Եթե `change` փակման ժամանակ panic տեղի ունենա, ամբողջ գործընթացը կդադարեցվի:
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}