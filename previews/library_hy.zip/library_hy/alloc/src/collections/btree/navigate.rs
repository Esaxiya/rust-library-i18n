use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Poraամանակավորապես դուրս է բերում նույն միջակայքի մեկ այլ, անփոփոխ համարժեք:
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Գտնում է տերևի հստակ եզրերը, որոնք սահմանազատում են ծառի որոշակի սահմանը:
    /// Վերադարձնում է կամ տարբեր բռնակների զույգ նույն ծառի մեջ կամ զույգ դատարկ ընտրանքներ:
    ///
    /// # Safety
    ///
    /// Քանի դեռ `BorrowType`-ը `Immut` չէ, մի օգտագործեք կրկնօրինակ բռնակները նույն ԿՎ-ն երկու անգամ այցելելու համար:
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Համարժեք է `(root1.first_leaf_edge(), root2.last_leaf_edge())`-ի, բայց ավելի արդյունավետ:
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Գտնում է տերևի զույգ եզրերը, որոնք սահմանազատում են ծառի որոշակի տիրույթը:
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է տալիս բանալին, ինչպես դա `BTreeMap`-ի ծառն է:
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մեր փոխառության տեսակը անփոփոխ է:
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Գտնում է տերևների զույգ եզրերը, որոնք սահմանազատում են մի ամբողջ ծառ:
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Եզակի հղումը բաժանում է տերևների զույգ եզրերի, որոնք սահմանազատում են նշված տիրույթը:
    /// Արդյունքում ստացվում են ոչ եզակի հղումներ, որոնք թույլ են տալիս (some) մուտացիան, որոնք պետք է օգտագործվեն ուշադիր:
    ///
    /// Արդյունքն իմաստալից է միայն այն դեպքում, եթե ծառը կարգի է տալիս բանալին, ինչպես դա `BTreeMap`-ի ծառն է:
    ///
    ///
    /// # Safety
    /// Մի օգտագործեք կրկնօրինակ բռնակներ `նույն ԿՎ-ն երկու անգամ այցելելու համար:
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Եզակի հղումը բաժանում է տերևի զույգ եզրերին, որոնք սահմանափակում են ծառի ամբողջ տեսականին:
    /// Արդյունքները ոչ եզակի հղումներ են, որոնք թույլ են տալիս մուտացիա (միայն արժեքների), ուստի դրանք պետք է օգտագործվեն խնամքով:
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Մենք այստեղ կրկնօրինակում ենք NodeRef արմատը. Մենք երբեք նույն KV-ն երկու անգամ չենք այցելելու և երբեք չենք հայտնվի համընկնող արժեքի հղումներով:
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Եզակի հղումը բաժանում է տերևի զույգ եզրերին, որոնք սահմանափակում են ծառի ամբողջ տեսականին:
    /// Արդյունքները մասսայական կործանարար մուտացիա թույլ տվող ոչ եզակի հղումներ են, ուստի դրանք պետք է օգտագործվեն առավելագույն խնամքով:
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Մենք այստեղ կրկնօրինակում ենք NodeRef արմատը. Մենք երբեք դրան չենք հասնի այնպես, որ համընկնի արմատից ստացված հղումները:
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Տրված edge տերևի բռնակով, բռնակի հետ [`Result::Ok`]-ը վերադառնում է աջ կողմի հարևան KV-ին, որը կա՛մ նույն տերևի հանգույցում է, կա՛մ նախնիների հանգույցում:
    ///
    /// Եթե edge տերևը վերջինն է ծառում, արմատային հանգույցով վերադարձնում է [`Result::Err`]:
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Տրված edge տերևի բռնակով, բռնակի հետ [`Result::Ok`]-ը վերադառնում է ձախ կողմի հարևան KV-ին, որը կա՛մ նույն տերևի հանգույցում է, կա՛մ նախնիների հանգույցում:
    ///
    /// Եթե edge տերևը ծառի մեջ առաջինն է, արմատային հանգույցով վերադարձնում է [`Result::Err`]:
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Հաշվի առնելով edge ներքին բռնիչը, բռնակի հետ [`Result::Ok`]-ը վերադարձնում է աջ կողմի հարևան KV-ին, որը կա՛մ նույն ներքին հանգույցում է, կա՛մ նախնիների հանգույցում:
    ///
    /// Եթե ներքին edge-ը վերջինն է ծառում, արմատային հանգույցով վերադարձնում է [`Result::Err`]:
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Հաշվի առնելով edge տերևի տերևը մեռնող ծառի մեջ, հետևում է edge հաջորդ տերևը աջ կողմում, և մեջտեղում առանցքային արժեքի զույգը, որը կա՛մ նույն տերևի հանգույցում է, կա՛մ նախնիների հանգույցում, կամ գոյություն չունի:
    ///
    ///
    /// Այս մեթոդը նաև տեղաբաշխում է ցանկացած node(s), որի վերջը հասնում է:
    /// Սա ենթադրում է, որ եթե առանցքային արժեքի այլևս զույգ գոյություն չունի, ծառի ամբողջ մնացորդը կտեղափոխվի և այլևս ոչինչ չի մնա վերադարձնելու:
    ///
    /// # Safety
    /// Տվյալ edge-ը չպետք է նախկինում վերադարձված լինի իր գործընկեր `deallocating_next_back`-ի կողմից:
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Հաշվի առնելով edge տերևի բռունցքը մահացող ծառի մեջ, հետևում է ձախ կողմում հաջորդ edge տերևը, իսկ միջև ստեղնային արժեքի զույգը, որը կա՛մ նույն տերևի հանգույցում է, կա՛մ նախնիների հանգույցում, կամ գոյություն չունի:
    ///
    ///
    /// Այս մեթոդը նաև տեղաբաշխում է ցանկացած node(s), որի վերջը հասնում է:
    /// Սա ենթադրում է, որ եթե առանցքային արժեքի այլևս զույգ գոյություն չունի, ծառի ամբողջ մնացորդը կտեղափոխվի և այլևս ոչինչ չի մնա վերադարձնելու:
    ///
    /// # Safety
    /// Տվյալ edge-ը չպետք է նախկինում վերադարձված լինի իր գործընկեր `deallocating_next`-ի կողմից:
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Վերաբաշխում է տերևներից մինչև արմատ ընկած հանգույցների կույտը:
    /// Սա միակ միջոցն է `ծառի մնացորդը տեղաբաշխելու այն բանից հետո, երբ `deallocating_next` և `deallocating_next_back` ծառերը խայթոցեն ծառի երկու կողմերում և հարվածել են նույն edge-ին:
    /// Քանի որ այն նախատեսված է զանգահարել միայն այն ժամանակ, երբ բոլոր բանալիները և արժեքները վերադարձվեն, ոչ մի բանալին կամ արժեքը չի մաքրվում:
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge տերևը տեղափոխում է հաջորդ տերևի edge և վերադարձնում հղումները ստեղնին և դրանց միջեւ եղած արժեքին:
    ///
    ///
    /// # Safety
    /// Անցած ուղղությամբ պետք է լինի ևս մեկ ԿՎ:
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// edge տերևը տեղափոխում է նախորդ տերևի edge և վերադարձնում հղումներ ստեղնին և դրանց միջեւ եղած արժեքին:
    ///
    ///
    /// # Safety
    /// Անցած ուղղությամբ պետք է լինի ևս մեկ ԿՎ:
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge տերևը տեղափոխում է հաջորդ տերևի edge և վերադարձնում հղումները ստեղնին և դրանց միջեւ եղած արժեքին:
    ///
    ///
    /// # Safety
    /// Անցած ուղղությամբ պետք է լինի ևս մեկ ԿՎ:
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Սա, ըստ չափանիշների, ավելի արագ է կատարում:
        kv.into_kv_valmut()
    }

    /// Տեղափոխում է edge տերևի բռնակը դեպի նախորդ տերևը և վերադառնում հղումներ ստեղնին և դրանց միջեւ եղած արժեքին:
    ///
    ///
    /// # Safety
    /// Անցած ուղղությամբ պետք է լինի ևս մեկ ԿՎ:
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Սա, ըստ չափանիշների, ավելի արագ է կատարում:
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge տերևի տերևը տեղափոխում է հաջորդ edge տերև և վերադարձնում ստեղնը և արժեքը ՝ տեղաբաշխելով հետ մնացած ցանկացած հանգույց, իսկ համապատասխան edge- ը թողնելով իր ծնողական հանգույցում կախված:
    ///
    /// # Safety
    /// - Անցած ուղղությամբ պետք է լինի ևս մեկ ԿՎ:
    /// - Այդ KV-ն իր գործընկեր `next_back_unchecked`-ը նախկինում չի վերադարձրել ծառի հատման համար օգտագործվող բռնակների որևէ օրինակ:
    ///
    /// Նորացված բռնակին անցնելու միակ անվտանգ միջոցն այն համեմատելն է, այն գցելը, այս մեթոդը կրկին զանգահարելը `ելնելով դրա անվտանգության պայմաններից, կամ զանգահարել գործընկեր `next_back_unchecked` դրա անվտանգության պայմանների համաձայն:
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// edge տերևը տեղափոխում է նախորդ edge տերևին և վերադարձնում ստեղնը և արժեքը `տեղաբաշխելով մնացած մնացած հանգույցը` համապատասխան edge-ը թողնելով իր հիմնական հանգույցում կախված:
    ///
    /// # Safety
    /// - Անցած ուղղությամբ պետք է լինի ևս մեկ ԿՎ:
    /// - edge այդ տերևը նախկինում չի վերադարձվել իր գործընկեր `next_unchecked`-ի կողմից ծառի վրայով անցնելու համար օգտագործվող բռնակների որևէ օրինակի վրա:
    ///
    /// Նորացված բռնակին անցնելու միակ անվտանգ միջոցն այն համեմատելն է, այն գցելը, այս մեթոդը կրկին զանգահարելը `ելնելով դրա անվտանգության պայմաններից, կամ զանգահարել գործընկեր `next_unchecked` դրա անվտանգության պայմանների համաձայն:
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Վերադարձնում է edge-ի ձախ ձախ տերևը մի հանգույցում կամ դրա տակ, այլ կերպ ասած, edge-ը, որն անհրաժեշտ է նախ ՝ առաջ նավարկելու ժամանակ (կամ վերջինը ՝ հետ շարժվելիս):
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Վերադարձնում է edge-ի աջ աջ տերևը մի հանգույցում կամ դրա տակ, այլ կերպ ասած, edge-ը, որն անհրաժեշտ է վերջինից `առաջ շարժվելիս (կամ առաջինը` հետ նետելիս):
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Այցելում է տերևի հանգույցները և ներքին KV-ները `բանալիներով բարձրանալու կարգով, ինչպես նաև այցելում է ներքին հանգույցները, ընդհանուր առմամբ, առաջին կարգի խորությամբ, ինչը նշանակում է, որ ներքին հանգույցները նախորդում են նրանց անհատական KV-ներին և նրանց երեխայի հանգույցներին:
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Հաշվարկում է (ենթ) ծառի տարրերի քանակը:
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Վերադարձնում է edge տերևը ամենամոտ ԿՎ-ին `առաջ նավարկելու համար:
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Վերադարձնում է edge ամենամոտ տերևը KV-ին `հետընթաց նավարկելու համար:
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}