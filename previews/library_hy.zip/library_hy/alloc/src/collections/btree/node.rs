// Սա իդեալին հաջորդող իրականացման փորձ է
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Քանի որ Rust-ն իրականում չունի կախված տեսակներ և բազմանդամ հետադարձություն, մենք բավարարվում ենք շատ անապահովության հետ:
//

// Այս մոդուլի հիմնական նպատակն է խուսափել բարդությունից `ծառը դիտելով որպես ընդհանուր (եթե տարօրինակ ձևով) տարա և խուսափի B-Tree անփոփոխների մեծամասնության հետ գործ ունենալուց:
//
// Որպես այդպիսին, այս մոդուլին չի հետաքրքրում `արդյո՞ք գրառումները դասավորված են, ո՞ր հանգույցները կարող են թերակատար լինել, կամ նույնիսկ` ինչ է նշանակում անբավարար: Այնուամենայնիվ, մենք ապավինում ենք մի քանի անփոփոխների.
//
// - Tառերը պետք է ունենան միատեսակ depth/height: Սա նշանակում է, որ տվյալ հանգույցից դեպի յուրաքանչյուր տերև ընկած յուրաքանչյուր ուղի ունի ճիշտ նույն երկարությունը:
// - `n` երկարության հանգույցն ունի `n` ստեղներ, `n` արժեքներ և `n + 1` եզրեր:
//   Սա ենթադրում է, որ նույնիսկ դատարկ հանգույցն ունի առնվազն մեկ edge:
//   Տերևի հանգույցի համար "having an edge" նշանակում է, որ մենք կարող ենք դիրքորոշել հանգույցում, քանի որ տերևի եզրերը դատարկ են և տվյալների ներկայացման կարիք չունեն:
// Ներքին հանգույցում edge-ը նույնականացնում է դիրքը և պարունակում է ցուցիչ դեպի երեխայի հանգույց:
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Տերեւի հանգույցների հիմքում ընկած ներկայացումը և ներքին հանգույցների ներկայացման մի մասը:
struct LeafNode<K, V> {
    /// Մենք ուզում ենք փոխկողմ լինել `K` և `V`-ում:
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Այս հանգույցի ինդեքսը մայր հանգույցի `edges` զանգված է:
    /// `*node.parent.edges[node.parent_idx]` պետք է լինի նույնը, ինչ `node`-ը:
    /// Դա երաշխավորված է նախադրվել միայն այն դեպքում, երբ `parent`-ն անվավեր է:
    parent_idx: MaybeUninit<u16>,

    /// Այս հանգույցը պահում է ստեղների և արժեքների քանակը:
    len: u16,

    /// Հանգույցի իրական տվյալները պահող զանգվածները:
    /// Յուրաքանչյուր զանգվածի միայն առաջին `len` տարրերն են սկզբնավորվում և վավեր:
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Նախաձեռնարկում է նոր `LeafNode` տեղում:
    unsafe fn init(this: *mut Self) {
        // Որպես ընդհանուր քաղաքականություն, մենք դաշտերը թողնում ենք ոչ նախնականացված, եթե դրանք հնարավոր է, քանի որ դա պետք է լինի և՛ մի փոքր ավելի արագ, և՛ ավելի հեշտ է հետևել Վալգրինդում:
        //
        unsafe {
            // parent_idx-ը, բանալիները և vals-ը բոլորը UUnit-ն են
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Ստեղծում է նոր տուփերով `LeafNode`:
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ներքին հանգույցների հիմքում ընկած ներկայացումը: Ինչպես «LeafNode`s»-ի դեպքում, դրանք նույնպես պետք է թաքնվեն «BoxedNode»-ի ետևում`կանխելու համար ոչ սկզբնական ստեղների և արժեքների անկումը:
/// `InternalNode`-ի ցանկացած ցուցիչ կարող է ուղղակիորեն տեղափոխվել հանգույցի հիմքում ընկած `LeafNode` մասի ցուցիչին, որը թույլ է տալիս ծածկագրին գործել տերևի և ներքին հանգույցների վրա առանց առհասարակ ստուգելու, թե որ ցուցիչից է ցույց տալիս այդ երկու ցուցիչը:
///
/// Այս հատկությունը միացված է `repr(C)`-ի օգտագործման միջոցով:
///
#[repr(C)]
// gdb_providers.py օգտագործում է այս տիպի անունը `ներհայեցման համար:
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Այս հանգույցի երեխաների ցուցիչները:
    /// `len + 1` դրանցից սկզբնավորված և վավեր են համարվում, բացառությամբ այն բանի, որ վերջում, մինչև ծառը պահվում է `Dying` տեսակի փոխառության միջոցով, այդ ցուցիչներից ոմանք կախված են:
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Ստեղծում է նոր տուփերով `InternalNode`:
    ///
    /// # Safety
    /// Ներքին հանգույցների անփոփոխությունն այն է, որ նրանք ունեն առնվազն մեկ նախնական և վավեր edge:
    /// Այս գործառույթը չի կարգավորում նման edge:
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Մենք միայն պետք է նախնական տվյալներ ներկայացնենք.եզրերը MaybeUninit են:
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Կառավարվող, ոչ զրոյական ցուցիչ դեպի հանգույց: Սա կա՛մ `LeafNode<K, V>`-ին պատկանող ցուցիչ է, կա՛մ `InternalNode<K, V>`-ին պատկանող ցուցիչ:
///
/// Այնուամենայնիվ, `BoxedNode`-ը չի պարունակում տեղեկատվություն այն մասին, թե երկու տեսակի հանգույցներից որն է իրականում պարունակում, և, մասամբ այս տեղեկատվության պակասի պատճառով, առանձին տեսակ չէ և չունի ոչնչացնող:
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Պատկանող ծառի արմատային հանգույցը:
///
/// Նկատի ունեցեք, որ սա կործանիչ չունի և պետք է ձեռքով մաքրվի:
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Վերադարձնում է նոր պատկանող ծառ ՝ իր սեփական արմատային հանգույցով, որը սկզբում դատարկ է:
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` չպետք է լինի զրո:
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Փոխադարձաբար վերցնում է պատկանող արմատային հանգույցը:
    /// Ի տարբերություն `reborrow_mut`-ի, սա անվտանգ է, քանի որ վերադարձի արժեքը չի կարող օգտագործվել արմատը ոչնչացնելու համար, և ծառի վերաբերյալ այլ հղումներ չեն կարող լինել:
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Մի փոքր փոխադարձաբար վերցնում է պատկանող արմատային հանգույցը:
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Անդառնալիորեն անցում դեպի հղում, որը թույլ է տալիս շրջանցել և առաջարկում է կործանարար մեթոդներ և շատ քիչ բան:
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ավելացնում է նոր ներքին հանգույց մեկ edge-ով, որը ցույց է տալիս նախորդ արմատային հանգույցը, այդ նոր հանգույցը դարձնում արմատային հանգույց և վերադարձնում այն:
    /// Սա բարձրությունը բարձրացնում է 1-ով և հակառակ է `pop_internal_level`-ին:
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, բացառությամբ, որ մենք պարզապես մոռացել ենք, որ այժմ ներքին ենք.
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Հեռացնում է ներքին արմատային հանգույցը ՝ օգտագործելով իր առաջին երեխան որպես նոր արմատային հանգույց:
    /// Քանի որ այն կոչված է զանգահարել միայն այն դեպքում, երբ արմատային հանգույցը միայն մեկ երեխա ունի, ոչ մի բանալիների, արժեքների և այլ երեխաների վրա մաքրում չի կատարվում:
    ///
    /// Սա բարձրությունը նվազեցնում է 1-ով և հակառակ է `push_internal_level`-ին:
    ///
    /// Պահանջում է բացառիկ մուտք դեպի `Root` օբյեկտ, բայց ոչ արմատային հանգույց:
    /// դա անվավեր չի դարձնի արմատային հանգույցի այլ բռնակներ կամ հղումներ:
    ///
    /// Panics, եթե չկա ներքին մակարդակ, այսինքն, եթե արմատային հանգույցը տերև է:
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պնդում էինք, որ ներքին ենք:
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք վերցրել ենք բացառապես `self`, և դրա փոխառման տեսակը բացառիկ է:
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Առաջին edge-ը միշտ նախանշվում է:
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef`-ը միշտ փոխվում է `K`-ում և `V`-ում, նույնիսկ այն դեպքում, երբ `BorrowType`-ը `Mut` է:
// Սա տեխնիկապես սխալ է, բայց չի կարող հանգեցնել որևէ անապահովության `NodeRef`-ի ներքին օգտագործման պատճառով, քանի որ մենք ամբողջովին ընդհանուր ենք մնում `K`-ի և `V`-ի նկատմամբ:
//
// Այնուամենայնիվ, ամեն անգամ, երբ հասարակական տիպը փաթաթում է `NodeRef`-ը, համոզվեք, որ այն ունի ճիշտ շեղում:
//
/// Հղում դեպի մի հանգույց:
///
/// Այս տեսակն ունի մի շարք պարամետրեր, որոնք վերահսկում են դրա գործողությունը.
/// - `BorrowType`: Կեղծ մի տեսակ, որը նկարագրում է փոխառության տեսակը և կրում է ողջ կյանքի ընթացքում:
///    - Երբ սա `Immut<'a>` է, `NodeRef`-ը գործում է մոտավորապես `&'a Node`-ի նման:
///    - Երբ սա `ValMut<'a>` է, `NodeRef`-ը գործում է մոտավորապես `&'a Node`-ի նման ստեղների և ծառի կառուցվածքի հետ կապված, բայց նաև թույլ է տալիս գոյատևել ամբողջ ծառի արժեքների բազմաթիվ փոփոխական հղումներ:
///    - Երբ սա `Mut<'a>` է, `NodeRef`-ը գործում է մոտավորապես `&'a mut Node`-ի նման, չնայած ներդիրի մեթոդները թույլ են տալիս փոխադարձ ցուցիչ ունենալ արժեքի հետ գոյակցելուն:
///    - Երբ սա `Owned` է, `NodeRef`-ը գործում է մոտավորապես `Box<Node>`-ի նման, բայց չունի ապակառուցող և պետք է ձեռքով մաքրվի:
///    - Երբ սա `Dying` է, `NodeRef`-ը դեռևս գործում է մոտավորապես `Box<Node>`-ի նման, բայց ծառը հատ առ հատ ոչնչացնելու մեթոդներ ունի, և սովորական մեթոդները, չնայած նշված չեն անվանել զանգելու, սխալ կանչելու դեպքում կարող են վկայակոչել UB:
///
///   Քանի որ ցանկացած `NodeRef` հնարավորություն է տալիս նավարկելու ծառի միջով, `BorrowType`-ն արդյունավետորեն վերաբերում է ամբողջ ծառին, ոչ միայն բուն հանգույցին:
/// - `K` և `V`. Սրանք ստեղների և արժեքների տեսակներ են, որոնք պահվում են հանգույցներում:
/// - `Type`: Սա կարող է լինել `Leaf`, `Internal` կամ `LeafOrInternal`:
/// Երբ սա `Leaf` է, `NodeRef`-ը ցույց է տալիս տերևի հանգույցը, երբ սա `Internal` է, `NodeRef`-ը մատնանշում է ներքին հանգույց, և երբ դա `LeafOrInternal` է, `NodeRef`-ը կարող է մատնանշել ցանկացած հանգույց:
///   `Type` կոչվում է `NodeType`, երբ օգտագործվում է `NodeRef`-ից դուրս:
///
/// Եվ `BorrowType`-ը, և `NodeType`-ը սահմանափակում են, թե ինչ մեթոդներ ենք մենք կիրառում `ստատիկ տիպի անվտանգությունն օգտագործելու համար: Նման սահմանափակումներ կիրառելու եղանակով սահմանափակումներ կան.
/// - Յուրաքանչյուր տիպի պարամետրի համար մենք կարող ենք միայն մեթոդ սահմանել կամ ընդհանուր կամ մեկ որոշակի տեսակի համար:
/// Օրինակ, մենք չենք կարող `into_kv`-ի նման մեթոդը բնորոշել բոլոր `BorrowType`-ների համար, կամ մեկ անգամ `կյանքի տևողությամբ բոլոր տեսակների համար, քանի որ մենք ուզում ենք, որ այն վերադարձնի `&'a` հղումները:
///   Հետեւաբար, մենք այն սահմանում ենք միայն նվազագույն հզոր `Immut<'a>` տիպի համար:
/// - Մենք չենք կարող անուղղակի հարկադրանք ստանալ `Mut<'a>`-ից `Immut<'a>` ասացվածքներից:
///   Հետևաբար, մենք պետք է հստակորեն զանգահարենք `reborrow`-ը ավելի հզոր `NodeRef`-ով, որպեսզի հասնենք `into_kv`-ի նման մեթոդի:
///
/// `NodeRef`-ի բոլոր մեթոդները, որոնք ինչ-որ տեղեկանք են վերադարձնում, կամ ՝
/// - Վերցրեք `self`-ը ըստ արժեքի և վերադարձրեք `BorrowType`-ի կրած ողջ կյանքը:
///   Երբեմն, նման մեթոդ ստանալու համար, մենք պետք է զանգահարենք `reborrow_mut`:
/// - Վերցրեք `self`-ը հղումով, և (implicitly)-ը վերադարձեք այդ տեղեկանքի կյանքի տևողությունը ՝ `BorrowType`-ի կրած կյանքի փոխարեն:
/// Այդ եղանակով փոխառության ստուգիչը երաշխավորում է, որ `NodeRef`-ը փոխառություն է մնում, քանի դեռ օգտագործվում է վերադարձված տեղեկանքը:
///   Ներդիրին աջակցող մեթոդները թեքում են այս կանոնը `վերադարձնելով հում ցուցիչ, այսինքն` հղում առանց կյանքի:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Հանգույցի և տերևների մակարդակի բաժանված մակարդակների քանակը `հանգույցի հաստատուն, որը չի կարող ամբողջությամբ նկարագրվել `Type`-ի կողմից, և որ հանգույցն ինքնին չի պահում:
    /// Մենք միայն պետք է պահենք արմատային հանգույցի բարձրությունը և դրանից վերցնենք յուրաքանչյուր մյուս հանգույցի բարձրությունը:
    /// Պետք է լինի զրո, եթե `Type`-ը `Leaf` է և ոչ զրոյական, եթե `Type`-ը `Internal` է:
    ///
    ///
    height: usize,
    /// Սլաքը դեպի տերևը կամ ներքին հանգույցը:
    /// `InternalNode`-ի սահմանումը ապահովում է ցուցիչի վավերականությունը կամ որևէ կերպ:
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Բեռնաթափեք հանգույցի տեղեկանքը, որը փաթեթավորված էր որպես `NodeRef::parent`:
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Բացահայտում է ներքին հանգույցի տվյալները:
    ///
    /// Վերադառնում է հում ptr ՝ այս հանգույցի այլ հղումներն անվավեր ճանաչելու համար:
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստատիկ հանգույցի տեսակը `Internal` է:
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ներառյալ ներքին հանգույցի տվյալների բացառիկ մուտքը:
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Գտնում է հանգույցի երկարությունը: Սա ստեղների կամ արժեքների քանակ է:
    /// Եզրերի քանակը `len() + 1` է:
    /// Ուշադրություն դարձրեք, որ չնայած անվտանգ լինելուն, այս գործառույթը կանչելը կարող է ունենալ կողմնակի ազդեցություն անվստահելի ծածկագրի ստեղծած անվստահելի հղումների:
    ///
    pub fn len(&self) -> usize {
        // Շատ կարևոր է, որ մենք այստեղ մուտք ենք գործում միայն `len` դաշտ:
        // Եթե BorrowType-ը marker::ValMut է, կարող են լինել չմարված փոփոխական հղումներ այն արժեքների, որոնք մենք չպետք է անվավեր ճանաչենք:
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Վերադարձնում է հանգույցի և տերևների բաժանված մակարդակների քանակը:
    /// Zրոյական բարձրությունը նշանակում է, որ հանգույցն ինքը տերև է:
    /// Եթե դուք պատկերում եք ծառեր ՝ արմատից վերևում, ապա թիվն ասում է, թե որ բարձրության վրա է հայտնվում հանգույցը:
    /// Եթե պատկերում եք ծառեր վերևում տերևներով, ապա համարը ասում է, թե որքան բարձր է ծառը տարածվում հանգույցի վերևում:
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Sameամանակավորապես վերցնում է մեկ այլ, անփոփոխ հղում նույն հանգույցին:
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Բացահայտում է ցանկացած տերևի կամ ներքին հանգույցի տերևի մասը:
    ///
    /// Վերադառնում է հում ptr ՝ այս հանգույցի այլ հղումներն անվավեր ճանաչելու համար:
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Հանգույցը պետք է վավեր լինի առնվազն LeafNode մասի համար:
        // Սա NodeRef տիպի հղում չէ, քանի որ մենք չգիտենք `այն պետք է եզակի լինի կամ համօգտագործված:
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Գտնում է ընթացիկ հանգույցի ծնողը:
    /// Վերադարձնում է `Ok(handle)`, եթե ընթացիկ հանգույցն իրականում ունի ծնող, որտեղ `handle`-ը մատնանշում է ծնողի edge-ը, որը մատնանշում է ընթացիկ հանգույցը:
    ///
    /// Վերադարձնում է `Err(self)`-ը, եթե ընթացիկ հանգույցը ծնող չունի `վերադարձնելով բնօրինակը `NodeRef`:
    ///
    /// Մեթոդի անվանումը ենթադրում է, որ դուք պատկերում եք ծառեր, որոնց վերևում արմատային հանգույցն է:
    ///
    /// `edge.descend().ascend().unwrap()` և `node.ascend().unwrap().descend()`-ը, հաջողության հասնելու դեպքում, ոչինչ չպետք է անեն:
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Մենք պետք է հանգույցների համար օգտագործենք հում ցուցիչներ, քանի որ, եթե BorrowType-ը marker::ValMut է, կարող են լինել չմարված փոփոխական հղումներ արժեքներին, որոնք մենք չպետք է անվավեր ճանաչենք:
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Նկատի ունեցեք, որ `self`-ը չպետք է դատարկ լինի:
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Նկատի ունեցեք, որ `self`-ը չպետք է դատարկ լինի:
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Բացահայտում է ցանկացած տերևի կամ ներքին հանգույցի տերևային մասը անփոփոխ ծառի մեջ:
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `Immut` փոխառված այս ծառի վերաբերյալ փոփոխական հղումներ չեն կարող լինել:
        unsafe { &*ptr }
    }

    /// Տեսքը խցկում է հանգույցում պահված ստեղները:
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend`-ի նման, հղում է ստանում հանգույցի ծնողական հանգույցին, բայց և ընթացիկ հանգույցը վերաբաշխում է գործընթացում:
    /// Սա անվտանգ չէ, քանի որ ընթացիկ հանգույցը, չնայած ապաբաշխված լինելուն, դեռ հասանելի կլինի:
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Անվստահ կերպով պնդում է կազմողին ստատիկ տեղեկատվությունը, որ այս հանգույցը `Leaf` է:
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Անվստահ կերպով պնդում է կազմողին ստատիկ տեղեկատվությունը, որ այս հանգույցը `Internal` է:
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Sameամանակավորապես վերցնում է մեկ այլ, փոփոխական հղում նույն հանգույցին: Գուշացեք, քանի որ այս մեթոդը շատ վտանգավոր է, կրկնակի, այնպես որ կարող է միանգամից վտանգավոր չթվալ:
    ///
    /// Քանի որ փոփոխվող ցուցիչները կարող են թափառել ծառի շուրջ ցանկացած տեղ, վերադարձված ցուցիչը հեշտությամբ կարող է օգտագործվել բուն ցուցիչը կախովի, սահմաններից դուրս կամ անվավեր դարձնելու համար `դասավորված փոխառության կանոնների համաձայն:
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) դիտարկեք `NodeRef`-ին ավելացնել ևս մեկ տիպի պարամետր, որը սահմանափակում է նավիգացիոն մեթոդների օգտագործումը վերալարված ցուցիչներով ՝ կանխելով այդ անապահովությունը:
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Rowsանկացած տերևի կամ ներքին հանգույցի տերևային մասի բացառիկ մուտքը խստացնում է:
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք բացառիկ մուտք ունենք դեպի ամբողջ հանգույցը:
        unsafe { &mut *ptr }
    }

    /// Առաջարկում է բացառիկ մուտք դեպի ցանկացած տերևի կամ ներքին հանգույցի տերևի հատված:
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք բացառիկ մուտք ունենք դեպի ամբողջ հանգույցը:
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Բեռնում է բացառիկ մուտքը առանցքային պահեստային տարածքի տարր:
    ///
    /// # Safety
    /// `index` 0-ի սահմաններում է ... ՀՆԱՐԱՎՈՐՈՒԹՅՈՒՆԸ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը չի կարողանա ինքնահաստատման հետագա մեթոդներ կանչել
        // մինչև հիմնական կտորի տեղեկանքի թողարկումը, քանի որ մենք յուրահատուկ հնարավորություն ունենք վարկի ողջ կյանքի ընթացքում:
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Բացառում է բացառիկ մուտքը հանգույցի արժեքի պահպանման տարածքի տարրի կամ հատվածի:
    ///
    /// # Safety
    /// `index` 0-ի սահմաններում է ... ՀՆԱՐԱՎՈՐՈՒԹՅՈՒՆԸ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը չի կարողանա ինքնահաստատման հետագա մեթոդներ կանչել
        // այնքան ժամանակ, քանի դեռ արժեքի կտորի տեղեկանքը չի իջել, քանի որ մենք բացառիկ հնարավորություն ունենք վարկի ողջ կյանքի ընթացքում:
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Բացառում է բացառիկ մուտքը հանգույցի պահեստային տարածքի տարրի կամ կտորի edge պարունակության համար:
    ///
    /// # Safety
    /// `index` 0-ի սահմաններում է ... ՀՆԱՐԱՎՈՐՈՒԹՅՈՒՆ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը չի կարողանա ինքնահաստատման հետագա մեթոդներ կանչել
        // մինչև edge կտորի տեղեկանքը չհեռանա, քանի որ մենք յուրօրինակ մուտք ունենք վարկի ողջ կյանքի ընթացքում:
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Հանգույցն ունի ավելի քան `idx` սկզբնավորված տարրեր:
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Մենք միայն հղում ենք ստեղծում մեզ հետաքրքրող մեկ էլեմենտի վրա `խուսափելու համար այլ տարրերի, մասնավորապես` զանգահարողին ավելի վաղ կրկնություններով վերադարձվածին վերագրվող ակնարկներով վերանայումներից:
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust #74679 թողարկման պատճառով մենք պետք է պարտադրենք զանգվածի ցուցիչների մեծությունը:
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Բորուսների բացառիկ մուտքը հանգույցի երկարությանը:
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Կարգավորում է հանգույցի հղումը դեպի իր հիմնական edge, առանց անվավեր ճանաչելու այլ հղումներ:
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Մաքրում է արմատի հղումը դեպի իր մայր edge:
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Հանգույցի վերջում ավելացնում է առանցքային արժեքի զույգ:
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range`-ի կողմից վերադարձված յուրաքանչյուր տարր հանգույցի համար գործող edge ինդեքս է:
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ավելացնում է առանցքային արժեքի զույգ և edge ՝ այդ զույգի աջ կողմում ՝ հանգույցի վերջում:
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ստուգում է ՝ արդյոք հանգույցը `Internal` հանգույց է, թե `Leaf` հանգույց:
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Հղում գտնվող հանգույցի մեջ որոշակի ստեղային արժեքի զույգի կամ edge-ի հղում:
/// `Node` պարամետրը պետք է լինի `NodeRef`, մինչդեռ `Type` կարող է լինել `KV` (բանալին-արժեքային զույգի բռնակի նշանակում) կամ `Edge` (edge-ի բռնակի նշանակում):
///
/// Նշենք, որ նույնիսկ `Leaf` հանգույցները կարող են ունենալ `Edge` բռնակ:
/// Մանկական հանգույցում ցուցիչ ներկայացնելու փոխարեն, դրանք ներկայացնում են այն տարածությունները, որտեղ մանկական ցուցիչները անցնում են առանցքային արժեքի զույգերի միջև:
/// Օրինակ ՝ 2 երկարությամբ հանգույցում կլինեին 3 հնարավոր edge վայրեր ՝ մեկը հանգույցից ձախ, մեկը երկու զույգի միջև և մեկը հանգույցի աջ կողմում:
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Մեզ պետք չէ `#[derive(Clone)]`-ի ամբողջական ընդհանրությունը, քանի որ `Node`-ը կլոնավորելու միակ դեպքն է, երբ դա անփոփոխ հղում է, ուստի `Copy`:
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Առբերում է այն հանգույցը, որը պարունակում է edge կամ ստեղնային արժեքի զույգ, որի վրա մատնանշում է այս բռնիչը:
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Վերադարձնում է այս բռնակի դիրքը հանգույցում:
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node`-ում ստեղծում է նոր բռնակ առանցքային արժեքի զույգի համար:
    /// Անվտանգ, քանի որ զանգահարողը պետք է ապահովի, որ `idx < node.len()`-ը:
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Կարող է լինել PartialEq-ի հանրային իրականացում, բայց օգտագործվել է միայն այս մոդուլում:
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Locationամանակավորապես հանում է մեկ այլ, անփոփոխ բռնակից նույն վայրում:
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Մենք չենք կարող օգտագործել Handle::new_kv կամ Handle::new_edge, քանի որ չգիտենք մեր տեսակը
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Անվստահ կերպով պնդում է կազմողին ստատիկ տեղեկատվությունը, որ բռնակի հանգույցը `Leaf` է:
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Locationամանակավորապես հանում է մեկ այլ, փոփոխվող բռնակ նույն վայրում:
    /// Գուշացեք, քանի որ այս մեթոդը շատ վտանգավոր է, կրկնակի, այնպես որ կարող է միանգամից վտանգավոր չթվալ:
    ///
    ///
    /// Մանրամասների համար տե՛ս `NodeRef::reborrow_mut`:
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Մենք չենք կարող օգտագործել Handle::new_kv կամ Handle::new_edge, քանի որ չգիտենք մեր տեսակը
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node`-ում ստեղծում է նոր բռնակ edge-ի համար:
    /// Անվտանգ, քանի որ զանգահարողը պետք է ապահովի, որ `idx <= node.len()`-ը:
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Հաշվի առնելով edge ինդեքսը, որտեղ մենք ցանկանում ենք ներդնել հզորության մեջ լցված հանգույցի մեջ, հաշվարկում է պառակտման կետի խելամիտ KV ինդեքսը և որտեղ է տեղադրումը կատարելու համար:
///
/// Պառակտման կետի նպատակն է, որ դրա բանալին և արժեքը հայտնվեն ծնողական հանգույցում.
/// պառակտման կետի ձախ կողմում գտնվող ստեղները, արժեքները և եզրերը դառնում են ձախ երեխա.
/// Պառակտման կետի աջ կողմում գտնվող ստեղները, արժեքները և եզրերը դառնում են ճիշտ երեխա:
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust #74834 համարը փորձում է բացատրել այս սիմետրիկ կանոնները:
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Տեղադրում է ստեղնի արժեքի նոր զույգ այս edge-ի աջից և ձախից ստեղնային արժեքի զույգերի միջև:
    /// Այս մեթոդը ենթադրում է, որ հանգույցում բավականաչափ տեղ կա, որպեսզի նոր զույգը տեղավորվի:
    ///
    /// Վերադարձված ցուցիչը ցույց է տալիս տեղադրված արժեքը:
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Տեղադրում է ստեղնի արժեքի նոր զույգ այս edge-ի աջից և ձախից ստեղնային արժեքի զույգերի միջև:
    /// Այս մեթոդը բաժանում է հանգույցը, եթե բավարար տեղ չկա:
    ///
    /// Վերադարձված ցուցիչը ցույց է տալիս տեղադրված արժեքը:
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ստեղծում է ծնողի ցուցիչը և ինդեքսը երեխայի հանգույցում, որին հղում է կատարում այս edge-ին:
    /// Սա օգտակար է, երբ եզրերի դասավորությունը փոխվի,
    fn correct_parent_link(self) {
        // Ստեղծեք backpointer ՝ առանց անվանակոչման այլ հղումներն անվավեր ճանաչելու:
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Տեղադրում է նոր ստեղնային արժեքի զույգ և edge, որոնք կգնան այդ նոր զույգի աջ կողմում այս edge-ի և այս edge-ի աջ կողմում գտնվող առանցքային արժեքի զույգի միջեւ:
    /// Այս մեթոդը ենթադրում է, որ հանգույցում բավականաչափ տեղ կա, որպեսզի նոր զույգը տեղավորվի:
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Տեղադրում է նոր ստեղնային արժեքի զույգ և edge, որոնք կգնան այդ նոր զույգի աջ կողմում այս edge-ի և այս edge-ի աջ կողմում գտնվող առանցքային արժեքի զույգի միջեւ:
    /// Այս մեթոդը բաժանում է հանգույցը, եթե բավարար տեղ չկա:
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Տեղադրում է ստեղնի արժեքի նոր զույգ այս edge-ի աջից և ձախից ստեղնային արժեքի զույգերի միջև:
    /// Այս մեթոդը բաժանում է հանգույցը, եթե բավարար տեղ չունի, և փորձում է պառակտված մասը ռեկուրսիվ կերպով ներդնել ծնողի հանգույցի մեջ, մինչև արմատը հասնի:
    ///
    ///
    /// Եթե վերադարձված արդյունքը `Fit` է, նրա բռնակի հանգույցը կարող է լինել այս edge հանգույցը կամ նախնին:
    /// Եթե վերադարձված արդյունքը `Split` է, `left` դաշտը կլինի արմատային հանգույցը:
    /// Վերադարձված ցուցիչը ցույց է տալիս տեղադրված արժեքը:
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Գտնում է այս edge-ի կողմից նշված հանգույցը:
    ///
    /// Մեթոդի անվանումը ենթադրում է, որ դուք պատկերում եք ծառեր, որոնց վերևում արմատային հանգույցն է:
    ///
    /// `edge.descend().ascend().unwrap()` և `node.ascend().unwrap().descend()`-ը, հաջողության հասնելու դեպքում, ոչինչ չպետք է անեն:
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Մենք պետք է հանգույցների համար օգտագործենք հում ցուցիչներ, քանի որ, եթե BorrowType-ը marker::ValMut է, կարող են լինել չմարված փոփոխական հղումներ արժեքներին, որոնք մենք չպետք է անվավեր ճանաչենք:
        // Բարձրության դաշտ մուտք գործելու համար անհանգստություն չկա, քանի որ այդ արժեքը պատճենվում է:
        // Գուշացեք, որ հանգույցի ցուցիչը չհետազոտելուց հետո մենք մուտք ենք գործում եզրերի զանգված հղումով (Rust թողարկում #73987) և անվավեր ենք համարում զանգվածի ներսում կամ դրա մեջ եղած ցանկացած այլ հղում, եթե գոյություն ունենա:
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Մենք չենք կարող զանգահարել առանցքային և արժեքի առանձին մեթոդներ, քանի որ երկրորդը կանչելը անվավեր է ճանաչում առաջինի կողմից վերադարձված տեղեկանքը:
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Փոխարինեք այն բանալին և արժեքը, որին վերաբերում է KV բռնիչը:
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Օգնում է `split`-ի իրականացմանը որոշակի `NodeType`-ի համար ՝ տերևային տվյալների խնամքով:
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Հիմքում գտնվող հանգույցը բաժանվում է երեք մասի.
    ///
    /// - Հանգույցը կտրված է ՝ այս բռնակի ձախ կողմում պարունակվող բանալիների արժեքի զույգերը միայն:
    /// - Այս բռնակի կողմից մատնանշված բանալին և արժեքը արդյունահանվում են:
    /// - Այս բռնակի աջ կողմում գտնվող առանցքային արժեքի բոլոր զույգերը դրվում են նոր բաշխված հանգույցում:
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Հեռացնում է այս բռնակի կողմից մատնանշված առանցքային արժեքի զույգը և վերադարձնում այն edge-ի հետ միասին, որի մեջ փլուզվել է բանալի-արժեքի զույգը:
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Հիմքում գտնվող հանգույցը բաժանվում է երեք մասի.
    ///
    /// - Հանգույցը կտրված է ՝ այս բռնակի ձախ կողմում միայն եզրերն ու բանալիի արժեքի զույգերը պարունակելու համար:
    /// - Այս բռնակի կողմից մատնանշված բանալին և արժեքը արդյունահանվում են:
    /// - Այս բռնակի աջ կողմում գտնվող բոլոր եզրերն ու ստեղնային արժեքի զույգերը դրվում են նոր հատկացված հանգույցի մեջ:
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Ներկայացնում է նստաշրջանը բանալին-արժեքի ներքին զույգի շուրջ հավասարակշռման գործողություն գնահատելու և կատարելու համար:
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Երեխայի ընթացքում հանգույցը ներգրավող հավասարակշռող համատեքստ է ընտրում, այդպիսով KV-ի միջև ծնողի հանգույցում անմիջապես ձախ կամ աջ:
    /// Վերադարձնում է `Err`, եթե ծնող չկա:
    /// Panics եթե ծնողը դատարկ է:
    ///
    /// Նախընտրում է ձախ կողմը `օպտիմալ լինելու համար, եթե տվյալ հանգույցը ինչ-որ կերպ թերի է, այսինքն` այստեղ միայն այն է, որ այն ավելի քիչ տարրեր ունի, քան իր ձախ քույրը և աջ քրոջը, եթե դրանք գոյություն ունեն:
    /// Այդ դեպքում ձախ քրոջը և քրոջը միաձուլումը ավելի արագ է, քանի որ մեզ անհրաժեշտ է տեղափոխել միայն հանգույցի N տարրերը, փոխարենը դրանք տեղափոխել դեպի աջ և տեղափոխել ավելի շատ N տարրեր, քան առջևում:
    /// Ձախ քրոջը կամ քրոջը գողությունը նույնպես սովորաբար ավելի արագ է, քանի որ մենք պետք է տեղափոխենք միայն հանգույցի N տարրերը դեպի աջ, փոխարենը քրոջ կամ քրոջ կամ էլեմենտի տարրերից գոնե ձախ տեղափոխենք:
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Վերադարձնում է `միաձուլումը հնարավոր է, այսինքն` արդյոք հանգույցում կա՞ արդյոք բավարար տեղ կենտրոնական KV-ն երկու հարակից մանկական հանգույցների հետ համատեղելու համար:
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Կատարում է միաձուլում և թույլ է տալիս փակմանը որոշել, թե ինչ է վերադարձնելու:
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Միավորված հանգույցների բարձրությունը բարձրությունից ցածր է
                // այս edge հանգույցի, այդպիսով զրոյից բարձր, այնպես որ դրանք ներքին են:
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Merնողի հիմնական արժեքի զույգը և հարակից երկու մանկական հանգույցները միաձուլում են ձախ երեխայի հանգույցի մեջ և վերադարձնում նեղացած ծնողական հանգույցը:
    ///
    ///
    /// Panics եթե մենք `.can_merge()` չենք:
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Միացնում է ծնողի հիմնական արժեքի զույգը և հարակից երկու մանկական հանգույցները ձախ երեխայի հանգույցում և վերադարձնում այդ մանկական հանգույցը:
    ///
    ///
    /// Panics եթե մենք `.can_merge()` չենք:
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Միաձուլում է ծնողի առանցքային արժեքի զույգը և հարակից մանկական հանգույցները ձախ երեխայի հանգույցում և վերադարձնում edge բռնիչը այդ երեխայի հանգույցում, որտեղ ավարտվել է հետևվող edge երեխան,
    ///
    ///
    /// Panics եթե մենք `.can_merge()` չենք:
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Ձախ երեխայից հեռացնում է առանցքային արժեքի զույգը և տեղադրում այն ծնողի հիմնական արժեքի պահեստում, մինչդեռ հին ծնողի հիմնական արժեքի զույգը մղում է ճիշտ երեխայի մեջ:
    ///
    /// Childիշտ երեխայի մեջ վերադարձնում է բռնիչը edge-ին, որը համապատասխանում է այնտեղ, որտեղ ավարտվել է `track_right_edge_idx`-ի կողմից նշված բնօրինակ edge-ն:
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Հեռացնում է առանցքային արժեքի զույգը աջ երեխայից և տեղադրում այն ծնողի հիմնական արժեքի պահեստում, մինչդեռ հին ծնողի հիմնական արժեքի զույգը մղում է ձախ երեխայի վրա:
    ///
    /// Վերադառնում է բռնակի edge-ին `track_left_edge_idx`-ի կողմից նշված ձախ երեխայի մեջ, որը չի շարժվել:
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Սա իրականում գողություն է, որը նման է `steal_left`-ին, բայց միանգամից գողանում է բազմաթիվ տարրեր:
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Համոզվեք, որ մենք կարող ենք անվտանգ գողություն կատարել:
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Տեղափոխեք տերևի տվյալները:
            {
                // Roomիշտ երեխայի մեջ տեղ բացեք գողացված տարրերի համար:
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Ձախ երեխայից տարրեր տեղափոխեք աջ:
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Տեղափոխեք ձախից ամենաշատ գողացված զույգը ծնողի մոտ:
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Տեղափոխեք ծնողի հիմնական արժեքի զույգը ճիշտ երեխայի վրա:
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Տեղ գողացված եզրերի համար:
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Գողանալ եզրեր:
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left`-ի սիմետրիկ կլոնը:
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Համոզվեք, որ մենք կարող ենք անվտանգ գողություն կատարել:
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Տեղափոխեք տերևի տվյալները:
            {
                // Տեղափոխեք ծնողից ճիշտ ամենաշատ գողացված զույգը:
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Տեղափոխեք ծնողի հիմնական արժեքի զույգը ձախ երեխայի վրա:
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Տեղափոխեք տարրեր աջ երեխայից ձախ:
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Լրացրեք բացը այնտեղ, որտեղ նախկինում եղել են գողացված տարրերը:
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Գողանալ եզրեր:
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Լրացրեք բացը այնտեղ, որտեղ նախկինում եղել են գողացված եզրերը:
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Հեռացնում է ցանկացած ստատիկ տեղեկատվություն ՝ պնդելով, որ այս հանգույցը `Leaf` հանգույց է:
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Հեռացնում է ցանկացած ստատիկ տեղեկատվություն ՝ պնդելով, որ այս հանգույցը `Internal` հանգույց է:
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Ստուգում է ՝ հիմքում ընկած հանգույցը `Internal` հանգույց է, թե `Leaf` հանգույց:
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self`-ից հետո ածանցը տեղափոխեք մի հանգույցից մյուսը: `right`-ը պետք է դատարկ լինի:
    /// `right`-ի առաջին edge-ը մնում է անփոփոխ:
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Տեղադրման արդյունք, երբ մի հանգույց անհրաժեշտ էր ընդլայնել իր կարողությունից վեր:
pub struct SplitResult<'a, K, V, NodeType> {
    // Փոփոխված հանգույց գոյություն ունեցող ծառի մեջ `kv`-ի ձախին պատկանող տարրերով և եզրերով:
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Որոշ բանալիներ և արժեքներ բաժանվում են և դրանք տեղադրվում են այլուր:
    pub kv: (K, V),
    // Պատկանող, չկապված, նոր հանգույց ՝ տարրերով և եզրերով, որոնք պատկանում են `kv` աջին:
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Արդյո՞ք այս փոխառության տիպի հանգույցների հղումները թույլ են տալիս ծառի մյուս հանգույցներին անցնել:
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Անցումը անհրաժեշտ չէ, դա տեղի է ունենում օգտագործելով `borrow_mut` արդյունքը:
        // Անջատելով անցումը և ստեղծելով միայն նոր հղումներ արմատներին, մենք գիտենք, որ `Owned` տիպի յուրաքանչյուր հղում արմատային հանգույցին է:
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Արժեքը զետեղում է սկզբնավորված տարրերի մի կտոր, որին հաջորդում է մեկ ոչ նախնական տարր:
///
/// # Safety
/// Կտորն ունի ավելի քան `idx` տարր:
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Հեռացնում և վերադարձնում է արժեքը նախաստորագրված բոլոր տարրերի կտորից ՝ հետևում թողնելով մեկ հետամնաց ոչ նախնական տարր:
///
///
/// # Safety
/// Կտորն ունի ավելի քան `idx` տարր:
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Տեղափոխում է տարրերը կտոր `distance` դիրքերում ձախ:
///
/// # Safety
/// Կտորն ունի առնվազն `distance` տարր:
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Տեղափոխում է տարրերը կտոր `distance` դիրքերում աջ:
///
/// # Safety
/// Կտորն ունի առնվազն `distance` տարր:
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Բոլոր արժեքները տեղափոխում է նախաստորագրված տարրերի կտորից դեպի ոչ նախնական տարրերի մի կտոր, հետևում թողնելով `src`-ը, քանի որ բոլորը ոչ նախնականացված են:
///
/// Աշխատում է ինչպես `dst.copy_from_slice(src)`, բայց չի պահանջում, որ `T` լինի `Copy`:
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;