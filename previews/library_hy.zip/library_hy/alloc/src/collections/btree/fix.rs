use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Բաժնետոմսերը հավաքում են հնարավոր թերակղզու հանգույցը ՝ միաձուլվելով կամ գողանալով եղբոր կամ քրոջից:
    /// Եթե հաջողակ է, բայց ծնող հանգույցը նեղացնելու գնով, վերադարձնում է այդ նեղացված մայր հանգույցը:
    /// Վերադարձնում է `Err`, եթե հանգույցը դատարկ արմատ է:
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Բաժնետոմսերը հնարավոր թերակատար հանգույց են հավաքում, և եթե դա հանգեցնում է նրա հիմնական հանգույցի նեղացմանը, կրկնօրինակում է ծնողի պաշարները:
    /// Վերադարձնում է `true`-ը, եթե այն շտկեց ծառը, `false`-ը, եթե դա չկարողացավ, քանի որ արմատային հանգույցը դատարկվեց:
    ///
    /// Այս մեթոդը չի ակնկալում, որ նախնիները մուտք գործելիս արդեն լիարժեք լինեն, և panics-ը, եթե բախվում է դատարկ նախնու հետ:
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Հեռացնում է վերին մասում գտնվող դատարկ մակարդակները, բայց պահում է դատարկ տերև, եթե ամբողջ ծառը դատարկ է:
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Բաժնետոմսերը վեր են միացվում կամ միաձուլվում են ծառի աջ եզրին գտնվող ցանկացած լիարժեք հանգույց:
    /// Մնացած հանգույցները, նրանք, որոնք արմատը չեն և ոչ էլ edge-ի ճիշտ տարբերակը, արդեն պետք է ունենան առնվազն MIN_LEN տարր:
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border`-ի սիմետրիկ կլոնը:
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Stockառի աջ եզրին պահեք ցանկացած լիարժեք հանգույց:
    /// Մնացած հանգույցները, նրանք, որոնք արմատը չեն և ոչ էլ edge-ի ճիշտ տարբերակը, պետք է պատրաստ լինեն մինչև MIN_LEN տարր գողանալու համար:
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Ստուգեք, արդյոք ճիշտ երեխան շատ թերի է:
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Պետք է գողանալ:
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Գնացեք ավելի ներքև:
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Ձախ երեխային բաժնետոմսեր է տալիս ՝ ենթադրելով, որ աջ երեխան թերի է, և նախատեսում է լրացուցիչ տարր, որը թույլ է տալիս իր երեխաներին հերթով միաձուլել ՝ առանց թերի դառնալու:
    ///
    /// Վերադառնում է ձախ երեխային:
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` խուսափել կարգաբերումից, եթե միաձուլումը տեղի ունենա հաջորդ մակարդակում:
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Childիշտ երեխայի պաշարները հավաքում են ՝ ենթադրելով, որ ձախ երեխան թերի է, և նախատեսում է լրացուցիչ տարր, որը թույլ է տալիս իր երեխաներին հերթով միաձուլել ՝ առանց թերի դառնալու:
    ///
    /// Վերադառնում է այնտեղ, որտեղ հայտնվել է ճիշտ երեխան:
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` խուսափել կարգաբերումից, եթե միաձուլումը տեղի ունենա հաջորդ մակարդակում:
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}