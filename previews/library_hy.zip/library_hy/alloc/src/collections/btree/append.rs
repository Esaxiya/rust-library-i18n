use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Երկու վեր բարձրանող կրկնիչների միավորումից միացնում է առանցքային արժեքի բոլոր զույգերը ՝ ճանապարհին ավելացնելով `length` փոփոխական: Վերջինս հեշտացնում է զանգահարողի համար խուսափել արտահոսքից, երբ կաթիլը կարգավորողը խուճապի է մատնվում:
    ///
    /// Եթե երկու կրկնիչներն էլ արտադրում են նույն բանալին, այս մեթոդը զույգը նետում է ձախ կրկնորդից և զույգը ավելացնում աջ կրկնիչից:
    ///
    /// Եթե ուզում եք, որ ծառը հայտնվի խիստ աճման կարգով, ինչպես `BTreeMap`-ի դեպքում, երկու կրկնորդներն էլ պետք է արտադրեն ստանդարտ աճող կարգի բանալիներ, յուրաքանչյուրը ավելի մեծ է, քան ծառի բոլոր ստեղները, ներառյալ մուտքի պահին արդեն ծառի մեջ եղած ցանկացած բանալին:
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Մենք պատրաստվում ենք միաձուլել `left`-ը և `right`-ը տեսակավորված հաջորդականության մեջ գծային ժամանակում:
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Միևնույն ժամանակ, մենք դասավորված հաջորդականությունից ծառ ենք կառուցում գծային ժամանակում:
        self.bulk_push(iter, length)
    }

    /// Բոլոր հիմնական զույգերի զույգերը մղում է ծառի վերջը ՝ ճանապարհին ավելացնելով `length` փոփոխական:
    /// Վերջինս հեշտացնում է զանգահարողի համար խուսափել արտահոսքից, երբ կրկնիչը խուճապի է մատնվում:
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Կրկնեք առանցքային արժեքի բոլոր զույգերը ՝ դրանք մղելով ճիշտ մակարդակի հանգույցների մեջ:
        for (key, value) in iter {
            // Փորձեք առանցքային արժեքի զույգը մղել ընթացիկ տերևային հանգույցի մեջ:
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Տեղ չի մնացել, վերև բարձրանալ և հրել այնտեղ:
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Գտավ մի հանգույց, որտեղ մնացել է տարածություն, սեղմեք այստեղ:
                                open_node = parent;
                                break;
                            } else {
                                // Նորից վեր բարձրանալ
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Մենք վերևում ենք, ստեղծում ենք նոր արմատային հանգույց և հրում այնտեղ:
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Հրել ստեղնային արժեքի զույգը և նոր աջ տրոհը:
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Կրկին իջեք աջից ամենա աջ տերևը:
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Յուրաքանչյուր կրկնություն ավելացրեք երկարությամբ ՝ համոզվելու համար, որ քարտեզը կթողնի կցված տարրերը, նույնիսկ եթե կրկնիչը խուճապի մատնվելու դեպքում:
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Երկու դասավորված հաջորդականությունները մեկում միավորելու կրկնիչ
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Եթե երկու ստեղներ հավասար են, ստեղնի արժեքի զույգը վերադարձնում է ճիշտ աղբյուրից:
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}