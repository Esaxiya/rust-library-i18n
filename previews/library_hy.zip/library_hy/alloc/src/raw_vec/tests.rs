use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Երրորդ կողմի հատկացիչների և `RawVec`-ի ինտեգրման փորձ գրելը մի փոքր բարդ է, քանի որ `RawVec` API-ը չի բացահայտում բաշխման սխալ եղանակները, ուստի մենք չենք կարող ստուգել, թե ինչ է տեղի ունենում, երբ բաշխիչը սպառվում է (panic-ի հայտնաբերումից վեր):
    //
    //
    // Փոխարենը, սա պարզապես ստուգում է, որ `RawVec` մեթոդները գոնե անցնում են Allocator API-ով, երբ այն պահուստավորում է պահպանում:
    //
    //
    //
    //
    //

    // Համր բաշխիչ, որը սպառում է վառելիքի ֆիքսված քանակը, նախքան բաշխման փորձերը սկսեն ձախողվել:
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (առաջացնում է վերաբաշխում ՝ այդպիսով օգտագործելով 50 + 150=200 միավոր վառելիք)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Նախ, `reserve`-ը հատկացնում է ինչպես `reserve_exact`-ը:
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97-ը 7-ի կրկնապատիկից ավելին է, ուստի `reserve`-ը պետք է աշխատի `reserve_exact`-ի նման:
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3-ը 12-ի կեսից պակաս է, ուստի `reserve`-ը պետք է էքսպոնենցիալ աճի:
        // Այս թեստը գրելու պահին աճի գործակիցը 2 է, ուստի նոր հզորությունը 24 է, սակայն 1.5 աճի գործոնը նույնպես նորմալ է:
        //
        // Ուստի պնդում է `>= 18`-ը:
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}