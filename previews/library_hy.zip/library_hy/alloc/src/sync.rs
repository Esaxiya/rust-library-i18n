#![stable(feature = "rust1", since = "1.0.0")]

//! Թելերի անվտանգ տեղեկանքների հաշվարկի ցուցիչներ:
//!
//! Տեսեք [`Arc<T>`][Arc] փաստաթղթերը `ավելի մանրամասն:

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Փափուկ սահմանափակում այն հղումների քանակի վերաբերյալ, որոնք կարող են կատարվել `Arc`-ին:
///
/// Այս սահմանից վեր անցնելը կդադարեցնի ձեր ծրագիրը (չնայած պարտադիր չէ) _exactly_ `MAX_REFCOUNT + 1` հղումներով:
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer-ը չի աջակցում հիշողության ցանկապատերը:
// Arc/Թույլ իրականացման մեջ կեղծ դրական զեկույցներից խուսափելու համար փոխարենը օգտագործեք ատոմային բեռներ համաժամացման համար:
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Թելային անվտանգ տեղեկանք հաշվիչ ցուցիչ: 'Arc' նշանակում է «Atomically Reference Counted»:
///
/// `Arc<T>` տեսակը ապահովում է կույտով բաշխված `T` տիպի արժեքի ընդհանուր սեփականություն: [`clone`][clone]-ի վրա [`clone`][clone]-ի վրա կանչելը առաջացնում է նոր `Arc` օրինակ, որը մատնանշում է կույտի նույն բաշխումը, ինչ աղբյուրը `Arc`, միևնույն ժամանակ ավելացնելով տեղեկանքի քանակը:
/// Երբ տվյալ բաշխման վերջին `Arc` ցուցիչը ոչնչացվում է, այդ հատկացման մեջ պահվող արժեքը (հաճախ անվանում են "inner value") նույնպես իջնում է:
///
/// Rust-ի համօգտագործված հղումները լռելյայնորեն արգելում են մուտացիան, և `Arc`-ը բացառություն չէ. Ընդհանուր առմամբ չեք կարող ձեռք բերել փոփոխվող հղում `Arc`-ի ներսում գտնվող ինչ-որ բանի: Եթե Ձեզ անհրաժեշտ է մուտացիա կատարել `Arc`-ի միջոցով, օգտագործեք [`Mutex`][mutex], [`RwLock`][rwlock] կամ [`Atomic`][atomic] տեսակներից մեկը:
///
/// ## Թելքի անվտանգություն
///
/// Ի տարբերություն [`Rc<T>`]-ի, `Arc<T>`-ն իր տեղեկանքի հաշվարկի համար օգտագործում է ատոմային գործողություններ: Սա նշանակում է, որ այն անվտանգ է թելերով:Անբարենպաստությունն այն է, որ ատոմային գործողություններն ավելի թանկ են, քան սովորական հիշողության մուտքերը:Եթե դուք չեք կիսում հղումների հաշվարկով հատկացումները թելերի միջև, հաշվի առեք [`Rc<T>`]-ի ստորին գլխաքանակի համար:
/// [`Rc<T>`] անվտանգ կանխադրված է, քանի որ կազմողը կփորձի թելերի միջև [`Rc<T>`] ուղարկելու ցանկացած փորձ:
/// Այնուամենայնիվ, գրադարանը կարող է ընտրել `Arc<T>`, որպեսզի գրադարանների սպառողներին ավելի ճկունություն ցուցաբերի:
///
/// `Arc<T>` կիրականացնի [`Send`] և [`Sync`] այնքան ժամանակ, քանի դեռ `T`-ն իրականացնում է [`Send`] և [`Sync`]:
/// Ինչու չես կարող `T`-ի մեջ տեղադրել ոչ թելերով անվտանգ տիպի `T` տիպ ՝ այն թելից անվտանգ դարձնելու համար: Սկզբում սա կարող է մի փոքր հակաինտուիտիվ լինել. Չէ՞ որ `Arc<T>` թելի անվտանգության կետը:Բանալին սա է. `Arc<T>`-ն անվտանգ է դարձնում միևնույն տվյալների բազմակի սեփականություն ունենալը, բայց դա չի ավելացնում իր տվյալների շղթայի անվտանգություն:
///
/// Հաշվի առեք `Arc <" ["RefCell<T>`]">":
/// [`RefCell<T>`] [`Sync`] չէ, և եթե `Arc<T>`-ը միշտ [`Send`] էր, ապա Arc <"[" RefCell<T>`]"> նույնպես կլիներ:
/// Բայց հետո մենք խնդիր կունենայինք.
/// [`RefCell<T>`] թելից անվտանգ չէ;այն հետևում է փոխառությունների քանակին ՝ օգտագործելով ոչ ատոմային գործողություններ:
///
/// Ի վերջո, սա նշանակում է, որ ձեզ կարող է անհրաժեշտ լինել զուգակցել `Arc<T>` մի տեսակ [`std::sync`] տիպի, սովորաբար [`Mutex<T>`][mutex]:
///
/// ## Կոտրելու ցիկլեր `Weak`-ի հետ
///
/// [`downgrade`][downgrade] մեթոդը կարող է օգտագործվել ոչ սեփականատեր [`Weak`] ցուցիչ ստեղծելու համար: [`Weak`] ցուցիչը կարող է [«արդիականացնել»][նորացնել] d `Arc`-ով, բայց սա կվերադարձնի [`None`], եթե բաշխման մեջ պահված արժեքն արդեն իջել է:
/// Այլ կերպ ասած, `Weak` ցուցիչները կենդանի չեն պահում բաշխման արժեքը: այնուամենայնիվ, նրանք * պահպանում են հատկացումը (արժեքի պահուստային խանութը) կենդանի:
///
/// `Arc` ցուցիչների միջեւ ցիկլը երբեք չի բաշխվի:
/// Այդ պատճառով [`Weak`]-ն օգտագործվում է ցիկլերը կոտրելու համար: Օրինակ ՝ ծառը կարող է ունենալ ուժեղ `Arc` ցուցիչներ ծնող հանգույցներից մինչև երեխաներ, իսկ [`Weak`] ցուցիչներ երեխաներից ՝ իրենց ծնողներին:
///
/// # Կլոնավորման հղումներ
///
/// Գոյություն ունեցող տեղեկանքով հաշվարկված ցուցիչից նոր հղում ստեղծելը կատարվում է [`Arc<T>`][Arc] և [`Weak<T>`][Weak]-ի համար ներդրված `Clone` trait-ի միջոցով:
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ստորև ներկայացված երկու շարահյուսությունները համարժեք են:
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b և foo բոլոր աղեղներն են, որոնք մատնանշում են հիշողության նույն վայրը
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ավտոմատ կերպով հետ կանչում `T`-ը ([`Deref`][deref] trait-ի միջոցով), այնպես որ կարող եք զանգահարել «T»-ի մեթոդները `Arc<T>` տիպի արժեքի վրա: «T»-ի մեթոդների հետ անունների բախումներից խուսափելու համար `Arc<T>`-ի մեթոդներն ինքնին կապված գործառույթներ են, որոնք կոչվում են `օգտագործելով [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Աղեղ<T>`Clone`-ի նման traits-ի ներդրումները կարող են նաև կոչվել`օգտագործելով լիովին որակավորված շարահյուսություն:
/// Որոշ մարդիկ նախընտրում են օգտագործել լիովին որակավորված շարահյուսություն, իսկ ոմանք էլ նախընտրում են օգտագործել մեթոդ զանգի շարահյուսություն:
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Մեթոդ-զանգի շարահյուսություն
/// let arc2 = arc.clone();
/// // Լիովին որակավորված շարահյուսություն
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] չի ավտոմատ կերպով վերահեռնում `T`-ին, քանի որ ներքին արժեքը կարող է արդեն իջել:
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Թելերի միջև որոշ անփոփոխ տվյալների փոխանակում.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Նկատի ունեցեք, որ մենք **չենք** վարում այս թեստերը այստեղ:
// windows կոնստրուկտորները չափազանց դժգոհ են դառնում, եթե շարանը գոյատևի հիմնական շարանը և այնուհետև դուրս գա միևնույն ժամանակ (ինչ-որ փակուղի), այնպես որ մենք պարզապես խուսափում ենք դրանից ՝ չանցնելով այս թեստերը:
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Փոխադարձ [`AtomicUsize`]-ի փոխանակում.
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Տեսեք [`rc` documentation][rc_examples]-ը, ընդհանուր առմամբ, հղումների հաշվարկի ավելի շատ օրինակների համար:
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`]-ի մի տարբերակ է, որը պահպանում է կառավարվող բաշխումը ոչ սեփականատեր:
/// Հատկացումը հասանելի է [`upgrade`] `Weak` ցուցիչի վրա զանգահարելով, որը վերադարձնում է [«Տարբերակ»] «<« [«Կամար»]<T>> "
///
/// Քանի որ `Weak` տեղեկանքը չի համարվում սեփականության իրավունքը, դա չի խանգարի հատկացման մեջ պահված արժեքի իջեցմանը, և `Weak`-ը ինքը երաշխիքներ չի տալիս այն արժեքի վերաբերյալ, որը դեռ առկա է:
///
/// Այսպիսով, այն կարող է վերադարձնել [`None`], երբ [«արդիականացնել»] դ.
/// Այնուամենայնիվ, նշեք, որ `Weak` հղումը *չի* թույլ տալիս բաշխումը (պահուստային խանութը) տեղաբաշխել:
///
/// `Weak` ցուցիչը օգտակար է [`Arc`]-ի կողմից կառավարվող հատկացմանը ժամանակավոր տեղեկանք պահելու համար `առանց կանխելու դրա ներքին արժեքի անկումը:
/// Այն նաև օգտագործվում է կանխելու [`Arc`] ցուցիչների շրջանաձև հղումները, քանի որ փոխադարձ սեփականության հղումները երբեք թույլ չեն տա որևէ [`Arc`] իջնել:
/// Օրինակ ՝ ծառը կարող է ունենալ ուժեղ [`Arc`] ցուցիչներ ծնողական հանգույցներից մինչև երեխաներ, և `Weak` ցուցիչներ երեխաներից ՝ իրենց ծնողներին:
///
/// `Weak` ցուցիչ ձեռք բերելու բնորոշ եղանակը [`Arc::downgrade`] զանգահարելն է:
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Սա `NonNull` է ՝ թույլ տալու համար այս տեսակի չափերը օպտիմալացնել հաշվարկներում, բայց պարտադիր չէ, որ այն վավեր ցուցիչ լինի:
    //
    // `Weak::new` սա սահմանում է `usize::MAX`, այնպես, որ անհրաժեշտ լինի կույտի վրա տարածք հատկացնել:
    // Դա արժեք չէ, որ իսկական ցուցիչը երբևէ ունենա, քանի որ RcBox-ն ունի հավասարեցում առնվազն 2-ի:
    // Դա հնարավոր է միայն այն դեպքում, երբ `T: Sized`;մեծ չափսի `T`-ը երբեք չի կախվում:
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Սա repr(C)-ից future-ի դիմացկուն է հնարավոր դաշտի վերադասավորման դեմ, ինչը խոչընդոտում է այլ կերպ անվտանգ [into|from]_raw() փոփոխական ներքին տեսակների:
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX արժեքը պահպանում է ժամանակավորապես "locking"-ի թույլ ցուցիչները արդիացնելու կամ ուժեղ դիրքերը վարկանիշի իջեցնելու ունակությունը.սա օգտագործվում է `make_mut` և `get_mut`-ում ցեղերից խուսափելու համար:
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Կառուցում է նոր `Arc<T>`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Սկսեք ցուցիչի թույլ հաշվարկը 1-ով, որը թույլ ցուցիչն է, որը պահվում է բոլոր ուժեղ ցուցիչների (kinda)-ի համար, տես std/rc.rs հավելյալ տեղեկությունների համար
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Կառուցում է նոր `Arc<T>` ՝ օգտագործելով ինքն իրեն թույլ հղում:
    /// Այս ֆունկցիայի վերադարձից առաջ թույլ հղումը թարմացնելու փորձը կհանգեցնի `None` արժեքի:
    /// Այնուամենայնիվ, թույլ տեղեկանքը կարող է ազատ կլոնավորվել և պահվել ավելի ուշ օգտագործման համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ներքինը կառուցեք "uninitialized" վիճակում ՝ մեկ թույլ հղումով:
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Կարևոր է, որ մենք չհրաժարվենք թույլ ցուցիչի սեփականությունից, հակառակ դեպքում հիշողությունը կարող է ազատվել մինչ `data_fn`-ի վերադարձը:
        // Եթե մենք իսկապես ուզում էինք փոխանցել սեփականությունը, ապա կարող էինք ստեղծել մեզ համար թույլ թույլ ցուցիչ, բայց դա կհանգեցներ թույլ տեղեկանքի թույլատրելի հաշվարկի լրացուցիչ թարմացումների, որոնք այլապես կարող էին անհրաժեշտ չլինել:
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Այժմ մենք կարող ենք պատշաճ կերպով նախաստորագրել ներքին արժեքը և մեր թույլ հղումը վերածել ուժեղ տեղեկանքի:
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Տվյալների դաշտում վերը նշված գրառումը պետք է տեսանելի լինի ցանկացած զրոյի, որը դիտում է ոչ զրոյական ուժեղ հաշվարկ:
            // Ուստի մեզ անհրաժեշտ է առնվազն "Release" պատվեր ՝ `Weak::upgrade`-ում `compare_exchange_weak`-ի հետ համաժամեցնելու համար:
            //
            // "Acquire" պատվիրելը պարտադիր չէ
            // Երբ հաշվի ենք առնում `data_fn`-ի հնարավոր վարքագիծը, մենք միայն պետք է նայենք, թե ինչ կարող է դա անել `չվերափոխվող `Weak`-ի վրա հղումով.
            //
            // - Այն կարող է *կլոնավորել*`Weak`-ը ՝ ավելացնելով թույլ տեղեկանքի քանակը:
            // - Այն կարող է թողնել այդ կլոնները ՝ նվազեցնելով թույլ տեղեկանքի քանակը (բայց ոչ երբեք զրոյի):
            //
            // Այս կողմնակի ազդեցությունները ոչ մի կերպ չեն ազդում մեզ վրա, և ոչ մի այլ կողմնակի ազդեցություն հնարավոր չէ միայն անվտանգ կոդով:
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Ուժեղ հղումները պետք է հավաքականորեն ունենան ընդհանուր թույլ հղում, այնպես որ մի օգտագործեք քայքայիչը մեր հին թույլ տեղեկանքի համար:
        //
        mem::forget(weak);
        strong
    }

    /// Կառուցում է նոր `Arc` ՝ ոչ սկզբնական բովանդակությամբ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Կառուցում է նոր `Arc` ՝ ոչ սկզբնական բովանդակությամբ, հիշողությունը լցված է `0` բայթով:
    ///
    ///
    /// Տե՛ս [`MaybeUninit::zeroed`][zeroed] ՝ այս մեթոդի ճիշտ և սխալ օգտագործման օրինակների համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Կառուցում է նոր `Pin<Arc<T>>`:
    /// Եթե `T`-ը չի իրականացնում `Unpin`, ապա `data`-ը կապվում է հիշողության մեջ և չի կարող տեղափոխվել:
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Կառուցում է նոր `Arc<T>`, եթե բաշխումը ձախողվում է, սխալ է վերադարձնում:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Սկսեք ցուցիչի թույլ հաշվարկը 1-ով, որը թույլ ցուցիչն է, որը պահվում է բոլոր ուժեղ ցուցիչների (kinda)-ի համար, տես std/rc.rs հավելյալ տեղեկությունների համար
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Կառուցում է նոր `Arc` ՝ ոչ նախնականացված բովանդակությամբ, եթե բաշխումը ձախողվում է, սխալ է վերադարձնում:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Կառուցում է նոր `Arc` ՝ ոչ նախնականացված բովանդակությամբ, հիշողությունը լցվում է `0` բայթով, եթե բաշխումը ձախողվում է, սխալ է վերադարձնում:
    ///
    ///
    /// Տե՛ս [`MaybeUninit::zeroed`][zeroed] ՝ այս մեթոդի ճիշտ և սխալ օգտագործման օրինակների համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Վերադարձնում է ներքին արժեքը, եթե `Arc`-ն ունի մեկ ուժեղ հղում:
    ///
    /// Հակառակ դեպքում, [`Err`]-ը վերադարձվում է նույն `Arc`-ով, որը փոխանցվել է:
    ///
    ///
    /// Դա հաջողության կհասնի նույնիսկ եթե կան ակնառու թույլ հղումներ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Թույլ ցուցիչ պատրաստեք `անուղղակի ուժեղ-թույլ հղումը մաքրելու համար
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Կառուցում է ատոմային տեղեկանքով հաշվարկված նոր կտոր ՝ ոչ նախնական բովանդակությամբ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Կառուցում է ատոմային տեղեկանքով հաշվարկված նոր կտոր ՝ ոչ սկզբնական բովանդակությամբ, հիշողությունը լցված է `0` բայթով:
    ///
    ///
    /// Տե՛ս [`MaybeUninit::zeroed`][zeroed] ՝ այս մեթոդի ճիշտ և սխալ օգտագործման օրինակների համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Փոխակերպվում է `Arc<T>`-ի:
    ///
    /// # Safety
    ///
    /// Ինչպես [`MaybeUninit::assume_init`]-ի դեպքում, զանգահարողը մնում է երաշխավորել, որ ներքին արժեքն իսկապես գտնվում է նախաստորագրված վիճակում:
    ///
    /// Այս մասին զանգելը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է անհապաղ անորոշ վարք:
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Փոխակերպվում է `Arc<[T]>`-ի:
    ///
    /// # Safety
    ///
    /// Ինչպես [`MaybeUninit::assume_init`]-ի դեպքում, զանգահարողը մնում է երաշխավորել, որ ներքին արժեքն իսկապես գտնվում է նախաստորագրված վիճակում:
    ///
    /// Այս մասին զանգելը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է անհապաղ անորոշ վարք:
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Հետաձգված նախնական հայտարարում.
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Սպառում է `Arc`-ը ՝ վերադարձնելով փաթաթված ցուցիչը:
    ///
    /// Հիշողության արտահոսքից խուսափելու համար ցուցիչը պետք է վերափոխվի `Arc` ՝ օգտագործելով [`Arc::from_raw`]:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Տրամադրում է տվյալների հում ցուցիչ:
    ///
    /// Հաշվարկները ոչ մի կերպ չեն ազդում, և `Arc`-ը չի սպառվում:
    /// Սլաքը վավեր է այնքան ժամանակ, քանի դեռ `Arc`-ում ուժեղ հաշվարկներ կան:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա չի կարող անցնել Deref::deref կամ RcBoxPtr::inner, քանի որ
        // սա պահանջվում է raw/mut ծագումը պահպանելու համար այնպես, որ օր
        // `get_mut` կարող է գրել ցուցիչի միջոցով Rc-ի `from_raw`-ի վերականգնումից հետո:
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Կառուցում է `Arc<T>` հում ցուցիչից:
    ///
    /// Հում ցուցիչը պետք է նախկինում վերադարձված լիներ [`Arc<U>::into_raw`][into_raw]-ի զանգով, որտեղ `U`-ը պետք է ունենա նույն չափը և հավասարեցումը, ինչպես `T`-ը:
    /// Սա տրիվիալ է, եթե `U`-ը `T` է:
    /// Նկատի ունեցեք, որ եթե `U`-ը `T` չէ, բայց ունի նույն չափը և հավասարեցումը, դա հիմնականում նման է տարբեր տեսակի հղումների փոխակերպմանը:
    /// Տե՛ս [`mem::transmute`][transmute] ՝ հավելյալ տեղեկություններ ստանալու համար, թե ինչ սահմանափակումներ են կիրառվում այս դեպքում:
    ///
    /// `from_raw` օգտագործողը պետք է համոզվի, որ `T`-ի որոշակի արժեքը միայն մեկ անգամ է ընկնում:
    ///
    /// Այս գործառույթն անապահով է, քանի որ ոչ պատշաճ օգտագործումը կարող է հանգեցնել հիշողության անապահովության, նույնիսկ եթե վերադարձված `Arc<T>`-ին երբեք մուտք չեն գործել:
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Վերադարձեք `Arc` ՝ արտահոսքը կանխելու համար:
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Հետագա զանգերը դեպի `Arc::from_raw(x_ptr)` կլինեն հիշողություն անվտանգ:
    /// }
    ///
    /// // Հիշողությունը ազատվեց, երբ `x`-ը դուրս եկավ վերը նշված տիրույթից, ուստի `x_ptr`-ն այժմ կախված է:
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Հակադարձեք օֆսեթը ՝ գտնելու բնօրինակը ArcInner:
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Այս բաշխման համար ստեղծում է նոր [`Weak`] ցուցիչ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Այս հանգստացածը նորմալ է, քանի որ մենք ստուգում ենք ստորև նշված CAS-ի արժեքը:
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ստուգեք, արդյոք թույլ հաշվիչը ներկայումս "locked" է;եթե այդպես է, պտտվի՛ր:
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: այս կոդը ներկայումս անտեսում է ջրհեղեղի հնարավորությունը
            // մեջ usize::MAX;ընդհանուր առմամբ և Rc-ն, և Arc-ը պետք է ճշգրտվեն `ջրհեղեղի դեմ պայքարելու համար:
            //

            // Ի տարբերություն Clone()-ի, մեզ անհրաժեշտ է, որ սա լինի «Ձեռք բերելու» ընթերցում `is_unique`-ից եկող գրության հետ համաժամացման համար, որպեսզի այդ գրառմանը նախորդող իրադարձությունները տեղի ունենան մինչև այս ընթերցումը:
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Համոզվեք, որ մենք չենք ստեղծում կախովի թույլ
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ստանում է այս բաշխման [`Weak`] ցուցիչների քանակը:
    ///
    /// # Safety
    ///
    /// Այս մեթոդն ինքնին անվտանգ է, բայց դրա ճիշտ օգտագործումը լրացուցիչ խնամք է պահանջում:
    /// Մեկ այլ թեմա կարող է ցանկացած պահի փոխել թույլ թվաքանակը, այդ թվում `այս մեթոդը զանգահարելու և արդյունքի վրա ազդելու միջև:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Այս պնդումը որոշիչ է, քանի որ մենք չենք կիսել `Arc` կամ `Weak` թելերի միջև:
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Եթե թույլ հաշվարկը ներկայումս կողպված է, ապա հաշվարկի արժեքը 0-ն էր հենց կողպեքը վերցնելուց առաջ:
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ստանում է այս տեղաբաշխման ուժեղ (`Arc`) ցուցիչների քանակը:
    ///
    /// # Safety
    ///
    /// Այս մեթոդն ինքնին անվտանգ է, բայց դրա ճիշտ օգտագործումը լրացուցիչ խնամք է պահանջում:
    /// Մեկ այլ թեմա կարող է ցանկացած պահի փոխել ուժեղ հաշվարկը, ներառյալ ՝ այս մեթոդը զանգահարելու և արդյունքի վրա ազդելու միջև:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Այս պնդումը որոշիչ է, քանի որ մենք `Arc`-ը չենք կիսել թելերի միջև:
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Տրված ցուցիչի հետ կապված `Arc<T>`-ի ուժեղ տեղեկանքի քանակը մեկով ավելացնում է:
    ///
    /// # Safety
    ///
    /// Սլաքը պետք է ստացված լինի `Arc::into_raw`-ի միջոցով, և դրա հետ կապված `Arc` օրինակը պետք է վավեր լինի (այսինքն
    /// ուժեղ հաշվարկը պետք է լինի առնվազն 1) այս մեթոդի տևողության համար:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Այս պնդումը որոշիչ է, քանի որ մենք `Arc`-ը չենք կիսել թելերի միջև:
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Պահպանեք Arc-ը, բայց մի հպեք վերահաշվարկին ՝ ManualDrop-ով փաթաթելով
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Այժմ ավելացրեք վերահաշվարկը, բայց և նոր գանձում մի գցեք
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Տրված ցուցիչի հետ կապված `Arc<T>`-ի ուժեղ տեղեկանքի քանակը մեկ առ մեկ իջեցնում է:
    ///
    /// # Safety
    ///
    /// Սլաքը պետք է ստացված լինի `Arc::into_raw`-ի միջոցով, և դրա հետ կապված `Arc` օրինակը պետք է վավեր լինի (այսինքն
    /// ուժեղ մեթոդը պետք է լինի առնվազն 1) այս մեթոդը վկայակոչելիս:
    /// Այս մեթոդը կարող է օգտագործվել վերջնական `Arc`-ի և պահուստային պահուստը ազատելու համար, բայց **չպետք է** կանչվի վերջնական `Arc`-ի թողարկումից հետո:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Այդ պնդումները որոշիչ են, քանի որ մենք `Arc`-ը չենք կիսել թելերի միջև:
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Այս անապահովությունը կարգին է, քանի որ մինչ այս աղեղը կենդանի է, մենք երաշխավորված ենք, որ ներքին ցուցիչը վավեր է:
        // Ավելին, մենք գիտենք, որ `ArcInner` կառուցվածքն ինքնին `Sync` է, քանի որ ներքին տվյալները նույնպես `Sync` են, ուստի մենք կարգին ենք վարկեր տրամադրել այս բովանդակության անփոփոխ ցուցիչով:
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop`-ի ոչ ընդգծված մասը:
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Այս պահին ոչնչացրեք տվյալները, չնայած մենք կարող ենք չազատել տուփի բաշխումը ինքն իրեն (կարող է դեռ կան թույլ ցուցիչներ):
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Նետեք թույլ հղումը, որը հավաքվում է բոլոր ուժեղ հղումներով
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Վերադարձնում է `true`, եթե երկու Arc-ը նշում են միևնույն բաշխումը ([`ptr::eq`]-ի նման երակով):
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Հատկացնում է `ArcInner<T>`-ը ՝ բավարար տարածություն ունենալով հնարավոր չափի չհամապատասխանող ներքին արժեքի համար, որտեղ արժեքն ունի տրամադրված դասավորությունը:
    ///
    /// `mem_to_arcinner` գործառույթը կանչվում է տվյալների ցուցիչի հետ և պետք է հետ վերադարձնի (պոտենցիալ ճարպի) ցուցիչ `ArcInner<T>`-ի համար:
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Հաշվիր դասավորությունը ՝ օգտագործելով տրված արժեքի դասավորությունը:
        // Նախկինում դասավորությունը հաշվարկվում էր `&*(ptr as* const ArcInner<T>)` արտահայտության վրա, բայց դա ստեղծեց սխալ ուղղորդում (տե՛ս #54908):
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Բաշխում է `ArcInner<T>`-ը `բավարար տարածություն հավանական չափի չհամապատասխանող ներքին արժեքի համար, որտեղ արժեքը տրամադրում է դասավորությունը, եթե բաշխումը ձախողվում է, վերադարձնում է սխալ:
    ///
    ///
    /// `mem_to_arcinner` գործառույթը կանչվում է տվյալների ցուցիչի հետ և պետք է հետ վերադարձնի (պոտենցիալ ճարպի) ցուցիչ `ArcInner<T>`-ի համար:
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Հաշվիր դասավորությունը ՝ օգտագործելով տրված արժեքի դասավորությունը:
        // Նախկինում դասավորությունը հաշվարկվում էր `&*(ptr as* const ArcInner<T>)` արտահայտության վրա, բայց դա ստեղծեց սխալ ուղղորդում (տե՛ս #54908):
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Նախաձեռնեք ArcInner-ը
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Հատկացում է `ArcInner<T>` ՝ բավարար տարածություն անխափան ներքին արժեքի համար:
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Հատկացրեք `ArcInner<T>`-ի համար ՝ օգտագործելով տրված արժեքը:
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Պատճենել արժեքը որպես բայթ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Ազատեք հատկացումը ՝ առանց դրա բովանդակությունը գցելու
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Տրված երկարությամբ հատկացնում է `ArcInner<[T]>`:
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Պատճենել տարրերը կտորից նոր հատկացված Arc <\[T\]>-ի մեջ
    ///
    /// Անվտանգ, քանի որ զանգահարողը կամ պետք է տիրանա սեփականությանը, կամ կապի `T: Copy`-ին:
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// `Arc<[T]>`-ը կառուցում է որոշակի չափի հայտնի կրկնիչից:
    ///
    /// Վարքի պահպանումը սահմանված չէ, եթե չափը սխալ լինի:
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Z տարրերը կլոնավորելու ժամանակ Panic պահակ:
        // panic-ի դեպքում նոր ArcInner-ում գրված տարրերը կթողարկվեն, ապա հիշողությունը կազատվի:
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Poուցանակ առաջին տարրից
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Ամեն ինչ պարզ է.Մոռացեք պահակին, որպեսզի այն չազատագրի նոր ArcInner-ին:
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>`-ի համար օգտագործվող մասնագիտացում trait:
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Կատարում է `Arc` ցուցիչի կլոն:
    ///
    /// Սա ստեղծում է նույն բաշխման մեկ այլ ցուցիչ ՝ ավելացնելով ուժեղ տեղեկանքի քանակը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Հանգիստ պատվեր օգտագործելը այստեղ լավ է, քանի որ բնօրինակ հղման մասին գիտելիքը խանգարում է այլ թելերին սխալ կերպով ջնջել առարկան:
        //
        // Ինչպես բացատրվել է [Boost documentation][1]-ում, հղումների հաշվիչի ավելացումը միշտ կարող է կատարվել հիշողություն_հասարակ_հանգստացմամբ. Օբյեկտի վերաբերյալ նոր հղումները կարող են կազմվել միայն գոյություն ունեցող հղումից, և առկա հղումը մեկ թեմայից մյուսը փոխանցելը արդեն պետք է ապահովի ցանկացած պահանջվող համաժամացում:
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Այնուամենայնիվ, մենք պետք է զգուշանանք զանգվածային վերահաշվարկներից, եթե ինչ-որ մեկը «մոռանում է» կամարների մասին:
        // Եթե մենք դա չանենք, հաշվարկը կարող է լցվել, և օգտվողները կօգտագործեն անվճար անվճար:
        // Մենք ռասայականորեն հագեցնում ենք `isize::MAX`-ին `ենթադրելով, որ ~2 միլիարդ թելեր միանգամից չեն ավելացնում հղումների քանակը:
        //
        // Այս branch-ը երբեք չի ընդունվի որևէ իրատեսական ծրագրում:
        //
        // Մենք վիժեցնում ենք, քանի որ նման ծրագիրն աներևակայելիորեն այլասերված է, և մենք չենք մտածում աջակցել դրան:
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Փոփոխական հղում է կատարում տվյալ `Arc`-ին:
    ///
    /// Եթե նույն բաշխման այլ `Arc` կամ [`Weak`] ցուցիչներ կան, ապա `make_mut`-ը կստեղծի նոր բաշխում և կկոչի [`clone`][clone] ներքին արժեքի վրա `եզակի սեփականություն ապահովելու համար:
    /// Սա նաև անվանվում է գրելու կլոն:
    ///
    /// Նկատի ունեցեք, որ դա տարբերվում է [`Rc::make_mut`]-ի պահվածքից, որն առանձնացնում է մնացած `Weak` ցուցիչները:
    ///
    /// Տես նաև [`get_mut`][get_mut], որը ձախողվելու է և ոչ կլոնավորմամբ:
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ոչինչ չի կլոնավորելու
    /// let mut other_data = Arc::clone(&data); // Չի կլոնավորելու ներքին տվյալները
    /// *Arc::make_mut(&mut data) += 1;         // Կլոնավորում է ներքին տվյալները
    /// *Arc::make_mut(&mut data) += 1;         // Ոչինչ չի կլոնավորելու
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ոչինչ չի կլոնավորելու
    ///
    /// // Այժմ `data`-ը և `other_data`-ը մատնանշում են տարբեր բաշխումներ:
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Նկատենք, որ մենք պահում ենք և ուժեղ հղում, և թույլ հղում:
        // Այսպիսով, մեր ուժեղ հղումը թողարկելը միայն ինքնին չի հանգեցնի հիշողությունը տեղաբաշխելու:
        //
        // Օգտագործեք Ձեռք բերեք ՝ համոզվելու համար, որ մենք տեսնում ենք `weak`-ի ցանկացած գրառումներ, որոնք տեղի են ունենում մինչև `strong` թողարկման գրառումները (այսինքն ՝ կրճատումներ):
        // Քանի որ մենք թույլ հաշվարկ ունենք, հնարավորություն չկա, որ ArcInner-ը կարող է տեղաբաշխվել:
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Մեկ այլ ուժեղ ցուցիչ գոյություն ունի, ուստի մենք պետք է կլոնավորենք:
            // Նախապես հատկացրեք հիշողությունը ՝ կլոնավորված արժեքն ուղղակիորեն գրելու հնարավորություն տալու համար:
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Հանգստացածը վերը նշվածում բավարար է, քանի որ սա հիմնովին օպտիմալացում է. Մենք միշտ մրցում ենք թույլ ցուցիչների անկման հետ:
            // Ամենավատ դեպքն այն է, որ մենք ի վերջո անտեղի հատկացրեցինք նոր Arc:
            //

            // Մենք հանեցինք վերջին ուժեղ ռեֆերը, բայց մնացել են լրացուցիչ թույլ ռեֆերներ:
            // Մենք բովանդակությունը կտեղափոխենք նոր Կամար, իսկ մյուս թույլ հղումները անվավեր կդարձնենք:
            //

            // Նկատի ունեցեք, որ հնարավոր չէ, որ `weak`-ի ընթերցմամբ ստացվի usize::MAX (այսինքն ՝ կողպված), քանի որ թույլ քանակը կարող է կողպվել միայն ուժեղ հղումով թելի միջոցով:
            //
            //

            // Նյութականացրեք մեր անուղղակի թույլ ցուցիչը, որպեսզի այն անհրաժեշտության դեպքում մաքրի ArcInner-ը:
            //
            let _weak = Weak { ptr: this.ptr };

            // Կարող է պարզապես գողանալ տվյալները, մնում է միայն Թուլություններ
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Մենք ցանկացած տեսակի միակ տեղեկանքն էինք.հետ վերցնել վերահաշվարկի ուժեղ հաշվարկը:
            //
            this.inner().strong.store(1, Release);
        }

        // Ինչպես `get_mut()`-ի դեպքում, անապահովությունն էլ կարգին է, քանի որ սկզբից մեր հղումը կա՛մ եզակի էր, կա՛մ դարձավ բովանդակությունը կլոնավորելու արդյունքում:
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Վերադարձնում է փոփոխվող հղումը տվյալ `Arc`-ին, եթե նույն տեղաբաշխման այլ `Arc` կամ [`Weak`] ցուցիչներ չկան:
    ///
    ///
    /// Հակառակ դեպքում վերադարձնում է [`None`], քանի որ ընդհանուր արժեքը փոխելու համար անվտանգ չէ:
    ///
    /// Տես նաև [`make_mut`][make_mut], որը [`clone`][clone] կլինի ներքին արժեքը, երբ կան այլ ցուցիչներ:
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Այս անապահովությունը կարգին է, քանի որ մենք երաշխավորված ենք, որ վերադարձված ցուցիչը * ** ցուցիչն է, որը երբևէ կվերադարձվի Տ:
            // Այս պահի դրությամբ մեր հղումների քանակը երաշխավորված է 1, և մենք պահանջեցինք, որ կամարը ինքը `mut` լինի, այնպես որ մենք վերադարձնում ենք ներքին տվյալների միակ հնարավոր հղումը:
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Վերադարձնում է փոփոխվող հղումը տվյալ `Arc`-ին ՝ առանց որևէ ստուգման:
    ///
    /// Տես նաև [`get_mut`], որն անվտանգ է և համապատասխան ստուգումներ է կատարում:
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Նույն հատկացման ցանկացած այլ `Arc` կամ [`Weak`] ցուցիչներ չպետք է վկայակոչվեն վերադարձված վարկի տևողության համար:
    ///
    /// Սա աննշան է, եթե այդպիսի ցուցիչներ գոյություն չունեն, օրինակ ՝ `Arc::new`-ից անմիջապես հետո:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Մենք ուշադիր ենք * չստեղծելու "count" դաշտերը ծածկող տեղեկանք, քանի որ դա կեղծանուն է հղումների հաշվարկի միաժամանակյա հասանելիության հետ (օրինակ ՝
        // `Weak`-ի կողմից):
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Որոշեք, արդյոք սա եզակի հղում է (ներառյալ թույլ ռեֆերատները) հիմքում ընկած տվյալների:
    ///
    ///
    /// Նկատի ունեցեք, որ սա պահանջում է արգելափակել թույլ փոփոխությունների քանակը:
    fn is_unique(&mut self) -> bool {
        // կողպեք ցուցիչների թույլ քանակը, եթե մենք կարծես ցուցիչի միակ թույլ կրողն ենք:
        //
        // Ձեռք բերող պիտակը այստեղ ապահովում է `strong`-ի (մասնավորապես `Weak::upgrade`-ում) ցանկացած գրառման հետ պատահական կապը նախքան `weak`-ի հաշվարկի նվազումը (`Weak::drop`-ի միջոցով, որն օգտագործում է թողարկում):
        // Եթե արդիացված թույլ ռեֆերենտը երբեք չընկնի, այստեղ CAS-ը ձախողվելու է, ուստի մենք չենք մտածում համաժամացման մասին:
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Սա պետք է լինի `Acquire` ՝ `drop`-ում `strong` հաշվիչի իջեցման հետ համաժամացման համար-միակ մուտքը, որը տեղի է ունենում, երբ որևէ այլ, բայց վերջին հղումը հրաժարվում է:
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Այստեղ թողարկված գրառումը սինխրոնիզացվում է `downgrade`-ով ընթերցվածի հետ `արդյունավետորեն կանխելով `strong`-ի վերը նշված ընթերցումը գրվելուց հետո:
            //
            //
            self.inner().weak.store(1, Release); // արձակել կողպեքը
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Նետում է `Arc`-ը:
    ///
    /// Սա կնվազեցնի ուժեղ տեղեկանքի քանակը:
    /// Եթե ուժեղ հղումների քանակը հասնում է զրոյի, ապա միակ այլ հղումները (եթե այդպիսիք կան) [`Weak`] են, ուստի մենք `drop` ներքին արժեքը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ոչինչ չի տպում
    /// drop(foo2);   // Տպում է "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Քանի որ `fetch_sub`-ն արդեն ատոմային է, մեզ հարկավոր չէ համաժամացնել այլ թելերի հետ, քանի դեռ չենք պատրաստվում ջնջել օբյեկտը:
        // Այս նույն տրամաբանությունը վերաբերում է ներքևում նշված `fetch_sub`-ին `weak` հաշվարկի համար:
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Այս ցանկապատն անհրաժեշտ է տվյալների օգտագործման վերադասավորումը և տվյալների ջնջումը կանխելու համար:
        // Քանի որ այն նշված է `Release`, տեղեկանքի քանակի նվազումը համաժամացվում է այս `Acquire` պարիսպի հետ:
        // Սա նշանակում է, որ տվյալների օգտագործումը տեղի է ունենում նախքան տեղեկանքի քանակի իջեցումը, ինչը տեղի է ունենում այս ցանկապատից առաջ, որը տեղի է ունենում մինչ տվյալների ջնջումը:
        //
        // Ինչպես բացատրվել է [Boost documentation][1]-ում,
        //
        // > Կարևոր է գործի դնել օբյեկտի ցանկացած հնարավոր մուտքը մեկում
        // > թեմա (գոյություն ունեցող հղման միջոցով)*տեղի ունենալու* ջնջումից առաջ
        // > օբյեկտը այլ թեմայի մեջ: Դրան հասնում է "release"-ը
        // > հղում թողնելուց հետո գործողություն (օբյեկտի ցանկացած մուտք
        // > այս հղման միջոցով ակնհայտորեն պետք է տեղի ունենար նախկինում), և
        // > "acquire" գործողությունը օբյեկտը ջնջելուց առաջ:
        //
        // Մասնավորապես, չնայած աղեղի պարունակությունը սովորաբար անփոփոխ է, հնարավոր է ունենալ Mutex-ի պես ինչ-որ բանի ներքին գրեր<T>,
        // Քանի որ Mutex-ը ջնջվելիս ձեռք չի բերվում, մենք չենք կարող ապավինել դրա համաժամացման տրամաբանությանը `A թեմայում գրվածքները տեսանելի դարձնելու համար B շղթայում աշխատող ապակառուցողին:
        //
        //
        // Նաև նշենք, որ «Ձեռք բերելու» ցանկապատը այստեղ, հավանաբար, կարող է փոխարինվել «Ձեռք բերել» բեռով, ինչը կարող է բարելավել կատարողականը շատ վիճելի իրավիճակներում: Տե՛ս [2]:
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>`-ը բետոնե տիպի իջեցնելու փորձ:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Կառուցում է նոր `Weak<T>` ՝ առանց որևէ հիշողություն հատկացնելու:
    /// Վերադարձի արժեքով [`upgrade`] զանգելը միշտ տալիս է [`None`]:
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Օգնականի տեսակը `թույլ տալով մուտք գործել հղումների հաշվարկներ` առանց տվյալների դաշտի վերաբերյալ որևէ պնդում կատարելու:
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Վերադառնում է հում ցուցիչ այս `Weak<T>`-ի կողմից մատնանշված `T` օբյեկտին:
    ///
    /// Սլաքը վավեր է միայն այն դեպքում, եթե կան մի քանի ուժեղ հղումներ:
    /// Հակառակ դեպքում ցուցիչը կարող է կախվել, չհարված լինել կամ նույնիսկ [`null`]:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Երկուսն էլ մատնանշում են նույն օբյեկտը
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Այստեղ ուժեղը այն կենդանի է պահում, ուստի մենք դեռ կարող ենք մուտք գործել օբյեկտ:
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Բայց ոչ ավելին:
    /// // Մենք կարող ենք անել weak.as_ptr(), բայց ցուցիչ մուտք գործելը կհանգեցնի չսահմանված վարքի:
    /// // assert_eq! («բարև», անապահով {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Եթե ցուցիչը կախված է, մենք պահակախումբը ուղիղ վերադարձնում ենք:
            // Սա չի կարող վավեր բեռի հասցե լինել, քանի որ բեռի բեռը համընկնում է առնվազն ArcInner (usize)-ի հետ:
            ptr as *const T
        } else {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Եթե is_dangling-ը կեղծ է վերադառնում, ապա ցուցիչը դյուրագրվող է:
            // Այս պահին բեռը կարող է իջնել, և մենք պետք է պահպանենք ծագումը, այնպես որ օգտագործեք ցուցիչի հում մանիպուլյացիա:
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Սպառում է `Weak<T>`-ը և այն վերածում հում ցուցիչի:
    ///
    /// Սա թույլ ցուցիչը վերածում է հում ցուցիչի, մինչդեռ դեռ պահպանում է մեկ թույլ տեղեկանքի պատկանելությունը (թույլ գործողությունը չի փոխվում այս գործողության միջոցով):
    /// Այն կարելի է վերափոխել `Weak<T>`-ի [`from_raw`]-ով:
    ///
    /// Theուցանիշի թիրախին հասանելիության նույն սահմանափակումները, ինչ [`as_ptr`]-ի դեպքում, կիրառվում են:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`]-ի կողմից նախկինում ստեղծված հում ցուցիչը վերափոխում է `Weak<T>`-ի:
    ///
    /// Սա կարող է օգտագործվել ուժեղ հղում ապահով ստանալու համար (ավելի ուշ զանգահարելով [`upgrade`]) կամ թույլ թվաքանակը տեղաբաշխել ՝ թողնելով `Weak<T>`:
    ///
    /// Այն տանում է մեկ թույլ տեղեկանքի սեփականություն (բացառությամբ [`new`]-ի կողմից ստեղծված ցուցիչների, քանի որ դրանք ոչ մի բանի չեն տիրապետում. Մեթոդը մինչ այժմ գործում է դրանց վրա):
    ///
    /// # Safety
    ///
    /// Սլաքը պետք է որ առաջացած լիներ [`into_raw`]-ից և դեռ պետք է տիրապետեր իր հավանական թույլ տեղեկանքին:
    ///
    /// Թույլատրվում է, որ ուժեղ զանգը 0 լինի սա կանչելու պահին:
    /// Այնուամենայնիվ, սա տիրապետում է մեկ թույլ տեղեկանքի, որը ներկայումս ներկայացված է որպես հում ցուցիչ (թույլ գործողությունը չի փոփոխվում այս գործողության միջոցով) և, հետևաբար, այն պետք է զուգակցվի [`into_raw`]-ի նախորդ զանգի հետ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Նվազեցնել վերջին թույլ հաշվարկը:
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Տե՛ս Weak::as_ptr ՝ համատեքստում, թե ինչպես է ստացվում մուտքային ցուցիչը:

        let ptr = if is_dangling(ptr as *mut T) {
            // Սա կախովի թույլ է:
            ptr as *mut ArcInner<T>
        } else {
            // Հակառակ դեպքում, մենք երաշխավորված ենք, որ ցուցիչը եկել է անհանգիստ Թուլից:
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Data_offset-ը անվտանգ է զանգահարելու համար, քանի որ ptr հղումները իրական (պոտենցիալ անկված) T են:
            let offset = unsafe { data_offset(ptr) };
            // Այսպիսով, մենք հակադարձում ենք օֆսեթը `ամբողջ RcBox-ը ստանալու համար:
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ցուցիչը առաջացել է Թույլից, ուստի այս փոխհատուցումն անվտանգ է:
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք այժմ վերականգնել ենք բնօրինակ Թույլ ցուցիչը, այնպես որ կարող ենք ստեղծել Թույլ:
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` ցուցիչը [`Arc`]-ով արդիականացնելու փորձեր ՝ հաջողության դեպքում հետաձգելով ներքին արժեքի անկումը:
    ///
    ///
    /// Վերադարձնում է [`None`], եթե ներքին արժեքը իջել է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ոչնչացրեք բոլոր ուժեղ ցուցիչները:
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Մենք օգտագործում ենք CAS օղակ ՝ ուժեղ հաշիվը ավելացնելու փոխարեն fetch_add-ի փոխարեն, քանի որ այս գործառույթը երբեք չպետք է վերցնի տեղեկանքի քանակը զրոյից մեկ:
        //
        //
        let inner = self.inner()?;

        // Հանգիստ բեռ, քանի որ 0 - ի ցանկացած գրություն, որը մենք կարող ենք դիտարկել, դաշտը թողնում է մշտապես զրոյական վիճակում (այնպես որ 0 - ի "stale" ընթերցումը լավ է), և ցանկացած այլ արժեք հաստատվում է ստորև նշված CAS- ի միջոցով:
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Տեսեք մեկնաբանությունները `Arc::clone`-ում, թե ինչու ենք մենք դա անում (`mem::forget`-ի համար):
            if n > MAX_REFCOUNT {
                abort();
            }

            // Հանգիստը լավ է ձախողման դեպքի համար, քանի որ մենք նոր պետության հետ կապված սպասելիքներ չունենք:
            // Ձեռք բերելը անհրաժեշտ է, որպեսզի հաջողության գործը համաժամացվի `Arc::new_cyclic`-ի հետ, երբ `Weak` հղումներն արդեն ստեղծվելուց հետո ներքին արժեքը կարող է նախանշվել:
            // Այդ դեպքում մենք ակնկալում ենք դիտարկել ամբողջությամբ նախանշված արժեքը:
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null վերը ստուգված է
                Err(old) => n = old,
            }
        }
    }

    /// Ստանում է ուժեղ տեղակայման (`Arc`) ցուցիչների քանակը, որը մատնանշում է այս բաշխումը:
    ///
    /// Եթե `self`-ը ստեղծվել է [`Weak::new`]-ի միջոցով, դա կվերադարձնի 0:
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ստանում է մոտավորապես այս տեղաբաշխումը մատնանշող `Weak` ցուցիչների քանակի մոտավորություն:
    ///
    /// Եթե `self`-ը ստեղծվել է [`Weak::new`]-ի միջոցով, կամ եթե ուժեղ ուժեղ ցուցիչներ չկան, սա կվերադարձնի 0:
    ///
    /// # Accuracy
    ///
    /// Իրականացման մանրամասների պատճառով վերադարձված արժեքը կարող է անջատվել 1-ով `երկու ուղղությամբ, երբ այլ թելեր շահարկում են ցանկացած` Arc`կամ`Թույլ` նույն բաշխումը մատնանշող:
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Քանի որ մենք նկատեցինք, որ թույլ հաշվարկը կարդալուց հետո կա առնվազն մեկ ուժեղ ցուցիչ, մենք գիտենք, որ ենթադրյալ թույլ հղումը (առկա է ցանկացած ուժեղ հղում ունենալու դեպքում) դեռ կար, երբ մենք դիտում էինք թույլ քանակը, և հետևաբար կարող ենք ապահով կերպով հանել այն:
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Վերադարձնում է `None`, երբ ցուցիչը կախված է, և չկա հատկացված `ArcInner`, (այսինքն, երբ այս `Weak`-ը ստեղծվել է `Weak::new`-ի կողմից):
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Մենք ուշադիր ենք * չստեղծելու "data" դաշտը ծածկող տեղեկանք, քանի որ դաշտը միաժամանակ կարող է մուտացիայի ենթարկվել (օրինակ, եթե վերջին `Arc`-ն ընկնի, տվյալների դաշտը տեղում կգցվի):
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Վերադարձնում է `true`, եթե երկու «Թույլ» կետերը մատնանշում են նույն բաշխումը (նման է [`ptr::eq`]-ին), կամ եթե երկուսն էլ չեն նշում որևէ բաշխում (քանի որ դրանք ստեղծվել են `Weak::new()`)-ով):
    ///
    ///
    /// # Notes
    ///
    /// Քանի որ սա համեմատում է ցուցիչները, դա նշանակում է, որ `Weak::new()`-ը հավասար կլինի միմյանց, չնայած որ դրանք չեն նշում որևէ բաշխման:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Համեմատելով `Weak::new`-ը:
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Կատարում է `Weak` ցուցիչի կլոն, որը մատնանշում է նույն բաշխումը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Տեսեք մեկնաբանությունները Arc::clone()-ում, թե ինչու է դա հանգիստ:
        // Սա կարող է օգտագործել fetch_add (անտեսելով կողպեքը), քանի որ թույլ քանակը կողպվում է միայն այնտեղ, որտեղ գոյություն չունի *այլ* թույլ ցուցիչներ:
        //
        // (Այնպես որ, այդ դեպքում մենք չենք կարող գործարկել այս կոդը):
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Տեսեք մեկնաբանությունները Arc::clone()-ում, թե ինչու ենք մենք դա անում (mem::forget-ի համար):
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Կառուցում է նոր `Weak<T>` ՝ առանց հիշողություն հատկացնելու:
    /// Վերադարձի արժեքով [`upgrade`] զանգելը միշտ տալիս է [`None`]:
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Նետում է `Weak` ցուցիչը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ոչինչ չի տպում
    /// drop(foo);        // Տպում է "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Եթե մենք պարզենք, որ մենք վերջին թույլ ցուցիչն ենք, ապա ժամանակն է ամբողջությամբ տեղաբաշխել տվյալները: Տե՛ս Arc::drop()-ի քննարկումը հիշողության կարգերի վերաբերյալ
        //
        // Այստեղ անհրաժեշտ չէ ստուգել արգելափակված վիճակը, քանի որ թույլ հաշվարկը կարող է կողպվել միայն այն դեպքում, եթե լիներ ճշգրիտ մեկ թույլ ռեֆերատ, այսինքն `այդ անկումը կարող էր հետագայում գործարկել միայն այդ մնացած թույլ ռեֆերենցիայով, ինչը կարող է տեղի ունենալ միայն կողպեքը բացելուց հետո:
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Մենք այս մասնագիտացումը կատարում ենք այստեղ, և ոչ թե որպես ավելի ընդհանուր օպտիմալացում `&T`-ի վրա, քանի որ այն այլ կերպ ծախսեր կավելացնի refs-ների հավասարության բոլոր ստուգումներին:
/// Մենք ենթադրում ենք, որ «Arc`-ն օգտագործվում է մեծ արժեքներ պահելու համար, որոնք դանդաղ են կլոնավորվում, բայց նաև ծանր են հավասարությունը ստուգելու համար` պատճառաբանելով, որ այդ ծախսն ավելի հեշտ է մարել:
///
/// Հավանական է նաև, որ երկու `Arc` կլոն ունենան, որոնք նույն արժեքն են նշում, քան երկու `&T`:
///
/// Մենք դա կարող ենք անել միայն այն դեպքում, երբ `T: Eq`-ը որպես `PartialEq` կարող է միտումնավոր անթափանցիկ լինել:
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Հավասարություն երկու `Arc` ի համար:
    ///
    /// Երկու `Կամար հավասար են, եթե նրանց ներքին արժեքները հավասար են, նույնիսկ եթե դրանք պահվում են տարբեր բաշխման մեջ:
    ///
    /// Եթե `T`-ը իրականացնում է նաև `Eq` (հավասարության ռեֆլեկտիվություն ենթադրող), ապա երկու `աղեղները, որոնք նշում են նույն բաշխումը, միշտ հավասար են:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Անհավասարություն երկու `Arc` ի համար:
    ///
    /// Երկու աղեղ անհավասար են, եթե նրանց ներքին արժեքները անհավասար են:
    ///
    /// Եթե `T`-ը իրականացնում է նաև `Eq` (հավասարության ռեֆլեկտիվություն ենթադրող), երկու նույնական արժեք ունեցող աղեղները երբեք անհավասար չեն:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Մասնակի համեմատություն երկու `Arc`s-ի համար:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `partial_cmp()` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ավելի քիչ, քան համեմատություն երկու Arc-ի համար:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `<` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Երկու կամարի `« պակասից կամ հավասար է »համեմատությունը:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `<=` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Ավելի մեծ, քան համեմատություն երկու Arc-ի համար:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `>` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Երկուից ավելի աղեղների «ավելի մեծ կամ հավասար» համեմատություն:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `>=` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Համեմատություն երկու `Arc` ի հետ:
    ///
    /// Այս երկուսը համեմատվում են `զանգահարելով `cmp()` իրենց ներքին արժեքները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Ստեղծում է նոր `Arc<T>` ՝ `T`-ի համար `Default` արժեքով:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Բաշխեք տեղեկանքով հաշվարկված կտոր և լրացրեք այն `կլոնավորելով« v »կետերը:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Հատկացրեք տեղեկանքով հաշվարկված `str`-ը և պատճենեք `v`-ը դրա մեջ:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Հատկացրեք տեղեկանքով հաշվարկված `str`-ը և պատճենեք `v`-ը դրա մեջ:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Տեղափոխեք տուփով առարկան նոր ՝ տեղեկանքներով հաշվարկված բաշխման:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Բաշխեք տեղեկանքով հաշվարկված հատված և տեղափոխեք «v»-ի իրերը դրա մեջ:
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Թույլ տվեք Vec-ին ազատել իր հիշողությունը, բայց ոչնչացնել դրա պարունակությունը
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Վերցնում է յուրաքանչյուր տարր `Iterator`-ում և հավաքում այն `Arc<[T]>`-ի մեջ:
    ///
    /// # Կատարման բնութագրերը
    ///
    /// ## Ընդհանուր գործը
    ///
    /// Ընդհանուր դեպքում, `Arc<[T]>`-ի մեջ հավաքումը կատարվում է նախ `հավաքելով `Vec<T>`-ի մեջ: Այսինքն ՝ հետևյալը գրելիս.
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// սա իրեն պահում է այնպես, կարծես գրել ենք.
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Հատկացումների առաջին փաթեթը տեղի է ունենում այստեղ:
    ///     .into(); // `Arc<[T]>`-ի երկրորդ հատկացումը տեղի է ունենում այստեղ:
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Սա հատկացնելու է այնքան անգամ, որքան անհրաժեշտ է `Vec<T>`-ի կառուցման համար, իսկ հետո այն հատկացվելու է մեկ անգամ `Vec<T>`-ը `Arc<[T]>`-ի վերածելու համար:
    ///
    ///
    /// ## Հայտնի երկարության կրկնիչներ
    ///
    /// Երբ ձեր `Iterator`-ն իրականացնում է `TrustedLen`-ը և ունի ճշգրիտ չափսեր, `Arc<[T]>`-ի համար մեկ հատկացում կկատարվի: Օրինակ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Պարզապես այստեղ կատարվում է մեկ հատկացում:
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// trait մասնագիտացումը, որն օգտագործվում է `Arc<[T]>`-ում հավաքելու համար:
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Այս դեպքը `TrustedLen` կրկնիչի դեպքում է:
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պետք է համոզվենք, որ կրկնիչը ունի ճշգրիտ երկարություն, և մենք ունենք:
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Վերադառնանք բնականոն իրականացմանը:
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Ստացեք փոխհատուցում `ArcInner`-ի սահմաններում ՝ ցուցիչի ետևում գտնվող ծանրաբեռնվածության համար:
///
/// # Safety
///
/// Սլաքը պետք է մատնանշի (և ունենա վավեր մետատվյալներ) T-ի նախկինում վավեր օրինակի, բայց T-ն թույլատրվում է թողնել:
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Անսահմանափակ արժեքը հավասարեցրեք ArcInner-ի ավարտին:
    // Քանի որ RcBox-ը repr(C) է, այն միշտ հիշողության մեջ կլինի վերջին դաշտը:
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Քանի որ միակ չնչին տեսակները հնարավոր են կտորները, trait օբյեկտները,
    // և արտաքին տեսակների, մուտքային անվտանգության պահանջը ներկայումս բավարար է ՝ գրաֆիկի_վ_ազարդի պահանջները բավարարելու համար.սա լեզվի իրականացման մանրամասնություն է, որը հնարավոր չէ ապավինել std-ից դուրս:
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}