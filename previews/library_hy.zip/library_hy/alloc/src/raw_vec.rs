#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Նոր հիշողության բովանդակությունը ոչ նախնականացված է:
    Uninitialized,
    /// Նոր հիշողությունը երաշխավորված է զրոյացնելուց:
    Zeroed,
}

/// Levelածր մակարդակի կոմունալ ՝ կույտի վրա ավելի շատ ergonomically բաշխելու, վերաբաշխելու և հիշողության բուֆեր տեղաբաշխելու համար ՝ առանց անհանգստանալու բոլոր ներգրավված անկյունային դեպքերի մասին:
///
/// Այս տեսակը հիանալի է Vec-ի և VecDeque-ի նման ձեր սեփական տվյալների կառուցվածքների կառուցման համար:
/// Մասնավորապես:
///
/// * `Unique::dangling()`-ն արտադրում է զրոյական չափի տեսակների վրա:
/// * Արտադրում է `Unique::dangling()` զրոյական երկարության հատկացումների վրա:
/// * Խուսափում է `Unique::dangling()`-ի ազատումից:
/// * Բռնում է տարողունակության հաշվարկների բոլոր վարարումները (դրանք հասցնում է "capacity overflow" panics):
/// * 32-բիթանոց համակարգերից ավելի շատ պահապաններ, որոնք հատկացնում են ավելի քան isize::MAX բայթ:
/// * Պահապան ձեր երկարությունը չլցնելու դեմ:
/// * Fallանգահարում է `handle_alloc_error`-ին `խոտան հատկացումների համար
/// * Պարունակում է `ptr::Unique` և այդպիսով օգտվողին օժտում է բոլոր հարակից առավելություններով:
/// * Օգտագործում է բաշխիչից վերադարձված ավելցուկը `ամենամեծ մատչելի հզորությունն օգտագործելու համար:
///
/// Այս տեսակն ամեն դեպքում չի ստուգում իր ղեկավարած հիշողությունը: Նետվելուց հետո այն * կազատի իր հիշողությունը, բայց չի փորձի նետել դրա պարունակությունը:
/// `RawVec`-ի օգտագործողին մնում է կարգավորել `RawVec`-ի ներսում *պահված* իրերը:
///
/// Նկատի ունեցեք, որ զրոյական չափի տիպերի ավելցուկը միշտ անսահման է, ուստի `capacity()`-ը միշտ վերադարձնում է `usize::MAX`:
/// Սա նշանակում է, որ դուք պետք է զգույշ լինեք `Box<[T]>`-ով այս տիպը կլորացնելիս, քանի որ `capacity()`-ը չի տա երկարությունը:
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Սա գոյություն ունի, քանի որ `#[unstable]` `const fn-ը կարիք չունի համապատասխանելու `min_const_fn`-ին, ուստի դրանք նույնպես չեն կարող կանչվել` min_const_fn-ով:
    ///
    /// Եթե փոխում եք `RawVec<T>::new`-ը կամ կախվածությունը, ուշադրություն դարձրեք չներկայացնել այնպիսի բան, որը իսկապես կխախտի `min_const_fn`-ը:
    ///
    /// NOTE: Մենք կարող ենք խուսափել այս կոտրումից և ստուգել համապատասխանությունը որոշ `#[rustc_force_min_const_fn]` հատկանիշների հետ, որը պահանջում է համապատասխանություն `min_const_fn`-ի հետ, բայց անպայման թույլ չի տալիս զանգահարել այն `stable(...) const fn`/օգտագործողի կոդով, որը հնարավորություն չի տալիս `foo`, երբ առկա է `#[rustc_const_unstable(feature = "foo", issue = "01234")]`:
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Առանց հատկացնելու ստեղծում է հնարավոր ամենամեծ `RawVec` (համակարգի կույտի վրա):
    /// Եթե `T`-ն ունի դրական չափ, ապա սա կազմում է `RawVec` `0` տարողությամբ:
    /// Եթե `T`-ը զրոյական չափի է, ապա այն կազմում է `RawVec` `usize::MAX` տարողությամբ:
    /// Օգտակար է հետաձգված հատկացումն իրականացնելու համար:
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Ստեղծում է `RawVec` (համակարգի կույտի վրա) `[T; capacity]`-ի ճշգրիտ հզորությամբ և հավասարեցման պահանջներով:
    /// Սա համարժեք է `RawVec::new` զանգահարելուն, երբ `capacity` `0` է կամ `T` զրոյական չափի:
    /// Նկատի ունեցեք, որ եթե `T`-ը զրոյական չափի է, սա նշանակում է, որ դուք * * չեք ստանա պահանջվող հզորությամբ `RawVec`:
    ///
    /// # Panics
    ///
    /// Panics եթե պահանջվող հզորությունը գերազանցում է `isize::MAX` բայթը:
    ///
    /// # Aborts
    ///
    /// Վիժեցնում է OOM-ը:
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity`-ի նման, բայց երաշխավորում է, որ բուֆերը զրոյացվում է:
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec`-ը վերականգնում է ցուցիչից և հզորությունից:
    ///
    /// # Safety
    ///
    /// `ptr`-ը պետք է բաշխվի (համակարգի կույտի վրա) և տրված `capacity`-ով:
    /// `capacity` չափի տեսակների համար չի կարող գերազանցել `isize::MAX`-ը: (միայն մտահոգություն 32-բիթանոց համակարգերի վրա):
    /// ZST vectors-ը կարող է ունենալ մինչև `usize::MAX` հզորություն:
    /// Եթե `ptr`-ը և `capacity`-ը գալիս են `RawVec`-ից, ապա դա երաշխավորված է:
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Փոքրիկ Վեկերը համր են: Անցնել ՝
    // - 8, եթե տարրի չափը 1 է, քանի որ ցանկացած կույտաբաշխիչ, ամենայն հավանականությամբ, կլորացնի 8 բայթից պակաս պահանջը առնվազն 8 բայթ:
    //
    // - 4, եթե տարրերը միջին չափի են (<=1 KiB):
    // - 1 այլապես ՝ խուսափելու համար շատ կարճ տարածք վեկերի համար չափազանց շատ տեղ վատնելուց:
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new`-ի նման, բայց պարամետրավորված է վերադարձված `RawVec`-ի համար բաշխողի ընտրության հարցում:
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` նշանակում է "unallocated": զրոյական չափի տեսակները անտեսվում են:
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity`-ի նման, բայց պարամետրավորված է վերադարձված `RawVec`-ի համար բաշխողի ընտրության հարցում:
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed`-ի նման, բայց պարամետրավորված է վերադարձված `RawVec`-ի համար բաշխողի ընտրության հարցում:
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>`-ը փոխակերպում է `RawVec<T>`-ի:
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Ամբողջ բուֆերը վերափոխում է `Box<[MaybeUninit<T>]>`-ի ՝ նշված `len`-ի հետ:
    ///
    /// Նկատի ունեցեք, որ սա ճիշտ կերպով կվերափոխի `cap`-ի ցանկացած փոփոխություն, որը կարող է կատարվել: (Մանրամասների համար տե՛ս տեսակի նկարագրությունը):
    ///
    /// # Safety
    ///
    /// * `len` պետք է լինի ավելի մեծ կամ հավասար վերջին պահանջվող հզորության, և
    /// * `len` պետք է լինի `self.capacity()`-ից փոքր կամ հավասար:
    ///
    /// Նկատի ունեցեք, որ պահանջվող հզորությունը և `self.capacity()`-ը կարող են տարբերվել, քանի որ տեղաբաշխիչը կարող է ընդհանուր տեղաբաշխել և վերադարձնել պահանջվող ավելի մեծ զանգված:
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Խելամտություն ստուգեք անվտանգության պահանջի կեսը (մյուս կեսը չենք կարող ստուգել):
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Մենք այստեղ `unwrap_or_else`-ից խուսափում ենք, քանի որ այն փչացնում է առաջացած LLVM IR-ի քանակը:
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec`-ը վերականգնում է ցուցիչից, հզորությունից և բաշխիչից:
    ///
    /// # Safety
    ///
    /// `ptr`-ը պետք է բաշխվի (տրված `alloc` բաշխիչի միջոցով) և տրված `capacity`-ով:
    /// `capacity` չափի տեսակների համար չի կարող գերազանցել `isize::MAX`-ը:
    /// (միայն մտահոգություն 32-բիթանոց համակարգերի վրա):
    /// ZST vectors-ը կարող է ունենալ մինչև `usize::MAX` հզորություն:
    /// Եթե `ptr`-ը և `capacity`-ը գալիս են `alloc`-ի միջոցով ստեղծված `RawVec`-ից, ապա դա երաշխավորված է:
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ստանում է հում ցուցիչ ՝ բաշխման մեկնարկին:
    /// Նշենք, որ սա `Unique::dangling()` է, եթե `capacity == 0` կամ `T` զրոյական չափի է:
    /// Նախկին դեպքում պետք է զգույշ լինել:
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ստանում է հատկացման կարողությունը:
    ///
    /// Սա միշտ կլինի `usize::MAX`, եթե `T` զրոյական չափի լինի:
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Վերադարձնում է ընդհանուր հղումը այս `RawVec`-ի աջակցող բաշխիչին:
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Մենք ունենք հատկացված հիշողություն, այնպես որ կարող ենք շրջանցել գործարկման ժամանակավոր ստուգումները ՝ մեր ընթացիկ դասավորությունը ստանալու համար:
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Ապահովում է, որ բուֆերը պարունակում է առնվազն բավարար տարածք `len + additional` տարրեր պահելու համար:
    /// Եթե դա արդեն չունի բավարար հզորություն, կբաշխի բավարար տարածություն և հարմարավետ անփույթ տարածք `ամորտիզացված *O*(1) վարք ստանալու համար:
    ///
    /// Կսահմանափակի այս վարքագիծը, եթե դա անիմաստորեն կհանգեցնի իրեն panic:
    ///
    /// Եթե `len`-ը գերազանցում է `self.capacity()`-ը, դա կարող է ձախողել իրականում հատկացնել պահանջվող տարածքը:
    /// Սա իրականում անվստահ չէ, բայց կարող է կոտրվել ձեր կողմից գրված անապահով ծածկագիրը, որը ապավինում է այս գործառույթի վարքին:
    ///
    /// Սա իդեալական է `extend`-ի նման զանգվածային գործողություն իրականացնելու համար:
    ///
    /// # Panics
    ///
    /// Panics եթե նոր հզորությունը գերազանցում է `isize::MAX` բայթը:
    ///
    /// # Aborts
    ///
    /// Վիժեցնում է OOM-ը:
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // պահուստը վիժեցված կլիներ կամ խուճապի մատնվեր, եթե լենը գերազանցեր `isize::MAX`-ը, այնպես որ դա անվտանգ է անել առանց ստուգված այժմ:
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Նույնը, ինչ `reserve`, բայց վերադարձնում է սխալները `խուճապի մատնելու կամ վիժեցնելու փոխարեն:
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Ապահովում է, որ բուֆերը պարունակում է առնվազն բավարար տարածք `len + additional` տարրեր պահելու համար:
    /// Եթե դա արդեն չկա, վերաբաշխելու է անհրաժեշտ նվազագույն հնարավոր քանակը հիշողության:
    /// Ընդհանրապես, դա կլինի հենց հիշողության անհրաժեշտ քանակը, բայց սկզբունքորեն բաշխողն ազատ է վերադարձնել ավելին, քան պահանջել ենք:
    ///
    ///
    /// Եթե `len`-ը գերազանցում է `self.capacity()`-ը, դա կարող է ձախողել իրականում հատկացնել պահանջվող տարածքը:
    /// Սա իրականում անվստահ չէ, բայց կարող է կոտրվել ձեր կողմից գրված անապահով ծածկագիրը, որը ապավինում է այս գործառույթի վարքին:
    ///
    /// # Panics
    ///
    /// Panics եթե նոր հզորությունը գերազանցում է `isize::MAX` բայթը:
    ///
    /// # Aborts
    ///
    /// Վիժեցնում է OOM-ը:
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Նույնը, ինչ `reserve_exact`, բայց վերադարձնում է սխալները `խուճապի մատնելու կամ վիժեցնելու փոխարեն:
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Նվազեցնում է հատկացումը մինչև նշված գումարը:
    /// Եթե տվյալ գումարը 0 է, իրականում ամբողջությամբ ապաբաշխվում է:
    ///
    /// # Panics
    ///
    /// Panics, եթե տվյալ գումարը *ավելի մեծ է*, քան ներկայիս հզորությունը:
    ///
    /// # Aborts
    ///
    /// Վիժեցնում է OOM-ը:
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Վերադառնում է, եթե բուֆերը պետք է աճի `անհրաժեշտ լրացուցիչ հզորությունը լրացնելու համար:
    /// Հիմնականում օգտագործվում է առանց պահուստային զանգերը հնարավոր դարձնելու առանց `grow` նշելու:
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Սովորաբար, այս մեթոդը բազմիցս ներկայացվում է: Այսպիսով, մենք ուզում ենք, որ այն հնարավորինս փոքր լինի, բարելավելու կազմման ժամանակները:
    // Բայց մենք նաև ցանկանում ենք, որ դրա բովանդակության մեծ մասը հնարավոր լինի ստատիկորեն հաշվարկելի դարձնել, որպեսզի ստացված կոդն ավելի արագ աշխատի:
    // Հետևաբար, այս մեթոդը մանրակրկիտ գրված է այնպես, որ `T`-ից կախված բոլոր ծածկագրերը գտնվեն դրա մեջ, մինչդեռ հնարավորինս կախված կոդերից շատը `T`-ի նկատմամբ ոչ ընդհանուր գործառույթներում է:
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Դա ապահովում են զանգահարող համատեքստերը:
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Քանի որ մենք վերադարձնում ենք `usize::MAX` հզորություն, երբ `elem_size` է
            // 0, այստեղ հասնելն անպայման նշանակում է, որ `RawVec`-ը գերհագեցած է:
            return Err(CapacityOverflow);
        }

        // Cheավոք, ոչինչ չի կարող անել այս ստուգումների վերաբերյալ:
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Սա երաշխավորում է էքսպենսիցիոն աճ:
        // Կրկնապատկումը չի կարող վարարել, քանի որ `cap <= isize::MAX`-ը և `cap`-ի տեսակը `usize` է:
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ոչ ընդհանուր է `T`-ի նկատմամբ:
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Այս մեթոդի սահմանափակումները շատ նույնն են, ինչ `grow_amortized`-ում, բայց այս մեթոդը սովորաբար ավելի հազվադեպ է ներկայացվում, ուստի պակաս կարևոր է:
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Քանի որ մենք վերադարձնում ենք `usize::MAX` հզորություն, երբ տիպի չափը լինի
            // 0, այստեղ հասնելն անպայման նշանակում է, որ `RawVec`-ը գերհագեցած է:
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ոչ ընդհանուր է `T`-ի նկատմամբ:
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Այս գործառույթը `RawVec`-ից դուրս է ՝ կազմման ժամանակները նվազագույնի հասցնելու համար: Մանրամասների համար տե՛ս `RawVec::grow_amortized`-ի վերևում տրված մեկնաբանությունը:
// (`A` պարամետրը նշանակալի չէ, քանի որ տարբեր `A` տեսակների քանակը գործնականում շատ ավելի փոքր է, քան `T` տեսակների քանակը):
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Ստուգեք սխալի այստեղ ՝ `RawVec::grow_*`-ի չափը նվազագույնի հասցնելու համար:
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Հատկացողը ստուգում է հավասարեցման հավասարությունը
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ազատում է `RawVec`-ին պատկանող հիշողությունը ՝ առանց * փորձելու նետել դրա պարունակությունը:
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Պահուստային սխալի մշակման կենտրոնական գործառույթ:
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Մենք պետք է երաշխավորենք հետևյալը.
// * Մենք երբեք չենք հատկացնում `> isize::MAX` բայթ չափի օբյեկտներ:
// * Մենք չենք վարարում `usize::MAX` և իրականում շատ քիչ գումար ենք հատկացնում:
//
// 64-բիթանոցում մենք պարզապես պետք է ստուգենք, թե որքանով է լցված ջուրը, քանի որ `> isize::MAX` բայթ հատկացնելու փորձը հաստատ չի հաջողվի:
// 32-բիթանոց և 16-բիթանոց համակարգերում մենք պետք է դրա համար լրացուցիչ պահապան ավելացնենք, եթե մենք աշխատում ենք այն պլատֆորմի վրա, որը կարող է օգտագործել բոլոր 4 ԳԲ-ն օգտագործողի տարածքում, օրինակ `PAE կամ x32:
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Հզորության արտահոսքի համար պատասխանատու մեկ կենտրոնական գործառույթ:
// Սա կապահովի, որ այս panics-ի հետ կապված կոդի ստեղծումը նվազագույն լինի, քանի որ կա միայն մեկ տեղակայություն, որը panics է, քան մի փունջ ամբողջ մոդուլի մեջ:
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}