# `rustc-std-workspace-core` crate

Այս crate-ը փայլուն և դատարկ crate է, որը պարզապես կախված է `libcore`-ից և վերաարտահանում է իր ամբողջ բովանդակությունը:
crate-ը ստանդարտ գրադարանին հնարավորություն տալու հիմքն է `կախված լինել crates-ից crates.io-ից:

Crates-ը crates.io-ի վրա, որ ստանդարտ գրադարանը կախված է անհրաժեշտությունից `կախված crates.io-ից `rustc-std-workspace-core` crate-ից, որը դատարկ է:

Մենք օգտագործում ենք `[patch]` ՝ այս պահեստում այն crate-ին անտեսելու համար:
Արդյունքում, crates-ը crates.io-ի վրա կախվածությունը edge-ից կդարձնի `libcore`, այս պահեստում սահմանված տարբերակը:
Դա պետք է գծի կախվածության բոլոր եզրերը `Cargo-ի crates-ի հաջող կառուցումը ապահովելու համար:

Նշենք, որ crates-ը crates.io-ի վրա պետք է կախված լինի այս crate-ից `core` անունով, որպեսզի ամեն ինչ ճիշտ աշխատի: Դա անելու համար նրանք կարող են օգտագործել.

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` ստեղնաշարի միջոցով crate-ը վերանվանվում է `core`, այսինքն ՝ նման կլինի

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

երբ Cargo-ը կանչում է կազմողին ՝ բավարարելով կազմողի կողմից ներարկված անուղղակի `extern crate core` հրահանգը:




