use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri-ն չափազանց դանդաղ է
fn exact_sanity_test() {
    // Այս թեստի արդյունքում ստացվում է այն, ինչը ես կարող եմ ենթադրել, միայն `exp2` գրադարանի գործառույթի որևէ անկյունային դեպք է, որը սահմանված է ցանկացած C գործառույթի ժամանակ, որը մենք օգտագործում ենք:
    // VS 2013-ում այս գործառույթն ակնհայտորեն ունեցել է սխալ, քանի որ այս թեստը չի հաջողվում միացնելիս, բայց VS 2015-ի հետ սխալը կարծես շտկվում է, քանի որ ստուգումը լավ է անցնում:
    //
    // Սխալը կարծես `exp2(-1057)`-ի վերադարձի արժեքի տարբերություն է, որտեղ VS 2013-ին այն կրկնապատկում է 0x2 բիթի օրինակով, իսկ VS 2015-ում այն վերադարձնում է 0x20000:
    //
    //
    // Առայժմ պարզապես անտեսեք այս թեստը ամբողջությամբ MSVC-ի վրա, քանի որ այն ամեն դեպքում փորձարկվել է այլուր, և մենք չափազանց հետաքրքրված չենք յուրաքանչյուր պլատֆորմի exp2 ներդրման փորձարկումով:
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}