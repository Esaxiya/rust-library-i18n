use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Սա կայուն մակերես չէ, բայց օգնում է նրանց միջեւ `?` էժան պահել, նույնիսկ եթե LLVM-ն այժմ միշտ չէ, որ կարող է օգտվել դրանից:
    //
    // (Lyավոք, արդյունքն ու տարբերակը անհամապատասխան են, ուստի ControlFlow-ը չի կարող համընկնել երկուսի հետ):

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}