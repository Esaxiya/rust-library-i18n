//! Libcore prelude
//!
//! Այս մոդուլը նախատեսված է libcore-ի այն օգտվողների համար, որոնք նույնպես չեն հղվում libstd-ին:
//! Այս մոդուլը լռելյայն ներմուծվում է, երբ `#![no_std]`-ն օգտագործվում է նույն ձևով, ինչ որ ստանդարտ գրադարանի prelude-ն է:
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015 թ.-ի միջուկի prelude տարբերակը:
///
/// Տեսեք [module-level documentation](self)-ը ավելին:
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude միջուկի 2018 թվականի տարբերակը:
///
/// Տեսեք [module-level documentation](self)-ը ավելին:
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude միջուկի 2021 տարբերակը:
///
/// Տեսեք [module-level documentation](self)-ը ավելին:
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Ավելացրեք ավելին:
}