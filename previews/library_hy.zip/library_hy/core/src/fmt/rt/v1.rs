//! Սա ifmt-ի կողմից օգտագործվող ներքին մոդուլ է: վթարի ժամանակԱյս կառուցվածքները արտանետվում են ստատիկ զանգվածների ՝ նախապես կազմելու ձևաչափի տողերը ժամանակից շուտ:
//!
//! Այս սահմանումները նման են իրենց `ct` համարժեքներին, բայց տարբերվում են նրանով, որ դրանք կարող են բաշխվել ստատիկ կերպով և մի փոքր օպտիմիզացված են գործարկման ժամանակի համար
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Հնարավոր հավասարեցումներ, որոնք կարող են պահանջվել որպես ձևաչափման հրահանգի մաս:
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Նշում, որ բովանդակությունը պետք է ձախ հավասարեցված լինի:
    Left,
    /// Նշում, որ բովանդակությունը պետք է ճիշտ հավասարեցված լինի:
    Right,
    /// Նշում, որ բովանդակությունը պետք է հավասարեցված լինի կենտրոնին:
    Center,
    /// Հավասարեցում չի պահանջվել:
    Unknown,
}

/// Օգտագործվում է [width](https://doc.rust-lang.org/std/fmt/#width) և [precision](https://doc.rust-lang.org/std/fmt/#precision) ճշգրտիչների կողմից:
#[derive(Copy, Clone)]
pub enum Count {
    /// Նշված է բառացի թվով, պահպանում է արժեքը
    Is(usize),
    /// `$` և `*` շարահյուսությունների օգտագործմամբ նշվածը պահպանում է ցուցիչը `args`
    Param(usize),
    /// Նշված չէ
    Implied,
}