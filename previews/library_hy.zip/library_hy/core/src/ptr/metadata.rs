#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Տրամադրում է ցուցիչի մետատվյալների ցանկացած ցուցիչ տիպի տիպ:
///
/// # Poուցանիշի մետատվյալներ
///
/// Rust-ի ցուցիչի հումքի տեսակները և հղումների տեսակները կարելի է համարել երկու մասից կազմված.
/// տվյալների ցուցիչ, որը պարունակում է արժեքի հիշողության հասցեն և որոշ մետատվյալներ:
///
/// Ստատիկ չափի տիպերի համար (որոնք իրականացնում են `Sized` traits), ինչպես նաև `extern` տիպերի համար ցուցիչները նշվում են որպես «բարակ». Մետատվյալները զրոյական են, իսկ տեսակները ՝ `()`:
///
///
/// Նշվում է, որ [dynamically-sized types][dst]-ի ցուցիչները «լայն» կամ «ճարպ» են, դրանք ունեն ոչ զրոյական չափի մետատվյալներ.
///
/// * Հատվածների համար, որոնց վերջին դաշտը DST է, մետատվյալները վերջին դաշտի մետատվյալներն են
/// * `str` տիպի համար մետատվյալը բայթերի երկարությունն է, որպես `usize`
/// * `[T]`-ի նման կտորների համար մետատվյալը իրերի երկարությունն է, որպես `usize`
/// * X0X-ի նման trait օբյեկտների համար մետատվյալները [`DynMetadata<Self>`][DynMetadata] են (օրինակ ՝ `DynMetadata<dyn SomeTrait>`)
///
/// future-ում Rust լեզուն կարող է ձեռք բերել նոր տեսակի տեսակներ, որոնք ունեն ցուցիչի տարբեր մետատվյալներ:
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Այս trait-ի կետը `Metadata`-ի հետ կապված տեսակն է, որը `()` կամ `usize` կամ `DynMetadata<_>` է, ինչպես նկարագրված է վերևում:
/// Այն ավտոմատ կերպով իրականացվում է յուրաքանչյուր տեսակի համար:
/// Կարելի է ենթադրել, որ այն իրականացվում է ընդհանուր համատեքստում, նույնիսկ առանց համապատասխան կապի:
///
/// # Usage
///
/// Հում ցուցիչները կարող են տարրալուծվել տվյալների հասցեի և մետատվյալների բաղադրիչների մեջ իրենց [`to_raw_parts`] մեթոդով:
///
/// Այլընտրանքորեն, միայն մետատվյալները կարող են արդյունահանվել [`metadata`] գործառույթով:
/// Հղումը կարող է փոխանցվել [`metadata`] և անուղղակի կերպով պարտադրվել:
///
/// (possibly-wide) ցուցիչը կարող է նորից միացվել իր հասցեից և [`from_raw_parts`] կամ [`from_raw_parts_mut`]-ի մետատվյալներից:
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Ersուցանակներում մետատվյալների տեսակը և `Self`-ի հղումները:
    #[lang = "metadata_type"]
    // NOTE: trait bounds-ը պահեք `static_assert_expected_bounds_for_metadata`-ում
    //
    // `library/core/src/ptr/metadata.rs`-ով ՝ համաժամացված այստեղի հետ.
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// trait կեղծանունն իրականացնող տիպերի ցուցիչները «բարակ» են:
///
/// Սա ներառում է ստատիկորեն «չափի» տեսակները և `extern` տեսակները:
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: մի կայունացնե՞ք սա մինչև trait կեղծանունները կայուն լինեն լեզվով:
pub trait Thin = Pointee<Metadata = ()>;

/// Արդյունահանել ցուցիչի մետատվյալների բաղադրիչը:
///
/// `*mut T`, `&T` կամ `&mut T` տիպի արժեքները կարող են փոխանցվել անմիջապես այս գործառույթին, քանի որ դրանք անուղղակիորեն պարտադրվում են `* const T`:
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `PtrRepr` միությունից արժեքին մուտք գործելը անվտանգ է, քանի որ * const T
    // և PtrComponents<T>ունեն հիշողության նույն դասավորությունը:
    // Միայն std-ը կարող է կատարել այս երաշխիքը:
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Տվյալների հասցեից և մետատվյալներից ձևավորում է (possibly-wide) հում ցուցիչ:
///
/// Այս գործառույթն անվտանգ է, բայց վերադարձված ցուցիչը պարտադիր չէ անվտանգ զսպելիս:
/// Կտորների համար տե՛ս [`slice::from_raw_parts`]- ի փաստաթղթերը ՝ անվտանգության պահանջների համար:
/// trait օբյեկտների համար մետատվյալները պետք է գան ցուցիչից նույն հիմքում ընկած մեծացված տիպին:
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `PtrRepr` միությունից արժեքին մուտք գործելը անվտանգ է, քանի որ * const T
    // և PtrComponents<T>ունեն հիշողության նույն դասավորությունը:
    // Միայն std-ը կարող է կատարել այս երաշխիքը:
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Կատարում է նույն ֆունկցիոնալությունը, ինչ [`from_raw_parts`]-ը, բացառությամբ, որ վերադարձվում է հում `*mut` ցուցիչը, ի տարբերություն հում `* const` ցուցիչի:
///
///
/// Տեսեք [`from_raw_parts`]-ի փաստաթղթերը `ավելի մանրամասն:
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `PtrRepr` միությունից արժեքին մուտք գործելը անվտանգ է, քանի որ * const T
    // և PtrComponents<T>ունեն հիշողության նույն դասավորությունը:
    // Միայն std-ը կարող է կատարել այս երաշխիքը:
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy`-ի պարտադիր պահումից խուսափելու համար անհրաժեշտ ձեռնարկ.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone`-ի պարտադիր պահումից խուսափելու համար անհրաժեշտ ձեռնարկ.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait օբյեկտի տիպի մետատվյալները:
///
/// Դա ցուցիչ է դեպի սեղանի (վիրտուալ զանգի աղյուսակ), որը ներկայացնում է բոլոր անհրաժեշտ տեղեկությունները trait օբյեկտի ներսում պահված բետոնի տեսակը շահարկելու համար:
/// Հատկապես այն պարունակում է.
///
/// * տեսակի չափը
/// * տիպի հավասարեցում
/// * ցուցիչ տիպի `drop_in_place` ազդանշանի (պարզ-հին տվյալների համար կարող է լինել ոչ-գործողություն)
/// * ցուցիչներ trait-ի տիպի իրականացման բոլոր մեթոդներին
///
/// Ուշադրություն դարձրեք, որ առաջին երեքը հատուկ են, քանի որ դրանք անհրաժեշտ են trait ցանկացած օբյեկտ հատկացնելու, գցելու և տեղաբաշխելու համար:
///
/// Հնարավոր է անվանել այս կառուցվածքը տիպային պարամետրով, որը `dyn` trait օբյեկտ չէ (օրինակ `DynMetadata<u64>`), բայց այդ կառուցվածքի իմաստալից արժեք չստանալ:
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Բոլոր սեղանների ընդհանուր նախածանցը: Դրան հաջորդում են ֆունկցիայի ցուցիչները trait մեթոդների համար:
///
/// `DynMetadata::size_of`-ի մասնավոր իրականացման մանրամասներ և այլն:
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Վերադարձնում է այս սեղանի հետ կապված տիպի չափը:
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Վերադարձնում է այս սեղանի հետ կապված տիպի հավասարեցումը:
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Վերադարձնում է չափը և հավասարեցումը միասին որպես `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Կազմողն արտանետել է այս սեղանը կոնկրետ Rust տիպի համար, որը
        // հայտնի է, որ ունի ճիշտ դասավորություն: Նույն հիմնավորումը, ինչ `Layout::for_value`-ում:
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ձեռնարկներ, որոնք անհրաժեշտ են `Dyn: $Trait` սահմաններից խուսափելու համար:

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}