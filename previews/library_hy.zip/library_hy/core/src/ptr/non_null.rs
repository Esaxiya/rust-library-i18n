use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` բայց ոչ զրոյական և փոխադարձ:
///
/// Հաճախ դա հում ցուցիչներով տվյալների կառուցվածքներ կառուցելիս օգտագործելու ճիշտ բանն է, բայց օգտագործումը, ի վերջո, ավելի վտանգավոր է ՝ իր լրացուցիչ հատկությունների պատճառով: Եթե վստահ չեք, որ պետք է օգտագործել `NonNull<T>`, պարզապես օգտագործեք `*mut T`:
///
/// Ի տարբերություն `*mut T`-ի, ցուցիչը միշտ պետք է լինի ոչ առարկայական, նույնիսկ եթե ցուցիչը երբեք չի զետեղվում: Սա այնպես է, որ հաշվարկողները կարող են օգտագործել այս արգելված արժեքը որպես խտրականություն. `Option<NonNull<T>>`-ն ունի նույն չափը, ինչ `* mut T`-ը:
/// Այնուամենայնիվ, ցուցիչը կարող է դեռ կախվել, եթե չուղարկվի:
///
/// Ի տարբերություն `*mut T`-ի, `NonNull<T>`-ն ընտրվեց `T`-ի փոխարեն փոխվող: Դա հնարավոր է դարձնում `NonNull<T>`-ի օգտագործումը կովարիանտ տիպեր կառուցելիս, բայց ներմուծում է անճշտության ռիսկ, եթե այն օգտագործվում է այնպիսի տիպի մեջ, որը իրականում չպետք է լինի փոփոխական:
/// (Հակառակ ընտրությունն արվեց `*mut T`-ի համար, չնայած տեխնիկապես անճշտությունը կարող էր առաջանալ միայն անվտանգ գործառույթներ կանչելով):
///
/// Կովարիանսը ճիշտ է շատ անվտանգ աբստրակցիաների համար, ինչպիսիք են `Box`, `Rc`, `Arc`, `Vec` և `LinkedList`: Սա այն դեպքն է, քանի որ դրանք տրամադրում են հանրային API, որը հետևում է Rust-ի սովորական ընդհանուր XOR փոփոխական կանոններին:
///
/// Եթե ձեր տեսակը չի կարող ապահով փոփոխական լինել, ապա պետք է համոզվեք, որ այն պարունակում է որոշ լրացուցիչ դաշտ ՝ անփոփոխություն ապահովելու համար: Հաճախ այս դաշտը կլինի [`PhantomData`] տիպ, ինչպիսին է `PhantomData<Cell<T>>` կամ `PhantomData<&'a mut T>`:
///
/// Ուշադրություն դարձրեք, որ `NonNull<T>`-ը `&T`-ի համար ունի `From` օրինակ: Այնուամենայնիվ, դա չի փոխում այն փաստը, որ (ա-ից ստացված ցուցիչի) միջոցով մուտացիայի ենթարկվելը չսահմանված վարք է, քանի դեռ մուտացիան տեղի չի ունեցել [`UnsafeCell<T>`]-ի ներսում:Նույնը վերաբերում է ընդհանուր տեղեկանքից փոփոխվող տեղեկանք ստեղծելու համար:
///
/// Այս `From` օրինակն առանց `UnsafeCell<T>` օգտագործելու ժամանակ ձեր պարտականությունն է ապահովել, որ `as_mut` երբեք չկանչի, և `as_ptr` երբեք չօգտագործվի մուտացիայի համար:
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ցուցիչները `Send` չեն, քանի որ նրանց հղած տվյալները կարող են այլազգի լինել:
// Հաշվի առնելով, այս ազդանշանն ավելորդ է, բայց պետք է ավելի լավ սխալ հաղորդագրություններ տա:
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ցուցիչները `Sync` չեն, քանի որ նրանց հղած տվյալները կարող են այլազգի լինել:
// Հաշվի առնելով, այս ազդանշանն ավելորդ է, բայց պետք է ավելի լավ սխալ հաղորդագրություններ տա:
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Ստեղծում է նոր `NonNull`, որը կախված է, բայց լավ դասավորված:
    ///
    /// Սա օգտակար է այն տեսակների նախաստորագրման համար, որոնք ծուլորեն հատկացնում են, ինչպես դա անում է `Vec::new`-ը:
    ///
    /// Ուշադրություն դարձրեք, որ ցուցիչի արժեքը կարող է պոտենցիալ ներկայացնել `T`-ի վավեր ցուցիչը, ինչը նշանակում է, որ սա չպետք է օգտագործվի որպես "not yet initialized" պահապանի արժեք:
    /// Տեսակները, որոնք ծուլորեն առանձնացնում են, պետք է հետևեն նախնական ձևավորմանը որոշ այլ միջոցներով:
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. mem::align_of()-ը վերադարձնում է ոչ զրոյական օգտագործումը, որն այնուհետև ձուլվում է
        // ա * մուտ Տ.
        // Հետևաբար, `ptr` անվավեր չէ, և պահպանվում են new_unchecked() զանգահարելու պայմանները:
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Վերադարձնում է արժեքի ընդհանուր հղումները: Ի տարբերություն [`as_ref`]-ի, սա չի պահանջում, որ արժեքը նախանշվի:
    ///
    /// Փոփոխական գործընկերոջ համար տե՛ս [`as_uninit_mut`]:
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Այս մեթոդը զանգահարելիս պետք է համոզվեք, որ նշված բոլոր տվյալները ճիշտ են.
    ///
    /// * Սլաքը պետք է պատշաճ կերպով հավասարեցվի:
    ///
    /// * Այն պետք է լինի "dereferencable" ՝ [the module documentation]-ով սահմանված իմաստով:
    ///
    /// * Դուք պետք է կատարեք Rust-ի այլանուն կանոնները, քանի որ վերադարձված կյանքի `'a`-ը կամայականորեն ընտրված է և պարտադիր չէ, որ արտացոլի տվյալների իրական կյանքի տևողությունը:
    ///
    ///   Մասնավորապես, այս կյանքի տևողության ընթացքում հիշողությունը, որի վրա ցուցիչը ցույց է տալիս, չպետք է մուտացիայի ենթարկվի (բացառությամբ `UnsafeCell`-ի ներսում):
    ///
    /// Սա վերաբերում է նույնիսկ եթե այս մեթոդի արդյունքն օգտագործված չէ:
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `self`-ը համապատասխանում է բոլոր պահանջներին
        // տեղեկանքի պահանջները.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Վերադարձնում է արժեքի եզակի հղումներ: Ի տարբերություն [`as_mut`]-ի, սա չի պահանջում, որ արժեքը նախանշվի:
    ///
    /// Համօգտագործված գործընկերոջ համար տե՛ս [`as_uninit_ref`]:
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Այս մեթոդը զանգահարելիս պետք է համոզվեք, որ նշված բոլոր տվյալները ճիշտ են.
    ///
    /// * Սլաքը պետք է պատշաճ կերպով հավասարեցվի:
    ///
    /// * Այն պետք է լինի "dereferencable" ՝ [the module documentation]-ով սահմանված իմաստով:
    ///
    /// * Դուք պետք է կատարեք Rust-ի այլանուն կանոնները, քանի որ վերադարձված կյանքի `'a`-ը կամայականորեն ընտրված է և պարտադիր չէ, որ արտացոլի տվյալների իրական կյանքի տևողությունը:
    ///
    ///   Մասնավորապես, այս կյանքի տևողության ընթացքում ցուցիչը ցույց տված հիշողությունը չպետք է մուտք գործի (կարդա կամ գրի) որևէ այլ ցուցիչի միջոցով:
    ///
    /// Սա վերաբերում է նույնիսկ եթե այս մեթոդի արդյունքն օգտագործված չէ:
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `self`-ը համապատասխանում է բոլոր պահանջներին
        // տեղեկանքի պահանջները.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Ստեղծում է նոր `NonNull`:
    ///
    /// # Safety
    ///
    /// `ptr` պետք է լինի ոչ առոչինչ:
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `ptr`-ն անվավեր է:
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ստեղծում է նոր `NonNull`, եթե `ptr` անվավեր է:
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սլաքն արդեն ստուգված է և զրոյական չէ
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Կատարում է նույն ֆունկցիոնալությունը, ինչ [`std::ptr::from_raw_parts`]-ը, բացառությամբ այն, որ `NonNull` ցուցիչը վերադարձվում է, ի տարբերություն հում `*const` ցուցիչի:
    ///
    ///
    /// Տեսեք [`std::ptr::from_raw_parts`]-ի փաստաթղթերը `ավելի մանրամասն:
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `ptr::from::raw_parts_mut`-ի արդյունքն անվավեր է, քանի որ `data_address`-ն է:
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// (Հնարավոր է `լայն) ցուցիչը քայքայվել է հասցեի և մետատվյալների բաղադրիչներով:
    ///
    /// Սլաքը հետագայում կարող է վերակառուցվել [`NonNull::from_raw_parts`]-ի միջոցով:
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Ձեռք է բերում հիմքում ընկած `*mut` ցուցիչը:
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Վերադարձնում է ընդհանուր հղումը արժեքին: Եթե արժեքը կարող է չհիմնավորված լինել, փոխարենը պետք է օգտագործվի [`as_uninit_ref`]:
    ///
    /// Փոփոխական գործընկերոջ համար տե՛ս [`as_mut`]:
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Այս մեթոդը զանգահարելիս պետք է համոզվեք, որ նշված բոլոր տվյալները ճիշտ են.
    ///
    /// * Սլաքը պետք է պատշաճ կերպով հավասարեցվի:
    ///
    /// * Այն պետք է լինի "dereferencable" ՝ [the module documentation]-ով սահմանված իմաստով:
    ///
    /// * Սլաքը պետք է մատնանշի `T`-ի նախնական օրինակ:
    ///
    /// * Դուք պետք է կատարեք Rust-ի այլանուն կանոնները, քանի որ վերադարձված կյանքի `'a`-ը կամայականորեն ընտրված է և պարտադիր չէ, որ արտացոլի տվյալների իրական կյանքի տևողությունը:
    ///
    ///   Մասնավորապես, այս կյանքի տևողության ընթացքում հիշողությունը, որի վրա ցուցիչը ցույց է տալիս, չպետք է մուտացիայի ենթարկվի (բացառությամբ `UnsafeCell`-ի ներսում):
    ///
    /// Սա վերաբերում է նույնիսկ եթե այս մեթոդի արդյունքն օգտագործված չէ:
    /// (Նախաձեռնման մասին մասը դեռ ամբողջությամբ որոշված չէ, բայց մինչև դրա պահպանումը միակ անվտանգ մոտեցումն է դրանց իսկապես նախաստորագրումը ապահովելը):
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `self`-ը համապատասխանում է բոլոր պահանջներին
        // տեղեկանքի պահանջները.
        unsafe { &*self.as_ptr() }
    }

    /// Վերադարձնում է արժեքի եզակի հղում: Եթե արժեքը կարող է չհիմնավորված լինել, փոխարենը պետք է օգտագործվի [`as_uninit_mut`]:
    ///
    /// Համօգտագործված գործընկերոջ համար տե՛ս [`as_ref`]:
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Այս մեթոդը զանգահարելիս պետք է համոզվեք, որ նշված բոլոր տվյալները ճիշտ են.
    ///
    /// * Սլաքը պետք է պատշաճ կերպով հավասարեցվի:
    ///
    /// * Այն պետք է լինի "dereferencable" ՝ [the module documentation]-ով սահմանված իմաստով:
    ///
    /// * Սլաքը պետք է մատնանշի `T`-ի նախնական օրինակ:
    ///
    /// * Դուք պետք է կատարեք Rust-ի այլանուն կանոնները, քանի որ վերադարձված կյանքի `'a`-ը կամայականորեն ընտրված է և պարտադիր չէ, որ արտացոլի տվյալների իրական կյանքի տևողությունը:
    ///
    ///   Մասնավորապես, այս կյանքի տևողության ընթացքում ցուցիչը ցույց տված հիշողությունը չպետք է մուտք գործի (կարդա կամ գրի) որևէ այլ ցուցիչի միջոցով:
    ///
    /// Սա վերաբերում է նույնիսկ եթե այս մեթոդի արդյունքն օգտագործված չէ:
    /// (Նախաձեռնման մասին մասը դեռ ամբողջությամբ որոշված չէ, բայց մինչև դրա պահպանումը միակ անվտանգ մոտեցումն է դրանց իսկապես նախաստորագրումը ապահովելը):
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `self`-ը համապատասխանում է բոլոր պահանջներին
        // փոփոխական տեղեկանքի պահանջները:
        unsafe { &mut *self.as_ptr() }
    }

    /// Նետում է մեկ այլ տեսակի ցուցիչ:
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `self`-ը `NonNull` ցուցիչ է, որն անպայման անվավեր է
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Բարակ ցուցիչից և երկարությունից ստեղծում է ոչ զրոյական հում կտոր:
    ///
    /// `len` փաստարկը **տարրերի քանակն է**, ոչ թե բայթերի քանակը:
    ///
    /// Այս գործառույթն անվտանգ է, բայց վերադարձի արժեքը չուղարկելը անվտանգ է:
    /// Տեսեք [`slice::from_raw_parts`]-ի փաստաթղթերը `կտորների անվտանգության պահանջների համար:
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ստեղծել սլաքի ցուցիչ, երբ սկսում եք առաջին տարրի ցուցիչը
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Ուշադրություն դարձրեք, որ այս օրինակը արհեստականորեն ցույց է տալիս այս մեթոդի օգտագործումը, բայց `թող կտրենք= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `data`-ը `NonNull` ցուցիչ է, որն անպայման անվավեր է
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Վերադարձնում է ոչ առոչ հում կտորի երկարությունը:
    ///
    /// Վերադարձված արժեքը **տարրերի** թիվն է, ոչ թե բայթերի քանակը:
    ///
    /// Այս գործառույթն անվտանգ է, նույնիսկ այն դեպքում, երբ ոչ զրոյական հում հատվածը չի կարող վերանայվել հատվածի, քանի որ ցուցիչը չունի վավեր հասցե:
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Վերադառնում է ոչ զրոյական ցուցիչը կտորի բուֆերին:
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք գիտենք, որ `self`-ն անվավեր է:
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Վերադարձնում է հում ցուցիչը կտորի բուֆերին:
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Վերադարձնում է ընդհանուր հղումը հնարավոր ոչ նախնական արժեքների հատվածին: Ի տարբերություն [`as_ref`]-ի, սա չի պահանջում, որ արժեքը նախանշվի:
    ///
    /// Փոփոխական գործընկերոջ համար տե՛ս [`as_uninit_slice_mut`]:
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Այս մեթոդը զանգահարելիս պետք է համոզվեք, որ նշված բոլոր տվյալները ճիշտ են.
    ///
    /// * Սլաքը պետք է լինի [valid] ՝ `ptr.len() * mem::size_of::<T>()` շատ բայթանոց ընթերցման համար, և այն պետք է ճիշտ դասավորված լինի: Սա, մասնավորապես, նշանակում է.
    ///
    ///     * Այս հատվածի հիշողության ամբողջ տիրույթը պետք է պարունակվի մեկ հատկացված օբյեկտի մեջ:
    ///       Կտորները երբեք չեն կարող տարածվել մի քանի հատկացված օբյեկտների վրա:
    ///
    ///     * Սլաքը պետք է հավասարեցված լինի նույնիսկ զրոյական երկարության կտորների համար:
    ///     Սրա պատճառն այն է, որ enum-ի դասավորության օպտիմիզացիան կարող է ապավինել հղումներին (ներառյալ ցանկացած երկարության հատվածների) հավասարեցված և ոչ առոչինչ `դրանք տարբերելու համար այլ տվյալներից:
    ///
    ///     Դուք կարող եք ձեռք բերել ցուցիչ, որը օգտագործելի է որպես `data` զրոյական երկարությամբ շերտերի համար, օգտագործելով [`NonNull::dangling()`]:
    ///
    /// * Կտորի `ptr.len() * mem::size_of::<T>()` ընդհանուր չափը չպետք է լինի `isize::MAX`-ից մեծ:
    ///   Տե՛ս [`pointer::offset`]-ի անվտանգության փաստաթղթերը:
    ///
    /// * Դուք պետք է կատարեք Rust-ի այլանուն կանոնները, քանի որ վերադարձված կյանքի `'a`-ը կամայականորեն ընտրված է և պարտադիր չէ, որ արտացոլի տվյալների իրական կյանքի տևողությունը:
    ///   Մասնավորապես, այս կյանքի տևողության ընթացքում հիշողությունը, որի վրա ցուցիչը ցույց է տալիս, չպետք է մուտացիայի ենթարկվի (բացառությամբ `UnsafeCell`-ի ներսում):
    ///
    /// Սա վերաբերում է նույնիսկ եթե այս մեթոդի արդյունքն օգտագործված չէ:
    ///
    /// Տես նաև [`slice::from_raw_parts`]:
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `as_uninit_slice`-ի անվտանգության պայմանագիրը:
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Վերադարձնում է եզակի հղում հնարավոր ոչ նախնական արժեքների հատվածին: Ի տարբերություն [`as_mut`]-ի, սա չի պահանջում, որ արժեքը նախանշվի:
    ///
    /// Համօգտագործված գործընկերոջ համար տե՛ս [`as_uninit_slice`]:
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Այս մեթոդը զանգահարելիս պետք է համոզվեք, որ նշված բոլոր տվյալները ճիշտ են.
    ///
    /// * Սլաքը `ptr.len() * mem::size_of::<T>()` շատ բայթ կարդալու և գրելու համար ցուցիչը պետք է լինի [valid], և այն պետք է ճիշտ դասավորված լինի: Սա, մասնավորապես, նշանակում է.
    ///
    ///     * Այս հատվածի հիշողության ամբողջ տիրույթը պետք է պարունակվի մեկ հատկացված օբյեկտի մեջ:
    ///       Կտորները երբեք չեն կարող տարածվել մի քանի հատկացված օբյեկտների վրա:
    ///
    ///     * Սլաքը պետք է հավասարեցված լինի նույնիսկ զրոյական երկարության կտորների համար:
    ///     Սրա պատճառն այն է, որ enum-ի դասավորության օպտիմիզացիան կարող է ապավինել հղումներին (ներառյալ ցանկացած երկարության հատվածների) հավասարեցված և ոչ առոչինչ `դրանք տարբերելու համար այլ տվյալներից:
    ///
    ///     Դուք կարող եք ձեռք բերել ցուցիչ, որը օգտագործելի է որպես `data` զրոյական երկարությամբ շերտերի համար, օգտագործելով [`NonNull::dangling()`]:
    ///
    /// * Կտորի `ptr.len() * mem::size_of::<T>()` ընդհանուր չափը չպետք է լինի `isize::MAX`-ից մեծ:
    ///   Տե՛ս [`pointer::offset`]-ի անվտանգության փաստաթղթերը:
    ///
    /// * Դուք պետք է կատարեք Rust-ի այլանուն կանոնները, քանի որ վերադարձված կյանքի `'a`-ը կամայականորեն ընտրված է և պարտադիր չէ, որ արտացոլի տվյալների իրական կյանքի տևողությունը:
    ///   Մասնավորապես, այս կյանքի տևողության ընթացքում ցուցիչը ցույց տված հիշողությունը չպետք է մուտք գործի (կարդա կամ գրի) որևէ այլ ցուցիչի միջոցով:
    ///
    /// Սա վերաբերում է նույնիսկ եթե այս մեթոդի արդյունքն օգտագործված չէ:
    ///
    /// Տես նաև [`slice::from_raw_parts_mut`]:
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Սա անվտանգ է, քանի որ `memory`-ն ուժի մեջ է `memory.len()` շատ բայթ կարդալու և գրելու համար:
    /// // Նկատի ունեցեք, որ `memory.as_mut()` զանգահարելը այստեղ չի թույլատրվում, քանի որ բովանդակությունը կարող է չհամալրված լինել:
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `as_uninit_slice_mut`-ի անվտանգության պայմանագիրը:
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Վերադարձնում է հում ցուցիչը տարրի կամ ենթաբաժնի ՝ առանց սահմանների ստուգում կատարելու:
    ///
    /// Այս մեթոդը արտաքին սահմանների ինդեքսով զանգահարելը կամ `self`-ի կողմից չհեռացվող լինելը *[չսահմանված վարք]* է, նույնիսկ եթե ստացված ցուցիչը չի օգտագործվում:
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողն ապահովում է, որ `self`-ը դյուրագրգիռ է և `index`-ը `սահմաններում:
        // Որպես արդյունք, ստացված ցուցիչը չի կարող լինել NULL:
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Եզակի ցուցիչը չի կարող զրոյական լինել, ուստի պայմանները `
        // new_unchecked() հարգված են
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Փոփոխական տեղեկանքը չի կարող առոչինչ լինել:
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հղումը չի կարող առոչինչ լինել, ուստի պայմանները
        // new_unchecked() հարգված են
        unsafe { NonNull { pointer: reference as *const T } }
    }
}