use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Հում ոչ անվավեր `*mut T`-ի շուրջ փաթաթան, որը ցույց է տալիս, որ այս փաթաթիչի տիրապետողին է պատկանում վկայականը:
/// Օգտակար է աբստրակցիաներ կառուցելու համար, ինչպիսիք են `Box<T>`, `Vec<T>`, `String` և `HashMap<K, V>`:
///
/// Ի տարբերություն `*mut T`-ի, `Unique<T>`-ը իրեն "as if" է պահում, դա `T`-ի օրինակ էր:
/// Այն իրականացնում է `Send`/`Sync`, եթե `T` `Send`/`Sync` է:
/// Դա նաև ենթադրում է, որ ամուր կեղծանվան տեսակը երաշխավորում է, որ `T`-ի օրինակ կարող է ակնկալել.
/// ցուցիչի հղիչը չպետք է փոփոխվի առանց իր յուրահատուկ եզակի ուղու տանելու:
///
/// Եթե անորոշ եք, արդյոք ճիշտ է օգտագործել `Unique` ձեր նպատակների համար, մտածեք օգտագործել `NonNull`, որն ունի ավելի թույլ իմաստաբանություն:
///
///
/// Ի տարբերություն `*mut T`-ի, ցուցիչը միշտ պետք է լինի ոչ առարկայական, նույնիսկ եթե ցուցիչը երբեք չի զետեղվում:
/// Սա այն է, որ հաշվարկողները կարող են օգտագործել այս արգելված արժեքը որպես խտրականություն. `Option<Unique<T>>`-ն ունի նույն չափը, ինչ `Unique<T>`-ը:
/// Այնուամենայնիվ, ցուցիչը կարող է դեռ կախվել, եթե չուղարկվի:
///
/// Ի տարբերություն `*mut T`-ի, `Unique<T>`-ը փոխվում է `T`-ի նկատմամբ:
/// Սա միշտ պետք է ճիշտ լինի ցանկացած տեսակի համար, որը պաշտպանում է Unique-ի այլանուն պահանջները:
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: այս նշիչը որևէ հետևանք չի թողնում շեղման համար, բայց անհրաժեշտ է
    // որպեսզի dropck-ը հասկանա, որ մենք տրամաբանորեն տիրում ենք `T`-ի:
    //
    // Մանրամասների համար տես ՝
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ցուցիչները `Send` են, եթե `T` `Send` է, քանի որ նրանց հղած տվյալներն անաչառ են:
/// Նկատի ունեցեք, որ այս կեղծանուն անփոփոխը չի կիրառվում տիպային համակարգի կողմից.`Unique`-ի օգտագործմամբ աբստրակցիան պետք է պարտադրի այն:
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ցուցիչները `Sync` են, եթե `T` `Sync` է, քանի որ նրանց հղած տվյալներն անաչառ են:
/// Նկատի ունեցեք, որ այս կեղծանուն անփոփոխը չի կիրառվում տիպային համակարգի կողմից.`Unique`-ի օգտագործմամբ աբստրակցիան պետք է պարտադրի այն:
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Ստեղծում է նոր `Unique`, որը կախված է, բայց լավ դասավորված:
    ///
    /// Սա օգտակար է այն տեսակների նախաստորագրման համար, որոնք ծուլորեն հատկացնում են, ինչպես դա անում է `Vec::new`-ը:
    ///
    /// Ուշադրություն դարձրեք, որ ցուցիչի արժեքը կարող է պոտենցիալ ներկայացնել `T`-ի վավեր ցուցիչը, ինչը նշանակում է, որ սա չպետք է օգտագործվի որպես "not yet initialized" պահապանի արժեք:
    /// Տեսակները, որոնք ծուլորեն առանձնացնում են, պետք է հետևեն նախնական ձևավորմանը որոշ այլ միջոցներով:
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. mem::align_of()-ը վերադարձնում է վավեր, ոչ զրոյական ցուցիչ: Ի
        // Այսպիսով, new_unchecked() զանգահարելու պայմանները պահպանվում են:
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Ստեղծում է նոր `Unique`:
    ///
    /// # Safety
    ///
    /// `ptr` պետք է լինի ոչ առոչինչ:
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `ptr`-ն անվավեր է:
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ստեղծում է նոր `Unique`, եթե `ptr` անվավեր է:
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սլաքն արդեն ստուգված է և զրոյական չէ:
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Ձեռք է բերում հիմքում ընկած `*mut` ցուցիչը:
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Հանում է բովանդակությունը:
    ///
    /// Արդյունքում գոյություն ունեցող կյանքը պարտավոր է ինքն իրեն, այնպես որ սա իրեն "as if" է պահում, իրականում փոխառվող T-ի օրինակ էր:
    /// Եթե (unbound) ավելի երկար կյանք է անհրաժեշտ, օգտագործեք `&*my_ptr.as_ptr()`:
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `self`-ը համապատասխանում է բոլոր պահանջներին
        // տեղեկանքի պահանջները.
        unsafe { &*self.as_ptr() }
    }

    /// Փոփոխականորեն հետ վերցնում են բովանդակությունը:
    ///
    /// Արդյունքում գոյություն ունեցող կյանքը պարտավոր է ինքն իրեն, այնպես որ սա իրեն "as if" է պահում, իրականում փոխառվող T-ի օրինակ էր:
    /// Եթե (unbound) ավելի երկար կյանք է անհրաժեշտ, օգտագործեք `&mut *my_ptr.as_ptr()`:
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `self`-ը համապատասխանում է բոլոր պահանջներին
        // փոփոխական տեղեկանքի պահանջները:
        unsafe { &mut *self.as_ptr() }
    }

    /// Նետում է մեկ այլ տեսակի ցուցիչ:
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Unique::new_unchecked()-ը ստեղծում է նոր յուրահատուկ և կարիքներ
        // տրված ցուցիչը զրո չլինելու համար:
        // Քանի որ մենք ինքներս ենք անցնում որպես ցուցիչ, դա չի կարող լինել առ ոչինչ:
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Փոփոխական տեղեկանքը չի կարող առոչինչ լինել
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}