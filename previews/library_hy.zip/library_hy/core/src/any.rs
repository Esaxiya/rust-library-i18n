//! Այս մոդուլը իրականացնում է `Any` trait, որը հնարավորություն է տալիս ցանկացած `'static` տեսակի դինամիկ մուտքագրում գործարկման ժամանակ արտացոլման միջոցով:
//!
//! `Any` ինքնին կարող է օգտագործվել `TypeId` ստանալու համար, և ունի ավելի շատ հատկություններ, երբ օգտագործվում է որպես trait օբյեկտ:
//! Որպես `&dyn Any` (փոխառված trait օբյեկտ), այն ունի `is` և `downcast_ref` մեթոդներ, ստուգելու համար, արդյոք պարունակվող արժեքը տրված տեսակի է, և ներքին արժեքին որպես տեսակ հղում ստանալու համար:
//! Որպես `&mut dyn Any`, կա նաև `downcast_mut` մեթոդը ՝ ներքին արժեքի փոփոխական հղում ստանալու համար:
//! `Box<dyn Any>` ավելացնում է `downcast` մեթոդը, որը փորձում է փոխարկել `Box<T>`:
//! Տե՛ս [`Box`] փաստաթղթերը ամբողջական մանրամասների համար:
//!
//! Ուշադրություն դարձրեք, որ `&dyn Any`-ը սահմանափակվում է այն բանի վրա, թե արդյոք արժեքը նշված է կոնկրետ տեսակի, և չի կարող օգտագործվել այն տիպի trait-ի ստուգման համար:
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Խելացի ցուցիչներ և `dyn Any`
//!
//! Մի պահվածք, որը պետք է հիշել `Any` որպես trait օբյեկտ օգտագործելիս, հատկապես `Box<dyn Any>` կամ `Arc<dyn Any>` նման տեսակների հետ, այն է, որ պարզապես `.type_id()` արժեքով զանգահարելը կստեղծի *կոնտեյների*`TypeId`, այլ ոչ թե հիմքում ընկած trait օբյեկտ:
//!
//! Դրանից կարելի է խուսափել `փոխարենը խելացի ցուցիչը `&dyn Any`-ի վերափոխելով, որը կվերադարձնի օբյեկտի `TypeId`-ը:
//! Օրինակ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Դուք, ամենայն հավանականությամբ, կցանկանաք սա ՝
//! let actual_id = (&*boxed).type_id();
//! // ... քան սա:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Հաշվի առեք մի իրավիճակ, երբ մենք ուզում ենք դուրս բերել գործառույթին փոխանցված արժեք:
//! Մենք գիտենք, թե ինչ արժեքի վրա ենք աշխատում, իրականացնում է Debug-ը, բայց չգիտենք դրա կոնկրետ տեսակը: Մենք ուզում ենք հատուկ վերաբերմունք ցուցաբերել որոշակի տեսակների. Այս դեպքում տպում ենք String արժեքների երկարությունը մինչև դրանց արժեքը:
//! Կոմպիլյացիայի ժամանակ մենք չգիտենք մեր արժեքի կոնկրետ տեսակը, ուստի դրա փոխարեն պետք է օգտագործել գործարկման ժամանակի արտացոլումը:
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Լոգերի գործառույթը ցանկացած տեսակի համար, որն իրականացնում է Սխալման սխալ:
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Փորձեք մեր արժեքը վերափոխել `String`-ի:
//!     // Հաջողության դեպքում մենք ցանկանում ենք դուրս բերել String`-ի երկարությունը, ինչպես նաև դրա արժեքը:
//!     // Եթե ոչ, ապա դա այլ տեսակ է. Պարզապես տպիր անզարդ:
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Այս գործառույթը ցանկանում է մուտքագրել իր պարամետրը նախքան դրա հետ աշխատանքը կատարելը:
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... կատարել այլ աշխատանք
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Zանկացած trait
///////////////////////////////////////////////////////////////////////////////

/// A trait ՝ դինամիկ մուտքագրում ընդօրինակելու համար:
///
/// Տեսակների մեծամասնությունը իրականացնում է `Any`: Այնուամենայնիվ, ցանկացած «ոչ ստատիկ» հղում պարունակող ցանկացած տիպ չունի:
/// Տեսեք [module-level documentation][mod]-ը ՝ ավելի մանրամասն:
///
/// [mod]: crate::any
// Այս trait-ն անապահով չէ, չնայած մենք ապավինում ենք դրա անապահով ծածկագրում (օրինակ ՝ `downcast`) դրա միակ իմպլեկտ `type_id` գործառույթի առանձնահատկություններին: Սովորաբար, դա խնդիր կլիներ, բայց քանի որ `Any`-ի միակ ազդեցությունը վերմակի կիրառումն է, ոչ մի այլ կոդ չի կարող իրականացնել `Any`:
//
// Մենք կարող ենք հավաստիորեն դարձնել այս trait անվնաս-դա չի հանգեցնի կոտրվածքի, քանի որ մենք վերահսկում ենք բոլոր իրականացումները, բայց մենք նախընտրում ենք դա չանել, քանի որ դա և՛ իրականում անհրաժեշտ չէ, և՛ կարող է շփոթեցնել օգտվողներին ՝ անվնաս traits-ի և ոչ անվտանգ մեթոդների տարբերակման վերաբերյալ (այսինքն ՝ `type_id`-ին զանգահարելը դեռ անվտանգ է, բայց մենք հավանաբար կցանկանայինք փաստաթղթերում նշել որպես այդպիսին):
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ստանում է `self`-ի `TypeId`-ը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Ensionանկացած trait օբյեկտների ընդլայնման մեթոդներ:
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Համոզվեք, որ, օրինակ, թեմային միանալու արդյունքը կարող է տպվել և հետևաբար օգտագործվել `unwrap`-ի հետ:
// Կարող է, ի վերջո, այլևս անհրաժեշտ չլինել, եթե առաքումն աշխատում է վերամբարձի հետ:
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Վերադարձնում է `true`, եթե տուփով տիպը նույնն է, ինչ `T`-ը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Ստացեք `TypeId` այն տիպից, որի հետ այս գործառույթն ակնարկվում է:
        let t = TypeId::of::<T>();

        // Ձեռք բերեք տիպի `TypeId` trait (`self`) օբյեկտում:
        let concrete = self.type_id();

        // Համեմատեք թե 'TypeId-ը հավասարության մասին:
        t == concrete
    }

    /// Վերադարձնում է որոշակի հղում տուփի արժեքին, եթե այն `T` տիպի է, կամ `None`, եթե դա ոչ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Պարզապես ստուգեցինք ՝ արդյո՞ք մենք ճիշտ տեսակն ենք մատնանշում, և կարող ենք ապավինել դրան
            // դա ստուգում է հիշողության անվտանգությունը, քանի որ մենք ներդրել ենք ցանկացած տարբերակ բոլոր տեսակի համար.ոչ մի այլ ազդանշան չի կարող գոյություն ունենալ, քանի որ դրանք հակասում են մեր ազդեցությանը:
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Վերադարձնում է ինչ-որ փոփոխական հղում տուփի արժեքին, եթե այն `T` տիպի է, կամ `None`, եթե ոչ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Պարզապես ստուգեցինք ՝ արդյո՞ք մենք ճիշտ տեսակն ենք մատնանշում, և կարող ենք ապավինել դրան
            // դա ստուգում է հիշողության անվտանգությունը, քանի որ մենք ներդրել ենք ցանկացած տարբերակ բոլոր տեսակի համար.ոչ մի այլ ազդանշան չի կարող գոյություն ունենալ, քանի որ դրանք հակասում են մեր ազդեցությանը:
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Առաջ է մղվում `Any` տիպի վրա սահմանված մեթոդի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Առաջ է մղվում `Any` տիպի վրա սահմանված մեթոդի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Առաջ է մղվում `Any` տիպի վրա սահմանված մեթոդի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Առաջ է մղվում `Any` տիպի վրա սահմանված մեթոդի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Առաջ է մղվում `Any` տիպի վրա սահմանված մեթոդի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Առաջ է մղվում `Any` տիպի վրա սահմանված մեթոդի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID-ը և դրա մեթոդները
///////////////////////////////////////////////////////////////////////////////

/// `TypeId`-ը տիպի համար ներկայացնում է գլոբալ եզակի նույնացուցիչ:
///
/// Յուրաքանչյուր `TypeId` անթափանց օբյեկտ է, որը թույլ չի տալիս ստուգել ներսում եղածը, բայց թույլ է տալիս այնպիսի հիմնական գործողություններ, ինչպիսիք են կլոնավորումը, համեմատությունը, տպումը և ցուցադրումը:
///
///
/// A `TypeId`-ը ներկայումս հասանելի է միայն `'static`-ին վերագրող տիպերի համար, բայց այս սահմանափակումը կարող է վերացվել future-ում:
///
/// Չնայած `TypeId`-ն իրականացնում է `Hash`, `PartialOrd` և `Ord`, հարկ է նշել, որ հեշերը և պատվերը կտարբերվեն Rust թողարկումների միջև:
/// Codeգուշացեք ձեր կոդի ներսում ապավինելուց:
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Վերադարձնում է այն տիպի `TypeId`, որի հետ մեկտեղացվել է այս ընդհանուր գործառույթը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Վերադարձնում է տիպի անունը որպես տողի կտոր:
///
/// # Note
///
/// Սա նախատեսված է ախտորոշիչ օգտագործման համար:
/// Վերադարձված տողի ճշգրիտ բովանդակությունն ու ձևաչափը չեն նշվում, բացառությամբ տեսակի լավագույն փորձ կատարող նկարագրության:
/// Օրինակ, `type_name::<Option<String>>()` տողերի շարքում `"Option<String>"` և `"std::option::Option<std::string::String>"` են:
///
///
/// Վերադարձված տողը չպետք է համարվի որպես տիպի յուրահատուկ նույնացուցիչ, քանի որ բազմաթիվ տիպեր կարող են քարտեզագրվել նույն տեսակի անունով:
/// Նմանապես, երաշխիք չկա, որ տիպի բոլոր մասերը կհայտնվեն վերադարձված տողի մեջ. Օրինակ ՝ կյանքի տևողությունները ներկայումս ներառված չեն:
/// Բացի այդ, արդյունքը կարող է փոխվել կազմողի տարբերակների միջև:
///
/// Ներկայիս կիրառումն օգտագործում է նույն ենթակառուցվածքը, ինչ կազմողի ախտորոշումն ու debuginfo-ն, բայց դա երաշխավորված չէ:
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Վերադառնում է մատնանշված արժեքի տեսակի անունը `որպես լարային հատված:
/// Սա նույնն է, ինչ `type_name::<T>()`-ը, բայց կարող է օգտագործվել այնտեղ, երբ փոփոխականի տեսակը հեշտությամբ մատչելի չէ:
///
/// # Note
///
/// Սա նախատեսված է ախտորոշիչ օգտագործման համար: Տողի ճշգրիտ պարունակությունը և ձևաչափը չեն նշվում, բացի տեսակի ամենալավ նկարագրությունը լինելուց:
/// Օրինակ, `type_name_of_val::<Option<String>>(None)`-ը կարող է վերադարձնել `"Option<String>"` կամ `"std::option::Option<std::string::String>"`, բայց ոչ `"foobar"`:
///
/// Բացի այդ, արդյունքը կարող է փոխվել կազմողի տարբերակների միջև:
///
/// Այս գործառույթը չի լուծում trait օբյեկտները, ինչը նշանակում է, որ `type_name_of_val(&7u32 as &dyn Debug)`-ը կարող է վերադարձնել `"dyn Debug"`, բայց ոչ `"u32"`:
///
/// Տիպի անունը չպետք է համարվի տեսակի եզակի նույնացուցիչ:
/// բազմակի տեսակները կարող են կիսվել նույն տեսակի անունով:
///
/// Ներկայիս կիրառումն օգտագործում է նույն ենթակառուցվածքը, ինչ կազմողի ախտորոշումն ու debuginfo-ն, բայց դա երաշխավորված չէ:
///
/// # Examples
///
/// Տպում է կանխադրված ամբողջ թվերի և բոց տեսակները:
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}