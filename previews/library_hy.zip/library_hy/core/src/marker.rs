//! Պարզունակ traits և տեսակների հիմնական հատկությունները ներկայացնող տեսակներ:
//!
//! Rust տեսակները կարող են դասակարգվել տարբեր օգտակար ձևերով ՝ ըստ իրենց ներքին հատկությունների:
//! Այս դասակարգումները ներկայացված են որպես traits:
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Տեսակները, որոնք կարող են փոխանցվել թելերի սահմաններով:
///
/// Այս trait-ն ավտոմատ կերպով իրականացվում է, երբ կազմողը որոշում է դրա նպատակահարմարությունը:
///
/// Ոչ «Ուղարկել» տիպի օրինակ է [`rc::Rc`][`Rc`] հղման հաշվիչ ցուցիչը:
/// Եթե երկու թել փորձում են կլոնավորել [«Rc» »-երը, որոնք մատնանշում են նույն տեղեկանքի հաշվարկված արժեքը, նրանք կարող են փորձել միաժամանակ թարմացնել հղումների քանակը, որը [undefined behavior][ub] է, քանի որ [`Rc`]-ը չի օգտագործում ատոմային գործողություններ:
///
/// Նրա զարմիկ [`sync::Arc`][arc]-ն օգտագործում է ատոմային գործողություններ (ինչ-որ գլխավերևում կատարում), ուստի `Send` է:
///
/// Տե՛ս [the Nomicon](../../nomicon/send-and-sync.html) ՝ ավելի մանրամասն:
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Տիպեր հաստատուն չափսերով, որոնք հայտնի են կազմման ժամանակ:
///
/// Տիպի բոլոր պարամետրերն ունեն անուղղակի `Sized` կապակցվածություն: `?Sized` հատուկ շարահյուսությունը կարող է օգտագործվել այդ կապվածը հանելու համար, եթե դա տեղին չէ:
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // կառուցվածք FooUse(Foo<[i32]>);//սխալ. Չափը [i32]-ի համար չի իրականացվում
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Բացառությունը մեկն է `trait-ի անուղղակի `Self` տեսակ:
/// trait-ը չունի անուղղակի `Sized` կապված, քանի որ դա անհամատեղելի է [trait օբյեկտի] հետ, որտեղ, ըստ սահմանման, trait-ն անհրաժեշտ է աշխատել բոլոր հնարավոր իրականացնողների հետ, և, այդպիսով, կարող է լինել ցանկացած չափի:
///
///
/// Չնայած Rust-ը թույլ կտա ձեզ `Sized`-ը կապել trait-ի հետ, այնուհետև դուք չեք կարողանա օգտագործել այն trait օբյեկտ կազմելու համար.
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // թող y: &dyn բար= &Impl;//սխալ. trait `Bar`-ը չի կարող օբյեկտի վերածվել
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // օրինակ, Default-ի համար, որը պահանջում է, որ `[T]: !Default`-ը գնահատելի լինի
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Տեսակներ, որոնք կարող են լինել "unsized" դինամիկ չափի տիպի:
///
/// Օրինակ, `[i8; 2]` չափի զանգվածը իրականացնում է `Unsize<[i8]>` և `Unsize<dyn fmt::Debug>`:
///
/// `Unsize`-ի բոլոր ներդրումները ավտոմատ կերպով տրամադրվում են կազմողի կողմից:
///
/// `Unsize` իրականացվում է ՝
///
/// - `[T; N]` `Unsize<[T]>` է
/// - `T` `Unsize<dyn Trait>` է, երբ `T: Trait`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` է, եթե ՝
///   - `T: Unsize<U>`
///   - Foo-ն կառուցվածք է
///   - `Foo`-ի միայն վերջին դաշտում կա մի տեսակ, որը ներառում է `T`
///   - `T` որևէ այլ դաշտի տիպի մաս չէ
///   - `Bar<T>: Unsize<Bar<U>>`, եթե `Foo`-ի վերջին դաշտը ունի `Bar<T>` տեսակ
///
/// `Unsize` օգտագործվում է [`ops::CoerceUnsized`]-ի հետ միասին `թույլ տալու համար, որ "user-defined" բեռնարկղերը, ինչպիսիք են [`Rc`]-ը, դինամիկ չափի տեսակներ պարունակեն:
/// Տեսեք [DST coercion RFC][RFC982] և [the nomicon entry on coercion][nomicon-coerce] լրացուցիչ մանրամասների համար:
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Պահանջվող trait-ը նախշերի համընկնումներում օգտագործվող հաստատունների համար:
///
/// `PartialEq` ածանցյալ ցանկացած տիպ ինքնաբերաբար իրականացնում է այս trait-ը,*անկախ* դրա տիպի պարամետրերի ներդրումը `Eq`:
///
/// Եթե `const` իրը պարունակում է ինչ-որ տիպ, որը չի իրականացնում այս trait-ը, ապա այդ տիպը կամ (1.) չի իրականացնում `PartialEq` (ինչը նշանակում է, որ հաստատունը չի ապահովի այդ համեմատության մեթոդը, որի ծածկագրերի ստեղծումը ենթադրում է, որ մատչելի է), կամ (2.)-ն այն իրականացնում է *իր սեփականը*`PartialEq`-ի տարբերակը (որը մենք ենթադրում ենք, որ չի համապատասխանում կառուցվածքային-հավասարության համեմատությանը):
///
///
/// Վերոնշյալ երկու սցենարներից որևէ մեկում մենք մերժում ենք նման հաստատունի օգտագործումը օրինաչափության համընկնումում:
///
/// Տե՛ս նաև [structural match RFC][RFC1445] և [issue 63438], որոնք դրդում էին ատրիբուտների վրա հիմնված դիզայնից այս trait տեղափոխվելուն:
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Պահանջվող trait-ը նախշերի համընկնումներում օգտագործվող հաստատունների համար:
///
/// `Eq` ածանցյալ ցանկացած տիպ ինքնաբերաբար իրականացնում է այս trait-ը ՝*անկախ* դրա տիպի պարամետրերի ներդրումը `Eq`:
///
/// Սա կոտրվածք է ՝ մեր տիպի համակարգի սահմանափակումների շուրջ աշխատելու համար:
///
/// # Background
///
/// Մենք ուզում ենք պահանջել, որ օրինաչափությունների համընկնումներում օգտագործվող բաղկացուցիչների տիպերը ունենան `#[derive(PartialEq, Eq)]` հատկանիշ:
///
/// Ավելի իդեալական աշխարհում մենք կարող ենք ստուգել այդ պահանջը ՝ պարզապես ստուգելով, որ տվյալ տեսակը իրականացնում է և՛ `StructuralPartialEq` Z0 նեղուց0 and *, և the `Eq` Z0 նեղուց 0 0:
/// Այնուամենայնիվ, դուք կարող եք ունենալ ADT-ներ, որոնք *անում են*`derive(PartialEq, Eq)`, և լինել դեպք, որը մենք ցանկանում ենք, որ կազմողն ընդունի, և այնուամենայնիվ, հաստատունի տեսակը չի իրականացնում `Eq`:
///
/// Այսինքն ՝ այսպիսի դեպք.
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Վերոնշյալ կոդի խնդիրն այն է, որ `Wrap<fn(&())>`-ը չի իրականացնում `PartialEq`, ոչ `Eq`, քանի որ «<> a> fn(&'a _)` does not implement those traits.)-ի համար
///
/// Հետևաբար, մենք չենք կարող ապավինել `StructuralPartialEq`-ի և զուտ `Eq`-ի միամիտ ստուգմանը:
///
/// Որպես կոտրվածք ՝ դրա շուրջ աշխատելու համար, մենք օգտագործում ենք երկու առանձին traits, որոնք ներարկվել են յուրաքանչյուր երկու (`#[derive(PartialEq)]` և `#[derive(Eq)]`) ածանցյալներից և ստուգում են, որ երկուսն էլ ներկա են, որպես կառուցվածքային համընկնումների ստուգում:
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Տեսակներ, որոնց արժեքները կարող են կրկնօրինակվել `պարզապես բիթեր պատճենելով:
///
/// Լռելյայնորեն, փոփոխական կապակցություններն ունեն «տեղափոխել իմաստաբանություն»: Այլ կերպ ասած:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` տեղափոխվել է `y`, և այն չի կարող օգտագործվել
///
/// // println! ("{: ?}", x);//սխալ. տեղափոխված արժեքի օգտագործում
/// ```
///
/// Այնուամենայնիվ, եթե մի տեսակ իրականացնում է `Copy`, ապա դրա փոխարեն կա «կրկնօրինակման իմաստաբանություն».
///
/// ```
/// // Մենք կարող ենք բերել `Copy` իրականացում:
/// // `Clone` նույնպես պահանջվում է, քանի որ դա `Copy` գերբեռնվածություն է:
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x`-ի պատճեն է
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Կարևոր է նշել, որ այս երկու օրինակներում միակ տարբերությունն այն է, թե արդյոք հանձնարարությունից հետո թույլատրվում է մուտք գործել `x`:
/// Կափարիչի տակ և՛ պատճենը, և՛ տեղափոխումը կարող են հանգեցնել հիշողության մեջ բիթերի պատճենմանը, չնայած դա երբեմն հեռացվում է օպտիմալացված:
///
/// ## Ինչպե՞ս կարող եմ իրականացնել `Copy`-ը:
///
/// Ձեր տեսակի վրա `Copy`-ն իրականացնելու երկու եղանակ կա: `derive`-ի օգտագործումն ամենապարզն է.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Դուք նաև կարող եք ձեռքով իրականացնել `Copy` և `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Այս երկուսի միջեւ կա մի փոքր տարբերություն. `derive` ռազմավարությունը նաև տեղադրելու է `Copy` կապված տիպի պարամետրերի հետ, ինչը միշտ չէ, որ ցանկալի է:
///
/// ## Ի՞նչ տարբերություն `Copy`-ի և `Clone`-ի միջև:
///
/// Պատճենները տեղի են ունենում անուղղակիորեն, օրինակ ՝ `y = x` հանձնարարականի մաս: `Copy`-ի պահվածքը ծանրաբեռնված չէ.այն միշտ մի պարզ իմաստուն օրինակ է:
///
/// Կլոնավորումը բացահայտ գործողություն է, `x.clone()`: [`Clone`]-ի իրականացումը կարող է ապահովել ցանկացած տիպի հատուկ վարքագիծ, որն անհրաժեշտ է արժեքները անվտանգ կրկնօրինակելու համար:
/// Օրինակ, [`Clone`]-ի [`String`]-ի իրականացման համար անհրաժեշտ է կույտի մեջ պատճենել լարային բուֆերը:
/// [`String`] արժեքների պարզ բիթային կրկնօրինակը պարզապես պատճենում էր ցուցիչը ՝ տողից կրկնակի ազատ տանելով:
/// Այդ պատճառով [`String`]-ը [`Clone`] է, բայց ոչ `Copy`:
///
/// [`Clone`] `Copy`-ի գերբարակ է, ուստի այն ամենը, ինչ `Copy` է, պետք է նաև ներդնի [`Clone`]:
/// Եթե տիպը `Copy` է, ապա դրա [`Clone`] ներդրումը պետք է միայն վերադարձնի `*self` (տե՛ս վերևում բերված օրինակը):
///
/// ## Ե՞րբ կարող է իմ տեսակը լինել `Copy`:
///
/// Մի տեսակ կարող է իրականացնել `Copy`, եթե դրա բոլոր բաղադրիչներն իրականացնում են `Copy`: Օրինակ, այս կառուցվածքը կարող է լինել `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Կառուցվածքը կարող է լինել `Copy`, իսկ [`i32`]-ը `Copy`, ուստի `Point` իրավասու է լինել `Copy`:
/// Ընդհակառակը, հաշվի առեք
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` կառուցվածքը չի կարող իրականացնել `Copy`, քանի որ [`Vec<T>`] `Copy` չէ: Եթե փորձենք դուրս բերել `Copy` իրականացում, մենք սխալ կստանանք.
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// (`&T`) համօգտագործվող հղումները նաև `Copy` են, ուստի տեսակը կարող է լինել `Copy`, նույնիսկ եթե այն պահում է `T` տիպի ընդհանուր հղումներ, որոնք * ** `Copy` չեն:
/// Հաշվի առեք հետևյալ կառուցվածքը, որը կարող է իրականացնել `Copy`, քանի որ այն ընդամենը պահում է *ընդհանուր հղում* վերևից վերևից մեր ոչ պատճենող `PointList` տիպին:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Ե՞րբ * իմ տեսակը չի կարող `Copy` լինել:
///
/// Որոշ տեսակներ հնարավոր չէ ապահով կերպով պատճենել: Օրինակ, `&mut T`-ի պատճենումը կստեղծի այլընտրանքային փոփոխական հղում:
/// [`String`]-ի պատճենումը կրկնօրինակում է [«Լարային»] բուֆերը կառավարելու պատասխանատվությունը, ինչը կրկնակի անվճար է:
///
/// Ընդհանրացնելով վերջին դեպքը ՝ [`Drop`] իրականացնող ցանկացած տիպ չի կարող լինել `Copy`, քանի որ այն կառավարում է որոշ ռեսուրսներ ՝ բացի իր սեփական [`size_of::<T>`] բայթերից:
///
/// Եթե փորձեք `Copy`-ն իրականացնել ոչ պատճենող տվյալներ պարունակող կառուցվածքի կամ թվի վրա, ապա կստանաք [E0204] սխալ:
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Ե՞րբ *պետք է* իմ տեսակը լինի `Copy`:
///
/// Ընդհանուր առմամբ, եթե ձեր _can_ տեսակն իրականացնում է `Copy`, ապա դա պետք է:
/// Հիշեք, սակայն, որ `Copy`-ի իրականացումը ձեր տեսակի հանրային API-ի մի մասն է:
/// Եթե future-ի տեսակը կարող է դառնալ ոչ «Պատճեն», ապա խելամիտ կլինի `Copy`-ի իրականացումն այժմ բաց թողնել, API-ի կոտրվածքային փոփոխությունից խուսափելու համար:
///
/// ## Լրացուցիչ իրականացնողներ
///
/// Բացի [implementors listed below][impls]-ից, `Copy`-ն իրականացնում են նաև հետևյալ տեսակները.
///
/// * Ֆունկցիայի կետի տեսակները (այսինքն `յուրաքանչյուր ֆունկցիայի համար սահմանված հստակ տեսակները)
/// * Ֆունկցիայի ցուցիչի տեսակները (օրինակ ՝ `fn() -> i32`)
/// * Rayանգվածի տեսակները, բոլոր չափերի համար, եթե իրի տեսակը նաև իրականացնում է `Copy` (օրինակ ՝ `[i32; 123456]`)
/// * Եզակի տիպեր, եթե յուրաքանչյուր բաղադրիչ իրականացնում է նաև `Copy` (օրինակ ՝ `()`, `(i32, bool)`)
/// * Փակման տեսակները, եթե դրանք շրջակա միջավայրից որևէ արժեք չեն գրավում, կամ եթե բոլոր այդպիսի գրավված արժեքներն իրենք են իրականացնում `Copy`:
///   Նկատի ունեցեք, որ ընդհանուր տեղեկանքի կողմից գրավված փոփոխականները միշտ իրականացնում են `Copy` (նույնիսկ եթե հղումը չի անում), մինչդեռ փոփոխական հղումով գրավված փոփոխականները երբեք չեն իրականացնում `Copy`:
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Սա թույլ է տալիս պատճենել մի տեսակ, որը չի իրականացնում `Copy` ՝ կյանքի չբավարարված սահմանների պատճառով (պատճենել `A<'_>`, երբ միայն `A<'static>: Copy` և `A<'_>: Clone`):
// Այս հատկանիշն այստեղ առայժմ ունենք միայն այն պատճառով, որ `Copy`-ում առկա են մի քանի մասնագիտացումներ, որոնք արդեն գոյություն ունեն ստանդարտ գրադարանում, և այս պահի դրությամբ ապահով կերպով վարվելակերպ չկա:
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Ստացեք trait `Copy`-ի ազդակ առաջացնող մակրո:
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Տեսակներ, որոնց համար անվտանգ է հղումները կիսել թելերի միջև:
///
/// Այս trait-ն ավտոմատ կերպով իրականացվում է, երբ կազմողը որոշում է դրա նպատակահարմարությունը:
///
/// Definitionշգրիտ սահմանումն է. `T` տիպը [`Sync`] է, եթե և միայն այն դեպքում, եթե `&T` [`Send`] է:
/// Այլ կերպ ասած, եթե `&T` հղումները շղթաների միջև անցնելու ժամանակ չկա [undefined behavior][ub] (ներառյալ տվյալների ցեղերը):
///
/// Ինչպես կարելի էր ակնկալել, [`u8`]-ի և [`f64`]-ի նման պարզունակ տիպերը բոլորը [`Sync`] են, և նույնն են դրանք պարունակող պարզ ագրեգատային տեսակները, ինչպիսիք են փնջերը, ձողերը և թվերը:
/// [`Sync`] հիմնական տիպերի ավելի շատ օրինակներ ներառում են X004 տիպի "immutable" տիպեր և պարզ ժառանգական փոփոխականություն ունեցողներ, ինչպիսիք են [`Box<T>`][box], [`Vec<T>`][vec] և հավաքածուի այլ տեսակներ:
///
/// (Ընդհանուր պարամետրերը պետք է լինեն [`Sync`], որպեսզի դրանց կոնտեյները լինի «« Համաժամացում »):)
///
/// Սահմանման մի փոքր զարմանալի արդյունք է այն, որ `&mut T`-ը `Sync` է (եթե `T`-ը `Sync` է), չնայած թվում է, որ դա կարող է ապահովել չհամաժամացված մուտացիա:
/// Հնարքն այն է, որ ընդհանուր հղման (այսինքն ՝ `& &mut T`) հիմքում ընկած փոփոխական տեղեկանքը դառնում է միայն ընթերցանության, կարծես `& &T` լինի:
/// Ուստի տվյալների մրցավազքի ռիսկ չկա:
///
/// `Sync` չեն այն տիպերը, որոնք ունեն "interior mutability" ոչ թելերով անվտանգ ձևով, ինչպիսիք են [`Cell`][cell] և [`RefCell`][refcell]:
/// Այս տեսակները թույլ են տալիս փոխել դրանց բովանդակությունը նույնիսկ անփոփոխ, ընդհանուր տեղեկանքի միջոցով:
/// Օրինակ, `set`-ի `set` մեթոդը տանում է `&self`, ուստի այն պահանջում է միայն [`&Cell<T>`][cell] ընդհանուր հղում:
/// Մեթոդը չի կատարում համաժամացում, ուստի [`Cell`][cell]-ը չի կարող լինել `Sync`:
///
/// Ոչ «Sync» տիպի մեկ այլ օրինակ է [`Rc`][rc] տեղեկանք հաշվիչ ցուցիչը:
/// Հաշվի առնելով ցանկացած [`&Rc<T>`][rc] հղում, դուք կարող եք կլոնավորել նոր [`Rc<T>`][rc] ՝ փոփոխելով հղումների քանակը ոչ ատոմային եղանակով:
///
/// Այն դեպքերի համար, երբ անհրաժեշտ է թելերով անվտանգ ներքին փոփոխականություն, Rust-ն ապահովում է [atomic data types], ինչպես նաև բացահայտ արգելափակում [`sync::Mutex`][mutex]-ի և [`sync::RwLock`][rwlock]-ի միջոցով:
/// Այս տեսակները ապահովում են, որ ցանկացած մուտացիա չի կարող տվյալների մրցավազք առաջացնել, հետևաբար տեսակները `Sync` են:
/// Նմանապես, [`sync::Arc`][arc]-ն ապահովում է [`Rc`][rc]-ի թելերով անալոգը:
///
/// Ներքին փոփոխականությամբ ցանկացած տիպեր պետք է նաև օգտագործեն X001 փաթաթան value(s)-ի շուրջ, որը կարող է մուտացիայի ենթարկվել ընդհանուր տեղեկանքի միջոցով:
/// Դա չկատարելը [undefined behavior][ub] է:
/// Օրինակ, [«transmute»][transmute]-`&T`-ից `&mut T` անվավեր է:
///
/// Տե՛ս [the Nomicon][nomicon-send-and-sync] ՝ `Sync`- ի վերաբերյալ ավելի մանրամասն տեղեկություններ ստանալու համար:
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): միանգամից աջակցություն `rustc_on_unimplemented` բետա տարածքներում նշումներ ավելացնելու համար, և այն երկարաձգվել է ՝ ստուգելու համար, արդյոք փակումը որևէ տեղ է պահանջների շղթայում, ընդլայնել այն որպես այդպիսին (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Eroրոյական տիպն օգտագործվում է այն բաները նշելու համար, որոնք "act like" ունեն `T`:
///
/// `PhantomData<T>` դաշտ ավելացնելը ձեր տեսակին ասում է կազմողին, որ ձեր տեսակը գործում է այնպես, կարծես `T` տիպի արժեք է պահում, չնայած իրականում այն իրականում չէ:
/// Այս տեղեկատվությունն օգտագործվում է անվտանգության որոշակի հատկություններ հաշվարկելիս:
///
/// `PhantomData<T>`-ի օգտագործման ավելի խորը բացատրության համար խնդրում ենք տե՛ս [the Nomicon](../../nomicon/phantom-data.html):
///
/// # Մի գարշելի նոտա
///
/// Չնայած երկուսն էլ վախեցնող անուններ ունեն, `PhantomData` և «ուրվական տիպերը» կապված են, բայց նույնական չեն: Ֆանտոմային տիպի պարամետրը պարզապես տիպի պարամետր է, որը երբեք չի օգտագործվում:
/// Rust-ում սա հաճախ առաջացնում է կազմողի բողոք, և լուծումը "dummy" օգտագործումն ավելացնել `PhantomData`-ի միջոցով:
///
/// # Examples
///
/// ## Չօգտագործված կյանքի պարամետրեր
///
/// `PhantomData`-ի օգտագործման գուցե ամենատարածված գործը մի կառուցվածք է, որն ունի չօգտագործված կյանքի պարամետր, որպես կանոն, որպես որոշ անապահով ծածկագրի մաս:
/// Օրինակ, ահա մի կառուցվածք `Slice`, որն ունի `*const T` տիպի երկու ցուցիչ, ենթադրաբար, ինչ-որ տեղ զանգված է ցույց տալիս.
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Նպատակն այն է, որ հիմքում ընկած տվյալները վավեր են միայն `'a` կյանքի ընթացքում, ուստի `Slice`-ը չպետք է գերազանցի `'a`-ը:
/// Այնուամենայնիվ, այս մտադրությունը չի արտահայտվում օրենսգրքում, քանի որ գոյություն չունի `'a` կյանքի ընթացքում, ուստի անհասկանալի է, թե որ տվյալների համար է այն կիրառվում:
/// Մենք կարող ենք դա ուղղել ՝ ասելով, որ կազմողին գործելու է *այնպես, կարծես*`Slice` կառուցվածքը պարունակում է `&'a T` հղում.
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Սա նաև իր հերթին պահանջում է `T: 'a` ծանոթագրություն, նշելով, որ `T`-ի ցանկացած հղում ուժի մեջ է ողջ `'a` կյանքի ընթացքում:
///
/// `Slice`-ի նախաստորագրման ժամանակ դուք պարզապես տալիս եք `PhantomData` արժեք `phantom` դաշտի համար.
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Չօգտագործված տիպի պարամետրեր
///
/// Երբեմն պատահում է, որ դուք ունեք չօգտագործված տիպի պարամետրեր, որոնք ցույց են տալիս, թե տվյալների որ տեսակն է կառուցվածքը "tied", չնայած որ այդ տվյալներն իրականում չեն գտնվում կառուցվածքի մեջ:
/// Ահա մի օրինակ, երբ դա առաջանում է [FFI]-ի հետ:
/// Արտասահմանյան ինտերֆեյսը օգտագործում է `*mut ()` տիպի բռնակներ ՝ տարբեր տեսակի Rust արժեքներին հղում կատարելու համար:
/// Մենք հետևում ենք Rust տիպին `օգտագործելով ֆանտոմային տիպի պարամետր կառուցվածքի `ExternalResource`-ի վրա, որը փաթաթում է բռնակը:
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Սեփականության իրավունքը և անկման ստուգումը
///
/// `PhantomData<T>` տիպի դաշտ ավելացնելը ցույց է տալիս, որ ձեր տիպը `T` տիպի տվյալների տեր է: Սա իր հերթին ենթադրում է, որ երբ ձեր տիպը իջնում է, այն կարող է թողնել `T` տիպի մեկ կամ մի քանի օրինակ:
/// Սա ազդում է Rust կազմողի [drop check] վերլուծության վրա:
///
/// Եթե ձեր կառուցվածքն իրականում *չի տիրապետում*`T` տիպի տվյալների, ապա ավելի լավ է օգտագործել հղումային տիպ ՝ `PhantomData<&'a T>` (ideally) կամ `PhantomData<*const T>` (եթե ոչ մի կյանքի տևողություն չի գործում), որպեսզի չնշվի սեփականության իրավունքը:
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Կազմող-ներքին trait-ն օգտագործվում է թվերի խտրականության տեսակ տեսակը նշելու համար:
///
/// Այս trait-ն ավտոմատ կերպով իրականացվում է յուրաքանչյուր տեսակի համար և [`mem::Discriminant`]-ին չի տալիս որևէ երաշխիք:
/// `DiscriminantKind::Discriminant`-ի և `mem::Discriminant`-ի միջև փոխակերպելը **անորոշ վարք է**:
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Խտրականության տեսակը, որը պետք է բավարարի `mem::Discriminant`-ի կողմից պահանջվող trait bounds-ին:
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Կոմպիլյատոր-ներքին trait-ն օգտագործվում է որոշելու համար, թե արդյոք տիպը ներսում պարունակում է `UnsafeCell`, բայց ոչ անուղղակիության միջոցով:
///
/// Սա ազդում է, օրինակ, արդյոք այդ տեսակի `static`-ը տեղադրվում է միայն կարդալու համար ստատիկ հիշողության մեջ կամ գրելի ստատիկ հիշողության մեջ:
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Տեսակները, որոնք կարող են անվտանգ տեղափոխվել կապվելուց հետո:
///
/// Rust-ն ինքնին անշարժ տիպի հասկացություն չունի և շարժումները (օրինակ ՝ հանձնարարականի միջոցով կամ [`mem::replace`]) համարում է միշտ անվտանգ:
///
/// Փոխարենը օգտագործվում է [`Pin`][Pin] տիպը ՝ տիպային համակարգում տեղաշարժերը կանխելու համար: `P<T>` փաթաթվածով փաթաթված `P<T>` ցուցիչները հնարավոր չէ տեղափոխել այնտեղից:
/// Տեսեք [`pin` module] փաստաթղթերը ՝ կապում ամրացնելու մասին լրացուցիչ տեղեկություններ ստանալու համար:
///
/// `T`-ի համար `Unpin` trait-ի իրականացումը վերացնում է տիպը կապելու սահմանափակումները, ինչը հետագայում թույլ է տալիս `T`-ը դուրս բերել [`Pin<P<T>>`][Pin]-ից [`mem::replace`]-ի նման գործառույթներով:
///
///
/// `Unpin` ընդհանրապես հետևանք չունի ոչ կապակցված տվյալների համար:
/// Մասնավորապես, [`mem::replace`]-ը ուրախությամբ տեղափոխում է `!Unpin` տվյալներ (այն աշխատում է ցանկացած `&mut T`-ի համար, ոչ միայն `T: Unpin`-ի դեպքում):
/// Այնուամենայնիվ, դուք չեք կարող օգտագործել [`mem::replace`] [`Pin<P<T>>`][Pin]-ի մեջ փաթաթված տվյալների վրա, քանի որ չեք կարող ստանալ դրա համար անհրաժեշտ `&mut T`-ը, և *դա* է, որ ստիպում է այս համակարգը աշխատել:
///
/// Այսպիսով, օրինակ, դա կարելի է անել միայն `Unpin`-ն իրականացնող տիպերի վրա.
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` զանգահարելու համար մեզ փոխադարձ տեղեկանք է պետք:
/// // Մենք կարող ենք նման հղում ստանալ (implicitly)-ով `վկայակոչելով `Pin::deref_mut`, բայց դա հնարավոր է միայն այն պատճառով, որ `String`-ն իրականացնում է `Unpin`:
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Այս trait-ն ավտոմատ կերպով իրականացվում է գրեթե յուրաքանչյուր տեսակի համար:
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Մարկերների տեսակ, որը չի իրականացնում `Unpin`:
///
/// Եթե տիպը պարունակում է `PhantomPinned`, այն լռելյայն չի իրականացնի `Unpin`:
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy`-ի իրականացումը պարզունակ տիպերի համար:
///
/// Իրականացումները, որոնք հնարավոր չէ նկարագրել Rust-ում, իրականացվում են `traits::SelectionContext::copy_clone_conditions()`-ում `rustc_trait_selection`-ում:
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Համօգտագործվող հղումները կարող են պատճենվել, բայց փոփոխվող հղումները *չեն կարող*:
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}