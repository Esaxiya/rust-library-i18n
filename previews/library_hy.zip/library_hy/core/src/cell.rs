//! Կիսվող փոխարկելի տարաներ:
//!
//! Rust հիշողության անվտանգությունը հիմնված է այս կանոնի վրա. Հաշվի առնելով `T` օբյեկտ, հնարավոր է ունենալ միայն հետևյալներից որևէ մեկը.
//!
//! - Ունենալով օբյեկտի (`&T`) մի քանի անփոփոխ հղումներ (հայտնի է նաև որպես **aliasing**):
//! - Ունենալով օբյեկտի նկատմամբ մեկ փոփոխվող հղում (`&mut T`)(հայտնի է նաև որպես **փոփոխություն**):
//!
//! Սա կիրառվում է Rust կազմողի կողմից: Այնուամենայնիվ, կան իրավիճակներ, երբ այս կանոնը բավականաչափ ճկուն չէ:Երբեմն պահանջվում է ունենալ բազմաթիվ հղումներ օբյեկտի վերաբերյալ և այնուամենայնիվ մուտացիայի ենթարկել:
//!
//! Կիսվող փոփոխվող տարաները գոյություն ունեն թույլատրելի փոփոխելիությունը վերահսկվող եղանակով, նույնիսկ այլընտրանքի առկայության դեպքում: Եվ [`Cell<T>`]-ը, և [`RefCell<T>`]-ը թույլ են տալիս դա անել մեկ թելերով:
//! Այնուամենայնիվ, ոչ `Cell<T>`-ը, ոչ `RefCell<T>`-ը ապահով չեն թելերով (նրանք չեն իրականացնում [`Sync`]):
//! Եթե Ձեզ անհրաժեշտ է կատարել բազմակի թելերի միջև անվանափոխություն և մուտացիա, հնարավոր է օգտագործել [`Mutex<T>`], [`RwLock<T>`] կամ [`atomic`] տեսակներ:
//!
//! `Cell<T>` և `RefCell<T>` տիպերի արժեքները կարող են փոփոխվել ընդհանուր հղումների միջոցով (այսինքն
//! ընդհանուր `&T` տիպը), մինչդեռ Rust տիպի մեծամասնությունը կարող է մուտացիայի ենթարկվել միայն եզակի (`&mut T`) հղումների միջոցով:
//! Մենք ասում ենք, որ `Cell<T>` և `RefCell<T>` ապահովում են «ներքին փոփոխականություն», ի տարբերություն տիպիկ Rust տիպերի, որոնք ցուցադրում են «ժառանգական փոփոխականություն»:
//!
//! Բջիջների տեսակները ունեն երկու համ. `Cell<T>` և `RefCell<T>`: `Cell<T>`-ն իրականացնում է ներքին փոփոխականություն `տեղափոխելով արժեքներ `Cell<T>`-ից և դրանցից դուրս:
//! Հղումները արժեքների փոխարեն օգտագործելու համար պետք է օգտագործել `RefCell<T>` տիպը ՝ մուտացիայի ենթարկվելուց առաջ ձեռք բերելով գրելու կողպեք: `Cell<T>`-ը տրամադրում է ընթացիկ ներքին արժեքը հետ բերելու և փոխելու մեթոդներ.
//!
//!  - [`Copy`] իրականացրած տիպերի համար [`get`](Cell::get) մեթոդը հետ է վերցնում ընթացիկ ներքին արժեքը:
//!  - [`Default`] իրականացրած տիպերի համար [`take`](Cell::take) մեթոդը փոխարինում է ընթացիկ ներքին արժեքը [`Default::default()`]-ով և վերադարձնում փոխարինված արժեքը:
//!  - Բոլոր տեսակների համար [`replace`](Cell::replace) մեթոդը փոխարինում է ընթացիկ ներքին արժեքին և վերադարձնում փոխարինված արժեքը, իսկ [`into_inner`](Cell::into_inner) մեթոդը սպառում է `Cell<T>`-ը և վերադարձնում ներքին արժեքը:
//!  Բացի այդ, [`set`](Cell::set) մեթոդը փոխարինում է ներքին արժեքին ՝ գցելով փոխարինված արժեքը:
//!
//! `RefCell<T>` օգտագործում է Rust-ի կյանքի տևողությունը «դինամիկ փոխառություն» իրականացնելու համար, գործընթաց, որի միջոցով կարելի է պահանջել ժամանակավոր, բացառիկ, փոփոխական մուտք դեպի ներքին արժեք:
//! «RefCell»-ի համար Borrows<T>«ները հետևվում են» գործառույթի ժամանակ », ի տարբերություն Rust-ի բնածին հղումների տիպերի, որոնք ամբողջությամբ հետևվում են ստատիկ կերպով, կազմման ժամանակ:
//! Քանի որ `RefCell<T>` փոխառությունները դինամիկ են, հնարավոր է փորձել վերցնել մի արժեք, որն արդեն փոխադարձաբար փոխառված է.երբ դա տեղի է ունենում, այն հանգեցնում է panic թեմայի:
//!
//! # Երբ ընտրել ներքին փոփոխականությունը
//!
//! Ավելի տարածված ժառանգական փոփոխականությունը, երբ մեկը պետք է ունենա եզակի մուտք մուտուտ արժեքը, լեզվի հիմնական տարրերից մեկն է, որը հնարավորություն է տալիս Rust-ին խիստ տրամաբանել ցուցիչի aliasing-ի մասին ՝ ստատիկորեն կանխելով վթարի սխալները:
//! Այդ պատճառով գերադասելի է ժառանգական փոփոխականությունը, իսկ ներքին փոփոխականությունը ՝ վերջին միջոց:
//! Քանի որ բջիջների տեսակները թույլ են տալիս մուտացիա, եթե այն այլևս թույլ չտա, կան դեպքեր, երբ ներքին փոփոխականությունը կարող է տեղին լինել, կամ նույնիսկ *պետք է օգտագործել*, օրինակ
//!
//! * Ներկայացնում ենք անփոփոխ ինչ-որ բանի 'inside' փոփոխականությունը
//! * Տրամաբանորեն անփոփոխ մեթոդների իրականացման մանրամասները:
//! * [`Clone`]-ի փոփոխությունները
//!
//! ## Ներկայացնում ենք անփոփոխ ինչ-որ բանի 'inside' փոփոխականությունը
//!
//! Բազմաթիվ ընդհանուր խելացի ցուցիչների տեսակներ, ներառյալ [`Rc<T>`] և [`Arc<T>`], ապահովում են տարաներ, որոնք կարող են կլոնավորվել և բաժանվել բազմաթիվ կողմերի միջև:
//! Քանի որ պարունակվող արժեքները կարող են բազմապատկվել, դրանք կարող են փոխառվել միայն `&`-ով, այլ ոչ թե `&mut`-ով:
//! Առանց բջիջների անհնար կլիներ ընդհանրապես փոխել տվյալները այս խելացի ցուցիչների ներսում:
//!
//! Շատ տարածված է այն դեպքում, երբ `RefCell<T>` տեղադրեք ցուցիչի համօգտագործվող տեսակների մեջ `փոփոխականությունը վերականգնելու համար.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Ստեղծեք նոր բլոկ `դինամիկ փոխառության շրջանակը սահմանափակելու համար
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Նկատի ունեցեք, որ եթե մենք թույլ չտայինք, որ քեշի նախորդ պարտքը դուրս գա տարածքից, ապա հետագա փոխառությունը կհանգեցնի panic դինամիկ թելի:
//!     //
//!     // Սա `RefCell`-ի օգտագործման հիմնական վտանգն է:
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Նշենք, որ այս օրինակում օգտագործվում է `Rc<T>`, այլ ոչ `Arc<T>`: `RefCell<T>Դրանք նախատեսված են մեկ թելերով սցենարների համար:Հաշվի առեք [`RwLock<T>`] կամ [`Mutex<T>`] օգտագործումը, եթե ձեզ անհրաժեշտ է ընդհանուր փոփոխականություն բազմաշերտ իրավիճակում:
//!
//! ## Տրամաբանորեն անփոփոխ մեթոդների իրականացման մանրամասները
//!
//! Asամանակ առ ժամանակ կարող է ցանկալի լինել, որ API-ում չբացահայտվի, որ "under the hood" տեղի է ունենում մուտացիա:
//! Դա կարող է լինել այն պատճառով, որ տրամաբանորեն գործողությունն անփոփոխ է, բայց, օրինակ, caching-ը ստիպում է իրականացմանը կատարել մուտացիա: կամ այն պատճառով, որ դուք պետք է մուտացիա օգտագործեք trait մեթոդն իրականացնելու համար, որն ի սկզբանե սահմանված էր `&self`-ը վերցնելու համար:
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Թանկ հաշվարկն այստեղ է
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone`-ի փոփոխությունները
//!
//! Սա պարզապես նախորդի հատուկ, բայց սովորական դեպքն է. Անփոփոխ թվացող գործողությունների համար փոփոխականության թաքցնելը:
//! Ակնկալվում է, որ [`clone`](Clone::clone) մեթոդը չի փոխի աղբյուրի արժեքը և հայտարարվում է, որ վերցնում է `&self`, այլ ոչ թե `&mut self`:
//! Հետեւաբար, ցանկացած մուտացիա, որը տեղի է ունենում `clone` մեթոդով, պետք է օգտագործի բջիջների տեսակները:
//! Օրինակ, [`Rc<T>`]-ը պահպանում է իր հղումների քանակը `Cell<T>`-ի սահմաններում:
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Փոփոխական հիշողության տեղադրություն:
///
/// # Examples
///
/// Այս օրինակում կարող եք տեսնել, որ `Cell<T>`-ը մուտացիայի հնարավորություն է տալիս անփոփոխ կառուցվածքի ներսում:
/// Այլ կերպ ասած, այն հնարավորություն է տալիս "interior mutability":
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ՍԽԱԼ. `my_struct`-ը անփոփոխ է
/// // my_struct.regular_field =նոր_ արժեք;
///
/// // ԱՇԽԱՏԱՆՔՆԵՐ. Չնայած `my_struct`-ն անփոփոխ է, բայց `special_field`-ը `Cell` է,
/// // որը միշտ կարող է մուտացիայի ենթարկվել
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Տեսեք [module-level documentation](self)-ը ավելին:
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Ստեղծում է `Cell<T>`, T-ի համար `Default` արժեքով:
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Ստեղծում է տրված արժեքը պարունակող նոր `Cell`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Սահմանում է պարունակվող արժեքը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Փոխանակում է երկու բջիջների արժեքները:
    /// `std::mem::swap`-ի հետ տարբերությունն այն է, որ այս գործառույթը չի պահանջում `&mut` հղում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա կարող է ռիսկային լինել, եթե կանչվում է առանձին թելերից, բայց `Cell`
        // `!Sync` է, այնպես որ դա տեղի չի ունենա:
        // Սա նաև անվավեր չի դարձնի որևէ ցուցիչ, քանի որ `Cell`-ը համոզվում է, որ այս «բջիջներից» ոչ մեկին այլևս ոչինչ չի նշվի:
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Փոխարինում է պարունակվող արժեքը `val`-ով և վերադարձնում հին պարունակվող արժեքը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա կարող է առաջացնել տվյալների մրցավազք, եթե կանչվում է առանձին թեմայից,
        // բայց `Cell`-ը `!Sync` է, այնպես որ դա տեղի չի ունենա:
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Արգելքը փաթաթում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Վերադարձնում է պարունակվող արժեքի պատճենը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա կարող է առաջացնել տվյալների մրցավազք, եթե կանչվում է առանձին թեմայից,
        // բայց `Cell`-ը `!Sync` է, այնպես որ դա տեղի չի ունենա:
        unsafe { *self.value.get() }
    }

    /// Թարմացնում է պարունակվող արժեքը ՝ օգտագործելով գործառույթ և վերադարձնելով նոր արժեքը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Հում ցուցիչը վերադարձնում է այս բջիջի հիմքում ընկած տվյալները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Վերադարձնում է հիմքում ընկած տվյալների փոփոխական հղումը:
    ///
    /// Այս զանգը փոխառու է `Cell` փոխադարձաբար (կազմման ժամանակ), ինչը երաշխավորում է, որ մենք ունենք միակ տեղեկանքը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Վերադառնում է `&Cell<T>`-ը `&mut T`-ից
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `&mut`-ն ապահովում է եզակի մատչում:
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Վերցնում է բջիջի արժեքը ՝ թողնելով `Default::default()`-ը իր տեղում:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Վերադառնում է `&[Cell<T>]`-ը `&Cell<[T]>`-ից
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `Cell<T>`-ը ունի նույն հիշողության դասավորությունը, ինչ `T`-ը:
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Փոփոխվող հիշողության տեղ ՝ դինամիկորեն ստուգված փոխառության կանոններով
///
/// Տեսեք [module-level documentation](self)-ը ավելին:
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`]-ի կողմից վերադարձված սխալ:
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`]-ի կողմից վերադարձված սխալ:
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Դրական արժեքները ներկայացնում են `Ref` ակտիվի թիվը: Բացասական արժեքները ներկայացնում են `RefMut` ակտիվի թիվը:
// Բազմաթիվ `RefMut-ը կարող է ակտիվ լինել միաժամանակ, եթե դրանք վերաբերում են `RefCell`-ի հստակ, չհամապատասխանող բաղադրիչներին (օրինակ` կտորի տարբեր տիրույթներ):
//
// `Ref` և `RefMut`-ը երկուսն էլ չափի երկու բառ են, և այդպիսով, հավանաբար, գոյություն չի ունենա `Ref`-ը կամ`RefMut-ը `usize` տիրույթի կեսը հեղեղելու համար:
// Այսպիսով, `BorrowFlag`-ը, հավանաբար, երբեք չի հորդանա կամ չի հորդելու:
// Այնուամենայնիվ, դա երաշխիք չէ, քանի որ պաթոլոգիական ծրագիրը կարող է բազմիցս ստեղծել, այնուհետև mem::forget `Ref` կամ`RefMut`:
// Այսպիսով, բոլոր ծածկագրերը պետք է հստակորեն ստուգեն արտահոսքի և արտահոսքի առկայությունը, որպեսզի խուսափեն անապահովությունից, կամ գոնե ճիշտ վարվեն այն դեպքում, երբ տեղի է ունենում վարարում կամ արտահոսք (օրինակ, տես BorrowRef::new):
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Ստեղծում է նոր `RefCell` պարունակող `value`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Սպառում է `RefCell`-ը ՝ վերադարձնելով փաթաթված արժեքը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Քանի որ այս գործառույթն ըստ արժեքի վերցնում է `self` (`RefCell`), կազմողը ստատիկորեն ստուգում է, որ այն ներկայումս փոխառված չէ:
        //
        self.value.into_inner()
    }

    /// Փաթաթված արժեքը փոխարինում է նորով ՝ վերադարձնելով հին արժեքը ՝ առանց որևէ մեկի ապասառավարման:
    ///
    ///
    /// Այս ֆունկցիան համապատասխանում է [`std::mem::replace`](../mem/fn.replace.html)-ին:
    ///
    /// # Panics
    ///
    /// Panics, եթե արժեքը ներկայումս վերցված է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Փոխարինում է փաթաթված արժեքը `f`-ից հաշվարկված նորով ՝ վերադարձնելով հին արժեքը, առանց որևէ մեկի ապասառեցման:
    ///
    ///
    /// # Panics
    ///
    /// Panics, եթե արժեքը ներկայումս վերցված է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Փոխանակում է `self`-ի փաթաթված արժեքը `other` փաթաթված արժեքով, առանց որևէ մեկի ապակենտրոնացման:
    ///
    ///
    /// Այս ֆունկցիան համապատասխանում է [`std::mem::swap`](../mem/fn.swap.html)-ին:
    ///
    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Անխուսափելիորեն վերցնում է փաթաթված արժեքը:
    ///
    /// Փոխառությունը տևում է մինչ վերադարձված `Ref`-ը դուրս կգա տարածքից:
    /// Միևնույն ժամանակ կարող են վերցվել բազմաթիվ անփոփոխ փոխառություններ:
    ///
    /// # Panics
    ///
    /// Panics եթե արժեքը ներկայումս փոխադարձաբար վերցված է:
    /// Խուճապի չմատնված տարբերակի համար օգտագործեք [`try_borrow`](#method.try_borrow):
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic-ի օրինակ.
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Անխուսափելիորեն վերցնում է փաթաթված արժեքը `վերադարձնելով սխալ, եթե արժեքը ներկայումս փոխադարձաբար վերցված է:
    ///
    ///
    /// Փոխառությունը տևում է մինչ վերադարձված `Ref`-ը դուրս կգա տարածքից:
    /// Միևնույն ժամանակ կարող են վերցվել բազմաթիվ անփոփոխ փոխառություններ:
    ///
    /// Սա [`borrow`](#method.borrow)-ի ոչ խուճապային տարբերակն է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `BorrowRef`-ն ապահովում է միայն անփոփոխ մուտքի հասանելիությունը
            // փոխառության ժամանակ եղած արժեքին:
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Փոխադարձաբար վերցնում է փաթաթված արժեքը:
    ///
    /// Փոխառությունը տևում է մինչև վերադարձված `RefMut`-ը կամ դրանից բխող ամբողջ «RefMut»-ը դուրս գա տարածքից:
    ///
    /// Արժեքը չի կարելի փոխառել, մինչ այս փոխառությունն ակտիվ է:
    ///
    /// # Panics
    ///
    /// Panics, եթե արժեքը ներկայումս վերցված է:
    /// Խուճապի չմատնված տարբերակի համար օգտագործեք [`try_borrow_mut`](#method.try_borrow_mut):
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic-ի օրինակ.
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Փոխադարձաբար վերցնում է փաթաթված արժեքը `վերադարձնելով սխալ, եթե արժեքը ներկայումս վերցված է:
    ///
    ///
    /// Փոխառությունը տևում է մինչև վերադարձված `RefMut`-ը կամ դրանից բխող ամբողջ «RefMut»-ը դուրս գա տարածքից:
    /// Արժեքը չի կարելի փոխառել, մինչ այս փոխառությունն ակտիվ է:
    ///
    /// Սա [`borrow_mut`](#method.borrow_mut)-ի ոչ խուճապային տարբերակն է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `BorrowRef`-ը երաշխավորում է եզակի մատչում:
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Հում ցուցիչը վերադարձնում է այս բջիջի հիմքում ընկած տվյալները:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Վերադարձնում է հիմքում ընկած տվյալների փոփոխական հղումը:
    ///
    /// Այս զանգը փոխառությամբ վերցնում է `RefCell` (կազմման ժամանակ), այնպես որ դինամիկ ստուգումների կարիք չկա:
    ///
    /// Այնուամենայնիվ, զգույշ եղեք. Այս մեթոդն ակնկալում է, որ `self`-ը փոփոխական կլինի, ինչը սովորաբար չի պատահում `RefCell`-ի օգտագործման ժամանակ:
    ///
    /// Փոխարենը նայեք [`borrow_mut`] մեթոդին, եթե `self` փոփոխական չէ:
    ///
    /// Նաև խնդրում ենք տեղյակ լինել, որ այս մեթոդը նախատեսված է միայն հատուկ հանգամանքների համար և սովորաբար այն չէ, ինչ ուզում եք:
    /// Կասկածի դեպքում փոխարենը օգտագործեք [`borrow_mut`]:
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Վերացնել արտահոսող պահակների ազդեցությունը `RefCell`-ի փոխառության վիճակի վրա:
    ///
    /// Այս զանգը նման է [`get_mut`]-ին, բայց ավելի մասնագիտացված է:
    /// Այն փոխառու է `RefCell`-ին `փոխառություններ գոյություն չունեցող ապահովելու համար, այնուհետև զրոյացնում է ընդհանուր փոխառությունները հետևող պետությունը:
    /// Սա կարևոր է, եթե `Ref` կամ `RefMut` փոխառությունների արտահոսք է եղել:
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Անխուսափելիորեն վերցնում է փաթաթված արժեքը `վերադարձնելով սխալ, եթե արժեքը ներկայումս փոխադարձաբար վերցված է:
    ///
    /// # Safety
    ///
    /// Ի տարբերություն `RefCell::borrow`-ի, այս մեթոդը անվտանգ է, քանի որ այն չի վերադարձնում `Ref`-ը, այդպիսով թողնելով փոխառության դրոշը անձեռնմխելի:
    /// `RefCell`-ի փոխադարձ փոխառությունը, մինչ այս մեթոդով վերադարձված տեղեկանքը կենդանի է, չսահմանված վարք է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք ստուգում ենք, որ հիմա ոչ ոք ակտիվորեն չի գրում, բայց դա այդպես է
            // զանգահարողի պատասխանատվությունը `ապահովել, որ ոչ ոք չգրի, մինչև վերադարձված տեղեկանքն այլևս օգտագործվի:
            // Բացի այդ, `self.value.get()`-ը վերաբերում է `self`-ին պատկանող արժեքին և, այդպիսով, երաշխավորված է, որ այն վավեր կլինի `self`-ի ողջ կյանքի ընթացքում:
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Վերցնում է փաթաթված արժեքը ՝ `Default::default()`-ը թողնելով իր տեղում:
    ///
    /// # Panics
    ///
    /// Panics, եթե արժեքը ներկայումս վերցված է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics եթե արժեքը ներկայումս փոխադարձաբար վերցված է:
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Ստեղծում է `RefCell<T>`, T-ի համար `Default` արժեքով:
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics եթե `RefCell`-ի ցանկացած արժեքը ներկայումս փոխառված է:
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Ավելացող փոխառությունն այս դեպքերում կարող է հանգեցնել չընթերցման արժեքի (<=0):
            // 1. Դա <0 էր, այսինքն ՝ կան գրառման փոխառություններ, այնպես որ մենք չենք կարող թույլ տալ ընթերցված փոխառություն ՝ Rust-ի հղման անվանման կանոնների պատճառով
            // 2.
            // Դա isize::MAX էր (ընթերցանության առավելագույն գումարը) և լցվեց isize::MIN (գրառման առավելագույն քանակը), այնպես որ մենք չենք կարող թույլատրել լրացուցիչ ընթերցման փոխառություն, քանի որ isize-ը չի կարող ներկայացնել այդքան շատ ընթերցված փոխառություններ (դա կարող է պատահել միայն եթե դուք mem::forget-ով ավելին, քան մի փոքր հաստատուն քանակի `Ref`, ինչը լավ պրակտիկա չէ)
            //
            //
            //
            //
            None
        } else {
            // Ավելացող փոխառությունն այս դեպքերում կարող է հանգեցնել ընթերցման արժեքի (> 0):
            // 1. Դա=0 էր, այսինքն ՝ փոխառված չէր, և մենք վերցնում ենք առաջին ընթերցված փոխառությունը
            // 2. Դա> 0 և <isize::MAX էր, այսինքն
            // կար կարդացած փոխառություններ, իսկ isize-ն այնքան մեծ է, որ ներկայացնի մեկ այլ ընթերցված փոխառություն ունենալը
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Քանի որ այս հղումը գոյություն ունի, մենք գիտենք, որ փոխառության դրոշը ընթերցանության փոխառություն է:
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Կանխել վարկերի հաշվիչի հեղեղումը գրավոր փոխառության:
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` տուփի մեջ փաթաթում է փոխառված հղումը մի արժեքի:
/// Փաթաթի տեսակ `RefCell<T>`-ից անփոփոխ փոխառված արժեքի համար:
///
/// Տեսեք [module-level documentation](self)-ը ավելին:
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Պատճենում է `Ref`:
    ///
    /// `RefCell`-ն արդեն անփոփոխ փոխառություն է ստացել, ուստի դա չի կարող ձախողվել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `Ref::clone(...)`:
    /// `Clone` ներդրումը կամ մեթոդը խոչընդոտում է `r.borrow().clone()`-ի տարածված օգտագործմանը `RefCell`-ի պարունակությունը կլոնավորելու համար:
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Փոխառու տվյալների մի բաղադրիչի համար կազմում է նոր `Ref`:
    ///
    /// `RefCell`-ն արդեն անփոփոխ փոխառություն է ստացել, ուստի դա չի կարող ձախողվել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `Ref::map(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Փոխառու տվյալների ընտրովի բաղադրիչի համար կազմում է նոր `Ref`:
    /// Բնօրինակը պահվում է որպես `Err(..)`, եթե փակումը վերադարձնում է `None`:
    ///
    /// `RefCell`-ն արդեն անփոփոխ փոխառություն է ստացել, ուստի դա չի կարող ձախողվել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `Ref::filter_map(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// `Ref`-ը բաժանում է բազմակի `Ref-ի` փոխառված տվյալների տարբեր բաղադրիչների համար:
    ///
    /// `RefCell`-ն արդեն անփոփոխ փոխառություն է ստացել, ուստի դա չի կարող ձախողվել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `Ref::map_split(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Փոխարկել հիմքում ընկած տվյալների հղումը:
    ///
    /// Հիմքում ընկած `RefCell`-ը այլևս չի կարող փոխադարձաբար փոխառվել և միշտ կհայտնվի արդեն անփոփոխ փոխառված:
    ///
    /// Լավ գաղափար չէ արտահոսել ավելին, քան հղումների անընդհատ քանակը:
    /// `RefCell`-ը կարող է կրկին անփոփոխ վերցվել, եթե ընդհանուր առմամբ միայն ավելի փոքր քանակությամբ արտահոսք է տեղի ունեցել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `Ref::leak(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Այս Ref-ը մոռանալով մենք ապահովում ենք, որ RefCell-ում փոխառության հաշվիչը չի կարող `'b` կյանքի ընթացքում վերադառնալ ԱՆՕԳՏԱԳՐՎԱ:
        // Հղման հետևման վիճակի վերակայումը կպահանջի եզակի հղում վերցված փոխառված RefCell-ին:
        // Հետագա փոփոխական հղումներ չեն կարող ստեղծվել բնօրինակ բջիջից:
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Կազմում է նոր `RefMut` փոխառու տվյալների մի մասի համար, օրինակ `enum տարբերակ:
    ///
    /// `RefCell`-ն արդեն փոխադարձ փոխառություն է ստացել, ուստի դա չի կարող ձախողվել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `RefMut::map(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ամրագրել պարտք-չեկը
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Փոխառու տվյալների ընտրովի բաղադրիչի համար կազմում է նոր `RefMut`:
    /// Բնօրինակը պահվում է որպես `Err(..)`, եթե փակումը վերադարձնում է `None`:
    ///
    /// `RefCell`-ն արդեն փոխադարձ փոխառություն է ստացել, ուստի դա չի կարող ձախողվել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `RefMut::filter_map(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ամրագրել պարտք-չեկը
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Գործառույթը տևողության ընթացքում պահում է բացառիկ տեղեկանք
        // իր զանգի `orig`-ի միջոցով, և սլաքը միայն հղում է արվում ֆունկցիայի զանգի ներսում `երբեք թույլ չտալով բացառել բացառիկ հղումը:
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նույնն է, ինչ վերևում:
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// `RefMut`-ը բաժանում է բազմաթիվ `RefMut-ի` փոխառու տվյալների տարբեր բաղադրիչների համար:
    ///
    /// Հիմքում ընկած `RefCell`-ը փոխադարձաբար փոխառված կլինի, քանի դեռ վերադարձված երկուսն էլ `RefMut-ը դուրս չի եկել իր սահմաններից:
    ///
    /// `RefCell`-ն արդեն փոխադարձ փոխառություն է ստացել, ուստի դա չի կարող ձախողվել:
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `RefMut::map_split(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Փոխակերպվել հիմքում ընկած տվյալների փոփոխական հղման:
    ///
    /// Հիմքում դրված `RefCell`-ն այլևս չի կարող փոխառվել և միշտ կհայտնվի արդեն փոխադարձաբար փոխառված `վերադարձի հղումը դարձնելով միակ ներքին հարդարանքը:
    ///
    ///
    /// Սա կապված գործառույթ է, որն անհրաժեշտ է օգտագործել որպես `RefMut::leak(...)`:
    /// Մի մեթոդ խոչընդոտում է համանուն մեթոդներին `Deref`-ի միջոցով օգտագործվող `RefCell`-ի պարունակության վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Մոռանալով այս BorrowRefMut-ը, մենք ապահովում ենք, որ RefCell-ում փոխառության հաշվիչը չի կարող վերադառնալ ԱՆՕԳՏԱԳՐՎԱ `'b` կյանքի ընթացքում:
        // Հղման հետևման վիճակի վերակայումը կպահանջի եզակի հղում վերցված փոխառված RefCell-ին:
        // Այդ կյանքի ընթացքում սկզբնական բջիջից այլևս հղումներ չեն կարող ստեղծվել ՝ ընթացիկ փոխառությունը դարձնելով մնացած կյանքի միակ հղումը:
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Ի տարբերություն BorrowRefMut::clone-ի, նորը կոչվում է ստեղծել նախնականը
        // փոփոխական տեղեկանք, և այդ պատճառով ներկայումս չպետք է որևէ հղում լինի:
        // Այսպիսով, մինչ կլոնը ավելացնում է փոփոխվող վերահաշվարկը, այստեղ մենք բացահայտորեն թույլ ենք տալիս միայն անցնել ԱՆՕԳՏԱԳՈՐԻ to դեպի ԱՆՇԱՀԱԳՈՒՅՆ, 1:
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Կլոնավորում է `BorrowRefMut`:
    //
    // Սա վավեր է միայն այն դեպքում, երբ յուրաքանչյուր `BorrowRefMut` օգտագործվում է բուն օբյեկտի հստակ, չհամապատասխանող տիրույթի փոփոխական հղումը հետևելու համար:
    //
    // Սա Clone ենթատեքստում չէ, որպեսզի այդ ծածկագիրը դա անուղղակիորեն չկանչի:
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Կանխել վարկերի հաշվիչի թերակատարումը:
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Փաթաթի տեսակ `RefCell<T>`-ից փոխադարձաբար փոխառված արժեքի համար:
///
/// Տեսեք [module-level documentation](self)-ը ավելին:
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust-ի ներքին փոփոխականության հիմնական պարզունակությունը:
///
/// Եթե ունեք `&T` հղում, ապա սովորաբար Rust-ում կազմողը կատարում է օպտիմալացումներ `հիմնվելով այն գիտելիքների վրա, որ `&T`-ը մատնանշում է անփոփոխ տվյալները: Այդ տվյալների փոփոխությունը, օրինակ`կեղծանվան միջոցով կամ `&T`-ը `&mut T`-ի փոխակերպելով, համարվում է չսահմանված վարք:
/// `UnsafeCell<T>` `&T`-ի անփոփոխելիության երաշխիքից հրաժարվելը. `&UnsafeCell<T>` ընդհանուր տեղեկանքը կարող է մատնանշել մուտացիայի ենթարկվող տվյալները: Սա կոչվում է "interior mutability":
///
/// Բոլոր մյուս տեսակները, որոնք թույլ են տալիս ներքին փոփոխականություն, ինչպիսիք են `Cell<T>` և `RefCell<T>`, ներքինից օգտագործում են `UnsafeCell` ՝ իրենց տվյալները փաթաթելու համար:
///
/// Նշենք, որ `UnsafeCell`-ի վրա ազդում է միայն համօգտագործվող հղումների անփոփոխելիության երաշխիքը: Փոփոխական հղումների եզակի երաշխիքը չի ազդում:`&mut` կեղծանուն ձեռք բերելու * * օրինական ձև չկա, նույնիսկ `UnsafeCell<T>`-ի դեպքում:
///
/// `UnsafeCell` API-ն ինքնին տեխնիկապես շատ պարզ է. [`.get()`]-ը ձեզ տալիս է հում `*mut T` ցուցիչ դրա պարունակության համար: Այդ հումքի ցուցիչը ճիշտ օգտագործելը մինչև _you_-ն է որպես աբստրակցիայի դիզայներ:
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Rust կեղծանունի ճշգրիտ կանոնները որոշակիորեն հոսքի մեջ են, բայց հիմնական կետերը վիճահարույց չեն.
///
/// - Եթե դուք ստեղծում եք անվտանգ հղում կյանքի `'a`-ի հետ (կամ `&T` կամ `&mut T` հղում), որը հասանելի է անվտանգ ծածկագրով (օրինակ, քանի որ այն վերադարձրել եք), ապա չպետք է մուտք գործեք տվյալներ որևէ ձևով, որը հակասում է մնացածի համար այդ հղմանը `'a`-ից:
/// Օրինակ, սա նշանակում է, որ եթե դուք վերցնում եք `*mut T`-ը `UnsafeCell<T>`-ից և գցում այն `&T`-ի, ապա `T`-ի տվյալները պետք է մնան անփոփոխ (իհարկե, `T`-ում գտնված ցանկացած `UnsafeCell` տվյալների մոդուլով), մինչև այդ տեղեկանքի կյանքի ժամկետը լրանա:
/// Նմանապես, եթե դուք ստեղծում եք `&mut T` տեղեկանք, որը թողարկվում է անվտանգ կոդ, ապա չպետք է մուտք գործեք տվյալներ `UnsafeCell`-ի սահմաններում, մինչև այդ տեղեկանքի ժամկետը լրանա:
///
/// - Բոլոր ժամանակներում պետք է խուսափել տվյալների մրցավազքից: Եթե բազմաթիվ թելեր ունեն միևնույն `UnsafeCell` մուտք, ապա ցանկացած գրառում պետք է ունենա պատշաճ դեպք, նախքան բոլոր մյուս մուտքերի հետ կապը (կամ օգտագործել ատոմիկա):
///
/// Պատշաճ ձևավորմանը օժանդակելու համար հետևյալ սցենարները հստակորեն հայտարարվում են օրինական ՝ միաշղթա ծածկագրի համար.
///
/// 1. `&T` տեղեկանքը կարող է թողարկվել անվտանգ կոդի, և այնտեղ այն կարող է գոյակցել `&T` այլ հղումների հետ, բայց ոչ `&mut T`-ի:
///
/// 2. `&mut T` տեղեկանքը կարող է թողարկվել անվտանգ ծածկագրին, եթե դրա հետ գոյություն չունենա ոչ մի այլ `&mut T` կամ `&T`: `&mut T`-ը միշտ պետք է լինի եզակի:
///
/// Նկատի ունեցեք, որ չնայած `&UnsafeCell<T>`-ի բովանդակությունը մուտացիայի ենթարկելը (նույնիսկ այն դեպքում, երբ `&UnsafeCell<T>` այլ հղումները `այլընտրանքով բջիջը) կարգին է (պայմանով, որ վերը նշված invariants-ը այլ կերպ եք կիրառում), `&mut UnsafeCell<T>` բազմակի կեղծանուններ ունենալը դեռ անորոշ է:
/// Այսինքն ՝ `UnsafeCell`-ը փաթաթված է, որը նախատեսված է _shared_ accesses (_i.e._-ի հետ հատուկ փոխազդեցություն ունենալու համար, `&UnsafeCell<_>` տեղեկանքի միջոցով);_exclusive_ accesses (_e.g._-ի միջոցով `&mut UnsafeCell<_>`-ի միջոցով գործ ունենալը ոչ մի կախարդանք չունի. ոչ այդ բջիջը և ոչ էլ փաթաթված արժեքը չեն կարող այլընտրանք լինել այդ `&mut` փոխառության տևողության համար:
///
/// Սա ցուցադրվում է [`.get_mut()`] աքսեսուարի կողմից, որը _safe_ getter է, որը տալիս է `&mut T`:
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ահա մի օրինակ, որը ցույց է տալիս, թե ինչպես կարելի է խստորեն մուտացիայի ենթարկել `UnsafeCell<_>`-ի պարունակությունը, չնայած որ բջիջը այլ կերպ ասած բազմաթիվ հղումներ կան.
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Ստացեք միևնույն/միաժամանակյա/համօգտագործվող հղումներ նույն `x`-ին:
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Այս շրջանակներում «x»-ի բովանդակությանը այլ հղումներ չկան,
///     // այնպես որ մերն արդյունավետորեն եզակի է:
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- փոխառել-+
///     *p1_exclusive += 27; // |
/// } // <---------- չի կարող դուրս գալ այս կետից -------------------+
///
/// unsafe {
///     // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Այս շրջանակներում ոչ ոք չի ակնկալում բացառիկ մուտք ունենալ «x»-ի բովանդակության վրա,
///     // այնպես որ մենք կարող ենք միաժամանակ ունենալ բազմաթիվ ընդհանուր մուտքեր:
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Հաջորդ օրինակը ցույց է տալիս այն փաստը, որ `UnsafeCell<T>`-ի բացառիկ մուտքը ենթադրում է բացառիկ մուտք դեպի `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // բացառիկ մուտքերով,
///                         // `UnsafeCell` no-op թափանցիկ փաթաթան է, ուստի այստեղ `unsafe`-ի կարիք չկա:
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Ստացեք `x`-ին կազմված ժամանակի ստուգմամբ ստուգված եզակի հղում:
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Բացառիկ տեղեկանքով մենք կարող ենք անվճար փոխել բովանդակությունը:
/// *p_unique.get_mut() = 0;
/// // Կամ համարժեք:
/// x = UnsafeCell::new(0);
///
/// // Երբ արժեքը մեզ է պատկանում, մենք կարող ենք անվճար արդյունահանել բովանդակությունը:
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Կառուցում է `UnsafeCell`-ի նոր օրինակ, որը փաթեթավորելու է նշված արժեքը:
    ///
    ///
    /// Ներքին արժեքին ամբողջությամբ հասանելիությունը մեթոդների միջոցով `unsafe` է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Արգելքը փաթաթում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Փաթաթվող ցուցիչ է ստանում փաթաթված արժեքին:
    ///
    /// Սա կարող է դրվել ցանկացած ցուցիչի վրա:
    /// Համոզվեք, որ մուտքը եզակի է (ակտիվ հղումներ չկան, փոփոխական են, թե ոչ) `&mut T`-ին ձուլելիս, և համոզվեք, որ `&T`-ին ձուլելու ժամանակ մուտացիաներ կամ փոփոխվող կեղծանուններ չկան:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Մենք կարող ենք պարզապես ցուցիչը գցել `UnsafeCell<T>`-ից `T` ՝ #[repr(transparent)]-ի պատճառով:
        // Սա օգտագործում է libstd-ի հատուկ կարգավիճակը, օգտվողի ծածկագրի համար երաշխիք չկա, որ սա կաշխատի կազմողի future տարբերակներում:
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Վերադարձնում է հիմքում ընկած տվյալների փոփոխական հղումը:
    ///
    /// Այս զանգը փոխառու է `UnsafeCell`-ին փոխադարձաբար (կազմման ժամանակ), ինչը երաշխավորում է, որ մենք ունենք միակ տեղեկանքը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Փաթաթվող ցուցիչ է ստանում փաթաթված արժեքին:
    /// [`get`]-ի տարբերությունն այն է, որ այս ֆունկցիան ընդունում է հում ցուցիչ, որն օգտակար է ժամանակավոր հղումների ստեղծումից խուսափելու համար:
    ///
    /// Արդյունքը կարող է տրվել ցանկացած ցուցիչի վրա:
    /// Համոզվեք, որ մուտքը եզակի է (ակտիվ հղումներ չկան, փոփոխական են, թե ոչ) `&mut T`-ին ձուլելիս և համոզվեք, որ `&T`-ին ձուլելիս չկան մուտացիաներ կամ փոփոխվող կեղծանուններ:
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell`-ի աստիճանական նախնականացումը պահանջում է `raw_get`, քանի որ `get` զանգահարելու համար անհրաժեշտ է հղում ստեղծել ոչ նախնական տվյալների:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Մենք կարող ենք պարզապես ցուցիչը գցել `UnsafeCell<T>`-ից `T` ՝ #[repr(transparent)]-ի պատճառով:
        // Սա օգտագործում է libstd-ի հատուկ կարգավիճակը, օգտվողի ծածկագրի համար երաշխիք չկա, որ սա կաշխատի կազմողի future տարբերակներում:
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Ստեղծում է `UnsafeCell`, T-ի համար `Default` արժեքով:
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}