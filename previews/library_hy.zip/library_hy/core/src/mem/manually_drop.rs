use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Մի փաթաթիչ, որը խանգարում է կազմողին ինքնաբերաբար կոչել «T»-ի կործանիչը:
/// Այս փաթաթումը 0-արժեք է:
///
/// `ManuallyDrop<T>` ենթակա է նույն դասավորության օպտիմիզացման, ինչ `T`-ը:
/// Արդյունքում, այն *ազդեցություն չունի* այն ենթադրությունների վրա, որոնք կազմողը կատարում է իր բովանդակության վերաբերյալ:
/// Օրինակ, `ManuallyDrop<&mut T>`-ի [`mem::zeroed`]-ով նախնական նախադրելը չսահմանված վարք է:
/// Եթե Ձեզ անհրաժեշտ է մշակել ոչ նախնական տվյալներ, փոխարենը օգտագործեք [`MaybeUninit<T>`]:
///
/// Նշենք, որ `ManuallyDrop<T>`-ի ներսում արժեքին մուտք գործելը անվտանգ է:
/// Սա նշանակում է, որ `ManuallyDrop<T>`-ը, որի բովանդակությունը թողարկվել է, չպետք է բացահայտվի հանրային անվտանգ API-ի միջոցով:
/// Համապատասխանաբար, `ManuallyDrop::drop`-ն անվտանգ չէ:
///
/// # `ManuallyDrop` և թողնել պատվերը:
///
/// Rust-ն ունի հստակ սահմանված [drop order] արժեքներ:
/// Համոզվելու համար, որ դաշտերը կամ տեղացիները կտրված են որոշակի հերթականությամբ, վերադասավորեք հայտարարությունները այնպես, որ անուղղակի անկման կարգը ճիշտ լինի:
///
/// Հնարավոր է օգտագործել `ManuallyDrop` ՝ կաթիլների կարգը վերահսկելու համար, բայց դա պահանջում է ոչ անվտանգ կոդ և դժվար է ճիշտ անել ՝ լիցքաթափման առկայության դեպքում:
///
///
/// Օրինակ, եթե ուզում եք համոզվել, որ որևէ այլ դաշտը մյուսներից հետո ընկնում է, ապա այն դարձրեք կառուցվածքի վերջին դաշտը.
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` կթողարկվի `children`-ից հետո:
///     // Rust-ը երաշխավորում է, որ դաշտերը թողարկվում են հայտարարագրման կարգի համաձայն:
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Փաթաթեք արժեքը, որը պետք է ձեռքով գցվի:
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Դուք դեռ կարող եք ապահով կերպով աշխատել արժեքի հետ
    /// assert_eq!(*x, "Hello");
    /// // Բայց `Drop`-ն այստեղ չի գործարկվի
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Քաշում է արժեքը `ManuallyDrop` տարայից:
    ///
    /// Սա թույլ է տալիս արժեքը կրկին իջեցնել:
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Սա թողնում է `Box`-ը:
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Հանում է `ManuallyDrop<T>` տարայի արժեքը:
    ///
    /// Այս մեթոդը հիմնականում նախատեսված է կաթիլները դուրս բերելու համար:
    /// Փոխանակ [`ManuallyDrop::drop`] օգտագործելու արժեքը ձեռքով գցելու համար, կարող եք օգտագործել այս մեթոդը արժեքը վերցնելու և այն ըստ ցանկության օգտագործելու համար:
    ///
    /// Հնարավորության դեպքում նախընտրելի է փոխարենը օգտագործել [`into_inner`][`ManuallyDrop::into_inner`], ինչը կանխում է `ManuallyDrop<T>`-ի բովանդակության կրկնօրինակումը:
    ///
    ///
    /// # Safety
    ///
    /// Այս ֆունկցիան իմաստապես դուրս է հանում պարունակվող արժեքը ՝ առանց կանխելու հետագա օգտագործումը ՝ թողնելով այս տարայի վիճակը անփոփոխ:
    /// Ձեր պարտականությունն է ապահովել, որ այս `ManuallyDrop`-ը կրկին չօգտագործվի:
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք կարդում ենք հղումից, որը երաշխավորված է
        // ուժի մեջ լինել ընթերցումների համար:
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ձեռքով նետում է պարունակվող արժեքը: Սա ճշգրտորեն համարժեք է [`ptr::drop_in_place`] պարունակող ցուցիչով պարունակվող արժեքին զանգահարելուն:
    /// Որպես այդպիսին, քանի դեռ պարունակվող արժեքը փաթեթավորված կառուցվածք չէ, ապակառուցողը կկոչվի տեղում ՝ առանց արժեքը տեղափոխելու, և այդպիսով կարող է օգտագործվել [pinned] տվյալների անվտանգ անկման համար:
    ///
    /// Եթե արժեքի սեփականություն ունեք, փոխարենը կարող եք օգտագործել [`ManuallyDrop::into_inner`]:
    ///
    /// # Safety
    ///
    /// Այս ֆունկցիան գործարկում է պարունակվող արժեքի ապակառուցողականը:
    /// Բնաջնջողի կողմից կատարված փոփոխություններից բացի, հիշողությունը մնում է անփոփոխ, և ինչ վերաբերում է կազմողին, այնուհանդերձ պահում է մի բիտ-օրինաչափություն, որը գործում է `T` տիպի համար:
    ///
    ///
    /// Այնուամենայնիվ, այս "zombie" արժեքը չպետք է ենթարկվի անվտանգ ծածկագրի, և այս գործառույթը չպետք է կանչվի մեկից ավելի անգամ:
    /// Նվազելուց հետո արժեք օգտագործելը կամ մի քանի անգամ արժեք գցելը կարող է առաջացնել չսահմանված վարք (կախված այն բանից, թե ինչ է անում `drop`):
    /// Սովորաբար դա կանխվում է տիպային համակարգով, բայց `ManuallyDrop`-ի օգտվողները պետք է պահպանեն այդ երաշխիքները ՝ առանց կազմողի օգնության:
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք իջեցնում ենք փոփոխական հղումով մատնանշված արժեքը
        // որը երաշխավորված է, որ վավեր է գրելու համար:
        // Theանգահարողը մնում է համոզվել, որ `slot`-ը կրկին չի նետվում:
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}