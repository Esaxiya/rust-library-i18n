use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Փաթաթի տեսակ ՝ `T`-ի ոչ սկզբնական օրինակներ կառուցելու համար:
///
/// # Նախաձեռնարկումն անփոփոխ է
///
/// Կազմողն, ընդհանուր առմամբ, ենթադրում է, որ փոփոխականը պատշաճ կերպով սկզբնավորվում է ՝ փոփոխականի տեսակի պահանջներին համապատասխան: Օրինակ, տեղեկանքի տիպի փոփոխականը պետք է հավասարեցված լինի և չլինի NULL:
/// Սա անփոփոխ է, որը պետք է *միշտ* պահպանվի, նույնիսկ անապահով ծածկագրում:
/// Որպես արդյունք, հղման տիպի փոփոխական զրոյական նախնականացումը առաջացնում է ակնթարթային [undefined behavior][ub], անկախ նրանից ՝ այդ հղումը երբևէ օգտագործվում է հիշողություն մուտք գործելու համար.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // չսահմանված պահվածք!⚠️
/// // Համարժեք կոդը `MaybeUninit<&i32>`-ի հետ.
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // չսահմանված պահվածք!⚠️
/// ```
///
/// Կազմողը օգտագործում է այն տարբեր օպտիմալացումների համար, ինչպիսիք են վազքի ժամանակի ստուգումները և `enum` դասավորության օպտիմիզացումը:
///
/// Նմանապես, ամբողջովին ոչ նախնական հիշողությունը կարող է ունենալ ցանկացած բովանդակություն, մինչդեռ `bool`-ը միշտ պետք է լինի `true` կամ `false`: Ուստի, uninitialized `bool` ստեղծելը չսահմանված վարք է.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // չսահմանված պահվածք!⚠️
/// // Համարժեք կոդը `MaybeUninit<bool>`-ի հետ.
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // չսահմանված պահվածք!⚠️
/// ```
///
/// Ավելին, ոչ նախնական հիշողությունը հատուկ է նրանով, որ չունի ֆիքսված արժեք ("fixed" նշանակում է "it won't change without being written to"): Նույն uninitialized բայթը բազմիցս կարդալը կարող է տարբեր արդյունքներ տալ:
/// Սա ստիպում է չսահմանված պահվածքին ունենալ ոչ նախնականացված տվյալներ փոփոխականում, նույնիսկ եթե այդ փոփոխականն ունի ամբողջ տեսակի տեսակ, որը հակառակ դեպքում կարող է պահել ցանկացած *ֆիքսված* բիթային օրինակ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // չսահմանված պահվածք!⚠️
/// // Համարժեք կոդը `MaybeUninit<i32>`-ի հետ.
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // չսահմանված պահվածք!⚠️
/// ```
/// (Ուշադրություն դարձրեք, որ uninialized ամբողջ թվերի շուրջ կանոնները դեռ վերջնական տեսքի չեն բերվել, բայց մինչ դրանք ավարտվեն, ցանկալի է խուսափել դրանցից):
///
/// Դրանից բացի, հիշեք, որ տեսակների մեծամասնությունը ունի լրացուցիչ անփոփոխություններ, որոնք պարզապես զուտ տիպի մակարդակի սկզբնավորված են համարվում:
/// Օրինակ `« 1 »-ով նախանշված [`Vec<T>`]-ը սկզբնավորված է համարվում (ընթացիկ իրականացման ներքո. Սա կայուն երաշխիք չի ներկայացնում), քանի որ դրա մասին կազմողը գիտի միակ պահանջը, որ տվյալների ցուցիչը պետք է լինի ոչ առոչինչ:
/// Նման `Vec<T>`-ի ստեղծումը չի առաջացնում *անհապաղ* չսահմանված վարք, այլ անպատճառ վարք կառաջացնի առավելագույն անվտանգ գործողությունների դեպքում (ներառյալ `թողնելը):
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ծառայում է հնարավորություն տալ անապահով կոդին գործ ունենալ ոչ նախնական տվյալների հետ:
/// Դա ազդանշան է կազմողին, որը ցույց է տալիս, որ այստեղ հնարավոր է * տվյալները նախնական չլինեն.
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Ստեղծեք հստակ ոչ նախնական հղում:
/// // Կազմողը գիտի, որ `MaybeUninit<T>`-ի ներսում առկա տվյալները կարող են անվավեր լինել, ուստի դրանք UB չեն.
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Սահմանեք այն վավեր արժեքի վրա:
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Արդյունահանեք նախնական տվյալները. Դա թույլատրվում է * *`x`-ը պատշաճ նախաստորագրելուց հետո *:
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Կազմողն այնուհետև գիտի այս կոդի վերաբերյալ ոչ մի սխալ ենթադրություն կամ օպտիմալացում չանել:
///
/// Դուք կարող եք մտածել, որ `MaybeUninit<T>`-ը մի փոքր նման է `Option<T>`-ին, բայց առանց վազքի ժամանակի որևէ հետևման և առանց անվտանգության որևէ ստուգման:
///
/// ## out-pointers
///
/// Դուք կարող եք օգտագործել `MaybeUninit<T>`-ը "out-pointers"-ն իրականացնելու համար. Գործառույթից տվյալներ վերադարձնելու փոխարեն, այն ցուցիչ փոխանցեք որոշ (uninitialized) հիշողությունների ՝ արդյունքը դնելու համար:
/// Սա կարող է օգտակար լինել, երբ զանգահարողի համար կարևոր է վերահսկել, թե ինչպես է արդյունքը պահվում հիշողության մեջ բաշխվում, և դուք ուզում եք խուսափել ավելորդ տեղաշարժերից:
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` չի գցում հին բովանդակությունը, ինչը կարևոր է:
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Այժմ մենք գիտենք, որ `v`-ը նախնականացվել է: Սա նաև համոզվում է, որ vector-ը ճիշտ ընկնում է:
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Նախաձեռնելով զանգվածը տարր առ տարր
///
/// `MaybeUninit<T>` կարող է օգտագործվել մեծ զանգված տարր առ տարր նախաստորագրելու համար.
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Ստեղծեք `MaybeUninit`-ի ոչ նախնական զանգված:
///     // `assume_init`-ն անվտանգ է, քանի որ այն տիպը, որը մենք պնդում ենք, որ այստեղ սկզբնավորվել ենք, միգուցե `MaybeUninit-ի մի փունջ, որոնք նախնականացում չեն պահանջում:
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit`-ի անկումը ոչինչ չի անում:
///     // Այսպիսով `ptr::write`-ի փոխարեն ցուցիչի հում նշանակման օգտագործումը չի հանգեցնում հին ոչ սկզբնական արժեքի իջեցմանը:
/////
///     // Բացի այդ, եթե այս օղակի ընթացքում կա panic, մենք ունենք հիշողության արտահոսք, բայց հիշողության անվտանգության խնդիր չկա:
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Ամեն ինչ նախանշված է:
///     // Rayանգվածը անցեք նախնական տիպի:
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Կարող եք նաև աշխատել մասամբ նախնական զանգվածների հետ, որոնք կարելի է գտնել ցածր մակարդակի տվյալների կառուցվածքներում:
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Ստեղծեք `MaybeUninit`-ի ոչ նախնական զանգված:
/// // `assume_init`-ն անվտանգ է, քանի որ այն տիպը, որը մենք պնդում ենք, որ այստեղ սկզբնավորվել ենք, միգուցե `MaybeUninit-ի մի փունջ, որոնք նախնականացում չեն պահանջում:
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Հաշվեք մեզ հանձնարարված տարրերի քանակը:
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Rayանգվածի յուրաքանչյուր կետի համար թողեք, եթե այն հատկացնենք:
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Դաշտ առ դաշտ կառուցվածք նախաձեռնելը
///
/// Դաշտ առ հատված նախադրյալների նախադրման համար կարող եք օգտագործել `MaybeUninit<T>` և [`std::ptr::addr_of_mut`] մակրոները.
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` դաշտի սկզբնավորում
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` դաշտի նախնական պատրաստում Եթե այստեղ կա panic, ապա `String` `name` դաշտում արտահոսում է:
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Բոլոր դաշտերը նախանշված են, ուստի մենք զանգահարում ենք `assume_init` ՝ նախնական Foo ստանալու համար:
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` երաշխավորված է ունենալ նույն չափը, հավասարեցումը և ABI-ն, ինչ `T`-ը.
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Այնուամենայնիվ, հիշեք, որ *`MaybeUninit<T>` պարունակող* տիպը պարտադիր չէ, որ նույն դասավորությունը լինի.Rust-ն ընդհանուր առմամբ չի երաշխավորում, որ `Foo<T>`-ի դաշտերը ունեն նույն կարգը, ինչ `Foo<U>`-ը, նույնիսկ եթե `T`-ը և `U`-ը ունեն նույն չափը և հավասարեցումը:
///
/// Ավելին, քանի որ ցանկացած բիթ արժեք վավեր է `MaybeUninit<T>`-ի համար, կազմողը չի կարող կիրառել non-zero/niche-filling օպտիմալացում, ինչը, հնարավոր է, ավելի մեծ չափի հանգեցնի.
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Եթե `T`-ն անվտանգ է FFI-ով, ապա այդպիսին է նաև `MaybeUninit<T>`-ը:
///
/// Չնայած `MaybeUninit`-ը `#[repr(transparent)]` է (նշելով, որ դա երաշխավորում է նույն չափը, հավասարեցումը և ABI-ը, ինչ `T`-ը), սա *չի* փոխում նախորդ նախազգուշացումները:
/// `Option<T>` և `Option<MaybeUninit<T>>`-ը դեռ կարող են ունենալ տարբեր չափեր, և `T` տիպի դաշտ պարունակող տիպերը կարող են դրվել (և չափի) այլ կերպ, քան եթե այդ դաշտը լիներ `MaybeUninit<T>`:
/// `MaybeUninit` միության տեսակ է, և արհմիությունների վրա `#[repr(transparent)]`-ն անկայուն է (տես [the tracking issue](https://github.com/rust-lang/rust/issues/60405)):
/// Overամանակի ընթացքում արհմիությունների վերաբերյալ `#[repr(transparent)]`-ի ճշգրիտ երաշխիքները կարող են զարգանալ, և `MaybeUninit`-ը կարող է մնալ կամ չմնալ `#[repr(transparent)]`:
/// Ասաց, որ `MaybeUninit<T>`-ը *միշտ* երաշխավորում է, որ այն ունի նույն չափը, հավասարեցումը և ABI-ը, ինչ `T`-ը.պարզապես կարող է զարգանալ `MaybeUninit`-ի կողմից այդ երաշխիքի իրականացման եղանակը:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Լանգ առարկա, որպեսզի կարողանանք դրա մեջ փաթաթել այլ տեսակներ: Սա օգտակար է գեներատորների համար:
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Չզանգահարելով `T::clone()` ՝ մենք չենք կարող իմանալ, արդյո՞ք նախաստորագրված ենք բավարար դրա համար:
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Ստեղծում է տրված արժեքով նախաստորագրված նոր `MaybeUninit<T>`:
    /// Այս ֆունկցիայի վերադարձման արժեքով անվտանգ է զանգահարել [`assume_init`]:
    ///
    /// Նկատի ունեցեք, որ `MaybeUninit<T>`-ի թողնելը երբեք չի զանգի «T»-ի թողարկման կոդ:
    /// Ձեր պարտականությունն է համոզվել, որ `T`-ն ընկնում է, եթե նախնական տեսք ստանա:
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Ստեղծում է նոր `MaybeUninit<T>` ոչ սկզբնական վիճակում:
    ///
    /// Նկատի ունեցեք, որ `MaybeUninit<T>`-ի թողնելը երբեք չի զանգի «T»-ի թողարկման կոդ:
    /// Ձեր պարտականությունն է համոզվել, որ `T`-ն ընկնում է, եթե նախնական տեսք ստանա:
    ///
    /// Տեսեք [type-level documentation][MaybeUninit]-ը մի քանի օրինակների համար:
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Ստեղծեք `MaybeUninit<T>` տարրերի նոր զանգված ՝ ոչ նախնականացված վիճակում:
    ///
    /// Note: future Rust տարբերակում այս մեթոդը կարող է անհարկի դառնալ, երբ զանգվածի բառային շարահյուսությունը թույլ է տալիս [repeating const expressions](https://github.com/rust-lang/rust/issues/49147):
    ///
    /// Ստորև բերված օրինակը կարող է օգտագործել `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`:
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Վերադարձնում է տվյալների (հնարավոր է ՝ ավելի փոքր) հատված, որն իրականում կարդացել է
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անտեղի `[MaybeUninit<_>; LEN]` ուժի մեջ է:
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Ստեղծում է նոր `MaybeUninit<T>` ոչ սկզբնական վիճակում, հիշողությունը լցվում է `0` բայթով: Դա կախված է `T`-ից `արդյո՞ք դա արդեն իսկ հնարավորություն է տալիս պատշաճ նախնականացման:
    ///
    /// Օրինակ, `MaybeUninit<usize>::zeroed()`-ը նախաստորագրվում է, բայց `MaybeUninit<&'static i32>::zeroed()`-ն այն պատճառով չէ, որ հղումները չպետք է զրոյական լինեն:
    ///
    /// Նկատի ունեցեք, որ `MaybeUninit<T>`-ի թողնելը երբեք չի զանգի «T»-ի թողարկման կոդ:
    /// Ձեր պարտականությունն է համոզվել, որ `T`-ն ընկնում է, եթե նախնական տեսք ստանա:
    ///
    /// # Example
    ///
    /// Այս ֆունկցիայի ճիշտ օգտագործումը. Կառուցվածք զրոյով նախաստորագրելը, որտեղ կառուցվածքի բոլոր դաշտերը կարող են 0-ի բիտ-օրինակը պահել որպես վավեր արժեք:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Այս ֆունկցիայի սխալ* օգտագործումը. Զանգահարել `x.zeroed().assume_init()`, երբ `0` վավեր բիթ-ձև չէ տեսակի համար.
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Aույգի ներսում մենք ստեղծում ենք `NotZero`, որը չունի ճիշտ խտրական:
    /// // Սա չսահմանված պահվածք է: ⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `u.as_mut_ptr()` կետերը հատկացված հիշողությանը:
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Սահմանում է `MaybeUninit<T>`-ի արժեքը:
    /// Սա վերագրանցում է ցանկացած նախորդ արժեք ՝ առանց այն գցելու, այնպես որ զգույշ եղեք, որ չօգտագործեք այն երկու անգամ, քանի դեռ չեք ցանկանում բաց թողնել կործանիչը:
    ///
    /// Ձեր հարմարության համար սա նաև վերադարձնում է անփոփոխ հղում `self`-ի (այժմ անվտանգ նախանշված) պարունակությանը:
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախանշեցինք այս արժեքը:
        unsafe { self.assume_init_mut() }
    }

    /// Ստանում է ցուցիչ պարունակության արժեքին:
    /// Այս ցուցիչից կարդալը կամ այն հղման վերածելը չսահմանված վարք է, քանի դեռ `MaybeUninit<T>`-ը չի նախնականացվել:
    /// Հիշողությանը գրելը, որի վրա մատնանշում է այս (non-transitively) ցուցիչը, չսահմանված վարք է (բացառությամբ `UnsafeCell<T>`-ի ներսում):
    ///
    /// # Examples
    ///
    /// Այս մեթոդի ճիշտ օգտագործումը.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ստեղծեք հղում `MaybeUninit<T>`-ի մեջ: Դա նորմալ է, քանի որ մենք նախաստորագրել ենք դա:
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Սխալ* այս մեթոդի օգտագործումը.
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Մենք ստեղծել ենք հղում դեպի ոչ նախնականացված vector-ին: Սա չսահմանված պահվածք է:⚠️
    /// ```
    ///
    /// (Ուշադրություն դարձրեք, որ ոչ նախնական տվյալներին հղումների վերաբերյալ կանոնները դեռ վերջնականացված չեն, բայց մինչ դրանք ավարտվեն, խորհուրդ է տրվում խուսափել դրանցից):
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` և `ManuallyDrop` երկուսն էլ `repr(transparent)` են, այնպես որ կարող ենք ցուցիչը գցել:
        self as *const _ as *const T
    }

    /// Ստանում է փոփոխվող ցուցիչ պարունակության արժեքին:
    /// Այս ցուցիչից կարդալը կամ այն հղման վերածելը չսահմանված վարք է, քանի դեռ `MaybeUninit<T>`-ը չի նախնականացվել:
    ///
    /// # Examples
    ///
    /// Այս մեթոդի ճիշտ օգտագործումը.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ստեղծեք հղում `MaybeUninit<Vec<u32>>`-ի մեջ:
    /// // Դա նորմալ է, քանի որ մենք նախաստորագրել ենք դա:
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Սխալ* այս մեթոդի օգտագործումը.
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Մենք ստեղծել ենք հղում դեպի ոչ նախնականացված vector-ին: Սա չսահմանված պահվածք է:⚠️
    /// ```
    ///
    /// (Ուշադրություն դարձրեք, որ ոչ նախնական տվյալներին հղումների վերաբերյալ կանոնները դեռ վերջնականացված չեն, բայց մինչ դրանք ավարտվեն, խորհուրդ է տրվում խուսափել դրանցից):
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` և `ManuallyDrop` երկուսն էլ `repr(transparent)` են, այնպես որ կարող ենք ցուցիչը գցել:
        self as *mut _ as *mut T
    }

    /// Քաշում է արժեքը `MaybeUninit<T>` տարայից: Սա հիանալի միջոց է ՝ տվյալների անկումը ապահովելու համար, քանի որ արդյունքում `T` ենթակա է սովորական անկման մշակման:
    ///
    /// # Safety
    ///
    /// Theանգահարողը մնում է երաշխավորել, որ `MaybeUninit<T>`-ն իսկապես գտնվում է նախաստորագրված վիճակում: Այս մասին զանգելը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է անհապաղ անորոշ վարք:
    /// [type-level documentation][inv] պարունակում է ավելի շատ տեղեկատվություն այս սկզբնավորման անփոփոխ մասին:
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Դրանից բացի, հիշեք, որ տեսակների մեծամասնությունը ունի լրացուցիչ անփոփոխություններ, որոնք պարզապես զուտ տիպի մակարդակի սկզբնավորված են համարվում:
    /// Օրինակ `« 1 »-ով նախանշված [`Vec<T>`]-ը սկզբնավորված է համարվում (ընթացիկ իրականացման ներքո. Սա կայուն երաշխիք չի ներկայացնում), քանի որ դրա մասին կազմողը գիտի միակ պահանջը, որ տվյալների ցուցիչը պետք է լինի ոչ առոչինչ:
    ///
    /// Նման `Vec<T>`-ի ստեղծումը չի առաջացնում *անհապաղ* չսահմանված վարք, այլ անպատճառ վարք կառաջացնի առավելագույն անվտանգ գործողությունների դեպքում (ներառյալ `թողնելը):
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Այս մեթոդի ճիշտ օգտագործումը.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Սխալ* այս մեթոդի օգտագործումը.
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` դեռ նախնականացված չէր, ուստի այս վերջին տողը առաջացրեց չսահմանված վարք: ⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի `self`-ի նախաստորագրումը:
        // Սա նաև նշանակում է, որ `self`-ը պետք է լինի `value` տարբերակ:
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Կարդում է արժեքը `MaybeUninit<T>` տարայից: Արդյունքում ստացվող `T`-ը ենթակա է սովորական անկման մշակման:
    ///
    /// Հնարավորության դեպքում նախընտրելի է փոխարենը օգտագործել [`assume_init`], ինչը կանխում է `MaybeUninit<T>`-ի բովանդակության կրկնօրինակումը:
    ///
    /// # Safety
    ///
    /// Theանգահարողը մնում է երաշխավորել, որ `MaybeUninit<T>`-ն իսկապես գտնվում է նախաստորագրված վիճակում: Սրա կոչումը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է չսահմանված վարք:
    /// [type-level documentation][inv] պարունակում է ավելի շատ տեղեկատվություն այս սկզբնավորման անփոփոխ մասին:
    ///
    /// Ավելին, սա թողնում է նույն տվյալների կրկնօրինակը `MaybeUninit<T>`-ում:
    /// Տվյալների բազմակի պատճեններ օգտագործելիս (բազմիցս զանգահարելով `assume_init_read`, կամ նախ զանգահարելով `assume_init_read` և ապա [`assume_init`]), ձեր պարտականությունն է ապահովել, որ այդ տվյալներն իսկապես կրկնօրինակվեն:
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Այս մեթոդի ճիշտ օգտագործումը.
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` է, այնպես որ կարող ենք մի քանի անգամ կարդալ:
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` արժեքի կրկնօրինակումը նորմալ է, ուստի կարող է մի քանի անգամ կարդալ:
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Սխալ* այս մեթոդի օգտագործումը.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Այժմ մենք ստեղծեցինք նույն vector-ի երկու օրինակ `հանգեցնելով կրկնակի ազատ ⚠️, երբ երկուսն էլ հրաժարվեն:
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի `self`-ի նախաստորագրումը:
        // `self.as_ptr()`-ից ընթերցումն անվտանգ է, քանի որ `self`-ը պետք է նախանշվի:
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Նետում է պարունակվող արժեքը տեղում:
    ///
    /// Եթե `MaybeUninit`-ի սեփականություն ունեք, փոխարենը կարող եք օգտագործել [`assume_init`]:
    ///
    /// # Safety
    ///
    /// Theանգահարողը մնում է երաշխավորել, որ `MaybeUninit<T>`-ն իսկապես գտնվում է նախաստորագրված վիճակում: Սրա կոչումը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է չսահմանված վարք:
    ///
    /// Բացի այդ, `T` տիպի բոլոր լրացուցիչ անփոփոխները պետք է բավարարվեն, քանի որ `T`-ի `Drop` (կամ դրա անդամների) իրականացումը կարող է հիմնվել դրա վրա:
    /// Օրինակ `« 1 »-ով նախանշված [`Vec<T>`]-ը սկզբնավորված է համարվում (ընթացիկ իրականացման ներքո. Սա կայուն երաշխիք չի ներկայացնում), քանի որ դրա մասին կազմողը գիտի միակ պահանջը, որ տվյալների ցուցիչը պետք է լինի ոչ առոչինչ:
    ///
    /// Այնուամենայնիվ, այդպիսի `Vec<T>`-ի անկումը կհանգեցնի չսահմանված վարքի:
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի `self`-ի նախաստորագրումը և
        // բավարարում է `T`-ի բոլոր ինվարիանտները:
        // Արժեքը տեղում գցելը անվտանգ է, եթե դա այդպես է:
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ստանում է ընդհանուր հղում պարունակվող արժեքին:
    ///
    /// Սա կարող է օգտակար լինել, երբ մենք ուզում ենք մուտք գործել նախնականացված `MaybeUninit`, բայց `MaybeUninit`-ի սեփականություն չունենալը (կանխելով `.assume_init()`)-ի օգտագործումը):
    ///
    /// # Safety
    ///
    /// Այս բովանդակությունը զանգահարելը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, անորոշ վարք է առաջացնում. Զանգահարողը պետք է երաշխավորի, որ `MaybeUninit<T>`-ն իսկապես գտնվում է նախնական վիճակում:
    ///
    ///
    /// # Examples
    ///
    /// ### Այս մեթոդի ճիշտ օգտագործումը.
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Նախաձեռնեք `x`-ը.
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Այժմ, երբ հայտնի է, որ մեր `MaybeUninit<_>`-ը նախաստորագրվում է, կարգին է ստեղծել դրա վերաբերյալ ընդհանուր հղում.
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `x`-ը նախնականացվել է:
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Այս մեթոդի* սխալ * գործածություններ.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Մենք ստեղծել ենք հղում դեպի ոչ նախնականացված vector-ին: Սա չսահմանված պահվածք է:⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Նախնականացրեք `MaybeUninit`-ը ՝ օգտագործելով `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Տեղեկանք uninitialized `Cell<bool>`-ին. UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի `self`-ի նախաստորագրումը:
        // Սա նաև նշանակում է, որ `self`-ը պետք է լինի `value` տարբերակ:
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ստանում է փոփոխվող (unique) հղում պարունակվող արժեքին:
    ///
    /// Սա կարող է օգտակար լինել, երբ մենք ուզում ենք մուտք գործել նախնականացված `MaybeUninit`, բայց `MaybeUninit`-ի սեփականություն չունենալը (կանխելով `.assume_init()`)-ի օգտագործումը):
    ///
    /// # Safety
    ///
    /// Այս բովանդակությունը զանգահարելը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, անորոշ վարք է առաջացնում. Զանգահարողը պետք է երաշխավորի, որ `MaybeUninit<T>`-ն իսկապես գտնվում է նախնական վիճակում:
    /// Օրինակ, `.assume_init_mut()`-ը չի կարող օգտագործվել `MaybeUninit`-ի նախաստորագրման համար:
    ///
    /// # Examples
    ///
    /// ### Այս մեթոդի ճիշտ օգտագործումը.
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Նախնականացնում է մուտքի բուֆերի *բոլոր* բայթերը:
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Նախաձեռնեք `buf`-ը.
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Այժմ մենք գիտենք, որ `buf`-ը նախնականացվել է, ուստի մենք կարող ենք `.assume_init()` այն:
    /// // Այնուամենայնիվ, `.assume_init()`-ի օգտագործումը կարող է առաջացնել 2048 բայթից `memcpy`:
    /// // Որպեսզի պնդենք, որ մեր բուֆերը նախաստորագրվել է առանց այն պատճենելու, մենք `&mut MaybeUninit<[u8; 2048]>`-ը վերափոխում ենք `&mut [u8; 2048]`-ի.
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `buf`-ը նախնականացվել է:
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Այժմ մենք կարող ենք օգտագործել `buf`-ը որպես սովորական կտոր.
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Այս մեթոդի* սխալ * գործածություններ.
    ///
    /// Դուք չեք կարող օգտագործել `.assume_init_mut()` ՝ արժեք նախադրելու համար.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Մենք ստեղծել ենք (mutable) հղում uninitialized `bool`-ին:
    ///     // Սա չսահմանված պահվածք է: ⚠️
    /// }
    /// ```
    ///
    /// Օրինակ, դուք չեք կարող [`Read`]-ը չհամապատասխանեցված բուֆերի մեջ դնել.
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) հղում դեպի ոչ սկզբնական հիշողություն:
    ///                             // Սա չսահմանված պահվածք է:
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ոչ էլ կարող եք դաշտային դաշտից օգտվել ՝ դաշտ առ դաշտ աստիճանական նախնական պատրաստման համար.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) հղում դեպի ոչ սկզբնական հիշողություն:
    ///                  // Սա չսահմանված պահվածք է:
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) հղում դեպի ոչ սկզբնական հիշողություն:
    ///                  // Սա չսահմանված պահվածք է:
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Ներկայումս մենք ապավինում ենք վերը նշվածի ոչ ճիշտ լինելուն, այսինքն ՝ մենք ունենք հղումներ ոչ նախնական տվյալների (օրինակ ՝ `libcore/fmt/float.rs`-ում):
    // Մենք պետք է վերջնական որոշում կայացնենք կանոնների վերաբերյալ `նախքան կայունացումը:
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի `self`-ի նախաստորագրումը:
        // Սա նաև նշանակում է, որ `self`-ը պետք է լինի `value` տարբերակ:
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Արդյունքները արդյունահանում է `MaybeUninit` տարաների զանգվածից:
    ///
    /// # Safety
    ///
    /// Lerանգահարողին մնում է երաշխավորել, որ զանգվածի բոլոր տարրերը գտնվում են սկզբնական վիճակում:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Այժմ անվտանգ, քանի որ նախանշեցինք բոլոր տարրերը
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Lerանգահարողը երաշխավորում է, որ զանգվածի բոլոր տարրերը սկզբնավորվում են
        // * `MaybeUninit<T>` և T երաշխավորված են, որ ունենան նույն դասավորությունը
        // * Գուցե Unint-ը չի ընկնում, այնպես որ կրկնակի վճարներ չկան: Այսպիսով, փոխարկումը անվտանգ է
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ենթադրելով, որ բոլոր տարրերը նախնականացված են, ստացեք դրանց մի կտոր:
    ///
    /// # Safety
    ///
    /// Theանգահարողը մնում է երաշխավորել, որ `MaybeUninit<T>` տարրերն իսկապես գտնվում են նախաստորագրված վիճակում:
    ///
    /// Սրա կոչումը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է չսահմանված վարք:
    ///
    /// Տե՛ս [`assume_init_ref`] ՝ ավելի մանրամասն և օրինակների համար:
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `*const [T]`-ին կտոր ձուլելը անվտանգ է, քանի որ զանգահարողը դա երաշխավորում է
        // `slice` նախանշված է, և «Գուցե Uninit»-ը երաշխավորված է ունենալ նույն դասավորությունը, ինչ `T`-ը:
        // Ստացված ցուցիչը վավեր է, քանի որ այն վերաբերում է `slice`-ին պատկանող հիշողությանը, որը հղում է, ուստի երաշխավորված է, որ վավեր է ընթերցումների համար:
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ենթադրելով, որ բոլոր տարրերը նախնականացված են, ստացեք նրանց փոփոխվող կտոր:
    ///
    /// # Safety
    ///
    /// Theանգահարողը մնում է երաշխավորել, որ `MaybeUninit<T>` տարրերն իսկապես գտնվում են նախաստորագրված վիճակում:
    ///
    /// Սրա կոչումը, երբ բովանդակությունը դեռ ամբողջությամբ նախնականացված չէ, առաջացնում է չսահմանված վարք:
    ///
    /// Տե՛ս [`assume_init_mut`] ՝ ավելի մանրամասն և օրինակների համար:
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նման է `slice_get_ref`-ի անվտանգության նշումներին, բայց մենք ունենք
        // փոփոխական տեղեկանք, որը երաշխավորված է նաև, որ վավեր է գրերի համար:
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Aուցանիշ է ստանում զանգվածի առաջին տարրին:
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ստանում է փոփոխվող ցուցիչ զանգվածի առաջին տարրին:
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Պատճենավորում է տարրերը `src`-ից `this` ՝ վերադարձնելով անփոփոխ հղում `this`-ի այժմ ինիտալիզացված պարունակությանը:
    ///
    /// Եթե `T`-ը չի իրականացնում `Copy`, օգտագործեք [`write_slice_cloned`]
    ///
    /// Սա նման է [`slice::copy_from_slice`]-ին:
    ///
    /// # Panics
    ///
    /// Այս գործառույթը կլինի panic, եթե երկու շերտերն ունեն տարբեր երկարություններ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք հենց նոր պատճենեցինք լենայի բոլոր տարրերը պահեստային կարողությունների մեջ
    /// // vec-ի առաջին src.len() տարրերն այժմ ուժի մեջ են:
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ.&[T] և&[MaybeUninit]<T>] ունեն նույն դասավորությունը
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Վավեր տարրերը հենց նոր պատճենվել են `this`-ի մեջ, ուստի այն նախակենդանացվում է
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Կլոնավորում է տարրերը `src`-ից `this` ՝ վերադարձնելով անփոփոխ հղում `this`-ի այժմ ինիտալիզացված պարունակությանը:
    /// Alreadyանկացած արդեն initalized տարրեր չեն հանվի:
    ///
    /// Եթե `T`-ն իրականացնում է `Copy`, օգտագործեք [`write_slice`]
    ///
    /// Սա նման է [`slice::clone_from_slice`]-ին, բայց չի թողնում առկա էլեմենտները:
    ///
    /// # Panics
    ///
    /// Այս գործառույթը կլինի panic, եթե երկու շերտերն ունեն տարբեր երկարություններ, կամ եթե `Clone` panics-ի իրականացումը:
    ///
    /// Եթե կա panic, արդեն կլոնավորված տարրերը դուրս կգան:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես կլոնավորեցինք լենայի բոլոր տարրերը պահեստային կարողությունների մեջ
    /// // vec-ի առաջին src.len() տարրերն այժմ ուժի մեջ են:
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Ի տարբերություն copy_from_slice-ի, սա չի անվանում կտորի clone_from_slice-ը, քանի որ `MaybeUninit<T: Clone>`-ը չի իրականացնում Clone-ը:
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Այս հում կտորը պարունակում է միայն նախնական օբյեկտներ
                // այդ պատճառով թույլատրվում է այն գցել:
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Մենք պետք է հստակ կտրենք դրանք նույն երկարությամբ
        // սահմանները ստուգելու համար, և օպտիմիզատորը կստեղծի հիշողություն պարզ դեպքերի համար (օրինակ ՝ T= u8):
        //
        let len = this.len();
        let src = &src[..len];

        // անհրաժեշտ է պաշտպանություն b/c panic կարող է պատահել կլոնի ժամանակ
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Վավեր տարրերը հենց նոր են գրվել `this`-ի մեջ, ուստի այն ինալիզացված է
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}