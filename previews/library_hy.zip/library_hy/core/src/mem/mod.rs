//! Հիշողության հետ գործ ունենալու հիմնական գործառույթները:
//!
//! Այս մոդուլը պարունակում է գործառույթներ `չափը հարցնելու և տեսակները հավասարեցնելու, հիշողությունը նախաստորագրելու և շահարկելու համար:
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Վերցնում է սեփականություն և "forgets" արժեքի մասին **առանց դրա ապակառուցչիչը գործարկելու**:
///
/// Resourcesանկացած ռեսուրս, որի արժեքը կառավարում է, ինչպիսիք են կույտ հիշողությունը կամ ֆայլի բռնիչը, հավերժ կմնա անհասանելի վիճակում: Այնուամենայնիվ, դա չի երաշխավորում, որ այս հիշողության ցուցիչները ուժի մեջ կմնան:
///
/// * Եթե ցանկանում եք հիշողություն արտահոսել, տես [`Box::leak`]:
/// * Եթե ցանկանում եք ձեռք բերել հիշողության հում ցուցիչ, տես [`Box::into_raw`]:
/// * Եթե ցանկանում եք պատշաճ կերպով տնօրինել արժեքը, գործարկելով դրա կործանիչը, տե՛ս [`mem::drop`]:
///
/// # Safety
///
/// `forget` չի նշվում որպես `unsafe`, քանի որ Rust-ի անվտանգության երաշխիքները չեն ներառում երաշխիք, որ ոչնչացնողները միշտ գործելու են:
/// Օրինակ, ծրագիրը կարող է ստեղծել հղման ցիկլ ՝ օգտագործելով [`Rc`][rc], կամ զանգահարել [`process::exit`][exit] ՝ դուրս գալու համար ՝ առանց գործելու ապակառուցող սարքեր:
/// Այսպիսով, անվտանգ կոդից `mem::forget`-ին թույլ տալը հիմնովին չի փոխում Rust-ի անվտանգության երաշխիքները:
///
/// Ասել է թե, հիշողության, I/O օբյեկտների նման ռեսուրսների արտահոսքը սովորաբար անցանկալի է:
/// Անհրաժեշտությունը առաջանում է FFI-ի կամ ոչ անվտանգ կոդի որոշ մասնագիտացված օգտագործման դեպքերում, բայց նույնիսկ այդ դեպքում [`ManuallyDrop`]-ը սովորաբար նախընտրելի է:
///
/// Քանի որ արժեք մոռանալը թույլատրվում է, ձեր գրած ցանկացած `unsafe` կոդ պետք է թույլ տա այս հնարավորությունը: Դուք չեք կարող վերադարձնել մի արժեք և ակնկալել, որ զանգահարողն անպայման գործի է դնում արժեքի ոչնչացնողը:
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`-ի կանոնական անվտանգ օգտագործումը `Drop` trait-ի կողմից ներդրված արժեքի կործանիչը շրջանցելն է: Օրինակ, սա կթողնի `File`, այսինքն
/// հետ վերցնել փոփոխականի կողմից վերցված տարածությունը, բայց երբեք չփակել համակարգի հիմքում ընկած ռեսուրսը.
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Սա օգտակար է, երբ հիմքում ընկած ռեսուրսի սեփականությունը նախկինում փոխանցվել է Rust-ից դուրս գտնվող կոդի, օրինակ `հումքի ֆայլի նկարագրիչը C կոդին փոխանցելու միջոցով:
///
/// # Հարաբերություններ `ManuallyDrop`-ի հետ
///
/// Չնայած `mem::forget`-ը կարող է օգտագործվել նաև *հիշողության* սեփականության իրավունքը փոխանցելու համար, դա անելը սխալ է:
/// [`ManuallyDrop`] փոխարենը պետք է օգտագործվի: Հաշվի առեք, օրինակ, այս ծածկագիրը.
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Կառուցեք `String` ՝ օգտագործելով `v` պարունակությունը
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // արտահոսում է `v`, քանի որ դրա հիշողությունն այժմ կառավարվում է `s`-ի կողմից
/// mem::forget(v);  // ՍԽԱԼ, v անվավեր է և չպետք է փոխանցվի գործառույթի
/// assert_eq!(s, "Az");
/// // `s` անուղղակիորեն ընկնում է, և դրա հիշողությունը տեղաբաշխվում է:
/// ```
///
/// Վերոնշյալ օրինակի հետ կապված երկու խնդիր կա.
///
/// * Եթե `String`-ի կառուցման և `mem::forget()`-ի կանչման միջև ավելի շատ կոդ ավելացվեր, դրա մեջ panic-ն կրկնակի ազատություն կստեղծեր, քանի որ նույն հիշողությունը վարվում է և՛ `v`-ի, և՛ `s`-ի կողմից:
/// * `v.as_mut_ptr()` զանգահարելուց և տվյալների սեփականությունը `s`-ին փոխանցելուց հետո `v` արժեքն անվավեր է:
/// Նույնիսկ այն դեպքում, երբ մի արժեք պարզապես տեղափոխվում է `mem::forget` (ինչը չի ստուգելու այն), որոշ տեսակներ իրենց արժեքների նկատմամբ ունեն խիստ պահանջներ, որոնք դրանք անվավեր են դարձնում կախելու ժամանակ կամ այլևս չեն պատկանում դրանց:
/// Անվավեր արժեքների որևէ ձևով օգտագործումը, ներառյալ դրանք գործառույթներին փոխանցելը կամ վերադարձնելը, կազմում է չսահմանված վարք և կարող է կոտրել կազմողի կողմից արված ենթադրությունները:
///
/// `ManuallyDrop`-ին անցնելը խուսափում է երկու խնդիրներից.
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Նախքան `v`-ը ապամոնտաժենք դրա հումքի մասերի մեջ, համոզվեք, որ այն չի թափվում:
/////
/// let mut v = ManuallyDrop::new(v);
/// // Այժմ ապամոնտաժեք `v`-ը: Այս գործողությունները չեն կարող panic լինել, ուստի չի կարող լինել արտահոսք:
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Վերջապես, կառուցեք `String`:
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` անուղղակիորեն ընկնում է, և դրա հիշողությունը տեղաբաշխվում է:
/// ```
///
/// `ManuallyDrop` կայունորեն կանխում է կրկնակի ազատությունը, քանի որ մենք անջատում ենք «v»-ի կործանիչը, նախքան որևէ այլ բան անելը:
/// `mem::forget()` թույլ չի տալիս դա, որովհետև այն սպառում է իր փաստարկները ՝ ստիպելով մեզ զանգահարել միայն `v`-ից մեզ անհրաժեշտ ինչ-որ բան արդյունահանելուց հետո:
/// Նույնիսկ եթե panic ներդրվեր `ManuallyDrop`-ի կառուցման և լարը կառուցելու միջև (ինչը չի կարող պատահել օրենսգրքում, ինչպես ցույց է տրված), դա կհանգեցնի արտահոսքի և ոչ թե կրկնակի ազատության:
/// Այլ կերպ ասած, `ManuallyDrop` սխալվում է արտահոսքի կողմում `փոխարենը սխալվելու (կրկնակի) անկման կողմում:
///
/// Բացի այդ, `ManuallyDrop`-ը խանգարում է մեզ "touch" `v`-ին ունենալ սեփականությունը `s`-ին փոխանցելուց հետո. `v`-ի հետ փոխգործակցության վերջին քայլը `այն տնօրինելու համար, առանց դրա ապակառուցչի գործարկումը լիովին խուսափվում է:
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`]-ի նման, բայց նաև ընդունում է չմշակված արժեքներ:
///
/// Այս գործառույթը պարզապես շող է, որը պետք է հեռացվի, երբ `unsized_locals` առանձնահատկությունը կայունանա:
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Վերադարձնում է տիպի չափը բայթերում:
///
/// Ավելի կոնկրետ, սա բայթերի փոխհատուցում է զանգվածի հաջորդական տարրերի միջև այդ իրի տեսակի հետ, ներառյալ հավասարեցման լրացումը:
///
/// Այսպիսով, `T` ցանկացած տեսակի և `n` երկարության համար `[T; n]`-ն ունի `n * size_of::<T>()` չափ:
///
/// Ընդհանուր առմամբ, տիպի չափը կայուն չէ հավաքածուներում, բայց հատուկ տիպեր, ինչպիսիք են պարզունակները, կայուն են:
///
/// Հետևյալ աղյուսակը տալիս է պարզունակության չափը:
///
/// Տեսակը |չափը: :<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 քար |4
///
/// Ավելին, `usize`-ը և `isize`-ն ունեն նույն չափը:
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` և `Option<Box<T>>` տեսակները բոլորն ունեն նույն չափը:
/// Եթե `T` չափի է, այդ բոլոր տիպերն ունեն նույն չափը, ինչ `usize`:
///
/// Սլաքի փոփոխականությունը չի փոխում դրա չափը: Որպես այդպիսին, `&T`-ը և `&mut T`-ը ունեն նույն չափը:
/// Նմանապես `*const T`-ի և `* mut T`-ի համար:
///
/// # `#[repr(C)]` իրերի չափը
///
/// Նյութերի `C` ներկայացուցչությունն ունի սահմանված դասավորություն:
/// Այս դասավորության դեպքում իրերի չափը նույնպես կայուն է, քանի դեռ բոլոր դաշտերն ունեն կայուն չափ:
///
/// ## Structs-ի չափը
///
/// `structs`-ի համար չափը որոշվում է հետևյալ ալգորիթմով:
///
/// Հայտարարագրման կարգով պատվիրված կառուցվածքի յուրաքանչյուր դաշտի համար.
///
/// 1. Ավելացրեք դաշտի չափը:
/// 2. Ընթացիկ չափը կլորացրեք հաջորդ դաշտի [alignment]-ի մոտակա բազմապատիկի վրա:
///
/// Վերջապես, կառուցվածքի չափը կլորացրեք նրա [alignment]-ի մոտակա բազմապատիկին:
/// Կառուցվածքի հավասարեցումը սովորաբար իր բոլոր դաշտերի ամենամեծ հավասարեցումն է.սա կարող է փոխվել `repr(align(N))`-ի օգտագործման դեպքում:
///
/// Ի տարբերություն `C`-ի, զրոյական չափի շերտերը կլորացված չեն մեկ բայթ չափի:
///
/// ## Enums-ի չափը
///
/// Թվանշանները, որոնք խտրականությունից բացի այլ տվյալներ չեն կրում, ունեն նույն չափը, ինչ C enums-ը իրենց համար կազմված հարթակում:
///
/// ## Միությունների չափը
///
/// Միության չափը նրա ամենամեծ ոլորտի չափն է:
///
/// Ի տարբերություն `C`-ի, զրոյական չափի միավորումները չեն կլորացվում մինչև մեկ բայթ չափի:
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Որոշ պարզունակներ
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Որոշ զանգվածներ
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Poուցանիշի չափի հավասարություն
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Օգտագործելով `#[repr(C)]`:
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Առաջին դաշտի չափը 1 է, այնպես որ 1-ին ավելացրու չափին: Չափը 1 է:
/// // Երկրորդ դաշտի հավասարեցումը 2 է, այնպես որ լցոնման համար չափը ավելացրեք 1-ով: Չափը 2 է:
/// // Երկրորդ դաշտի չափը 2 է, այնպես որ չափին ավելացրեք 2-ով: Չափը 4 է:
/// // Երրորդ դաշտի հավասարեցումը 1 է, ուստի լցոնման համար չափին ավելացրեք 0: Չափը 4 է:
/// // Երրորդ դաշտի չափը 1 է, այնպես որ 1-ին ավելացրու չափին: Չափը 5 է:
/// // Վերջապես, կառուցվածքի հավասարեցումը 2 է (քանի որ դրա դաշտերի մեջ ամենամեծ հավասարեցումը 2-ն է), ուստի լրացնելու համար չափին ավելացրեք 1:
/// // Չափը 6 է:
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Տուպլային հարվածները հետևում են նույն կանոններին:
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Նշենք, որ դաշտերի վերադասավորումը կարող է իջեցնել չափը:
/// // Մենք կարող ենք հեռացնել լցոնման երկու բայթը ՝ `third`-ը դնելով `second`-ին:
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Միության չափը ամենամեծ դաշտի չափն է:
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Վերադարձնում է բայթերով մատնանշված արժեքի չափը:
///
/// Սովորաբար սա նույնն է, ինչ `size_of::<T>()`-ը:
/// Այնուամենայնիվ, երբ `T`*չունի* ստատիկապես հայտնի չափ, օրինակ ՝ [`[T]`][slice] կտոր կամ [trait object] կտոր, ապա դինամիկորեն հայտնի չափը ստանալու համար կարող է օգտագործվել `size_of_val`:
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `val`-ը հղում է, ուստի այն վավեր հում ցուցիչ է
    unsafe { intrinsics::size_of_val(val) }
}

/// Վերադարձնում է բայթերով մատնանշված արժեքի չափը:
///
/// Սովորաբար սա նույնն է, ինչ `size_of::<T>()`-ը: Այնուամենայնիվ, երբ `T`*չունի* ստատիկապես հայտնի չափ, օրինակ ՝ [`[T]`][slice] կտոր կամ [trait object] կտոր, ապա դինամիկորեն հայտնի չափը ստանալու համար կարող է օգտագործվել `size_of_val_raw`:
///
/// # Safety
///
/// Այս գործառույթն անվտանգ է զանգահարել միայն այն դեպքում, եթե առկա են հետևյալ պայմանները.
///
/// - Եթե `T`-ը `Sized` է, այս գործառույթը զանգահարելը միշտ անվտանգ է:
/// - Եթե `T`-ի չափի պոչը `
///     - a [slice], ապա կտրվածքի պոչի երկարությունը պետք է նախանշված ամբողջ թիվ լինի, իսկ *ամբողջ արժեքի* չափը (դինամիկ պոչի երկարություն + ստատիկ չափի նախածանց) պետք է տեղավորվի `isize`-ի մեջ:
///     - a [trait object], ապա ցուցիչի vtable մասը պետք է մատնանշի չեղափոխող հարկադրանքով ձեռք բերված վավեր սեղան, իսկ *ամբողջ արժեքի* չափը (դինամիկ պոչի երկարություն + ստատիկ չափի նախածանց) պետք է տեղավորվի `isize`-ի մեջ:
///
///     - (unstable) [extern type], ապա այս գործառույթը միշտ անվտանգ է զանգահարելու համար, բայց կարող է panic-ը կամ այլ կերպ վերադարձնել սխալ արժեք, քանի որ արտաքին տեսակի դասավորությունը հայտնի չէ:
///     Սա նույն վարքն է, ինչ [`size_of_val`]-ը `արտաքին տեսակի պոչ ունեցող տիպի վերաբերյալ:
///     - հակառակ դեպքում պահպանողականորեն չի թույլատրվում զանգահարել այս գործառույթը:
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է ապահովի վավեր հում ցուցիչ
    unsafe { intrinsics::size_of_val(val) }
}

/// Վերադարձնում է [ABI] պահանջվող տիպի նվազագույն հավասարեցում:
///
/// `T` տիպի արժեքի յուրաքանչյուր հղում պետք է լինի այս թվի բազմապատիկը:
///
/// Սա հավասարեցում է, որն օգտագործվում է կառուցվածքային դաշտերի համար: Այն կարող է փոքր լինել, քան նախընտրած հավասարեցումը:
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Վերադարձնում է [ABI] պահանջվող նվազագույն հավասարեցում այն տեսակի արժեքի, որի վրա `val` մատնանշում է:
///
/// `T` տիպի արժեքի յուրաքանչյուր հղում պետք է լինի այս թվի բազմապատիկը:
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Val-ը հղում է, ուստի այն վավեր հում ցուցիչ է
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Վերադարձնում է [ABI] պահանջվող տիպի նվազագույն հավասարեցում:
///
/// `T` տիպի արժեքի յուրաքանչյուր հղում պետք է լինի այս թվի բազմապատիկը:
///
/// Սա հավասարեցում է, որն օգտագործվում է կառուցվածքային դաշտերի համար: Այն կարող է փոքր լինել, քան նախընտրած հավասարեցումը:
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Վերադարձնում է [ABI] պահանջվող նվազագույն հավասարեցում այն տեսակի արժեքի, որի վրա `val` մատնանշում է:
///
/// `T` տիպի արժեքի յուրաքանչյուր հղում պետք է լինի այս թվի բազմապատիկը:
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Val-ը հղում է, ուստի այն վավեր հում ցուցիչ է
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Վերադարձնում է [ABI] պահանջվող նվազագույն հավասարեցում այն տեսակի արժեքի, որի վրա `val` մատնանշում է:
///
/// `T` տիպի արժեքի յուրաքանչյուր հղում պետք է լինի այս թվի բազմապատիկը:
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Այս գործառույթն անվտանգ է զանգահարել միայն այն դեպքում, եթե առկա են հետևյալ պայմանները.
///
/// - Եթե `T`-ը `Sized` է, այս գործառույթը զանգահարելը միշտ անվտանգ է:
/// - Եթե `T`-ի չափի պոչը `
///     - a [slice], ապա կտրվածքի պոչի երկարությունը պետք է նախանշված ամբողջ թիվ լինի, իսկ *ամբողջ արժեքի* չափը (դինամիկ պոչի երկարություն + ստատիկ չափի նախածանց) պետք է տեղավորվի `isize`-ի մեջ:
///     - a [trait object], ապա ցուցիչի vtable մասը պետք է մատնանշի չեղափոխող հարկադրանքով ձեռք բերված վավեր սեղան, իսկ *ամբողջ արժեքի* չափը (դինամիկ պոչի երկարություն + ստատիկ չափի նախածանց) պետք է տեղավորվի `isize`-ի մեջ:
///
///     - (unstable) [extern type], ապա այս գործառույթը միշտ անվտանգ է զանգահարելու համար, բայց կարող է panic-ը կամ այլ կերպ վերադարձնել սխալ արժեք, քանի որ արտաքին տեսակի դասավորությունը հայտնի չէ:
///     Սա նույն վարքն է, ինչ [`align_of_val`]-ը `արտաքին տեսակի պոչ ունեցող տիպի վերաբերյալ:
///     - հակառակ դեպքում պահպանողականորեն չի թույլատրվում զանգահարել այս գործառույթը:
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է ապահովի վավեր հում ցուցիչ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Վերադարձնում է `true`, եթե `T` տիպի արժեքները թողնելը նշանակություն ունի:
///
/// Սա զուտ օպտիմալացման ակնարկ է և կարող է իրականացվել պահպանողականորեն.
/// այն կարող է վերադարձնել `true` այն տեսակների համար, որոնք իրականում հրաժարվելու կարիք չունեն:
/// Որպես այդպիսին, միշտ `true` վերադարձնելը կլինի այս գործառույթի վավեր իրականացումը: Այնուամենայնիվ, եթե այս ֆունկցիան իրականում վերադարձնում է `false`, ապա վստահ կլինեք, որ `T` իջնելը կողմնակի ազդեցություն չունի:
///
/// Հավաքածուների նման իրերի ցածր մակարդակի իրականացումը, որոնք պետք է ձեռքով գցեն իրենց տվյալները, պետք է օգտագործեն այս գործառույթը, որպեսզի խուսափեն անհարկի փորձել նետել դրանց ամբողջ բովանդակությունը, երբ դրանք ոչնչացվում են:
///
/// Սա կարող է փոփոխություն չթողնել թողարկումների կառուցվածքում (որտեղ օղակը, որը չունի կողմնակի էֆեկտներ, հեշտությամբ հայտնաբերվում և վերացվում է), բայց հաճախ դա մեծ շահույթ է վրիպազերծման կառուցվածքների համար:
///
/// Նկատի ունեցեք, որ [`drop_in_place`]-ն արդեն կատարում է այս ստուգումը, այնպես որ, եթե ձեր ծանրաբեռնվածությունը հնարավոր է հասցնել [`drop_in_place`] զանգերի մի փոքր քանակի, ապա դրա օգտագործումը ավելորդ է:
/// Մասնավորապես նշենք, որ դուք կարող եք [`drop_in_place`] մի կտոր տալ, և դա կկատարի կարիքների մեկ կաթիլի ստուգում բոլոր արժեքների համար:
///
/// Vec-ի նման տեսակները, հետեւաբար, պարզապես `drop_in_place(&mut self[..])` են `առանց `needs_drop`-ի բացահայտ օգտագործման:
/// Մյուս կողմից, [`HashMap`]-ի նման տեսակները միանգամից պետք է արժեքներ գցեն և պետք է օգտագործեն այս API-ն:
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ահա մի օրինակ, թե ինչպես հավաքածուն կարող է օգտագործել `needs_drop`-ը.
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // թողնել տվյալները
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Վերադարձնում է `T` տիպի արժեքը, որը ներկայացված է ամբողջ զրոյական բայթ-օրինակով:
///
/// Սա նշանակում է, որ, օրինակ, լցոնման բայթը `(u8, u16)`-ում պարտադիր չէ զրոյացնել:
///
/// Չկա երաշխիք, որ ամբողջ զրոյական բայթ-օրինակը ներկայացնում է `T` որոշ տիպի վավեր արժեք:
/// Օրինակ, ամբողջ զրոյական բայթ օրինաչափությունը վավեր արժեք չէ տեղեկատու տիպերի (`&T`, `&mut T`) և գործառույթների ցուցիչների համար:
/// `zeroed`-ի օգտագործումը նման տիպերի վրա առաջացնում է անհապաղ [undefined behavior][ub], քանի որ [the Rust compiler assumes][inv]-ը, որը միշտ համարում է վավեր մեծություն, փոփոխականում, որը համարում է սկզբնավորված:
///
///
/// Սա ունի նույն ազդեցությունը, ինչ [`MaybeUninit::zeroed().assume_init()`][zeroed]-ը:
/// Այն երբեմն օգտակար է FFI-ի համար, բայց, ընդհանուր առմամբ, պետք է խուսափել:
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Այս գործառույթի ճիշտ օգտագործումը. Ամբողջ թվով զրոյով նախաստորագրում:
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Այս գործառույթի* սխալ * օգտագործումը. Հղում նախնականացնելով զրոյով:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Չսահմանված պահվածք!
/// let _y: fn() = unsafe { mem::zeroed() }; // Եւ կրկին!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ ամբողջ զրոյական արժեքը վավեր է `T`-ի համար:
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Շրջանցում է Rust-ի նորմալ հիշողության սկզբնավորման ստուգումները ՝ `T` տիպի արժեք արտադրելու ձևով, մինչդեռ ընդհանրապես ոչինչ չի ձեռնարկում:
///
/// **Այս գործառույթը հնացած է:** Փոխարենը օգտագործեք [`MaybeUninit<T>`]:
///
/// Արգելափակման պատճառն այն է, որ գործառույթը հիմնականում չի կարող ճիշտ օգտագործվել. Այն ունի նույն ազդեցությունը, ինչ [`MaybeUninit::uninit().assume_init()`][uninit]-ը:
///
/// Ինչպես բացատրում է [`assume_init` documentation][assume_init]-ը, այդ արժեքները [the Rust compiler assumes][inv]-ը պատշաճ կերպով նախանշվում են:
/// Որպես հետեւանք, զանգահարել, օրինակ
/// `mem::uninitialized::<bool>()` անհապաղ անորոշ վարք է առաջացնում `bool` վերադարձնելու համար, որը հաստատ `true` կամ `false` չէ:
/// Ավելի վատ, իսկապես ոչ նախնականացված հիշողությունը, ինչպիսին է այստեղ վերադարձը, առանձնահատուկ է նրանով, որ կազմողը գիտի, որ այն չունի հաստատուն արժեք:
/// Սա ստիպում է չսահմանված պահվածքին ունենալ ոչ նախնական տվյալներ փոփոխականում, նույնիսկ եթե այդ փոփոխականն ունի ամբողջ տիպի տեսակ:
/// (Ուշադրություն դարձրեք, որ uninialized ամբողջ թվերի շուրջ կանոնները դեռ վերջնական տեսքի չեն բերվել, բայց մինչ դրանք ավարտվեն, ցանկալի է խուսափել դրանցից):
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ միավորացված արժեքը վավեր է `T`-ի համար:
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Փոխանակում է արժեքները երկու փոփոխական վայրերում ՝ առանց որևէ մեկի ապասառավարման:
///
/// * Եթե ցանկանում եք փոխել լռելյայն կամ կեղծ արժեքով, տե՛ս [`take`]:
/// * Եթե ցանկանում եք փոխել անցած արժեքով, վերադարձնելով հին արժեքը, տե՛ս [`replace`]:
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հում ցուցիչները ստեղծվել են անվտանգ փոփոխվող հղումներից, որոնք բավարարում են բոլոր կետերը
    // սահմանափակումներ `ptr::swap_nonoverlapping_one`-ի վրա
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest`-ը փոխարինում է `T`-ի կանխադրված արժեքով `վերադարձնելով նախորդ `dest` արժեքը:
///
/// * Եթե ցանկանում եք փոխարինել երկու փոփոխականների արժեքները, տես [`swap`]:
/// * Եթե ուզում եք լռելյայն արժեքի փոխարեն փոխարինել փոխանցված արժեքով, տես [`replace`]:
///
/// # Examples
///
/// Պարզ օրինակ.
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` թույլ է տալիս տիրանալ կառուցվածքային դաշտին ՝ այն փոխարինելով "empty" արժեքով:
/// Առանց `take`-ի կարող եք բախվել այսպիսի խնդիրների.
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Նշենք, որ `T`-ը պարտադիր չէ, որ [`Clone`] է իրականացնում, ուստի այն չի կարող նույնիսկ կլոնավորել և վերականգնել `self.buf`-ը:
/// Բայց `take`-ը կարող է օգտագործվել `self.buf`-ի սկզբնական արժեքը `self`-ից բաժանելու համար `թույլ տալով վերադարձնել այն.
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src`-ը տեղափոխվում է վկայակոչված `dest`-ի մեջ ՝ վերադարձնելով նախորդ `dest` արժեքը:
///
/// Ոչ մի արժեք չի իջնում:
///
/// * Եթե ցանկանում եք փոխարինել երկու փոփոխականների արժեքները, տես [`swap`]:
/// * Եթե ցանկանում եք փոխարինել լռելյայն արժեքով, տես [`take`]:
///
/// # Examples
///
/// Պարզ օրինակ.
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` թույլ է տալիս կառուցվածքային դաշտի սպառում `այն փոխարինելով մեկ այլ արժեքով:
/// Առանց `replace`-ի կարող եք բախվել այսպիսի խնդիրների.
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Նշենք, որ `T`-ը պարտադիր չէ, որ [`Clone`]-ն է իրականացնում, ուստի մենք չենք կարող նույնիսկ կլոնավորել `self.buf[i]`-ը `տեղափոխվելուց խուսափելու համար:
/// Բայց `replace`-ը կարող է օգտագործվել այդ ինդեքսում սկզբնական արժեքը `self`-ից բաժանելու համար `թույլ տալով, որ այն վերադարձվի.
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք կարդում ենք `dest`-ից, բայց դրանից հետո դրա մեջ ուղղակիորեն գրում ենք `src`,
    // այնպիսին, որ հին արժեքը կրկնօրինակված չէ:
    // Ոչինչ չի ընկնում, և այստեղ ոչինչ չի կարող panic:
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Տնօրինում է արժեք:
///
/// Դա արվում է `կանչելով փաստարկի [`Drop`][drop]-ի իրականացումը:
///
/// Սա, ըստ էության, ոչինչ չի ձեռնարկում այն տեսակների համար, որոնք իրականացնում են `Copy`, օրինակ
/// integers.
/// Նման արժեքները պատճենվում են և _then_-ը տեղափոխվում է գործառույթ, ուստի արժեքը պահպանվում է այս գործառույթի զանգից հետո:
///
///
/// Այս գործառույթը կախարդական չէ.այն բառացիորեն սահմանվում է որպես
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Քանի որ `_x`-ը տեղափոխվում է գործառույթ, այն ինքնաբերաբար ընկնում է մինչ գործառույթը վերադառնա:
///
/// [drop]: Drop
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // բացահայտորեն հրաժարվել vector-ից
/// ```
///
/// Քանի որ [`RefCell`]-ը գործարկման ժամանակ պարտադրում է փոխառության կանոնները, `drop`-ը կարող է թողարկել [`RefCell`] փոխառություն.
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // հրաժարվել այս անցքի փոխադարձ փոխառությունից
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// X001-ի վրա չեն ազդում ամբողջ թվերը և [`Copy`]-ն իրականացնող այլ տեսակներ:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x`-ի պատճենը տեղափոխվում և գցվում է
/// drop(y); // `y`-ի պատճենը տեղափոխվում և գցվում է
///
/// println!("x: {}, y: {}", x, y.0); // դեռ մատչելի է
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src`-ը մեկնաբանում է որպես `&U` տիպ ունեցող, ապա կարդում է `src` ՝ առանց պարունակությունը փոխելու:
///
/// Այս ֆունկցիան անվստահորեն ենթադրելու է, որ `src` ցուցիչը վավեր է [`size_of::<U>`][size_of] բայթերի համար `փոխարկելով `&T`-ը `&U` և այնուհետև կարդալով `&U` (բացառությամբ, որ դա արվում է ճիշտ եղանակով, նույնիսկ այն դեպքում, երբ `&U`-ը ավելի խիստ պահանջներ է դնում հավասարեցման `&T`-ի):
/// Այն նաև անապահով կստեղծի պարունակվող արժեքի կրկնօրինակը ՝ `src`-ից դուրս գալու փոխարեն:
///
/// Կոմպիլյացիայի ժամանակի սխալ չէ, եթե `T`-ը և `U`-ն ունեն տարբեր չափսեր, բայց խրախուսվում է այս գործառույթը վկայակոչել միայն այն դեպքում, երբ `T`-ը և `U`-ը ունեն նույն չափը: Այս գործառույթը հրահրում է [undefined behavior][ub]-ը, եթե `U`-ը `T`-ից մեծ է:
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Պատճենեք տվյալները 'foo_array'-ից և վերաբերվեք դրանք որպես 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Փոփոխել պատճենված տվյալները
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array'-ի պարունակությունը չպետք է փոխվեր
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Եթե U-ն ունի հավասարեցման ավելի բարձր պահանջ, src-ը կարող է համապատասխանաբար հավասարեցված չլինել:
    if align_of::<U>() > align_of::<T>() {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `src`-ը հղում է, որը երաշխավորված է, որ ուժի մեջ է ընթերցումների համար:
        // Theանգահարողը պետք է երաշխավորի, որ իրական փոխարկումն անվտանգ է:
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `src`-ը հղում է, որը երաշխավորված է, որ ուժի մեջ է ընթերցումների համար:
        // Մենք պարզապես ստուգեցինք, որ `src as *const U`-ը ճիշտ է դասավորված:
        // Theանգահարողը պետք է երաշխավորի, որ իրական փոխարկումն անվտանգ է:
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Անթափանց տիպ, որը ներկայացնում է հաշվարկի խտրականությունը:
///
/// Լրացուցիչ տեղեկությունների համար տեսեք այս մոդուլի [`discriminant`] գործառույթը:
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. trait-ի այս ներդրումները չեն կարող ստացվել, քանի որ մենք T-ի սահմաններ չենք ուզում:

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Վերադարձնում է մի արժեք, որը եզակիորեն ճանաչում է `v`-ի enum տարբերակը:
///
/// Եթե `T` թվանշան չէ, այս գործառույթը կանչելը չի հանգեցնի չսահմանված վարքի, բայց վերադարձի արժեքը չի նշվում:
///
///
/// # Stability
///
/// Enum-ի տարբերակի տարբերակիչը կարող է փոխվել, եթե enum-ի սահմանումը փոխվի:
/// Որոշ տարբերակի տարբերակիչը չի փոխվի նույն կազմողի հետ կազմողների միջև:
///
/// # Examples
///
/// Սա կարող է օգտագործվել տվյալների համեմատություն կատարող թվանշանների համեմատության համար ՝ միևնույն ժամանակ հաշվի չառնելով բուն տվյալները.
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Վերադարձնում է `T` enum տիպի տարբերակների քանակը:
///
/// Եթե `T` թվանշան չէ, այս գործառույթը կանչելը չի հանգեցնի չսահմանված վարքի, բայց վերադարձի արժեքը չի նշվում:
/// Հավասարապես, եթե `T`-ը `usize::MAX`-ից ավելի տարբերակներ ունեցող հաշվարկ է, վերադարձի արժեքը չի նշվում:
/// Հաշվելու են անմարդաբնակ տարբերակները:
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}