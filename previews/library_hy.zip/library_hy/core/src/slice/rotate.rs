// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Պտտեցնում է `[mid-left, mid+right)` տիրույթը այնպես, որ `mid`-ի տարրը դառնա առաջին տարրը: Համարժեքորեն պտտվում է `left` տարրերի տիրույթը ձախ կամ `right` տարրերը աջ:
///
/// # Safety
///
/// Նշված տիրույթը պետք է վավեր լինի ընթերցելու և գրելու համար:
///
/// # Algorithm
///
/// Ալգորիթմ 1-ն օգտագործվում է `left + right` փոքր մեծության կամ մեծ `T`-ի համար:
/// Էլեմենտները տեղափոխվում են իրենց վերջնական դիրքերը միանգամից սկսած `mid - left`-ից և առաջ շարժվում `right` աստիճաններով `left + right` մոդուլով, այնպես, որ անհրաժեշտ է միայն մեկ ժամանակավոր:
/// Ի վերջո, մենք հետ ենք գալիս `mid - left`:
/// Այնուամենայնիվ, եթե `gcd(left + right, right)`-ը 1 չէ, վերը նշված քայլերը շրջանցվում են տարրերի վրա:
/// Օրինակ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Բարեբախտաբար, վերջնական տարրերի միջև բաց թողնված տարրերի քանակը միշտ հավասար է, ուստի մենք կարող ենք պարզապես փոխհատուցել մեր մեկնարկային դիրքը և կատարել ավելի շատ շրջափակումներ (ընդհանուր փուլերի քանակը `gcd(left + right, right)` value) է):
///
/// Վերջնական արդյունքն այն է, որ բոլոր տարրերը վերջանում են մեկ և միայն մեկ անգամ:
///
/// Ալգորիթմ 2-ն օգտագործվում է, եթե `left + right`-ը մեծ է, բայց `min(left, right)`-ն այնքան փոքր է, որ տեղավորվի բուրգ բուֆերի վրա:
/// `min(left, right)` տարրերը պատճենվում են բուֆերի վրա, `memmove`-ը կիրառվում է մյուսների վրա, իսկ բուֆերի վրա գտնվողները հետ են տեղափոխվում իրենց ծագման հակառակ կողմի անցքը:
///
/// Վեկտորիզացված ալգորիթմները գերազանցում են վերը նշվածին, հենց որ `left + right`-ը դառնա բավականաչափ մեծ:
/// 1-ին ալգորիթմը հնարավոր է վեկտորիզացնել `միանգամից բազմաթիվ փուլեր կտրելով և կատարելով, բայց միջինում շատ քիչ փուլեր կան, մինչև `left + right`-ը հսկայական լինի, և մեկ փուլի ամենավատ դեպքը միշտ առկա է:
/// Փոխարենը, 3 ալգորիթմը օգտագործում է `min(left, right)` տարրերի կրկնակի փոխանակում, մինչև պտտման ավելի փոքր խնդիր մնա:
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// երբ `left < right`-ը փոխանակումը տեղի է ունենում ձախից փոխարենը:
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. Ստորև նշված ալգորիթմները կարող են ձախողվել, եթե այդ դեպքերը չստուգվեն
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Ալգորիթմ 1 միկրոբենանիշերը ցույց են տալիս, որ պատահական հերթափոխի միջին կատարողականը մինչև `left + right == 32` ավելի լավն է, բայց ամենավատ դեպքը կատարում է նույնիսկ 16-ը:
            // 24-ը ընտրվեց որպես միջակ:
            // Եթե `T`-ի չափը 4-ից մեծ է, ապա այս ալգորիթմը գերազանցում է նաև այլ ալգորիթմներին:
            //
            //
            let x = unsafe { mid.sub(left) };
            // առաջին շրջանի սկիզբը
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` կարելի է գտնել ձեռքից առաջ ՝ `gcd(left + right, right)`- ը հաշվարկելով, բայց ավելի արագ է անել մի օղակ, որը gcd- ն հաշվարկում է որպես կողմնակի էֆեկտ, ապա կատարում է մնացած կտորը
            //
            //
            let mut gcd = right;
            // հենանիշները ցույց են տալիս, որ ժամանակի ընթացքում փոխելն ավելի արագ է ՝ փոխարենը մեկ անգամ մեկ ժամանակավոր կարդալու, հետ պատճենելու և այն ժամանակավոր գրելու վերջում:
            // Դա հնարավոր է պայմանավորված է նրանով, որ ժամանակի փոխանակումը կամ փոխարինումը հանգույցում օգտագործում է միայն մեկ հիշողության հասցե ՝ փոխարենը երկուսը կառավարելու անհրաժեշտության:
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // փոխանակ `i` ավելացնելու և ապա ստուգելու, թե արդյոք այն սահմաններից դուրս է, մենք ստուգում ենք, արդյոք `i` դուրս կգա սահմաններից դուրս հաջորդ աճի վրա:
                // Սա կանխում է ցուցիչների կամ `usize`-ի ցանկացած փաթաթում:
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // առաջին փուլի ավարտ
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // այս պայմանականը պետք է լինի այստեղ, եթե `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ավարտեք կտորը ավելի շատ պտույտներով
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` զրոյական չափի տեսակ չէ, ուստի նորմալ է բաժանել դրա չափը:
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Ալգորիթմ 2 Այստեղ `[T; 0]`-ն ապահովում է T-ի համապատասխան համապատասխանեցումը
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Ալգորիթմ 3 Փոխանակման այլընտրանքային տարբերակ կա, որը ենթադրում է գտնել, թե որտեղ է լինելու այս ալգորիթմի վերջին փոխանակումը, և այդ վերջին կտորի օգտագործմամբ փոխանակում ՝ փոխարենը փոխելով հարակից կտորները, ինչպես անում է այս ալգորիթմը, բայց այս եղանակը դեռ ավելի արագ է:
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Ալգորիթմ 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}