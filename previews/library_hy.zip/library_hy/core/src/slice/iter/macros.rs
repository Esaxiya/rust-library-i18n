//! Հատվածքի կրկնիչների կողմից օգտագործվող մակրոները:

// Տողերը լրացնելը դատարկ է և len-ը հսկայական տարբերություն է կատարում
macro_rules! is_empty {
    // ZST կրկնիչի երկարության ծածկագրման եղանակով սա գործում է ինչպես ZST, այնպես էլ ոչ ZST:
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Որոշ սահմանային ստուգումներից ազատվելու համար (տես `position`) մենք երկարությունը հաշվարկում ենք մի փոքր անսպասելի ձևով:
// (Փորձարկվում է «codegen/կտոր-դիրքի սահմանների-ստուգման» միջոցով):
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // մենք երբեմն օգտագործվում ենք ոչ անվտանգ բլոկում

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Այս _cannot_-ն օգտագործում է `unchecked_sub`, քանի որ մենք կախված ենք փաթաթումից `ներկայացնելով ZST երկար կտոր կրկնիչների երկարությունը:
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Մենք գիտենք, որ `start <= end`-ը, այնպես որ, կարող է ավելի լավ անել, քան `offset_from`-ը, որն անհրաժեշտ է ստորագրել գործարքի մեջ:
            // Այստեղ համապատասխան դրոշներ տեղադրելով մենք կարող ենք LLVM-ին ասել սա, ինչը օգնում է նրան հեռացնել սահմանների ստուգումները:
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ըստ տեսակի անփոփոխ, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // LLVM-ին ասելով, որ ցուցիչները բաժանված են տիպի չափի ճշգրիտ բազմապատկմամբ, այն կարող է օպտիմալացնել `len() == 0`-ը մինչև `start == end` `(end - start) < size`-ի փոխարեն:
            //
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ըստ անփոփոխ տիպի, ցուցիչները հավասարեցված են այնպես, որ
            //         նրանց միջեւ հեռավորությունը պետք է լինի միավորի չափի բազմապատիկը
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` և `IterMut` կրկնիչների ընդհանուր սահմանումը
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Վերադարձնում է առաջին տարրը և կրկնիչի մեկնարկը տեղափոխում 1-ով առաջ:
        // Մեծապես բարելավում է կատարումը `համեմատած ընդգծված գործառույթի հետ:
        // Կրկնիչը չպետք է դատարկ լինի:
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Վերադարձնում է վերջին տարրը և կրկնիչի վերջը 1-ով տեղափոխում հետընթաց:
        // Մեծապես բարելավում է կատարումը `համեմատած ընդգծված գործառույթի հետ:
        // Կրկնիչը չպետք է դատարկ լինի:
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Նվազեցնում է կրկնիչը, երբ T-ն ZST է, կրկնիչի վերջը `n`-ով հետ շարժելով:
        // `n` չպետք է գերազանցի `self.len()`-ը:
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Օգնողի գործառույթը կրկնիչի կողմից կտոր ստեղծելու համար:
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Կրկնիչը ստեղծվել է ցուցիչի կտորից
                // `self.ptr` և երկարությունը `len!(self)`:
                // Սա երաշխավորում է, որ `from_raw_parts`-ի բոլոր նախադրյալները կատարված են:
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Օգնողի գործառույթը կրկնիչի մեկնարկը `offset` տարրերով առաջ տեղափոխելու համար ՝ վերադարձնելով հին մեկնարկը:
            //
            // Անվտանգ, քանի որ փոխհատուցումը չպետք է գերազանցի `self.len()`-ը:
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը երաշխավորում է, որ `offset`-ը չի գերազանցում `self.len()`-ը,
                    // այնպես որ այս նոր ցուցիչը `self`-ի ներսում է և, այդպիսով, երաշխավորված է, որ ոչ առոչինչ է:
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Օգնողի գործառույթը կրկնիչի վերջը `offset` տարրերով հետ տեղափոխելու համար ՝ վերադարձնելով նոր վերջը:
            //
            // Անվտանգ, քանի որ փոխհատուցումը չպետք է գերազանցի `self.len()`-ը:
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը երաշխավորում է, որ `offset`-ը չի գերազանցում `self.len()`-ը,
                    // որը երաշխավորված է, որ չի լցվի `isize`:
                    // Բացի այդ, արդյունքում ցուցիչը `slice`-ի սահմաններում է, որը համապատասխանում է `offset`-ի մյուս պահանջներին:
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // կարող էր իրականացվել կտորներով, բայց դա խուսափում է սահմանների ստուգումներից

                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `assume` զանգերը անվտանգ են, քանի որ կտորի մեկնարկի ցուցիչը
                // պետք է լինի ոչ առարկայական, իսկ ոչ ZST-ների կտորները պետք է ունենան նաև ոչ անվավեր վերջի ցուցիչ:
                // `next_unchecked!`-ի զանգը անվտանգ է, քանի որ մենք ստուգում ենք, թե նախ արդյոք կրկնվողը դատարկ է:
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Այս կրկնիչը այժմ դատարկ է:
                    if mem::size_of::<T>() == 0 {
                        // Մենք պետք է դա անենք այս եղանակով, քանի որ `ptr` կարող է երբեք 0 չլինել, բայց `end` կարող է լինել (փաթաթելու պատճառով):
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Վերջը չի կարող լինել 0, եթե T-ն ZST չէ, քանի որ ptr-ը 0 չէ, և վերջ>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք սահմանների մեջ ենք: `post_inc_start`-ը ճիշտ է անում նույնիսկ ZST-ների համար:
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Մենք անտեսում ենք լռելյայն իրականացումը, որն օգտագործում է `try_fold`, քանի որ այս պարզ իրականացումը առաջացնում է ավելի քիչ LLVM IR և ավելի արագ է կազմվում:
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Մենք անտեսում ենք լռելյայն իրականացումը, որն օգտագործում է `try_fold`, քանի որ այս պարզ իրականացումը առաջացնում է ավելի քիչ LLVM IR և ավելի արագ է կազմվում:
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Մենք անտեսում ենք լռելյայն իրականացումը, որն օգտագործում է `try_fold`, քանի որ այս պարզ իրականացումը առաջացնում է ավելի քիչ LLVM IR և ավելի արագ է կազմվում:
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Մենք անտեսում ենք լռելյայն իրականացումը, որն օգտագործում է `try_fold`, քանի որ այս պարզ իրականացումը առաջացնում է ավելի քիչ LLVM IR և ավելի արագ է կազմվում:
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Մենք անտեսում ենք լռելյայն իրականացումը, որն օգտագործում է `try_fold`, քանի որ այս պարզ իրականացումը առաջացնում է ավելի քիչ LLVM IR և ավելի արագ է կազմվում:
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Մենք անտեսում ենք լռելյայն իրականացումը, որն օգտագործում է `try_fold`, քանի որ այս պարզ իրականացումը առաջացնում է ավելի քիչ LLVM IR և ավելի արագ է կազմվում:
            // Բացի այդ, `assume`-ը խուսափում է սահմանների ստուգումից:
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Երաշխավորված ենք, որ օղակը անփոփոխ է ՝
                        // երբ `i >= n`, `self.next()` վերադարձնում է `None`, և հանգույցը կոտրվում է:
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Մենք անտեսում ենք լռելյայն իրականացումը, որն օգտագործում է `try_fold`, քանի որ այս պարզ իրականացումը առաջացնում է ավելի քիչ LLVM IR և ավելի արագ է կազմվում:
            // Բացի այդ, `assume`-ը խուսափում է սահմանների ստուգումից:
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `i`-ը պետք է ցածր լինի `n`-ից, քանի որ այն սկսվում է `n`-ից
                        // և միայն նվազում է:
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `i`-ը սահմաններում է
                // հիմքում ընկած հատվածը, այնպես որ `i`-ը չի կարող `isize`-ից հորդել, և վերադարձված հղումները երաշխավորված են, որ վերաբերում են կտորի տարրին և, այդպիսով, երաշխավորված են, որ դրանք վավեր են:
                //
                // Նաև նշենք, որ զանգահարողը նաև երաշխավորում է, որ մենք այլևս երբեք մեզ նույն ցուցանիշով չեն զանգահարում, և որ այլ եղանակներ չեն կանչվում, որոնք մուտք կգտնեն այս ենթահամարը, ուստի վավեր է, որ վերադարձված հղումը փոփոխական լինի այն դեպքում, երբ
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // կարող էր իրականացվել կտորներով, բայց դա խուսափում է սահմանների ստուգումներից

                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `assume` զանգերն անվտանգ են, քանի որ կտորի մեկնարկի ցուցիչը պետք է լինի ոչ առոչինչ,
                // և ոչ ZST-ների կտորները նույնպես պետք է ունենան ոչ զրոյական վերջի ցուցիչ:
                // `next_back_unchecked!`-ի զանգը անվտանգ է, քանի որ մենք ստուգում ենք, թե նախ արդյոք կրկնվողը դատարկ է:
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Այս կրկնիչը այժմ դատարկ է:
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք սահմանների մեջ ենք: `pre_dec_end`-ը ճիշտ է անում նույնիսկ ZST-ների համար:
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}