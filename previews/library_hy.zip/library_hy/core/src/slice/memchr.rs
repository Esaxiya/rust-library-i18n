// Նախնական իրականացումը վերցված է rust-memchr-ից:
// Հեղինակային իրավունք 2015 Էնդրյու Գալանթ, բլյուս և Նիկոլաս Կոխ

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Օգտագործեք կարճացում:
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Վերադարձնում է `true`, եթե `x` պարունակում է ցանկացած զրոյական բայթ:
///
/// From *Matters Computational*, J. Arndt:
///
/// «Գաղափարն է յուրաքանչյուր բայթից հանել մեկին և այնուհետև փնտրել բայթեր, որտեղ փոխառությունը տարածվում է մինչև առավել նշանակալի
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Վերադարձնում է `x` բայթը համապատասխանող առաջին ցուցիչը `text`-ում:
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Արագ ճանապարհ փոքր կտորների համար
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Ստուգեք մեկ բայթ արժեք `միաժամանակ կարդալով երկու `usize` բառ:
    //
    // `text`-ը բաժանեք երեք մասի
    // - չհավասարակշռված նախնական մասը, նախքան տեքստի առաջին բառի հավասարեցված հասցեն
    // - մարմին, սկան միաժամանակ 2 բառով
    // - վերջին մնացած մասը, <2 բառի չափ

    // որոնել մինչև հավասարեցված սահման
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // որոնել տեքստի մարմինը
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. While-ի նախահաշիվը երաշխավորում է առնվազն 2 * օգտագործման_բայթ հեռավորություն
        // հատի օֆսեթից և վերջից:
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ընդմիջում, եթե կա համապատասխան բայթ
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Գտեք բայթը մարմնի հանգույցի դադարից հետո:
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Վերադարձնում է `x` բայթը համապատասխանող վերջին ցուցիչը `text`-ում:
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Ստուգեք մեկ բայթ արժեք `միաժամանակ կարդալով երկու `usize` բառ:
    //
    // `text`-ը բաժանեք երեք մասի.
    // - չհավասարակշռված պոչը, տեքստի վերջին բառի համապատասխանեցված հասցեն հետո
    // - մարմին, սկանավորված միանգամից 2 բառով,
    // - առաջին մնացած բայթերը, <2 բառի չափ:
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Մենք սա անվանում ենք պարզապես նախածանցի և վերջածանցի երկարությունը ստանալու համար:
        // Մեջտեղում մենք միշտ միանգամից երկու կտոր ենք մշակում:
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `[u8]`-ից `[usize]` փոխակերպելը անվտանգ է, բացառությամբ չափի տարբերությունների, որոնք կարգավորվում են `align_to`-ի կողմից:
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Որոնեք տեքստի մարմնում, համոզվեք, որ մենք չենք հատում min_aligned_offset-ը:
    // օֆսեթը միշտ հավասարեցված է, ուստի `>`-ի պարզապես փորձարկումը բավարար է և խուսափում է հնարավոր արտահոսքից:
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Օֆսեթը սկսվում է len, suffix.len()-ից, քանի դեռ այն ավելի մեծ է, քան
        // min_aligned_offset (prefix.len()) մնացած հեռավորությունը առնվազն 2 * կտոր_բայթ է:
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Ընդմիջում, եթե կա համապատասխան բայթ:
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Գտեք բայթը մինչ մարմնի հանգույցի դադարեցումը:
    text[..offset].iter().rposition(|elt| *elt == x)
}