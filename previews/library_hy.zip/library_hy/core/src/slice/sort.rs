//! Կտորների տեսակավորում
//!
//! Այս մոդուլը պարունակում է տեսակավորման ալգորիթմ, որը հիմնված է Օրսոն Փիթերսի օրինաչափությունը հաղթահարող ենթախմբի վրա, որը հրապարակվել է ՝ <https://github.com/orlp/pdqsort>
//!
//!
//! Անկայուն տեսակավորումը համատեղելի է libcore-ի հետ, քանի որ այն չի հատկացնում հիշողություն, ի տարբերություն մեր տեսակավորման կայուն իրականացման:
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Երբ նետվում է, պատճենները `src`-ից `dest`:
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա օգնող դաս է:
        //          Nessիշտության համար դիմեք դրա օգտագործմանը:
        //          Մասնավորապես, պետք է վստահ լինել, որ `src` և `dst` չեն համընկնում, ինչպես պահանջում է `ptr::copy_nonoverlapping`:
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Առաջին տարրը տեղափոխում է աջ, մինչև որ այն հանդիպի ավելի մեծ կամ հավասար տարրի:
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստորև ներկայացված անապահով գործառնությունները ներառում են ինդեքսավորում առանց պարտադիր ստուգման (`get_unchecked` և `get_unchecked_mut`)
    // և (`ptr::copy_nonoverlapping`) հիշողություն պատճենելը:
    //
    // աԻնդեքսավորումը.
    //  1. Մենք ստուգեցինք զանգվածի չափը>>=2-ով:
    //  2. Ամբողջ ինդեքսավորումը, որը մենք կանենք, միշտ առավելագույնը {0 <= index < len}-ի միջև է:
    //
    // բՀիշողության պատճենումը
    //  1. Մենք ձեռք ենք բերում հղումներ, որոնց երաշխավորված է վավերությունը:
    //  2. Նրանք չեն կարող համընկնել, քանի որ մենք ստանում ենք ցուցիչի տարբերության ցուցանիշների ցուցիչներ:
    //     Այսինքն ՝ `i` և `i-1`:
    //  3. Եթե կտորը պատշաճ կերպով հավասարեցված է, տարրերը ճիշտ են հավասարեցված:
    //     Lerանգահարողի պարտականությունն է համոզվել, որ կտորը պատշաճ կերպով հավասարեցված է:
    //
    // Լրացուցիչ մանրամասների համար տե՛ս մեկնաբանությունները ստորև:
    unsafe {
        // Եթե առաջին երկու տարրերը շարքից դուրս են գալիս ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Կարդացեք առաջին տարրը դեղերով հատկացված փոփոխականի մեջ:
            // Եթե panics-ի հետ համեմատության հետևյալ գործողությունը, `hole`-ը ցած կընկնի և ավտոմատ կերպով տարրը կգրի կտորի մեջ:
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Տեղափոխեք «i»-րդ տարրը մեկ տեղից ձախ ՝ այդպիսով անցքը տեղափոխելով աջ:
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ընկնում է և այդպիսով պատճենում `tmp`-ը `v`-ի մնացած անցքում:
        }
    }
}

/// Վերջին տարրը տեղափոխում է ձախ, մինչև որ այն հանդիպում է ավելի փոքր կամ հավասար տարրի:
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստորև ներկայացված անապահով գործառնությունները ներառում են ինդեքսավորում առանց պարտադիր ստուգման (`get_unchecked` և `get_unchecked_mut`)
    // և (`ptr::copy_nonoverlapping`) հիշողություն պատճենելը:
    //
    // աԻնդեքսավորումը.
    //  1. Մենք ստուգեցինք զանգվածի չափը>>=2-ով:
    //  2. Ամբողջ ինդեքսավորումը, որը մենք կանենք, միշտ առավելագույնը `0 <= index < len-1`-ի միջև է:
    //
    // բՀիշողության պատճենումը
    //  1. Մենք ձեռք ենք բերում հղումներ, որոնց երաշխավորված է վավերությունը:
    //  2. Նրանք չեն կարող համընկնել, քանի որ մենք ստանում ենք ցուցիչի տարբերության ցուցանիշների ցուցիչներ:
    //     Այսինքն ՝ `i` և `i+1`:
    //  3. Եթե կտորը պատշաճ կերպով հավասարեցված է, տարրերը ճիշտ են հավասարեցված:
    //     Lerանգահարողի պարտականությունն է համոզվել, որ կտորը պատշաճ կերպով հավասարեցված է:
    //
    // Լրացուցիչ մանրամասների համար տե՛ս մեկնաբանությունները ստորև:
    unsafe {
        // Եթե վերջին երկու տարրերը շարքից դուրս են գալիս ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Կարդացեք վերջին տարրը դեղերով հատկացված փոփոխականում:
            // Եթե panics-ի հետ համեմատության հետևյալ գործողությունը, `hole`-ը ցած կընկնի և ավտոմատ կերպով տարրը կգրի կտորի մեջ:
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Տեղափոխեք «i»-ի տարրը մեկ տեղից աջ ՝ այդպիսով անցքը տեղափոխելով ձախ:
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ընկնում է և այդպիսով պատճենում `tmp`-ը `v`-ի մնացած անցքում:
        }
    }
}

/// Մասամբ տեսակավորում է մի կտոր ՝ շարքից դուրս եկած մի շարք տարրեր տեղափոխելով շուրջը:
///
/// Վերադարձնում է `true`, եթե կտորը դասավորված է վերջում: Այս գործառույթը *O*(*n*) վատագույն դեպքում է:
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Կողքից դուրս եկած զույգերի առավելագույն քանակը, որոնք տեղափոխվելու են:
    const MAX_STEPS: usize = 5;
    // Եթե կտորը դրանից կարճ է, մի տեղափոխեք ոչ մի տարր:
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք արդեն հստակորեն ստուգեցինք `i < len`-ը:
        // Մեր հետագա բոլոր ինդեքսավորումը միայն `0 <= index < len` տիրույթում է
        unsafe {
            // Գտեք հարակից անսարք տարրերի հաջորդ զույգը:
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ավարտե՞լ ենք
        if i == len {
            return true;
        }

        // Մի տեղափոխեք տարրերը կարճ զանգվածների վրա, ինչը կատարման արժեք ունի:
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Փոխանակեք գտնված տարրերի զույգը: Սա նրանց ճիշտ կարգի է բերում:
        v.swap(i - 1, i);

        // Ավելի փոքր տարրը տեղափոխեք ձախ:
        shift_tail(&mut v[..i], is_less);
        // Ավելի մեծ տարրը տեղափոխեք աջ:
        shift_head(&mut v[i..], is_less);
    }

    // Չհաջողվեց տեսակավորել հատվածը քայլերի սահմանափակ քանակով:
    false
}

/// Տեսակավորում է մի հատված ՝ օգտագործելով ներդիրի տեսակ, որը *O*(*n*^ 2) վատագույն դեպքում է:
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Տեսակավորում է `v`-ը heapsort-ի միջոցով, որը երաշխավորում է *O*(*n*\*log(* n*)) վատագույն դեպքերը:
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Այս երկուական կույտը հարգում է անփոփոխ `parent >= child`-ը:
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node`-ի երեխաներ.
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Ընտրեք ավելի մեծ երեխա:
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Դադարեցրեք, եթե անփոփոխը `node`-ում է:
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Փոխանակեք `node`-ը մեծ երեխայի հետ, մի քայլ իջեք ներքև և շարունակեք մաղել:
            v.swap(node, greater);
            node = greater;
        }
    };

    // Կառուցեք կույտը գծային ժամանակում:
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop-ի առավելագույն տարրերը կույտից:
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` բաժինները `pivot`-ից փոքր տարրերի, որին հաջորդում են `pivot`-ից մեծ կամ հավասար տարրեր:
///
///
/// Վերադարձնում է `pivot`-ից փոքր տարրերի քանակը:
///
/// Բաժանումը կատարվում է բլոկ առ բլոկ ՝ ճյուղավորման գործողությունների գինը նվազագույնի հասցնելու համար:
/// Այս գաղափարը ներկայացված է [BlockQuicksort][pdf] թերթում:
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Տարրերի քանակը բնորոշ բլոկում:
    const BLOCK: usize = 128;

    // Բաժանման ալգորիթմը կրկնում է հետևյալ քայլերը մինչև ավարտը.
    //
    // 1. Հետևեք մի ձախ մասի բլոկին `առանցքի մեծից կամ հավասար տարրեր հայտնաբերելու համար:
    // 2. Հետագծեք աջ մասից մի բլոկ ՝ առանցքից փոքր տարրեր հայտնաբերելու համար:
    // 3. Փոխանակեք որոշված տարրերը ձախ և աջ կողմերի միջև:
    //
    // Մենք պահում ենք հետևյալ փոփոխականները տարրերի բլոկի համար.
    //
    // 1. `block` - Բլոկում տարրերի քանակը:
    // 2. `start` - Սկսեք ցուցիչը `offsets` զանգվածում:
    // 3. `end` - Վերջացրեք ցուցիչը `offsets` զանգվածում:
    // 4. `փոխհատուցումներ, բլոկի ներսում անսարք տարրերի ցուցանիշներ:

    // Ձախ կողմի ընթացիկ բլոկը (`l`-ից `l.add(block_l)`)):
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Ներկայիս բլոկը աջ կողմում (`r.sub(block_r)` to `r`)-ից:
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. .add()-ի փաստաթղթերում հատուկ նշված է, որ `vec.as_ptr().add(vec.len())`-ը միշտ անվտանգ է
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Երբ մենք ստանում ենք VLA, փորձեք ավելի շուտ ստեղծել `min(v.len() երկարության մեկ զանգված, 2 * BLOCK) `
    // քան `BLOCK` երկարության երկու ֆիքսված չափի զանգված: VLA-ները կարող են ավելի արդյունավետ լինել քեշում:

    // Վերադարձնում է տարրերի քանակը `l` (inclusive) և `r` (exclusive) ցուցիչների միջև:
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Մենք ավարտեցինք բլոկ առ բլոկ բաժանարարով, երբ `l` և `r` շատ մոտենան:
        // Դրանից հետո մենք կատարում ենք կարկատման աշխատանքներ `մնացած տարրերը բաժանելու միջև:
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Մնացած տարրերի քանակը (դեռ չի համեմատվում առանցքի հետ):
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Կարգավորեք բլոկի չափերը այնպես, որ ձախ և աջ բլոկները չհամընկնեն, բայց կատարյալ դասավորվեն ՝ մնացած ողջ բացը ծածկելու համար:
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Հետևեք `block_l` տարրերին ձախ կողմից:
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստորև բերված անապահով գործողությունները ներառում են `offset`-ի օգտագործումը:
                //         Ըստ գործառույթի կողմից պահանջվող պայմանների, մենք դրանք բավարարում ենք, քանի որ.
                //         1. `offsets_l` stack-ն է հատկացված, և այդպիսով համարվում է առանձին հատկացված օբյեկտ:
                //         2. `is_less` ֆունկցիան վերադարձնում է `bool`:
                //            `bool`-ի ձուլումը երբեք չի վարարելու `isize`-ը:
                //         3. Մենք երաշխավորել ենք, որ `block_l`-ը կլինի `<= BLOCK`:
                //            Բացի այդ, `end_l`-ը նախապես դրված էր `offsets_`-ի սկզբնական ցուցիչի վրա, որը հայտարարված էր դեղի վրա:
                //            Այսպիսով, մենք գիտենք, որ նույնիսկ վատթարագույն դեպքում (`is_less`-ի բոլոր կանչերը կեղծ են վերադառնում) մենք կլինենք միայն առավելագույնը 1 բայթ:
                //        Այստեղ մեկ այլ անապահով գործողություն է `elem`-ի վերագրումը:
                //        Այնուամենայնիվ, `elem`-ն ի սկզբանե այն ցուցիչի սկզբնական ցուցիչն էր, որը միշտ վավեր է:
                unsafe {
                    // Մասնաճյուղային համեմատություն:
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Հետևեք `block_r` տարրերին աջ կողմից:
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստորև բերված անապահով գործողությունները ներառում են `offset`-ի օգտագործումը:
                //         Ըստ գործառույթի կողմից պահանջվող պայմանների, մենք դրանք բավարարում ենք, քանի որ.
                //         1. `offsets_r` stack-ն է հատկացված, և այդպիսով համարվում է առանձին հատկացված օբյեկտ:
                //         2. `is_less` ֆունկցիան վերադարձնում է `bool`:
                //            `bool`-ի ձուլումը երբեք չի վարարելու `isize`-ը:
                //         3. Մենք երաշխավորել ենք, որ `block_r`-ը կլինի `<= BLOCK`:
                //            Բացի այդ, `end_r`-ը նախապես դրված էր `offsets_`-ի սկզբնական ցուցիչի վրա, որը հայտարարված էր դեղի վրա:
                //            Այսպիսով, մենք գիտենք, որ նույնիսկ ամենավատ դեպքում (`is_less`-ի բոլոր կոչումները վերադառնում են իրական) մենք կլինենք միայն առավելագույնը 1 բայթ:
                //        Այստեղ մեկ այլ անապահով գործողություն է `elem`-ի վերագրումը:
                //        Այնուամենայնիվ, `elem`-ն ի սկզբանե `1 *sizeof(T)`-ն ավարտին էր, և մենք այն նվազեցրեցինք `1* sizeof(T)`-ով `նախքան դրան մուտք գործելը:
                //        Բացի այդ, `block_r`-ը պնդում էր, որ `BLOCK`-ից պակաս է, և `elem`-ը, հետևաբար, առավելագույնը ցույց կտա կտորի սկիզբը:
                unsafe {
                    // Մասնաճյուղային համեմատություն:
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Ձախ և աջ կողմերի միջև անսարք տարրերի քանակը փոխանակելու համար:
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Oneամանակին մեկ զույգ փոխանակելու փոխարեն ավելի արդյունավետ է կատարել ցիկլային փոխարկում:
            // Սա խստորեն համարժեք չէ փոխանակմանը, բայց տալիս է նման արդյունք ՝ օգտագործելով ավելի քիչ հիշողության գործողություններ:
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Ձախ բլոկում անսարք բոլոր տարրերը տեղափոխվել են: Տեղափոխել հաջորդ բլոկ:
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Blockիշտ բլոկում անսարք բոլոր տարրերը տեղափոխվել են: Տեղափոխել նախորդ բլոկ:
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Մնում է առավելագույնը մեկ բլոկ (կամ ձախ կամ աջ) ՝ անսարք տարրերով, որոնք պետք է տեղափոխվեն:
    // Նման մնացած տարրերը կարող են պարզապես տեղափոխվել վերջ ՝ իրենց բլոկի ներսում:
    //

    if start_l < end_l {
        // Ձախ բլոկը մնում է:
        // Իր շարքից դուրս մնացած շարք տարրերը տեղափոխեք ծայրահեղ աջ:
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blockիշտ բլոկը մնում է:
        // Տեղափոխեք իր շարքից դուրս եկած տարրերը ծայրահեղ ձախ:
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ուրիշ ոչինչ անել, մենք ավարտեցինք:
        width(v.as_mut_ptr(), l)
    }
}

/// `v` բաժինները `v[pivot]`-ից փոքր տարրերի, որին հաջորդում են `v[pivot]`-ից մեծ կամ հավասար տարրեր:
///
///
/// Վերադարձնում է մի տուփ ՝
///
/// 1. `v[pivot]`-ից փոքր տարրերի քանակ:
/// 2. Ueիշտ է, եթե `v`-ն արդեն բաժանված էր:
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Տեղադրեք առանցքը կտորի սկզբում:
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Արդյունավետության համար կարդացեք առանցքը բուրգով հատկացված փոփոխականի մեջ:
        // Եթե panics-ի համեմատության հետևյալ գործողությունը, առանցքը ավտոմատ կերպով կգրվի կտորի մեջ:
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Գտեք շարքից դուրս եկած տարրերի առաջին զույգը:
        let mut l = 0;
        let mut r = v.len();

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստորև բերված անապահովությունը ներառում է զանգվածի ինդեքսավորումը:
        // Առաջինի համար. Մենք արդեն սահմանները ստուգում ենք այստեղ `l < r`-ով:
        // Երկրորդի համար. Մենք ի սկզբանե ունենք `l == 0` և `r == v.len()`, և ստուգում ենք այդ `l < r` ինդեքսավորման յուրաքանչյուր գործողության ժամանակ:
        //                     Այստեղից մենք գիտենք, որ `r`-ը պետք է լինի առնվազն `r == l`, որն ապացուցվեց, որ վավեր է առաջինից:
        unsafe {
            // Գտեք առանցքի մեծ կամ հավասար առաջին տարրը:
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Գտեք առանցքի ավելի փոքր վերջին տարրը:
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` դուրս է գալիս շրջանակից և առանցքը (որը բուրգերով հատկացված փոփոխական է) կրկին գրում է այն հատվածի մեջ, որտեղ սկզբնապես եղել է:
        // Այս քայլը կարևոր նշանակություն ունի անվտանգության ապահովման գործում:
        //
    };

    // Տեղադրեք առանցքը երկու բաժանման միջեւ:
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` բաժինները `v[pivot]`-ի հավասար տարրերի, որին հաջորդում են `v[pivot]`-ից մեծ տարրեր:
///
/// Վերադարձնում է առանցքի հավասար տարրերի քանակը:
/// Ենթադրվում է, որ `v`-ը չի պարունակում առանցքից փոքր տարրեր:
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Տեղադրեք առանցքը կտորի սկզբում:
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Արդյունավետության համար կարդացեք առանցքը բուրգով հատկացված փոփոխականի մեջ:
    // Եթե panics-ի համեմատության հետևյալ գործողությունը, առանցքը ավտոմատ կերպով կգրվի կտորի մեջ:
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Այստեղ ցուցիչը վավեր է, քանի որ այն ստացվում է կտորի հղումից:
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Այժմ բաժանեք կտորը:
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստորև բերված անապահովությունը ներառում է զանգվածի ինդեքսավորումը:
        // Առաջինի համար. Մենք արդեն սահմանները ստուգում ենք այստեղ `l < r`-ով:
        // Երկրորդի համար. Մենք ի սկզբանե ունենք `l == 0` և `r == v.len()`, և ստուգում ենք այդ `l < r` ինդեքսավորման յուրաքանչյուր գործողության ժամանակ:
        //                     Այստեղից մենք գիտենք, որ `r`-ը պետք է լինի առնվազն `r == l`, որն ապացուցվեց, որ վավեր է առաջինից:
        unsafe {
            // Գտեք առանցքն ավելի մեծ առաջին տարրը:
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Գտեք առանցքի հավասար վերջին տարրը:
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ավարտե՞լ ենք
            if l >= r {
                break;
            }

            // Փոխանակեք անսարք տարրերի հայտնաբերված զույգը:
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Մենք գտել ենք առանցքի հավասար `l` տարրեր: Ավելացնել 1-ը `առանցքի բուն հաշվարկման համար:
    l + 1

    // `_pivot_guard` դուրս է գալիս շրջանակից և առանցքը (որը բուրգերով հատկացված փոփոխական է) կրկին գրում է այն հատվածի մեջ, որտեղ սկզբնապես եղել է:
    // Այս քայլը կարևոր նշանակություն ունի անվտանգության ապահովման գործում:
}

/// Տարբեր տարրեր է ցրում ՝ փորձելով կոտրել այն օրինաչափությունները, որոնք կարող են անհավասարակշիռ բաժանմունքներ առաջացնել quicksort-ում:
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pորջ Մարսալիայի "Xorshift RNGs" թղթից կեղծ օրինակի թվերի գեներատոր:
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Վերցրեք պատահական թվերի մոդուլը այս համարի վրա:
        // Համարը տեղավորվում է `usize`-ի մեջ, քանի որ `len`-ը `isize::MAX`-ից մեծ չէ:
        let modulus = len.next_power_of_two();

        // Որոշ առանցքային թեկնածուներ կլինեն այս ցուցանիշի մոտակայքում: Եկեք պատահականացնենք դրանք:
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Ստեղծեք պատահական թվերի մոդուլ `len`:
            // Այնուամենայնիվ, ծախսատար գործառնություններից խուսափելու համար մենք նախ այն վերցնում ենք երկու հզորության մոդուլ և այնուհետև նվազում `len`-ով, մինչև այն տեղավորվի `[0, len - 1]` տիրույթի մեջ:
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` երաշխավորված է, որ `2 * len`-ից պակաս կլինի:
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Ընտրում է առանցքը `v`-ում և վերադարձնում է ինդեքսը և `true`-ը, եթե կտորը հավանաբար արդեն տեսակավորված է:
///
/// `v`-ի տարրերը կարող են վերադասավորվել ընթացքի մեջ:
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Նվազագույն երկարությունը միջինից միջինը ընտրելու մեթոդը:
    // Ավելի կարճ կտորներով օգտագործվում է երեք միջին միջոցի մեթոդը:
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Փոխանակման առավելագույն քանակը, որը կարող է իրականացվել այս գործառույթում:
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Երեք ցուցանիշ, որոնց մոտ մենք պատրաստվում ենք առանցք ընտրել:
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Հաշվում է փոխանակումների ընդհանուր քանակը, որոնք մենք պատրաստվում ենք կատարել, ինդեքսները տեսակավորելիս:
    let mut swaps = 0;

    if len >= 8 {
        // Փոխանակում է ինդեքսները այնպես, որ `v[a] <= v[b]`:
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Փոխանակում է ինդեքսները այնպես, որ `v[a] <= v[b] <= v[c]`:
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Գտնում է `v[a - 1], v[a], v[a + 1]`-ի միջինը և պահում ինդեքսը `a`-ի մեջ:
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Գտեք միջիններ `a`, `b` և `c` թաղամասերում:
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Գտեք `a`, `b` և `c`-ների միջինը:
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Իրականացվել է փոխանակման առավելագույն քանակ:
        // Հավանական է, որ կտորը նվազում է կամ հիմնականում իջնում է, ուստի շրջելը, հավանաբար, կօգնի այն ավելի արագ տեսակավորել:
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Տեսակավորում է `v`-ը ռեկուրսիվ կերպով:
///
/// Եթե կտորը սկզբնական զանգվածում ունեցել է նախորդ, ապա այն նշված է որպես `pred`:
///
/// `limit` `heapsort`-ին անցնելուց առաջ թույլատրված անհավասարակշռված միջնապատերի քանակն է:
/// Եթե զրո լինի, այս գործառույթն անմիջապես կանցնի heapsort-ի:
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Մինչև այս երկարության շերտերը տեսակավորվում են ՝ ներդիրների տեսակավորման միջոցով:
    const MAX_INSERTION: usize = 20;

    // Ueիշտ է, եթե վերջին բաժանումը ողջամտորեն հավասարակշռված լիներ:
    let mut was_balanced = true;
    // Ueիշտ է, եթե վերջին բաժանումը չխառնի տարրերը (կտորն արդեն բաժանված էր):
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Շատ կարճ կտորները տեսակավորվում են ՝ օգտագործելով ներմուծման տեսակ:
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Եթե չափազանց շատ առանցքային ընտրություններ են կատարվել, ապա պարզապես վերադառնաք հավաքածուի ՝ `O(n * log(n))` վատագույն դեպքերի երաշխավորելու համար:
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Եթե վերջին միջնորմն անհավասարակշռված էր, փորձեք կոտրել կտորները ՝ խառնելով որոշ տարրեր:
        // Հուսանք `այս անգամ մենք ավելի լավ առանցք կընտրենք:
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Ընտրեք առանցք և փորձեք կռահել, թե արդյո՞ք հատվածն արդեն տեսակավորված է:
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Եթե վերջին բաժանումը պատշաճ կերպով հավասարակշռված էր և չէր խառնվում տարրերը, և եթե առանցքային ընտրությունը կանխատեսում է, որ հատվածը, ամենայն հավանականությամբ, արդեն տեսակավորված է ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Փորձեք նույնականացնել անսարք մի քանի տարրեր և դրանք տեղափոխել ճիշտ դիրքեր:
            // Եթե կտորն ավարտվում է ամբողջովին տեսակավորմամբ, մենք ավարտեցինք:
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Եթե ընտրված առանցքը հավասար է նախորդին, ապա դա կտորի ամենափոքր տարրն է:
        // Կտորը բաժանեք հավասար տարրերի և առանցքից ավելի մեծ տարրերի:
        // Այս գործը սովորաբար հարվածվում է, երբ կտորը պարունակում է բազմաթիվ կրկնօրինակ տարրեր:
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Շարունակեք առանցքից ավելի մեծ տարրերի տեսակավորում:
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Բաժանել կտորը:
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Կտորը բաժանեք `left`, `pivot` և `right`:
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Վերադարձեք ավելի կարճ կողմը միայն ռեկուրսիվ զանգերի ընդհանուր քանակը նվազագույնի հասցնելու և բուրգերի ավելի քիչ տարածք սպառելու համար:
        // Ապա պարզապես շարունակեք ավելի երկար կողմով (սա նման է պոչի հետադարձմանը):
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Տեսակավորում է `v`-ը ՝ օգտագործելով օրինաչափությունը հաղթահարող quicksort, ինչը *O* է (*n*\*log(* n*)) վատագույն դեպքում:
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Տեսակավորումը զրոյական չափի տեսակների համար իմաստալից վարք չունի:
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Սահմանափակեք անհավասարակշռված բաժանմունքների քանակը `floor(log2(len)) + 1`-ով:
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Մինչև այս երկարության կտորների համար դրանք դասավորելը երևի ավելի արագ է:
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ընտրեք առանցք
        let (pivot, _) = choose_pivot(v, is_less);

        // Եթե ընտրված առանցքը հավասար է նախորդին, ապա դա կտորի ամենափոքր տարրն է:
        // Կտորը բաժանեք հավասար տարրերի և առանցքից ավելի մեծ տարրերի:
        // Այս գործը սովորաբար հարվածվում է, երբ կտորը պարունակում է բազմաթիվ կրկնօրինակ տարրեր:
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Եթե մենք անցել ենք մեր ցուցանիշը, ապա մենք լավն ենք:
                if mid > index {
                    return;
                }

                // Հակառակ դեպքում, շարունակեք առանցքայինից մեծ տարրերի տեսակավորումը:
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Կտորը բաժանեք `left`, `pivot` և `right`:
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Եթե mid==ինդեքսը, ապա մենք ավարտեցինք, քանի որ partition()-ը երաշխավորեց, որ կեսից հետո բոլոր տարրերը մեծ են կամ հավասար են կեսին:
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Տեսակավորումը զրոյական չափի տեսակների համար իմաստալից վարք չունի: Չանել ոչինչ.
    } else if index == v.len() - 1 {
        // Գտեք առավելագույն տարրը և տեղադրեք այն զանգվածի վերջին դիրքում:
        // Մենք ազատ ենք այստեղ `unwrap()`-ից օգտվելուց, քանի որ գիտենք, որ v-ն չպետք է դատարկ լինի:
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Գտեք min տարրը և տեղադրեք այն զանգվածի առաջին դիրքում:
        // Մենք ազատ ենք այստեղ `unwrap()`-ից օգտվելուց, քանի որ գիտենք, որ v-ն չպետք է դատարկ լինի:
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}