//! Գործառնություններ ASCII `[u8]`-ի վրա:

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Ստուգում է ՝ արդյոք այս հատվածի բոլոր բայթերը գտնվում են ASCII տիրույթում:
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Ստուգում է, որ երկու կտոր ASCII գործին անզգայուն համընկնում է:
    ///
    /// Նույնը, ինչ `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, բայց առանց ժամանակագրերին հատկացնելու և պատճենելու:
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Այս կտորը վերափոխում է իր ASCII մեծատառի համարժեք տեղում:
    ///
    /// ASCII 'a'-ից 'z' տառերը քարտեզագրվում են 'A'-ից 'Z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Առանց եղածը փոփոխելու ՝ նոր մեծատառ արժեք վերադարձնելու համար օգտագործեք [`to_ascii_uppercase`]:
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Այս կտորը վերափոխում է իր ASCII փոքրատառ համարժեք տեղում:
    ///
    /// ASCII 'A'-ից 'Z' տառերը քարտեզագրվում են 'a'-ից 'z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Առանց եղածը փոփոխելու `նոր փոքր արժեք վերադարձնելու համար օգտագործեք [`to_ascii_lowercase`]:
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Վերադարձնում է `true`-ը, եթե `v` բառի մեջ կա ցանկացած բայթ, ոչ ստանդարտ է (>=128):
/// Snarfed `../str/mod.rs`-ից, որը utf8 վավերացման համար նման բան է անում:
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Օպտիմիզացված ASCII թեստ, որը կօգտագործի միանգամից օգտագործման գործառնություններ ՝ բայտով միանգամյա գործողությունների փոխարեն (հնարավորության դեպքում):
///
/// Այն ալգորիթմը, որն այստեղ օգտագործում ենք, բավականին պարզ է: Եթե `s`-ը շատ կարճ է, մենք պարզապես ստուգում ենք յուրաքանչյուր բայթ և դրանով ավարտվում ենք:Հակառակ դեպքում.
///
/// - Կարդացեք առաջին բառը չհավասարակշռված բեռով:
/// - Ուղղեք ցուցիչը, կարդացեք հետագա բառերը մինչև վերջ ՝ հավասարեցված բեռներով:
/// - Կարդացեք `s`-ի վերջին `usize`-ը `չհամապատասխանված բեռով:
///
/// Եթե այս բեռներից որևէ մեկը առաջացնում է մի բան, որի համար `contains_nonascii` (above) ճիշտ է վերադառնում, ապա մենք գիտենք, որ պատասխանը կեղծ է:
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Եթե բառ առ ժամանակ իրականացումից ոչինչ չէինք շահի, հետ գանք սկալյար օղակի:
    //
    // Մենք դա անում ենք նաև այն ճարտարապետությունների համար, որտեղ `size_of::<usize>()`-ը բավարար հավասարեցում չէ `usize`-ի համար, քանի որ դա տարօրինակ edge դեպք է:
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Մենք միշտ կարդում ենք առաջին բառը ոչ հավասարեցված, ինչը նշանակում է, որ `align_offset` է
    // 0, մենք կարդում ենք նույն արժեքը կրկին հավասարեցված ընթերցման համար:
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Վերևում ենք `len < USIZE_SIZE`-ը:
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Մենք դա ստուգեցինք վերևում, որոշակիորեն անուղղակիորեն:
    // Նշենք, որ `offset_to_aligned`-ը կամ `align_offset` է կամ `USIZE_SIZE`, երկուսն էլ բացահայտ ստուգված են վերևում:
    //
    debug_assert!(offset_to_aligned <= len);

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Word_ptr-ը (պատշաճ կերպով հավասարեցված) օգտագործող ptr է, որն օգտագործում ենք կարդալու համար
    // կտորի միջին կտորը:
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` բայթային ինդեքսն է, որն օգտագործվում է օղակի վերջի ստուգումների համար:
    let mut byte_pos = offset_to_aligned;

    // Paranoia-ն ստուգում է հավասարեցման մասին, քանի որ մենք պատրաստվում ենք կատարել մի շարք չհավասարեցված բեռներ:
    // Գործնականում դա անհնար է, չհաշված `align_offset`-ի սխալը:
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Կարդացեք հետևյալ բառերը մինչև վերջին հավասարեցված բառը ՝ բացառելով վերջին հավասարեցված բառը, որն ավելի ուշ պետք է արվի պոչի ստուգման մեջ, որպեսզի համոզվեք, որ պոչը միշտ առավելագույնը մեկ `usize` է ՝ branch `byte_pos == len` հավելյալից:
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Խելամտություն ստուգեք, որ ընթերցվածը սահմանների մեջ է
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Եվ որ `byte_pos`-ի վերաբերյալ մեր ենթադրությունները պահպանում են:
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք գիտենք, որ `word_ptr`-ը ճիշտ է դասավորված (դրա պատճառով
        // `align_offset`), և մենք գիտենք, որ `word_ptr`-ի և վերջի միջև ունենք բավականաչափ բայթ
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք գիտենք, որ `byte_pos <= len - USIZE_SIZE`, ինչը նշանակում է, որ
        // այս `add`-ից հետո `word_ptr`-ը կլինի առավելագույնը անցյալում:
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Խելամտության ստուգում ՝ համոզվելու համար, որ իսկապես մնացել է միայն մեկ `usize`:
    // Սա պետք է երաշխավորվի մեր օղակի պայմանով:
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա կախված է `len >= USIZE_SIZE`-ից, որը մենք ստուգում ենք հենց սկզբում:
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}