//! Overանրաբեռնված օպերատորներ:
//!
//! Այս traits-ի իրականացումը թույլ է տալիս ծանրաբեռնել որոշակի օպերատորների:
//!
//! Այս traits-ի մի մասը ներմուծվում է prelude-ի կողմից, ուստի դրանք մատչելի են յուրաքանչյուր Rust ծրագրում: Միայն traits-ի կողմից աջակցվող օպերատորները կարող են ծանրաբեռնված լինել:
//! Օրինակ, լրացման (`+`) օպերատորը կարող է ծանրաբեռնված լինել [`Add`] trait-ի միջոցով, բայց քանի որ նշանակման օպերատորը (`=`) չունի օժանդակ trait, դրա իմաստաբանությունը ծանրաբեռնելու տարբերակ չկա:
//! Լրացուցիչ, այս մոդուլը չի տրամադրում որևէ մեխանիզմ նոր օպերատորներ ստեղծելու համար:
//! Եթե անհրաժեշտ է անտրամաբանական ծանրաբեռնվածություն կամ հարմարեցված օպերատորներ, Rust-ի շարահյուսությունը ընդլայնելու համար պետք է նայեք մակրոների կամ կազմողի plugins-ի:
//!
//! traits օպերատորի իրականացումը չպետք է զարմացնի իրենց համապատասխան համատեքստում ՝ հաշվի առնելով դրանց սովորական իմաստները և [operator precedence]:
//! Օրինակ, [`Mul`]-ն իրականացնելիս գործողությունը պետք է որոշակի նմանություն ունենա բազմապատկման հետ (և կիսի սպասվող հատկությունները, ինչպիսիք են ասոցիացիան):
//!
//! Ուշադրություն դարձրեք, որ `&&` և `||` օպերատորները կարճ միացում են, այսինքն, նրանք գնահատում են իրենց երկրորդ օպերանդը միայն այն դեպքում, եթե դա նպաստում է արդյունքին: Քանի որ traits-ի կողմից այս վարքագիծը կիրառելի չէ, `&&`-ը և `||`-ը չեն աջակցվում որպես ծանրաբեռնված օպերատորներ:
//!
//! Օպերատորներից շատերն իրենց օպերանդներն ընդունում են ըստ արժեքի: Ներկառուցված տեսակների ներգրավմամբ ոչ ընդհանուր համատեքստերում դա սովորաբար խնդիր չէ:
//! Այնուամենայնիվ, այս օպերատորների ընդհանուր կոդում օգտագործումը որոշակի ուշադրություն է պահանջում, եթե արժեքները պետք է վերաօգտագործվեն, ի տարբերություն օպերատորներին թույլ տալ սպառել դրանք: Մեկ տարբերակ `երբեմն օգտագործել [`clone`]:
//! Մեկ այլ տարբերակ `ապավինել ներգրավված տեսակներին` հղումների համար լրացուցիչ օպերատորի ներդրումներ ապահովելով:
//! Օրինակ, օգտագործողի կողմից սահմանված `T` տիպի համար, որը ենթադրվում է լրացում ապահովել, հավանաբար լավ գաղափար է, որ և՛ `T`-ը, և՛ `&T`-ն իրականացնեն traits [`Add<T>`][`Add`]-ը և [`Add<&T>`][`Add`]-ն այնպես, որ ընդհանուր կոդը կարող է գրվել առանց ավելորդ կլոնավորման:
//!
//!
//! # Examples
//!
//! Այս օրինակը ստեղծում է `Point` կառուցվածք, որն իրականացնում է [`Add`] և [`Sub`], և այնուհետև ցույց է տալիս երկու `« Point »կետերի ավելացում և հանում:
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Տե՛ս յուրաքանչյուր trait-ի փաստաթղթերը `օրինակի իրականացման համար:
//!
//! [`Fn`], [`FnMut`] և [`FnOnce`] traits-ներն իրականացվում են ըստ տեսակների, որոնք կարող են կանչվել ինչպես գործառույթները: Նշենք, որ [`Fn`]-ը վերցնում է `&self`, [`FnMut`]-ը `&mut self`, իսկ [`FnOnce`]-ը` `self`:
//! Դրանք համապատասխանում են երեք տեսակի մեթոդների, որոնք կարող են վկայակոչվել օրինակով ՝ զանգ առ ցուցակ, զանգ առ փոփոխվող տեղեկանք և զանգ ըստ արժեք:
//! Այս traits-ի ամենատարածված օգտագործումը բարձր մակարդակի գործառույթների սահմանների դեր կատարելն է, որոնք գործառույթները կամ փակումները որպես փաստարկ են վերցնում:
//!
//! [`Fn`]-ը որպես պարամետր ընդունելը.
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`]-ը որպես պարամետր ընդունելը.
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`]-ը որպես պարամետր ընդունելը.
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` սպառում է իր գրաված փոփոխականները, ուստի այն հնարավոր չէ գործարկել մեկից ավելի անգամ
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()`-ին նորից վկայակոչելու փորձը `func`-ի համար `use of moved value` սխալ կհանգեցնի
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` այս պահին այլևս հնարավոր չէ վկայակոչել
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;