/// `?` օպերատորի վարքագիծը հարմարեցնելու համար trait:
///
/// `Try` իրականացնող տեսակն այն տեսակն է, որն ունի այն դիտելու կանոնական եղանակ success/failure երկփորձության տեսանկյունից:
/// Այս trait-ը թույլ է տալիս ինչպես արդյունքի արդյունքից արդյունահանել այդ հաջողության կամ ձախողման արժեքները, այնպես էլ հաջողության կամ ձախողման արժեքից ստեղծել նոր ատյան:
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Այս արժեքի տեսակը, երբ հաջող է դիտվում:
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Այս արժեքի տեսակը, երբ դիտվում է որպես ձախողված:
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Կիրառում է "?" օպերատորը: `Ok(t)`-ի վերադարձը նշանակում է, որ կատարումը պետք է շարունակվի նորմալ, և `?`-ի արդյունքը `t` արժեքն է:
    /// `Err(e)`-ի վերադարձը նշանակում է, որ կատարումը պետք է branch-ը `catch`-ի ներսից ներս պարունակող կամ վերադառնա գործառույթից:
    ///
    /// Եթե `Err(e)` արդյունք է վերադարձվում, `e` արժեքը "wrapped" կլինի կցող շրջանակի վերադարձի տիպում (որն ինքնին պետք է իրականացնի `Try`):
    ///
    /// Մասնավորապես, վերադարձվում է `X::from_error(From::from(e))` արժեքը, որտեղ `X`-ը կցող գործառույթի վերադարձի տեսակն է:
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Փաթաթել սխալի արժեքը ՝ կազմված արդյունքը կառուցելու համար:
    /// Օրինակ, `Result::Err(x)`-ը և `Result::from_error(x)`-ը համարժեք են:
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Փաթաթել OK արժեքը ՝ կազմված արդյունքը կառուցելու համար:
    /// Օրինակ, `Result::Ok(x)`-ը և `Result::from_ok(x)`-ը համարժեք են:
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}