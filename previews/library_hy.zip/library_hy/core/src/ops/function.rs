/// Callանգի օպերատորի այն տարբերակը, որը տանում է անփոփոխ ստացող:
///
/// `Fn`-ի դեպքերը կարելի է անվանել բազմիցս ՝ առանց փոփոխվող վիճակի:
///
/// *Այս trait (`Fn`)-ը չպետք է շփոթել [function pointers] (`fn`)-ի հետ:*
///
/// `Fn` իրականացվում է ավտոմատ կերպով ՝ փակումների միջոցով, որոնք միայն անփոփոխ հղումներ են կատարում գրավված փոփոխականներին կամ ընդհանրապես չեն գրավում որևէ բան, ինչպես նաև (safe) [function pointers] (որոշ նախազգուշացումներով, տես մանրամասների համար դրանց փաստաթղթերը):
///
/// Բացի այդ, ցանկացած տեսակի `F`, որն իրականացնում է `Fn`, `&F`-ն իրականացնում է նաև `Fn`:
///
/// Քանի որ և՛ [`FnMut`]-ը, և՛ [`FnOnce`]-ը `Fn`-ի գերհամաձայնագիր են, `Fn`-ի ցանկացած օրինակ կարող է օգտագործվել որպես պարամետր, որտեղ [`FnMut`] կամ [`FnOnce`] է սպասվում:
///
/// Օգտագործեք `Fn`-ը որպես կապանք, երբ ուզում եք ընդունել ֆունկցիայի նման տիպի պարամետր և անհրաժեշտ է այն անվանել բազմիցս և առանց փոփոխվող վիճակի (օրինակ ՝ միաժամանակ զանգահարելիս):
/// Եթե նման խիստ պահանջների կարիք չունեք, օգտագործեք [`FnMut`] կամ [`FnOnce`] որպես սահմաններ:
///
/// Տե՛ս [chapter on closures in *The Rust Programming Language*][book]-ը այս թեմայի վերաբերյալ լրացուցիչ տեղեկություններ ստանալու համար:
///
/// Հատկանշական է նաև հատուկ շարահյուսությունը `Fn` traits-ի համար (օրինակ
/// `Fn(usize, bool) -> օգտագործել »): Սրա տեխնիկական մանրամասներով հետաքրքրվողները կարող են դիմել [the relevant section in the *Rustonomicon*][nomicon]:
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Callանգահարելով փակումը
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Օգտագործելով `Fn` պարամետր
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // որպեսզի regex-ը կարողանա ապավինել այդ `&str: !FnMut`-ին
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Կատարում է զանգի գործողություն:
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Callանգի օպերատորի այն տարբերակը, որը տանում է անփոփոխ ստացող:
///
/// `FnMut`-ի դեպքերը կարելի է անվանել բազմիցս և կարող են փոփոխական վիճակ ունենալ:
///
/// `FnMut` իրականացվում է ավտոմատ կերպով այն փակումների միջոցով, որոնք տանում են փոփոխվող հղումներ գրավվող փոփոխականներին, ինչպես նաև [`Fn`] իրականացնող բոլոր տիպերին, օրինակ ՝ (safe) [function pointers] (քանի որ `FnMut`-ը [`Fn`]-ի գերբարակ է):
/// Բացի այդ, ցանկացած տեսակի `F`, որն իրականացնում է `FnMut`, `&mut F`-ն իրականացնում է նաև `FnMut`:
///
/// Քանի որ [`FnOnce`]-ը `FnMut`-ի գերբարակ է, `FnMut`-ի ցանկացած օրինակ կարող է օգտագործվել այնտեղ, որտեղ սպասվում է [`FnOnce`], և քանի որ [`Fn`]-ը `FnMut`-ի ենթաբազմություն է, [`Fn`]-ի ցանկացած օրինակ կարող է օգտագործվել այնտեղ, որտեղ սպասվում է `FnMut`:
///
/// Օգտագործեք `FnMut`-ը որպես կապակցված, երբ ուզում եք ընդունել ֆունկցիայի նման տիպի պարամետր և պետք է այն մի քանի անգամ զանգահարել ՝ միաժամանակ թույլ տալով, որ այն փոխի վիճակը:
/// Եթե չեք ցանկանում, որ պարամետրը փոխի վիճակը, օգտագործեք [`Fn`]-ը որպես կապակցված;եթե անհրաժեշտ չէ այն բազմիցս զանգահարել, օգտագործեք [`FnOnce`]:
///
/// Տե՛ս [chapter on closures in *The Rust Programming Language*][book]-ը այս թեմայի վերաբերյալ լրացուցիչ տեղեկություններ ստանալու համար:
///
/// Հատկանշական է նաև հատուկ շարահյուսությունը `Fn` traits-ի համար (օրինակ
/// `Fn(usize, bool) -> օգտագործել »): Սրա տեխնիկական մանրամասներով հետաքրքրվողները կարող են դիմել [the relevant section in the *Rustonomicon*][nomicon]:
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Փոխադարձաբար գրավող փակումը կոչելը
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Օգտագործելով `FnMut` պարամետր
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // որպեսզի regex-ը կարողանա ապավինել այդ `&str: !FnMut`-ին
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Կատարում է զանգի գործողություն:
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Callանգի օպերատորի այն տարբերակը, որը տանում է ենթաարժեքային ընդունիչ:
///
/// `FnOnce`-ի դեպքեր կարելի է զանգահարել, բայց կարող է բազմիցս չկանչվել: Այս պատճառով, եթե տիպի մասին հայտնի է միայն այն, որ այն `FnOnce` է իրականացնում, այն կարող է կանչվել միայն մեկ անգամ:
///
/// `FnOnce` իրականացվում է ավտոմատ կերպով այն փակումների միջոցով, որոնք կարող են սպառել գրավված փոփոխականները, ինչպես նաև բոլոր տիպերը, որոնք իրականացնում են [`FnMut`], օրինակ ՝ (safe) [function pointers] (քանի որ `FnOnce`-ը [`FnMut`]-ի գերբարակ է):
///
///
/// Քանի որ և՛ [`Fn`]-ը, և՛ [`FnMut`]-ը `FnOnce`-ի ենթատեսակ են, [`Fn`]-ի կամ [`FnMut`]-ի ցանկացած օրինակ կարող է օգտագործվել այնտեղ, որտեղ `FnOnce` է սպասվում:
///
/// Օգտագործեք `FnOnce`-ը որպես կապակցված, երբ ուզում եք ընդունել ֆունկցիայի նման տիպի պարամետր և անհրաժեշտ է միայն մեկ անգամ զանգահարել այն:
/// Եթե Ձեզ անհրաժեշտ է պարբերաբար զանգահարել պարամետրը, օգտագործեք [`FnMut`]-ը որպես կապակցված;եթե դա ձեզ նույնպես պետք է վիճակը չփոփոխելու համար, օգտագործեք [`Fn`]:
///
/// Տե՛ս [chapter on closures in *The Rust Programming Language*][book]-ը այս թեմայի վերաբերյալ լրացուցիչ տեղեկություններ ստանալու համար:
///
/// Հատկանշական է նաև հատուկ շարահյուսությունը `Fn` traits-ի համար (օրինակ
/// `Fn(usize, bool) -> օգտագործել »): Սրա տեխնիկական մանրամասներով հետաքրքրվողները կարող են դիմել [the relevant section in the *Rustonomicon*][nomicon]:
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Օգտագործելով `FnOnce` պարամետր
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` սպառում է իր գրաված փոփոխականները, ուստի այն հնարավոր չէ գործարկել մեկից ավելի անգամ:
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()`-ին նորից վկայակոչելու փորձը `func`-ի համար `use of moved value` սխալ կհանգեցնի:
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` այս պահին այլևս հնարավոր չէ վկայակոչել
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // որպեսզի regex-ը կարողանա ապավինել այդ `&str: !FnMut`-ին
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Returnedանգի օպերատորից հետո վերադարձված տեսակը:
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Կատարում է զանգի գործողություն:
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}