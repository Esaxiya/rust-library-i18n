use crate::fmt;
use crate::hash::Hash;

/// (`..`) անսահմանափակ տիրույթ:
///
/// `RangeFull` հիմնականում օգտագործվում է որպես [slicing index], դրա սղագրությունը `..` է:
/// Այն չի կարող ծառայել որպես [`Iterator`], քանի որ չունի ելակետ:
///
/// # Examples
///
/// `..` շարահյուսությունը `RangeFull` է.
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// Այն չունի [`IntoIterator`] ներդրում, ուստի այն ուղղակիորեն չեք կարող օգտագործել `for` հանգույցում:
/// Սա չի կազմելու.
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// Օգտագործվելով որպես [slicing index], `RangeFull`-ն արտադրում է ամբողջական զանգվածը որպես կտոր:
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // Սա `RangeFull`-ն է
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// (half-open) տիրույթը սահմանափակվում էր ներառյալ (`start..end`)-ից ներքև և բացառապես վերևում:
///
///
/// `start..end` տիրույթը պարունակում է `start <= x < end`-ի բոլոր արժեքները:
/// Դատարկ է, եթե `start >= end`:
///
/// # Examples
///
/// `start..end` շարահյուսությունը `Range` է.
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // Սա `Range` է
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // ոչ Պատճենել-տե՛ս #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) տիրույթի ստորին սահմանը:
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// (exclusive) տիրույթի վերին սահմանը:
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// Վերադարձնում է `true`, եթե `item` պարունակվում է տիրույթում:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// Վերադարձնում է `true`, եթե տիրույթը ոչ մի տարր չի պարունակում:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// Միջակայքը դատարկ է, եթե կողմերից յուրաքանչյուրն անհամեմատելի է.
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// Մի շարք ընդգրկված է միայն ներառյալ (`start..`)-ից ցածր:
///
/// `RangeFrom` `start..` պարունակում է `x >= start`-ի բոլոր արժեքները:
///
/// *Նշում*. [`Iterator`] իրականացման մեջ հեղեղումը (երբ պարունակվող տվյալների տեսակը հասնում է իր թվային սահմանին) թույլատրվում է panic, փաթաթել կամ հագեցնել:
/// Այս վարքագիծը որոշվում է [`Step`] trait-ի ներդրմամբ:
/// Պարզունակ ամբողջ թվերի համար սա հետևում է նորմալ կանոններին և հարգում է վարարման ստուգումների պրոֆիլը (panic կարգաբերում, փաթեթավորում թողարկումով):
/// Նկատի ունեցեք նաև, որ գերհեղեղը տեղի է ունենում ավելի շուտ, քան կարող եք ենթադրել. Գերհեղեղը տեղի է ունենում `next` զանգի ժամանակ, որը տալիս է առավելագույն արժեքը, քանի որ հաջորդ արժեքը տալու համար սահմանը պետք է դրվի վիճակի:
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` շարահյուսությունը `RangeFrom` է.
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // Սա `RangeFrom` է
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // ոչ Պատճենել-տե՛ս #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) տիրույթի ստորին սահմանը:
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// Վերադարձնում է `true`, եթե `item` պարունակվում է տիրույթում:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// Մի շարք սահմանափակվում է բացառապես (`..end`)-ից վեր:
///
/// `RangeTo` `..end` պարունակում է `x < end`-ի բոլոր արժեքները:
/// Այն չի կարող ծառայել որպես [`Iterator`], քանի որ չունի ելակետ:
///
/// # Examples
///
/// `..end` շարահյուսությունը `RangeTo` է.
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// Այն չունի [`IntoIterator`] ներդրում, ուստի այն ուղղակիորեն չեք կարող օգտագործել `for` հանգույցում:
/// Սա չի կազմելու.
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// Երբ օգտագործվում է որպես [slicing index], `RangeTo`-ն արտադրում է զանգվածի բոլոր տարրերի կտորը մինչև `end`-ով նշված ցուցանիշը:
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // Սա `RangeTo` է
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// (exclusive) տիրույթի վերին սահմանը:
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// Վերադարձնում է `true`, եթե `item` պարունակվում է տիրույթում:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// Մի շարք, ներառյալ (`start..=end`)-ից ներքև և վեր:
///
/// `RangeInclusive` `start..=end` պարունակում է `x >= start` և `x <= end` ունեցող բոլոր արժեքները: Դատարկ է, բացառությամբ `start <= end`-ի:
///
/// Այս կրկնիչը [fused] է, բայց կրկնությունն ավարտելուց հետո `start`-ի և `end`-ի հատուկ արժեքները **անորոշ են**, բացի այդ [`.is_empty()`]-ը կվերադարձնի `true`, երբ այլևս արժեքներ չստեղծվեն:
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` շարահյուսությունը `RangeInclusive` է.
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // Սա `RangeInclusive` է
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // ոչ Պատճենել-տե՛ս #27186
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // Նկատի ունեցեք, որ այստեղ դաշտերը հանրային չեն, որպեսզի թույլ տրվի փոխել ներկայացուցչությունը future-ում;մասնավորապես, չնայած մենք կարող էինք հավանականորեն բացահայտել start/end-ը, դրանք փոփոխելը առանց (future/current) մասնավոր դաշտերը փոխելու կարող է հանգեցնել սխալ վարքի, ուստի մենք չենք ցանկանում աջակցել այդ ռեժիմին:
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // Այս ոլորտն է.
    //  - `false` շինարարության ժամանակ
    //  - `false` երբ կրկնությունը տալիս է մի տարր, և կրկնիչը չի սպառվում
    //  - `true` երբ կրկնությունն օգտագործվել է կրկնիչը սպառելու համար
    //
    // Սա պահանջվում է PartialEq-ին և Hash-ին աջակցելու համար `առանց PartialOrd-ի պարտավորվածության կամ մասնագիտացման:
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// Ստեղծում է նոր ներառական շրջանակ: Համարժեք է `start..=end` գրելուն:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// Վերադարձնում է (inclusive) տիրույթի ստորին սահմանը:
    ///
    /// Կրկնման համար ներառական տիրույթ օգտագործելիս `start()` և [`end()`] արժեքներն անորոշ են կրկնության ավարտից հետո:
    /// Որոշելու համար, թե արդյոք ներառական տիրույթը դատարկ է, օգտագործեք [`is_empty()`] մեթոդը `start() > end()`-ը համեմատելու փոխարեն:
    ///
    /// Note: Այս մեթոդով վերադարձված արժեքը չի նշվում, երբ միջակայքն անցնում է ուժասպառության:
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// Վերադարձնում է (inclusive) տիրույթի վերին սահմանը:
    ///
    /// Կրկնման համար ներառական տիրույթ օգտագործելիս [`start()`] և `end()` արժեքներն անորոշ են կրկնության ավարտից հետո:
    /// Որոշելու համար, թե արդյոք ներառական տիրույթը դատարկ է, օգտագործեք [`is_empty()`] մեթոդը `start() > end()`-ը համեմատելու փոխարեն:
    ///
    /// Note: Այս մեթոդով վերադարձված արժեքը չի նշվում, երբ միջակայքն անցնում է ուժասպառության:
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// Քայքայում է `RangeInclusive`-ը (ներքևի սահման, վերև (inclusive) կապակցված):
    ///
    /// Note: Այս մեթոդով վերադարձված արժեքը չի նշվում, երբ միջակայքն անցնում է ուժասպառության:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// Փոխակերպվում է բացառիկ `Range`-ի `SliceIndex` իրականացման համար:
    /// Lerանգահարողը պատասխանատու է `end == usize::MAX`-ի հետ գործ ունենալու համար:
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // Եթե մենք ուժասպառ չենք եղել, մենք ուզում ենք պարզապես կտրել `start..end + 1`:
        // Եթե մենք ուժասպառ ենք եղել, ապա `end + 1..end + 1`-ի կտոր կտորը մեզ տալիս է դատարկ միջակայք, որը դեռ ենթակա է սահմանների ստուգումների այդ վերջնակետի համար:
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// Վերադարձնում է `true`, եթե `item` պարունակվում է տիրույթում:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// Կրկնությունն ավարտելուց հետո այս մեթոդը միշտ վերադարձնում է `false`:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // Fieldշգրիտ դաշտի արժեքներն այստեղ անորոշ են
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// Վերադարձնում է `true`, եթե տիրույթը ոչ մի տարր չի պարունակում:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// Միջակայքը դատարկ է, եթե կողմերից յուրաքանչյուրն անհամեմատելի է.
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// Այս մեթոդը վերադարձնում է `true` ՝ կրկնությունն ավարտելուց հետո.
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // Fieldշգրիտ դաշտի արժեքներն այստեղ անորոշ են
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// Մի շարք ընդգրկված է միայն ներառյալ (`..=end`)-ից բարձր:
///
/// `RangeToInclusive` `..=end` պարունակում է `x <= end`-ի բոլոր արժեքները:
/// Այն չի կարող ծառայել որպես [`Iterator`], քանի որ չունի ելակետ:
///
/// # Examples
///
/// `..=end` շարահյուսությունը `RangeToInclusive` է.
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// Այն չունի [`IntoIterator`] ներդրում, ուստի այն ուղղակիորեն չեք կարող օգտագործել `for` հանգույցում: Սա չի կազմելու.
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// Երբ օգտագործվում է որպես [slicing index], `RangeToInclusive`-ն արտադրում է զանգվածի բոլոր տարրերի կտորը մինչև `end`-ի կողմից նշված ինդեքսը ներառյալ:
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // Սա `RangeToInclusive` է
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// (inclusive) տիրույթի վերին սահմանը
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// Վերադարձնում է `true`, եթե `item` պարունակվում է տիրույթում:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>չի կարող ազդել From-ից <RangeTo<Idx>> քանի որ ցածր հոսքը հնարավոր կլինի (..0).into()-ի դեպքում
//

/// Մի շարք ստեղների վերջնակետ:
///
/// # Examples
///
/// `Bound`s-ը ընդգրկույթի վերջնակետեր են.
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// Օգտագործելով «Bound`s»-ի մի տուփ ՝ որպես փաստարկ [`BTreeMap::range`]-ին:
/// Նշենք, որ շատ դեպքերում փոխարենը ավելի լավ է օգտագործել տիրույթի շարահյուսությունը (`1..5`):
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// Ներառական պարտավորված:
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// Բացառիկ պարտավորված:
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// Անսահման վերջնակետ: Նշում է, որ այս ուղղությամբ կապված չկա:
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// Փոխարկվում է `&Bound<T>`-ից `Bound<&T>`:
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// Փոխարկվում է `&mut Bound<T>`-ից `Bound<&T>`:
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// Քարտեզագրեք `Bound<&T>`-ից `Bound<T>` ՝ կլոնավորելով կապվածի պարունակությունը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` իրականացվում է Rust-ի ներկառուցված տեսականու տեսակների կողմից, որոնք արտադրվում են `..`, `a..`, `..b`, `..=c`, `d..e` կամ `f..=g` տիրույթների շարահյուսության միջոցով:
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// Սկսեք ինդեքսը պարտավորված:
    ///
    /// Վերադարձնում է մեկնարկային արժեքը որպես `Bound`:
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// Վերջը ցուցանիշը պարտավորված է:
    ///
    /// Վերադարձնում է վերջնական արժեքը որպես `Bound`:
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// Վերադարձնում է `true`, եթե `item` պարունակվում է տիրույթում:
    ///
    /// # Examples
    ///
    /// ```
    /// պնդեք! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// պնդեք! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // Երբ կրկնիչը սպառվում է, մենք սովորաբար ունենում ենք start==end, բայց ուզում ենք, որ տիրույթը դատարկ ստացվի ՝ ոչինչ չպարունակելով:
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}