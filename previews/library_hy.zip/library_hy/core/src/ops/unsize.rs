use crate::marker::Unsize;

/// Trait, որը ցույց է տալիս, որ սա ցուցիչի կամ փաթաթված է մեկի համար, որտեղ չափափոխումը կարող է կատարվել միավորի վրա:
///
/// Տեսեք [DST coercion RFC][dst-coerce] և [the nomicon entry on coercion][nomicon-coerce] լրացուցիչ մանրամասների համար:
///
/// Ներկառուցված ցուցիչների տեսակների համար `T`-ի ցուցիչները կստիպեն `U` ցուցիչներին, եթե `T: Unsize<U>`-ը բարակ ցուցիչից ճարպ ցուցիչ վերափոխելով:
///
/// Սովորական տիպերի համար այստեղ հարկադրանքն աշխատում է `Foo<T>`-ին `Foo<U>`-ով պարտադրելով, եթե առկա է `CoerceUnsized<Foo<U>> for Foo<T>`-ի ազդակ:
/// Նման ազդանշան կարող է գրվել միայն այն դեպքում, երբ `Foo<T>`-ն ունի միայն մեկ ոչ ֆանտոմտվային դաշտ, որը ներառում է `T`:
/// Եթե այդ դաշտի տեսակը `Bar<T>` է, ապա `CoerceUnsized<Bar<U>> for Bar<T>`-ի իրականացում պետք է գոյություն ունենա:
/// Պարտադրանքն աշխատելու է `Bar<T>` դաշտը `Bar<U>`-ի պարտադրելով և `Foo<T>`-ից մնացած դաշտերը լրացնելով `Foo<U>` ստեղծելու համար:
/// Սա արդյունավետորեն կփոխանցվի ցուցիչի դաշտ և կստիպի դրան:
///
/// Ընդհանրապես, խելացի ցուցիչների համար դուք կիրականացնեք `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, կամընտիր `?Sized`-ով, որը կապված է հենց `T`-ի հետ:
/// Փաթաթանման տեսակների համար, որոնք ուղղակիորեն ներկառուցում են `T`, ինչպես `Cell<T>` և `RefCell<T>`, դուք կարող եք ուղղակիորեն իրականացնել `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`:
///
/// Սա թույլ կտա աշխատել `Cell<Box<T>>`-ի նման տիպի պարտադրանքները:
///
/// [`Unsize`][unsize] օգտագործվում է այն տիպերը նշելու համար, որոնք կարող են պարտադրվել DST-ներին, եթե ցուցիչների ետևում են: Այն ավտոմատ կերպով իրականացվում է կազմողի կողմից:
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Սա օգտագործվում է օբյեկտի անվտանգության համար ՝ ստուգելու համար, թե արդյոք մեթոդի ստացողի տեսակը կարող է ուղարկվել:
///
/// trait-ի իրականացման օրինակ.
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}