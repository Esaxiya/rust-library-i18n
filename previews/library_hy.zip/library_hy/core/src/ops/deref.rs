/// Օգտագործվում է անուղղակի վերհղման գործողությունների համար, ինչպիսին է `*v`-ը:
///
/// Բացի այն, որ օգտագործվում է անփոփոխ համատեքստերում (unary) `*` օպերատորի հետ բացահայտ փոխադրման գործառույթների համար, `Deref`-ը նաև շատ դեպքերում օգտագործվում է անուղղակիորեն կազմողի կողմից:
/// Այս մեխանիզմը կոչվում է ['`Deref` coercion'][more]:
/// Փոփոխական ենթատեքստերում օգտագործվում է [`DerefMut`]:
///
/// `Deref`-ի ներդրումը խելացի ցուցիչների համար հարմար է դարձնում դրանց ետևում գտնվող տվյալների հասանելիությունը, այդ իսկ պատճառով նրանք իրականացնում են `Deref`:
/// Մյուս կողմից, `Deref` և [`DerefMut`]-ի վերաբերյալ կանոնները մշակվել են հատուկ խելացի ցուցիչները տեղավորելու համար:
/// Այդ պատճառով **«Deref»-ը պետք է իրականացվի միայն խելացի ցուցիչների համար**՝ շփոթությունից խուսափելու համար:
///
/// Նմանատիպ պատճառներով,**այս trait-ը երբեք չպետք է ձախողվի**: Վերահղման ընթացքում ձախողումը կարող է չափազանց շփոթեցնող լինել, երբ անուղղակիորեն `Deref` է կանչվում:
///
/// # Ավելին `Deref` հարկադրանքի մասին
///
/// Եթե `T`-ն իրականացնում է `Deref<Target = U>`, և `x`-ը `T` տիպի արժեք է, ապա.
///
/// * Փոփոխական ենթատեքստերում `*x` (որտեղ `T` ոչ հղում է, ոչ էլ հում ցուցիչ) համարժեք է `* Deref::deref(&x)`-ին:
/// * `&T` տիպի արժեքները պարտադրվում են `&U` տիպի արժեքներին
/// * `T` անուղղակիորեն իրականացնում է `U` տիպի (immutable) բոլոր մեթոդները:
///
/// Լրացուցիչ մանրամասների համար այցելեք [the chapter in *The Rust Programming Language*][book], ինչպես նաև [the dereference operator][ref-deref-op], [method resolution] և [type coercions] էջերի տեղեկատու բաժինները:
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Կառուցվածք մեկ դաշտով, որը մատչելի է կառուցվածքի վերանայումով:
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Վերահղումից հետո ստացված տեսակը:
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Հանում է արժեքը:
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Օգտագործվում է անփոփոխ փոխանցման գործառույթների համար, ինչպես `*v = 1;`-ում:
///
/// Բացի այն, որ օգտագործվում է փոփոխական համատեքստերում (unary) `*` օպերատորի հետ բացահայտ փոխադրման գործառնությունների համար, շատ դեպքերում `DerefMut`-ը նաև անուղղակիորեն օգտագործվում է կազմողի կողմից:
/// Այս մեխանիզմը կոչվում է ['`Deref` coercion'][more]:
/// Անփոփոխ համատեքստերում օգտագործվում է [`Deref`]:
///
/// `DerefMut`-ի ներդրումը խելացի ցուցիչների համար հարմար է դարձնում դրանց հիմքում ընկած տվյալների մուտացումը, այդ իսկ պատճառով նրանք իրականացնում են `DerefMut`:
/// Մյուս կողմից, [`Deref`] և `DerefMut`-ի վերաբերյալ կանոնները մշակվել են հատուկ խելացի ցուցիչները տեղավորելու համար:
/// Այդ պատճառով **«DerefMut»-ը պետք է իրականացվի միայն խելացի ցուցիչների համար**՝ շփոթությունից խուսափելու համար:
///
/// Նմանատիպ պատճառներով,**այս trait-ը երբեք չպետք է ձախողվի**: Վերահղման ընթացքում ձախողումը կարող է չափազանց շփոթեցնող լինել, երբ անուղղակիորեն `DerefMut` է կանչվում:
///
/// # Ավելին `Deref` հարկադրանքի մասին
///
/// Եթե `T`-ն իրականացնում է `DerefMut<Target = U>`, և `x`-ը `T` տիպի արժեք է, ապա.
///
/// * Փոփոխական ենթատեքստերում `*x`-ը (որտեղ `T`-ը ոչ հղում է, ոչ էլ հում ցուցիչ) համարժեք է `* DerefMut::deref_mut(&mut x)`-ին:
/// * `&mut T` տիպի արժեքները պարտադրվում են `&mut U` տիպի արժեքներին
/// * `T` անուղղակիորեն իրականացնում է `U` տիպի (mutable) բոլոր մեթոդները:
///
/// Լրացուցիչ մանրամասների համար այցելեք [the chapter in *The Rust Programming Language*][book], ինչպես նաև [the dereference operator][ref-deref-op], [method resolution] և [type coercions] էջերի տեղեկատու բաժինները:
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Մի կառուցվածք, որը ունի մեկ դաշտ, որը փոփոխվում է կառուցվածքը չհրապարակելու միջոցով:
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Անխախտորեն հետ կանչում են արժեքը:
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Նշում է, որ կառուցվածքը կարող է օգտագործվել որպես մեթոդ ստացող, առանց `arbitrary_self_types` հատկության:
///
/// Սա իրականացվում է stdlib ցուցիչի այնպիսի տեսակների միջոցով, ինչպիսիք են `Box<T>`, `Rc<T>`, `&T` և `Pin<P>`:
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}