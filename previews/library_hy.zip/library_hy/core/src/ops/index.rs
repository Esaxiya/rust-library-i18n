/// Օգտագործվում է անփոփոխ համատեքստերում (`container[index]`) գործառնությունների ինդեքսավորման համար:
///
/// `container[index]` իրականում շարահյուսական շաքար է `*container.index(index)`-ի համար, բայց միայն այն դեպքում, երբ օգտագործվում է որպես անփոփոխ արժեք:
/// Եթե փոփոխական արժեք է պահանջվում, փոխարենը օգտագործվում է [`IndexMut`]:
/// Սա թույլ է տալիս այնպիսի հաճելի բաներ, ինչպիսին է `let value = v[index]`-ը, եթե `value`-ի տեսակն իրականացնում է [`Copy`]:
///
/// # Examples
///
/// Հաջորդ օրինակը `Index`-ն իրականացնում է միայն կարդալու համար `NucleotideCount` տարայի վրա ՝ հնարավորություն տալով անհատական հաշվարկները ստանալ ինդեքսի շարահյուսությամբ:
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Վերադարձված տեսակը ինդեքսավորումից հետո:
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Կատարում է ինդեքսավորման (`container[index]`) գործողությունը:
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Օգտագործվում է փոփոխական համատեքստերում (`container[index]`) գործառնությունների ինդեքսավորման համար:
///
/// `container[index]` իրականում շարահյուսական շաքար է `*container.index_mut(index)`-ի համար, բայց միայն այն դեպքում, երբ օգտագործվում է որպես փոփոխական արժեք:
/// Եթե անփոփոխ արժեք է պահանջվում, փոխարենը օգտագործվում է [`Index`] trait:
/// Սա թույլ է տալիս այնպիսի գեղեցիկ բաներ, ինչպիսիք են `v[index] = value`-ը:
///
/// # Examples
///
/// `Balance` կառուցվածքի շատ պարզ իրականացում, որն ունի երկու կողմ, որտեղ յուրաքանչյուրը կարող է ինդեքսավորվել փոփոխական և անփոփոխ:
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Այս դեպքում `balance[Side::Right]`-ը շաքար է `*balance.index(Side::Right)`-ի համար, քանի որ մենք ընդամենը* ենք կարդում * `balance[Side::Right]`, այլ ոչ թե գրում այն:
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Այնուամենայնիվ, այս դեպքում `balance[Side::Left]`-ը շաքար է `*balance.index_mut(Side::Left)`-ի համար, քանի որ մենք գրում ենք `balance[Side::Left]`:
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Կատարում է փոփոխվող ինդեքսավորման (`container[index]`) գործողությունը:
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}