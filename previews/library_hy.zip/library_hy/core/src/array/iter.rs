//! Որոշում է `IntoIter`-ին պատկանող կրկնիչը զանգվածների համար:

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] կրկնվող կրկնվող արժեք:
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Սա այն զանգվածն է, որի վրա մենք կրկնում ենք:
    ///
    /// `i` ինդեքսով տարրեր, որտեղ `alive.start <= i < alive.end` դեռ չի բերվել և վանդակի վավեր գրառումներ են:
    /// `i < alive.start` կամ `i >= alive.end` ցուցիչներով տարրերն արդեն բերվել են, և դրանց մուտքն այլևս չպետք է լինի: Այդ մեռած տարրերը կարող են նույնիսկ բոլորովին ոչ նախնականացված վիճակում լինել:
    ///
    ///
    /// Այսպիսով, անփոփոխներն են.
    /// - `data[alive]` կենդանի է (այսինքն պարունակում է վավեր տարրեր)
    /// - `data[..alive.start]` և `data[alive.end..]`-ը մեռած են (այսինքն ՝ տարրերն արդեն կարդացել են և դրանք այլևս չպետք է դիպչել):
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data`-ի այն տարրերը, որոնք դեռ չեն բերվել:
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Տրված `array`-ի վրա ստեղծում է նոր կրկնիչ:
    ///
    /// *Նշում*. Այս մեթոդը կարող է մաշված լինել future-ում ՝ [`IntoIterator` is implemented for arrays][array-into-iter]-ից հետո:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value`-ի տեսակն այստեղ `i32` է ՝ `&i32`-ի փոխարեն
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Այստեղ տրանսմուտը իրականում անվտանգ է: `MaybeUninit`-ի փաստաթղթերը
        // promise:
        //
        // > `MaybeUninit<T>` երաշխավորված է ունենալ նույն չափը և հավասարեցումը
        // > ինչպես `T`:
        //
        // Փաստաթղթերը ցույց են տալիս անգամ փոխարկիչ `MaybeUninit<T>` զանգվածից `T` զանգված:
        //
        //
        // Դրանով այս նախնականացումը բավարարում է անփոփոխներին:

        // FIXME(LukasKalbertodt): իրականում օգտագործեք `mem::transmute` այստեղ, հենց որ այն աշխատի const generics-ի հետ.
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Մինչ այդ, մենք կարող ենք օգտագործել `mem::transmute_copy` ՝ բիթային օրինակ ստեղծելու համար որպես այլ տեսակ, ապա մոռանալ `array`-ը, որպեսզի այն չթողնի:
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Վերադարձնում է բոլոր տարրերի անփոփոխ կտորը, որոնք դեռ չեն բերվել:
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք գիտենք, որ `alive`-ի բոլոր տարրերը պատշաճ կերպով սկզբնավորվում են:
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Վերադարձնում է բոլոր տարրերի փոփոխական կտորը, որոնք դեռ չեն բերվել:
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք գիտենք, որ `alive`-ի բոլոր տարրերը պատշաճ կերպով սկզբնավորվում են:
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Ստացեք հաջորդ ցուցանիշը ճակատից:
        //
        // `alive.start`-ի 1-ով ավելացումը պահպանում է `alive`-ի վերաբերյալ անփոփոխությունը:
        // Սակայն այս փոփոխության շնորհիվ, կարճ ժամանակով, կենդանի գոտին այլևս ոչ թե `data[alive]` է, այլ `data[idx..alive.end]`:
        //
        self.alive.next().map(|idx| {
            // Կարդացեք զանգվածից տարրը:
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `idx`-ը ցուցանիշ է նախկին "alive" տարածաշրջանում
            // զանգվածԱյս տարրը կարդալը նշանակում է, որ `data[idx]`-ն այժմ համարվում է մեռած (այսինքն `ձեռք մի տվեք):
            // Քանի որ `idx`-ը կենդանի գոտու սկիզբն էր, կենդանի գոտին այժմ կրկին `data[alive]` է ՝ վերականգնելով բոլոր անփոփոխները:
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Ստացեք հաջորդ ցուցանիշը հետեւից:
        //
        // `alive.end`-ի 1-ով նվազումը պահպանում է `alive`-ի վերաբերյալ անփոփոխությունը:
        // Սակայն այս փոփոխության շնորհիվ, կարճ ժամանակով, կենդանի գոտին այլևս ոչ թե `data[alive]` է, այլ `data[alive.start..=idx]`:
        //
        self.alive.next_back().map(|idx| {
            // Կարդացեք զանգվածից տարրը:
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `idx`-ը ցուցանիշ է նախկին "alive" տարածաշրջանում
            // զանգվածԱյս տարրը կարդալը նշանակում է, որ `data[idx]`-ն այժմ համարվում է մեռած (այսինքն `ձեռք մի տվեք):
            // Քանի որ `idx`-ը կենդանի գոտու վերջն էր, կենդանի գոտին այժմ կրկին `data[alive]` է ՝ վերականգնելով բոլոր անփոփոխները:
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա անվտանգ է. `as_mut_slice`-ը վերադարձնում է հենց ենթաբաժինը
        // տարրերի, որոնք դեռ չեն տեղափոխվել և մնում են թողնել:
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Երբեք չի հորդելու անփոփոխ `կենդանի պատճառով: սկիզբ <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Կրկնիչը իսկապես հայտնում է ճիշտ երկարությունը:
// "alive" տարրերի քանակը (որը դեռ կտա) `alive` տիրույթի երկարությունն է:
// Այս միջակայքը երկարությամբ կրճատվում է կամ `next`-ում կամ `next_back`-ում:
// Այդ մեթոդներում այն միշտ նվազում է 1-ով, բայց միայն այն դեպքում, եթե `Some(_)` վերադարձվի:
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Նկատի ունեցեք, որ իրականում մեզ պետք չէ համապատասխանել ճիշտ նույն կենդանի տիրույթին, այնպես որ մենք կարող ենք պարզապես կլոնավորել 0-ի փոխհատուցում ՝ անկախ այն բանից, թե որտեղ է `self`-ը:
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Կլոնավորել բոլոր կենդանի տարրերը:
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Նոր զանգվածում կլոն գրեք, ապա թարմացրեք դրա կենդանի տիրույթը:
            // Եթե panics-ը կլոնավորվի, մենք ճիշտ դուրս կգանք նախորդ կետերը:
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Տպեք միայն այն տարրերը, որոնք դեռ չեն բերվել. Մենք այլևս չենք կարող մուտք գործել զիջված տարրեր:
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}