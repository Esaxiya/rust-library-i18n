//! Նիշերի վերափոխումներ:

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32`-ը փոխակերպում է `char`-ի:
///
/// Նկատի ունեցեք, որ բոլոր [`char`] ներն ուժի մեջ են [`u32`] s և կարող են տրվել մեկի հետ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Սակայն հակառակը ճիշտ չէ. Ոչ բոլոր վավեր [`u32`]-երն են վավեր [`char`]-երը:
/// `from_u32()` կվերադարձնի `None`, եթե մուտքագրումը վավեր արժեք չէ [`char`]-ի համար:
///
/// Այս գործառույթի ոչ անվտանգ տարբերակի համար, որն անտեսում է այս ստուգումները, տե՛ս [`from_u32_unchecked`]:
///
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None`-ի վերադարձը, երբ մուտքագրումը վավեր [`char`] չէ.
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// `u32`-ը փոխարկում է `char` ՝ անտեսելով վավերականությունը:
///
/// Նկատի ունեցեք, որ բոլոր [`char`] ներն ուժի մեջ են [`u32`] s և կարող են տրվել մեկի հետ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Սակայն հակառակը ճիշտ չէ. Ոչ բոլոր վավեր [`u32`]-երն են վավեր [`char`]-երը:
/// `from_u32_unchecked()` դա անտեսելու է և կուրորեն նետվում է [`char`] ՝ հնարավոր է ստեղծելով անվավեր մեկը:
///
///
/// # Safety
///
/// Այս գործառույթն անվտանգ չէ, քանի որ այն կարող է կառուցել անվավեր `char` արժեքներ:
///
/// Այս գործառույթի անվտանգ տարբերակի համար տե՛ս [`from_u32`] գործառույթը:
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `i`-ը վավեր արժեքի արժեք է:
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`]-ը փոխակերպում է [`u32`]-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`]-ը փոխակերպում է [`u64`]-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Ածուխը գցվում է ծածկագրի կետի արժեքի վրա, այնուհետև զրոյացվում է մինչև 64 բիթ:
        // Տե՛ս [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`]-ը փոխակերպում է [`u128`]-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Ածուխը գցվում է ծածկագրի կետի արժեքի վրա, այնուհետև զրոյացվում է մինչև 128 բիթ:
        // Տե՛ս [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Քարտեզում է մի բայթ 0x00 ..=0xFF-ից `char`, որի ծածկագրի կետը նույն արժեքն է, U + 0000 ..=U + 00FF:
///
/// Unicode-ը նախագծված է այնպես, որ սա արդյունավետորեն ապակոդավորի բայթերը `IANA-ն ISO-8859-1 անվանումով ծածկագրող նիշով:
/// Այս կոդավորումը համատեղելի է ASCII-ի հետ:
///
/// Նշենք, որ սա տարբերվում է ISO/IEC 8859-1 aka-ից
/// ISO 8859-1 (մեկ պակաս գծիկով), որը թողնում է որոշ "blanks", բայթ արժեքներ, որոնք նշանակված չեն որևէ նիշի:
/// ISO-8859-1-ը (IANA-ն) դրանք վերագրում է C0 և C1 կառավարման կոդերին:
///
/// Նշենք, որ սա *նույնպես* տարբերվում է Windows-1252 aka-ից
/// 1252 էջի ծածկագիրը, որը գերադասելի ISO/IEC 8859-1 է, որը որոշ (ոչ բոլորը!) Դատարկներ է հատկացնում կետադրության և տարբեր լատինական նիշերի:
///
/// Իրերը հետագայում շփոթելու համար, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` և `windows-1252` բոլորն էլ հանդիսանում են Windows-1252 գերհամակարգի կեղծանուններ, որոնք մնացած դատարկները լրացնում են համապատասխան C0 և C1 կառավարման կոդերով:
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`]-ը փոխակերպում է [`char`]-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Սխալ, որը կարող է վերադարձվել փայտանյութը վերլուծելիս:
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ստուգեց, որ դա օրինական յունիկոդային արժեք է
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Սխալի տեսակը վերադարձավ, երբ u32-ից char փոխարկումը ձախողվեց:
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Տրված շառավղի թվանշանը վերափոխում է `char`-ի:
///
/// 'radix'-ը այստեղ երբեմն կոչվում է նաև 'base':
/// Երկու շառավիղը ցույց է տալիս երկուական թիվ, տաս տասնորդական տասնորդական, տասնվեց տասնորդական շառավիղ, տասնվեց տասնվեցական ՝ որոշ ընդհանուր արժեքներ տալու համար:
///
/// Կամայական ճառագայթները ապահովվում են:
///
/// `from_digit()` կվերադարձնի `None`, եթե մուտքագրումը տվյալ ռադիկսում թվանշան չէ:
///
/// # Panics
///
/// Panics եթե 36-ից մեծ շառավիղ է տրված:
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Տասնորդական տասնյակը 16-ի բազայում մեկ նիշ է
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// `None`-ի վերադարձը, երբ մուտքը թվանշան չէ.
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Անցնելով մեծ շառավիղ ՝ առաջացնելով panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}