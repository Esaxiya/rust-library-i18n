//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char`-ի ամենաբարձր վավեր կոդային կետը կարող է ունենալ:
    ///
    /// `char`-ը [Unicode Scalar Value] է, ինչը նշանակում է, որ այն [Code Point] է, բայց միայն նրանք, ովքեր գտնվում են որոշակի տիրույթում:
    /// `MAX` ամենաբարձր վավեր կոդային կետն է, որը վավեր [Unicode Scalar Value] է:
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` ()-ն օգտագործվում է Unicode-ում `վերծանման սխալ ներկայացնելու համար:
    ///
    /// Դա կարող է առաջանալ, օրինակ, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-ին վատ կազմավորված UTF-8 բայթ տալու ժամանակ:
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/)-ի տարբերակը, որի վրա հիմնված են `char` և `str` մեթոդների Unicode մասերը:
    ///
    /// Unicode-ի նոր տարբերակները պարբերաբար թողարկվում են, հետագայում ստանդարտ գրադարանում բոլոր մեթոդները, որոնք կախված են Unicode-ից, թարմացվում են:
    /// Հետևաբար, `char` և `str` որոշ մեթոդների վարքագիծը և այս հաստատունի արժեքը ժամանակի ընթացքում փոխվում են:
    /// Սա * չի համարվում կոտրող փոփոխություն:
    ///
    /// Տարբերակի համարակալման սխեման բացատրվում է [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4)-ում:
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter`-ում UTF-16 կոդավորված կոդերի կետերի վրա ստեղծում է կրկնիչ `վերադարձնելով չզույգված փոխնակներին որպես` Err`:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Կորուստային վերծանիչը կարելի է ձեռք բերել `Err` արդյունքները փոխարինող բնույթով փոխարինելով.
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32`-ը փոխակերպում է `char`-ի:
    ///
    /// Նկատի ունեցեք, որ բոլոր `char-ները վավեր են` `u32``, և դրանք կարող են տրվել մեկի հետ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Սակայն հակառակը ճիշտ չէ. Ոչ բոլոր [[u32 »] ներն են վավեր` «char»:
    /// `from_u32()` կվերադարձնի `None`, եթե մուտքագրումը վավեր արժեք չէ `char`-ի համար:
    ///
    /// Այս գործառույթի ոչ անվտանգ տարբերակի համար, որն անտեսում է այս ստուգումները, տե՛ս [`from_u32_unchecked`]:
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None`-ի վերադարձը, երբ մուտքագրումը վավեր `char` չէ.
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32`-ը փոխարկում է `char` ՝ անտեսելով վավերականությունը:
    ///
    /// Նկատի ունեցեք, որ բոլոր `char-ները վավեր են` `u32``, և դրանք կարող են տրվել մեկի հետ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Սակայն հակառակը ճիշտ չէ. Ոչ բոլոր [[u32 »] ներն են վավեր` «char»:
    /// `from_u32_unchecked()` դա անտեսելու է և կուրորեն նետվում է `char` ՝ հնարավոր է ստեղծելով անվավեր մեկը:
    ///
    ///
    /// # Safety
    ///
    /// Այս գործառույթն անվտանգ չէ, քանի որ այն կարող է կառուցել անվավեր `char` արժեքներ:
    ///
    /// Այս գործառույթի անվտանգ տարբերակի համար տե՛ս [`from_u32`] գործառույթը:
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անվտանգության պայմանագիրը պետք է պահպանվի զանգահարողի կողմից:
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Տրված շառավղի թվանշանը վերափոխում է `char`-ի:
    ///
    /// 'radix'-ը այստեղ երբեմն կոչվում է նաև 'base':
    /// Երկու շառավիղը ցույց է տալիս երկուական թիվ, տաս տասնորդական տասնորդական, տասնվեց տասնորդական շառավիղ, տասնվեց տասնվեցական ՝ որոշ ընդհանուր արժեքներ տալու համար:
    ///
    /// Կամայական ճառագայթները ապահովվում են:
    ///
    /// `from_digit()` կվերադարձնի `None`, եթե մուտքագրումը տվյալ ռադիկսում թվանշան չէ:
    ///
    /// # Panics
    ///
    /// Panics եթե 36-ից մեծ շառավիղ է տրված:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Տասնորդական տասնյակը 16-ի բազայում մեկ նիշ է
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None`-ի վերադարձը, երբ մուտքը թվանշան չէ.
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Անցնելով մեծ շառավիղ ՝ առաջացնելով panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Ստուգում է `արդյոք `char`-ը տրված ռադիկսում թվանշան է:
    ///
    /// 'radix'-ը այստեղ երբեմն կոչվում է նաև 'base':
    /// Երկու շառավիղը ցույց է տալիս երկուական թիվ, տաս տասնորդական տասնորդական, տասնվեց տասնորդական շառավիղ, տասնվեց տասնվեցական ՝ որոշ ընդհանուր արժեքներ տալու համար:
    ///
    /// Կամայական ճառագայթները ապահովվում են:
    ///
    /// [`is_numeric()`]-ի համեմատ այս գործառույթը ճանաչում է միայն `0-9`, `a-z` և `A-Z` նիշերը:
    ///
    /// 'Digit' սահմանվում է որպես միայն հետևյալ նիշերը.
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit'-ի ավելի ամբողջական պատկերացում կազմելու համար տե՛ս [`is_numeric()`]:
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics եթե 36-ից մեծ շառավիղ է տրված:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Անցնելով մեծ շառավիղ ՝ առաջացնելով panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char`-ը վերափոխում է տրված ռադիկսի թվանշանի:
    ///
    /// 'radix'-ը այստեղ երբեմն կոչվում է նաև 'base':
    /// Երկու շառավիղը ցույց է տալիս երկուական թիվ, տաս տասնորդական տասնորդական, տասնվեց տասնորդական շառավիղ, տասնվեց տասնվեցական ՝ որոշ ընդհանուր արժեքներ տալու համար:
    ///
    /// Կամայական ճառագայթները ապահովվում են:
    ///
    /// 'Digit' սահմանվում է որպես միայն հետևյալ նիշերը.
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Վերադարձնում է `None`, եթե `char`-ը չի վերաբերում տվյալ շառավիղի թվանշանին:
    ///
    /// # Panics
    ///
    /// Panics եթե 36-ից մեծ շառավիղ է տրված:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Անտանիշ անցնելը հանգեցնում է ձախողման.
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Անցնելով մեծ շառավիղ ՝ առաջացնելով panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // կոդը բաժանվում է այստեղ `կատարման արագությունը բարելավելու համար այն դեպքերում, երբ `radix`-ը կայուն է և 10 կամ ավելի փոքր
        //
        let val = if likely(radix <= 10) {
            // Եթե ոչ թվանշան է, կստեղծվի radix-ից մեծ թիվ:
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Վերադարձնում է կրկնիչի, որը տալիս է տասնվեցական Unicode փախուստը բնույթի ``char`նիշից:
    ///
    /// Սա կփախչի նիշերից `\u{NNNNNN}` ձևի Rust շարահյուսությամբ, որտեղ `NNNNNN` տասնվեցական ներկայացուցչություն է:
    ///
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // կամ 1-ը ապահովում է, որ c==0-ի համար կոդը հաշվարկում է, որ մեկ նիշ պետք է տպվի և (որը նույնն է) խուսափում է (31, 32) ենթահոսքից
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ամենանշանակալի վեցանկյուն նիշի ցուցիչը
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug`-ի ընդլայնված տարբերակը, որը ըստ ցանկության թույլ է տալիս փախչել ընդլայնված գրաֆեմի ծածկագրերից:
    /// Սա թույլ է տալիս մեզ ավելի լավ ձևավորել նիշերը, ինչպիսիք են ոչ հեռավորության վրա գտնվող նշանները, երբ դրանք գտնվում են տողի սկզբում:
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Վերադարձնում է կրկնիչի, որը տալիս է նիշի բառացի փախուստի ծածկագիրը ``char`
    ///
    /// Սա կփախչի `str` կամ `char` `Debug` ներդրումների նման նիշերից:
    ///
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Վերադարձնում է կրկնիչի, որը տալիս է նիշի բառացի փախուստի ծածկագիրը ``char`
    ///
    /// Լռելյայնն ընտրվում է մի շարք լեզուներով օրինական բառեր ստեղծելու կողմնակալությամբ, ներառյալ C++ 11 և նմանատիպ C ընտանիքի լեզուները:
    /// Exactշգրիտ կանոններն են.
    ///
    /// * Ներդիրը փախել է որպես `\t`:
    /// * Փոխադրման վերադարձից խուսափում են որպես `\r`:
    /// * Line feed-ից խուսափում են որպես `\n`:
    /// * Միայնակ մեջբերումից խուսափում են որպես `\'`:
    /// * Կրկնակի մեջբերումից խուսափում են որպես `\"`:
    /// * Հետադարձ կապից խուսափելը `\\` է:
    /// * «Տպվող ASCII» `0x20` .. `0x7e` ներառյալ տիրույթում որևէ նիշ չի խուսափում:
    /// * Մնացած բոլոր նիշերին տրվում է տասնվեցական յունիկոդի փախուստներ;տես [`escape_unicode`]:
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Վերադարձնում է այս `char`-ի համար անհրաժեշտ բայթերի քանակը, եթե կոդավորված է UTF-8-ում:
    ///
    /// Բայտերի այդ քանակը միշտ 1-ից 4-ի սահմաններում է, ներառյալ:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` տիպը երաշխավորում է, որ դրա պարունակությունը UTF-8 է, և այդպիսով մենք կարող ենք համեմատել այն տևողությունը, որը կպահանջվեր, եթե յուրաքանչյուր կոդային կետ ներկայացվեր որպես `char` ընդդեմ հենց `&str`-ի.
    ///
    ///
    /// ```
    /// // որպես բնավորություն
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // երկուսն էլ կարող են ներկայացվել որպես երեք բայթ
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // որպես &str, այս երկուսը կոդավորված են UTF-8-ում
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // մենք կարող ենք տեսնել, որ նրանք ընդհանուր առմամբ վերցնում են վեց բայթ ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ճիշտ այնպես, ինչպես &str-ը
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Վերադարձնում է 16 բիթանոց կոդերի միավորներ, որոնք այս `char`-ին անհրաժեշտ կլինեն, եթե կոդավորված է UTF-16-ում:
    ///
    ///
    /// Տե՛ս [`len_utf8()`]- ի փաստաթղթերը ՝ այս հայեցակարգի մանրամասն բացատրության համար:
    /// Այս գործառույթը հայելի է, բայց UTF-16-ի համար UTF-8-ի փոխարեն:
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Այս նիշը կոդավորում է որպես UTF-8 տրամադրված բայթ բուֆերի մեջ, այնուհետև վերադարձնում է կոդավորված նիշ պարունակող բուֆերի ենթաբաժինը:
    ///
    ///
    /// # Panics
    ///
    /// Panics, եթե բուֆերը բավականաչափ մեծ չէ:
    /// Չորս երկարությամբ բուֆերը բավականաչափ մեծ է ցանկացած `char` կոդավորելու համար:
    ///
    /// # Examples
    ///
    /// Այս երկու օրինակներում էլ 'ß'-ը կոդավորելու համար տանում է երկու բայթ:
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Բուֆեր, որը չափազանց փոքր է.
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `char`-ը փոխարինող չէ, ուստի սա գործում է UTF-8:
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Այս նիշը կոդավորում է որպես UTF-16 տրամադրված `u16` բուֆերի մեջ, այնուհետև վերադարձնում է կոդավորված նիշ պարունակող բուֆերի ենթաբաժինը:
    ///
    ///
    /// # Panics
    ///
    /// Panics, եթե բուֆերը բավականաչափ մեծ չէ:
    /// 2 երկարությամբ բուֆերը բավականաչափ մեծ է ցանկացած `char` կոդավորելու համար:
    ///
    /// # Examples
    ///
    /// Այս երկու օրինակներում էլ '𝕊'-ը կոդավորելու համար տանում է երկու `u16:
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Բուֆեր, որը չափազանց փոքր է.
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ն ունի `Alphabetic` հատկություն:
    ///
    /// `Alphabetic` նկարագրված է [Unicode Standard]-ի 4-րդ գլխում (Նիշերի հատկությունները) և նշված է [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ում:
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // սերը շատ բան է, բայց այբբենական չէ
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ն ունի `Lowercase` հատկություն:
    ///
    /// `Lowercase` նկարագրված է [Unicode Standard]-ի 4-րդ գլխում (Նիշերի հատկությունները) և նշված է [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ում:
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Չինական տարբեր գրերը և կետադրությունները գործ չունեն, և այսպես.
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ն ունի `Uppercase` հատկություն:
    ///
    /// `Uppercase` նկարագրված է [Unicode Standard]-ի 4-րդ գլխում (Նիշերի հատկությունները) և նշված է [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ում:
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Չինական տարբեր գրերը և կետադրությունները գործ չունեն, և այսպես.
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ն ունի `White_Space` հատկություն:
    ///
    /// `White_Space` նշված է [Unicode Character Database][ucd] [`PropList.txt`]-ում:
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // չխախտող տարածք
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ը բավարարում է կամ [`is_alphabetic()`]-ին կամ [`is_numeric()`]-ին:
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ն ունի կառավարման կոդերի ընդհանուր կատեգորիա:
    ///
    /// Կառավարման ծածկագրերը (ծածկագրային կետեր `Cc`-ի ընդհանուր կատեգորիայի հետ) նկարագրված են [Unicode Standard]-ի 4-րդ գլխում (Նիշերի հատկությունները) և նշված են [Unicode Character Database][ucd] [`UnicodeData.txt`]-ում:
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// // U + 009C, շղթայի տերմինատոր
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ն ունի `Grapheme_Extend` հատկություն:
    ///
    /// `Grapheme_Extend` նկարագրված է [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29]-ում և նշված է [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ում:
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Վերադարձնում է `true`, եթե այս `char`-ն ունի թվերի ընդհանուր կատեգորիաներից մեկը:
    ///
    /// Թվերի ընդհանուր կատեգորիաները (տասնորդական թվանշանների համար `Nd`, տառերի նման թվային նիշերի համար `Nl` և այլ թվային նիշերի համար `No`) նշված են [Unicode Character Database][ucd] [`UnicodeData.txt`]-ում:
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Վերադարձնում է կրկնիչը, որը տալիս է այս `char`-ի փոքրատառ քարտեզագրումը որպես մեկ կամ մի քանի
    /// `char`s.
    ///
    /// Եթե այս `char`-ը չունի փոքրատառ քարտեզագրություն, կրկնիչը տալիս է նույն `char`-ը:
    ///
    /// Եթե այս `char`-ը ունի մեկ-մեկ փոքրատառ քարտեզագրություն, որը տրված է [Unicode Character Database][ucd] [`UnicodeData.txt`]-ի կողմից, կրկնիչը տալիս է այդ `char`:
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Եթե այս `char`-ը պահանջում է հատուկ նկատառումներ (օրինակ `բազմակի` char`), ապա iterator-ը տալիս է [`SpecialCasing.txt`]-ի կողմից տրված`char (ներ) ը:
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Այս գործողությունն իրականացնում է անվերապահ քարտեզագրում ՝ առանց դերձակի: Այսինքն ՝ դարձը անկախ է համատեքստից և լեզվից:
    ///
    /// [Unicode Standard]-ում 4-րդ գլխում (Նիշերի հատկությունները) ընդհանուր առմամբ քննարկվում է դեպքերի քարտեզագրումը, իսկ 3-րդ գլուխում (Conformance)-ում քննարկվում է դեպքերի վերափոխման կանխադրված ալգորիթմը:
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Երբեմն արդյունքը մեկից ավելի նիշ է.
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Նիշերը, որոնք չունեն ինչպես մեծ, այնպես էլ փոքրատառ, վերափոխվում են իրենց մեջ:
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Վերադարձնում է կրկնիչ, որը տալիս է այս `char`-ի մեծատառ քարտեզը որպես մեկ կամ մի քանի
    /// `char`s.
    ///
    /// Եթե այս `char`-ը չունի մեծատառ քարտեզ, ապա կրկնիչը տալիս է նույն `char`-ը:
    ///
    /// Եթե այս `char`-ն ունի մեկ-մեկ մեծատառ քարտեզագրություն, որը տալիս է [Unicode Character Database][ucd] [`UnicodeData.txt`]-ը, կրկնիչը տալիս է այդ `char`-ը:
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Եթե այս `char`-ը պահանջում է հատուկ նկատառումներ (օրինակ `բազմակի` char`), ապա iterator-ը տալիս է [`SpecialCasing.txt`]-ի կողմից տրված`char (ներ) ը:
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Այս գործողությունն իրականացնում է անվերապահ քարտեզագրում ՝ առանց դերձակի: Այսինքն ՝ դարձը անկախ է համատեքստից և լեզվից:
    ///
    /// [Unicode Standard]-ում 4-րդ գլխում (Նիշերի հատկությունները) ընդհանուր առմամբ քննարկվում է դեպքերի քարտեզագրումը, իսկ 3-րդ գլուխում (Conformance)-ում քննարկվում է դեպքերի վերափոխման կանխադրված ալգորիթմը:
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Երբեմն արդյունքը մեկից ավելի նիշ է.
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Նիշերը, որոնք չունեն ինչպես մեծ, այնպես էլ փոքրատառ, վերափոխվում են իրենց մեջ:
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Նշում տեղայնացման մասին
    ///
    /// Թուրքերենում լատիներենում 'i' համարժեքը երկուի փոխարեն ունի հինգ ձև.
    ///
    /// * 'Dotless': I/ı, երբեմն գրված է
    /// * 'Dotted': İ/ես
    ///
    /// Նշենք, որ փոքրատառ 'i' կետավոր կետը նույնն է, ինչ լատիներենը: Հետևաբար.
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i`-ի արժեքն այստեղ ապավինում է տեքստի լեզվին. Եթե մենք `en-US`-ի մեջ ենք, ապա այն պետք է լինի `"I"`, բայց եթե `tr_TR`-ի մեջ ենք, ապա այն `"İ"` պետք է լինի:
    /// `to_uppercase()` դա հաշվի չի առնում, և այսպես.
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// պահում է լեզուների միջև:
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII տիրույթում է:
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Կատարում է արժեքի պատճեն իր ASCII մեծատառ համարժեքով:
    ///
    /// ASCII 'a'-ից 'z' տառերը քարտեզագրվում են 'A'-ից 'Z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Տեղը մեծացնելու համար օգտագործեք [`make_ascii_uppercase()`]:
    ///
    /// ASCII նիշերը մեծատառից բացի, բացի ոչ ASCII նիշերից, օգտագործեք [`to_uppercase()`]:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Արարում է արժեքի պատճենը իր ASCII փոքրատառ համարժեքով:
    ///
    /// ASCII 'A'-ից 'Z' տառերը քարտեզագրվում են 'a'-ից 'z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Արժեքը տեղում փոքրացնելու համար օգտագործեք [`make_ascii_lowercase()`]:
    ///
    /// ASCII նիշերը փոքրատառ դարձնելու համար, բացի ոչ ASCII նիշերից, օգտագործեք [`to_lowercase()`]:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ստուգում է, որ երկու արժեք ASCII գործի նկատմամբ անզգայացուցիչ համընկնում է:
    ///
    /// Համարժեք `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Այս տիպը վերափոխում է իր ASCII մեծատառի տեղում համարժեքի:
    ///
    /// ASCII 'a'-ից 'z' տառերը քարտեզագրվում են 'A'-ից 'Z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Առանց եղածը փոփոխելու ՝ նոր մեծատառ արժեք վերադարձնելու համար օգտագործեք [`to_ascii_uppercase()`]:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Այս տիպը փոխակերպում է իր ASCII փոքրատառ տեղում:
    ///
    /// ASCII 'A'-ից 'Z' տառերը քարտեզագրվում են 'a'-ից 'z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Առանց եղածը փոփոխելու `նոր փոքր արժեք վերադարձնելու համար օգտագործեք [`to_ascii_lowercase()`]:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII այբբենական բնույթ է.
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', կամ
    /// - U + 0061 'a' ..=U + 007A 'z':
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII մեծատառ է.
    /// U + 0041 'A' ..=U + 005A 'Z':
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII փոքրատառ է.
    /// U + 0061 'a' ..=U + 007A 'z':
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII ալֆանային թվանշան է.
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', կամ
    /// - U + 0061 'a' ..=U + 007A 'z', կամ
    /// - U + 0030 '0' ..=U + 0039 '9':
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII տասնորդական նիշ է.
    /// U + 0030 '0' ..=U + 0039 '9':
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII տասնվեցական նիշ է.
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', կամ
    /// - U + 0041 'A' ..=U + 0046 'F', կամ
    /// - U + 0061 'a' ..=U + 0066 'f':
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII կետադրության կետ է:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, կամ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, կամ
    /// - U + 005B ..=U + 0060 «[\] ^ _« ``, կամ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII գրաֆիկական նիշ է.
    /// U + 0021 '!' ..=U + 007E '~':
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII սպիտակ տարածության բնույթ է.
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, կամ U + 000D ՎԱIAԱՌՔԻ ՎԵՐԱԴԱՐՁ:
    ///
    /// Rust-ն օգտագործում է WhatWG Infra Standard-ի [definition of ASCII whitespace][infra-aw]-ը: Լայն օգտագործման մեջ կան մի քանի այլ սահմանումներ:
    /// Օրինակ, [the POSIX locale][pct]-ն իր մեջ ներառում է U + 000B ուղղաձիգ սալիկ, ինչպես նաև վերը նշված բոլոր նիշերը, բայց, նույն բնութագրից ելնելով, [[Bourne shell-ի "field splitting"-ի լռելյայն կանոնը][bfs] համարում է *միայն* SPACE, HORIZONTAL TAB և LINE FEED-ը որպես սպիտակ տարածք:
    ///
    ///
    /// Եթե դուք գրում եք ծրագիր, որը կմշակի գոյություն ունեցող ֆայլի ձևաչափը, նախքան այս գործառույթն օգտագործելը, ստուգեք, թե որն է այդ ձևաչափի սպիտակ տարածության սահմանումը:
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Ստուգում է ՝ արդյոք արժեքը ASCII հսկիչ բնույթ է.
    /// U + 0000 NUL ..=U + 001F ՄԻԱՅԱԼ ԲԱPԱՆԻՉ, կամ U + 007F LEՆԵԼ:
    /// Նշենք, որ ASCII սպիտակ տարածության նիշերի մեծ մասը վերահսկիչ նիշեր են, բայց SPACE-ը ՝ ոչ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Կոդավորում է հում u32 արժեքը որպես UTF-8 տրամադրված բայթ բուֆերի մեջ, այնուհետև վերադարձնում է կոդավորված նիշ պարունակող բուֆերի ենթաբաժինը:
///
///
/// Ի տարբերություն `char::encode_utf8`-ի, այս մեթոդը նաև կարգավորում է փոխանորդների սահմաններում գտնվող կոդային կետերը:
/// (Փոխանորդ տիրույթում `char`-ի ստեղծումը UB է) Արդյունքն ուժի մեջ է [generalized UTF-8], բայց ոչ վավեր UTF-8:
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, եթե բուֆերը բավականաչափ մեծ չէ:
/// Չորս երկարությամբ բուֆերը բավականաչափ մեծ է ցանկացած `char` կոդավորելու համար:
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Տրամադրվում է հում u32 արժեքը որպես UTF-16 տրամադրված `u16` բուֆերի մեջ, այնուհետև վերադարձնում է կոդավորված նիշ պարունակող բուֆերի ենթաբաժինը:
///
///
/// Ի տարբերություն `char::encode_utf16`-ի, այս մեթոդը նաև կարգավորում է փոխանորդների սահմաններում գտնվող կոդային կետերը:
/// (Փոխանորդ տիրույթում `char`-ի ստեղծումը UB է):
///
/// # Panics
///
/// Panics, եթե բուֆերը բավականաչափ մեծ չէ:
/// 2 երկարությամբ բուֆերը բավականաչափ մեծ է ցանկացած `char` կոդավորելու համար:
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Յուրաքանչյուր թև ստուգում է ՝ արդյոք բիտերը բավարար են գրելու համար
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP-ն ընկնում է
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Լրացուցիչ ինքնաթիռները ներխուժում են փոխարինողներ:
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}