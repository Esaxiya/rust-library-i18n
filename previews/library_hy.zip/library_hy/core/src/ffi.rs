#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Կոմունալ ծառայություններ, կապված օտարերկրյա ֆունկցիայի (FFI) կապակցիչների հետ:

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Համարժեք է C-ի `void` տիպին, երբ օգտագործվում է որպես [pointer]:
///
/// Ըստ էության, `*const c_void` համարժեք է C-ի `const void*`-ին, իսկ `*mut c_void`-ը համարժեք է C-ի `void*`-ին:
/// Ասել է թե, սա * նույնը չէ, ինչ C-ի `void` վերադարձման տեսակը, որը Rust-ի `()` տեսակն է:
///
/// FFI-ում անթափանց տիպերի ցուցիչները մոդելավորելու համար, մինչև `extern type` կայունանա, խորհուրդ է տրվում օգտագործել newtype փաթաթան դատարկ բայթ զանգվածի շուրջ:
///
/// Մանրամասների համար տես [Nomicon]:
///
/// Կարելի է օգտագործել `std::os::raw::c_void`, եթե նրանք ցանկանում են աջակցել հին Rust կազմողին մինչև 1.1.0:
/// Rust 1.30.0-ից հետո այն վերաարտահանվեց այս սահմանմամբ:
/// Լրացուցիչ տեղեկությունների համար կարդացեք [RFC 2521]:
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, որպեսզի LLVM-ը ճանաչի անվավեր ցուցիչի տեսակը և malloc()-ի նման ընդլայնման գործառույթներով, մենք պետք է ունենանք այն որպես i8 * LLVM բիթկոդում:
// Այստեղ օգտագործված հաշվարկը դա ապահովում է և կանխում "raw" տիպի չարաշահումը ՝ ունենալով միայն մասնավոր տարբերակներ:
// Մեզ երկու տարբերակ է պետք, քանի որ կազմողը այլ կերպ է բողոքում repr հատկանիշից, և մեզ առնվազն մեկ տարբերակ է պետք, քանի որ հակառակ դեպքում enum-ը անմարդաբնակ կլիներ, և գոնե նման ցուցիչների վերանայում կլիներ UB:
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list`-ի հիմնական ներդրում:
// Անունը WIP է ՝ ներկայումս օգտագործելով `VaListImpl`:
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f`-ի նկատմամբ անփոփոխ է, ուստի յուրաքանչյուր `VaListImpl<'f>` օբյեկտ կապված է իր սահմանած գործառույթի տարածաշրջանի հետ
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list`-ի ABI իրականացում:
/// Տեսեք [AArch64 Procedure Call Standard]-ը ՝ ավելի մանրամասն:
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list`-ի ABI իրականացում:
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list`-ի ABI իրականացում:
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Փաթեթ `va_list`-ի համար
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Փոխակերպեք `VaListImpl`-ը `VaList`-ի, որը երկուական համատեղելի է C's `va_list`-ի հետ:
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Փոխակերպեք `VaListImpl`-ը `VaList`-ի, որը երկուական համատեղելի է C's `va_list`-ի հետ:
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait-ն անհրաժեշտ է օգտագործել հանրային ինտերֆեյսերում, սակայն trait-ն ինքնին չպետք է թույլատրվի օգտագործել այս մոդուլից դուրս:
// Թույլ տալ օգտվողներին իրականացնել trait նոր տիպի համար (դրանով իսկ թույլ տալով, որ va_arg-ի ներքին օգտագործումը նոր տեսակի վրա), ամենայն հավանականությամբ, առաջացնում է չսահմանված վարք:
//
// FIXME(dlrobertson): Որպեսզի VaArgSafe trait-ը օգտագործվի հանրային ինտերֆեյսում, բայց նաև ապահովի, որ այն չի կարող օգտագործվել այլուր, trait-ը պետք է հանրային լինի մասնավոր մոդուլի շրջանակներում:
// RFC 2145-ի ներդրումից հետո ուսումնասիրեք այն բարելավելու համար:
//
//
//
//
mod sealed_trait {
    /// Trait, որը թույլ է տալիս թույլատրված տեսակները օգտագործել [super::VaListImpl::arg]-ի հետ:
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Հետագա հաջորդ փաստարկին:
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `va_arg`-ի անվտանգության պայմանագիրը:
        unsafe { va_arg(self) }
    }

    /// Պատճենում է `va_list`-ը ընթացիկ վայրում:
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `va_end`-ի անվտանգության պայմանագիրը:
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք գրում ենք `MaybeUninit`-ին, ուստի այն նախաստորագրվում է և `assume_init`-ն օրինական է
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: սա պետք է զանգի `va_end`, բայց դրան մաքուր միջոց չկա
        // երաշխավորում է, որ `drop`-ը միշտ խորանում է իր զանգահարողի մեջ, ուստի `va_end`-ը ուղղակիորեն կանչվում է նույն գործառույթից, ինչ համապատասխան `va_copy`-ը:
        // `man va_end` նշում է, որ C-ն դա է պահանջում, և LLVM-ը հիմնականում հետևում է C իմաստաբանությանը, ուստի մենք պետք է համոզվենք, որ `va_end`-ը միշտ կանչվում է նույն գործառույթից, ինչ `va_copy`-ը:
        //
        // Լրացուցիչ մանրամասների համար see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Սա գործում է առայժմ, քանի որ `va_end` արգելված է գործող բոլոր LLVM թիրախների համար:
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Քանդեք arg0list `ap`-ը `va_start` կամ `va_copy`-ի հետ նախնական ձեւակերպելուց հետո:
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Պատճենում է arg01 ցուցակի ներկայիս գտնվելու վայրը arg00list-ում `dst`:
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `T` տիպի փաստարկը բեռնում է `va_list` `ap`-ից և ավելացնում `ap` փաստարկը:
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}