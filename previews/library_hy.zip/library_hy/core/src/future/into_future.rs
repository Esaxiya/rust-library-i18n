use crate::future::Future;

/// Փոխարկումը `Future`-ի:
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Արդյունքն, որն future-ն արտադրելու է ավարտից հետո:
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Ո՞ր տեսակի future-ի ենք վերածում:
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Ստեղծում է future արժեքից:
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}