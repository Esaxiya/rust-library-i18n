#![stable(feature = "futures_api", since = "1.36.0")]

//! Ասինխրոն արժեքներ:

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Այս տեսակն անհրաժեշտ է, քանի որ.
///
/// ա) Գեներատորները չեն կարող իրականացնել `for<'a, 'b> Generator<&'a mut Context<'b>>`, ուստի մենք պետք է հում ցուցիչ փոխանցենք (տես <https://github.com/rust-lang/rust/issues/68923>):
///
/// բ) Հում ցուցիչները և `NonNull`-ը `Send` կամ `Sync` չեն, ուստի դա կստիպեր նաև յուրաքանչյուր future non-Send/Sync, և մենք դա չենք ուզում:
///
/// Այն նաև հեշտացնում է `.await`-ի HIR իջեցումը:
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Գեներատոր փաթեթավորեք future-ով:
///
/// Այս ֆունկցիան տակը վերադարձնում է `GenFuture`, բայց այն թաքցնում է `impl Trait`-ի մեջ ՝ ավելի լավ սխալ հաղորդագրություն տալու համար (`impl Future` քան `GenFuture<[closure.....]>`):
///
// Սա `const` է ՝ `const async fn`-ից վերականգնվելուց հետո լրացուցիչ սխալներից խուսափելու համար
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Մենք ապավինում ենք այն փաստին, որ async/await futures-ն անշարժ են հիմքում ընկած գեներատորիայում ինքնահղման վարկեր ստեղծելու համար:
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ապահով, քանի որ մենք !Unpin + !Drop ենք, և սա պարզապես դաշտի պրոյեկցիա է:
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Վերսկսեք գեներատորը, `&mut Context`-ը վերածելով `NonNull` հում ցուցիչի:
            // `.await` իջեցումն անվտանգորեն կդարձնի այն `&mut Context`:
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `cx.0`-ը վավեր ցուցիչ է
    // որը լրացնում է փոփոխական տեղեկանքի բոլոր պահանջները:
    unsafe { &mut *cx.0.as_ptr().cast() }
}