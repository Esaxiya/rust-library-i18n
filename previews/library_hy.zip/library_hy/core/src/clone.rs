//! `Clone` trait այն տեսակների համար, որոնք հնարավոր չէ «անուղղակիորեն պատճենել»:
//!
//! Rust-ում որոշ պարզ տիպեր "implicitly copyable" են, և երբ դրանք նշանակեք կամ դրանք որպես փաստարկներ փոխանցեք, ստացողը կստանա պատճեն ՝ թողնելով բնօրինակ արժեքը տեղում:
//! Այս տեսակների համար հատկացում չի պահանջվում պատճենելու համար և չունեն վերջնականացնողներ (այսինքն դրանք չեն պարունակում տուփեր կամ իրականացնում են [`Drop`]), ուստի կազմողը նրանց համարում է էժան և անվտանգ պատճենման համար:
//!
//! Այլ տիպերի համար պատճենները պետք է արվեն հստակ ՝ [`Clone`] trait-ի ներդրմամբ և [`clone`] մեթոդով զանգահարելով:
//!
//! [`clone`]: Clone::clone
//!
//! Հիմնական օգտագործման օրինակ.
//!
//! ```
//! let s = String::new(); // Լարի տեսակը իրականացնում է Clone-ը
//! let copy = s.clone(); // այնպես որ կարողանանք կլոնավորել այն
//! ```
//!
//! Clone trait-ը հեշտությամբ իրականացնելու համար կարող եք նաև օգտագործել `#[derive(Clone)]`: Օրինակ:
//!
//! ```
//! #[derive(Clone)] // մենք ավելացնում ենք Clone trait-ը Morpheus կառուցվածքին
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // և այժմ մենք կարող ենք կլոնավորել այն:
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Ընդհանուր trait օբյեկտը հստակ կրկնօրինակելու ունակության համար:
///
/// [`Copy`]-ից տարբերվող այդ [`Copy`]-ում անուղղակի է և ծայրաստիճան էժան, մինչդեռ `Clone`-ը միշտ հստակ է և կարող է թանկ լինել կամ լինել:
/// Այս բնութագրերն ուժի մեջ մտնելու համար Rust-ը թույլ չի տալիս վերամեկնարկել [`Copy`]-ը, բայց կարող եք վերագործարկել `Clone`-ը և գործարկել կամայական ծածկագիր:
///
/// Քանի որ `Clone`-ն ավելի ընդհանուր է, քան [`Copy`]-ը, դուք կարող եք ինքնաբերաբար այնպես անել, որ ցանկացած [`Copy`] լինի նաև `Clone`:
///
/// ## Derivable
///
/// Այս trait-ը կարող է օգտագործվել `#[derive]`-ի հետ, եթե բոլոր դաշտերը `Clone` են: [`Clone`]-ի «բխող» իրականացումը յուրաքանչյուր դաշտում զանգահարում է [`clone`]:
///
/// [`clone`]: Clone::clone
///
/// Ընդհանուր կառուցվածքի համար `#[derive]`-ը իրականացնում է `Clone` պայմանականորեն `ավելացնելով պարտադիր `Clone` ընդհանուր պարամետրերի վրա:
///
/// ```
/// // `derive` իրականացնում է Clone for Reading-ը<T>երբ T-ը Clone է:
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ինչպե՞ս կարող եմ իրականացնել `Clone`-ը:
///
/// [`Copy`] տեսակները պետք է ունենան `Clone` չնչին իրականացում: Ավելի պաշտոնական ՝
/// եթե `T: Copy`, `x: T` և `y: &T`, ապա `let x = y.clone();` համարժեք է `let x = *y;`:
/// Ձեռնարկի իրականացումը պետք է զգույշ լինի, որպեսզի այս անփոփոխը պահպանվի: այնուամենայնիվ, անապահով ծածկագիրը չպետք է ապավինի դրան ՝ հիշողության անվտանգությունն ապահովելու համար:
///
/// Որպես օրինակ `գործառույթի ցուցիչը պահող ընդհանուր կառուցվածք է: Այս դեպքում `Clone`-ի իրականացումը չի կարող «բխել», բայց կարող է իրականացվել ՝
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Լրացուցիչ իրականացնողներ
///
/// Բացի [implementors listed below][impls]-ից, `Clone`-ն իրականացնում են նաև հետևյալ տեսակները.
///
/// * Ֆունկցիայի կետի տեսակները (այսինքն `յուրաքանչյուր ֆունկցիայի համար սահմանված հստակ տեսակները)
/// * Ֆունկցիայի ցուցիչի տեսակները (օրինակ ՝ `fn() -> i32`)
/// * Rayանգվածի տեսակները, բոլոր չափերի համար, եթե իրի տեսակը նաև իրականացնում է `Clone` (օրինակ ՝ `[i32; 123456]`)
/// * Եզակի տիպեր, եթե յուրաքանչյուր բաղադրիչ իրականացնում է նաև `Clone` (օրինակ ՝ `()`, `(i32, bool)`)
/// * Փակման տեսակները, եթե դրանք շրջակա միջավայրից որևէ արժեք չեն գրավում, կամ եթե բոլոր այդպիսի գրավված արժեքներն իրենք են իրականացնում `Clone`:
///   Նկատի ունեցեք, որ ընդհանուր տեղեկանքի կողմից գրավված փոփոխականները միշտ իրականացնում են `Clone` (նույնիսկ եթե հղումը չի անում), մինչդեռ փոփոխական հղումով գրավված փոփոխականները երբեք չեն իրականացնում `Clone`:
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Վերադարձնում է արժեքի կրկնօրինակը:
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str իրականացնում է Clone-ը
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Կատարում է պատճենների հանձնարարություն `source`-ից:
    ///
    /// `a.clone_from(&b)` համարժեք է `a = b.clone()` ֆունկցիոնալությանը, բայց կարող է չեղյալ համարվել `a`-ի ռեսուրսները նորից օգտագործելու համար ՝ ավելորդ հատկացումներից խուսափելու համար:
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Ստացեք trait `Clone`-ի ազդակ առաջացնող մակրո:
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): այս նիշերը օգտագործվում են բացառապես#[derive]-ի կողմից `պնդելու համար, որ տիպի յուրաքանչյուր բաղադրիչ իրականացնում է Clone կամ Copy:
//
//
// Այս ոճերը երբեք չպետք է հայտնվեն օգտվողի ծածկագրում:
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone`-ի իրականացումը պարզունակ տիպերի համար:
///
/// Իրականացումները, որոնք հնարավոր չէ նկարագրել Rust-ում, իրականացվում են `traits::SelectionContext::copy_clone_conditions()`-ում `rustc_trait_selection`-ում:
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Համօգտագործվող հղումները կարող են կլոնավորվել, բայց փոփոխվող հղումները *չեն կարող*:
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Համօգտագործվող հղումները կարող են կլոնավորվել, բայց փոփոխվող հղումները *չեն կարող*:
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}