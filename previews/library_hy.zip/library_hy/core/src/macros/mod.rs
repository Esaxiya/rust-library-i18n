#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Ընդլայնվում է կամ `$crate::panic::panic_2015` կամ `$crate::panic::panic_2021` ՝ կախված զանգահարողի թողարկումից:
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Պնդում է, որ երկու արտահայտություն հավասար է միմյանց (օգտագործելով [`PartialEq`]):
///
/// panic-ի վրա այս մակրոը կտպագրի արտահայտությունների արժեքները իրենց վրիպազերծման ներկայացումներով:
///
///
/// [`assert!`]-ի նման, այս մակրոը ունի նաև երկրորդ ձևը, որտեղ կարելի է տրամադրել panic մաքսային հաղորդագրություն:
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ստորև բերված հետադարձները դիտավորյալ են:
                    // Առանց դրանց, փոխառության ստոցի բնիկը նախանշվում է նույնիսկ նախքան արժեքները համեմատելը, ինչը հանգեցնում է նկատելի դանդաղեցման:
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ստորև բերված հետադարձները դիտավորյալ են:
                    // Առանց դրանց, փոխառության ստոցի բնիկը նախանշվում է նույնիսկ նախքան արժեքները համեմատելը, ինչը հանգեցնում է նկատելի դանդաղեցման:
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Պնդում է, որ երկու արտահայտություն հավասար չեն միմյանց (օգտագործելով [`PartialEq`]):
///
/// panic-ի վրա այս մակրոը կտպագրի արտահայտությունների արժեքները իրենց վրիպազերծման ներկայացումներով:
///
///
/// [`assert!`]-ի նման, այս մակրոը ունի նաև երկրորդ ձևը, որտեղ կարելի է տրամադրել panic մաքսային հաղորդագրություն:
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ստորև բերված հետադարձները դիտավորյալ են:
                    // Առանց դրանց, փոխառության ստոցի բնիկը նախանշվում է նույնիսկ նախքան արժեքները համեմատելը, ինչը հանգեցնում է նկատելի դանդաղեցման:
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ստորև բերված հետադարձները դիտավորյալ են:
                    // Առանց դրանց, փոխառության ստոցի բնիկը նախանշվում է նույնիսկ նախքան արժեքները համեմատելը, ինչը հանգեցնում է նկատելի դանդաղեցման:
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Պնդում է, որ բուլյան արտահայտությունը գործարկման ժամանակ `true` է:
///
/// Սա կանչելու է [`panic!`] մակրոը, եթե տրամադրված արտահայտությունը հնարավոր չէ գնահատել `true` ՝ գործարկման ժամանակ:
///
/// [`assert!`]-ի նման, այս մակրո-ն ունի նաև երկրորդ տարբերակը, որտեղ կարելի է տրամադրել panic մաքսային հաղորդագրություն:
///
/// # Uses
///
/// Ի տարբերություն [`assert!`]-ի, `debug_assert!` հայտարարությունները կանխադրված են միայն ոչ օպտիմիզացված կառուցվածքներում:
/// Օպտիմիզացված կառուցվածքը չի կատարի `debug_assert!` հայտարարությունները, քանի դեռ `-C debug-assertions`-ը չի փոխանցվել կազմողին:
/// Սա `debug_assert!`-ն օգտակար է դարձնում այն ստուգումների համար, որոնք չափազանց թանկ են `թողարկման կառուցվածքում ներկայանալու համար, բայց կարող են օգտակար լինել մշակման ընթացքում:
/// `debug_assert!`-ի ընդլայնման արդյունքը միշտ ստուգվում է տիպով:
///
/// Չստուգված պնդումը թույլ է տալիս անընդհատ վիճակում գտնվող ծրագրին շարունակել գործարկել, ինչը կարող է ունենալ անսպասելի հետևանքներ, բայց անապահովություն չի ներմուծում, քանի դեռ դա տեղի է ունենում միայն անվտանգ ծածկագրում:
///
/// Սակայն պնդումների կատարողական արժեքը, ընդհանուր առմամբ, չափելի չէ:
/// [`assert!`]-ը `debug_assert!`-ով փոխարինելը, այսպիսով, խրախուսվում է միայն մանրակրկիտ պրոֆիլավորումից հետո, և որ ավելի կարևոր է, միայն անվտանգ ծածկագրում:
///
/// # Examples
///
/// ```
/// // այս պնդումների համար panic հաղորդագրությունը տրված արտահայտության լարային արժեքն է:
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // շատ պարզ գործառույթ
/// debug_assert!(some_expensive_computation());
///
/// // պնդել պատվերով հաղորդագրությամբ
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Պնդում է, որ երկու արտահայտություն հավասար է միմյանց:
///
/// panic-ի վրա այս մակրոը կտպագրի արտահայտությունների արժեքները իրենց վրիպազերծման ներկայացումներով:
///
/// Ի տարբերություն [`assert_eq!`]-ի, `debug_assert_eq!` հայտարարությունները կանխադրված են միայն ոչ օպտիմիզացված կառուցվածքներում:
/// Օպտիմիզացված կառուցվածքը չի կատարի `debug_assert_eq!` հայտարարությունները, քանի դեռ `-C debug-assertions`-ը չի փոխանցվել կազմողին:
/// Սա `debug_assert_eq!`-ն օգտակար է դարձնում այն ստուգումների համար, որոնք չափազանց թանկ են `թողարկման կառուցվածքում ներկայանալու համար, բայց կարող են օգտակար լինել մշակման ընթացքում:
///
/// `debug_assert_eq!`-ի ընդլայնման արդյունքը միշտ ստուգվում է տիպով:
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Պնդում է, որ երկու արտահայտություն հավասար չեն միմյանց:
///
/// panic-ի վրա այս մակրոը կտպագրի արտահայտությունների արժեքները իրենց վրիպազերծման ներկայացումներով:
///
/// Ի տարբերություն [`assert_ne!`]-ի, `debug_assert_ne!` հայտարարությունները կանխադրված են միայն ոչ օպտիմիզացված կառուցվածքներում:
/// Օպտիմիզացված կառուցվածքը չի կատարի `debug_assert_ne!` հայտարարությունները, քանի դեռ `-C debug-assertions`-ը չի փոխանցվել կազմողին:
/// Սա `debug_assert_ne!`-ն օգտակար է դարձնում այն ստուգումների համար, որոնք չափազանց թանկ են `թողարկման կառուցվածքում ներկայանալու համար, բայց կարող են օգտակար լինել մշակման ընթացքում:
///
/// `debug_assert_ne!`-ի ընդլայնման արդյունքը միշտ ստուգվում է տիպով:
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Վերադարձնում է ՝ տրված արտահայտությունը համապատասխանո՞ւմ է տրված օրինաչափություններից որևէ մեկին:
///
/// `match` արտահայտության նման, օրինակին ըստ ցանկության կարող են հետևել նաև `if`-ը և պաշտպանական արտահայտությունը, որը մուտք ունի նախշով կապված անունների:
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Արգելափակում է արդյունքը կամ տարածում դրա սխալը:
///
/// `?` օպերատորը ավելացվել է `try!`-ին փոխարինելու համար և պետք է օգտագործվի դրա փոխարեն:
/// Ավելին, `try`-ը վերապահված բառ է Rust 2018-ում, այնպես որ, եթե այն անպայման օգտագործեք, ձեզ հարկավոր է օգտագործել [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` համապատասխանում է տվյալ [`Result`]-ին: `Ok` տարբերակի դեպքում արտահայտությունն ունի փաթաթված արժեքի արժեք:
///
/// `Err` տարբերակի դեպքում այն վերականգնում է ներքին սխալը: `try!`-ն այնուհետև կատարում է փոխակերպում `օգտագործելով `From`:
/// Սա ապահովում է ավտոմատ փոխարկում մասնագիտացված սխալների և ավելի ընդհանուր սխալների միջև:
/// Դրանից հետո ստացված սխալը անմիջապես վերադարձվում է:
///
/// Վաղ վերադարձի պատճառով `try!`-ը կարող է օգտագործվել միայն այն գործառույթներում, որոնք վերադարձնում են [`Result`]:
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Սխալները արագ վերադարձնելու նախընտրելի մեթոդը
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Սխալները արագ վերադարձնելու նախորդ մեթոդը
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Սա համարժեք է.
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Ձևաչափված տվյալները գրում է բուֆերի մեջ:
///
/// Այս մակրո-ն ընդունում է 'writer', ձևաչափի տող և փաստարկների ցուցակ:
/// Փաստարկները կձևափոխվեն ըստ նշված ձևաչափի տողի, և արդյունքը կփոխանցվի գրողին:
/// Գրողը կարող է լինել ցանկացած արժեք `write_fmt` մեթոդով;հիմնականում դա գալիս է կամ [`fmt::Write`]-ի կամ [`io::Write`] trait-ի իրականացումից:
/// Մակրոն վերադարձնում է այն ամենը, ինչ վերադարձնում է `write_fmt` մեթոդը;սովորաբար [`fmt::Result`] կամ [`io::Result`]:
///
/// Տե՛ս [`std::fmt`] ՝ ֆորմատի տողի շարահյուսության վերաբերյալ լրացուցիչ տեղեկություններ ստանալու համար:
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Մոդուլը կարող է ներմուծել ինչպես `std::fmt::Write`, այնպես էլ `std::io::Write` և զանգահարել `write!` կամ այն իրականացնող օբյեկտների վրա, քանի որ օբյեկտները սովորաբար չեն իրականացնում երկուսն էլ:
///
/// Այնուամենայնիվ, մոդուլը պետք է ներմուծի traits որակավորված, որպեսզի նրանց անունները չհակասեն:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // օգտագործում է fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // օգտագործում է io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Այս մակրոը կարող է օգտագործվել նաև `no_std` կարգաբերումներում:
/// `no_std` կարգավորման դեպքում դուք պատասխանատու եք բաղադրիչների իրականացման մանրամասների համար:
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Ձևաչափված տվյալները գրեք բուֆերի մեջ, նոր տողին կցված:
///
/// Բոլոր հարթակներում նոր գիծը միայն LINE FEED նիշն է (`\n`/`U+000A`) (լրացուցիչ CARRIAGE RETURN (`\r`/`U+000D`) չկա):
///
/// Լրացուցիչ տեղեկությունների համար տե՛ս [`write!`]: Ձևաչափի տողի շարահյուսության վերաբերյալ տեղեկատվության համար տե՛ս [`std::fmt`]:
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Մոդուլը կարող է ներմուծել ինչպես `std::fmt::Write`, այնպես էլ `std::io::Write` և զանգահարել `write!` կամ այն իրականացնող օբյեկտների վրա, քանի որ օբյեկտները սովորաբար չեն իրականացնում երկուսն էլ:
/// Այնուամենայնիվ, մոդուլը պետք է ներմուծի traits որակավորված, որպեսզի նրանց անունները չհակասեն:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // օգտագործում է fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // օգտագործում է io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Նշում է անհասանելի ծածկագիրը:
///
/// Սա օգտակար է ցանկացած պահի, երբ կազմողը չի կարող որոշել, որ որոշ կոդ անհասանելի է: Օրինակ:
///
/// * Համապատասխան զենքեր պահակության պայմաններին:
/// * Օղակները, որոնք դինամիկորեն ավարտվում են:
/// * Կրկնվողները, որոնք դինամիկորեն դադարում են:
///
/// Եթե ծածկագրի անհասանելի լինելու որոշումը սխալ է ապացուցում, ծրագիրը անմիջապես ավարտվում է [`panic!`]-ով:
///
/// Այս մակրոի անապահով գործընկերը [`unreachable_unchecked`] գործառույթն է, որը ծածկագիրը ստանալու դեպքում կառաջացնի չսահմանված վարք:
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Սա միշտ կլինի [`panic!`]:
///
/// # Examples
///
/// Խաղի զենք:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // կազմելու սխալ, եթե մեկնաբանվում է
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3-ի ամենաաղքատ իրականացումներից մեկը
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Նշում է չիրականացված կոդը `խուճապի մատնվելով "not implemented" հաղորդագրությամբ:
///
/// Սա թույլ է տալիս ձեր կոդին մուտքագրել ստուգում, ինչը օգտակար է, եթե դուք նախատիպավորում եք կատարում կամ իրականացնում եք trait, որը պահանջում է բազմաթիվ մեթոդներ, որոնք դուք չեք նախատեսում օգտագործել բոլորը:
///
/// `unimplemented!`-ի և [`todo!`]-ի տարբերությունն այն է, որ չնայած `todo!`-ը գործառույթն ավելի ուշ իրականացնելու նպատակ է հաղորդում, և հաղորդագրությունը "not yet implemented" է, `unimplemented!`-ը նման պնդումներ չի անում:
/// Դրա հաղորդագրությունը "not implemented" է:
/// Որոշ IDE-ներ նշելու են «todo!»-ը:
///
/// # Panics
///
/// Սա միշտ կլինի [`panic!`], քանի որ `unimplemented!`-ը պարզապես կարճուղի է `panic!`-ի համար `ֆիքսված, հատուկ հաղորդագրությամբ:
///
/// `panic!`-ի նման, այս մակրոը ունի երկրորդ ձև ՝ հատուկ արժեքներ ցուցադրելու համար:
///
/// # Examples
///
/// Ասենք, որ մենք ունենք trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Մենք ուզում ենք `Foo`-ն իրականացնել 'MyStruct'-ի համար, բայց չգիտես ինչու, իմաստ ունի իրականացնել `bar()` ֆունկցիան:
/// `baz()` և `qux()`-ը դեռ պետք է սահմանվեն `Foo`-ի մեր իրականացման ընթացքում, բայց դրանց սահմանումներում մենք կարող ենք օգտագործել `unimplemented!`-ը `թույլ տալու, որ մեր կոդը կազմվի:
///
/// Մենք դեռ ուզում ենք, որ չիրականացված մեթոդների հասնելու դեպքում մեր ծրագիրը դադարեցնի գործարկումը:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` a `MyStruct`-ի համար անիմաստ է, ուստի այստեղ մենք ընդհանրապես տրամաբանություն չունենք:
/////
///         // Սա ցույց կտա "thread 'main' panicked at 'not implemented'":
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Մենք այստեղ որոշակի տրամաբանություն ունենք, և մենք կարող ենք հաղորդագրություն ավելացնել չիրականացվածին: ի ցույց դնելու մեր բացթողումը:
///         // Սա կցուցադրի ՝ "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Նշում է անավարտ ծածկագիր:
///
/// Սա կարող է օգտակար լինել, եթե դուք նախատիպ եք անում և պարզապես փնտրում եք ձեր կոդի տիպային ստուգումը:
///
/// [`unimplemented!`]-ի և `todo!`-ի տարբերությունն այն է, որ չնայած `todo!`-ը գործառույթն ավելի ուշ իրականացնելու նպատակ է հաղորդում, և հաղորդագրությունը "not yet implemented" է, `unimplemented!`-ը նման պնդումներ չի անում:
/// Դրա հաղորդագրությունը "not implemented" է:
/// Որոշ IDE-ներ նշելու են «todo!»-ը:
///
/// # Panics
///
/// Սա միշտ կլինի [`panic!`]:
///
/// # Examples
///
/// Ահա մի քանի ընթացիկ կոդի օրինակ: Մենք ունենք trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Մենք ուզում ենք `Foo`-ն իրականացնել մեր տեսակներից մեկի վրա, բայց նաև ուզում ենք նախ աշխատել հենց `bar()`-ի վրա: Որպեսզի մեր կոդը կազմվի, մենք պետք է `baz()` ներդնենք, որպեսզի կարողանանք օգտագործել `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // իրականացումը գնում է այստեղ
///     }
///
///     fn baz(&self) {
///         // եկեք հիմա չանհանգստանանք baz()-ի ներդրման գործով
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // մենք նույնիսկ չենք օգտագործում baz(), այնպես որ դա լավ է:
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Ներկառուցված մակրոների սահմանումներ:
///
/// Մակրո հատկությունների մեծ մասը (կայունություն, տեսանելիություն և այլն) վերցված են այստեղի սկզբնաղբյուրից, բացառությամբ ընդլայնման գործառույթների, որոնք մակրո մուտքերը վերածում են արդյունքների, այդ գործառույթները տրամադրվում է կազմողի կողմից:
///
///
pub(crate) mod builtin {

    /// Առաջացնում է կազմման ձախողումը տրված սխալի հաղորդագրության հետ, երբ բախվում է:
    ///
    /// Այս մակրոը պետք է օգտագործվի, երբ crate-ն օգտագործում է պայմանական կազմման ռազմավարություն ՝ սխալ պայմանների համար ավելի լավ սխալ հաղորդագրություններ տրամադրելու համար:
    ///
    /// Դա [`panic!`] կազմողի մակարդակի ձև է, բայց սխալ է արտանետում *կազմման ժամանակ, այլ ոչ* գործարկման պահին *:
    ///
    /// # Examples
    ///
    /// Երկու այդպիսի օրինակներ են մակրոները և `#[cfg]` միջավայրերը:
    ///
    /// Եթե մակրոը անվավեր արժեքներ է փոխանցվում, դուրս բերեք կազմողի ավելի լավ սխալ:
    /// Առանց վերջնական branch-ի, կազմողը դեռ սխալ է թողարկում, բայց սխալի հաղորդագրության մեջ նշված չեն երկու վավեր արժեքները:
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Ստեղծեք կազմողի սխալ, եթե մի շարք առանձնահատկություններից մեկը մատչելի չէ:
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Կառուցում է պարագաների ձևաչափման մյուս մակրոների պարամետրերը:
    ///
    /// Այս մակրոը գործում է ՝ յուրաքանչյուր անցած լրացուցիչ փաստարկի համար վերցնելով `{}` պարունակող ձևաչափման տողը բառացի:
    /// `format_args!` պատրաստում է լրացուցիչ պարամետրեր ՝ ապահովելու համար, որ արդյունքը կարող է մեկնաբանվել որպես տող և կանոնակարգել փաստարկները մեկ տիպի:
    /// 0անկացած արժեք, որն իրականացնում է [`Display`] trait, կարող է փոխանցվել `format_args!`, ինչպես նաև ցանկացած [`Debug`] իրականացում կարող է փոխանցվել `{:?}` ձևաչափման տողի շրջանակներում:
    ///
    ///
    /// Այս մակրոը արտադրում է [`fmt::Arguments`] տիպի արժեք: Օգտակար վերահղում կատարելու համար այս արժեքը կարող է փոխանցվել մակրոներին [`std::fmt`]-ի շրջանակներում:
    /// Ձևավորման բոլոր մյուս մակրոները ([«ձևաչափը»], [`write!`], [`println!`] և այլն) վստահված են այս մեկի միջոցով:
    /// `format_args!`, ի տարբերություն իր ստացված մակրոների, խուսափում է կույտերի բաշխումներից:
    ///
    /// Դուք կարող եք օգտագործել [`fmt::Arguments`] արժեքը, որը `format_args!` վերադարձնում է `Debug` և `Display` համատեքստերում, ինչպես տեսնում ենք ստորև:
    /// Օրինակը նաև ցույց է տալիս, որ `Debug` և `Display` ձևաչափը նույն բանի `ինտերպոլացված ձևաչափի տողը `format_args!`-ում:
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Լրացուցիչ տեղեկությունների համար տե՛ս [`std::fmt`]-ի փաստաթղթերը:
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Նույնը, ինչ `format_args`, բայց վերջում ավելացնում է նոր տող:
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Կոմպիլյացիայի ժամանակ ստուգում է շրջակա միջավայրի փոփոխականը:
    ///
    /// Այս մակրոը ընդլայնվելու է մինչև անվանված միջավայրի փոփոխականի արժեքը կազմողի ժամանակ `տալով `&'static str` տիպի արտահայտություն:
    ///
    ///
    /// Եթե շրջակա միջավայրի փոփոխականը սահմանված չէ, ապա կտեղադրվի կազմման սխալ:
    /// Կոմպիլյացիայի սխալ չթողարկելու համար փոխարենը օգտագործեք [`option_env!`] մակրոը:
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Դուք կարող եք անհատականացնել սխալի հաղորդագրությունը ՝ անցնելով մի տող ՝ որպես երկրորդ պարամետր:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Եթե `documentation` միջավայրի փոփոխականը սահմանված չէ, դուք կստանաք հետևյալ սխալը.
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Կոմպիլյացիայի պահին ընտրովի ստուգում է շրջակա միջավայրի փոփոխականությունը:
    ///
    /// Եթե անվանված միջավայրի փոփոխականը առկա է կոմպիլյացիայի ժամանակ, ապա այն կվերածվի `Option<&'static str>` տիպի արտահայտության, որի արժեքը `Some` է շրջակա միջավայրի փոփոխականի արժեքի:
    /// Եթե շրջակա միջավայրի փոփոխականը բացակայում է, ապա այն կավելանա մինչև `None`:
    /// Տե՛ս [`Option<T>`][Option] ՝ այս տեսակի վերաբերյալ լրացուցիչ տեղեկություններ ստանալու համար:
    ///
    /// Կոմպիլյացիայի ժամանակի սխալ երբեք չի արտանետվում այս մակրո օգտագործելու ժամանակ ՝ անկախ շրջակա միջավայրի փոփոխականի առկայությունից, թե ոչ:
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Նույնացուցիչները միացնում է մեկ նույնացուցիչի:
    ///
    /// Այս մակրոը տանում է ստորակետերով առանձնացված ցանկացած քանակի նույնացուցիչներ և բոլորն իրար միացնում է մեկում ՝ տալով արտահայտություն, որը նոր նույնացուցիչ է:
    /// Նկատի ունեցեք, որ հիգիենան այն դարձնում է այնպես, որ այս մակրոը չի կարող գրավել տեղական փոփոխականները:
    /// Բացի այդ, որպես ընդհանուր կանոն, մակրոները թույլատրվում են միայն կետում, հայտարարությունում կամ արտահայտման դիրքում:
    /// Դա նշանակում է, որ չնայած դուք կարող եք օգտագործել այս մակրոն առկա փոփոխականներին, գործառույթներին կամ մոդուլներին և այլն հղում կատարելու համար, դուք դրանով չեք կարող նորը սահմանել:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn համակցված պատահականություններ! (նոր, զվարճալի, անուն) { }//այս եղանակով օգտագործելի չէ:
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Բառերը միացնում է ստատիկական լարի կտորի:
    ///
    /// Այս մակրոը տանում է ստորակետերով առանձնացված ցանկացած քանակի տառատեսակներ ՝ տալով `&'static str` տիպի արտահայտություն, որը ներկայացնում է ձախից աջ միացված բոլոր բառակապակցությունները:
    ///
    ///
    /// Ամբողջ և լողացող կետի բառացիաները լարային են, որպեսզի դրանք միացվեն:
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ընդլայնվում է գծի համարի վրա, որի վրա այն կանչվել է:
    ///
    /// [`column!`]-ի և [`file!`]-ի հետ այս մակրոները ծրագրավորողների համար աղբյուրի գտնվելու վայրի վերաբերյալ կարգաբերման տեղեկատվություն են տրամադրում:
    ///
    /// Ընդլայնված արտահայտությունն ունի `u32` տեսակ և հիմնված է 1-ի վրա, ուստի յուրաքանչյուր ֆայլի առաջին տողը գնահատում է 1-ը, երկրորդը ՝ 2 և այլն:
    /// Սա համընկնում է սովորական կազմողների կամ սիրված խմբագիրների սխալ հաղորդագրությունների հետ:
    /// Վերադարձված տողը *պարտադիր չէ* ինքը `line!` կոչման տողը, այլ ավելի շուտ առաջին մակրո կոչումն է, որը տանում է դեպի `line!` մակրո կոչման:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ընդլայնվում է սյունակի համարի վրա, որի վրա այն կանչվել է:
    ///
    /// [`line!`]-ի և [`file!`]-ի հետ այս մակրոները ծրագրավորողների համար աղբյուրի գտնվելու վայրի վերաբերյալ կարգաբերման տեղեկատվություն են տրամադրում:
    ///
    /// Ընդլայնված արտահայտությունն ունի `u32` տեսակ և հիմնված է 1-ի վրա, ուստի յուրաքանչյուր տողի առաջին սյունը գնահատում է 1-ը, երկրորդը `2 և այլն:
    /// Սա համընկնում է սովորական կազմողների կամ սիրված խմբագիրների սխալ հաղորդագրությունների հետ:
    /// Վերադարձված սյունակը *պարտադիր չէ*`column!` կոչման տողը, այլ ավելի շուտ առաջին մակրո կոչումն է, որը տանում է դեպի `column!` մակրո կոչման:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Ընդլայնվում է մինչև այն ֆայլի անունը, որում այն կանչվել է:
    ///
    /// [`line!`]-ի և [`column!`]-ի հետ այս մակրոները ծրագրավորողների համար աղբյուրի գտնվելու վայրի վերաբերյալ կարգաբերման տեղեկատվություն են տրամադրում:
    ///
    /// Ընդլայնված արտահայտությունն ունի `&'static str` տիպ, և վերադարձված ֆայլը ոչ թե `file!` մակրոյի կոչումն է, այլ ավելի շուտ առաջին մակրո կոչումն է, որը տանում է մինչև `file!` մակրո գործարկման:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Լարում է իր փաստարկները:
    ///
    /// Այս մակրոը կտա `&'static str` տիպի արտահայտություն, որը մակրոին փոխանցված բոլոր tokens-ի լարայինացումն է:
    /// Ոչ մի սահմանափակում չի դրվում բուն մակրո կոչման շարահյուսության վրա:
    ///
    /// Նշենք, որ tokens մուտքի ընդլայնված արդյունքները կարող են փոխվել future-ում: Պետք է զգույշ լինել, եթե ապավինեք արդյունքին:
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Որպես տող ներառում է UTF-8 կոդավորված ֆայլ:
    ///
    /// Ֆայլը տեղակայված է ընթացիկ ֆայլի համեմատ (նման է, թե ինչպես են հայտնաբերվում մոդուլները):
    /// Տրամադրված ուղին մեկնաբանվում է պլատֆորմի վրա `կազմման ժամանակ:
    /// Այսպիսով, օրինակ, Windows արահետով պարունակվող կոչումը `\` հետադարձ շեղերով չի կազմվի ճիշտ Unix-ի վրա:
    ///
    ///
    /// Այս մակրոը կտա `&'static str` տիպի արտահայտություն, որը ֆայլի պարունակությունն է:
    ///
    /// # Examples
    ///
    /// Ենթադրենք, որ նույն գրացուցակում կա երկու ֆայլ `հետևյալ բովանդակությամբ.
    ///
    /// Ֆայլ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ֆայլ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs'-ի կազմումը և արդյունքում ստացված երկուական գործարկումը կտպագրի "adiós"-ը:
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ներառում է ֆայլ ՝ որպես հղում դեպի բայթ զանգված:
    ///
    /// Ֆայլը տեղակայված է ընթացիկ ֆայլի համեմատ (նման է, թե ինչպես են հայտնաբերվում մոդուլները):
    /// Տրամադրված ուղին մեկնաբանվում է պլատֆորմի վրա `կազմման ժամանակ:
    /// Այսպիսով, օրինակ, Windows արահետով պարունակվող կոչումը `\` հետադարձ շեղերով չի կազմվի ճիշտ Unix-ի վրա:
    ///
    ///
    /// Այս մակրոը կտա `&'static [u8; N]` տիպի արտահայտություն, որը ֆայլի պարունակությունն է:
    ///
    /// # Examples
    ///
    /// Ենթադրենք, որ նույն գրացուցակում կա երկու ֆայլ `հետևյալ բովանդակությամբ.
    ///
    /// Ֆայլ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ֆայլ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs'-ի կազմումը և արդյունքում ստացված երկուական գործարկումը կտպագրի "adiós"-ը:
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ընդլայնվում է մի տողի, որը ներկայացնում է ընթացիկ մոդուլի ուղին:
    ///
    /// Ընթացիկ մոդուլի ուղին կարելի է համարել որպես մոդուլների հիերարխիա, որոնք վերադառնում են դեպի crate root:
    /// Վերադարձված ուղու առաջին բաղադրիչը ներկայումս կազմվող crate-ի անունն է:
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Գնահատում է կազմաձևման ժամանակ կազմաձևի դրոշների բուլյան համադրությունները:
    ///
    /// Բացի `#[cfg]` հատկանիշից, այս մակրոը տրամադրվում է ՝ կազմաձևման դրոշների բուլյան արտահայտության գնահատումը թույլ տալու համար:
    /// Սա հաճախ հանգեցնում է պակաս կրկնօրինակված կոդի:
    ///
    /// Այս մակրոին տրված շարահյուսությունը նույն շարահյուսությունն է, ինչ [`cfg`] հատկանիշը:
    ///
    /// `cfg!`, ի տարբերություն `#[cfg]`-ի, չի հեռացնում որևէ ծածկագիր և գնահատում է միայն ճիշտ կամ կեղծ:
    /// Օրինակ, if/else արտահայտության բոլոր բլոկները պետք է վավեր լինեն, երբ պայմանի համար օգտագործվում է `cfg!`, անկախ այն բանից, թե ինչ է գնահատում `cfg!`-ը:
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ֆայլը վերլուծում է որպես արտահայտություն կամ նյութ ՝ ըստ համատեքստի:
    ///
    /// Ֆայլը տեղակայված է ընթացիկ ֆայլի համեմատ (նման է, թե ինչպես են հայտնաբերվում մոդուլները): Տրամադրված ուղին մեկնաբանվում է պլատֆորմի վրա `կազմման ժամանակ:
    /// Այսպիսով, օրինակ, Windows արահետով պարունակվող կոչումը `\` հետադարձ շեղերով չի կազմվի ճիշտ Unix-ի վրա:
    ///
    /// Այս մակրո օգտագործելը հաճախ վատ գաղափար է, քանի որ եթե ֆայլը վերլուծվում է որպես արտահայտություն, ապա այն ոչ հիգիենիկ կերպով տեղադրվելու է շրջակա կոդի մեջ:
    /// Սա կարող է հանգեցնել նրան, որ փոփոխականները կամ գործառույթները տարբեր կլինեն այն բանից, ինչ ֆայլն ակնկալում էր, եթե առկա ֆայլում կան փոփոխականներ կամ գործառույթներ, որոնք ունեն նույն անունը:
    ///
    ///
    /// # Examples
    ///
    /// Ենթադրենք, որ նույն գրացուցակում կա երկու ֆայլ `հետևյալ բովանդակությամբ.
    ///
    /// Ֆայլ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Ֆայլ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs'-ի կազմումը և արդյունքում ստացված երկուական գործարկումը կտպագրի "🙈🙊🙉🙈🙊🙉"-ը:
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Պնդում է, որ բուլյան արտահայտությունը գործարկման ժամանակ `true` է:
    ///
    /// Սա կանչելու է [`panic!`] մակրոը, եթե տրամադրված արտահայտությունը հնարավոր չէ գնահատել `true` ՝ գործարկման ժամանակ:
    ///
    /// # Uses
    ///
    /// Հայտարարությունները միշտ ստուգվում են և՛ կարգաբերումներից, և՛ թողարկումներից, և չեն կարող անջատվել:
    /// Տե՛ս [`debug_assert!`] պնդումների համար, որոնք լռելյայն թույլ չեն տրված թողարկումների կառուցումներում:
    ///
    /// Անվտանգ ծածկագիրը կարող է ապավինել `assert!`-ին `գործադրելու ժամանակի անփոփոխությունը, որը խախտելու դեպքում կարող է հանգեցնել անապահովության:
    ///
    /// `assert!`-ի օգտագործման այլ դեպքերը ներառում են անվտանգ ծածկագրում աշխատող ժամանակի անփոփոխների փորձարկում և կիրառում (որոնց խախտումը չի կարող հանգեցնել անապահովության):
    ///
    ///
    /// # Պատվերով հաղորդագրություններ
    ///
    /// Այս մակրոը ունի երկրորդ ձև, որտեղ panic մաքսային հաղորդագրությունը կարող է տրամադրվել ձևաչափման փաստարկներով կամ առանց դրանց:
    /// Տե՛ս [`std::fmt`] շարահյուսության համար ՝ այս ձևի համար:
    /// Որպես ձևաչափի փաստարկներ օգտագործվող արտահայտությունները կգնահատվեն միայն այն դեպքում, եթե պնդումը ձախողվի:
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // այս պնդումների համար panic հաղորդագրությունը տրված արտահայտության լարային արժեքն է:
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // շատ պարզ գործառույթ
    ///
    /// assert!(some_computation());
    ///
    /// // պնդել պատվերով հաղորդագրությամբ
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Անսարք հավաքում:
    ///
    /// Կարդացեք [unstable book]-ը օգտագործման համար:
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM ոճի գծային հավաքույթ:
    ///
    /// Կարդացեք [unstable book]-ը օգտագործման համար:
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Մոդուլի մակարդակի գծային հավաքույթ:
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Տպագրությունները tokens-ին փոխանցեցին ստանդարտ արտադրանքի մեջ:
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Միացնում և անջատում է այլ մակրոների կարգաբերման համար օգտագործվող հետագծման ֆունկցիոնալությունը:
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Հատկանիշ մակրո, որն օգտագործվում է ստացված ածանցյալ մակրոներ կիրառելու համար:
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Հատկանիշի մակրոն կիրառվում է գործառույթի վրա `այն միավորի փորձարկման վերածելու համար:
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Հատկանիշի մակրոն կիրառվում է գործառույթի վրա `այն հենանիշային թեստի վերածելու համար:
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` և `#[bench]` մակրոների իրականացման մանրամասնություն:
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Հատկորոշիչ մակրոն դիմել է ստատիկային ՝ այն որպես համաշխարհային բաշխիչ գրանցելու համար:
    ///
    /// Տես նաև [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html):
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Պահում է այն իրը, որի վրա կիրառվում է, եթե անցած ուղին մատչելի է, և հակառակ դեպքում այն հեռացնում է:
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Ընդլայնում է բոլոր `#[cfg]` և `#[cfg_attr]` հատկանիշները այն ծածկագրում, որի վրա կիրառվում է:
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` կազմողի անկայուն իրականացման մանրամասներ, մի օգտագործեք:
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` կազմողի անկայուն իրականացման մանրամասներ, մի օգտագործեք:
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}