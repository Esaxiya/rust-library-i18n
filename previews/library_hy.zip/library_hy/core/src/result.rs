//! `Result` տիպի հետ սխալ վարվելիս:
//!
//! [`Result<T, E>`][`Result`] սխալների վերադարձման և բազմացման համար օգտագործվող տեսակն է:
//! Այն թվանշան է ՝ [`Ok(T)`], հաջողություն ներկայացնող և արժեք պարունակող տարբերակներով, և [`Err(E)`] ՝ սխալ ներկայացնող և սխալի արժեք պարունակող:
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Գործառույթները վերադարձնում են [`Result`], երբ որ սխալներն են սպասվում և վերականգնվում: `std` crate-ում [`Result`]-ը առավելապես օգտագործվում է [I/O](../../std/io/index.html)-ի համար:
//!
//! [`Result`] վերադարձող պարզ գործառույթը կարող է սահմանվել և օգտագործվել այնպես, ինչպես հետևյալն է.
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [«Արդյունքի»] վրա նախշերի համընկնումը պարզ և պարզ է պարզ դեպքերի համար, բայց [`Result`]-ն ունի հարմարավետության որոշ մեթոդներ, որոնք դրա հետ աշխատանքը ավելի լակոն են դարձնում:
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` և `is_err` մեթոդներն անում են այն, ինչ ասում են:
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` սպառում է `Result`-ը և արտադրում է մեկ այլը:
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // Հաշվարկը շարունակելու համար օգտագործեք `and_then`:
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // Սխալը կարգավորելու համար օգտագործեք `or_else`:
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Սպառեք արդյունքը և հետ բերեք պարունակությունը `unwrap`-ով:
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Արդյունքները պետք է օգտագործվեն
//!
//! Սխալները ցույց տալու համար վերադարձման արժեքների օգտագործման ընդհանուր խնդիրն այն է, որ վերադարձի արժեքը հեշտ է անտեսել, այդպիսով չկարողանալով կարգավորել սխալը:
//! [`Result`] նշվում է `#[must_use]` հատկանիշի հետ, ինչը կստիպի կազմողին նախազգուշացնել, երբ Արդյունքի արժեքը անտեսվի:
//! Սա [`Result`]-ը հատկապես օգտակար է դարձնում գործառույթներով, որոնք կարող են սխալներ ունենալ, բայց այլապես օգտակար արժեք չեն վերադարձնում:
//!
//! Հաշվի առեք I/O տիպերի համար [`Write`] trait-ով սահմանված [`write_all`] մեթոդը.
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`]-ի իրական սահմանում օգտագործվում է [`io::Result`], որը պարզապես [«Արդյունք»]-ի հոմանիշն է<T, `[`io: :Error`]`>`*
//!
//! Այս մեթոդը արժեք չի առաջացնում, բայց գրելը կարող է ձախողվել: Կարևոր է կարգավորել սխալի գործը, և *ոչ* գրել այսպիսի մի բան.
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Եթե `write_all` սխալ լինի, ապա մենք երբեք չենք իմանա, քանի որ վերադարձի արժեքը անտեսվում է:
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Եթե * անում եք, գրեք, որ Rust-ում կազմողը ձեզ նախազգուշացում կտա (ըստ լռելյայն, վերահսկվում է `unused_must_use` lint-ի կողմից):
//!
//! Կարող եք փոխարենը, եթե չեք ցանկանում կարգավորել սխալը, պարզապես պնդեք հաջողությունը [`expect`]-ի հետ:
//! Սա panic կլինի, եթե գրառումը ձախողվի, տրամադրելով մարգինալորեն օգտակար հաղորդագրություն ՝ նշելով, թե ինչու.
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! Կարող եք նաև պարզապես պնդել հաջողությունը.
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! Կամ տարածեք սխալը զանգի տուփի վրա [`?`]-ով.
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # Հարցական գործառույթը, `?`
//!
//! Կոդ գրելիս, որը կանչում է [`Result`] տիպը վերադարձնող շատ գործառույթներ, սխալի հետ վարվելը կարող է ձանձրալի լինել:
//! Հարցման օպերատորը ՝ [`?`]-ը, թաքցնում է զանգի տուփի վրա տարածման սխալների կաթսայատան մի մասը:
//!
//! Այն փոխարինում է սա.
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Սխալի վաղ վերադարձը
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! Դրանով.
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Սխալի վաղ վերադարձը
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *Դա շատ ավելի հաճելի է:*
//!
//! [`?`]-ով արտահայտությունն ավարտելը կհանգեցնի չփաթաթված հաջողության ([`Ok`]) արժեքի, եթե արդյունքը [`Err`] չէ, որի դեպքում [`Err`]-ը շուտ է վերադարձվում կցող գործառույթից:
//!
//!
//! [`?`] կարող է օգտագործվել միայն այն գործառույթներում, որոնք վերադարձնում են [`Result`] ՝ իր տրամադրած [`Err`]-ի վաղ վերադարձի պատճառով:
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` մի տեսակ է, որը ներկայացնում է կամ հաջողություն ([`Ok`]) կամ ձախողում ([`Err`]):
///
/// Մանրամասների համար տես [module documentation](self):
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// Պարունակում է հաջողության արժեքը
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Պարունակում է սխալի արժեք
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// Տիպի իրականացում
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // Հարցում պարունակվող արժեքները
    /////////////////////////////////////////////////////////////////////////

    /// Վերադարձնում է `true`, եթե արդյունքը [`Ok`] է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Վերադարձնում է `true`, եթե արդյունքը [`Err`] է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Վերադարձնում է `true`, եթե արդյունքը տրված արժեքը պարունակող [`Ok`] արժեք է:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Վերադարձնում է `true`, եթե արդյունքը տրված արժեքը պարունակող [`Err`] արժեք է:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Յուրաքանչյուր տարբերակի ադապտեր
    /////////////////////////////////////////////////////////////////////////

    /// Փոխարկվում է `Result<T, E>`-ից [`Option<T>`]:
    ///
    /// `self`-ը վերափոխում է [`Option<T>`]-ի ՝ սպառում է `self` և վերացնում սխալը, եթե այդպիսիք կան:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// Փոխարկվում է `Result<T, E>`-ից [`Option<E>`]:
    ///
    /// `self`-ը վերափոխում է [`Option<E>`]-ի ՝ սպառում է `self` և վերացնում հաջողության արժեքը, եթե այդպիսիք կան:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Հղումների հետ աշխատելու ադապտեր
    /////////////////////////////////////////////////////////////////////////

    /// Փոխարկվում է `&Result<T, E>`-ից `Result<&T, &E>`:
    ///
    /// Արտադրում է նոր `Result`, որը պարունակում է հղում բնօրինակին ՝ բնօրինակը թողնելով տեղում:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// Փոխարկվում է `&mut Result<T, E>`-ից `Result<&mut T, &mut E>`:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Վերափոխելով պարունակվող արժեքները
    /////////////////////////////////////////////////////////////////////////

    /// Քարտեզում է `Result<T, E>`-ից `Result<U, E>` ՝ գործառույթ կիրառելով պարունակվող [`Ok`] արժեքի վրա ՝ թողնելով [`Err`] արժեքը անձեռնմխելի:
    ///
    ///
    /// Այս ֆունկցիան կարող է օգտագործվել երկու գործառույթի արդյունքներ կազմելու համար:
    ///
    /// # Examples
    ///
    /// Տողի վրա գրեք թվերը ՝ բազմապատկելով երկուով:
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// Կիրառում է պարունակվող արժեքի գործառույթը (եթե [`Ok`]), կամ վերադարձնում է տրամադրված լռելյայնը (եթե [`Err`]):
    ///
    /// `map_or`-ին փոխանցված փաստարկները անհամբերորեն գնահատվում են.եթե գործառույթի զանգի արդյունք եք փոխանցում, խորհուրդ է տրվում օգտագործել [`map_or_else`], որը ծուլորեն գնահատվում է:
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// Քարտեզում է `Result<T, E>`-ից `U` ՝ գործառույթ կիրառելով պարունակվող [`Ok`] արժեքի կամ հետադարձ գործառույթ պարունակող [`Err`] արժեքի վրա:
    ///
    ///
    /// Այս գործառույթը կարող է օգտագործվել հաջող արդյունքի փաթեթավորման համար `սխալը գործածելիս:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// Քարտեզում է `Result<T, E>`-ից `Result<T, F>` ՝ գործառույթ կիրառելով պարունակվող [`Err`] արժեքի վրա ՝ թողնելով [`Ok`] արժեքը անձեռնմխելի:
    ///
    ///
    /// Այս ֆունկցիան կարող է օգտագործվել սխալի հետ աշխատելիս հաջող արդյունք անցնելու համար:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Իտերատոր կոնստրուկտորներ
    /////////////////////////////////////////////////////////////////////////

    /// Վերադարձնում է կրկնիչը հնարավոր պարունակվող արժեքի նկատմամբ:
    ///
    /// Կրկնիչը տալիս է մեկ արժեք, եթե արդյունքը [`Result::Ok`] է, հակառակ դեպքում ՝ ոչ մեկը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Վերադարձնում է փոփոխվող կրկնիչը հնարավոր պարունակվող արժեքի նկատմամբ:
    ///
    /// Կրկնիչը տալիս է մեկ արժեք, եթե արդյունքը [`Result::Ok`] է, հակառակ դեպքում ՝ ոչ մեկը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Բուլյան գործողություններ արժեքների վրա ՝ անհամբեր և ծույլ
    /////////////////////////////////////////////////////////////////////////

    /// Վերադարձնում է `res`, եթե արդյունքը [`Ok`] է, հակառակ դեպքում վերադարձնում է `self` [`Err`] արժեքը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Theանգահարում է `op`-ին, եթե արդյունքը [`Ok`] է, հակառակ դեպքում վերադարձնում է `self`-ի [`Err`] արժեքը:
    ///
    ///
    /// Այս ֆունկցիան կարող է օգտագործվել վերահսկողության հոսքի համար ՝ հիմնված `Result` արժեքների վրա:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Վերադարձնում է `res`, եթե արդյունքը [`Err`] է, հակառակ դեպքում վերադարձնում է `self` [`Ok`] արժեքը:
    ///
    /// `or`-ին փոխանցված փաստարկները անհամբերորեն գնահատվում են.եթե գործառույթի զանգի արդյունք եք փոխանցում, խորհուրդ է տրվում օգտագործել [`or_else`], որը ծուլորեն գնահատվում է:
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Theանգահարում է `op`-ին, եթե արդյունքը [`Err`] է, հակառակ դեպքում վերադարձնում է `self`-ի [`Ok`] արժեքը:
    ///
    ///
    /// Այս ֆունկցիան կարող է օգտագործվել կառավարման հոսքի համար `ելնելով արդյունքի արժեքներից:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// Վերադարձնում է պարունակվող [`Ok`] արժեքը կամ տրամադրված լռելյայնը:
    ///
    /// `unwrap_or`-ին փոխանցված փաստարկները անհամբերորեն գնահատվում են.եթե գործառույթի զանգի արդյունք եք փոխանցում, խորհուրդ է տրվում օգտագործել [`unwrap_or_else`], որը ծուլորեն գնահատվում է:
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// Վերադարձնում է պարունակվող [`Ok`] արժեքը կամ հաշվարկում այն փակման պահից:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// Վերադարձնում է պարունակվող [`Ok`] արժեքը, սպառում է `self` արժեքը, առանց ստուգելու, որ արժեքը [`Err`] չէ:
    ///
    ///
    /// # Safety
    ///
    /// Այս մեթոդը [`Err`]-ով զանգելը *[չսահմանված վարք]* է:
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Չսահմանված պահվածք!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անվտանգության պայմանագիրը պետք է պահպանվի զանգահարողի կողմից:
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// Վերադարձնում է պարունակվող [`Err`] արժեքը, սպառում է `self` արժեքը, առանց ստուգելու, որ արժեքը [`Ok`] չէ:
    ///
    ///
    /// # Safety
    ///
    /// Այս մեթոդը [`Ok`]-ով զանգելը *[չսահմանված վարք]* է:
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Չսահմանված պահվածք!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անվտանգության պայմանագիրը պետք է պահպանվի զանգահարողի կողմից:
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// Քարտեզում է `Result<&T, E>`-ը `Result<T, E>`-ին `պատճենելով `Ok` մասի բովանդակությունը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// Քարտեզում է `Result<&mut T, E>`-ը `Result<T, E>`-ին `պատճենելով `Ok` մասի բովանդակությունը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// Քարտեզում է `Result<&T, E>`-ը `Result<T, E>`-ին `կլոնավորելով `Ok` մասի պարունակությունը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// Քարտեզում է `Result<&mut T, E>`-ը `Result<T, E>`-ին `կլոնավորելով `Ok` մասի պարունակությունը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// Վերադարձնում է պարունակվող [`Ok`] արժեքը, սպառում է `self` արժեքը:
    ///
    /// # Panics
    ///
    /// Panics եթե արժեքը [`Err`] է, panic հաղորդագրությամբ, ներառյալ փոխանցված հաղորդագրությունը, և [`Err`]-ի պարունակությամբ:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// Վերադարձնում է պարունակվող [`Ok`] արժեքը, սպառում է `self` արժեքը:
    ///
    /// Քանի որ այս գործառույթը կարող է լինել panic, դրա օգտագործումը հիմնականում հուսալքված է:
    /// Փոխարենը, նախընտրեք օգտագործել օրինակների համընկնումը և հստակ կարգավորել [`Err`] գործը կամ զանգահարել [`unwrap_or`], [`unwrap_or_else`] կամ [`unwrap_or_default`]:
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics եթե արժեքը [`Err`] է, [[Err »] արժեքով տրամադրված panic հաղորդագրությամբ:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// Վերադարձնում է պարունակվող [`Err`] արժեքը, սպառում է `self` արժեքը:
    ///
    /// # Panics
    ///
    /// Panics եթե արժեքը [`Ok`] է, panic հաղորդագրությամբ, ներառյալ փոխանցված հաղորդագրությունը, և [`Ok`]-ի պարունակությամբ:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// Վերադարձնում է պարունակվող [`Err`] արժեքը, սպառում է `self` արժեքը:
    ///
    /// # Panics
    ///
    /// Panics, եթե արժեքը [`Ok`] է, [[Ok »] արժեքի կողմից տրամադրված panic մաքսային հաղորդագրությամբ:
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// Վերադարձնում է պարունակվող [`Ok`] արժեքը կամ լռելյայն
    ///
    /// Սպառում է `self` փաստարկը, ապա, եթե [`Ok`], վերադարձնում է պարունակվող արժեքը, հակառակ դեպքում, եթե [`Err`], վերադարձնում է այդ տեսակի կանխադրված արժեքը:
    ///
    ///
    /// # Examples
    ///
    /// Մի տողը վերափոխում է ամբողջ թվերի ՝ վատ կազմավորված տողերը վերածելով 0-ի (ամբողջ թվերի լռելյայն արժեքը):
    /// [`parse`] փոխում է տողը ցանկացած այլ տիպի, որն իրականացնում է [`FromStr`] ՝ [`Err`]-ը վերադարձնելով սխալի վրա:
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// Վերադարձնում է պարունակվող [`Ok`] արժեքը, բայց երբեք panics:
    ///
    /// Ի տարբերություն [`unwrap`]-ի, այս մեթոդը երբեք հայտնի չէ panic արդյունքների տեսակների համար, որոնց համար ներդրված է:
    /// Հետևաբար, այն կարող է օգտագործվել `unwrap`-ի փոխարեն, որպես պահպանվողության երաշխիք, որը չի հաջողվի կազմել, եթե `Result`-ի սխալի տեսակը հետագայում վերափոխվի այն սխալի, որն իրականում կարող է առաջանալ:
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// Փոխակերպվում է `Result<T, E>` (կամ `&Result<T, E>`)-ից `Result<&<T as Deref>::Target, &E>`:
    ///
    /// [`Deref`](crate::ops::Deref)-ի միջոցով պարտադրում է բնօրինակ [`Result`]-ի [`Ok`] տարբերակը և վերադարձնում նոր [`Result`]-ը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// Փոխակերպվում է `Result<T, E>` (կամ `&mut Result<T, E>`)-ից `Result<&mut <T as DerefMut>::Target, &mut E>`:
    ///
    /// [`DerefMut`](crate::ops::DerefMut)-ի միջոցով պարտադրում է բնօրինակ [`Result`]-ի [`Ok`] տարբերակը և վերադարձնում նոր [`Result`]-ը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// Տեղափոխում է `Option`-ի `Result`-ը `Result`-ի `Option`-ի մեջ:
    ///
    /// `Ok(None)` քարտեզագրվելու է `None`:
    /// `Ok(Some(_))` և `Err(_)`-ը գծագրվելու են `Some(Ok(_))` և `Some(Err(_))`:
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// Փոխարկվում է `Result<Result<T, E>, E>`-ից `Result<T, E>`
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Հարթեցումը միանգամից հեռացնում է միայն մեկ մակարդակի բնադրումը.
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// Վերադարձնում է [`Ok`] արժեքը, եթե `self` `Ok` է, և [`Err`] արժեքը, եթե `self` `Err` է:
    ///
    /// Այլ կերպ ասած, այս ֆունկցիան վերադարձնում է `Result<T, T>`-ի արժեքը (`T`), անկախ նրանից `այդ արդյունքը `Ok` կամ `Err` է, թե ոչ:
    ///
    /// Սա կարող է օգտակար լինել API-ների հետ համատեղ, ինչպիսիք են [`Atomic*::compare_exchange`] կամ [`slice::binary_search`], բայց միայն այն դեպքերում, երբ ձեզ չի հետաքրքրում `արդյունքը `Ok` է, թե ոչ:
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// Սա մեթոդի կոդի չափը նվազեցնելու համար առանձին գործառույթ է
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait իրականացում
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Վերադարձնում է սպառող կրկնիչը հնարավոր պարունակվող արժեքի նկատմամբ:
    ///
    /// Կրկնիչը տալիս է մեկ արժեք, եթե արդյունքը [`Result::Ok`] է, հակառակ դեպքում ՝ ոչ մեկը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Արդյունքը կրկնիչները
/////////////////////////////////////////////////////////////////////////////

/// [`Result`]-ի [`Ok`] տարբերակին հղում կատարելու կրկնիչ:
///
/// Կրկնիչը տալիս է մեկ արժեք, եթե արդյունքը [`Ok`] է, հակառակ դեպքում ՝ ոչ մեկը:
///
/// Ստեղծվել է [`Result::iter`]-ի կողմից:
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`]-ի [`Ok`] տարբերակին անփոփոխ հղում կատարելու կրկնիչ:
///
/// Ստեղծվել է [`Result::iter_mut`]-ի կողմից:
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Result`]-ի [`Ok`] տարբերակի արժեքի կրկնիչը
///
/// Կրկնիչը տալիս է մեկ արժեք, եթե արդյունքը [`Ok`] է, հակառակ դեպքում ՝ ոչ մեկը:
///
/// Այս կառուցվածքը ստեղծվում է X001 մեթոդով [`Result`]-ի վրա (տրամադրված է [`IntoIterator`] trait-ի կողմից):
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// Վերցնում է յուրաքանչյուր տարր `Iterator`-ում. Եթե դա `Err` է, այլևս ոչ մի տարր չի վերցվում, և `Err`-ը վերադարձվում է:
    /// Եթե `Err` տեղի չունենա, վերադարձվում է յուրաքանչյուր `Result`-ի արժեքներով տարա:
    ///
    /// Ահա մի օրինակ, որն ավելացնում է vector-ի յուրաքանչյուր ամբողջ թիվ ՝ ստուգելով արտահոսքի առկայությունը.
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// Ահա ևս մեկ օրինակ, որը փորձում է մեկը մյուսին հանել ամբողջ թվերի ցուցակից ՝ այս անգամ ստուգելով հոսքի պակասը.
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// Ահա մի տարբերակ նախորդ օրինակի վրա, որը ցույց է տալիս, որ առաջին `Err`-ից հետո `iter`-ից այլ տարրեր չեն վերցվում:
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Քանի որ երրորդ տարրը ենթահոսք է առաջացրել, այլ տարրեր չեն վերցվել, ուստի `shared`-ի վերջնական արժեքը 6 է (= `3 + 2 + 1`), ոչ թե 16:
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Սա կարող է փոխարինվել Iterator::scan-ով, երբ այս կատարողականի սխալը փակվի:
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}