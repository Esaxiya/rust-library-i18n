//! Էքսպոնենտ գնահատողը:

/// Գտնում է `k_0`-ն այնպիսին, ինչպիսին `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`-ն է:
///
/// Սա օգտագործվում է մոտավոր `k = ceil(log_10 (mant * 2^exp))`;
/// իրական `k`-ը կամ `k_0` է կամ `k_0+1`:
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits եթե mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2), հետեւաբար, սա միշտ թերագնահատում է (կամ ճշգրիտ է), բայց ոչ շատ:
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}