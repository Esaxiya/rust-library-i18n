//! Գրեթե ուղղակի (բայց փոքր-ինչ օպտիմիզացված) Rust թարգմանությունը «Լողացող կետերի թվերի արագ և ճշգրիտ տպում» [^ 1] Նկար 3-ի:
//!
//!
//! [^1]: Burger, RG և Dybvig, RK 1996. Լողացող կետերի համարների տպագրություն
//!   արագ և ճշգրիտ: SIGPLAN Ոչ31, 5 (1996 թ. Մայիս), 108-116:

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// «Թվանշանի» նախահաշվարկված զանգվածները 10 ^ (2 ^ n) համար
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// օգտագործելի է միայն այն դեպքում, երբ `x < 16 * scale`;`scaleN`-ը պետք է լինի `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Dragon-ի ամենակարճ ռեժիմի իրականացումը:
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // Հայտնի է, որ ձևաչափելու համար `v` համարը `
    // - հավասար է `mant * 2^exp`;
    // - նախնական տեսակով նախորդում է `(mant - 2 *minus)* 2^exp`;և
    // - որին հաջորդում է `(mant + 2 *plus)* 2^exp`-ը բնօրինակ տիպում:
    //
    // ակնհայտ է, որ `minus` և `plus` չեն կարող զրո լինել: (անսահմանության համար մենք օգտագործում ենք տիրույթից դուրս արժեքներ): նաև ենթադրում ենք, որ գոնե մեկ նիշ է գոյանում, այսինքն `mant`-ը նույնպես չի կարող զրո լինել:
    //
    // սա նաև նշանակում է, որ `low = (mant - minus)*2^exp`-ի և `high = (mant + plus)* 2^exp`-ի միջև ցանկացած թիվ կհամապատասխանի այս ճշգրիտ լողացող կետի թվին, որի սահմանները ներառված կլինեն, երբ բուն մանտիսան հավասար էր (այսինքն `!mant_was_odd`):
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` է
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // գնահատեք `k_0`-ը `10^(k_0-1) < high <= 10^(k_0+1)`-ին բավարարող բնօրինակ մուտքերից:
    // ամուր կապված `k` բավարարող `10^(k-1) < high <= 10^k`-ը հաշվարկվում է ավելի ուշ:
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // փոխակերպել `{mant, plus, minus} * 2^exp`-ը կոտորակային ձևի, որպեսզի.
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // բաժանել `mant`-ը `10^k`-ի վրա: այժմ `scale / 10 < mant + plus <= scale * 10`:
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // շտկում, երբ `mant + plus > scale` (կամ `>=`):
    // մենք իրականում չենք փոփոխում `scale`-ը, քանի որ փոխարենը կարող ենք բաց թողնել սկզբնական բազմապատկումը:
    // այժմ `scale < mant + plus <= scale * 10`, և մենք պատրաստ ենք թվանշաններ առաջացնել:
    //
    // նշենք, որ `d[0]`*կարող է* լինել զրո, երբ `scale - plus < mant < scale`:
    // այս դեպքում կլորացման պայմանը (`up` ներքևում) անմիջապես կգործարկվի:
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // համարժեք է `scale`-ի 10-ով մասշտաբավորմանը
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` թվանշանների առաջացման համար:
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // անփոփոխներ, որտեղ `d[0..n-1]` մինչ օրս գեներացված թվանշաններ են.
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (այսպիսով `mant / scale < 10`), որտեղ `d[i..j]`-ը կարճագրություն է `d [i] * 10 ^ (ji) +-ի համար
        // + d [j-1] * 10 + d[j]`:

        // առաջացնում է մեկ նիշ. `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // սա փոփոխված Dragon ալգորիթմի պարզեցված նկարագրությունն է:
        // Հարմարավետության համար շատ միջանկյալ ածանցյալներ և ամբողջականության փաստարկներ բաց են թողնված:
        //
        // սկսեք փոփոխված անփոփոխներից, քանի որ մենք նորացրել ենք `n`-ը.
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ենթադրենք, որ `d[0..n-1]`-ը `low`-ի և `high`-ի միջև ամենակարճ ներկայացումն է, այսինքն `d[0..n-1]`-ը բավարարում է հետևյալը, բայց `d[0..n-2]`-ը` ոչ:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (բիժեկտիվություն. թվանշանները մինչև `v`);և
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (վերջին նիշը ճիշտ է):
        //
        // երկրորդ պայմանը պարզեցնում է `2 * mant <= scale`-ը:
        // `mant`-ի, `low`-ի և `high`-ի տեսանկյունից անփոփոխ լուծումները տալիս են առաջին պայմանի ավելի պարզ տարբերակը. `-plus < mant < minus`.
        // `-plus < 0 <= mant`-ից ի վեր, մենք ունենք ամենակարճ կարճ ներկայացումը, երբ `mant < minus` և `2 * mant <= scale`:
        // (առաջինը դառնում է `mant <= minus`, երբ բնօրինակ մանտիսան հավասար է):
        //
        // երբ երկրորդը չի պահում («2 * mant> մասշտաբ»), մենք պետք է ավելացնենք վերջին նիշը:
        // սա բավարար է այդ պայմանը վերականգնելու համար. մենք արդեն գիտենք, որ թվանշանային սերունդը երաշխավորում է `0 <= v / 10^(k-n) - d[0..n-1] < 1`:
        // այս դեպքում առաջին պայմանը դառնում է `-plus < mant - scale < minus`:
        // սկսած `mant < scale`-ից `մենք ունենք `scale < mant + plus`:
        // (կրկին սա դառնում է `scale <= mant + plus`, երբ բուն մանտիսան հավասար է):
        //
        // կարճ ասած:
        // - կանգ առնել և կլորացնել `down`-ը (թվանշանները պահել այնպես, ինչպես կա), երբ `mant < minus` (կամ `<=`):
        // - կանգառ և կլոր `up` (բարձրացնել վերջին նիշը), երբ `scale < mant + plus` (կամ `<=`):
        // - շարունակիր այլ կերպ առաջացնել:
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // մենք ունենք ամենակարճ ներկայացուցչությունը, անցեք կլորացման

        // վերականգնել անփոփոխները:
        // սա ստիպում է ալգորիթմը միշտ դադարեցնել. `minus` և `plus` միշտ ավելանում են, բայց `mant` կտրված է `scale` մոդուլով և `scale` ֆիքսված է:
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // կլորացումը տեղի է ունենում այն ժամանակ, երբ i) գործարկվել է միայն կլորացման պայմանը, կամ ii) երկու պայմաններն էլ գործարկվել են, և փողկապը նախընտրում է կլորացումը:
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // եթե կլորացումը փոխում է երկարությունը, ապա պետք է փոխվի նաև արտահայտիչը:
        // թվում է, որ այս պայմանը շատ դժվար է բավարարել (հնարավոր է անհնար է), բայց մենք այստեղ պարզապես ապահով և հետևողական ենք:
        //
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք վերարտադրեցինք այդ հիշողությունը:
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք վերարտադրեցինք այդ հիշողությունը:
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Dragon-ի ճշգրիտ և ֆիքսված ռեժիմի իրականացումը:
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // գնահատեք `k_0`-ը `10^(k_0-1) < v <= 10^(k_0+1)`-ին բավարարող բնօրինակ մուտքերից:
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // բաժանել `mant`-ը `10^k`-ի վրա: այժմ `scale / 10 < mant <= scale * 10`:
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // շտկում, երբ `mant + plus >= scale`, որտեղ `plus / scale = 10^-buf.len() / 2`:
    // ֆիքսված չափի բիգնումը պահելու համար մենք իրականում օգտագործում ենք `mant + floor(plus) >= scale`:
    // մենք իրականում չենք փոփոխում `scale`-ը, քանի որ փոխարենը կարող ենք բաց թողնել սկզբնական բազմապատկումը:
    // կրկին ամենակարճ ալգորիթմով `d[0]`-ը կարող է զրո լինել, բայց ի վերջո կլորացվի:
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // համարժեք է `scale`-ի 10-ով մասշտաբավորմանը
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // եթե մենք աշխատում ենք վերջին նիշի սահմանափակման հետ, մենք պետք է կրճատենք բուֆերը նախքան իրական ներկայացումը, որպեսզի խուսափենք կրկնակի կլորացումից:
    //
    // նշենք, որ կլորացումը պատահելիս մենք պետք է նորից մեծացնենք բուֆերը:
    let mut len = if k < limit {
        // այո, մենք նույնիսկ չենք կարող արտադրել *մեկ* նիշ:
        // դա հնարավոր է, երբ, ասենք, մենք ունենք 9.5-ի նման մի բան, և այն կլորացվում է 10-ի:
        // մենք վերադարձնում ենք դատարկ բուֆեր, բացառությամբ ավելի ուշ կլորացման դեպքի, որը տեղի է ունենում `k == limit`-ի դեպքում և ստիպված է արտադրել ճիշտ մեկ նիշ:
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` թվանշանների առաջացման համար:
        // (սա կարող է թանկ լինել, այնպես որ մի հաշվարկեք դրանք, երբ բուֆերը դատարկ է):
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // հետևյալ թվանշանները բոլորն են զրոներ, մենք կանգ ենք առնում այստեղ * մի փորձեք կատարել կլորացում: ավելի շուտ լրացնել մնացած թվանշանները:
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք վերարտադրեցինք այդ հիշողությունը:
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // կլորացում, եթե կանգ առնենք թվանշանների մեջտեղում, եթե հետևյալ թվանշանները ճշգրիտ 5000 են ..., ստուգիր նախորդ նիշը և փորձիր կլորացնել (այսինքն ՝ խուսափել կլորացնելուց, երբ նախորդ նիշը հավասար է):
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `buf[len-1]` սկզբնավորվում է:
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // եթե կլորացումը փոխում է երկարությունը, ապա պետք է փոխվի նաև արտահայտիչը:
        // բայց մեզանից պահանջվել է թվանշանների ֆիքսված քանակ, ուստի մի փոխեք բուֆերը ...
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք վերարտադրեցինք այդ հիշողությունը:
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... եթե փոխարենը մեզանից չեն պահանջել ֆիքսված ճշգրտություն:
            // մենք նաև պետք է ստուգենք, որ եթե բնօրինակ բուֆերը դատարկ էր, ապա լրացուցիչ թվանշանը կարող է ավելացվել միայն այն դեպքում, երբ `k == limit` (edge գործ):
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք վերարտադրեցինք այդ հիշողությունը:
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}