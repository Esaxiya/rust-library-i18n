//! Լողացող կետի արժեքը վերծանում է առանձին մասերի և սխալի միջակայքերի:

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Ապակոդավորված վերջավոր արժեքը, այնպես, որ.
///
/// - Սկզբնական արժեքը հավասար է `mant * 2^exp`-ի:
///
/// - `(mant - minus)*2^exp`-ից `(mant + plus)* 2^exp` ցանկացած թիվ կլորացվի մինչև սկզբնական արժեք:
/// Շարքը ներառական է միայն այն դեպքում, երբ `inclusive`-ը `true` է:
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Մասշտաբված մանտիսան:
    pub mant: u64,
    /// Ստորին սխալի միջակայքը:
    pub minus: u64,
    /// Վերին սխալի միջակայքը:
    pub plus: u64,
    /// 2-րդ բազայի ընդհանուր ցուցիչը:
    pub exp: i16,
    /// Ueիշտ է, երբ սխալի միջակայքն ընդգրկուն է:
    ///
    /// IEEE 754-ում դա ճիշտ է, երբ բնօրինակ մանտիսան հավասար էր:
    pub inclusive: bool,
}

/// Վերծանված անստորագիր արժեքը:
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Անսահմանություն ՝ կա՛մ դրական, կա՛մ բացասական:
    Infinite,
    /// Eroրո, կամ դրական, կամ բացասական:
    Zero,
    /// Վերջավոր թվեր հետագա վերծանված դաշտերով:
    Finite(Decoded),
}

/// Լողացող կետի տեսակ, որը կարող է «վերծանվել» d:
pub trait DecodableFloat: RawFloat + Copy {
    /// Նվազագույն դրական նորմալացված արժեքը:
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Տրված լողացող կետի համարից վերադարձնում է նշան (ճիշտ է, երբ բացասական է) և `FullDecoded` արժեք:
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // հարևաններ. (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode միշտ պահպանում է էքսպոնենտը, ուստի մանտիսան մասշտաբավորվում է ենթաբնականների համար:
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // հարևաններ. (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // որտեղ maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // հարևաններ. (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}