/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// չնայած սա ընդարձակ փաստաթղթավորված է, բայց դա սկզբունքորեն մասնավոր է, որը հրապարակվում է միայն փորձարկման համար:
// մի բացահայտեք մեզ
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Թվային սերնդի ալգորիթմներ:
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Բուֆերի նվազագույն չափը, որն անհրաժեշտ է ամենակարճ ռեժիմի համար:
///
/// Ստանալը մի փոքր ոչ տրիվիալ է, բայց սա գումարած է ամենակարճ արդյունք ունեցող ձևաչափման ալգորիթմներից զգալի տասնորդական թվանշանների առավելագույն թվին:
///
/// Exactշգրիտ բանաձեւը `ceil(# bits in mantissa * log_10 2 + 1)` է:
pub const MAX_SIG_DIGITS: usize = 17;

/// Երբ `d` պարունակում է տասնորդական թվանշաններ, ավելացրեք վերջին նիշը և տարածեք կրիչը:
/// Վերադարձնում է հաջորդ նիշը, երբ դա հանգեցնում է երկարության փոփոխության:
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] բոլորը ինն է
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 կլորացվում է դեպի 1000..000` ավելացված ցուցիչով
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // դատարկ բուֆերը կլորացվում է (մի քիչ տարօրինակ, բայց ողջամիտ)
            Some(b'1')
        }
    }
}

/// Ձևաչափված մասեր:
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Հաշվի առնելով զրոյական թվանշանների քանակը:
    Zero(usize),
    /// Բառացի թիվ ՝ մինչև 5 նիշ:
    Num(u16),
    /// Տրված բայթերի բառացի կրկնօրինակը:
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Վերադարձնում է տրված մասի ճշգրիտ բայտի երկարությունը:
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Մասը գրում է մատակարարված բուֆերի մեջ:
    /// Վերադառնում է գրված բայթերի քանակը կամ `None`-ը, եթե բուֆերը բավարար չէ:
    /// (Այն կարող է դեռ բուֆերում թողնել մասամբ գրված բայթեր. Մի ապավինեք դրան):
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Ձևաչափված արդյունք, որը պարունակում է մեկ կամ ավելի մասեր:
/// Սա կարող է գրվել բայտ բուֆերում կամ վերափոխվել հատկացված տողի:
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` կամ `"+"` նշան ներկայացնող բայթ հատված:
    pub sign: &'static str,
    /// Ձևաչափված մասեր, որոնք մատուցվելու են նշանից և ընտրովի զրոյական լցոնումից հետո:
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Վերադարձնում է համակցված ֆորմատավորված արդյունքի բայտի ճշգրիտ երկարությունը:
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Գրում է բոլոր ձևաչափված մասերը մատակարարված բուֆերի մեջ:
    /// Վերադառնում է գրված բայթերի քանակը կամ `None`-ը, եթե բուֆերը բավարար չէ:
    /// (Այն կարող է դեռ բուֆերում թողնել մասամբ գրված բայթեր. Մի ապավինեք դրան):
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// `0.<...buf...> * 10^exp` տասնորդական թվանշաններին տրված ձևաչափերը տասնորդական ձևի մեջ ունեն գոնե տրված կոտորակային թվերի քանակը:
///
/// Արդյունքը պահվում է մատակարարված մասերի զանգվածում և վերադարձվում է գրված մասերի մի կտոր:
///
/// `frac_digits` կարող է պակաս լինել `buf`-ի իրական կոտորակային թվերի քանակից;
/// այն անտեսվելու է և ամբողջ թվանշանները տպվելու են: Այն օգտագործվում է միայն տրված թվանշաններից հետո լրացուցիչ զրոներ տպելու համար:
/// Այսպիսով, 0-ի `frac_digits`-ը նշանակում է, որ այն կտպագրի միայն տրված թվանշանները և ոչ այլ ինչ:
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // եթե վերջին թվանշանի դիրքի սահմանափակում կա, ապա ենթադրվում է, որ `buf`-ը ձախում լցված է վիրտուալ զրոներով:
    // վիրտուալ զրոների քանակը, `nzeroes`, հավասար է `max(0, exp + frac_digits - buf.len())`, այնպես որ `exp - buf.len() - nzeroes` վերջին նիշի դիրքը `-frac_digits`-ից ոչ ավելի է.
    //
    //
    //                       |<-virtual->|
    //       | <----բուֆ----> |զրոներ |էքսպ
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` անհատապես հաշվարկվում է յուրաքանչյուր դեպքի համար `ջրհեղեղից խուսափելու համար:
    //

    if exp <= 0 {
        // տասնորդական կետը տրված թվանշաններից առաջ է. [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..4` տարրերը:
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..3` տարրերը:
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // տասնորդական կետը տրված թվանշանների ներսում է. [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..4` տարրերը:
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..3` տարրերը:
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // տասնորդական կետը տրված թվանշաններից հետո է. [1234][____0000] կամ [1234][__][.][__]:
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..4` տարրերը:
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..2` տարրերը:
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Ձևաչափում է տրված տասնորդական թվերը `0.<...buf...> * 10^exp` ցուցիչ ձևի մեջ `առնվազն նշանակալից թվանշանների տվյալ քանակով:
///
/// Երբ `upper`-ը `true` է, էքսպոնենտը նախածանցով կլինի `E`;հակառակ դեպքում դա `e` է:
/// Արդյունքը պահվում է մատակարարված մասերի զանգվածում և վերադարձվում է գրված մասերի մի կտոր:
///
/// `min_digits` կարող է լինել պակաս, քան `buf`-ի իրական նշանակալի թվանշանների քանակը;
/// այն անտեսվելու է և ամբողջ թվանշանները տպվելու են: Այն օգտագործվում է միայն տրված թվանշաններից հետո լրացուցիչ զրոներ տպելու համար:
/// Այսպիսով, `min_digits == 0` նշանակում է, որ այն կտպագրի միայն տրված թվանշանները և ոչ այլ ինչ:
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // խուսափեք ցածր հոսքից, երբ exp-ը i16::MIN է
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..n + 2` տարրերը:
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Գրանցման ձևաչափման ընտրանքներ:
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Տպում է `-` միայն բացասական ոչ զրոյական արժեքների համար:
    Minus, // -inf -1 0 0 1 ինֆ
    /// Տպում է `-` միայն բացասական արժեքների համար (ներառյալ բացասական զրոն):
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Տպում է `-` բացասական ոչ զրոյական արժեքների համար, կամ այլապես `+`:
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Տպում է `-` ցանկացած բացասական արժեքի համար (ներառյալ բացասական զրոն), կամ այլ կերպ `+`-ի համար:
    MinusPlusRaw, // -inf -1 -0 +0 +1 + ինֆ
}

/// Վերադարձնում է ստատիկ բայթային տողը, որը համապատասխանում է ձևաչափման նշանին:
/// Դա կարող է լինել կամ `""`, `"+"` կամ `"-"`:
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Տրված լողացող կետի համարը ձևավորում է տասնորդական ձևի `առնվազն տրված կոտորակային թվերի քանակով:
/// Արդյունքը պահվում է մատակարարված մասերի զանգվածում `միաժամանակ օգտագործելով տրված բայթ բուֆերը որպես քերծվածք:
/// `upper` ներկայումս օգտագործված չէ, բայց մեկնել է future որոշման ՝ փոխել ոչ վերջավոր արժեքների գործը, այսինքն ՝ `inf` և `nan`:
///
/// Առաջին մասը, որը պետք է մատուցվի, միշտ `Part::Sign` է (որը կարող է լինել դատարկ տող, եթե ոչ մի նշան չի տրվում):
///
/// `format_shortest` պետք է լինի թվանշանների առաջացման հիմնական գործառույթը:
/// Այն պետք է վերադարձնի բուֆերի նախաստորագրված մասը:
/// Դուք հավանաբար կցանկանաք `strategy::grisu::format_shortest` սրա համար:
///
/// `frac_digits` կարող է պակաս լինել `v`-ի իրական կոտորակային թվերի քանակից;
/// այն անտեսվելու է և ամբողջ թվանշանները տպվելու են: Այն օգտագործվում է միայն տրված թվանշաններից հետո լրացուցիչ զրոներ տպելու համար:
/// Այսպիսով, 0-ի `frac_digits`-ը նշանակում է, որ այն կտպագրի միայն տրված թվանշանները և ոչ այլ ինչ:
///
/// Բայթ բուֆերը պետք է ունենա առնվազն `MAX_SIG_DIGITS` բայթ երկարություն:
/// Առնվազն 4 մաս պետք է լինի մատչելի ՝ կապված `[+][0.][0000][2][0000]`-ի հետ `frac_digits = 10`-ի նման վատագույն դեպքի հետ:
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..2` տարրերը:
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Տրված լողացող կետի համարը ձևաչափում է տասնորդական ձևի կամ ցուցիչ ձևի ՝ կախված արդյունքի ցուցիչից:
/// Արդյունքը պահվում է մատակարարված մասերի զանգվածում `միաժամանակ օգտագործելով տրված բայթ բուֆերը որպես քերծվածք:
/// `upper` օգտագործվում է ոչ վերջավոր արժեքների (`inf` և `nan`) դեպքերի կամ էքսպոնենտ նախածանցի դեպքը (`e` կամ `E`) որոշելու համար:
/// Առաջին մասը, որը պետք է մատուցվի, միշտ `Part::Sign` է (որը կարող է լինել դատարկ տող, եթե ոչ մի նշան չի տրվում):
///
/// `format_shortest` պետք է լինի թվանշանների առաջացման հիմնական գործառույթը:
/// Այն պետք է վերադարձնի բուֆերի նախաստորագրված մասը:
/// Դուք հավանաբար կցանկանաք `strategy::grisu::format_shortest` սրա համար:
///
/// `dec_bounds`-ը տիպային `(lo, hi)` է, այնպես որ համարը տասնորդական ձևաչափվում է միայն այն դեպքում, երբ `10^lo <= V < 10^hi`:
/// Նշենք, որ սա *ակնհայտ*`V` է ՝ իրական `v`-ի փոխարեն: Այսպիսով, ցուցիչ տեսքով ցանկացած տպագիր ցուցիչ չի կարող լինել այս տիրույթում ՝ խուսափելով որևէ խառնաշփոթից:
///
///
/// Բայթ բուֆերը պետք է ունենա առնվազն `MAX_SIG_DIGITS` բայթ երկարություն:
/// Պետք է լինեն առնվազն 6 մասեր մատչելի ՝ `[+][1][.][2345][e][-][6]`-ի նման վատագույն դեպքի պատճառով:
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Վերադարձնում է բավականին կոպիտ մոտավորություն (վերին սահման) տրված վերծանված ցուցիչից հաշվարկված բուֆերի առավելագույն չափի համար:
///
/// Theշգրիտ սահմանն է.
///
/// - երբ `exp < 0`, առավելագույն երկարությունը `ceil(log_10 (5^-exp * (2^64 - 1)))` է:
/// - երբ `exp >= 0`, առավելագույն երկարությունը `ceil(log_10 (2^exp * (2^64 - 1)))` է:
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`-ից պակաս է, որն իր հերթին պակաս է `20 + (1 + exp* log_10 x)`-ից:
/// Մենք օգտագործում ենք `log_10 2 < 5/16` և `log_10 5 < 12/16` փաստերը, ինչը բավարար է մեր նպատակների համար:
///
/// Ինչու է սա մեզ պետք: `format_exact` գործառույթները կլրացնեն ամբողջ բուֆերը, քանի դեռ չեն սահմանափակվել վերջին նիշի սահմանափակումով, բայց հնարավոր է, որ հայցվող թվանշանների քանակը ծիծաղելիորեն մեծ է (ասենք, 30,000 նիշ):
///
/// Բուֆերի ճնշող մեծամասնությունը կլցվի զրոներով, ուստի մենք չենք ցանկանում նախապես բաշխել բոլոր բուֆերները:
/// Հետևաբար, ցանկացած փաստարկի համար
/// 826 բայթ բուֆեր պետք է բավարար լինի `f64`-ի համար: Համեմատեք սա ամենավատ դեպքերի իրական թվի հետ. 770 բայթ (երբ `exp = -1074`):
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Լողացող կետի համարը ցուցիչ ձևի մեջ տրված ձևաչափերին `նշանակալի թվանշանների ճիշտ տրված թվով:
/// Արդյունքը պահվում է մատակարարված մասերի զանգվածում `միաժամանակ օգտագործելով տրված բայթ բուֆերը որպես քերծվածք:
/// `upper` օգտագործվում է էքսպոնենտ նախածանցի դեպքը որոշելու համար (`e` կամ `E`):
/// Առաջին մասը, որը պետք է մատուցվի, միշտ `Part::Sign` է (որը կարող է լինել դատարկ տող, եթե ոչ մի նշան չի տրվում):
///
/// `format_exact` պետք է լինի թվանշանների առաջացման հիմնական գործառույթը:
/// Այն պետք է վերադարձնի բուֆերի նախաստորագրված մասը:
/// Դուք հավանաբար կցանկանաք `strategy::grisu::format_exact` սրա համար:
///
/// Բայթ բուֆերը պետք է լինի առնվազն `ndigits` բայթ երկարությամբ, եթե `ndigits` այնքան մեծ չէ, որ երբևէ գրվի միայն թվանշանների ֆիքսված թիվը:
/// (`f64`-ի համար շրջադարձային կետը մոտ 800 է, ուստի 1000 բայթ պետք է որ լինի բավարար) Պետք է լինի առնվազն 6 մաս ՝ մատչելի ՝ `[+][1][.][2345][e][-][6]`-ի նման վատագույն դեպքի պատճառով:
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..3` տարրերը:
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Լողացող կետի համարը տասնորդական ձևի մեջ տրված ձևաչափերին `կոտորակային թվանշանների ճիշտ տրված թվով:
/// Արդյունքը պահվում է մատակարարված մասերի զանգվածում `միաժամանակ օգտագործելով տրված բայթ բուֆերը որպես քերծվածք:
/// `upper` ներկայումս օգտագործված չէ, բայց մեկնել է future որոշման ՝ փոխել ոչ վերջավոր արժեքների գործը, այսինքն ՝ `inf` և `nan`:
/// Առաջին մասը, որը պետք է մատուցվի, միշտ `Part::Sign` է (որը կարող է լինել դատարկ տող, եթե ոչ մի նշան չի տրվում):
///
/// `format_exact` պետք է լինի թվանշանների առաջացման հիմնական գործառույթը:
/// Այն պետք է վերադարձնի բուֆերի նախաստորագրված մասը:
/// Դուք հավանաբար կցանկանաք `strategy::grisu::format_exact` սրա համար:
///
/// Բայտի բուֆերը պետք է բավարար լինի ելքի համար, եթե `frac_digits` այնքան մեծ չէ, որ երբևէ գրվի միայն թվանշանների ֆիքսված թիվը:
/// (`f64`-ի համար շրջադարձային կետը մոտ 800 է, և 1000 բայթ պետք է լինի բավարար): Պետք է լինի առնվազն 4 մաս `մատչելի, քանի որ `[+][0.][0000][2][0000]`-ի հետ `frac_digits = 10`-ի նման վատագույն դեպքը:
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..2` տարրերը:
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // * հնարավոր է, որ `frac_digits`-ը ծիծաղելիորեն մեծ լինի:
            // `format_exact` այս դեպքում կավարտվի թվանշանների տրամադրումը շատ ավելի վաղ, քանի որ մենք խստորեն սահմանափակված ենք `maxlen`-ով:
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // սահմանափակումն անհնար էր բավարարել, այնպես որ սա պետք է զրոյի պես լինի, անկախ նրանից `exp` լիներ:
                // սա չի պարունակում այն դեպքը, երբ սահմանափակումները բավարարվել են միայն վերջին կլորացումից հետո.դա սովորական դեպք է `exp = limit + 1`-ի հետ:
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..2` տարրերը:
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք պարզապես նախաստորագրեցինք `..1` տարրերը:
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}