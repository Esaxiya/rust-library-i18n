//! Բիտ ֆիդինգ IEEE 754 դրական բոցերի վրա: Բացասական թվերը չեն մշակվում և կարիք չկա:
//! Սովորական լողացող կետերի համարները ունեն կանոնական ներկայացում ինչպես (frac, exp) այնպես, որ արժեքը 2 <sup>exp</sup> * է (1 + sum(frac[N-i] / 2<sup>i</sup>)), որտեղ N-բիթերի քանակն է):
//!
//! Ենթանկյունները մի փոքր տարբեր են և տարօրինակ, բայց գործում է նույն սկզբունքը:
//!
//! Այստեղ, սակայն, մենք դրանք ներկայացնում ենք որպես (sig, k) f դրականով, այնպես որ արժեքը f * է
//! 2 <sup>ե</sup> .Բացի "hidden bit"-ը պարզ դարձնելուց, սա փոխում է էքսպոնենտը, այսպես կոչված, մանտիսայի հերթափոխով:
//!
//! Այլ կերպ ասած, սովորաբար բոցերը գրվում են որպես (1), բայց այստեղ դրանք գրվում են որպես (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Մենք (1)-ն անվանում ենք **կոտորակային ներկայացուցչություն**, իսկ (2)-ը ՝**ինտեգրալ ներկայացուցչություն**:
//!
//! Այս մոդուլի շատ գործառույթներ կարգավորում են միայն նորմալ թվերը: Dec2flt ռեժիմները պահպանողականորեն տանում են համընդհանուր ճիշտ դանդաղ ուղին (Ալգորիթմ M) շատ փոքր և շատ մեծ թվերի համար:
//! Այդ ալգորիթմին անհրաժեշտ է միայն next_float(), որը կարգավորում է ենթանորմալներն ու զրոները:
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// trait օգնական ՝ `f32` և `f64`-ի համար հիմնականում բոլոր փոխակերպման ծածկագրերը կրկնօրինակելուց խուսափելու համար:
///
/// Տե՛ս ծնողական մոդուլի փաստաթղթի մեկնաբանությունը, թե ինչու է դա անհրաժեշտ:
///
/// Պետք է **երբևէ**** ներդրվի այլ տեսակների համար կամ օգտագործվի dec2flt մոդուլից դուրս:
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Տեսակը, որն օգտագործվում է `to_bits` և `from_bits`-ի կողմից:
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Կատարում է հում փոխարկում ամբողջ թվին:
    fn to_bits(self) -> Self::Bits;

    /// Կատարում է հում փոխարկում ամբողջ թվից:
    fn from_bits(v: Self::Bits) -> Self;

    /// Վերադարձնում է այն կատեգորիան, որի մեջ ընկնում է այս թիվը:
    fn classify(self) -> FpCategory;

    /// Վերադառնում է մանտիսան, ցուցիչը և նշանը `որպես ամբողջ թվեր:
    fn integer_decode(self) -> (u64, i16, i8);

    /// Վերծանում է բոցը:
    fn unpack(self) -> Unpacked;

    /// Ձուլում է փոքր ամբողջ թվից, որը կարող է ճշգրիտ ներկայացվել:
    /// Panic եթե ամբողջ թիվը չի կարող ներկայացվել, այս մոդուլի մյուս ծածկագիրը համոզվում է, որ երբեք դա տեղի չի ունենա:
    fn from_int(x: u64) -> Self;

    /// Նախնական հաշվարկված աղյուսակից ստանում է 10 <sup>e</sup> արժեքը:
    /// Panics `e >= CEIL_LOG5_OF_MAX_SIG`-ի համար:
    fn short_fast_pow10(e: usize) -> Self;

    /// Ինչ է ասում անունը:
    /// Կոդը ծածկագրելը ավելի հեշտ է, քան ներքուստի ներքաշելը և հույս ունենալով, որ LLVM-ն անընդհատ ծալում է այն:
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Պահպանողական, որը կապված է մուտքերի տասնորդական նիշերի հետ, որոնք չեն կարող առաջացնել գերհոսք կամ զրո կամ
    /// ենթաբնականները: Հավանաբար առավելագույն նորմալ արժեքի տասնորդական ցուցիչը, այստեղից էլ ՝ անվանումը:
    const MAX_NORMAL_DIGITS: usize;

    /// Երբ ամենանշանակալի տասնորդական նիշը դրանից ավելի մեծ արժեք ունի, այդ թիվը, անշուշտ, կլորացվում է դեպի անվերջություն:
    ///
    const INF_CUTOFF: i64;

    /// Երբ ամենանշանակալի տասնորդական նիշը ունի դրանից պակաս տեղային արժեք, այդ թիվը, անկասկած, կլորացվում է զրոյի:
    ///
    const ZERO_CUTOFF: i64;

    /// Բծերի քանակը ցուցիչում:
    const EXP_BITS: u8;

    /// Նշված բիտերի քանակը,*ներառյալ* թաքնված բիթը:
    const SIG_BITS: u8;

    /// Նշումների մեջ բիտերի քանակը,*բացառելով* թաքնված բիտը:
    const EXPLICIT_SIG_BITS: u8;

    /// Կոտորակային ներկայացուցչության առավելագույն իրավական ցուցիչը:
    const MAX_EXP: i16;

    /// Կոտորակային ներկայացուցչության նվազագույն իրավական ցուցիչը, բացառությամբ ենթաօրինականների:
    const MIN_EXP: i16;

    /// `MAX_EXP` ինտեգրալ ներկայացման համար, այսինքն ՝ կիրառվող հերթափոխով:
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` կոդավորված (այսինքն ՝ փոխհատուցման կողմնակալությամբ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ինտեգրալ ներկայացման համար, այսինքն ՝ կիրառվող հերթափոխով:
    const MIN_EXP_INT: i16;

    /// Առավելագույն նորմալացված նշանակությունը և ինտեգրալ ներկայացուցչությունում:
    const MAX_SIG: u64;

    /// Նվազագույն նորմալացված նշանակությունը և ինտեգրալ ներկայացուցչությունում:
    const MIN_SIG: u64;
}

// Հիմնականում լուծում #34344-ի համար:
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Վերադառնում է մանտիսան, ցուցիչը և նշանը `որպես ամբողջ թվեր:
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Էքսպոնենտ կողմնակալություն + մանտիսայի հերթափոխ
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe-ն անորոշ է `արդյո՞ք `as`-ը ճիշտ է պտտվում բոլոր հարթակներում:
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Վերադառնում է մանտիսան, ցուցիչը և նշանը `որպես ամբողջ թվեր:
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Էքսպոնենտ կողմնակալություն + մանտիսայի հերթափոխ
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe-ն անորոշ է `արդյո՞ք `as`-ը ճիշտ է պտտվում բոլոր հարթակներում:
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp`-ը փոխակերպում է ամենամոտ ապարատի բոց տեսակի:
/// Չի կարգավորում աննորմալ արդյունքները:
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 բիթ է, ուստի xe-ն ունի 63 հատ մանտիսայի հերթափոխ
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Կլորացնել 64-բիթանոց նշանակությունը և T::SIG_BITS բիթերը `կիսով չափ հավասարեցմամբ:
/// Չի կարգավորում ցուցիչների արտահոսքը:
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Կարգավորեք մանտիսայի հերթափոխը
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// `RawFloat::unpack()`-ի հակադարձ նորմավորված թվերի համար:
/// Panics, եթե նշանակը կամ ցուցիչը վավեր չեն նորմալացված թվերի համար:
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Հեռացրեք թաքնված բիտը
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Կարգավորեք ցուցիչը ցուցիչների կողմնակալության և մանտիսայի հերթափոխի համար
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Նշանի բիտը թողեք 0 ("+")-ի վրա, մեր թվերը բոլորը դրական են
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Կառուցել ենթասովորական:0-ի մանտիսը թույլատրվում է և կառուցում է զրո:
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Կոդավորված ցուցիչը 0 է, նշանի բիթը ՝ 0, այնպես որ մենք պարզապես պետք է նորից մեկնաբանենք բիթերը:
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Մոտեցեք bignum-ը Fp-ով: Կլորացվում է 0.5 ULP-ի սահմաններում `կիսով չափ հավասարեցմամբ:
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Մենք կտրում ենք բոլոր բիթերը մինչև `start` ինդեքսը, այսինքն ՝ մենք արդյունավետորեն աջ-հերթափոխվում ենք `start` քանակով, այնպես որ սա նաև մեզ անհրաժեշտ արտահայտիչն է:
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Կլոր (half-to-even) ՝ կախված կտրված բիթերից:
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Գտնում է լողացող կետի ամենամեծ համարը խիստ փոքր ՝ փաստարկից:
/// Չի կարգավորում ենթանորմալները, զրոյական կամ ցուցիչ հոսքը:
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Գտեք ամենափոքր լողացող կետի համարը խիստ ավելի մեծ, քան փաստարկը:
// Այս գործողությունը հագեցնում է, այսինքն, next_float(inf) ==ներածում:
// Ի տարբերություն այս մոդուլի կոդերի մեծ մասի, այս ֆունկցիան իրականացնում է զրո, ենթաօրինականներ և անսահմանություններ:
// Այնուամենայնիվ, ինչպես այստեղ մնացած բոլոր ծածկագրերը, այն չի գործարկում NaN և բացասական թվերի հետ:
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Սա շատ լավ է թվում իրականության համար, բայց գործում է:
        // 0.0 ծածկագրված է որպես ամբողջ զրոյական բառ: Ենթանկյունները 0x000 մ ... մ են, որտեղ m-մանտիսան է:
        // Մասնավորապես, ամենափոքր subnormal-ը 0x0 ... 01 է, իսկ ամենամեծը ՝ 0x000F ... F:
        // Ամենափոքր նորմալ թիվը 0x0010 ... 0 է, ուստի այս անկյունային պատյանը նույնպես գործում է:
        // Եթե ավելացումը դուրս է գալիս մանտիսայից, ապա փոխադրման բիտը ավելացնում է էքսպոնենտը, ինչպես ուզում ենք, և մանտիսայի բիթերը դառնում են զրո:
        // Թաքնված բիտ կոնվենցիայի պատճառով սա նույնպես հենց մեր ուզածն է:
        // Վերջապես, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}