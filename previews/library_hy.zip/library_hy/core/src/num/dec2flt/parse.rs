//! Ձևի տասնորդական տողի վավերացում և քայքայում:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Այլ կերպ ասած, ստանդարտ լողացող կետի շարահյուսությունը, բացառությամբ երկու բացառության. Ոչ մի նշան և "inf"-ի և "NaN"-ի ոչ մի բեռնաթափում: Դրանք վարվում են վարորդի (super::dec2flt) գործառույթի միջոցով:
//!
//! Չնայած վավեր ներածումները ճանաչելը համեմատաբար հեշտ է, այս մոդուլը նաև ստիպված է մերժել անթիվ անվավեր տատանումները, երբեք panic, և կատարել բազմաթիվ ստուգումներ, որոնց վրա մյուս մոդուլները ապավինում են ոչ թե panic (կամ հեղեղել) իրենց հերթին:
//!
//! Որպեսզի իրավիճակն ավելի վատ լինի, այդ ամենը տեղի է ունենում մուտքի մեկ փոխանցումով:
//! Այսպիսով, զգույշ եղեք ցանկացած բան փոփոխելիս և կրկնակի ստուգեք մյուս մոդուլների հետ:
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Տասնորդական տողի հետաքրքիր մասերը:
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Տասնորդական ցուցիչը, երաշխավորված ունենալով 18 տասնորդական թվանշանից պակաս:
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Ստուգում է, թե արդյոք մուտքային տողը վավեր լողացող կետի համար է, և եթե այո, ապա տեղաբաշխի ինտեգրալ մասը, կոտորակային մասը և դրա ցուցիչը:
/// Նշաններ չի կարգավորում:
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e'-ից առաջ թվանշաններ չկան
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Մենք կետից առաջ կամ դրանից հետո պահանջում ենք առնվազն մեկ նիշ:
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Կոտորակային մասից հետո հետևյալ աղբը
            }
        }
        _ => Invalid, // Առաջին նիշից հետո հետևում է աղբը
    }
}

/// Քանդակում է տասնորդական թվանշանները մինչև առաջին ոչանիշ նիշը:
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Էքսպոնենտների արդյունահանման և սխալի ստուգում:
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Հետևանքով աղբը ցուցիչից հետո
    }
    if number.is_empty() {
        return Invalid; // Դատարկ ցուցիչ
    }
    // Այս պահին մենք, անշուշտ, ունենք թվանշանների վավեր տող: Գուցե `i64`-ը դնելը չափազանց երկար է, բայց եթե դա այդքան հսկայական է, մուտքն, իհարկե, զրոյական է կամ անսահմանություն:
    // Քանի որ տասնորդական թվանշանների յուրաքանչյուր զրոյականությունը միայն ցուցիչը կարգավորում է +/-1-ով, exp=10 ^ 18-ում մուտքը պետք է լիներ 17 exabyte (!) զրո, որպեսզի նույնիսկ հեռակաորեն մոտ լինի վերջավոր լինելուն:
    //
    // Սա հենց այն օգտագործման դեպքը չէ, որին պետք է սպասարկենք:
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}