//! 8-բիթանոց ամբողջ թվով տիպի հաստատուններ:
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Նոր ծածկագիրը պետք է օգտագործի կապակցված հաստատունները ուղղակիորեն պարզունակ տիպի վրա:

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }