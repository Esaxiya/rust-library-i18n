//! Կայուններ 32-բիթանոց չստորագրված ամբողջ տեսակի համար:
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Նոր ծածկագիրը պետք է օգտագործի կապակցված հաստատունները ուղղակիորեն պարզունակ տիպի վրա:

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }