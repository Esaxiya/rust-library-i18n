//! 32-բիթանոց ստորագրված ամբողջ տեսակի տիպի հաստատուններ:
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Նոր ծածկագիրը պետք է օգտագործի կապակցված հաստատունները ուղղակիորեն պարզունակ տիպի վրա:

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }