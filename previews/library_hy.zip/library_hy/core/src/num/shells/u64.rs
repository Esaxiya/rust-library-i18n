//! 64-բիթանոց անստորագիր ամբողջ տիպի հաստատուններ:
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Նոր ծածկագիրը պետք է օգտագործի կապակցված հաստատունները ուղղակիորեն պարզունակ տիպի վրա:

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }