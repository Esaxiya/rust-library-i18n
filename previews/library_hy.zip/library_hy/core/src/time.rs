#![stable(feature = "duration_core", since = "1.25.0")]

//! Empամանակային քանակականացում:
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // երկու հայտարարություններն էլ համարժեք են
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// `Duration` տիպ ՝ ժամանակի տևողությունը ներկայացնելու համար, որը սովորաբար օգտագործվում է համակարգի ընդմիջումների համար:
///
/// Յուրաքանչյուր `Duration` բաղկացած է մի ամբողջ վայրկյանից և նանովայրկյանում ներկայացված կոտորակային մասից:
/// Եթե հիմքում ընկած համակարգը չի ապահովում նանովայրկյան մակարդակի ճշգրտություն, համակարգի ժամկետի ավարտը կապող API-ները սովորաբար կլրացնեն նանովայրկյանների քանակը:
///
/// [«Տևողությունը»]-ն իրականացնում է շատ տարածված traits, ներառյալ [`Add`], [`Sub`] և այլ [`ops`] traits: Այն իրականացնում է [`Default`] ՝ վերադարձնելով զրոյական երկարությամբ `Duration`:
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` արժեքների ձևավորում
///
/// `Duration` դիտավորյալ չունի `Display` ազդանշան, քանի որ կան մարդու ընթերցանության ժամանակի տևողությունը ձևաչափելու մի շարք եղանակներ:
/// `Duration` ապահովում է `Debug` ազդանշան, որը ցույց է տալիս արժեքի ամբողջական ճշգրտությունը:
///
/// `Debug` ելքը միկրովայրկյանների համար օգտագործում է ոչ ASCII "µs" վերջածանց:
/// Եթե ձեր ծրագրի ելքը կարող է հայտնվել համատեքստերում, որոնք չեն կարող ապավինել Unicode-ի ամբողջական համատեղելիությանը, ապա գուցե ցանկանաք ինքներդ ձևաչափել `Duration` օբյեկտներ կամ դրա համար օգտագործել crate:
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // Միշտ 0 <=նանո <NANOS_PER_SEC
}

impl Duration {
    /// Մեկ վայրկյանի տևողությունը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// Մեկ միլիվայրկյան տևողությունը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// Մեկ միկրովայրկյան տևողությունը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// Մեկ նանովայրկյան տևողությունը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// Zeroրոյական տևողություն:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// Առավելագույն տևողությունը:
    ///
    /// Այն մոտավորապես հավասար է 584,942,417,355 տարի տևողությանը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// Ստեղծում է նոր `Duration` ՝ նշված վայրկյանների և լրացուցիչ նանովայրկյանների քանակից:
    ///
    /// Եթե նանովայրկյանների քանակը 1 միլիարդից ավելին է (նանովայրկյանների քանակը մեկ վայրկյանում), ապա այն կանցնի տրամադրված վայրկյանների ընթացքում:
    ///
    ///
    /// # Panics
    ///
    /// Այս կոնստրուկտորը կլինի panic, եթե նանովայրկյաններից տեղափոխումը դուրս գա վայրկյանների հաշվիչից:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// Ամբողջ վայրկյանների նշված քանակից ստեղծում է նոր `Duration`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// Նշված միլիվայրկյաններից ստեղծում է նոր `Duration`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// Նշված միկրովայրկյաններից ստեղծում է նոր `Duration`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// Նշված նանովայրկյաններից ստեղծում է նոր `Duration`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// Վերադառնում է իրական, եթե այս `Duration`-ը ժամանակ չի խնայում:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// Վերադարձնում է այս `Duration`-ի պարունակած _whole_ վայրկյանների քանակը:
    ///
    /// Վերադարձված արժեքը չի ներառում տևողության կոտորակային (nanosecond) մասը, որը կարելի է ձեռք բերել [`subsec_nanos`]-ի միջոցով:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration`-ով ներկայացված վայրկյանների ընդհանուր քանակը որոշելու համար օգտագործեք `as_secs` ՝ [`subsec_nanos`]-ի հետ միասին.
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// Վերադարձնում է այս `Duration`-ի կոտորակային մասը `միլիվայրկյաններով:
    ///
    /// Այս մեթոդը **չի** վերադարձնում տևողության տևողությունը, երբ ներկայացված է միլիվայրկյաններով:
    /// Վերադարձված թիվը միշտ ներկայացնում է վայրկյանի կոտորակային մասը (այսինքն ՝ մեկ հազարից պակաս է):
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// Վերադարձնում է այս `Duration`-ի կոտորակային մասը `ամբողջ միկրովայրկյանում:
    ///
    /// Այս մեթոդը **չի** վերադարձնում տևողության տևողությունը, երբ ներկայացված է միկրովայրկյանով:
    /// Վերադարձված թիվը միշտ ներկայացնում է վայրկյանի կոտորակային մասը (այսինքն `մեկ միլիոնից պակաս է):
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// Վերադառնում է այս `Duration`-ի կոտորակային մասը `նանովայրկյանով:
    ///
    /// Այս մեթոդը **չի** վերադարձնում տևողության տևողությունը, երբ ներկայացված է նանովայրկյանով:
    /// Վերադարձված թիվը միշտ ներկայացնում է վայրկյանի կոտորակային մասը (այսինքն ՝ մեկ միլիարդից պակաս է):
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// Վերադարձնում է այս `Duration`-ով պարունակվող ամբողջ միլիվայրկյանների ընդհանուր քանակը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// Վերադարձնում է այս `Duration`-ով պարունակվող ամբողջ միկրովայրկյանների ընդհանուր քանակը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// Վերադարձնում է այս `Duration`-ի պարունակած նանովայրկյանների ընդհանուր քանակը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// Ստուգված `Duration` լրացում:
    /// Հաշվարկում է `self + other`-ը, եթե գերհեղեղ է տեղի ունեցել, վերադարձնում է [`None`]-ը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Հագեցնելով `Duration` լրացումը:
    /// Հաշվարկում է `self + other`-ը, եթե գերհեղեղ է տեղի ունեցել, վերադարձնում է [`Duration::MAX`]-ը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// Ստուգված `Duration` հանում:
    /// Հաշվարկում է `self - other`-ը, վերադարձնելով [`None`]-ը, եթե արդյունքը բացասական կլինի, կամ եթե ջրհեղեղ է տեղի ունեցել:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Հագեցնելով `Duration` հանումը:
    /// Հաշվարկում է `self - other`-ը, վերադարձնելով [`Duration::ZERO`]-ը, եթե արդյունքը բացասական կլինի, կամ եթե ջրհեղեղ է տեղի ունեցել:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// Ստուգված `Duration` բազմապատկում:
    /// Հաշվարկում է `self * other`-ը, եթե գերհեղեղ է տեղի ունեցել, վերադարձնում է [`None`]-ը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // Բազմապատկեք նանովայրկյանները որպես u64, քանի որ այն չի կարող այդ կերպ հորդել:
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// Հագեցնելով `Duration` բազմապատկումը:
    /// Հաշվարկում է `self * other`-ը, եթե գերհեղեղ է տեղի ունեցել, վերադարձնում է [`Duration::MAX`]-ը:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// Ստուգված `Duration` բաժին:
    /// Հաշվարկում է `self / other`-ը, եթե `other == 0`-ը վերադարձնում է [`None`]:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Վերադարձնում է այս `Duration`-ի պարունակած վայրկյանների քանակը որպես `f64`:
    /// Վերադարձված արժեքն իր մեջ ներառում է տևողության կոտորակային (nanosecond) մասը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// Վերադարձնում է այս `Duration`-ի պարունակած վայրկյանների քանակը որպես `f32`:
    /// Վերադարձված արժեքն իր մեջ ներառում է տևողության կոտորակային (nanosecond) մասը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// Ստեղծում է նոր `Duration` նշված վայրկյանների քանակից, որը ներկայացված է որպես `f64`:
    ///
    /// # Panics
    /// Այս կոնստրուկտորը panic-ն է, եթե `secs` վերջավոր, բացասական չէ կամ `Duration` հորդում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// Ստեղծում է նոր `Duration` նշված վայրկյանների քանակից, որը ներկայացված է որպես `f32`:
    ///
    /// # Panics
    /// Այս կոնստրուկտորը panic-ն է, եթե `secs` վերջավոր, բացասական չէ կամ `Duration` հորդում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// Բազմապատկում է `Duration`-ը `f64`-ի վրա:
    /// # Panics
    /// Այս մեթոդը panic կլինի, եթե արդյունքը վերջավոր, բացասական չէ կամ `Duration`-ը հորդում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// Բազմապատկում է `Duration`-ը `f32`-ի վրա:
    /// # Panics
    /// Այս մեթոդը panic կլինի, եթե արդյունքը վերջավոր, բացասական չէ կամ `Duration`-ը հորդում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // նշենք, որ կլորացման սխալների պատճառով արդյունքը փոքր-ինչ տարբերվում է 8.478-ից և 847800.0-ից
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration`-ը բաժանեք `f64`-ի:
    /// # Panics
    /// Այս մեթոդը panic կլինի, եթե արդյունքը վերջավոր, բացասական չէ կամ `Duration`-ը հորդում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // նշենք, որ կոճկումը օգտագործվում է, ոչ թե կլորացվում
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration`-ը բաժանեք `f32`-ի:
    /// # Panics
    /// Այս մեթոդը panic կլինի, եթե արդյունքը վերջավոր, բացասական չէ կամ `Duration`-ը հորդում է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // նշենք, որ կլորացման սխալների պատճառով արդյունքը մի փոքր տարբերվում է 0.859_872_611-ից
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // նշենք, որ կոճկումը օգտագործվում է, ոչ թե կլորացվում
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration`-ը բաժանել `Duration`-ի և վերադարձնել `f64`:
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration`-ը բաժանել `Duration`-ի և վերադարձնել `f32`:
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// Տասնորդական նշագրման մեջ ձևավորում է լողացող կետի համարը:
        ///
        /// Թիվը տրված է որպես `integer_part` և կոտորակային մաս:
        /// Կոտորակային մասի արժեքը `fractional_part / divisor` է:
        /// Այսպիսով, `integer_part` =3, `fractional_part` =12 և `divisor` =100 ներկայացնում է `3.012` թիվը:
        /// Հետ մնացող զրոները բաց են թողնված:
        ///
        /// `divisor` չպետք է լինի 100_000_000-ից բարձր:
        /// Դա նույնպես պետք է լինի 10-ի ուժ, մնացած ամեն ինչ իմաստ չունի:
        /// `fractional_part` պետք է լինի `10 * divisor`-ից պակաս:
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // Կոտորակային մասը կոդավորեք ժամանակավոր բուֆերի մեջ:
            // Բուֆերը պետք է պահի միայն 9 տարր, քանի որ `fractional_part`-ը պետք է փոքր լինի 10 ^ 9-ից:
            //
            // Ստորև նշված կոդը պարզեցնելու համար բուֆերը նախալրացվում է '0' թվանշաններով:
            let mut buf = [b'0'; 9];

            // Հաջորդ նիշը գրված է այս դիրքում
            let mut pos = 0;

            // Մենք անընդհատ թվանշաններ ենք գրում բուֆերի մեջ, մինչ մնացել են ոչ զրոյական թվանշաններ, և մենք դեռ բավարար թվանշաններ չենք գրել:
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // Գրեք նոր թվանշան բուֆերի մեջ
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // Եթե հստակեցված էր <9 ճշգրտություն, հնարավոր է մնան ոչ զրոյական թվանշաններ, որոնք գրված չեն բուֆերի մեջ:
            // Այդ դեպքում մենք պետք է կլորացում կատարենք, որպեսզի համապատասխանի նորմալ լողացող կետերի թվերի տպման իմաստաբանությանը:
            // Այնուամենայնիվ, մենք պետք է աշխատանք կատարենք միայն պտտվելիս:
            // Դա տեղի է ունենում, եթե մնացածի առաջին նիշը>=5 է:
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // Կլորացրեք բուֆերի մեջ պարունակվող համարը:
                // Մենք անցնում ենք բուֆերի միջով հետ և հետևում ենք տեղափոխմանը:
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // Եթե բուֆերի թվանշանը '9' չէ, մենք պարզապես պետք է ավելացնենք այն և կարող ենք դադարեցնել այն (քանի որ մենք այլևս կրող չունենք):
                    // Հակառակ դեպքում, մենք այն դնում ենք '0' (overflow) և շարունակում ենք:
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // Եթե մենք դեռ ունենք կրման բիթի հավաքածու, դա նշանակում է, որ ամբողջ բուֆերը դնում ենք '0-ի և պետք է ավելացնենք ամբողջ մասը:
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // Որոշեք բուֆերի վերջը. Եթե ճշգրտությունը դրված է, մենք պարզապես նույնքան թվանշաններ ենք օգտագործում բուֆերից (ծածկված է մինչև 9):
            // Եթե այն դրված չէ, մենք օգտագործում ենք միայն բոլոր թվանշանները մինչև վերջին ոչ զրոյական:
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // Եթե մենք մեկ կոտորակային թվանշան չենք արտանետել, և ճշգրտությունը չի դրվել ոչ զրոյական արժեքի, մենք տասնորդական կետ չենք տպում:
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք միայն ASCII թվանշաններ ենք գրում բուֆերի մեջ և դա եղավ
                // սկզբնավորվել է «0» -ներով, ուստի այն պարունակում է վավեր UTF8:
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // Եթե օգտագործողը պահանջում է ճշգրտություն> 9, մենք վերջում պահում ենք «0»-ը:
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // Հարցման դեպքում տպեք առաջատար '+' նշանը
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}