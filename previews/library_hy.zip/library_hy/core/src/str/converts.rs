//! `str` բայթերի կտորից `str` ստեղծելու ուղիներ:

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Բայթերի մի կտոր վերածում է լարային հատվածի:
///
/// ([`&str`]) տողի կտորը կազմված է ([`u8`]) բայթից, իսկ ([`&[u8]`][byteslice]) բայթ կտորը ՝ բայթից, ուստի այս գործառույթը փոխարկվում է երկուսի միջև:
/// Այնուամենայնիվ, ոչ բոլոր բայտ կտորներն են լարային կտորների վավեր կտորներ, այնուամենայնիվ. [`&str`]-ը պահանջում է, որ այն վավեր UTF-8 լինի:
/// `from_utf8()` ստուգում է ՝ բայտերի UTF-8 վավերությունը ստուգելու համար, և այնուհետև կատարում է փոխարկումը:
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Եթե համոզված եք, որ բայտի կտորը վավեր է UTF-8, և դուք չեք ցանկանում կատարել վավերականության ստուգման գլխավերևը, կա այս գործառույթի ոչ անվտանգ տարբերակը ՝ [`from_utf8_unchecked`], որն ունի նույն վարքագիծը, բայց շրջանցում է ստուգումը:
///
///
/// Եթե `&str`-ի փոխարեն ձեզ `String` է պետք, հաշվի առեք [`String::from_utf8`][string]-ը:
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Քանի որ կարող եք բաշխել `[u8; N]`, և կարող եք վերցնել [`&[u8]`][byteslice] նրանից, այս ֆունկցիան դեղով հատկացված տող ունենալու միջոցներից մեկն է: Սրա մի օրինակ կա ստորև բերված օրինակների բաժնում:
///
/// [byteslice]: slice
///
/// # Errors
///
/// Վերադարձնում է `Err`, եթե կտորը UTF-8 չէ, նկարագրությամբ, թե ինչու տրամադրվող կտորը UTF-8 չէ:
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::str;
///
/// // որոշ բայթ ՝ vector-ում
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Մենք գիտենք, որ այս բայթերը վավեր են, այնպես որ պարզապես օգտագործեք `unwrap()`:
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Սխալ բայթ:
///
/// ```
/// use std::str;
///
/// // որոշ անվավեր բայթ vector-ում
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Տե՛ս [`Utf8Error`]-ի փաստաթղթերը ՝ հետ վերադարձնելու համար թույլ տրված սխալների մասին ավելի մանրամասն:
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // որոշ բայթ ՝ բուրգով հատկացված զանգվածում
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Մենք գիտենք, որ այս բայթերը վավեր են, այնպես որ պարզապես օգտագործեք `unwrap()`:
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ուղղակի վավերացումը վազեց:
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Բայթերի փոփոխվող կտորը վերափոխում է փոփոխվող լարի կտորի:
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" որպես փոփոխական vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Քանի որ գիտենք, որ այս բայթերը վավեր են, մենք կարող ենք օգտագործել `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Սխալ բայթ:
///
/// ```
/// use std::str;
///
/// // Մի քանի անվավեր բայթ փոփոխական vector-ում
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Տե՛ս [`Utf8Error`]-ի փաստաթղթերը ՝ հետ վերադարձնելու համար թույլ տրված սխալների մասին ավելի մանրամասն:
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ուղղակի վավերացումը վազեց:
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Բայթերի մի կտոր վերածում է լարի կտորի ՝ առանց ստուգելու, որ տողը պարունակում է վավեր UTF-8:
///
/// Տեսեք անվտանգ տարբերակը ՝ [`from_utf8`], լրացուցիչ տեղեկությունների համար:
///
/// # Safety
///
/// Այս գործառույթն անապահով է, քանի որ այն չի ստուգում, թե դրան փոխանցված բայթերը վավեր են UTF-8:
/// Եթե այդ կաշկանդումը խախտվում է, ապա չսահմանված վարքագիծ է առաջանում, քանի որ Rust-ի մնացած մասը ենթադրում է, որ [«&str»]-երը վավեր են UTF-8:
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::str;
///
/// // որոշ բայթ ՝ vector-ում
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `v` բայթը UTF-8 վավեր է:
    // Հենվում է նաև `&str` և `&[u8]` նույն դասավորության վրա:
    unsafe { mem::transmute(v) }
}

/// Բայթերի մի կտոր վերածում է տողի հատվածի ՝ առանց ստուգելու, որ տողը պարունակում է վավեր UTF-8;փոփոխական տարբերակ:
///
///
/// Տե՛ս անփոփոխ տարբերակը ՝ [`from_utf8_unchecked()`], լրացուցիչ տեղեկությունների համար:
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `v` բայթը
    // վավեր UTF-8 են, ուստի `*mut str`-ին տրված դերասանությունն անվտանգ է:
    // Բացի այդ, ցուցիչի հետաձգումը անվտանգ է, քանի որ այդ ցուցիչը գալիս է հղումից, որը երաշխավորված է, որ վավեր է գրելու համար:
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}