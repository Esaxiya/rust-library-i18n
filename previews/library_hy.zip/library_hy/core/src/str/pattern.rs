//! Լարը Pattern API:
//!
//! Pattern API-ն տողի միջոցով որոնելիս տարբեր մեխանիկական տեսակներ օգտագործելու ընդհանուր մեխանիզմ է տրամադրում:
//!
//! Լրացուցիչ մանրամասների համար տե՛ս traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] և [`DoubleEndedSearcher`]:
//!
//! Չնայած այս API-ն անկայուն է, այն ենթարկվում է կայուն API-ների միջոցով [`str`] տեսակի վրա:
//!
//! # Examples
//!
//! [`Pattern`] [implemented][pattern-impls]-ն է կայուն API-ում ՝ [`&str`][`str`], [`char`], [`char`] կտորների և `FnMut(char) -> bool`-ն իրականացնող գործառույթների ու փակման համար:
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // փայտի օրինակ
//! assert_eq!(s.find('n'), Some(2));
//! // բնույթի կտորի կտոր
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // փակման օրինակ
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Լարի նմուշ:
///
/// A `Pattern<'a>`-ն արտահայտում է, որ իրականացնող տեսակը կարող է օգտագործվել որպես տողի նմուշ [`&'a str`][str]-ում որոնելու համար:
///
/// Օրինակ ՝ և՛ `'a'`-ը, և՛ `"aa"` նմուշներ են, որոնք համապատասխանում են `"baaaab"` տողի `1` ինդեքսին:
///
/// trait-ն ինքնին հանդես է գալիս որպես հարակից [`Searcher`] տիպի կառուցող, որը կատարում է տողի մեջ օրինակի դեպքերի հայտնաբերման իրական աշխատանքը:
///
///
/// Կախված նմուշի տեսակից, [`str::find`] և [`str::contains`]-ի նման մեթոդների վարքագիծը կարող է փոխվել:
/// Ստորև բերված աղյուսակը նկարագրում է այդ վարքագծերից մի քանիսը:
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Այս նմուշի հետ կապված որոնող
    type Searcher: Searcher<'a>;

    /// Կառուցում է `self`-ի և `haystack`-ի հետ կապված որոնողը `որոնում կատարելու համար:
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Ստուգում է, թե արդյոք օրինակը համընկնում է խոտի դեզի ցանկացած վայրում
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Ստուգում է ՝ օրինաչափությունը համընկնում է խոտի դեզի դիմաց
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Ստուգում է `օրինաչափությունը համընկնում է խոտի դեզի հետնամասում
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Հեռացնում է նախշը խոտի դեզի առջևից, եթե այն համընկնում է:
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հայտնի է, որ `Searcher`-ը վերադարձնում է վավեր ինդեքսներ:
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Հեռացնում է նախշը խոտի դեզի հետևից, եթե այն համընկնում է:
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հայտնի է, որ `Searcher`-ը վերադարձնում է վավեր ինդեքսներ:
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] կամ [`ReverseSearcher::next_back()`] զանգահարելու արդյունք:
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Արտահայտում է, որ նախշի համընկնումը հայտնաբերվել է `haystack[a..b]`-ում:
    ///
    Match(usize, usize),
    /// Արտահայտում է, որ `haystack[a..b]`-ը մերժվել է որպես օրինաչափության հնարավոր համընկնում:
    ///
    /// Ուշադրություն դարձրեք, որ երկու «Խաղերի» միջև կարող է լինել մեկից ավելի `Reject`, որևէ պահանջ չկա, որ դրանք միավորվեն մեկի մեջ:
    ///
    ///
    Reject(usize, usize),
    /// Արտահայտում է, որ խոտի դեզի յուրաքանչյուր բայթ այցելվել է ՝ վերջ տալով կրկնությանը:
    ///
    Done,
}

/// Լարային նմուշի որոնիչ:
///
/// Այս trait-ն ապահովում է տողի առջևի (left)-ից սկսվող օրինակի ոչ համընկնող համընկնումների որոնման մեթոդներ:
///
/// Այն կիրականացվի [`Pattern`] trait-ի հարակից `Searcher` տեսակների միջոցով:
///
/// trait-ն նշվում է որպես անապահով, քանի որ [`next()`][Searcher::next] մեթոդներով վերադարձված ինդեքսները պահանջվում են խոտի դեզում գտնվել utf8 վավեր սահմանների վրա:
/// Սա հնարավորություն է տալիս այս trait-ի սպառողներին կտրել խոտի դեզը ՝ առանց արտահերթ ստուգումների:
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter ՝ հիմքում ընկած տողի համար, որը պետք է որոնել
    ///
    /// Միշտ կվերադարձնի նույն [`&str`][str]-ը:
    fn haystack(&self) -> &'a str;

    /// Կատարում է որոնման հաջորդ քայլը `սկսած առջևից:
    ///
    /// - Վերադարձնում է [`Match(a, b)`][SearchStep::Match], եթե `haystack[a..b]` համապատասխանում է օրինակին:
    /// - Վերադարձնում է [`Reject(a, b)`][SearchStep::Reject], եթե `haystack[a..b]`-ը չի կարող համընկնել օրինակին, նույնիսկ մասամբ:
    /// - Վերադարձնում է [`Done`][SearchStep::Done], եթե խոտի դեզի յուրաքանչյուր բայթ այցելված է:
    ///
    /// [`Match`][SearchStep::Match] և [`Reject`][SearchStep::Reject] արժեքների հոսքը մինչև [`Done`][SearchStep::Done] պարունակում է ինդեքսի միջակայքեր, որոնք հարակից են, չեն համընկնում, ծածկում են ամբողջ խոտի դեզը և դնում utf8 սահմաններ:
    ///
    ///
    /// [`Match`][SearchStep::Match] արդյունքը պետք է պարունակի ամբողջ համապատասխանեցված օրինակը, սակայն [`Reject`][SearchStep::Reject] արդյունքները կարող են բաժանվել կամայական շատ հարակից բեկորների: Երկու տիրույթները կարող են ունենալ զրո երկարություն:
    ///
    /// Որպես օրինակ, `"aaa"` օրինակը և խոտի դեզը `"cbaaaaab"` կարող են հոսք առաջացնել
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Գտնում է [`Match`][SearchStep::Match] հաջորդ արդյունքը: Տե՛ս [`next()`][Searcher::next]:
    ///
    /// Ի տարբերություն [`next()`][Searcher::next]-ի, երաշխիք չկա, որ այս և [`next_reject`][Searcher::next_reject]-ի վերադարձված միջակայքերը համընկնելու են:
    /// Սա կվերադարձնի `(start_match, end_match)`-ը, որտեղ start_match-ը հանդիպման սկզբի ինդեքսն է, իսկ end_match-ը `հանդիպման ավարտից հետո ցուցանիշը:
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Գտնում է [`Reject`][SearchStep::Reject] հաջորդ արդյունքը: Տե՛ս [`next()`][Searcher::next] և [`next_match()`][Searcher::next_match]:
    ///
    /// Ի տարբերություն [`next()`][Searcher::next]-ի, երաշխիք չկա, որ այս և [`next_match`][Searcher::next_match]-ի վերադարձված միջակայքերը համընկնելու են:
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Լարային նմուշի հակառակ որոնիչ:
///
/// Այս trait-ն ապահովում է տողի հետևի (right)-ից սկսած օրինակի ոչ համընկնող համընկնումների որոնման մեթոդներ:
///
/// Այն կիրականացվի [`Pattern`] trait-ի հարակից [`Searcher`] տեսակների միջոցով, եթե օրինակը աջակցում է հետևից փնտրելուն:
///
///
/// Այս trait-ի կողմից վերադարձված ինդեքսի միջակայքերը պարտադիր չեն, որ ճշգրտորեն համապատասխանեն հակառակ ուղղությամբ որոնման որոնման հատվածներին:
///
/// Այն պատճառով, որ այս trait-ն անվստահ է նշվում, տես նրանց ծնող trait [`Searcher`]:
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Կատարում է որոնման հաջորդ քայլը ՝ սկսած հետևից:
    ///
    /// - Վերադարձնում է [`Match(a, b)`][SearchStep::Match], եթե `haystack[a..b]` համապատասխանում է օրինակին:
    /// - Վերադարձնում է [`Reject(a, b)`][SearchStep::Reject], եթե `haystack[a..b]`-ը չի կարող համընկնել օրինակին, նույնիսկ մասամբ:
    /// - Վերադարձնում է [`Done`][SearchStep::Done], եթե խոտի դեզի յուրաքանչյուր բայթ այցելված է
    ///
    /// [`Match`][SearchStep::Match] և [`Reject`][SearchStep::Reject] արժեքների հոսքը մինչև [`Done`][SearchStep::Done] պարունակում է ինդեքսի միջակայքեր, որոնք հարակից են, չեն համընկնում, ծածկում են ամբողջ խոտի դեզը և դնում utf8 սահմաններ:
    ///
    ///
    /// [`Match`][SearchStep::Match] արդյունքը պետք է պարունակի ամբողջ համապատասխանեցված օրինակը, սակայն [`Reject`][SearchStep::Reject] արդյունքները կարող են բաժանվել կամայական շատ հարակից բեկորների: Երկու տիրույթները կարող են ունենալ զրո երկարություն:
    ///
    /// Որպես օրինակ, `"aaa"` նմուշը և խոտի դեզը `"cbaaaaab"` կարող են արտադրել `[Reject(7, 8), Match(4, 7), Reject(1, 4) հոսք, Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Գտնում է [`Match`][SearchStep::Match] հաջորդ արդյունքը:
    /// Տե՛ս [`next_back()`][ReverseSearcher::next_back]:
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Գտնում է [`Reject`][SearchStep::Reject] հաջորդ արդյունքը:
    /// Տե՛ս [`next_back()`][ReverseSearcher::next_back]:
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// trait նշիչ `արտահայտելու համար, որ [`ReverseSearcher`]-ը կարող է օգտագործվել [`DoubleEndedIterator`] իրականացման համար:
///
/// Դրա համար [`Searcher`] և [`ReverseSearcher`] ազդանշանները պետք է հետևեն հետևյալ պայմաններին.
///
/// - `next()`-ի բոլոր արդյունքները պետք է նույնական լինեն հակառակ կարգով `next_back()`-ի արդյունքներին:
/// - `next()` և `next_back()`-ը պետք է իրենց պահեն որպես մի շարք արժեքների երկու ծայրեր, այսինքն նրանք չեն կարող "walk past each other":
///
/// # Examples
///
/// `char::Searcher` `DoubleEndedSearcher` է, քանի որ [`char`] որոնելը պահանջում է միայն մեկին նայել միանգամից, որն իրեն նույն կերպ է պահում երկու ծայրերից:
///
/// `(&str)::Searcher` `DoubleEndedSearcher` չէ, քանի որ `"aa"` օրինակը խոտի դեզի մեջ `"aaa"` համընկնում է կամ `"[aa]a"` կամ `"a[aa]"`, կախված որ կողմից է այն որոնվում:
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl համար char
/////////////////////////////////////////////////////////////////////////////

/// Ասոցացված տեսակը `<char as Pattern<'a>>::Searcher`-ի համար:
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // անվտանգության անփոփոխ. `finger`/`finger_back`-ը պետք է լինի `haystack`-ի վավեր utf8 բայթ ցուցիչ: Այս անփոփոխը կարող է կոտրվել * * next_match-ի և next_match_back-ի սահմաններում, սակայն դրանք պետք է մատներով դուրս գան կոդային կետի վավեր սահմանների վրա:
    //
    //
    /// `finger` առաջ որոնման ընթացիկ բայթային ինդեքսն է:
    /// Պատկերացրեք, որ այն գոյություն ունի բայթից առաջ իր ինդեքսում, այսինքն
    /// `haystack[finger]` կտորի առաջին բայթն է, որը մենք պետք է ստուգենք առաջ որոնման ընթացքում
    ///
    finger: usize,
    /// `finger_back` հակառակ որոնման ընթացիկ բայթային ինդեքսն է:
    /// Պատկերացրեք, որ այն գոյություն ունի իր ինդեքսում բայթից հետո, այսինքն
    /// haystack [finger_back, 1] կտորի վերջին բայթն է, որը մենք պետք է ստուգենք առաջ որոնման ընթացքում (և, այդպիսով, առաջին բայթը, որը ստուգվում է next_back()) զանգահարելիս):
    ///
    finger_back: usize,
    /// Փնտրվող հերոսը
    needle: char,

    // անվտանգության անփոփոխ. `utf8_size`-ը պետք է լինի 5-ից պակաս
    /// `needle` բայթերի քանակը զբաղեցնում է utf8-ում կոդավորված ժամանակ:
    utf8_size: usize,
    /// X001-ի utf8 կոդավորված պատճենը
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. 1-4-ը երաշխավորում է `get_unchecked`-ի անվտանգությունը
        // 1. `self.finger` և `self.finger_back`-ը պահվում են unicode-ի սահմաններում (սա անփոփոխ է)
        // 2. `self.finger >= 0` քանի որ այն սկսվում է 0-ից և միայն ավելանում է
        // 3. `self.finger < self.finger_back` քանի որ հակառակ դեպքում char `iter`-ը կվերադարձներ `SearchStep::Done`
        // 4.
        // `self.finger` գալիս է խոտի դեզի ավարտից առաջ, քանի որ `self.finger_back`-ը սկսվում է վերջից և միայն նվազում է
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // ավելացնել ընթացիկ նիշի բայթային օֆսեթ ՝ առանց utf-8-ի վերանոդագրման
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // ստացեք խոտի դեզը հայտնաբերված վերջին նիշից հետո
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 կոդավորված ասեղի ԱՆՎՏԱՆԳՈՒԹՅԱՆ վերջին բայթը. մենք ունենք անփոփոխ որ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Նոր մատը մեր գտած բայտի ցուցիչն է, գումարած մեկ, քանի որ մենք հիշատակում ենք նիշի վերջին բայթը:
                //
                // Նշենք, որ դա միշտ չէ, որ մեզ մատ է տալիս UTF8 սահմանագծի վրա:
                // Եթե մենք * չէինք գտնում մեր բնավորությունը, մենք կարող ենք ինդեքսավորվել 3 բայթ կամ 4 բայթ նիշի ոչ վերջին բայթում:
                // Մենք չենք կարող պարզապես անցնել հաջորդ վավեր մեկնարկային բայթ, քանի որ character (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81`-ի նման նիշը կստիպի մեզ միշտ գտնել երրորդ բայթը երրորդը որոնելիս:
                //
                //
                // Այնուամենայնիվ, դա բոլորովին նորմալ է:
                // Չնայած մենք ունենք անփոփոխ, որ self.finger-ը գտնվում է UTF8 սահմանագծում, այս անփոփոխության վրա չի ապավինվում այս մեթոդի մեջ (այն ապավինում է CharSearcher::next())-ում:
                //
                // Մենք դուրս ենք գալիս այս մեթոդից միայն այն ժամանակ, երբ հասնում ենք լարի ծայրին, կամ եթե ինչ-որ բան գտնում ենք: Երբ մենք ինչ-որ բան գտնենք, `finger`-ը կտեղադրվի UTF8 սահման:
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ոչինչ չի գտել, ելք
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // թող next_reject-ը օգտագործի Searcher trait-ի կանխադրված իրականացումը
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տե՛ս վերևում next()-ի մեկնաբանությունը
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // հանել ընթացիկ նիշի բայթային օֆսեթը `առանց utf-8-ի վերանոդագրման
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // հասցրեք խոտի դեզը մինչև որոնված վերջին նիշը չներառված
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 կոդավորված ասեղի ԱՆՎՏԱՆԳՈՒԹՅԱՆ վերջին բայթը. մենք ունենք անփոփոխ որ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // մենք որոնեցինք մի կտոր, որը փոխհատուցվեց self.finger-ով, ավելացրեց self.finger ՝ սկզբնական ինդեքսը փոխհատուցելու համար
                //
                let index = self.finger + index;
                // memrchr-ը կվերադարձնի բայթի ինդեքսը, որը ցանկանում ենք գտնել:
                // ASCII նիշ ունենալու դեպքում սա, իսկապես, եթե մենք կցանկանայինք, որ մեր նոր մատը լիներ ("after"-ը ՝ հակառակ կրկնության պարադիգմում հայտնաբերված նշանը):
                //
                // Մուլտիմայթ բայերի համար մենք պետք է բաց թողնենք նրանց քանակով ավելի շատ բայթ, քան ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // մատը տեղափոխել նախքան հայտնաբերված նիշը (այսինքն ՝ իր մեկնարկի ցուցիչից)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Մենք չենք կարող այստեղ օգտագործել finger_back=index, size + 1:
                // Եթե մենք գտել ենք այլ չափի բնույթի վերջին նիշ (կամ այլ նիշի միջին բայթ), ապա մենք պետք է մատը հետ տանք մինչև `index`:
                // Նմանապես, `finger_back`-ը հնարավորություն ունի այլևս սահման չլինելու, բայց դա լավ է, քանի որ մենք այս գործառույթից դուրս ենք գալիս միայն սահմանի վրա, կամ երբ խոտի դեզը ամբողջությամբ որոնվում է:
                //
                //
                // Ի տարբերություն next_match-ի, սա utf-8-ում կրկնվող բայթերի խնդիր չունի, քանի որ մենք փնտրում ենք վերջին բայթը, և մենք կարող ենք գտնել միայն վերջին բայթը `հակառակ ուղղությամբ որոնելիս:
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ոչինչ չի գտել, ելք
                return None;
            }
        }
    }

    // թող next_reject_back-ն օգտագործի Searcher trait-ի կանխադրված իրականացումը
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Նիշերի որոնումներ, որոնք հավասար են տվյալ [`char`]-ի:
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ներդրեք MultiCharEq փաթաթան
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Համեմատեք ներքին բայթ հատվածի կրկնիչի երկարությունները `գտնելու ընթացիկ բնույթի երկարությունը
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Համեմատեք ներքին բայթ հատվածի կրկնիչի երկարությունները `գտնելու ընթացիկ բնույթի երկարությունը
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Տեղեկացնել&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Փոխել/հեռացնել `իմաստի երկիմաստության պատճառով:

/// Ասոցացված տեսակը `<&[char] as Pattern<'a>>::Searcher`-ի համար:
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Նիշերի որոնումներ, որոնք հավասար են հատվածի [`char]-ներից ցանկացածին:
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl F-ի համար: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Ասոցացված տեսակը `<F as Pattern<'a>>::Searcher`-ի համար:
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// [`Char`]-ի որոնումները, որոնք համապատասխանում են տրված նախդիրին:
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl for&&str
/////////////////////////////////////////////////////////////////////////////

/// Պատվիրակներ `&str` իմպլ.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl &str-ի համար
/////////////////////////////////////////////////////////////////////////////

/// Ենթալեզու որոնում չբաշխող որոնում:
///
/// Այն կկարգավորի `""` օրինակը ՝ վերադառնալով դատարկ համընկնումների յուրաքանչյուր նիշի սահմանում:
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Ստուգում է ՝ օրինաչափությունը համընկնում է խոտի դեզի դիմաց:
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Հեռացնում է նախշը խոտի դեզի առջևից, եթե այն համընկնում է:
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նախածանցը պարզապես ստուգվեց, որ գոյություն ունի:
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Ստուգում է `օրինաչափությունը համընկնում է խոտի դեզի հետնամասում:
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Հեռացնում է նախշը խոտի դեզի հետևից, եթե այն համընկնում է:
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ածանցը պարզապես ստուգվեց, որ գոյություն ունի:
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Երկու եղանակով ենթալեզու որոնող
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Ասոցացված տեսակը `<&str as Pattern<'a>>::Searcher`-ի համար:
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // դատարկ ասեղը մերժում է յուրաքանչյուր ածուխը և համընկնում յուրաքանչյուր դատարկ լարի միջեւ
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher-ը արտադրում է վավեր *Համապատասխանության* ինդեքսներ, որոնք բաժանվում են ածխի սահմաններում, քանի դեռ ճիշտ է համապատասխանում և խոտի դեզն ու ասեղը վավեր են, որպեսզի նրանք utf-8 անվտանգ լինեն:
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // անցնել հաջորդ նշագծին
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // դուրս գրեք `true` և `false` պատյաններ ՝ խրախուսելու համար, որ կազմողը երկու մասն առանձին մասնագիտացնի:
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // անցնել հաջորդ նշագծին
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // դուրս գրեք `true` և `false`, ինչպես `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Երկկողմանի ենթալար որոնման ալգորիթմի ներքին վիճակը:
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// կրիտիկական գործոնացման ինդեքս
    crit_pos: usize,
    /// հակադարձ ասեղի համար կարևոր գործոնների ինդեքսը
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ընդլայնում է (երկկողմանի ալգորիթմի մաս չէ);
    /// դա 64-բիթանոց "fingerprint" է, որտեղ յուրաքանչյուր բազմություն `j` համապատասխանում է ասեղում առկա (բայթ և 63)==ժ:
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// ինդեքսը ասեղի մեջ, որի առաջ մենք արդեն համապատասխանել ենք
    memory: usize,
    /// ինդեքսը ասեղի մեջ, որից հետո մենք արդեն համապատասխանել ենք
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Հատկապես ընթեռնելի բացատրություն այն մասին, թե ինչ է այստեղ կատարվում, կարելի է գտնել Crochemore-ի և Rytter-ի "Text Algorithms" գրքում, գլուխ 13:
        // Մասնավորապես տեսեք "Algorithm CP"-ի կոդը էջում:
        // 323.
        //
        // Ինչ է տեղի ունենում, մենք ունենք ասեղի որոշ կարևոր ֆակտորիզացիա (u, v), և ուզում ենք պարզել, թե արդյոք u-ն&v [.. ժամանակահատվածի] վերջածանց է:
        // Եթե այդպես է, մենք օգտագործում ենք "Algorithm CP1":
        // Հակառակ դեպքում մենք օգտագործում ենք "Algorithm CP2", որը օպտիմիզացված է այն դեպքում, երբ ասեղի ժամանակահատվածը մեծ է:
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // կարճ ժամանակահատվածի դեպք. ժամանակահատվածը ճշգրիտ է. հաշվարկեք առանձին քննադատական գործոնավորում հակադարձված ասեղի համար x=u 'v' որտեղ | v '|<period(x)
            //
            // Սա արագանում է արդեն հայտնի ժամանակահատվածով:
            // Ուշադրություն դարձրեք, որ x= "acba"-ի նման դեպքը կարող է ֆակտորացվել ճշգրիտ առաջ (krite_pos=1, ժամանակահատված=3), իսկ մոտավոր ժամանակահատվածով ֆակտորացվել հակառակ (crit_pos=2, ժամանակահատված=2):
            // Մենք օգտագործում ենք տրված հակառակ գործոնացումը, բայց պահում ենք ճշգրիտ ժամանակահատվածը:
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // երկար ժամանակի դեպք. մենք մոտավորություն ունենք իրական ժամանակահատվածի հետ և չենք օգտագործում անգիր:
            //
            //
            // Մոտավոր ժամանակահատվածը ստորին սահմանով max(|u|, |v|) + 1:
            // Կրիտիկական ֆակտորիզացիան արդյունավետ է ինչպես առաջ, այնպես էլ հակառակ որոնման համար:
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Կեղծ արժեք ՝ նշելու համար, որ ժամանակահատվածը երկար է
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Երկկողմանի հիմնական գաղափարներից մեկն այն է, որ մենք ասեղը գործոնավորենք երկու մասի (u, v) և սկսենք փորձել խոտի դեզում v գտնել ՝ ձախից աջ սկանավորելով:
    // Եթե v համընկնում է, մենք փորձում ենք համապատասխանել u-ին ՝ սկանավորելով աջից ձախ:
    // Որքանով կարող ենք ցատկել, երբ անհամապատասխանություն ենք ունենում, բոլորը հիմնված են այն փաստի վրա, որ (u, v) ասեղի համար կարևոր գործոն է:
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` օգտագործում է `self.position`-ը որպես իր կուրսորը
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Ստուգեք, որ տեղ ունենք որոնելու տեղ: + needle_last-ը չի կարող լցվել, եթե ենթադրենք, որ կտորները սահմանափակված են isize-ի տիրույթով:
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Արագորեն շրջանցեք մեր բաժինների հետ կապ չունեցող մեծ մասերի կողմից
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Տեսեք, թե արդյոք ասեղի աջ մասը համընկնում է
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Տեսեք, թե ասեղի ձախ հատվածը համընկնում է
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Մենք գտել ենք համընկնում:
            let match_pos = self.position;

            // Note: needle.len()-ի փոխարեն ավելացնել self.period, որպեսզի համընկնող համընկնումներ լինեն
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // դրված է needle.len(), self.period համընկնող համընկնումների համար
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Հետևում է `next()`-ի գաղափարներին:
    //
    // Սահմանումները սիմետրիկ են. period(x) = period(reverse(x)) և local_period(u, v) = local_period(reverse(v), reverse(u)), ուստի եթե (u, v) կրիտիկական գործոն է, ապա (reverse(v), reverse(u)).
    //
    //
    // Հակառակ դեպքում մենք հաշվարկել ենք x=u 'v' (`crit_pos_back` դաշտ) կրիտիկական գործոնացումը: Մեզ պետք է | u |<period(x) փոխանցվող գործի համար և այդպիսով | v '|<period(x) հակադարձի համար:
    //
    // Դեպի հակառակ խոտի դեզը որոնելու համար մենք հետադարձ որոնվածքով խոտի դեզի միջոցով փնտրում ենք հակառակ ասեղով `նախ համապատասխանեցնելով u-ին և ապա v-ին:
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` օգտագործում է `self.end`-ը որպես իր կուրսորը-այնպես, որ `next()` և `next_back()` անկախ լինեն:
        //
        let old_end = self.end;
        'search: loop {
            // Ստուգեք, որ վերջում տեղ ունենք որոնելու, needle.len()-ը կփաթաթվի այն ժամանակ, երբ այլևս տեղ չի մնա, բայց կտորների երկարության սահմանափակումների պատճառով այն երբեք չի կարող ամբողջությամբ փաթաթվել խոտի դեզի երկարության մեջ:
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Արագորեն շրջանցեք մեր բաժինների հետ կապ չունեցող մեծ մասերի կողմից
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Տեսեք, թե ասեղի ձախ հատվածը համընկնում է
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Տեսեք, թե արդյոք ասեղի աջ մասը համընկնում է
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Մենք գտել ենք համընկնում:
            let match_pos = self.end - needle.len();
            // Note: ենթավերն self.period-ը needle.len()-ի փոխարեն ունենալ համընկնող համընկնումներ
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Հաշվիր `arr`-ի առավելագույն ածանցը:
    //
    // Առավելագույն ածանցը `arr`-ի հնարավոր կրիտիկական գործոնացումն է (u, v):
    //
    // Վերադարձնում է (`i`, `p`), որտեղ `i`-ը v-ի մեկնարկային ինդեքսն է, իսկ `p`-ը` v ժամանակահատվածը:
    //
    // `order_greater` որոշում է ՝ արդյոք բառարանային կարգը `<` է, թե `>`:
    // Երկու պատվերն էլ պետք է հաշվարկվեն. Ամենամեծ `i`- ով պատվերը տալիս է կարևոր ֆակտորիզացիա:
    //
    //
    // Երկար ժամանակահատվածների դեպքում ստացված ժամանակահատվածը ճշգրիտ չէ (չափազանց կարճ է):
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Թղթում համապատասխանում է i-ին
        let mut right = 1; // Թղթում համապատասխանում է j-ին
        let mut offset = 0; // Թղթում համապատասխանում է k-ին, բայց սկսվում է 0-ից
        // 0-ի վրա հիմնված ինդեքսավորմանը համապատասխանելու համար:
        let mut period = 1; // Թղթում համապատասխանում է p-ին

        while let Some(&a) = arr.get(right + offset) {
            // `left` կլինի ներգնա, երբ `right`-ը լինի:
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Ածանցը փոքր է, մինչև վերջ ժամանակահատվածը ամբողջ նախածանցն է:
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ընթացիկ ժամանակաշրջանի կրկնության միջոցով առաջընթաց:
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Ածանցն ավելի մեծ է. Սկսեք ընթացիկ վայրից:
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Հաշվիր `arr`-ի հակադարձի առավելագույն վերջածանցը:
    //
    // Առավելագույն ածանցը `arr`-ի հնարավոր կրիտիկական գործոնացումն է (u ', v'):
    //
    // Վերադարձնում է `i`, որտեղ `i`-ը v-ի մեկնարկային ինդեքսն է ՝ հետևից;
    // վերադառնում է անմիջապես, երբ `known_period` ժամանակահատված է հասնում:
    //
    // `order_greater` որոշում է ՝ արդյոք բառարանային կարգը `<` է, թե `>`:
    // Երկու պատվերն էլ պետք է հաշվարկվեն. Ամենամեծ `i`- ով պատվերը տալիս է կարևոր ֆակտորիզացիա:
    //
    //
    // Երկար ժամանակահատվածների դեպքում ստացված ժամանակահատվածը ճշգրիտ չէ (չափազանց կարճ է):
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Թղթում համապատասխանում է i-ին
        let mut right = 1; // Թղթում համապատասխանում է j-ին
        let mut offset = 0; // Թղթում համապատասխանում է k-ին, բայց սկսվում է 0-ից
        // 0-ի վրա հիմնված ինդեքսավորմանը համապատասխանելու համար:
        let mut period = 1; // Թղթում համապատասխանում է p-ին
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Ածանցը փոքր է, մինչև վերջ ժամանակահատվածը ամբողջ նախածանցն է:
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ընթացիկ ժամանակաշրջանի կրկնության միջոցով առաջընթաց:
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Ածանցն ավելի մեծ է. Սկսեք ընթացիկ վայրից:
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy-ն ալգորիթմին թույլ է տալիս հնարավորինս արագ բաց թողնել ոչ համընկնումները կամ աշխատել այնպիսի ռեժիմով, որտեղ այն համեմատաբար արագ արձակում է Մերժում:
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Որքան հնարավոր է արագ անցեք համապատասխանության միջակայքերին
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit-ը պարբերաբար մերժում է
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}