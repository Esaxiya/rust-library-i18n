//! Լարի մանիպուլյացիա:
//!
//! Լրացուցիչ մանրամասների համար տե՛ս [`std::str`] մոդուլը:
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. սահմաններից դուրս
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. սկսել <=վերջ
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. բնույթի սահման
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // գտնել բնավորությունը
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` պետք է լինի պակաս, քան len և char սահմանը
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Վերադարձնում է `self` երկարությունը:
    ///
    /// Այս երկարությունը բայթերով է, այլ ոչ թե ``char`-ի կամ գծապատկերների:
    /// Այլ կերպ ասած, կարող է լինել այն, ինչ մարդը համարում է լարի երկարությունը:
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // շքեղ f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Վերադարձնում է `true`, եթե `self`-ն ունի զրո բայթ երկարություն:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ստուգում է, որ «ինդեքս»-րդ բայթը UTF-8 կոդի կետային հաջորդականության կամ տողի վերջի առաջին բայթն է:
    ///
    ///
    /// Լարի մեկնարկը և ավարտը (երբ `index== self.len()`) համարվում են սահմաններ:
    ///
    /// Վերադարձնում է `false`, եթե `index`-ը `self.len()`-ից մեծ է:
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老`-ի մեկնարկը
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` երկրորդ բայթ
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` երրորդ բայթ
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0-ը և len-ը միշտ լավ են:
        // Պարզապես փորձեք 0-ի համար, որպեսզի այն կարողանա հեշտությամբ ստուգել ստուգումը և բաց թողնել այդ գործի համար տողի տվյալները:
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Սա մի քիչ մոգություն է համարժեք ՝ b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Լարի կտորը վերածում է բայտի կտորի:
    /// Բայթ հատվածը լարային հատված դարձնելու համար օգտագործեք [`from_utf8`] գործառույթը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հնչյուն է, քանի որ մենք փոխում ենք երկու տեսակի նույն դասավորությամբ
        unsafe { mem::transmute(self) }
    }

    /// Փոփոխվող լարի կտորը վերափոխում է փոփոխվող բայթ հատվածի:
    ///
    /// # Safety
    ///
    /// Calանգահարողը պետք է համոզվի, որ կտորի պարունակությունը վավեր է UTF-8 մինչ վարկի ավարտը և հիմքում ընկած `str` օգտագործումը:
    ///
    ///
    /// `str`-ի օգտագործումը, որի բովանդակությունը վավեր չէ UTF-8, չսահմանված վարք է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `&str`-ից `&[u8]` գիպսը անվտանգ է `str`-ից
        // ունի նույն դասավորությունը, ինչպես `&[u8]` (միայն libstd-ն է կարող տալ այս երաշխիքը):
        // Սլաքի ցուցիչի անվտանգությունը անվտանգ է, քանի որ այն գալիս է փոփոխվող հղումից, որը երաշխավորված է, որ վավեր է գրելու համար:
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Լարի կտորը վերածում է հում ցուցիչի:
    ///
    /// Քանի որ լարային կտորները բայթերի կտոր են, հում ցուցիչը ցույց է տալիս [`u8`]:
    /// Այս ցուցիչը ցույց կտա լարային հատվածի առաջին բայթը:
    ///
    /// Theանգահարողը պետք է համոզվի, որ վերադարձված ցուցիչը երբեք գրված չէ:
    /// Եթե Ձեզ անհրաժեշտ է մուտային հատվածի բովանդակությունը մուտացիայի ենթարկելու համար, օգտագործեք [`as_mut_ptr`]:
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Փոփոխական լարի կտորը վերածում է հում ցուցիչի:
    ///
    /// Քանի որ լարային կտորները բայթերի կտոր են, հում ցուցիչը ցույց է տալիս [`u8`]:
    /// Այս ցուցիչը ցույց կտա լարային հատվածի առաջին բայթը:
    ///
    /// Ձեր պարտականությունն է համոզվել, որ լարային հատվածը փոփոխվում է միայն այնպես, որ այն վավեր մնա UTF-8:
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Վերադարձնում է `str` ենթաբաժին:
    ///
    /// Սա `str` ինդեքսավորման ոչ խուճապային այլընտրանք է:
    /// Վերադարձնում է [`None`], երբ համարժեք ինդեքսավորման գործողությունը panic է:
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ցուցանիշներ, որոնք չեն գտնվում UTF-8 հաջորդականության սահմաններում
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // սահմաններից դուրս
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Վերադարձնում է `str`-ի փոփոխվող ենթավանդակ:
    ///
    /// Սա `str` ինդեքսավորման ոչ խուճապային այլընտրանք է:
    /// Վերադարձնում է [`None`], երբ համարժեք ինդեքսավորման գործողությունը panic է:
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ճիշտ երկարությունը
    /// assert!(v.get_mut(0..5).is_some());
    /// // սահմաններից դուրս
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Վերադարձնում է `str`-ի չստուգված ենթաբաժինը:
    ///
    /// Սա `str` ինդեքսավորելու չստուգված այլընտրանքն է:
    ///
    /// # Safety
    ///
    /// Այս գործառույթի զանգահարողները պատասխանատու են, որ այդ նախապայմանները բավարարվեն.
    ///
    /// * Մեկնարկային ինդեքսը չպետք է գերազանցի ավարտի ինդեքսը.
    /// * Ինդեքսները պետք է լինեն բնօրինակ հատվածի սահմաններում.
    /// * Ինդեքսները պետք է ընկած լինեն UTF-8 հաջորդականության սահմանների վրա:
    ///
    /// Եթե դա չլինի, վերադարձված տողի կտորը կարող է վկայակոչել անվավեր հիշողություն կամ խախտել `str` տիպի միջոցով հաղորդվող անփոփոխները:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `get_unchecked`-ի անվտանգության պայմանագիրը.
        // կտորը հետընտրելի է, քանի որ `self`-ը անվտանգ տեղեկանք է:
        // Վերադարձված ցուցիչը անվտանգ է, քանի որ `SliceIndex`-ի ազդանշանները պետք է երաշխավորեն, որ դա այդպես է:
        unsafe { &*i.get_unchecked(self) }
    }

    /// Վերադարձնում է `str`-ի փոփոխվող, չստուգված ենթավանդակը:
    ///
    /// Սա `str` ինդեքսավորելու չստուգված այլընտրանքն է:
    ///
    /// # Safety
    ///
    /// Այս գործառույթի զանգահարողները պատասխանատու են, որ այդ նախապայմանները բավարարվեն.
    ///
    /// * Մեկնարկային ինդեքսը չպետք է գերազանցի ավարտի ինդեքսը.
    /// * Ինդեքսները պետք է լինեն բնօրինակ հատվածի սահմաններում.
    /// * Ինդեքսները պետք է ընկած լինեն UTF-8 հաջորդականության սահմանների վրա:
    ///
    /// Եթե դա չլինի, վերադարձված տողի կտորը կարող է վկայակոչել անվավեր հիշողություն կամ խախտել `str` տիպի միջոցով հաղորդվող անփոփոխները:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `get_unchecked_mut`-ի անվտանգության պայմանագիրը.
        // կտորը հետընտրելի է, քանի որ `self`-ը անվտանգ տեղեկանք է:
        // Վերադարձված ցուցիչը անվտանգ է, քանի որ `SliceIndex`-ի ազդանշանները պետք է երաշխավորեն, որ դա այդպես է:
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Ստեղծում է լարային հատված մեկ այլ լարային հատվածից ՝ շրջանցելով անվտանգության ստուգումները:
    ///
    /// Սա սովորաբար խորհուրդ չի տրվում, օգտագործեք զգուշորեն: Անվտանգ այլընտրանքի համար տե՛ս [`str`] և [`Index`]:
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Այս նոր հատվածը `begin`-ից անցնում է `end`, ներառյալ `begin`, բայց չհաշված `end`:
    ///
    /// Փոխարենը փոխելի լարի կտոր ստանալու համար տե՛ս [`slice_mut_unchecked`] մեթոդը:
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Այս գործառույթի զանգահարողները պատասխանատու են, որ բավարարվեն երեք նախապայմաններ.
    ///
    /// * `begin` չպետք է գերազանցի `end`-ը:
    /// * `begin` և `end`-ը պետք է լինեն բայտի դիրքեր լարային հատվածի մեջ:
    /// * `begin` և `end`-ը պետք է ընկած լինեն UTF-8 հաջորդականության սահմանների վրա:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `get_unchecked`-ի անվտանգության պայմանագիրը.
        // կտորը հետընտրելի է, քանի որ `self`-ը անվտանգ տեղեկանք է:
        // Վերադարձված ցուցիչը անվտանգ է, քանի որ `SliceIndex`-ի ազդանշանները պետք է երաշխավորեն, որ դա այդպես է:
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Ստեղծում է լարային հատված մեկ այլ լարային հատվածից ՝ շրջանցելով անվտանգության ստուգումները:
    /// Սա սովորաբար խորհուրդ չի տրվում, օգտագործեք զգուշորեն: Անվտանգ այլընտրանքի համար տե՛ս [`str`] և [`IndexMut`]:
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Այս նոր հատվածը `begin`-ից անցնում է `end`, ներառյալ `begin`, բայց չհաշված `end`:
    ///
    /// Փոխարենը լարի անփոփոխ կտոր ստանալու համար տե՛ս [`slice_unchecked`] մեթոդը:
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Այս գործառույթի զանգահարողները պատասխանատու են, որ բավարարվեն երեք նախապայմաններ.
    ///
    /// * `begin` չպետք է գերազանցի `end`-ը:
    /// * `begin` և `end`-ը պետք է լինեն բայտի դիրքեր լարային հատվածի մեջ:
    /// * `begin` և `end`-ը պետք է ընկած լինեն UTF-8 հաջորդականության սահմանների վրա:
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `get_unchecked_mut`-ի անվտանգության պայմանագիրը.
        // կտորը հետընտրելի է, քանի որ `self`-ը անվտանգ տեղեկանք է:
        // Վերադարձված ցուցիչը անվտանգ է, քանի որ `SliceIndex`-ի ազդանշանները պետք է երաշխավորեն, որ դա այդպես է:
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Մեկ լարային շերտը ինդեքսով բաժանեք երկու մասի:
    ///
    /// Փաստարկը ՝ `mid`, պետք է լինի բայթ օֆսեթ տողի սկզբից:
    /// Այն պետք է լինի նաև UTF-8 կոդի կետի սահմանագծին:
    ///
    /// Վերադարձված երկու կտորները լարային հատվածի սկզբից տեղափոխվում են `mid`, իսկ `mid`-ից ՝ լարային հատվածի վերջ:
    ///
    /// Փոխարենը ստացվող փոփոխվող լարի կտորներ ստանալու համար տե՛ս [`split_at_mut`] մեթոդը:
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics եթե `mid`-ը UTF-8 կոդի կետի սահմանագծում չէ, կամ եթե այն անցել է լարի կտորի վերջին կոդի կետի վերջը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary-ն ստուգում է, որ ցուցանիշը գտնվում է [0, .len()]
        if self.is_char_boundary(mid) {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց նոր ստուգվեց, որ `mid`-ը լիցքավորված է:
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ինդեքսով մեկ փոփոխվող լարի կտորը բաժանեք երկու մասի:
    ///
    /// Փաստարկը ՝ `mid`, պետք է լինի բայթ օֆսեթ տողի սկզբից:
    /// Այն պետք է լինի նաև UTF-8 կոդի կետի սահմանագծին:
    ///
    /// Վերադարձված երկու կտորները լարային հատվածի սկզբից տեղափոխվում են `mid`, իսկ `mid`-ից ՝ լարային հատվածի վերջ:
    ///
    /// Փոխարենը լարի անփոփոխ կտորներ ստանալու համար տե՛ս [`split_at`] մեթոդը:
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics եթե `mid`-ը UTF-8 կոդի կետի սահմանագծում չէ, կամ եթե այն անցել է լարի կտորի վերջին կոդի կետի վերջը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary-ն ստուգում է, որ ցուցանիշը գտնվում է [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց նոր ստուգվեց, որ `mid`-ը լիցքավորված է:
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Վերադառնում է կրկնիչը լարային հատվածի [«char»] վրայով:
    ///
    /// Քանի որ լարի կտորը բաղկացած է վավեր UTF-8-ից, մենք կարող ենք կրկնել [`char`]-ի լարային հատվածի միջոցով:
    /// Այս մեթոդը վերադարձնում է նման կրկնիչը:
    ///
    /// Կարևոր է հիշել, որ [`char`]-ը ներկայացնում է Unicode Scalar արժեքը և կարող է չհամընկնել այն գաղափարի հետ, թե ինչ է իրենից ներկայացնում 'character':
    ///
    /// Գրաֆեմի կլաստերների վրա կրկնությունը կարող է լինել այն, ինչ իրականում ցանկանում եք:
    /// Այս գործառույթը չի տրամադրվում Rust-ի ստանդարտ գրադարանում, փոխարենը ստուգեք crates.io:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Հիշե՛ք, [«char» »-ները կարող են չհամընկնել նիշերի վերաբերյալ ձեր ինտուիցիային.
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ոչ 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Վերադառնում է կրկնիչը լարային հատվածի [`char]]-ների և դրանց դիրքերի վրայով:
    ///
    /// Քանի որ լարի կտորը բաղկացած է վավեր UTF-8-ից, մենք կարող ենք կրկնել [`char`]-ի լարային հատվածի միջոցով:
    /// Այս մեթոդը վերադարձնում է ինչպես այս [`char]-ների կրկնիչը, այնպես էլ նրանց բայթ դիրքերը:
    ///
    /// Կրկնվողը տրոհ է տալիս: Դիրքն առաջինն է, [`char`]-ը ՝ երկրորդը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Հիշե՛ք, [«char» »-ները կարող են չհամընկնել նիշերի վերաբերյալ ձեր ինտուիցիային.
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ոչ (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // նշեք այստեղ 3-ը, վերջին նիշը երկու բայթ է գրավել
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Կրկնիչ լարային հատվածի բայթերի վրա:
    ///
    /// Քանի որ լարի կտորը բաղկացած է բայթերի հաջորդականությունից, մենք կարող ենք կրկնել լարային հատվածի միջոցով բայթը:
    /// Այս մեթոդը վերադարձնում է նման կրկնիչը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Լարի կտորը բաժանում է ըստ տարածության տարածության:
    ///
    /// Վերադարձած կրկնիչը կվերադարձնի լարի կտորները, որոնք նախնական լարային հատվածի ենթաշերտեր են, առանձնացված ցանկացած տարածության բաց տարածքով:
    ///
    ///
    /// 'Whitespace' սահմանվում է ըստ Unicode Derived Core Property `White_Space`-ի պայմանների:
    /// Եթե փոխարենը ցանկանում եք բաժանվել միայն ASCII սպիտակ տարածության վրա, օգտագործեք [`split_ascii_whitespace`]:
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Դիտարկվում են բոլոր տեսակի սպիտակ տարածքները.
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Լարում է տողի բաժինը ASCII սպիտակ տարածության կողմից:
    ///
    /// Վերադարձված կրկնիչը կվերադարձնի լարի կտորները, որոնք նախնական լարային հատվածի ենթաշերտեր են, առանձնացված ASCII սպիտակ տարածության ցանկացած քանակով:
    ///
    ///
    /// Փոխարենը բաժանվելու համար Unicode `Whitespace`-ի, օգտագործեք [`split_whitespace`]:
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Դիտարկվում են բոլոր տեսակի ASCII սպիտակ տարածքները.
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Կրկնվողը լարի գծերի վրայով ՝ որպես լարային կտորներ:
    ///
    /// Տողերն ավարտվում են կամ նոր գիծ (`\n`) կամ փոխադրման վերադարձ ՝ գծի հոսքով (`\r\n`):
    ///
    /// Վերջնական տողի ավարտը պարտադիր չէ:
    /// Լարը, որն ավարտվում է վերջնական տողի վերջավորությամբ, կվերադարձնի նույն տողերը, ինչպես այլապես նույնական տողը ՝ առանց վերջնական տողի ավարտի:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Վերջնական տողի ավարտը չի պահանջվում.
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Իտերիայի գծերի վրայով կրկնվող:
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Վերադարձնում է `u16` կրկնիչը UTF-16 կոդավորված տողի վրայով:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Վերադարձնում է `true`, եթե տրված օրինակը համընկնում է այս լարային հատվածի ենթաբաժնի:
    ///
    /// Վերադարձնում է `false`, եթե դա չի անում:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Վերադարձնում է `true`, եթե տրված օրինակը համապատասխանում է այս լարային հատվածի նախածանցին:
    ///
    /// Վերադարձնում է `false`, եթե դա չի անում:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Վերադարձնում է `true`, եթե տրված օրինակը համընկնում է այս լարային հատվածի ածանցի հետ:
    ///
    /// Վերադարձնում է `false`, եթե դա չի անում:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Վերադարձնում է այս տողի հատվածի առաջին նիշի բայթ ցուցիչը, որը համապատասխանում է օրինակին:
    ///
    /// Վերադառնում է [`None`], եթե օրինակը չի համապատասխանում:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Ավելի բարդ նմուշներ, որոնք օգտագործում են առանց կետի ոճ և փակումներ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Չգտնելով օրինաչափությունը.
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Վերադառնում է բայտի ինդեքսը այս տողի կտորի օրինակի ամենահարմար համընկնումի առաջին նիշի համար:
    ///
    /// Վերադառնում է [`None`], եթե օրինակը չի համապատասխանում:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Ավելի բարդ նմուշներ փակմամբ.
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Չգտնելով օրինաչափությունը.
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Այս լարային հատվածի ենթալարերի վրայի կրկնիչը ՝ առանձնացված նիշերով, որոնք համընկնում են օրինաչափության հետ:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը կլինի [`DoubleEndedIterator`], եթե օրինակը թույլ է տալիս հակառակ որոնում կատարել, և forward/reverse որոնումը տալիս է նույն տարրերը:
    /// Սա ճիշտ է, օրինակ, [`char`]-ի համար, բայց ոչ `&str`-ի:
    ///
    /// Եթե օրինակը թույլ է տալիս հակադարձ որոնում կատարել, բայց դրա արդյունքները կարող են տարբերվել առաջ որոնումից, ապա կարելի է օգտագործել [`rsplit`] մեթոդը:
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Եթե նմուշը բնույթի կտոր է, բաժանեք հերոսներից որևէ մեկի յուրաքանչյուր դեպքի.
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Ավելի բարդ օրինաչափություն, օգտագործելով փակումը.
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Եթե տողը պարունակում է բազմաթիվ հարակից բաժանարարներ, ապա արդյունքի մեջ դուք վերջում կունենաք դատարկ տողեր.
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Կողքին բաժանարարները բաժանվում են դատարկ լարով:
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Լարի սկզբում կամ վերջում բաժանարարները հարևան են դատարկ լարերով:
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Երբ դատարկ տողը օգտագործվում է որպես տարանջատիչ, այն բաժանվում է լարի յուրաքանչյուր նիշի ՝ լարի սկզբի և վերջի հետ միասին:
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Հարակից տարանջատիչները կարող են հանգեցնել հնարավոր զարմանալի վարքի, երբ սպիտակ տարածությունն օգտագործվում է որպես տարանջատիչ: Այս կոդը ճիշտ է.
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Դա ձեզ _not_ տալիս է ՝
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Այս վարքի համար օգտագործեք [`split_whitespace`]:
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Այս լարային հատվածի ենթալարերի վրայի կրկնիչը ՝ առանձնացված նիշերով, որոնք համընկնում են օրինաչափության հետ:
    /// `split`-ի կողմից արտադրված կրկնիչից տարբերվում է նրանով, որ `split_inclusive`-ը համընկնող մասը թողնում է որպես ենթալարի վերջավորիչ:
    ///
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Եթե տողի վերջին տարրը համընկնում է, այդ տարրը կդիտվի նախորդ ենթալարի վերջավորիչը:
    /// Այդ ենթատողը կդառնա կրկնվողի կողմից վերադարձված վերջին նյութը:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Տրված տողի հատվածի ենթալարերի վրայի կրկնիչը ՝ առանձնացված նիշերով, որոնք համընկնում են օրինակի հետ և տալիս են հակառակ կարգով:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը պահանջում է, որ օրինակը աջակցի հակառակ որոնմանը, և դա կլինի [`DoubleEndedIterator`], եթե forward/reverse որոնումը տա նույն տարրերը:
    ///
    ///
    /// Առջևից կրկնելու համար կարելի է օգտագործել [`split`] մեթոդը:
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Ավելի բարդ օրինաչափություն, օգտագործելով փակումը.
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Տրված տողի հատվածի ենթալարերի վրայի կրկնիչը ՝ առանձնացված նմուշով, որը համապատասխանում է օրինաչափությանը:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Համարժեք է [`split`]-ի, բացառությամբ այն բանի, որ հետևի ենթալարը շրջանցվում է, եթե դատարկ է:
    ///
    /// [`split`]: str::split
    ///
    /// Այս մեթոդը կարող է օգտագործվել տողի տվյալների համար, որոնք _terminated_ են, այլ ոչ թե _separated_ օրինակով:
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը կլինի [`DoubleEndedIterator`], եթե օրինակը թույլ է տալիս հակառակ որոնում կատարել, և forward/reverse որոնումը տալիս է նույն տարրերը:
    /// Սա ճիշտ է, օրինակ, [`char`]-ի համար, բայց ոչ `&str`-ի:
    ///
    /// Եթե օրինակը թույլ է տալիս հակադարձ որոնում կատարել, բայց դրա արդյունքները կարող են տարբերվել առաջ որոնումից, ապա կարելի է օգտագործել [`rsplit_terminator`] մեթոդը:
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self`-ի ենթալարերի վրայի կրկնիչը `առանձնացված նիշերով, որոնք համընկնում են օրինակի հետ և տալիս են հակառակ կարգով:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Համարժեք է [`split`]-ի, բացառությամբ այն բանի, որ հետևի ենթալարը շրջանցվում է, եթե դատարկ է:
    ///
    /// [`split`]: str::split
    ///
    /// Այս մեթոդը կարող է օգտագործվել տողի տվյալների համար, որոնք _terminated_ են, այլ ոչ թե _separated_ օրինակով:
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը պահանջում է, որ օրինակը աջակցի հակառակ որոնմանը, և այն կրկնակի կավարտվի, եթե forward/reverse որոնումը տա նույն տարրերը:
    ///
    ///
    /// Առջևից կրկնելու համար կարելի է օգտագործել [`split_terminator`] մեթոդը:
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Տրված տողի հատվածի ենթալարերի վրայի կրկնիչը, որը բաժանված է նախշով, սահմանափակվում է առավելագույնը `n` իրերի վերադարձով:
    ///
    /// Եթե `n` ենթատողերը վերադարձվեն, վերջին ենթալարը («n`-րդ ենթալարը») կպարունակի լարի մնացած մասը:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը կրկնակի չի լինի, քանի որ աջակցելը արդյունավետ չէ:
    ///
    /// Եթե օրինաչափությունը թույլ է տալիս հակառակ որոնում կատարել, ապա կարող է օգտագործվել [`rsplitn`] մեթոդը:
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Ավելի բարդ օրինաչափություն, օգտագործելով փակումը.
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Այս լարային հատվածի ենթալարերի վրայի կրկնիչը, որը նախշով բաժանված է, սկսած լարի վերջից, սահմանափակվում է առավելագույնը `n` իրերի վերադարձով:
    ///
    ///
    /// Եթե `n` ենթատողերը վերադարձվեն, վերջին ենթալարը («n`-րդ ենթալարը») կպարունակի լարի մնացած մասը:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը կրկնակի չի լինի, քանի որ աջակցելը արդյունավետ չէ:
    ///
    /// Առջևից պառակտման համար կարող է օգտագործվել [`splitn`] մեթոդը:
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Ավելի բարդ օրինաչափություն, օգտագործելով փակումը.
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Բաժանում է տողը նշված սահմանազատիչի առաջին առաջացման վրա և վերադարձնում նախածանցը սահմանազատողից առաջ և վերջածանցը սահմանազատողից հետո:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Բաժանում է տողը նշված սահմանաբանի վերջին առաջացման վրա և վերադառնում նախածանցը մինչ սահմանազատիչը, իսկ վերջածանցը սահմանազատողից հետո:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Տրված տողի կտորի ներսում օրինակի տարանջատված համընկնումների կրկնիչը:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը կլինի [`DoubleEndedIterator`], եթե օրինակը թույլ է տալիս հակառակ որոնում կատարել, և forward/reverse որոնումը տալիս է նույն տարրերը:
    /// Սա ճիշտ է, օրինակ, [`char`]-ի համար, բայց ոչ `&str`-ի:
    ///
    /// Եթե օրինակը թույլ է տալիս հակադարձ որոնում կատարել, բայց դրա արդյունքները կարող են տարբերվել առաջ որոնումից, ապա կարելի է օգտագործել [`rmatches`] մեթոդը:
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Այս լարային հատվածի մեջ գտնվող նմուշի տարանջատված համընկնումների կրկնիչը կատարվեց հակառակ կարգով:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը պահանջում է, որ օրինակը աջակցի հակառակ որոնմանը, և դա կլինի [`DoubleEndedIterator`], եթե forward/reverse որոնումը տա նույն տարրերը:
    ///
    ///
    /// Առջևից կրկնելու համար կարելի է օգտագործել [`matches`] մեթոդը:
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Այս լարային հատվածի օրինակի տարանջատված համընկնումների, ինչպես նաև այն ցուցանիշի, որի սկզբից սկսվում է հանդիպումը, կրկնիչը:
    ///
    /// `self`-ի ներսում `pat` հանդիպումների համար, որոնք համընկնում են, վերադարձվում են միայն առաջին խաղին համապատասխան ցուցանիշները:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը կլինի [`DoubleEndedIterator`], եթե օրինակը թույլ է տալիս հակառակ որոնում կատարել, և forward/reverse որոնումը տալիս է նույն տարրերը:
    /// Սա ճիշտ է, օրինակ, [`char`]-ի համար, բայց ոչ `&str`-ի:
    ///
    /// Եթե օրինակը թույլ է տալիս հակադարձ որոնում կատարել, բայց դրա արդյունքները կարող են տարբերվել առաջ որոնումից, ապա կարելի է օգտագործել [`rmatch_indices`] մեթոդը:
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // միայն առաջին `aba`-ը
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self`-ի օրինաչափության տարանջատված համընկնումների կրկնիչը հետադարձ կարգով զիջեց համընկնումի ցուցիչին:
    ///
    /// `self`-ի ներսում `pat` հանդիպումների համար, որոնք համընկնում են, վերադարձվում են միայն վերջին խաղին համապատասխան ցուցանիշները:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Իտերատորի վարք
    ///
    /// Վերադարձված կրկնիչը պահանջում է, որ օրինակը աջակցի հակառակ որոնմանը, և դա կլինի [`DoubleEndedIterator`], եթե forward/reverse որոնումը տա նույն տարրերը:
    ///
    ///
    /// Առջևից կրկնելու համար կարելի է օգտագործել [`match_indices`] մեթոդը:
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // միայն վերջին `aba`-ը
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Վերադառնում է լարային հատված ՝ առաջատար և հետևող սպիտակ տարածությունը հեռացված:
    ///
    /// 'Whitespace' սահմանվում է ըստ Unicode Derived Core Property `White_Space`-ի պայմանների:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Վերադառնում է լարային հատված `առաջատար սպիտակ տարածությունը հեռացվածով:
    ///
    /// 'Whitespace' սահմանվում է ըստ Unicode Derived Core Property `White_Space`-ի պայմանների:
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// `start` այս համատեքստում նշանակում է այդ բայթ տողի առաջին դիրքը.անգլերենից կամ ռուսերենից նման ձախից աջ լեզվի համար սա կլինի ձախ կողմը, իսկ արաբերենից կամ եբրայերենից աջից ձախ լեզուների համար սա կլինի աջ կողմը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Վերադառնում է լարային հատված `հետևի սպիտակ տարածությունը հեռացվածով:
    ///
    /// 'Whitespace' սահմանվում է ըստ Unicode Derived Core Property `White_Space`-ի պայմանների:
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// `end` այս համատեքստում նշանակում է այդ բայթ տողի վերջին դիրքը.ձախից աջ լեզվի համար, ինչպիսին է անգլերենը կամ ռուսերենը, դա կլինի աջ կողմը, իսկ աջից ձախ լեզուների համար, ինչպիսիք են արաբերենը կամ եբրայերենը, դա կլինի ձախ կողմը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Վերադառնում է լարային հատված `առաջատար սպիտակ տարածությունը հեռացվածով:
    ///
    /// 'Whitespace' սահմանվում է ըստ Unicode Derived Core Property `White_Space`-ի պայմանների:
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// 'Left' այս համատեքստում նշանակում է այդ բայթ տողի առաջին դիրքը.Արաբերենի կամ եբրայերենի նման լեզվի համար, որոնք ավելի շուտ «աջից ձախ» են, քան «ձախից աջ», սա կլինի _right_ կողմը, ոչ թե ձախ:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Վերադառնում է լարային հատված `հետևի սպիտակ տարածությունը հեռացվածով:
    ///
    /// 'Whitespace' սահմանվում է ըստ Unicode Derived Core Property `White_Space`-ի պայմանների:
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// 'Right' այս համատեքստում նշանակում է այդ բայթ տողի վերջին դիրքը.Արաբերենի կամ եբրայերենի նման լեզվի համար, որոնք «աջից ձախ» են, քան «ձախից աջ», սա կլինի _left_ կողմը, ոչ թե ճիշտը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Վերադարձնում է լարի կտորը բոլոր նախածանցներով և ածանցներով, որոնք համընկնում են մի քանի անգամ հեռացված օրինակին:
    ///
    /// [pattern]-ը կարող է լինել [`char`], [«char»-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Ավելի բարդ օրինաչափություն, օգտագործելով փակումը.
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Հիշեք ամենավաղ հայտնի համընկնումը, ուղղեք ստորև, եթե
            // վերջին հանդիպումը տարբեր է
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հայտնի է, որ `Searcher`-ը վերադարձնում է վավեր ինդեքսներ:
        unsafe { self.get_unchecked(i..j) }
    }

    /// Վերադարձնում է լարի կտորը բոլոր նախածանցներով, որոնք համընկնում են բազմիցս հանված նախշի հետ:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// `start` այս համատեքստում նշանակում է այդ բայթ տողի առաջին դիրքը.անգլերենից կամ ռուսերենից նման ձախից աջ լեզվի համար սա կլինի ձախ կողմը, իսկ արաբերենից կամ եբրայերենից աջից ձախ լեզուների համար սա կլինի աջ կողմը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հայտնի է, որ `Searcher`-ը վերադարձնում է վավեր ինդեքսներ:
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Վերադարձնում է լարի կտորը հեռացված նախածանցով:
    ///
    /// Եթե տողը սկսվում է `prefix` օրինակով, `Some`-ով փաթաթված նախածանցից հետո ենթալարը վերադառնում է:
    /// Ի տարբերություն `trim_start_matches`-ի, այս մեթոդը վերացնում է նախածանցը ուղիղ մեկ անգամ:
    ///
    /// Եթե տողը չի սկսվում `prefix`-ով, ապա վերադարձնում է `None`:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Վերադառնում է լարային կտոր `հանված ածանցով:
    ///
    /// Եթե լարը ավարտվում է `suffix` օրինակով, ապա ենթատողը վերադարձնում է `Some`-ով փաթաթված ածանցից առաջ:
    /// Ի տարբերություն `trim_end_matches`-ի, այս մեթոդը ածանցը հանում է ճիշտ մեկ անգամ:
    ///
    /// Եթե տողը չի ավարտվում `suffix`-ով, ապա վերադարձնում է `None`:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Վերադարձնում է լարի կտորը բոլոր ածանցներով, որոնք համընկնում են բազմիցս հանված նախշին:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// `end` այս համատեքստում նշանակում է այդ բայթ տողի վերջին դիրքը.ձախից աջ լեզվի համար, ինչպիսին է անգլերենը կամ ռուսերենը, դա կլինի աջ կողմը, իսկ աջից ձախ լեզուների համար, ինչպիսիք են արաբերենը կամ եբրայերենը, դա կլինի ձախ կողմը:
    ///
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ավելի բարդ օրինաչափություն, օգտագործելով փակումը.
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հայտնի է, որ `Searcher`-ը վերադարձնում է վավեր ինդեքսներ:
        unsafe { self.get_unchecked(0..j) }
    }

    /// Վերադարձնում է լարի կտորը բոլոր նախածանցներով, որոնք համընկնում են բազմիցս հանված նախշի հետ:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// 'Left' այս համատեքստում նշանակում է այդ բայթ տողի առաջին դիրքը.Արաբերենի կամ եբրայերենի նման լեզվի համար, որոնք ավելի շուտ «աջից ձախ» են, քան «ձախից աջ», սա կլինի _right_ կողմը, ոչ թե ձախ:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Վերադարձնում է լարի կտորը բոլոր ածանցներով, որոնք համընկնում են բազմիցս հանված նախշին:
    ///
    /// [pattern]-ը կարող է լինել `&str`, [`char`], ['char`]-ի կտոր կամ գործառույթ կամ փակում, որը որոշում է նիշի համընկնումը:
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Տեքստի ուղղվածություն
    ///
    /// Լարը բայթերի հաջորդականություն է:
    /// 'Right' այս համատեքստում նշանակում է այդ բայթ տողի վերջին դիրքը.Արաբերենի կամ եբրայերենի նման լեզվի համար, որոնք «աջից ձախ» են, քան «ձախից աջ», սա կլինի _left_ կողմը, ոչ թե ճիշտը:
    ///
    ///
    /// # Examples
    ///
    /// Պարզ նախշեր.
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ավելի բարդ օրինաչափություն, օգտագործելով փակումը.
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Այս լարը կտրում է մեկ այլ տեսակի:
    ///
    /// Քանի որ `parse`-ն այնքան ընդհանուր է, դա կարող է խնդիրներ առաջացնել տիպի եզրակացության հետ կապված:
    /// Որպես այդպիսին, `parse`-ը այն եզակի դեպքերից մեկն է, երբ կտեսնեք շարահյուսությունը սիրով հայտնի որպես 'turbofish': `::<>`.
    ///
    /// Սա օգնում է եզրակացության ալգորիթմին հասկանալ, թե հատկապես որ տեսակի եք փորձում վերլուծել:
    ///
    /// `parse` կարող է վերլուծվել ցանկացած տեսակի մեջ, որն իրականացնում է [`FromStr`] trait:
    ///

    /// # Errors
    ///
    /// [`Err`]-ը կվերադարձնի, եթե հնարավոր չլինի այս լարային հատվածը վերլուծել ցանկալի տեսակի մեջ:
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործումը
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// X001 ծանոթագրության փոխարեն օգտագործելով 'turbofish':
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Չհաջողվեց վերլուծել.
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Ստուգում է, արդյոք այս տողի բոլոր նիշերը ASCII տիրույթում են:
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Այստեղ յուրաքանչյուր բայթ կարող ենք վերաբերվել որպես նիշ. Բոլոր բազմաբայթ նիշերը սկսվում են բայթից, որը ascii տիրույթում չէ, ուստի մենք այնտեղ արդեն կանգ կառնենք:
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Ստուգում է, որ երկու տողերը ASCII գործի նկատմամբ անզգայացուցիչ համընկնում են:
    ///
    /// Նույնը, ինչ `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, բայց առանց ժամանակագրերին հատկացնելու և պատճենելու:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Այս տողը վերափոխում է իր ASCII մեծատառի համարժեք տեղում:
    ///
    /// ASCII 'a'-ից 'z' տառերը քարտեզագրվում են 'A'-ից 'Z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Առանց եղածը փոփոխելու ՝ նոր մեծատառ արժեք վերադարձնելու համար օգտագործեք [`to_ascii_uppercase()`]:
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անվտանգ, քանի որ մենք փոխում ենք երկու տեսակի նույն դասավորությամբ:
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Այս տողը վերափոխում է իր ASCII փոքրատառ տեղում:
    ///
    /// ASCII 'A'-ից 'Z' տառերը քարտեզագրվում են 'a'-ից 'z', բայց ոչ ASCII տառերը անփոփոխ են:
    ///
    /// Առանց եղածը փոփոխելու `նոր փոքր արժեք վերադարձնելու համար օգտագործեք [`to_ascii_lowercase()`]:
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անվտանգ, քանի որ մենք փոխում ենք երկու տեսակի նույն դասավորությամբ:
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Վերադարձրեք կրկնիչի, որը `self`-ով [`char::escape_debug`]-ով խուսափում է յուրաքանչյուր քարից:
    ///
    ///
    /// Note: կփախչվեն միայն երկարացված գրաֆեմային կոդային կետերից, որոնք սկսում են լարը:
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Վերադարձրեք կրկնիչի, որը `self`-ով [`char::escape_default`]-ով խուսափում է յուրաքանչյուր քարից:
    ///
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Վերադարձրեք կրկնիչի, որը `self`-ով [`char::escape_unicode`]-ով խուսափում է յուրաքանչյուր քարից:
    ///
    ///
    /// # Examples
    ///
    /// Որպես iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ուղղակիորեն օգտագործելով `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Երկուսն էլ համարժեք են.
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Օգտագործելով `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Ստեղծում է դատարկ տող
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Ստեղծում է դատարկ փոփոխվող փ
    #[inline]
    fn default() -> Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Դատարկ տողը վավեր է UTF-8:
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Անվանական, կլոնավորվող fn տեսակ
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անվտանգ չէ
        unsafe { from_utf8_unchecked(bytes) }
    };
}