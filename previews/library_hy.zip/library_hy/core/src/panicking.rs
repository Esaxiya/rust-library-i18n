//! Panic աջակցություն libcore-ին
//!
//! Հիմնական գրադարանը չի կարող սահմանել խուճապը, բայց դա *հայտարարում է* խուճապի մատնվելու մասին:
//! Սա նշանակում է, որ libcore-ի ներսում գործառույթները թույլատրվում են panic, բայց հոսանքն ի վեր crate-ն օգտակար լինելու համար պետք է խուճապ սահմանի, որպեսզի libcore-ն օգտագործի:
//! Խուճապի մատուցման ներկայիս ինտերֆեյսն է.
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Այս սահմանումը թույլ է տալիս խուճապի մատնվել ցանկացած ընդհանուր հաղորդագրության հետ, բայց դա թույլ չի տալիս ձախողել `Box<Any>` արժեքը:
//! (`PanicInfo`-ը պարզապես պարունակում է `&(dyn Any + Send)`, որի համար մենք «PanicInfo: : internal_constructor» բառում լրացնում ենք կեղծ արժեք): Դրա պատճառն այն է, որ libcore-ին չի թույլատրվում հատկացնել:
//!
//!
//! Այս մոդուլը պարունակում է խուճապի մատնման մի քանի այլ գործառույթներ, բայց սրանք պարզապես կազմողի համար անհրաժեշտ լեզուներն են: Բոլոր panics-ներն ուղեկցվում են այս մեկ գործառույթի միջոցով:
//! Իրական խորհրդանիշը հայտարարվում է `#[panic_handler]` հատկանիշի միջոցով:
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore-ի `panic!` մակրոի հիմքում ընկած իրականացումը, երբ ձևաչափ չի օգտագործվում:
#[cold]
// երբեք մի շարադրեք, եթե հնարավոր չէ panic_immediate_abort-ը `հնարավորինս խուսափելու համար զանգի կայքերում կոդերի փչումից
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // Codegen-ի համար անհրաժեշտ է panic-ի համար արտահոսքի և `Assert` MIR այլ վերջավորիչների վրա
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Օգտագործեք Arguments::new_v1 ՝ format_args-ի փոխարեն («{}», expr) ՝ գլխավերևի չափը հավանականորեն նվազեցնելու համար:
    // Ձևաչափը_ազարդերը: macro-ն օգտագործում է str's Display trait-ը expr գրելու համար, որը կոչ է անում Formatter::pad, որը պետք է տեղավորի լարի կտրում և լրացում (չնայած այստեղ ոչ մեկը չի օգտագործվում):
    //
    // Arguments::new_v1-ի օգտագործումը կարող է թույլ տալ, որ կազմողը դուրս թողնի Formatter::pad ելքային երկուականից ՝ խնայելով մինչև մի քանի կիլոբայթ:
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // անհրաժեշտ է գնահատված panics-ի համար
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // անհրաժեշտ է codegen-ի կողմից OOB array/slice մուտքի վրա panic-ի համար
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Ձևաչափման ժամանակ օգտագործվում է libcore-ի `panic!` մակրոի հիմքում ընկած իրականացումը:
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Նշում Այս գործառույթը երբեք չի հատում FFI սահմանը.դա Rust-to-Rust զանգ է, որը լուծվում է `#[panic_handler]` գործառույթի համար:
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `panic_impl`-ը սահմանվում է անվտանգ Rust ծածկագրում, ուստի զանգահարելն անվտանգ է:
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Ներքին գործառույթը `assert_eq!` և `assert_ne!` մակրոների համար
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}