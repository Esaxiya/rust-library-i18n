//! Կազմող բնածիններ.
//!
//! Համապատասխան սահմանումները `compiler/rustc_codegen_llvm/src/intrinsic.rs`-ում են:
//! Համապատասխան կոնստրուկցիաների իրականացումը `compiler/rustc_mir/src/interpret/intrinsics.rs`-ում է
//!
//! # Կոնստ - ներ
//!
//! Note: Ներքինների կայունության ցանկացած փոփոխություն պետք է քննարկվի լեզվի թիմի հետ:
//! Սա ներառում է կայունության կայունության փոփոխություններ:
//!
//! Կոմպիլյացիայի ժամանակ ներքինը օգտագործելի դարձնելու համար հարկավոր է պատճենել կատարումը <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>-ից `compiler/rustc_mir/src/interpret/intrinsics.rs` և ներդիրին ավելացնել `#[rustc_const_unstable(feature = "foo", issue = "01234")]`:
//!
//!
//! Եթե ենթադրվում է, որ `rustc_const_stable` հատկանիշով `const fn`-ից օգտագործվելու է ներքին, այն նույնպես պետք է լինի `rustc_const_stable`:
//! Նման փոփոխությունը չպետք է կատարվի առանց T-lang-ի խորհրդատվության, քանի որ այն լեզու է ներմուծում մի առանձնահատկություն, որը հնարավոր չէ կրկնօրինակել օգտվողի կոդում առանց կազմողի աջակցության:
//!
//! # Volatiles
//!
//! Անկայուն ներքինները տրամադրում են գործողություններ, որոնք նախատեսված են I/O հիշողության վրա գործելու համար, որոնք երաշխավորված են, որ կազմողը չի վերադասավորի այլ անկայուն ներքիններին: Տե՛ս LLVM փաստաթղթերը [[volatile]]-ի վրա:
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Ատոմային բնույթները տրամադրում են ընդհանուր ատոմային գործողություններ մեքենայական բառերի վրա, հիշողության բազմակի հնարավոր դասավորություններով: Նրանք ենթարկվում են նույն իմաստաբանությանը, ինչ C++ 11:Տե՛ս LLVM փաստաթղթերը [[atomics]]-ի վրա:
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Արագ թարմացում հիշողության պատվերի հարցում.
//!
//! * Ձեռք բերեք, կողպեք ձեռք բերելու արգելք: Հետագա կարդալը և գրելը տեղի են ունենում արգելապատնեշից հետո:
//! * Ազատում, կողպեք բացելու արգելք: Նախորդող ընթերցանությունը և գրելը տեղի են ունենում արգելապատնեշից առաջ:
//! * Հերթականորեն հետեւողական, հաջորդականորեն հետեւողական գործողությունները երաշխավորված են, որ տեղի կունենան ըստ հերթականության: Սա ատոմային տիպերի հետ աշխատելու ստանդարտ ռեժիմն է և համարժեք է Java-ի `volatile`-ին:
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Այս ներմուծումներն օգտագործվում են ներլոգային հղումները պարզեցնելու համար
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տե՛ս `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, այդ ներքինները վերցնում են հում ցուցիչները, քանի որ դրանք մուտացիայի են ենթարկում այլանուն հիշողությունը, որը վավեր չէ ոչ `&`-ի, ոչ `&mut`-ի համար:
    //

    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տեսակների վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::SeqCst`] ինչպես `success`, այնպես էլ `failure` պարամետրեր:
    ///
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տեսակների վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::Acquire`] ինչպես `success`, այնպես էլ `failure` պարամետրեր:
    ///
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::Release`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::AcqRel`] որպես `success` և [`Ordering::Acquire`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տեսակների վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::Relaxed`] ինչպես `success`, այնպես էլ `failure` պարամետրեր:
    ///
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::SeqCst`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::SeqCst`] որպես `success` և [`Ordering::Acquire`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::Acquire`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange` մեթոդի միջոցով ՝ անցնելով [`Ordering::AcqRel`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տեսակների վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::SeqCst`] ինչպես `success`, այնպես էլ `failure` պարամետրեր:
    ///
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տեսակների վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::Acquire`] ինչպես `success`, այնպես էլ `failure` պարամետրեր:
    ///
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::Release`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::AcqRel`] որպես `success` և [`Ordering::Acquire`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տեսակների վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::Relaxed`] ինչպես `success`, այնպես էլ `failure` պարամետրեր:
    ///
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::SeqCst`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::SeqCst`] որպես `success` և [`Ordering::Acquire`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::Acquire`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Արժեք է պահում, եթե ընթացիկ արժեքը նույնն է, ինչ `old` արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `compare_exchange_weak` մեթոդի միջոցով ՝ անցնելով [`Ordering::AcqRel`] որպես `success` և [`Ordering::Relaxed`] որպես `failure` պարամետրեր:
    /// Օրինակ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Բեռնվում է ցուցիչի ընթացիկ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `load` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Բեռնվում է ցուցիչի ընթացիկ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `load` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Բեռնվում է ցուցիչի ընթացիկ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `load` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Արժեքը պահում է նշված հիշողության վայրում:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `store` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Արժեքը պահում է նշված հիշողության վայրում:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `store` մեթոդի միջոցով ՝ [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Արժեքը պահում է նշված հիշողության վայրում:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `store` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Արժեքը պահում է նշված հիշողության վայրում ՝ վերադարձնելով հին արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `swap` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Արժեքը պահում է նշված հիշողության վայրում ՝ վերադարձնելով հին արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `swap` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Արժեքը պահում է նշված հիշողության վայրում ՝ վերադարձնելով հին արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `swap` մեթոդի միջոցով ՝ [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Արժեքը պահում է նշված հիշողության վայրում ՝ վերադարձնելով հին արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `swap` մեթոդի միջոցով ՝ [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Արժեքը պահում է նշված հիշողության վայրում ՝ վերադարձնելով հին արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `swap` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ավելացնում է ընթացիկ արժեքին ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_add` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ավելացնում է ընթացիկ արժեքին ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_add` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ավելացնում է ընթացիկ արժեքին ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_add` մեթոդի միջոցով ՝ [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ավելացնում է ընթացիկ արժեքին ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_add` մեթոդի միջոցով ՝ [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ավելացնում է ընթացիկ արժեքին ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_add` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Հանեք ընթացիկ արժեքից ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_sub` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Հանեք ընթացիկ արժեքից ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_sub` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Հանեք ընթացիկ արժեքից ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_sub` մեթոդի միջոցով ՝ [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Հանեք ընթացիկ արժեքից ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_sub` մեթոդի միջոցով ՝ անցնելով [`Ordering::AcqRel`] որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Հանեք ընթացիկ արժեքից ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_sub` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_and` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_and` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_and` մեթոդի միջոցով ՝ [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_and` մեթոդի միջոցով ՝ [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_and` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`AtomicBool`] տիպի վրա `fetch_nand` մեթոդի միջոցով ՝ անցնելով [`Ordering::SeqCst`] որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`AtomicBool`] տիպի վրա `fetch_nand` մեթոդի միջոցով ՝ անցնելով [`Ordering::Acquire`] որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`AtomicBool`] տիպի վրա `fetch_nand` մեթոդի միջոցով ՝ անցնելով [`Ordering::Release`] որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`AtomicBool`] տիպի վրա `fetch_nand` մեթոդի միջոցով ՝ անցնելով [`Ordering::AcqRel`] որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise և ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`AtomicBool`] տիպի վրա `fetch_nand` մեթոդի միջոցով ՝ անցնելով [`Ordering::Relaxed`] որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise կամ ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_or` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise կամ ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_or` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise կամ ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_or` մեթոդի միջոցով ՝ [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise կամ ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_or` մեթոդի միջոցով ՝ [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise կամ ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_or` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_xor` մեթոդի միջոցով ՝ [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_xor` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_xor` մեթոդի միջոցով ՝ [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_xor` մեթոդի միջոցով ՝ [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ընթացիկ արժեքով, վերադարձնելով նախորդ արժեքը:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] տիպերի վրա `fetch_xor` մեթոդի միջոցով ՝ [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_max` մեթոդի միջոցով [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակի վրա `fetch_max` մեթոդի միջոցով ՝ [`Ordering::Acquire`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_max` մեթոդի միջոցով [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_max` մեթոդի միջոցով [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքով:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_max` մեթոդի միջոցով [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_min` մեթոդի միջոցով [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_min` մեթոդի միջոցով [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_min` մեթոդի միջոցով [`Ordering::Release`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_min` մեթոդի միջոցով [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով ստորագրված համեմատություն:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic`] ստորագրված ամբողջ տեսակների վրա `fetch_min` մեթոդի միջոցով [`Ordering::Relaxed`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_min` մեթոդի միջոցով [`Ordering::SeqCst`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_min` մեթոդի միջոցով [`Ordering::Acquire`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_min` մեթոդի միջոցով [`Ordering::Release`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_min` մեթոդի միջոցով [`Ordering::AcqRel`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Նվազագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_min` մեթոդի միջոցով [`Ordering::Relaxed`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_max` մեթոդի միջոցով [`Ordering::SeqCst`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_max` մեթոդի միջոցով [`Ordering::Acquire`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_max` մեթոդի միջոցով [`Ordering::Release`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_max` մեթոդի միջոցով [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Առավելագույնը ընթացիկ արժեքի հետ `օգտագործելով անստորագիր համեմատություն:
    ///
    /// Այս ներքին կայունացված տարբերակը հասանելի է [`atomic`] չստորագրված ամբողջ տեսակի վրա `fetch_max` մեթոդի միջոցով [`Ordering::Relaxed`]-ը փոխանցելով որպես `order`:
    /// Օրինակ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` բնույթը հուշում է կոդերի գեներատորին `աջակցելու դեպքում նախադրյալ հրահանգը տեղադրելու համար.հակառակ դեպքում դա no-op է:
    /// Նախընտրումները ոչ մի ազդեցություն չեն ունենում ծրագրի վարքի վրա, բայց կարող են փոխել դրա կատարողական բնութագրերը:
    ///
    /// `locality` արգումենտը պետք է լինի անընդհատ ամբողջ թիվ և ժամանակավոր տեղորոշման բնութագրիչ է ՝ սկսած (0), առանց տեղայնության, մինչև (3), չափազանց տեղական պահված է քեշում:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` բնույթը հուշում է կոդերի գեներատորին `աջակցելու դեպքում նախադրյալ հրահանգը տեղադրելու համար.հակառակ դեպքում դա no-op է:
    /// Նախընտրումները ոչ մի ազդեցություն չեն ունենում ծրագրի վարքի վրա, բայց կարող են փոխել դրա կատարողական բնութագրերը:
    ///
    /// `locality` արգումենտը պետք է լինի անընդհատ ամբողջ թիվ և ժամանակավոր տեղորոշման բնութագրիչ է ՝ սկսած (0), առանց տեղայնության, մինչև (3), չափազանց տեղական պահված է քեշում:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` բնույթը հուշում է կոդերի գեներատորին `աջակցելու դեպքում նախադրյալ հրահանգը տեղադրելու համար.հակառակ դեպքում դա no-op է:
    /// Նախընտրումները ոչ մի ազդեցություն չեն ունենում ծրագրի վարքի վրա, բայց կարող են փոխել դրա կատարողական բնութագրերը:
    ///
    /// `locality` արգումենտը պետք է լինի անընդհատ ամբողջ թիվ և ժամանակավոր տեղորոշման բնութագրիչ է ՝ սկսած (0), առանց տեղայնության, մինչև (3), չափազանց տեղական պահված է քեշում:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` բնույթը հուշում է կոդերի գեներատորին `աջակցելու դեպքում նախադրյալ հրահանգը տեղադրելու համար.հակառակ դեպքում դա no-op է:
    /// Նախընտրումները ոչ մի ազդեցություն չեն ունենում ծրագրի վարքի վրա, բայց կարող են փոխել դրա կատարողական բնութագրերը:
    ///
    /// `locality` արգումենտը պետք է լինի անընդհատ ամբողջ թիվ և ժամանակավոր տեղորոշման բնութագրիչ է ՝ սկսած (0), առանց տեղայնության, մինչև (3), չափազանց տեղական պահված է քեշում:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ատոմային ցանկապատ:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::fence`]-ում [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    ///
    ///
    pub fn atomic_fence();
    /// Ատոմային ցանկապատ:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::fence`]-ում [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ատոմային ցանկապատ:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::fence`]-ում [`Ordering::Release`]-ն անցնելով որպես `order`:
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ատոմային ցանկապատ:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::fence`]-ում [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Միայն կազմողի հիշողության խոչընդոտ:
    ///
    /// Կազմողի կողմից հիշողությունների մուտքերը երբեք չեն վերադասավորվի այս արգելքի միջով, բայց դրա համար ոչ մի հրահանգ չի արտանետվի:
    /// Սա հարմար է նույն թեմայի վրա գործողություններին, որոնք կարող են կանխատեսվել, օրինակ ՝ ազդանշանի կարգաբերողների հետ փոխազդելիս:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::compiler_fence`]-ում [`Ordering::SeqCst`]-ն անցնելով որպես `order`:
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Միայն կազմողի հիշողության խոչընդոտ:
    ///
    /// Կազմողի կողմից հիշողությունների մուտքերը երբեք չեն վերադասավորվի այս արգելքի միջով, բայց դրա համար ոչ մի հրահանգ չի արտանետվի:
    /// Սա հարմար է նույն թեմայի վրա գործողություններին, որոնք կարող են կանխատեսվել, օրինակ ՝ ազդանշանի կարգաբերողների հետ փոխազդելիս:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::compiler_fence`]-ում [`Ordering::Acquire`]-ն անցնելով որպես `order`:
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Միայն կազմողի հիշողության խոչընդոտ:
    ///
    /// Կազմողի կողմից հիշողությունների մուտքերը երբեք չեն վերադասավորվի այս արգելքի միջով, բայց դրա համար ոչ մի հրահանգ չի արտանետվի:
    /// Սա հարմար է նույն թեմայի վրա գործողություններին, որոնք կարող են կանխատեսվել, օրինակ ՝ ազդանշանի կարգաբերողների հետ փոխազդելիս:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::compiler_fence`]-ում [`Ordering::Release`]-ն անցնելով որպես `order`:
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Միայն կազմողի հիշողության խոչընդոտ:
    ///
    /// Կազմողի կողմից հիշողությունների մուտքերը երբեք չեն վերադասավորվի այս արգելքի միջով, բայց դրա համար ոչ մի հրահանգ չի արտանետվի:
    /// Սա հարմար է նույն թեմայի վրա գործողություններին, որոնք կարող են կանխատեսվել, օրինակ ՝ ազդանշանի կարգաբերողների հետ փոխազդելիս:
    ///
    /// Այս ներքինի կայունացված տարբերակը հասանելի է [`atomic::compiler_fence`]-ում [`Ordering::AcqRel`]-ն անցնելով որպես `order`:
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Կախարդական բնույթ, որն իր իմաստը բխում է գործառույթին կցված հատկություններից:
    ///
    /// Օրինակ, տվյալների հոսքը սա օգտագործում է ստատիկ պնդումներ ներարկելու համար, որպեսզի `rustc_peek(potentially_uninitialized)`-ն իրականում կրկնակի ստուգի, որ տվյալների հոսքն իսկապես հաշվել է, որ վերահսկողության հոսքի այդ կետում այն ոչ նախնականացված է:
    ///
    ///
    /// Այս ներքինը չպետք է օգտագործվի կազմողից դուրս:
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Դադարեցնում է գործընթացի կատարումը:
    ///
    /// Այս գործողության ավելի հարմարավետ և կայուն տարբերակը [`std::process::abort`](../../std/process/fn.abort.html) է:
    ///
    pub fn abort() -> !;

    /// Տեղեկացնում է օպտիմիզատորին, որ ծածկագրի այս կետը հասանելի չէ, ինչը հնարավորություն է տալիս հետագա օպտիմալացումներին:
    ///
    /// NB, սա շատ տարբերվում է `unreachable!()` մակրոից. Ի տարբերություն մակրոի, որը panics-ն է կատարում, դա *չսահմանված վարք է*՝ այս գործառույթով նշված կոդին հասնելու համար:
    ///
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) է:
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Տեղեկացնում է օպտիմիզատորին, որ պայմանը միշտ էլ իրական է:
    /// Եթե պայմանը կեղծ է, ապա վարքն անորոշ է:
    ///
    /// Այս ներքինի համար ոչ մի կոդ չի ստեղծվում, բայց օպտիմիզատորը կփորձի պահպանել այն (և դրա վիճակը) փոխանցումների միջև, ինչը կարող է խանգարել շրջապատող կոդի օպտիմիզացմանը և նվազեցնել կատարումը:
    /// Այն չպետք է օգտագործվի, եթե անփոփոխը կարող է ինքնուրույն հայտնաբերվել օպտիմիզատորի կողմից, կամ եթե այն չի տալիս որևէ նշանակալի օպտիմալացում:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Կոմպիլյատորին ակնարկում է, որ branch պայմանը հավանաբար ճիշտ է:
    /// Վերադարձնում է իրեն փոխանցված արժեքը:
    ///
    /// Useանկացած այլ օգտագործում, քան `if` հայտարարությունները, հավանաբար ազդեցություն չի ունենա:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Կազմողին ակնարկում է, որ branch պայմանը հավանաբար կեղծ է:
    /// Վերադարձնում է իրեն փոխանցված արժեքը:
    ///
    /// Useանկացած այլ օգտագործում, քան `if` հայտարարությունները, հավանաբար ազդեցություն չի ունենա:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Կատարում է խզման կետ ծուղակ, կարգաբերիչի կողմից ստուգելու համար:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn breakpoint();

    /// Տիպի չափը բայթերում:
    ///
    /// Ավելի կոնկրետ, սա բայթերի փոխհատուցում է նույն տիպի հաջորդական իրերի, այդ թվում `հավասարեցման լրացման:
    ///
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::mem::size_of`](crate::mem::size_of) է:
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Տիպի նվազագույն հավասարեցում:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::mem::align_of`](crate::mem::align_of) է:
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Տիպի նախընտրելի հավասարեցում:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Բայտերով հղված արժեքի չափը:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`mem::size_of_val`] է:
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Հղված արժեքի պահանջվող հավասարեցում:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::mem::align_of_val`](crate::mem::align_of_val) է:
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Ստանում է ստատիկ տողի կտոր, որը պարունակում է տիպի անուն:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::any::type_name`](crate::any::type_name) է:
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ստանում է նույնացուցիչ, որը գլոբալ առումով եզակի է նշված տեսակին:
    /// Այս ֆունկցիան կվերադարձնի նույն արժեքը մի տիպի համար `անկախ այն բանից, թե որ crate-ում է այն գործածվում:
    ///
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::any::TypeId::of`](crate::any::TypeId::of) է:
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Անվտանգ գործառույթների պահակ, որը երբեք չի կարող կատարվել, եթե `T`-ը անմարդաբնակ է.
    /// Սա ստատիկորեն կա՛մ panic-ն է, կա՛մ ոչինչ չի ձեռնարկի:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Անվտանգ գործառույթների պահակ, որը երբևէ հնարավոր չէ կատարել, եթե `T` թույլ չի տալիս զրոյական նախնականացում. Սա ստատիկորեն կամ panic է, կամ էլ ոչինչ չի ձեռնարկի:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn assert_zero_valid<T>();

    /// Անվտանգ գործառույթների պահակ, որը երբևէ հնարավոր չէ կատարել, եթե `T`-ն ունի բիթի անվավեր նմուշներ. Սա ստատիկորեն կամ panic է, կամ էլ ոչինչ չի ձեռնարկի:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn assert_uninit_valid<T>();

    /// Հղում է ստանում ստատիկ `Location`-ին `նշելով, թե որտեղ է այն կանչվել:
    ///
    /// Մտածեք դրա փոխարեն [`core::panic::Location::caller`](crate::panic::Location::caller)-ի օգտագործման մասին:
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Առանց կաթիլային սոսինձի մի արժեք տեղափոխում է իր սահմաններից դուրս:
    ///
    /// Սա գոյություն ունի բացառապես [`mem::forget_unsized`]-ի համար.normal `forget` փոխարենը օգտագործում է `ManuallyDrop`:
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Վերաիմաստավորում է մի տեսակի արժեքի բիթերը որպես այլ տեսակի:
    ///
    /// Երկու տեսակներն էլ պետք է ունենան նույն չափը:
    /// Ոչ բնօրինակը, և ոչ էլ արդյունքը չեն կարող լինել [invalid value](../../nomicon/what-unsafe-does.html):
    ///
    /// `transmute` իմաստաբանորեն համարժեք է մի տիպի բիթային տեղափոխմանը մյուսը: Այն կրկնօրինակում է բիթերը աղբյուրի արժեքից նպատակակետի արժեքի մեջ, ապա մոռանում բնօրինակը:
    /// Դա համարժեք է C-ի `memcpy`-ին կապոտի տակ, ճիշտ այնպես, ինչպես `transmute_copy`-ը:
    ///
    /// Քանի որ `transmute`-ը ենթաարժեքային գործողություն է,*փոխակերպված արժեքների հավասարեցումը* մտահոգիչ չէ:
    /// Ինչպես ցանկացած այլ գործառույթի դեպքում, կազմողն արդեն ապահովում է և՛ `T`-ի, և՛ `U`-ի ճիշտ դասավորվածությունը:
    /// Այնուամենայնիվ, երբ * կետերը այլ տեղ են ցույց տալիս արժեքները փոխարկելիս (օրինակ ՝ ցուցիչները, հղումները, տուփերը…), զանգահարողը պետք է ապահովի ցուցված արժեքների պատշաճ հավասարեցում:
    ///
    /// `transmute` **աներեւակայելի** անվտանգ է: Այս գործառույթով [undefined behavior][ub] առաջացնելու հսկայական եղանակներ կան:`transmute`-ը պետք է լինի բացարձակ վերջին միջոցը:
    ///
    /// [nomicon](../../nomicon/transmutes.html)-ն ունի լրացուցիչ փաստաթղթեր:
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Մի քանի բան կա, որի համար `transmute`-ն իսկապես օգտակար է:
    ///
    /// Սլաքը ֆունկցիայի ցուցիչի վերածելը: Սա *շարժական չէ* այն մեքենաների համար, որտեղ ֆունկցիայի ցուցիչները և տվյալների ցուցիչները տարբեր չափսեր ունեն:
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Կյանքի երկարացում կամ անփոփոխ կյանքի տևողություն: Սա առաջադեմ է, շատ անապահով Rust:
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Մի հուսահատվեք. `transmute`-ի շատ օգտագործման կարելի է հասնել այլ միջոցներով:
    /// Ստորև բերված են `transmute`-ի սովորական ծրագրերը, որոնք կարող են փոխարինվել ավելի անվտանգ կառուցվածքներով:
    ///
    /// Հում bytes(`&[u8]`)-ը դարձնելով `u32`, `f64` և այլն:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // փոխարենը օգտագործեք `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // կամ օգտագործեք `u32::from_le_bytes` կամ `u32::from_be_bytes` վերջը որոշելու համար
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Սլաքը `usize`-ի վերածելը.
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Փոխարենը օգտագործեք `as` գիպս
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T`-ը `&mut T`-ի վերածելը.
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Փոխարենը օգտագործեք reborrow
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T`-ը `&mut U`-ի վերածելը.
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Հիմա, միացրեք `as`-ը և rerowrowing-ը, նշեք, որ `as` `as`-ի շղթայակցումը անցողիկ չէ
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str`-ը `&[u8]`-ի վերածելը.
    ///
    /// ```
    /// // դա լավ միջոց չէ դա անելու համար:
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Կարող եք օգտագործել `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Կամ, պարզապես օգտագործեք բայթային տող, եթե տիրույթի նկատմամբ վերահսկողություն ունեք բառացիորեն
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>`-ը `Vec<Option<&T>>`-ի վերածելը:
    ///
    /// Կոնտեյների պարունակության ներքին տեսակը փոխակերպելու համար պետք է համոզվեք, որ չխախտեք տարայի ոչ մի փոփոխություն:
    /// `Vec`-ի համար սա նշանակում է, որ ներքին տեսակների և՛ չափը, և՛ հավասարեցումը * պետք է համընկնեն:
    /// Այլ բեռնարկղերը կարող են ապավինել տեսակի, հավասարեցման կամ նույնիսկ `TypeId`-ի չափին, որի դեպքում փոխակերպումը ընդհանրապես հնարավոր չէր լինի առանց կոնտեյների անփոփոխությունները խախտելու:
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // կլոնավորենք vector-ն, քանի որ դրանք հետագայում կրկին կօգտագործենք
    /// let v_clone = v_orig.clone();
    ///
    /// // Օգտագործելով տրանսմուտ. Սա ապավինում է `Vec`-ի տվյալների չսահմանված դասավորությանը, ինչը վատ գաղափար է և կարող է առաջացնել չսահմանված վարք:
    /////
    /// // Այնուամենայնիվ, այն կրկնօրինակ չէ:
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Սա առաջարկվող, անվտանգ միջոցն է:
    /// // Այն, միևնույն ժամանակ, պատճենում է ամբողջ vector-ը, նոր զանգվածում:
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Սա "transmuting" a `Vec`-ի ոչ պատճենահանման, անվստահելի միջոցն է ՝ առանց հենվելու տվյալների դասավորության վրա:
    /// // Փոխանակ բառացիորեն `transmute` զանգահարելու, մենք կատարում ենք ցուցիչի ձևափոխում, բայց բնօրինակ (`&i32`) ներքին տիպը նորին (`Option<&i32>`) դարձնելու առումով, սա ունի բոլոր նույն նախազգուշացումները:
    /////
    /// // Բացի վերը տրամադրված տեղեկատվությունից, խորհրդակցեք նաև [`from_raw_parts`] փաստաթղթերի հետ:
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Թարմացրեք սա, երբ vec_into_raw_part-ները կայունացվեն:
    ///     // Համոզվեք, որ vector-ի բնօրինակը չի նետվել:
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Իրականացնող `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Դա անելու մի քանի եղանակներ կան, և բազմաթիվ խնդիրներ կան հետևյալ (transmute) եղանակի հետ:
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // առաջին. տրանսմուտը անվտանգ չէ տեսակից.ստուգում է միայն, որ T և
    ///         // U-ն նույն չափի են:
    ///         // Երկրորդ, հենց այստեղ, դուք ունեք երկու փոփոխական հղումներ, որոնք մատնանշում են նույն հիշողությունը:
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Սա ազատվում է տեսակի անվտանգության խնդիրներից.`&mut *`-ը* միայն *ձեզ կտա `&mut T` `&mut T` կամ `* mut T`-ից:
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // այնուամենայնիվ, դուք դեռ ունեք երկու փոփոխական հղումներ, որոնք մատնանշում են նույն հիշողությունը:
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ստանդարտ գրադարանն այսպես է անում:
    /// // Սա լավագույն մեթոդն է, եթե ձեզ հարկավոր է նման բան անել
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Սա այժմ ունի երեք փոփոխական հղումներ, որոնք ուղղված են նույն հիշողությանը: `slice`, R0 արժեք ret.0 և R00 արժեք ret.1:
    ///         // `slice` երբեք չի օգտագործվում `let ptr = ...`-ից հետո, և այդպիսով կարելի է դրան վերաբերվել որպես "dead", և, հետևաբար, դուք ունեք միայն երկու իրական փոփոխվող շերտ:
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Չնայած սա կայուն է դարձնում ներքին կառուցվածքը, բայց fn-ում մենք ունենք որոշ հարմարեցված ծածկագիր
    // ստուգումներ, որոնք կանխում են դրա օգտագործումը `const fn`-ի սահմաններում:
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Վերադարձնում է `true`, եթե `T` անունով տրված իրական տեսակը պահանջում է կաթիլային սոսինձ;վերադարձնում է `false`, եթե `T`-ի համար նախատեսված իրական տեսակը իրականացնում է `Copy`:
    ///
    ///
    /// Եթե իրական տեսակը ո՛չ կաթիլային սոսինձ է պահանջում, ո՛չ էլ իրականացնում է `Copy`, ապա այս գործառույթի վերադարձի արժեքը չի նշվում:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`mem::needs_drop`](crate::mem::needs_drop) է:
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Հաշվարկում է ցուցիչը օֆսեթը:
    ///
    /// Սա իրականացվում է որպես ներքին ՝ ամբողջ թվից չվերափոխվելուց խուսափելու համար, քանի որ փոխարկումը դեն է նետելու մոլորական տեղեկատվություն:
    ///
    /// # Safety
    ///
    /// Ե՛վ մեկնարկային, և՛ ստացված ցուցիչը պետք է լինի սահմանների մեջ կամ մեկ բայթ հատկացված օբյեկտի ավարտից հետո:
    /// Եթե ցուցիչը սահմաններից դուրս է, կամ տեղի է ունենում թվաբանական գերհոսք, ապա վերադարձված արժեքի ցանկացած հետագա օգտագործումը հանգեցնում է չսահմանված վարքի:
    ///
    ///
    /// Այս ներքինի կայունացված տարբերակը [`pointer::offset`] է:
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Հաշվարկում է ցուցիչը օֆսեթը `պոտենցիալ փաթաթելով:
    ///
    /// Սա իրականացվում է որպես ներքին ՝ ամբողջ թվից չվերափոխվելուց խուսափելու համար, քանի որ փոխարկումը խանգարում է որոշակի օպտիմիզացիաներին:
    ///
    /// # Safety
    ///
    /// Ի տարբերություն `offset` ներքինի, այս ներքինը չի սահմանափակում, որ ստացված ցուցիչը հատկացնի հատկացված օբյեկտի վերջը կամ մեկ բայթ, և այն փաթաթվում է երկուսի լրացման թվաբանության հետ:
    /// Արդյունքում ստացված արժեքը պարտադիր չէ, որ օգտագործվի հիշողություն իրականում մուտք գործելու համար:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`pointer::wrapping_offset`] է:
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Համարժեք է համապատասխան `llvm.memcpy.p0i8.0i8.*` ներքինին, `count`*`size_of::<T>()` չափսով և հավասարեցմամբ
    ///
    /// `min_align_of::<T>()`
    ///
    /// Անկայուն պարամետրը դրված է `true`, այնպես որ այն չի օպտիմիզացվի, քանի դեռ չափը հավասար չէ զրոյի:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Համարժեք է համապատասխան `llvm.memmove.p0i8.0i8.*` ներքինին, `count* size_of::<T>()` չափսով և հավասարեցմամբ
    ///
    /// `min_align_of::<T>()`
    ///
    /// Անկայուն պարամետրը դրված է `true`, այնպես որ այն չի օպտիմիզացվի, քանի դեռ չափը հավասար չէ զրոյի:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Համարժեք է համապատասխան `llvm.memset.p0i8.*` ներքինի, `count* size_of::<T>()` չափսով և `min_align_of::<T>()` հավասարեցմամբ:
    ///
    ///
    /// Անկայուն պարամետրը դրված է `true`, այնպես որ այն չի օպտիմիզացվի, քանի դեռ չափը հավասար չէ զրոյի:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` ցուցիչից կատարում է ցնդող բեռ:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::ptr::read_volatile`](crate::ptr::read_volatile) է:
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Անկայուն պահում է `dst` ցուցիչը:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::ptr::write_volatile`](crate::ptr::write_volatile) է:
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` ցուցիչից կատարում է ցնդող բեռ: interուցիչը հավասարեցված չէ:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Անկայուն պահում է `dst` ցուցիչը:
    /// Սլաքը չի պահանջվում հավասարեցնել:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Վերադարձնում է `f32` քառակուսի արմատը
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Վերադարձնում է `f64` քառակուսի արմատը
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32`-ը բարձրացնում է ամբողջ ուժի:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64`-ը բարձրացնում է ամբողջ ուժի:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Վերադարձնում է `f32`-ի սինուսը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի սինուսը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Վերադարձնում է `f32`-ի կոսինուսը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի կոսինուսը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32`-ը բարձրացնում է `f32` հզորության:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64`-ը բարձրացնում է `f64` հզորության:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Վերադարձնում է `f32`-ի ցուցիչը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի ցուցիչը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Վերադառնում է 2-ը, որը բարձրացվել է `f32`-ի հզորության վրա:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Վերադառնում է 2-ը, որը բարձրացվել է `f64`-ի հզորության վրա:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Վերադարձնում է `f32`-ի բնական լոգարիթմը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի բնական լոգարիթմը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Վերադարձնում է `f32`-ի բազային 10 լոգարիթմը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի բազային 10 լոգարիթմը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Վերադարձնում է `f32`-ի հիմքի 2 լոգարիթմը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի հիմքի 2 լոգարիթմը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Վերադարձնում է `a * b + c` `f32` արժեքների համար:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Վերադարձնում է `a * b + c` `f64` արժեքների համար:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Վերադարձնում է `f32`-ի բացարձակ արժեքը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի բացարձակ արժեքը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Վերադարձնում է `f32` երկու նվազագույն արժեք:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Վերադարձնում է `f64` երկու նվազագույն արժեք:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Վերադարձնում է առավելագույնը երկու `f32` արժեք:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Վերադարձնում է առավելագույնը երկու `f64` արժեք:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `y`-ից `x` նշանը պատճենում է `f32` արժեքների համար:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `y`-ից `x` նշանը պատճենում է `f64` արժեքների համար:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Վերադարձնում է ամենամեծ ամբողջ թվին `f32`-ից պակաս կամ հավասար:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Վերադարձնում է ամենամեծ ամբողջ թվին `f64`-ից պակաս կամ հավասար:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Վերադարձնում է `f32`-ից մեծ կամ հավասար փոքրագույն ամբողջ թիվ:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ից մեծ կամ հավասար փոքրագույն ամբողջ թիվ:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Վերադարձնում է `f32`-ի ամբողջ մասը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Վերադարձնում է `f64`-ի ամբողջ մասը:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Վերադարձնում է մոտակա ամբողջ թվին `f32`:
    /// Կարող է անճիշտ լողացող կետից բացառություն առաջացնել, եթե փաստարկը ամբողջ թիվ չէ:
    pub fn rintf32(x: f32) -> f32;
    /// Վերադարձնում է մոտակա ամբողջ թվին `f64`:
    /// Կարող է անճիշտ լողացող կետից բացառություն առաջացնել, եթե փաստարկը ամբողջ թիվ չէ:
    pub fn rintf64(x: f64) -> f64;

    /// Վերադարձնում է մոտակա ամբողջ թվին `f32`:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn nearbyintf32(x: f32) -> f32;
    /// Վերադարձնում է մոտակա ամբողջ թվին `f64`:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn nearbyintf64(x: f64) -> f64;

    /// Վերադարձնում է մոտակա ամբողջ թվին `f32`: Կլորացնում է դեպքերի կես ճանապարհը զրոյից հեռու:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Վերադարձնում է մոտակա ամբողջ թվին `f64`: Կլորացնում է դեպքերի կես ճանապարհը զրոյից հեռու:
    ///
    /// Այս ներքինի կայունացված տարբերակը
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Բոց հավելում, որը թույլ է տալիս հանրահաշվական կանոնների վրա հիմնված օպտիմալացումներ:
    /// Կարող է ենթադրել, որ մուտքերը վերջավոր են:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Բոց հանում, որը թույլ է տալիս հանրահաշվական կանոնների վրա հիմնված օպտիմալացումներ:
    /// Կարող է ենթադրել, որ մուտքերը վերջավոր են:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Բոց բազմապատկում, որը թույլ է տալիս հանրահաշվական կանոնների վրա հիմնված օպտիմալացումներ:
    /// Կարող է ենթադրել, որ մուտքերը վերջավոր են:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Բոց բաժանում, որը թույլ է տալիս հանրահաշվական կանոնների վրա հիմնված օպտիմալացումներ:
    /// Կարող է ենթադրել, որ մուտքերը վերջավոր են:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Բոց մնացորդ, որը թույլ է տալիս հանրահաշվական կանոնների հիման վրա օպտիմալացումներ:
    /// Կարող է ենթադրել, որ մուտքերը վերջավոր են:
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Փոխարկեք LLVM-ի fptoui/fptosi-ի հետ, որը կարող է անվերադարձ վերադարձնել տիրույթից դուրս գտնվող արժեքների համար
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Կայունացել է որպես [`f32::to_int_unchecked`] և [`f64::to_int_unchecked`]:
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Վերադարձնում է `T` ամբողջ տիպում տեղադրված բիթերի քանակը
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `count_ones` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Վերադարձնում է (zeroes) առաջատար չսահմանված բիթերի քանակը `T` ամբողջ տեսակի մեջ:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `leading_zeros` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` արժեքով `x` կվերադարձնի `T` բիթի լայնությունը:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz`-ի նման, բայց ևս ոչ անվտանգ, քանի որ այն վերադարձնում է `undef`, երբ տալիս է `x` `0` արժեքով:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Վերադարձնում է հետևյալ չսահմանված բիտերի քանակը (zeroes) ամբողջ `T` տեսակի մեջ:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `trailing_zeros` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` արժեքով `x` կվերադարձնի `T` բիթի լայնությունը.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz`-ի նման, բայց ևս ոչ անվտանգ, քանի որ այն վերադարձնում է `undef`, երբ տալիս է `x` `0` արժեքով:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Հակադարձում է բայթերը `T` ամբողջ տեսակի մեջ:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `swap_bytes` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Հակադարձում է բիտերը `T` ամբողջ տեսակի մեջ:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `reverse_bits` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Կատարում է ստուգված ամբողջ լրացում:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `overflowing_add` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Կատարում է ստուգված ամբողջ հանում
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `overflowing_sub` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Կատարում է ստուգված ամբողջ բազմապատկում
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `overflowing_mul` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Կատարում է ճշգրիտ բաժանում `հանգեցնելով չսահմանված վարքի, երբ `x % y != 0` կամ `y == 0` կամ `x == T::MIN && y == -1`
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Կատարում է չստուգված բաժանում, որի արդյունքում առաջանում է չսահմանված պահվածք, երբ `y == 0` կամ `x == T::MIN && y == -1`
    ///
    ///
    /// Այս ներքինի համար անվտանգ փաթաթաները հասանելի են ամբողջ պրիմիտիվների վրա `checked_div` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Վերադարձնում է չստուգված բաժանման մնացորդը, որի արդյունքում առաջանում է չսահմանված վարք, երբ `y == 0` կամ `x == T::MIN && y == -1`
    ///
    ///
    /// Այս ներքինի անվտանգ փաթաթաները հասանելի են ամբողջ պրիմիտիվների վրա `checked_rem` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Կատարում է չստուգված ձախ հերթափոխ, ինչը հանգեցնում է չսահմանված վարքի, երբ `y < 0` կամ `y >= N`, որտեղ N-ը T-ի լայնությունն է բիթերով:
    ///
    ///
    /// Այս ներքինի անվտանգ փաթաթաները հասանելի են ամբողջ պրիմիտիվների վրա `checked_shl` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Կատարում է չստուգված աջ հերթափոխ, ինչը հանգեցնում է չսահմանված վարքի, երբ `y < 0` կամ `y >= N`, որտեղ N-ը T-ի լայնությունն է բիթերով:
    ///
    ///
    /// Այս ներքինի անվտանգ փաթաթաները հասանելի են ամբողջ պրիմիտիվների վրա `checked_shr` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Վերադարձնում է չստուգված լրացման արդյունքը `հանգեցնելով չսահմանված վարքի, երբ `x + y > T::MAX` կամ `x + y < T::MIN`:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Վերադարձնում է չստուգված հանման արդյունքը `հանգեցնելով չսահմանված վարքի, երբ `x - y > T::MAX` կամ `x - y < T::MIN`:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Վերադարձնում է չստուգված բազմապատկման արդյունքը `հանգեցնելով չսահմանված վարքի, երբ `x *y > T::MAX` կամ `x* y < T::MIN`:
    ///
    ///
    /// Այս ներքինը չունի կայուն նմանակ:
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Կատարում է պտտվել ձախ:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `rotate_left` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Կատարում է պտտվող աջ:
    ///
    /// Այս ներքին կայունացված տարբերակները հասանելի են ամբողջ պրիմիտիվների վրա `rotate_right` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Վերադարձնում է (a + b) mod 2 <sup>N</sup>, որտեղ N-ը T-ի լայնությունն է բիտերում:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `wrapping_add` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Վերադարձնում է (a, b) mod 2 <sup>N</sup>, որտեղ N-ը T-ի լայնությունն է բիտերում:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `wrapping_sub` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Վերադարձնում է (a * b) mod 2 <sup>N</sup>, որտեղ N-ը T-ի լայնությունն է բիտերում:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `wrapping_mul` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Հաշվարկում է `a + b` ՝ հագեցած թվային սահմաններով:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `saturating_add` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Հաշվարկում է `a - b` ՝ հագեցած թվային սահմաններով:
    ///
    /// Այս ներքին կայունացված տարբերակները ամբողջ պրիմիտիվների վրա հասանելի են `saturating_sub` մեթոդի միջոցով:
    /// Օրինակ,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Վերադարձնում է տարբերակի համար տարբերակողի արժեքը 'v'-ում;
    /// եթե `T`-ը խտրական չունի, վերադարձնում է `0`:
    ///
    /// Այս ներքինի կայունացված տարբերակը [`core::mem::discriminant`](crate::mem::discriminant) է:
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Վերադարձնում է `T` տիպի գցված տիպի տարբերակների քանակը `usize`;
    /// եթե `T`-ը տարբերակներ չունի, վերադարձնում է `0`: Հաշվելու են անմարդաբնակ տարբերակները:
    ///
    /// Այս ներքինի կայունացվող տարբերակը [`mem::variant_count`] է:
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust-ի "try catch" կոնստրուկցիան, որը վկայակոչում է `try_fn` ֆունկցիայի ցուցիչը `data` տվյալների ցուցիչով:
    ///
    /// Երրորդ փաստարկը գործառույթ է, որը կոչվում է, եթե տեղի է ունենում panic:
    /// Այս գործառույթը տվյալների ցուցիչը և ցուցիչը տանում է դեպի թիրախին հատուկ բացառության օբյեկտ, որը որսացել է:
    ///
    /// Լրացուցիչ տեղեկությունների համար տեսեք կազմողի աղբյուրը, ինչպես նաև std-ի բռնումների իրականացումը:
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Ըստ LLVM-ի թողարկում է `!nontemporal` խանութ (տես դրանց փաստաթղթերը):
    /// Հավանաբար, երբեք կայուն չի դառնա:
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Մանրամասների համար տե՛ս `<*const T>::offset_from`-ի փաստաթղթերը:
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Մանրամասների համար տե՛ս `<*const T>::guaranteed_eq`-ի փաստաթղթերը:
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Մանրամասների համար տե՛ս `<*const T>::guaranteed_ne`-ի փաստաթղթերը:
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Հատկացրեք կազմման ժամանակ: Չի կարելի զանգել գործարկման ժամանակ:
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Որոշ գործառույթներ սահմանվում են այստեղ, քանի որ դրանք պատահաբար հասանելի են դարձել այս մոդուլում կայունի վրա:
// Տե՛ս <https://github.com/rust-lang/rust/issues/15702>:
// (`transmute`-ը նույնպես ընկնում է այս կատեգորիայի մեջ, բայց այն հնարավոր չէ փաթաթել `T`-ի և `U`-ի նույն չափի ստուգման պատճառով):
//

/// Ստուգում է `արդյոք `ptr`-ը `align_of::<T>()`-ի նկատմամբ ճիշտ է հավասարեցված:
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Պատկերացնում է `count *size_of::<T>()` բայթ `src`-ից `dst`: Աղբյուրը և նպատակակետը չպետք է* համընկնեն:
///
/// Հիշողության շրջանների համար, որոնք կարող են համընկնել, փոխարենը օգտագործել [`copy`]:
///
/// `copy_nonoverlapping` իմաստաբանորեն համարժեք է C-ի [`memcpy`]-ին, բայց փաստարկի կարգը փոխված է:
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Վարքը չի որոշվում, եթե հետևյալ պայմաններից որևէ մեկը խախտվում է.
///
/// * `src` պետք է լինի [valid] `count * size_of::<T>()` բայթ կարդալու համար:
///
/// * `dst` պետք է լինի [valid] ՝ `count * size_of::<T>()` բայթ գրելու համար:
///
/// * Եվ `src`-ը, և `dst`-ը պետք է համապատասխանեցված լինեն:
///
/// * Հիշողության շրջանը, որը սկսվում է `src`-ից `« հաշվարկի »չափով *
///   չափը: :<T>() «բայթերը *չպետք է* համընկնեն նույն տարածաշրջանի `dst`-ից սկիզբ առած հիշողության տարածաշրջանի հետ:
///
/// [`read`]-ի նման, `copy_nonoverlapping`-ն էլ ստեղծում է `T`-ի բիթային կրկնօրինակը `անկախ այն բանից` `T`-ը [`Copy`] է:
/// Եթե `T`-ը [`Copy`] չէ, օգտագործելով *և* արժեքները տարածաշրջանում, որոնք սկսվում են `*src`-ից և տարածաշրջանը, որը սկսվում է `* src`-ից, կարող է [violate memory safety][read-ownership]:
///
///
/// Նկատի ունեցեք, որ նույնիսկ եթե արդյունավետորեն կրկնօրինակված չափը («հաշվել * չափը_:::<T>() `) `0` է, ցուցիչները պետք է լինեն ոչ NULL և պատշաճ կերպով հավասարեցված:
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ձեռքով իրականացնել [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// `src`- ի բոլոր տարրերը տեղափոխում է `dst` ՝ թողնելով `src` դատարկ:
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Համոզվեք, որ `dst`-ն ունի բավարար հզորություն `ամբողջ `src`-ը պահելու համար:
///     dst.reserve(src_len);
///
///     unsafe {
///         // Օֆսեթ կատարելու կոչը միշտ անվտանգ է, քանի որ `Vec`-ը երբեք չի հատկացնի `isize::MAX` բայթից ավելին:
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Կտրեք `src`-ը ՝ առանց դրա բովանդակությունը գցելու:
///         // Մենք դա անում ենք նախ, որպեսզի խուսափենք խնդիրներից, եթե panics-ից ավելի ցածր բան լինի:
///         src.set_len(0);
///
///         // Երկու տարածաշրջանները չեն կարող համընկնել, քանի որ փոփոխվող հղումները չեն հանդիսանում կեղծանուն, և երկու տարբեր vectors չեն կարող ունենալ նույն հիշողությունը:
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Տեղեկացրեք `dst`-ին, որ այն այժմ պահում է `src`-ի պարունակությունը:
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Այս ստուգումները կատարեք միայն վազքի ժամանակ
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Խուճապի չմատնվելով, որպեսզի կոդեգենի ազդեցությունը փոքր լինի:
        abort();
    }*/

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `copy_nonoverlapping`-ի անվտանգության պայմանագիրը պետք է լինի
    // զանգահարողի կողմից պաշտպանված:
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Պատկերացնում է `count * size_of::<T>()` բայթ `src`-ից `dst`: Սկզբնաղբյուրը և նպատակակետը կարող են համընկնել:
///
/// Եթե աղբյուրը և նպատակակետը *երբեք* չեն համընկնում, փոխարենը կարող է օգտագործվել [`copy_nonoverlapping`]:
///
/// `copy` իմաստաբանորեն համարժեք է C-ի [`memmove`]-ին, բայց փաստարկի կարգը փոխված է:
/// Պատճենումն ընթանում է այնպես, կարծես բայթերը պատճենվել են `src`-ից ժամանակավոր զանգված և այնուհետև պատճենվել զանգվածից `dst`:
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Վարքը չի որոշվում, եթե հետևյալ պայմաններից որևէ մեկը խախտվում է.
///
/// * `src` պետք է լինի [valid] `count * size_of::<T>()` բայթ կարդալու համար:
///
/// * `dst` պետք է լինի [valid] ՝ `count * size_of::<T>()` բայթ գրելու համար:
///
/// * Եվ `src`-ը, և `dst`-ը պետք է համապատասխանեցված լինեն:
///
/// [`read`]-ի նման, `copy`-ն էլ ստեղծում է `T`-ի բիթային կրկնօրինակը `անկախ այն բանից` `T`-ը [`Copy`] է:
/// Եթե `T`-ը [`Copy`] չէ, օգտագործելով ինչպես արժեքները տարածաշրջանում, որոնք սկսվում են `*src`-ից, այնպես էլ տարածաշրջանը, որը սկսվում է `* dst`-ից, կարող է [violate memory safety][read-ownership]:
///
///
/// Նկատի ունեցեք, որ նույնիսկ եթե արդյունավետորեն կրկնօրինակված չափը («հաշվել * չափը_:::<T>() `) `0` է, ցուցիչները պետք է լինեն ոչ NULL և պատշաճ կերպով հավասարեցված:
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Արդյունավետորեն ստեղծեք Rust vector ոչ անվտանգ բուֆերից.
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` պետք է ճիշտ հավասարեցված լինի իր տեսակի համար և ոչ զրոյական:
/// /// * `ptr` պետք է վավեր լինի `T` տիպի `elts` հարակից տարրերի ընթերցման համար:
/// /// * Այս տարրերը չպետք է օգտագործվեն այս գործառույթը կանչելուց հետո, բացառությամբ `T: Copy`:
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մեր նախապայմանն ապահովում է աղբյուրի հավասարեցումը և վավերությունը,
///     // և `Vec::with_capacity`-ն ապահովում է, որ մենք ունենք օգտագործելի տարածք դրանք գրելու համար:
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք այդքան մեծ կարողությամբ այն ստեղծեցինք ավելի վաղ,
///     // և նախորդ `copy`- ը սկզբնավորել է այս տարրերը:
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Այս ստուգումները կատարեք միայն վազքի ժամանակ
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Խուճապի չմատնվելով, որպեսզի կոդեգենի ազդեցությունը փոքր լինի:
        abort();
    }*/

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `copy`-ի անվտանգության պայմանագիրը պետք է պահպանի զանգահարողը:
    unsafe { copy(src, dst, count) }
}

/// Սահմանում է `count * size_of::<T>()` բայթ հիշողություն `սկսած `dst`-ից `val`:
///
/// `write_bytes` նման է C-ի [`memset`]-ին, բայց `count * size_of::<T>()` բայթը սահմանում է `val`:
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Վարքը չի որոշվում, եթե հետևյալ պայմաններից որևէ մեկը խախտվում է.
///
/// * `dst` պետք է լինի [valid] ՝ `count * size_of::<T>()` բայթ գրելու համար:
///
/// * `dst` պետք է պատշաճ կերպով հավասարեցված լինի:
///
/// Բացի այդ, զանգահարողը պետք է ապահովի, որ `count * size_of::<T>()` բայթ գրառումը հիշողության տվյալ հատվածում հանգեցնի `T`-ի վավեր արժեքի:
/// Որպես `T` մուտքագրված հիշողության տարածաշրջանի օգտագործումը, որը պարունակում է `T` անվավեր արժեք, չսահմանված վարք է:
///
/// Նկատի ունեցեք, որ նույնիսկ եթե արդյունավետորեն կրկնօրինակված չափը («հաշվել * չափը_:::<T>() `) `0` է, ցուցիչը պետք է լինի ոչ NULL և պատշաճ կերպով հավասարեցված:
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ստեղծելով անվավեր արժեք ՝
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Արտահոսում է նախկինում պահված արժեքը ՝ `Box<T>`-ը վերացնելով զրոյական ցուցիչով:
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Այս պահին `v`-ի օգտագործումը կամ թողնելը հանգեցնում է չսահմանված վարքի:
/// // drop(v); // ERROR
///
/// // Նույնիսկ `v` "uses"-ի արտահոսքը, և հետևաբար ՝ չսահմանված վարք:
/// // mem::forget(v); // ERROR
///
/// // Փաստորեն, `v`-ը անվավեր է ըստ հիմնական տիպի դասավորության անփոփոխների, այնպես որ դրան առնչվող *ցանկացած* գործողություն անորոշ վարք է:
/////
/// // թող v2 =v;//ՍԽԱԼ
///
/// unsafe {
///     // Փոխարենը եկեք դնենք վավեր արժեք
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Այժմ տուփը լավ է
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `write_bytes`-ի անվտանգության պայմանագիրը պետք է պահպանի զանգահարողը:
    unsafe { write_bytes(dst, val, count) }
}