//! Yույլ արժեքներ և ստատիկ տվյալների միանվագ նախնականացում:

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Բջիջ, որը կարող է գրվել միայն մեկ անգամ:
///
/// Ի տարբերություն `RefCell`-ի, `OnceCell`-ը տրամադրում է միայն `&T` ընդհանուր հղումներ իր արժեքի վերաբերյալ:
/// Ի տարբերություն `Cell`-ի, `OnceCell`-ը դրան մուտք գործելու համար չի պահանջում պատճենել կամ փոխարինել արժեքը:
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Անփոփոխ. Գրված է առավելագույնը մեկ անգամ:
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Ստեղծում է նոր դատարկ բջիջ:
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Ստանում է հղում հիմքում ընկած արժեքին:
    ///
    /// Վերադարձնում է `None`, եթե բջիջը դատարկ է:
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ապահով ՝ «ներքինի» անփոփոխության պատճառով
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Ստանում է փոփոխական հղում հիմքում ընկած արժեքին:
    ///
    /// Վերադարձնում է `None`, եթե բջիջը դատարկ է:
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ապահով, քանի որ մենք ունենք բացառիկ հնարավորություն
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Բջջի պարունակությունը սահմանում է `value`:
    ///
    /// # Errors
    ///
    /// Այս մեթոդը վերադարձնում է `Ok(())`, եթե բջիջը դատարկ էր, և `Err(value)`, եթե այն լի էր:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ապահով, քանի որ մենք չենք կարող համընկնելի փոխադարձ փոխառություններ ունենալ
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա միակ տեղն է, որտեղ մենք սահմանում ենք բնիկը, առանց մրցավազքի
        // reentrancy/concurrency-ի շնորհիվ հնարավոր է, և մենք ստուգեցինք, որ ներկայումս բնիկը `None` է, այնպես որ այս գրառումը պահպանում է «ներքինի» անփոփոխությունը:
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Ստանում է բջիջի պարունակությունը, նախնական նախանշելով այն `f`-ով, եթե բջիջը դատարկ է:
    ///
    /// # Panics
    ///
    /// Եթե `f` panics, panic-ը տարածվում է զանգահարողի մոտ, և բջիջը մնում է uninitialized:
    ///
    ///
    /// `f`-ից բջիջը նորից նախաստորագրելու սխալ է: Դա անելը հանգեցնում է panic-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Ստանում է բջիջի պարունակությունը, նախնական նախանշելով այն `f`-ով, եթե բջիջը դատարկ է:
    /// Եթե բջիջը դատարկ էր, և `f`-ը ձախողվեց, սխալը վերադարձվում է:
    ///
    /// # Panics
    ///
    /// Եթե `f` panics, panic-ը տարածվում է զանգահարողի մոտ, և բջիջը մնում է uninitialized:
    ///
    ///
    /// `f`-ից բջիջը նորից նախաստորագրելու սխալ է: Դա անելը հանգեցնում է panic-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Նկատի ունեցեք, որ վերահաշվարկի սկզբնավորման *որոշ* ձևեր կարող են հանգեցնել UB (տե՛ս `reentrant_init` թեստ):
        // Կարծում եմ, որ պարզապես այս `assert`-ի հեռացումը, մինչդեռ `set/get`-ը պահելը հիմնավոր կլիներ, բայց panic-ին դա ավելի լավ է թվում, քան հին արժեքը լուռ օգտագործելու համար:
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Սպառում է բջիջը ՝ վերադարձնելով փաթաթված արժեքը:
    ///
    /// Վերադարձնում է `None`, եթե բջիջը դատարկ էր:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Քանի որ `into_inner`-ն ըստ արժեքի վերցնում է `self`-ը, կազմողը ստատիկորեն ստուգում է, որ այն ներկայումս փոխառված չէ:
        // Այսպիսով, անվտանգ է տեղափոխել `Option<T>`:
        self.inner.into_inner()
    }

    /// Վերցնում է արժեքը այս `OnceCell`-ից ՝ այն հետ տեղափոխելով ոչ սկզբնական վիճակ:
    ///
    /// Արդյունք չունի և վերադարձնում է `None`, եթե `OnceCell`-ը նախնականացված չէ:
    ///
    /// Անվտանգությունը երաշխավորվում է փոփոխական տեղեկանք պահանջելով:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Արժեք, որը սկզբնավորվում է առաջին մուտքի վրա:
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   պատրաստի նախաստորագրում
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Տրված նախնական գործառույթով ստեղծում է նոր ծույլ արժեք:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Ստիպում է գնահատել այս ծույլ արժեքը և վերադարձնում արդյունքը:
    ///
    ///
    /// Սա համարժեք է `Deref` ազդանշանին, բայց հստակ է:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Ստեղծում է նոր ծույլ արժեք `օգտագործելով `Default`-ը որպես նախնական գործառույթ:
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}