use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// Մի կրկնիչ, որը միաժամանակ կրկնում է ևս երկու կրկնվող:
///
/// Այս `struct`-ը ստեղծվել է [`Iterator::zip`]-ի կողմից:
/// Տեսեք դրա փաստաթղթերը ավելին:
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // index, len և a_len օգտագործվում են միայն zip-ի մասնագիտացված տարբերակի կողմից
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `ZipImpl::__iterator_get_unchecked`-ն ունի նույն անվտանգությունը
        // պահանջները, ինչպես `Iterator::__iterator_get_unchecked`:
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// Zip մասնագիտացում trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // Սա ունի անվտանգության նույն պահանջները, ինչ `Iterator::__iterator_get_unchecked`-ը
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// Ընդհանուր Zip իմպլ
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b հավասարեցրեք հավասար երկարությանը
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `i`-ը `self.len`-ից փոքր է, ուստի `self.a.len()`-ից և `self.b.len()`-ից փոքր է
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // համապատասխանում են բազային իրականացման հավանական կողմնակի ազդեցություններին ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. մենք պարզապես ստուգեցինք, որ `i` <`self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `cmp::min`-ի օգտագործումը `delta`-ը հաշվարկելու համար
                // ապահովում է, որ `end`-ը `self.len`-ից փոքր է կամ հավասար է դրան, ուստի `i`-ը նաև `self.len`-ից փոքր է:
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նույնն է, ինչ վերևում:
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b հավասարեցրեք հավասար երկարությանը, համոզվեք, որ դա անում է միայն `next_back`-ի առաջին զանգը, հակառակ դեպքում `get_unchecked()` զանգահարելուց հետո մենք կկոտրենք `self.next_back()` զանգերի սահմանափակումները:
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `i`-ն ավելի փոքր է, քան `self.len`-ի նախորդ արժեքը,
            // որը նույնպես փոքր է կամ հավասար է `self.a.len()`-ին և `self.b.len()`-ին
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի պայմանագիրը `Iterator::__iterator_get_unchecked`-ի համար:
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// Կամայականորեն ընտրում է zip կրկնության ձախ կողմը որպես արդյունահանվող "source": դրա համար կպահանջվի բացասական trait bounds, որպեսզի երկուսն էլ փորձեն:
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Անապահով գործառույթի նույն պահանջներով փոխանցում դեպի անապահով գործառույթ
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// Սահմանափակվել է նյութով. Պատճենել, քանի որ անհասկանալի է Zip-ի TrustedRandomAccess-ի օգտագործման և Drop-ի իրականացման փոխգործակցության միջև:
//
// Սկզբնաղբյուրը տրամաբանորեն առաջ բերված քանի անգամների վերադարձման լրացուցիչ մեթոդ (առանց next()) զանգահարելու անհրաժեշտ կլինի աղբյուրի մնացած մասը պատշաճ կերպով գցելու համար:
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Անվտանգ *չէ* զանգահարել fmt պարունակվող կրկնիչների, քանի որ երբ մենք սկսում ենք կրկնել, դրանք տարօրինակ, պոտենցիալ անվստահ վիճակներում են:
        //
        f.debug_struct("Zip").finish()
    }
}

/// Կրկնիչ, որի իրերը արդյունավետորեն մատչելի են պատահականորեն
///
/// # Safety
///
/// Կատարողի `size_hint`-ը զանգահարելու համար պետք է լինի ճշգրիտ և էժան:
///
/// `size` կարող է չփոխանցվել:
///
/// `<Self as Iterator>::__iterator_get_unchecked` հետևյալ պայմանները բավարարելու դեպքում պետք է ապահով լինի զանգահարել:
///
/// 1. `0 <= idx` և `idx < self.size()`:
/// 2. Եթե `self: !Clone`, ապա `get_unchecked` երբեք չի զանգվում նույն ցուցանիշով `self`-ի վրա մեկից ավելի անգամ:
/// 3. `self.get_unchecked(idx)` կոչվելուց հետո `next_back` կկանչվի առավելագույնը `self.size() - idx - 1` անգամ:
/// 4. `get_unchecked` կանչելուց հետո `self`-ի վրա կանչվելու են միայն հետևյալ մեթոդները.
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// Բացի այդ, հաշվի առնելով, որ այդ պայմանները բավարարված են, այն պետք է երաշխավորի, որ.
///
/// * Այն չի փոխում `size_hint`-ից վերադարձված արժեքը
/// * `get_unchecked` զանգահարելուց հետո պետք է ապահով լինի զանգահարել վերոհիշյալ մեթոդները `self`, ենթադրելով, որ պահանջվող traits-ն իրականացված է:
///
/// * X001 զանգահարելուց հետո պետք է ապահով լինի նաև `self` թողնելը:
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // Հարմարավետության մեթոդը:
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` եթե կրկնիչի տարր ստանալը կարող է կողմնակի բարդություններ ունենալ:
    /// Մի մոռացեք հաշվի առնել ներքին կրկնիչները:
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked`-ի նման, բայց չի պահանջում, որ կազմողը իմանա այդ `U: TrustedRandomAccess`-ը:
///
///
/// ## Safety
///
/// Նույն պահանջները, որոնք ուղղակիորեն զանգահարում են `get_unchecked`:
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի պայմանագիրը `Iterator::__iterator_get_unchecked`-ի համար:
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// Եթե `Self: TrustedRandomAccess` է, `Iterator::__iterator_get_unchecked(self, index)` զանգահարելը պետք է ապահով լինի:
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի պայմանագիրը `Iterator::__iterator_get_unchecked`-ի համար:
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}