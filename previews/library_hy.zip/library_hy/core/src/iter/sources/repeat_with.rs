use crate::iter::{FusedIterator, TrustedLen};

/// Ստեղծում է նոր կրկնիչ, որն անվերջ կրկնում է `A` տիպի տարրերը ՝ կիրառելով տրամադրված փակումը, կրկնողը, `F: FnMut() -> A`.
///
/// `repeat_with()` գործառույթը կրկին ու կրկին զանգում է կրկնողին:
///
/// `repeat_with()`-ի նման անսահման կրկնիչները հաճախ օգտագործվում են [`Iterator::take()`]-ի նման ադապտերների հետ `դրանք վերջնական դարձնելու համար:
///
/// Եթե ձեզ անհրաժեշտ կրկնիչի տարրի տեսակը իրականացնում է [`Clone`], և աղբյուրի տարրը հիշողության մեջ պահելը նորմալ է, փոխարենը պետք է օգտագործեք [`repeat()`] գործառույթը:
///
///
/// `repeat_with()`-ի արտադրած կրկնիչը [`DoubleEndedIterator`] չէ:
/// Եթե X001-ը վերադարձնելու համար `repeat_with()`-ի կարիք ունեք, խնդրում ենք բացել GitHub-ի թողարկում `բացատրելով ձեր օգտագործման դեպքը:
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::iter;
///
/// // ենթադրենք, որ մենք ունենք մի տիպի որոշակի արժեք, որը `Clone` չէ կամ որը դեռ չի ցանկանում հիշողության մեջ ունենալ, քանի որ այն թանկ է.
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // որոշակի արժեք ընդմիշտ.
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Օգտագործելով մուտացիա և վերջավոր գնալով.
///
/// ```rust
/// use std::iter;
///
/// // Theրոտից երկուսի երրորդ ուժը.
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... և հիմա մենք ավարտեցինք
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Կրկնիչ, որն անվերջ կրկնում է `A` տիպի տարրերը `կիրառելով տրամադրված `F: FnMut() -> A` փակումը:
///
///
/// Այս `struct`-ը ստեղծվում է [`repeat_with()`] գործառույթի կողմից:
/// Տեսեք դրա փաստաթղթերը ավելին:
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}