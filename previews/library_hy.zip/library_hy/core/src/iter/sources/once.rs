use crate::iter::{FusedIterator, TrustedLen};

/// Ստեղծում է կրկնիչ, որը տարր է տալիս միանգամից մեկ անգամ:
///
/// Սա սովորաբար օգտագործվում է մեկ արժեքը [`chain()`] այլ տիպի կրկնության փոխակերպելու համար:
/// Գուցե դուք ունեք կրկնիչ, որը ծածկում է գրեթե ամեն ինչ, բայց ձեզ հարկավոր է լրացուցիչ հատուկ պատյան:
/// Գուցե դուք ունեք գործառույթ, որն աշխատում է կրկնիչների վրա, բայց անհրաժեշտ է մշակել միայն մեկ արժեք:
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::iter;
///
/// // մեկը ամենաերկար թիվն է
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ընդամենը մեկը, դա այն է, ինչ մենք ստանում ենք
/// assert_eq!(None, one.next());
/// ```
///
/// Մեկ այլ կրկնիչի հետ միասին շղթայակցում:
/// Ասենք, որ մենք ուզում ենք կրկնել `.foo` գրացուցակի յուրաքանչյուր ֆայլ, բայց նաև կազմաձևման ֆայլ,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // մենք պետք է DirEntry-ի կրկնիչից վերափոխենք PathBufs-ի կրկնիչի, այնպես որ մենք օգտագործում ենք քարտեզ
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // հիմա, մեր կրկնիչը հենց մեր կազմաձևող ֆայլի համար
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // շղթայեք երկու կրկնիչները միասին մեկ մեծ կրկնիչի
/// let files = dirs.chain(config);
///
/// // սա մեզ կտա .foo-ի, ինչպես նաև .foorc-ի բոլոր ֆայլերը
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Իտերատոր, որը տարր է տալիս միանգամից մեկ անգամ:
///
/// Այս `struct`-ը ստեղծվում է [`once()`] գործառույթի կողմից: Տեսեք դրա փաստաթղթերը ավելին:
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}