use crate::iter::{FusedIterator, TrustedLen};

/// Ստեղծում է նոր կրկնիչ, որն անվերջ կրկնում է մեկ տարր:
///
/// `repeat()` ֆունկցիան կրկին ու կրկին կրկնում է մեկ արժեքը:
///
/// `repeat()`-ի նման անսահման կրկնիչները հաճախ օգտագործվում են [`Iterator::take()`]-ի նման ադապտերների հետ `դրանք վերջնական դարձնելու համար:
///
/// Եթե ձեր համար անհրաժեշտ կրկնիչի տարրի տեսակը չի իրականացնում `Clone`, կամ եթե չեք ցանկանում կրկնվող տարրը պահել հիշողության մեջ, փոխարենը կարող եք օգտագործել [`repeat_with()`] գործառույթը:
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::iter;
///
/// // թիվը չորս 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // այո, դեռ չորս
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Վերջանում է [`Iterator::take()`]-ով.
///
/// ```
/// use std::iter;
///
/// // այդ վերջին օրինակը չափազանց շատ չորս էր: Եկեք ընդամենը չորս քառյակ ունենանք:
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... և հիմա մենք ավարտեցինք
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Իտերատոր, որն անվերջ կրկնում է մի տարր:
///
/// Այս `struct`-ը ստեղծվում է [`repeat()`] գործառույթի կողմից: Տեսեք դրա փաստաթղթերը ավելին:
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}