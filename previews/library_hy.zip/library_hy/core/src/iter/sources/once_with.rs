use crate::iter::{FusedIterator, TrustedLen};

/// Ստեղծում է կրկնիչ, որը ծուլորեն առաջացնում է արժեք հենց մեկ անգամ `վկայակոչելով փակված փակումը:
///
/// Սա սովորաբար օգտագործվում է մեկ արժեքի գեներատորը [`chain()`] կրկնվող այլ տիպի կրկնության համար հարմարեցնելու համար:
/// Գուցե դուք ունեք կրկնիչ, որը ծածկում է գրեթե ամեն ինչ, բայց ձեզ հարկավոր է լրացուցիչ հատուկ պատյան:
/// Գուցե դուք ունեք գործառույթ, որն աշխատում է կրկնիչների վրա, բայց անհրաժեշտ է մշակել միայն մեկ արժեք:
///
/// Ի տարբերություն [`once()`]-ի, այս գործառույթը ծուլորեն առաջացնում է արժեքը ըստ պահանջի:
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// use std::iter;
///
/// // մեկը ամենաերկար թիվն է
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ընդամենը մեկը, դա այն է, ինչ մենք ստանում ենք
/// assert_eq!(None, one.next());
/// ```
///
/// Մեկ այլ կրկնիչի հետ միասին շղթայակցում:
/// Ասենք, որ մենք ուզում ենք կրկնել `.foo` գրացուցակի յուրաքանչյուր ֆայլ, բայց նաև կազմաձևման ֆայլ,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // մենք պետք է DirEntry-ի կրկնիչից վերափոխենք PathBufs-ի կրկնիչի, այնպես որ մենք օգտագործում ենք քարտեզ
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // հիմա, մեր կրկնիչը հենց մեր կազմաձևող ֆայլի համար
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // շղթայեք երկու կրկնիչները միասին մեկ մեծ կրկնիչի
/// let files = dirs.chain(config);
///
/// // սա մեզ կտա .foo-ի, ինչպես նաև .foorc-ի բոլոր ֆայլերը
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Իտերատոր, որը տալիս է `A` տիպի մեկ տարր ՝ կիրառելով տրամադրված `F: FnOnce() -> A` փակումը:
///
///
/// Այս `struct`-ը ստեղծվում է [`once_with()`] գործառույթի կողմից:
/// Տեսեք դրա փաստաթղթերը ավելին:
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}