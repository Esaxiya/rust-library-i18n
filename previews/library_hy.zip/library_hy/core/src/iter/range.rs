use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Օբյեկտներ, որոնք ունեն *իրավահաջորդ* և *նախորդի* գործողություններ հասկացություն:
///
/// *Իրավահաջորդ* գործողությունը շարժվում է դեպի արժեքներ, որոնք ավելի մեծ համեմատություն են կատարում:
/// *Նախորդ* գործողությունը շարժվում է դեպի ավելի փոքր արժեքներ համեմատող արժեքներ:
///
/// # Safety
///
/// Այս trait-ը `unsafe` է, քանի որ դրա իրականացումը պետք է ճիշտ լինի `unsafe trait TrustedLen` ներդրումների անվտանգության համար, և այս trait-ի օգտագործման արդյունքները այլապես կարող են վստահվել `unsafe` ծածկագրի կողմից `ճիշտ լինելու և թվարկված պարտավորությունները կատարելու համար:
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Վերադարձնում է *իրավահաջորդ* քայլերի քանակը, որոնք անհրաժեշտ են `start`-ից `end`:
    ///
    /// Վերադարձնում է `None`, եթե քայլերի քանակը `usize`-ով լցվի (կամ անսահման է, կամ եթե `end`-ին երբեք չէր հասնի):
    ///
    ///
    /// # Invariants
    ///
    /// Xանկացած `a`, `b` և `n` համար ՝
    ///
    /// * `steps_between(&a, &b) == Some(n)` եթե և միայն եթե `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` եթե և միայն եթե `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` միայն եթե `a <= b`
    ///   * Եզրակացություն. `steps_between(&a, &b) == Some(0)` եթե և միայն եթե `a == b`
    ///   * Նշենք, որ `a <= b`-ը _not_-ը ենթադրում է `steps_between(&a, &b) != None`;
    ///     սա այն դեպքն է, երբ `b`-ին հասնելու համար կպահանջվեր `usize::MAX`-ից ավելի քայլ
    /// * `steps_between(&a, &b) == None` եթե `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Վերադարձնում է այն արժեքը, որը կստացվեր `self` `count`-ի *ժառանգորդը* վերցնելու դեպքում:
    ///
    /// Եթե դա գերազանցի `Self`-ի կողմից աջակցվող արժեքների շարքը, ապա վերադարձնում է `None`:
    ///
    /// # Invariants
    ///
    /// Xանկացած `a`, `n` և `m` համար ՝
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Xանկացած `a`, `n` և `m` համար, որտեղ `n + m` չի լցվում.
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Xանկացած `a` և `n` համար ՝
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Վերադարձնում է այն արժեքը, որը կստացվեր `self` `count`-ի *ժառանգորդը* վերցնելու դեպքում:
    ///
    /// Եթե դա լցվի `Self`-ի կողմից աջակցվող արժեքների տիրույթը, այս գործառույթը թույլատրվում է panic, փաթաթել կամ հագեցնել:
    ///
    /// Առաջարկվող վարքագիծը panic-ինն է, երբ վրիպազերծման պնդումները միացված են, և այլապես փաթաթել կամ հագեցնել:
    ///
    /// Անվտանգ ծածկագիրը չպետք է ապավինի վարարումից հետո վարքի ճիշտությանը:
    ///
    /// # Invariants
    ///
    /// Xանկացած `a`, `n` և `m` համար, որտեղ արտահոսք տեղի չի ունենում.
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Xանկացած `a` և `n` համար, որտեղ արտահոսք տեղի չի ունենում.
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Վերադարձնում է այն արժեքը, որը կստացվեր `self` `count`-ի *ժառանգորդը* վերցնելու դեպքում:
    ///
    /// # Safety
    ///
    /// Չսահմանված վարքագիծ է, որպեսզի այս գործողությունը դուրս գա `Self`-ի կողմից աջակցվող արժեքների տիրույթից:
    /// Եթե չեք կարող երաշխավորել, որ դա չի լցվի, փոխարենը օգտագործեք `forward` կամ `forward_checked`:
    ///
    /// # Invariants
    ///
    /// Xանկացած `a`-ի համար.
    ///
    /// * եթե առկա է `b` այնպիսի `b > a`, անվտանգ է զանգահարել `Step::forward_unchecked(a, 1)`
    /// * եթե առկա են `b`, `n` այնպիսի `steps_between(&a, &b) == Some(n)`, `Step::forward_unchecked(a, m)` ցանկացած `m <= n` համար անվտանգ է զանգահարելը:
    ///
    ///
    /// Xանկացած `a` և `n` համար, որտեղ արտահոսք տեղի չի ունենում.
    ///
    /// * `Step::forward_unchecked(a, n)` համարժեք է `Step::forward(a, n)`-ին
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Վերադարձնում է այն արժեքը, որը կստացվեր `self` `count` անգամվա *նախորդի* վերցմամբ:
    ///
    /// Եթե դա գերազանցի `Self`-ի կողմից աջակցվող արժեքների շարքը, ապա վերադարձնում է `None`:
    ///
    /// # Invariants
    ///
    /// Xանկացած `a`, `n` և `m` համար ՝
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Xանկացած `a` և `n` համար ՝
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Վերադարձնում է այն արժեքը, որը կստացվեր `self` `count` անգամվա *նախորդի* վերցմամբ:
    ///
    /// Եթե դա լցվի `Self`-ի կողմից աջակցվող արժեքների տիրույթը, այս գործառույթը թույլատրվում է panic, փաթաթել կամ հագեցնել:
    ///
    /// Առաջարկվող վարքագիծը panic-ինն է, երբ վրիպազերծման պնդումները միացված են, և այլապես փաթաթել կամ հագեցնել:
    ///
    /// Անվտանգ ծածկագիրը չպետք է ապավինի վարարումից հետո վարքի ճիշտությանը:
    ///
    /// # Invariants
    ///
    /// Xանկացած `a`, `n` և `m` համար, որտեղ արտահոսք տեղի չի ունենում.
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Xանկացած `a` և `n` համար, որտեղ արտահոսք տեղի չի ունենում.
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Վերադարձնում է այն արժեքը, որը կստացվեր `self` `count` անգամվա *նախորդի* վերցմամբ:
    ///
    /// # Safety
    ///
    /// Չսահմանված վարքագիծ է, որպեսզի այս գործողությունը դուրս գա `Self`-ի կողմից աջակցվող արժեքների տիրույթից:
    /// Եթե չեք կարող երաշխավորել, որ դա չի լցվի, փոխարենը օգտագործեք `backward` կամ `backward_checked`:
    ///
    /// # Invariants
    ///
    /// Xանկացած `a`-ի համար.
    ///
    /// * եթե առկա է `b` այնպիսի `b < a`, անվտանգ է զանգահարել `Step::backward_unchecked(a, 1)`
    /// * եթե առկա են `b`, `n` այնպիսի `steps_between(&b, &a) == Some(n)`, `Step::backward_unchecked(a, m)` ցանկացած `m <= n` համար անվտանգ է զանգահարելը:
    ///
    ///
    /// Xանկացած `a` և `n` համար, որտեղ արտահոսք տեղի չի ունենում.
    ///
    /// * `Step::backward_unchecked(a, n)` համարժեք է `Step::backward(a, n)`-ին
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Սրանք դեռ մակրոտնտեսական են, քանի որ ամբողջ թվերի բառացիաները լուծվում են տարբեր տեսակների:
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `start + n`-ը չի լցվում:
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ `start - n`-ը չի լցվում:
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Վրիպազերծված կառուցվածքներում վարարման վրա գործարկեք panic:
            // Սա պետք է ամբողջովին օպտիմիզացվի թողարկումների կառուցվածքներում:
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Կատարեք փաթեթավորող մաթեմատիկա ՝ թույլ տալու համար, օրինակ `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Վրիպազերծված կառուցվածքներում վարարման վրա գործարկեք panic:
            // Սա պետք է ամբողջովին օպտիմիզացվի թողարկումների կառուցվածքներում:
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Կատարեք փաթեթավորող մաթեմատիկա ՝ թույլ տալու համար, օրինակ `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Սա ապավինում է $u_narrower <=օգտագործմանը
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // եթե n տիրույթից դուրս է, `unsigned_start + n`-ն էլ է
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // եթե n տիրույթից դուրս է, `unsigned_start - n`-ն էլ է
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Սա ապավինում է $i_narrower <=օգտագործմանը
                        //
                        // Իզիզացման համար ձուլումը տարածում է լայնությունը, բայց պահպանում է նշանը:
                        // Օգտագործեք wrapping_sub-ը `իզիզացված տարածության մեջ և ձուլեք` օգտագործելու համար `հաշվարկելու համար այն տարբերությունը, որը կարող է չտեղավորվել իզիզի տիրույթում:
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Փաթաթելը կարգավորում է այնպիսի դեպքեր, ինչպիսիք են `Step::forward(-120_i8, 200) == Some(80_i8)`, չնայած որ 200-ը i8-ի սահմաններից դուրս է:
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Ավելացումը վարարեց
                            }
                        }
                        // Եթե n-ն օրինակից դուրս է
                        // u8, ապա այն ավելի մեծ է, քան i8-ի համար ամբողջ տիրույթը լայն է, այնպես որ `any_i8 + n`-ը պարտադիր լցվում է i8:
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Փաթաթելը կարգավորում է այնպիսի դեպքեր, ինչպիսիք են `Step::forward(-120_i8, 200) == Some(80_i8)`, չնայած որ 200-ը i8-ի սահմաններից դուրս է:
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Հանումը հորդում էր
                            }
                        }
                        // Եթե n-ն օրինակից դուրս է
                        // u8, ապա այն ավելի մեծ է, քան i8-ի համար ամբողջ տիրույթը լայն է, այնպես որ `any_i8 - n`-ը պարտադիր լցվում է i8:
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Եթե տարբերությունը շատ մեծ է, օրինակ,
                            // i128, այն նաև մեծ կլինի ավելի քիչ օգտագործման համար ՝ ավելի քիչ բիթերով:
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Res-ը վավեր միաոդ կոդ է
            // (0x110000-ից ցածր և ոչ 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Res-ը վավեր միաոդ կոդ է
        // (0x110000-ից ցածր և ոչ 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ դա չի հորդում
        // արժեքի շարքը գրանշանի համար:
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ դա չի հորդում
            // արժեքի շարքը գրանշանի համար:
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նախորդ պայմանագրի պատճառով դա երաշխավորված է
        // զանգահարողի կողմից վավեր գործիչ լինելու համար:
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ դա չի հորդում
        // արժեքի շարքը գրանշանի համար:
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է երաշխավորի, որ դա չի հորդում
            // արժեքի շարքը գրանշանի համար:
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նախորդ պայմանագրի պատճառով դա երաշխավորված է
        // զանգահարողի կողմից վավեր գործիչ լինելու համար:
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Այս մակրոները առաջացնում են `ExactSizeIterator` ազդանշաններ տարբեր տեսակների համար:
//
// * `ExactSizeIterator::len` պահանջվում է միշտ ճշգրիտ `usize` վերադարձնելու համար, ուստի ոչ մի տիրույթ չի կարող ավելի երկար լինել, քան `usize::MAX`-ը:
//
// * `Range<_>`-ի ամբողջ տեսակների համար դա վերաբերում է `usize`-ից ավելի նեղ կամ լայն տեսակների:
//   `RangeInclusive<_>`-ի ամբողջ տեսակների համար դա վերաբերում է *խիստ նեղ* տիպերին, քան `usize`, քանի որ, օրինակ,
//   `(0..=u64::MAX).len()` կլիներ `u64::MAX + 1`:
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Սրանք ներառված չեն վերոհիշյալ պատճառաբանությամբ, բայց դրանք հանելը կոտրող փոփոխություն կլինի, քանի որ դրանք կայունացել են Rust 1.0.0-ում:
    // Այսպիսով, օրինակ
    // `(0..66_000_u32).len()` օրինակ ՝ կկազմի առանց սխալի կամ նախազգուշացման 16-բիթանոց պլատֆորմներում, բայց կշարունակի սխալ արդյունք տալ:
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Սրանք ներառված չեն վերոհիշյալ պատճառաբանությամբ, բայց դրանք հանելը կոտրող փոփոխություն կլինի, քանի որ դրանք կայունացել են Rust 1.26.0-ում:
    // Այսպիսով, օրինակ
    // `(0..=u16::MAX).len()` օրինակ ՝ կկազմի առանց սխալի կամ նախազգուշացման 16-բիթանոց պլատֆորմներում, բայց կշարունակի սխալ արդյունք տալ:
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Հենց ստուգված նախապայման
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}