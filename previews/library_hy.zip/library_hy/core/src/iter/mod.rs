//! Կազմելի արտաքին կրկնություն:
//!
//! Եթե դուք գտել եք ինչ-որ տեսակի հավաքածու, և անհրաժեշտ է գործողություն կատարել նշված հավաքածուի տարրերի վրա, դուք արագ կբախվեք 'iterators'-ին:
//! Կրկնվողները մեծապես օգտագործվում են իդոմատիկ Rust կոդում, ուստի արժե նրանց հետ ծանոթանալ:
//!
//! Լրացուցիչ բացատրելուց առաջ եկեք խոսենք, թե ինչպես է կառուցված այս մոդուլը.
//!
//! # Organization
//!
//! Այս մոդուլը հիմնականում կազմակերպվում է ըստ տեսակների.
//!
//! * [Traits] հիմնական մասն են. այս traits-ը սահմանում է, թե ինչպիսի կրկնիչներ գոյություն ունեն և ինչ կարող ես անել դրանց հետ: Այս traits-ի մեթոդներն արժե ուսումնասիրության լրացուցիչ ժամանակ տրամադրել:
//! * [Functions] տրամադրեք որոշ հիմնական կրկնիչներ ստեղծելու օգտակար եղանակներ:
//! * [Structs] հաճախ այս մոդուլի traits-ի տարբեր մեթոդների վերադարձման տեսակներ են: Սովորաբար կցանկանաք դիտել `struct` ստեղծող մեթոդը, այլ ոչ թե `struct` բունը:
//! Ինչի վերաբերյալ ավելի մանրամասն տեղեկություններ ստանալու համար տե՛ս «[Implementing Iterator](#implement-iterator)»:
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! ՎերջԵկեք փորփրենք կրկնիչների մեջ:
//!
//! # Iterator
//!
//! Այս մոդուլի սիրտն ու հոգին [`Iterator`] trait է: [`Iterator`]-ի միջուկն ունի այսպիսի տեսք.
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Կրկնիչը ունի [`next`] մեթոդ, որը զանգահարելիս վերադարձնում է [«Տարբերակ»] »<Item>`
//! [`next`] կվերադարձնի [`Some(Item)`], քանի դեռ կան տարրեր, և երբ բոլորը սպառվեն, կվերադարձնի `None` ՝ նշելու, որ կրկնությունն ավարտված է:
//! Անհատական կրկնիչները կարող են որոշել վերսկսել կրկնությունը, և այդպիսով նորից [`next`] զանգելը կարող է ինչ-որ պահի ի վերջո սկսել կամ վերադառնալ [`Some(Item)`] (օրինակ, տես [`TryIter`]):
//!
//!
//! [«Iterator»]-ի ամբողջական սահմանումը ներառում է նաև մի շարք այլ մեթոդներ, բայց դրանք լռելյայն մեթոդներ են ՝ կառուցված [`next`]-ի վերևում, և այդպիսով դրանք անվճար եք ստանում:
//!
//! Կրկնվողները նույնպես կոմպոզիցիոն են, և սովորական է դրանք միասին շղթայել `վերամշակման ավելի բարդ ձևեր կատարելու համար: Լրացուցիչ մանրամասների համար տե՛ս [Adapters](#adapters) բաժինը ստորև:
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Կրկնության երեք ձևերը
//!
//! Գոյություն ունեն երեք ընդհանուր մեթոդներ, որոնք կարող են հավաքածուից ստեղծել կրկնիչներ.
//!
//! * `iter()`, որը կրկնվում է `&T`-ի վրա:
//! * `iter_mut()`, որը կրկնվում է `&mut T`-ի վրա:
//! * `into_iter()`, որը կրկնվում է `T`-ի վրա:
//!
//! Ստանդարտ գրադարանում զանազան իրեր կարող են իրականացնել երեքից մեկը կամ մի քանիսը, անհրաժեշտության դեպքում:
//!
//! # Իրականացնող Iterator
//!
//! Սեփական ինտերատոր ստեղծելը ներառում է երկու քայլ. Ստեղծեք `struct` ՝ կրկնիչի վիճակը պահելու համար, և ապա իրականացնել [`Iterator`] այդ `struct`-ի համար:
//! Ահա թե ինչու այս մոդուլում այսքան շատ կառուցվածք կա. Յուրաքանչյուր կրկնիչի և կրկնիչի ադապտերի համար կա մեկը:
//!
//! Եկեք պատրաստենք `Counter` անունով կրկնիչ, որը հաշվում է `1`-ից `5`:
//!
//! ```
//! // Նախ ՝ կառուցվածքը.
//!
//! /// Կրկնիչ, որը հաշվում է մեկից հինգը
//! struct Counter {
//!     count: usize,
//! }
//!
//! // մենք ուզում ենք, որ մեր հաշվարկը սկսվի մեկից, ուստի եկեք օգնենք new() եղանակին:
//! // Սա խիստ անհրաժեշտ չէ, բայց հարմար է:
//! // Նշենք, որ մենք `count`-ը սկսում ենք զրոյից, թե ինչու մենք կտեսնենք ստորև `next()`'s իրականացման մեջ:
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Դրանից հետո մենք իրականացնում ենք `Iterator` մեր `Counter`-ի համար.
//!
//! impl Iterator for Counter {
//!     // մենք հաշվելու ենք օգտագործողի հետ
//!     type Item = usize;
//!
//!     // next() միակ պահանջվող մեթոդն է
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Ավելացրեք մեր հաշվարկը: Ահա թե ինչու մենք սկսեցինք զրոյից:
//!         self.count += 1;
//!
//!         // Ստուգեք ՝ արդյո՞ք ավարտել ենք հաշվելը, թե ոչ:
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Եվ հիմա մենք կարող ենք օգտագործել այն:
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Այս եղանակով [`next`] զանգահարելը կրկնվում է: Rust-ն ունի կառուցվածք, որը կարող է զանգահարել [`next`] ձեր կրկնիչի վրա, մինչև այն հասնի `None`:Եկեք անցնենք դրան հաջորդիվ:
//!
//! Նկատի ունեցեք նաև, որ `Iterator`-ն ապահովում է այնպիսի մեթոդների լռելյայն իրականացում, ինչպիսին են `nth`-ը և `fold`-ը, որոնք ներքինով զանգահարում են `next`:
//! Այնուամենայնիվ, հնարավոր է նաև գրել այնպիսի մեթոդների հարմարեցված իրականացում, ինչպիսին է `nth`-ը և `fold`-ը, եթե կրկնիչը կարող է դրանք ավելի արդյունավետ հաշվարկել `առանց `next` զանգահարելու:
//!
//! # `for` օղակներ և `IntoIterator`
//!
//! Rust-ի `for` հանգույցի շարահյուսությունը իրականում շաքար է կրկնիչների համար: Ահա `for`-ի հիմնական օրինակը.
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Սա կտպագրի թվերը մեկից հինգ, յուրաքանչյուրը իր տողի վրա: Բայց այստեղ դուք ինչ-որ բան կնկատեք. Մենք երբեք մեր vector-ի վրա ոչինչ չենք զանգահարել `կրկնիչ ստեղծելու համար:Ի՞նչ է տալիս:
//!
//! Ստանդարտ գրադարանում կա trait ՝ ինչ-որ բան կրկնիչի վերափոխելու համար. [`IntoIterator`].
//! Այս trait-ն ունի մեկ մեթոդ [`into_iter`], որը [`IntoIterator`]-ն իրագործող բանը վերափոխում է կրկնիչի:
//! Եկեք նորից նայենք այդ `for` հանգույցին և այն, ինչի վերածում է կազմողը:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust-ը շաքարավազ է տալիս հետևյալի ՝
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Նախ, մենք արժեքի վրա զանգահարում ենք `into_iter()`: Դրանից հետո մենք համընկնում ենք վերադարձողի կրկնիչի հետ ՝ անընդմեջ զանգահարելով [`next`], մինչև տեսնենք `None`:
//! Այդ պահին մենք `break`-ը դուրս ենք գալիս օղակից և ավարտում ենք կրկնությունը:
//!
//! Այստեղ կա ևս մեկ նուրբ մի կտոր. Ստանդարտ գրադարանը պարունակում է [`IntoIterator`]-ի հետաքրքիր իրականացում.
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Այլ կերպ ասած, [[Iterator »-ի] բոլորն իրականացնում են [`IntoIterator`], պարզապես վերադառնալով իրենց: Սա նշանակում է երկու բան.
//!
//! 1. Եթե [`Iterator`] եք գրում, այն կարող եք օգտագործել `for` օղակով:
//! 2. Եթե հավաքածու եք ստեղծում, դրա համար [`IntoIterator`]-ի ներդրումը թույլ կտա ձեր հավաքածուն օգտագործել `for` օղակի հետ:
//!
//! # Կրկնվում է հղումով
//!
//! Քանի որ [`into_iter()`]-ը ըստ արժեքի վերցնում է `self`-ը, հավաքածուի վրա կրկնություն կատարելու համար `for` օղակի օգտագործումը սպառում է այդ հավաքածուն: Հաճախ դուք կարող եք ցանկանալ կրկնություն կատարել հավաքածուի մեջ ՝ առանց այն սպառելու:
//! Բազմաթիվ հավաքածուներ առաջարկում են մեթոդներ, որոնք ապահովում են հղումների նկատմամբ կրկնիչները, որոնք պայմանականորեն կոչվում են համապատասխանաբար `iter()` և `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` դեռ պատկանում է այս գործառույթին:
//! ```
//!
//! Եթե `C` տեսակի հավաքածուն ապահովում է `iter()`, այն սովորաբար իրականացնում է նաև `IntoIterator` `&C`-ի համար, այն իրականացումով, որը պարզապես զանգահարում է `iter()`:
//! Նմանապես, `C` հավաքածուն, որն ապահովում է `iter_mut()`, սովորաբար իրականացնում է `IntoIterator` `&mut C`-ի համար ՝ պատվիրելով `iter_mut()`-ին: Սա հնարավորություն է տալիս հարմար սղագրության.
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // նույնը, ինչ `values.iter_mut()`-ը
//!     *x += 1;
//! }
//! for x in &values { // նույնը, ինչ `values.iter()`-ը
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Չնայած շատ հավաքածուներ առաջարկում են `iter()`, ոչ բոլորն են առաջարկում `iter_mut()`:
//! Օրինակ, [`HashSet<T>`]-ի կամ [`HashMap<K, V>`]-ի ստեղները մուտացիայի ենթարկելը կարող է հավաքածուն դնել անհամապատասխան վիճակում, եթե ստեղնաշղթաները փոխվեն, ուստի այս հավաքածուներն առաջարկում են միայն `iter()`:
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Այն գործառույթները, որոնք վերցնում են [`Iterator`] և վերադարձնում մեկ այլ [`Iterator`], հաճախ կոչվում են «iterator adapters», քանի որ դրանք «adapter»-ի ձև են:
//! pattern'.
//!
//! Iterator-ի սովորական ադապտերները ներառում են [`map`], [`take`] և [`filter`]:
//! Լրացուցիչի համար տես նրանց փաստաթղթերը:
//!
//! Եթե կրկնվող panics ադապտեր է, ապա iterator-ը կլինի չճշտված (բայց հիշողություն ապահով) վիճակում:
//! Այս վիճակը նաև երաշխավորված չէ նույնը մնալ Rust-ի տարբերակներում, այնպես որ պետք է խուսափել խուճապահար կրկնվողի վերադարձած ճշգրիտ արժեքների վրա:
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Կրկնողները (և [adapters](#adapters)) կրկնիչը * ծույլ են): Սա նշանակում է, որ պարզապես կրկնիչ ստեղծելը _do_-ին միանգամայն շատ բան չի ներկայացնում: Ոչինչ իրականում չի պատահում, մինչև դուք չեք զանգում [`next`]:
//! Դա երբեմն շփոթության աղբյուր է, երբ կրկնիչ ստեղծելը բացառապես իր կողմնակի ազդեցությունների համար է:
//! Օրինակ, [`map`] մեթոդը կոչ է անում փակել յուրաքանչյուր տարրի վրա, որն իր վրա կրկնում է.
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Սա չի տպի որևէ արժեք, քանի որ մենք ստեղծել ենք միայն կրկնիչ, այլ ոչ թե օգտագործել այն: Կազմողը նախազգուշացնելու է մեզ այսպիսի վարքի մասին.
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`]-ը իր կողմնակի ազդեցությունների համար գրելու իդիոմատիկ ձևը `for` հանգույց օգտագործելն է կամ [`for_each`] մեթոդը զանգահարելը.
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Իտերատոր գնահատելու մեկ այլ սովորական միջոց է `օգտագործել [`collect`] մեթոդը` նոր հավաքածու արտադրելու համար:
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Կրկնողները պարտադիր չեն վերջավոր լինել: Որպես օրինակ, բաց ավարտի տիրույթը անվերջ կրկնիչ է.
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Սովորական է [`take`] կրկնիչի ադապտեր օգտագործել անվերջ կրկնիչը վերջավորի վերածելու համար.
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Սա կտպագրի `0`-ից `4` համարները, յուրաքանչյուրն իր գծի վրա:
//!
//! Հիշեք, որ անսահման կրկնիչների մեթոդները, նույնիսկ նրանք, որոնց համար արդյունքը կարող է որոշվել մաթեմատիկորեն վերջավոր ժամանակում, կարող են չդադարեցնել:
//! Մասնավորապես, [`min`]-ի նման մեթոդները, որոնք, ընդհանուր առմամբ, պահանջում են կրկնիչի յուրաքանչյուր տարրը հատել, հավանական է, որ հաջողությամբ չեն վերադառնա ցանկացած անսահման կրկնիչների համար:
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Օ ոչ!Անսահման օղակ:
//! // `ones.min()` առաջացնում է անսահման հանգույց, այնպես որ մենք չենք հասնի այս կետին:
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;