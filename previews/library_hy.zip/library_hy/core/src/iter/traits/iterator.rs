// injore-tidy-filelength Այս ֆայլը գրեթե բացառապես բաղկացած է `Iterator` սահմանումից:
// Մենք չենք կարող դա բաժանել մի քանի ֆայլերի:
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Կրկնվողների հետ գործելու միջերես:
///
/// Սա trait հիմնական կրկնիչն է:
/// Ընդհանրապես կրկնիչներ հասկացության մասին ավելին իմանալու համար տես [module-level documentation]:
/// Մասնավորապես, գուցե ցանկանաք իմանալ, թե ինչպես կարելի է [implement `Iterator`][impl]:
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Տարրերի կրկնվող տիպը:
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Առաջ է մղում կրկնիչը և վերադարձնում հաջորդ արժեքը:
    ///
    /// Վերադարձնում է [`None`], երբ կրկնությունն ավարտվում է:
    /// Իտերատորի անհատական իրականացումը կարող է ընտրել վերսկսումը վերսկսելը, և այդպիսով կրկին `next()` զանգելը կարող է ինչ-որ պահի ի վերջո նորից սկսել վերադարձնել [`Some(Item)`]:
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next()-ի զանգը վերադարձնում է հաջորդ արժեքը ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... և հետո ոչ մեկը, երբ ավարտվի:
    /// assert_eq!(None, iter.next());
    ///
    /// // Ավելի շատ զանգեր կարող են վերադարձնել `None`: Այստեղ նրանք միշտ էլ կանեն:
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Վերադարձնում է կրկնիչի մնացած երկարության սահմանները:
    ///
    /// Մասնավորապես, `size_hint()`-ը վերադարձնում է մի տուփ, որտեղ առաջին տարրը ստորին սահմանն է, իսկ երկրորդը `վերին սահմանը:
    ///
    /// Վերադարձված տուպլի երկրորդ կեսը [«Տարբերակ»] «<« [օգտագործեք »]»> է:
    /// [`None`]-ն այստեղ նշանակում է, որ կա՛մ հայտնի վերին սահման չկա, կա՛մ վերին սահմանը [`usize`]-ից մեծ է:
    ///
    /// # Իրականացման նշում
    ///
    /// Չի պարտադրվում, որ կրկնիչի իրականացումը տալիս է հայտարարված տարրերի քանակը: Սխալ կրկնօրինակը կարող է զիջել տարրերի ստորին սահմանից կամ վերևի սահմանից ավելին:
    ///
    /// `size_hint()` առաջին հերթին նախատեսված է օպտիմալացման համար, ինչպիսիք են կրկնիչի տարրերի համար տարածք պահելու համար, բայց չպետք է վստահել, որ օրինակ `անպաշտպան ծածկագրում սահմանների ստուգումները բաց թողնելը:
    /// `size_hint()`-ի սխալ իրականացումը չպետք է հանգեցնի հիշողության անվտանգության խախտումների:
    ///
    /// Ասել է թե, իրականացումը պետք է ճիշտ գնահատական տա, քանի որ հակառակ դեպքում դա կլինի trait-ի արձանագրության խախտում:
    ///
    /// Լռելյայն իրականացումը վերադարձնում է «(0,« [«Ոչ մեկը» »)», որը ճիշտ է ցանկացած կրկնիչի համար:
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Ավելի բարդ օրինակ.
    ///
    /// ```
    /// // Evenույգ թվերը զրոյից տաս:
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Մենք կարող ենք զրոյից տաս անգամ կրկնել:
    /// // Իմանալով, որ դա հինգ է, հնարավոր չէր լինի առանց filter() կատարելու:
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Եկեք chain()-ով ավելացնենք ևս հինգ թվեր
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // այժմ երկու սահմաններն էլ ավելացել են հինգով
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Վերադառնալով `None`-ը վերին սահմանի համար.
    ///
    /// ```
    /// // անվերջ կրկնիչը չունի վերին սահման և առավելագույն հնարավոր ստորին սահման
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Սպառում է կրկնիչը ՝ հաշվելով կրկնությունների քանակը և վերադարձնելով այն:
    ///
    /// Այս մեթոդը մի քանի անգամ զանգահարելու է [`next`] մինչև [`None`] չհանդիպի ՝ վերադարձնելով [`Some`] տեսած անգամների քանակը:
    /// Նշենք, որ [`next`]-ը պետք է կանչվի գոնե մեկ անգամ, նույնիսկ եթե կրկնիչը չունի որևէ տարր:
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Հորդառատ վարք
    ///
    /// Մեթոդը չի պաշտպանում վարարումները, ուստի [`usize::MAX`]-ից ավելի տարրերով կրկնիչի տարրերի հաշվելը կամ առաջացնում է սխալ արդյունք, կամ panics:
    ///
    /// Եթե վրիպազերծման պնդումները միացված են, panic-ն երաշխավորված է:
    ///
    /// # Panics
    ///
    /// Այս գործառույթը կարող է լինել panic, եթե կրկնիչը ունի ավելի քան [`usize::MAX`] տարր:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Սպառում է կրկնիչը ՝ վերադարձնելով վերջին տարրը:
    ///
    /// Այս մեթոդը կգնահատի կրկնիչը մինչև այն վերադարձնի [`None`]:
    /// Դա անելիս այն հետևում է ընթացիկ տարրի հետ:
    /// [`None`]-ը վերադարձնելուց հետո `last()`-ը հետ կվերադարձնի իր տեսած վերջին տարրը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Առաջնորդին զարգացնում է `n` տարրերով:
    ///
    /// Այս մեթոդը անհամբերությամբ շրջանցելու է `n` տարրերը ՝ զանգահարելով [`next`] մինչև `n` անգամ, մինչև [`None`] չհանդիպի:
    ///
    /// `advance_by(n)` կվերադարձնի [`Ok(())`][Ok], եթե կրկնիչը հաջողությամբ առաջ է շարժվում `n` տարրերով, կամ [`Err(k)`][Err], եթե [`None`] հանդիպում է, որտեղ `k` այն տարրերի թիվն է, որով առաջադրողը առաջ է մղվում նախքան տարրերի սպառումը (այսինքն
    /// կրկնիչի երկարությունը):
    /// Նշենք, որ `k`-ը միշտ պակաս է, քան `n`-ը:
    ///
    /// `advance_by(0)` զանգահարելը չի սպառում որևէ տարր և միշտ վերադարձնում է [`Ok(())`][Ok]:
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // բաց է թողնվել միայն `&4`-ը
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Վերադարձնում է կրկնիչի `n`-րդ տարրը:
    ///
    /// Ինդեքսավորման գործառնությունների մեծամասնության նման, հաշվարկը սկսվում է զրոյից, այնպես որ `nth(0)`-ը վերադարձնում է առաջին արժեքը, `nth(1)` երկրորդը և այլն:
    ///
    /// Նշենք, որ նախորդող բոլոր տարրերը, ինչպես նաև վերադարձված տարրը կսպառվեն կրկնիչից:
    /// Դա նշանակում է, որ նախորդ տարրերը կվերացվեն, և նաև, որ `nth(0)` բազմակի զանգահարելը նույն կրկնիչի միջոցով կվերադարձնի տարբեր տարրեր:
    ///
    ///
    /// `nth()` կվերադարձնի [`None`], եթե `n`-ը կրկնիչի երկարությունից մեծ կամ հավասար է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` բազմակի զանգելը չի փոխում կրկնիչը.
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `None`-ի վերադարձը, եթե `n + 1`-ից պակաս տարրեր կան.
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Ստեղծում է նույնականիչ սկսած նույն կետից, բայց յուրաքանչյուր կրկնության վրա քայլ առ քայլ տրված գումարի չափով:
    ///
    /// Նշում 1. Կրկնիչի առաջին տարրը միշտ հետ կվերադարձվի ՝ անկախ տրված քայլից:
    ///
    /// Նշում 2. Անտեսված տարրերը քաշելու ժամանակը ֆիքսված չէ:
    /// `StepBy` իրեն պահում է ինչպես `next(), nth(step-1), nth(step-1),…` հաջորդականությունը, բայց նաև ազատ է վարվելու հաջորդականության նման
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Կատարման պատճառներով որոշ կրկնիչների համար որ եղանակն է օգտագործվում, կարող է փոխվել:
    /// Երկրորդ ճանապարհը ավելի շուտ առաջ կտանի կրկնիչը և կարող է սպառել ավելի շատ իրեր:
    ///
    /// `advance_n_and_return_first` համարժեք է.
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Մեթոդը կլինի panic, եթե տրված քայլը `0` է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Վերցնում է երկու կրկնիչ և ստեղծում նոր կրկնիչ հաջորդականությամբ:
    ///
    /// `chain()` կվերադարձնի նոր կրկնիչը, որը նախ կկրկնվի առաջին կրկնիչի արժեքներից, ապա երկրորդ կրկնիչից արժեքների նկատմամբ:
    ///
    /// Այլ կերպ ասած, այն շղթայի մեջ կապում է երկու կրկնորդի իրար: 🔗
    ///
    /// [`once`] սովորաբար օգտագործվում է մեկ արժեքը կրկնության այլ տեսակների շղթայի մեջ հարմարեցնելու համար:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Քանի որ `chain()`-ի փաստարկն օգտագործում է [`IntoIterator`], մենք կարող ենք փոխանցել ցանկացած բան, ինչը կարող է փոխարկվել [`Iterator`], ոչ միայն [`Iterator`] ինքնին:
    /// Օրինակ, (`&[T]`) կտորներն իրականացնում են [`IntoIterator`], և այդպիսով կարելի է ուղղակիորեն փոխանցել `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Եթե աշխատում եք Windows API-ի հետ, գուցե ցանկանաք փոխել [`OsStr`]-ը `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// «Կատարում է վերևում» երկու կրկնիչի և վերածվում է զույգերի մեկ կրկնիչի:
    ///
    /// `zip()` վերադարձնում է նոր կրկնիչ, որը կրկնվելու է երկու այլ կրկնիչների վրա ՝ վերադարձնելով մի տուփ, որտեղ առաջին տարրը գալիս է առաջին կրկնիչի կողմից, իսկ երկրորդը գալիս է երկրորդ կրկնիչի կողմից:
    ///
    ///
    /// Այլ կերպ ասած, այն միացնում է երկու կրկնիչի միասին `մեկին:
    ///
    /// Եթե որևէ կրկնիչ վերադարձնի [`None`], ապա z0 կրկնվողից [`next`] կվերադարձնի [`None`]:
    /// Եթե առաջին կրկնիչը վերադարձնի [`None`], `zip`-ը կարճ միացում կկազմի, և `next`-ը չի կանչի երկրորդ կրկնիչի վրա:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Քանի որ `zip()`-ի փաստարկն օգտագործում է [`IntoIterator`], մենք կարող ենք փոխանցել ցանկացած բան, ինչը կարող է փոխարկվել [`Iterator`], ոչ միայն [`Iterator`] ինքնին:
    /// Օրինակ, (`&[T]`) կտորներն իրականացնում են [`IntoIterator`], և այդպիսով կարելի է ուղղակիորեն փոխանցել `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` հաճախ օգտագործվում է անսահման կրկնիչը փակելու համար վերջավորի հետ:
    /// Սա գործում է, քանի որ վերջավոր կրկնիչը ի վերջո կվերադառնա [`None`] ՝ վերջ տալով կայծակաճարմանդին: `(0..)`-ով կայծակաճարմանդ կարող է նմանվել [`enumerate`]-ին.
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Ստեղծում է նոր կրկնիչ, որը տեղադրում է `separator`-ի պատճենը բնօրինակ կրկնիչի հարակից իրերի միջև:
    ///
    /// Այն դեպքում, երբ `separator`-ը չի իրականացնում [`Clone`] կամ անհրաժեշտ է ամեն անգամ հաշվարկել, օգտագործեք [`intersperse_with`]:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Առաջին տարրը `a`-ից:
    /// assert_eq!(a.next(), Some(&100)); // Առանձնացնողը:
    /// assert_eq!(a.next(), Some(&1));   // Հաջորդ տարրը `a`-ից:
    /// assert_eq!(a.next(), Some(&100)); // Առանձնացնողը:
    /// assert_eq!(a.next(), Some(&2));   // Վերջին տարրը `a`-ից:
    /// assert_eq!(a.next(), None);       // Կրկնիչն ավարտված է:
    /// ```
    ///
    /// `intersperse` կարող է շատ օգտակար լինել կրկնիչի իրերին միանալու համար `օգտագործելով ընդհանուր տարր:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Ստեղծում է նոր կրկնիչ, որը տեղադրում է `separator`-ի կողմից առաջացած իրը բնօրինակ կրկնիչի հարակից իրերի միջև:
    ///
    /// Փակումը կկոչվի ուղիղ մեկ անգամ, երբ ապրանքը տեղադրվում է հիմքում ընկած կրկնիչից երկու հարակից իրերի միջև:
    /// մասնավորապես, փակումը չի կոչվում, եթե հիմքում ընկած կրկնորդը տալիս է երկու կետից պակաս և վերջին նյութը տալուց հետո:
    ///
    ///
    /// Եթե կրկնիչի տարրը իրականացնում է [`Clone`], գուցե ավելի հեշտ լինի օգտագործել [`intersperse`]:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Առաջին տարրը `v`-ից:
    /// assert_eq!(it.next(), Some(NotClone(99))); // Առանձնացնողը:
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Հաջորդ տարրը `v`-ից:
    /// assert_eq!(it.next(), Some(NotClone(99))); // Առանձնացնողը:
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Վերջին տարրը `v`-ից:
    /// assert_eq!(it.next(), None);               // Կրկնիչն ավարտված է:
    /// ```
    ///
    /// `intersperse_with` կարող է օգտագործվել այն իրավիճակներում, երբ բաժանարարը պետք է հաշվարկի.
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Փակումը փոխադարձաբար վերցնում է իր համատեքստը ՝ իր ստեղծելու համար:
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Փակում է փակումը և ստեղծում է կրկնիչ, որն այդ փակումը կոչում է յուրաքանչյուր տարր:
    ///
    /// `map()` վերափոխում է մեկ կրկնիչը մյուսի ՝ իր փաստարկի միջոցով.
    /// մի բան, որն իրականացնում է [`FnMut`]: Այն արտադրում է նոր կրկնիչ, որն այս փակումը կոչում է սկզբնական կրկնիչի յուրաքանչյուր տարր:
    ///
    /// Եթե դուք լավ եք մտածում տեսակների մեջ, կարող եք `map()`-ի մասին մտածել այսպես.
    /// Եթե ունեք կրկնիչ, որը ձեզ տալիս է որոշ տեսակի `A` տիպի տարրեր, և ցանկանում եք ինչ-որ այլ տեսակի `B` կրկնիչ, կարող եք օգտագործել `map()` ՝ անցնելով փակումը, որը տանում է `A` և վերադարձնում `B`:
    ///
    ///
    /// `map()` հայեցակարգով նման է [`for`] հանգույցին: Այնուամենայնիվ, քանի որ `map()`-ը ծույլ է, այն լավագույնս օգտագործվում է այն ժամանակ, երբ դուք արդեն աշխատում եք այլ կրկնիչների հետ:
    /// Եթե կողմնակի էֆեկտի համար ինչ-որ օղակ եք անում, [`for`]-ի օգտագործումը ավելի իդիոմատիկա է, քան `map()`-ը:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Եթե ինչ-որ կողմնակի էֆեկտ եք անում, նախընտրեք [`for`]-ը `map()`-ից.
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // մի արա սա.
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // այն նույնիսկ չի կատարվի, քանի որ ծույլ է: Rust-ը ձեզ զգուշացնելու է այս մասին:
    ///
    /// // Փոխարենը, օգտագործեք հետևյալի համար.
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Կոչ է անում փակիչի յուրաքանչյուր տարրի փակմանը:
    ///
    /// Սա համարժեք է կրկնիչի վրա [`for`] հանգույց օգտագործելու, չնայած `break` և `continue` հնարավոր չէ փակվելուց հետո:
    /// `for` հանգույց օգտագործելը, ընդհանուր առմամբ, ավելի իդիոմատիկ է, բայց `for_each`-ը կարող է ավելի ընթեռնելի լինել, երբ ավելի երկար կրկնվող շղթաների վերջում իրերը մշակվեն:
    ///
    /// Որոշ դեպքերում `for_each`-ը կարող է նաև ավելի արագ լինել, քան օղակը, քանի որ այն կօգտագործի ներքին կրկնում `Chain`-ի նման ադապտերների վրա:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Նման փոքր օրինակի համար `for` հանգույցը կարող է ավելի մաքուր լինել, բայց `for_each`-ը կարող է նախընտրելի լինել ՝ ավելի երկար կրկնիչներով ֆունկցիոնալ ոճ պահելու համար.
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Ստեղծում է կրկնիչ, որն օգտագործում է փակումը ՝ որոշելու համար, թե արդյոք տարրը պետք է զիջվի:
    ///
    /// Հաշվի առնելով մի տարր, փակումը պետք է վերադարձնի `true` կամ `false`: Վերադարձված կրկնիչը կտա միայն այն տարրերը, որոնց համար փակումը վերադառնում է իրական:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Քանի որ `filter()`-ին փոխանցված փակումը հղում է կատարում, և շատ կրկնիչներ կրկնում են հղումները, դա հանգեցնում է հնարավոր խառնաշփոթ իրավիճակի, երբ փակման տեսակը կրկնակի հղում է.
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // հարկավոր է երկու *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Փաստորեն փաստարկների վրա ապակողմնորոշում օգտագործելը մեկը հանելու համար սովորական է.
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // և՛ և *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// կամ երկուսն էլ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // երկու &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// այս շերտերից:
    ///
    /// Նշենք, որ `iter.filter(f).next()` համարժեք է `iter.find(f)`-ին:
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Ստեղծում է կրկնիչ, որը և զտում է, և քարտեզագրում:
    ///
    /// Վերադարձված կրկնիչը տալիս է միայն «արժեքը, որի համար մատակարարված փակումը վերադարձնում է `Some(value)`:
    ///
    /// `filter_map` կարելի է օգտագործել [`filter`] և [`map`] շղթաները ավելի հակիրճ դարձնելու համար:
    /// Ստորև բերված օրինակը ցույց է տալիս, թե ինչպես կարելի է `map().filter().map()`-ը կրճատել և դարձնել մեկ զանգ դեպի `filter_map`:
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ահա նույն օրինակը, բայց [`filter`]-ի և [`map`]-ի հետ.
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Ստեղծում է կրկնիչ, որը տալիս է ընթացիկ կրկնությունների քանակը, ինչպես նաև հաջորդ արժեքը:
    ///
    /// Վերադարձված կրկնիչը տալիս է `(i, val)` զույգ, որտեղ `i` կրկնության ընթացիկ ինդեքսն է, իսկ `val` կրկնիչը վերադարձված արժեքն է:
    ///
    ///
    /// `enumerate()` պահում է իր հաշվարկը որպես [`usize`]:
    /// Եթե ցանկանում եք հաշվել այլ չափի ամբողջ թվով, ապա [`zip`] ֆունկցիան ապահովում է նմանատիպ ֆունկցիոնալություն:
    ///
    /// # Հորդառատ վարք
    ///
    /// Մեթոդը չի պաշտպանում վարարումները, ուստի [`usize::MAX`]-ից ավելի տարրեր թվարկելը կամ տալիս է սխալ արդյունք, կամ panics:
    /// Եթե վրիպազերծման պնդումները միացված են, panic-ն երաշխավորված է:
    ///
    /// # Panics
    ///
    /// Վերադարձված կրկնիչը կարող է panic լինել, եթե վերադարձվող ինդեքսը [`usize`]-ով լցվի:
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Ստեղծում է կրկնիչ, որը կարող է օգտագործել [`peek`] ՝ դիտելու կրկնիչի հաջորդ տարրը ՝ առանց այն սպառելու:
    ///
    /// [`peek`] եղանակը ավելացնում է կրկնիչի: Լրացուցիչ տեղեկությունների համար տես դրա փաստաթղթերը:
    ///
    /// Նկատի ունեցեք, որ հիմքում ընկած կրկնիչը դեռ զարգացած է, երբ [`peek`]-ն առաջին անգամ է կանչվում. Հաջորդ տարրը վերականգնելու համար [`next`]-ը կանչվում է հիմքում ընկած կրկնիչի, հետևաբար ցանկացած կողմնակի ազդեցության (այսինքն
    ///
    /// տեղի կունենա [`next`] մեթոդի հաջորդ արժեքը վերցնելուց բացի այլ բան):
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() թույլ տանք տեսնել future-ը
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // մենք կարող ենք մի քանի անգամ peek(), կրկնիչը չի առաջ շարժվում
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // կրկնիչը ավարտելուց հետո peek()-ը նույնպես
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Ստեղծում է կրկնիչ, որը [`բաց թողնել]] տարրերը, կազմված է նախադրյալի հիման վրա:
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` որպես փաստարկ վերցնում է փակումը: Այն կանչելու է այս փակումը կրկնիչի յուրաքանչյուր տարրի վրա և անտեսելու է տարրերը մինչև այն վերադարձնի `false`:
    ///
    /// `false`-ի վերադարձից հետո `skip_while()`'s աշխատանքն ավարտվում է, և մնացած տարրերը բերվում են:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Քանի որ `skip_while()`-ին փոխանցված փակումը հղում է կատարում, և շատ կրկնիչներ կրկնում են հղումները, դա հանգեցնում է հնարավոր խառնաշփոթ իրավիճակի, երբ փակման փաստարկի տեսակը կրկնակի հղում է.
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // հարկավոր է երկու *
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Կանգառում նախնական `false`-ից հետո.
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // չնայած սա կեղծ կլիներ, քանի որ մենք արդեն ստացանք կեղծիք, skip_while()-ն այլևս չի օգտագործվում
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Ստեղծում է iterator, որը տալիս է տարրեր ՝ հիմնված մի նախադրյալի վրա:
    ///
    /// `take_while()` որպես փաստարկ վերցնում է փակումը: Այն կկոչի այս փակումը կրկնիչի յուրաքանչյուր տարրի վրա և կտա տարրեր, մինչդեռ այն վերադարձնում է `true`:
    ///
    /// `false`-ի վերադարձից հետո `take_while()`'s աշխատանքն ավարտված է, և մնացած տարրերն անտեսվում են:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Քանի որ `take_while()`-ին փոխանցված փակումը հղում է կատարում, և շատ կրկնիչներ կրկնում են հղումները, դա հանգեցնում է հնարավոր խառնաշփոթ իրավիճակի, երբ փակման տեսակը կրկնակի հղում է.
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // հարկավոր է երկու *
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Կանգառում նախնական `false`-ից հետո.
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Մենք ունենք ավելի շատ տարրեր, որոնք զրոյից պակաս են, բայց քանի որ մենք արդեն ստացանք կեղծիք, take_while()-ն այլևս չի օգտագործվում
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Քանի որ `take_while()`-ը պետք է ուսումնասիրի այդ արժեքը ՝ տեսնելու համար, արդյոք այն պետք է ներառվի, թե ոչ, սպառող կրկնիչները կտեսնեն, որ այն հանվել է.
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3`-ն այլևս չկա, քանի որ այն սպառվել է ՝ տեսնելու համար արդյոք կրկնությունը պետք է դադարեցվի, բայց այն կրկին չի դրվել կրկնիչի մեջ:
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Ստեղծում է կրկնիչ, որը և՛ տալիս է տարրեր ՝ հիմնվելով մի պնդիչի, և՛ քարտեզի վրա:
    ///
    /// `map_while()` որպես փաստարկ վերցնում է փակումը:
    /// Այն կկոչի այս փակումը կրկնիչի յուրաքանչյուր տարրի վրա և կտա տարրեր, մինչդեռ այն վերադարձնում է [`Some(_)`][`Some`]:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ահա նույն օրինակը, բայց [`take_while`]-ի և [`map`]-ի հետ.
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Կանգառում նախնական [`None`]-ից հետո.
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Մենք ունենք ավելի շատ տարրեր, որոնք կարող են տեղավորվել u32-ում (4, 5), բայց `map_while`-ը վերադարձրել է `None`-ը `-3`-ի համար (քանի որ `predicate`-ը վերադարձրել է `None`) և `collect` կանգառներ `հանդիպած առաջին `None`-ում:
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Քանի որ `map_while()`-ը պետք է ուսումնասիրի այդ արժեքը ՝ տեսնելու համար, արդյոք այն պետք է ներառվի, թե ոչ, սպառող կրկնիչները կտեսնեն, որ այն հանվել է.
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3`-ն այլևս չկա, քանի որ այն սպառվել է ՝ տեսնելու համար արդյոք կրկնությունը պետք է դադարեցվի, բայց այն կրկին չի դրվել կրկնիչի մեջ:
    ///
    /// Նշենք, որ ի տարբերություն [`take_while`]-ի, այս կրկնիչը ** միացված չէ:
    /// Նշված չէ նաև, թե ինչ է վերադարձնում այս կրկնիչը առաջին [`None`]-ը վերադարձնելուց հետո:
    /// Եթե ձեզ հարկավոր է միաձուլված կրկնիչ, օգտագործեք [`fuse`]:
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Ստեղծում է կրկնիչ, որը բաց է թողնում առաջին `n` տարրերը:
    ///
    /// Դրանք սպառելուց հետո մնացած տարրերը դուրս են բերվում:
    /// Փոխանակ ուղղակիորեն գերակշռելու այս մեթոդը, փոխարենը գերադասեք `nth` մեթոդը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Ստեղծում է կրկնիչ, որը տալիս է իր առաջին `n` տարրերը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` հաճախ օգտագործվում է անսահման կրկնիչի հետ ՝ այն վերջնական դարձնելու համար.
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Եթե `n`-ից պակաս տարրեր մատչելի են, `take`-ն իրեն կսահմանափակի միայն հիմքում ընկած կրկնիչի չափով.
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`]-ի նման կրկնիչի ադապտեր, որն ունի ներքին վիճակ և ստեղծում է նոր կրկնիչ:
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` վերցնում է երկու փաստարկ. նախնական արժեքը, որը սերմնավորում է ներքին վիճակը և փակումը երկու փաստարկով. առաջինը փոփոխական հղում է ներքին վիճակին, իսկ երկրորդը ՝ կրկնիչի տարր:
    ///
    /// Փակումը կարող է վերագրվել ներքին վիճակին ՝ պետությունը բաժանելու կրկնությունների միջև:
    ///
    /// Կրկնման ժամանակ փակումը կկիրառվի կրկնիչի յուրաքանչյուր տարրի վրա, և փակումից վերադարձվող արժեքը ՝ [`Option`], տալիս է կրկնիչը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // յուրաքանչյուր կրկնություն, մենք կբազմապատկենք պետությունը տարրով
    ///     *state = *state * x;
    ///
    ///     // ապա մենք կտանք պետության ժխտումը
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Ստեղծում է iterator, որն աշխատում է քարտեզի պես, բայց հարթեցնում է տեղադրված կառուցվածքը:
    ///
    /// [`map`] ադապտերը շատ օգտակար է, բայց միայն այն դեպքում, երբ փակման փաստարկը արժեքներ է տալիս:
    /// Եթե դրա փոխարեն առաջացնում է կրկնիչ, ապա կա անուղղակիության լրացուցիչ շերտ:
    /// `flat_map()` ինքնուրույն կհեռացնի այս լրացուցիչ շերտը:
    ///
    /// Դուք կարող եք `flat_map(f)`-ը համարել որպես [«քարտեզ»] ping-ի իմաստային համարժեք, այնուհետև [«հարթեցնել»], ինչպես `map(f).flatten()`-ում:
    ///
    /// `flat_map()`-ի մասին մտածելու մեկ այլ եղանակ. [«Քարտեզի» փակումը վերադարձնում է մեկ տարր յուրաքանչյուր տարրի համար, իսկ `flat_map()`'s փակումը վերադարձնում է կրկնիչ յուրաքանչյուր տարրի համար:
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() վերադառնում է կրկնիչ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Ստեղծում է կրկնիչ, որը հարթեցնում է բնադրված կառուցվածքը:
    ///
    /// Սա օգտակար է, երբ դուք ունեք կրկնիչների կրկնիչ կամ այն բաների կրկնիչ, որոնք կարող են վերափոխիչ դառնալ, և ցանկանում եք հեռացնել անուղղակիության մեկ մակարդակից:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Քարտեզագրում և այնուհետեւ հավասարեցում.
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() վերադառնում է կրկնիչ
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Կարող եք նաև սա վերաշարադրել [`flat_map()`]-ի տեսանկյունից, որն այս դեպքում նախընտրելի է, քանի որ այն ավելի հստակ է փոխանցում մտադրությունը.
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() վերադառնում է կրկնիչ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Հարթեցումը միանգամից հեռացնում է միայն մեկ մակարդակի բնադրումը.
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Այստեղ մենք տեսնում ենք, որ `flatten()`-ը չի կատարում "deep" հարթեցում:
    /// Փոխարենը, բնադրման միայն մեկ մակարդակը հանվում է: Այսինքն, եթե `flatten()` եք եռաչափ զանգված, արդյունքը կլինի երկչափ, այլ ոչ թե միաչափ:
    /// Միաչափ կառուցվածք ստանալու համար պետք է նորից `flatten()`:
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Ստեղծում է կրկնիչ, որն ավարտվում է առաջին [`None`]-ից հետո:
    ///
    /// Կատարողի կրկնօրինակը [`None`] վերադառնալուց հետո future զանգերը կարող են [`Some(T)`] նորից տալ կամ չհանգեցնել:
    /// `fuse()` հարմարեցնում է կրկնիչը ՝ ապահովելով, որ [`None`] տալուց հետո այն միշտ վերադարձնի [`None`] ընդմիշտ:
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// // կրկնիչ, որը փոխարինվում է ոմանց և ոչ մեկի միջև
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // եթե դա նույնիսկ, Some(i32), այլ ոչ մեկը
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // մենք կարող ենք տեսնել, թե ինչպես է մեր կրկնիչը գնում-գալիս
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // այնուամենայնիվ, հենց որ այն միաձուլենք ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // այն միշտ կվերադառնա `None` առաջին անգամից հետո:
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Ինչ-որ բան կատարում է կրկնիչի յուրաքանչյուր տարրով `փոխանցելով արժեքը:
    ///
    /// Կրկնիչներից օգտվելիս հաճախ դրանցից մի քանիսը կապում եք միասին:
    /// Նման կոդի վրա աշխատելիս գուցե ցանկանաք ստուգել, թե ինչ է կատարվում գազատարի տարբեր մասերում: Դա անելու համար զանգահարեք `inspect()`:
    ///
    /// Ավելի տարածված է, որ `inspect()`-ն օգտագործվի որպես կարգաբերման միջոց, քան գոյություն ունենա ձեր վերջնական ծածկագրում, բայց ծրագրերը դա կարող են օգտակար համարել որոշակի իրավիճակներում, երբ նախքան մերժելը անհրաժեշտ է սխալներ մուտքագրել:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // այս կրկնիչի հաջորդականությունը բարդ է:
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // եկեք ավելացնենք մի քանի inspect() զանգ ՝ ուսումնասիրելու, թե ինչ է կատարվում
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Սա կտպագրի ՝
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Անտառահատման սխալները նախքան դրանք մերժելը.
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Սա կտպագրի ՝
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Խստացնում է կրկնիչը, այլ ոչ թե սպառում այն:
    ///
    /// Սա օգտակար է թույլատրելու համար կիրառել կրկնիչի ադապտերներ ՝ միևնույն ժամանակ պահպանելով սկզբնական կրկնիչի սեփականությունը:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // եթե մենք նորից փորձենք օգտագործել iter, դա չի ստացվի:
    /// // Հետևյալ տողը տալիս է «սխալ. Տեղափոխված արժեքի օգտագործում. `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // եկեք նորից փորձենք դա
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // փոխարենը մենք ավելացնում ենք .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // հիմա սա շատ լավ է.
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Վերափոխիչը վերափոխում է հավաքածուի:
    ///
    /// `collect()` կարող է վերցնել ցանկացած խոցելի բան և վերածել այն համապատասխան հավաքածուի:
    /// Սա ստանդարտ գրադարանի առավել հզոր մեթոդներից մեկն է, որն օգտագործվում է տարբեր համատեքստերում:
    ///
    /// `collect()`-ի օգտագործման ամենահիմնական օրինաչափությունը մի հավաքածուն մյուսի վերածելն է:
    /// Դուք վերցնում եք հավաքածու, զանգահարում դրա վրա [`iter`], կատարում եք մի շարք վերափոխումներ, իսկ վերջում `collect()`:
    ///
    /// `collect()` կարող է նաև ստեղծել այնպիսի տեսակների օրինակներ, որոնք բնորոշ հավաքածուներ չեն:
    /// Օրինակ, [`String`]-ը կարելի է կառուցել [`char`]-ից, իսկ [`Result<T, E>`][`Result`] տարրերի կրկնիչը կարող է հավաքվել `Result<Collection<T>, E>`-ի մեջ:
    ///
    /// Տե՛ս ստորև բերված օրինակները ՝ ավելին:
    ///
    /// Քանի որ `collect()`-ն այնքան ընդհանուր է, դա կարող է խնդիրներ առաջացնել տիպի եզրակացության հետ կապված:
    /// Որպես այդպիսին, `collect()`-ը այն եզակի դեպքերից մեկն է, երբ կտեսնեք շարահյուսությունը սիրով հայտնի որպես 'turbofish': `::<>`.
    /// Սա օգնում է եզրակացության ալգորիթմին հասկանալ, թե հատկապես որ հավաքածուն եք փորձում հավաքել:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Նշենք, որ մեզ անհրաժեշտ էր ձախ կողմում գտնվող `: Vec<i32>`-ը: Սա այն պատճառով է, որ մենք փոխարենը կարող ենք հավաքել, օրինակ, [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// X001 ծանոթագրության փոխարեն օգտագործելով 'turbofish':
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Քանի որ `collect()`-ը մտածում է միայն այն մասին, թե ինչ եք հավաքում, դուք դեռ կարող եք օգտագործել մասնակի տիպի ակնարկ `_`, տուրբոֆիլի հետ միասին.
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()`-ի միջոցով [`String`]-ը պատրաստելու համար.
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Եթե ունեք [«Արդյունք<T, E>`][« Արդյունք »] s, դուք կարող եք օգտագործել `collect()` տեսնելու համար, արդյոք դրանցից որևէ մեկը ձախողվել է.
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // տալիս է մեզ առաջին սխալը
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // տալիս է մեզ պատասխանների ցուցակը
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Սպառում է կրկնիչը ՝ ստեղծելով դրանից երկու հավաքածու:
    ///
    /// `partition()`-ին անցած պրեդիկատը կարող է վերադարձնել `true` կամ `false`:
    /// `partition()` վերադարձնում է մի զույգ, բոլոր տարրերը, որոնց համար վերադարձրել է `true`, և բոլոր տարրերը, որոնց համար վերադարձրել է `false`:
    ///
    ///
    /// Տես նաև [`is_partitioned()`] և [`partition_in_place()`]:
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Այս կրկնիչի տարրերը * տեղում տեղադրում է ըստ տրված նախադրյալի, այնպես, որ բոլոր նրանք, ովքեր `true` են վերադարձնում, նախորդում են բոլոր նրանց, ովքեր վերադարձնում են `false`:
    ///
    /// Վերադարձնում է գտնված `true` տարրերի քանակը:
    ///
    /// Բաժանված իրերի հարաբերական կարգը չի պահպանվում:
    ///
    /// Տես նաև [`is_partitioned()`] և [`partition()`]:
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Տեղաբաշխում տեղում հավասար և հավանականության միջև
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: արդյո՞ք պետք է անհանգստանանք, որ հաշվարկը հորդանաԱվելին, քան ունենալու միակ միջոցը
        // `usize::MAX` փոփոխական հղումները ZST-ների հետ են, որոնք բաժանման համար օգտակար չեն ...

        // "factory" փակման այս գործառույթները գոյություն ունեն `Self`-ում առատաձեռնությունից խուսափելու համար:

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Կրկնեք գտեք առաջին `false`-ը և փոխեք այն վերջին `true`-ի հետ:
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Ստուգում է, արդյոք այս կրկնիչի տարրերը բաժանված են ըստ տրված նախադրյալի, այնպես, որ `true` վերադարձող բոլորները նախորդեն բոլոր `false` վերադարձողներին:
    ///
    ///
    /// Տես նաև [`partition()`] և [`partition_in_place()`]:
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Կամ բոլոր տարրերը ստուգում են `true`-ը, կամ առաջին կետը դադարում է `false`-ում, և մենք ստուգում ենք, որ դրանից հետո այլևս `true` կետ չկա:
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Իտերատոր մեթոդը, որը գործառույթ է կիրառում, քանի դեռ այն հաջողությամբ վերադառնում է ՝ արտադրելով մեկ, վերջնական արժեք:
    ///
    /// `try_fold()` վերցնում է երկու փաստարկ. նախնական արժեք և փակում երկու փաստարկով. 'accumulator' և տարր:
    /// Փակումը կամ հաջողությամբ վերադառնում է, այն արժեքով, որը կուտակիչը պետք է ունենա հաջորդ կրկնության համար, կամ վերադառնում է ձախողում ՝ սխալի արժեքով, որը տարածվում է անմիջապես (short-circuiting) զանգահարողին:
    ///
    ///
    /// Նախնական արժեքն այն արժեքն է, որը կուտակիչը կունենա առաջին զանգի ժամանակ: Եթե փակումը կիրառելը հաջողվեց կրկնիչի յուրաքանչյուր տարրի դեմ, `try_fold()`-ը վերջնական կուտակիչը վերադարձնում է որպես հաջողություն:
    ///
    /// Փեղկավորումը օգտակար է, երբ որևէ բանի հավաքածու ունեք, և ուզում եք դրանից մեկ արժեք արտադրել:
    ///
    /// # Նշում իրականացնողներին
    ///
    /// (forward)-ի մի քանի այլ մեթոդներ ունեն լռելյայն ներդրումներ այս մեկի առումով, այնպես որ փորձեք իրականացնել սա հստակ, եթե այն կարող է ավելի լավ բան անել, քան լռելյայն `for` հանգույցի իրականացումը:
    ///
    /// Մասնավորապես, փորձեք ունենալ այս զանգը `try_fold()` այն ներքին մասերի վրա, որոնցից կազմված է այս կրկնիչը:
    /// Եթե բազմաթիվ զանգեր են անհրաժեշտ, `?` օպերատորը կարող է հարմար լինել կուտակիչի արժեքը շղթայակցելու համար, բայց զգուշացեք ցանկացած անփոփոխությունից, որոնք անհրաժեշտ է պահպանել մինչ այդ վաղ վերադարձը:
    /// Սա `&mut self` մեթոդ է, ուստի կրկնությունը պետք է վերսկսվի ՝ այստեղ սխալ թույլ տալուց հետո:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // զանգվածի բոլոր տարրերի ստուգված գումարը
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Այս գումարը լցվում է 100 տարրը ավելացնելիս
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Քանի որ այն կարճ միացվեց, մնացած տարրերը դեռ հասանելի են կրկնիչի միջոցով:
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Կրկնիչի մեթոդ, որը կիրառվում է կրկնվող գործառույթի յուրաքանչյուր կետի վրա ընկալելի գործառույթ `կանգ առնելով առաջին սխալի վրա և վերադարձնելով այդ սխալը:
    ///
    ///
    /// Սա կարելի է նաև համարել որպես [`for_each()`]-ի խորտակվող ձև կամ [`try_fold()`]-ի քաղաքացիություն չունեցող տարբերակ:
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Այն կարճ միացվեց, ուստի մնացած իրերը դեռ գտնվում են կրկնիչի մեջ.
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Elementալում է յուրաքանչյուր տարրը կուտակիչի մեջ ՝ կիրառելով գործողություն ՝ վերադարձնելով վերջնական արդյունքը:
    ///
    /// `fold()` վերցնում է երկու փաստարկ. նախնական արժեք և փակում երկու փաստարկով. 'accumulator' և տարր:
    /// Փակումը վերադարձնում է այն արժեքը, որը կուտակիչը պետք է ունենա հաջորդ կրկնության համար:
    ///
    /// Նախնական արժեքն այն արժեքն է, որը կուտակիչը կունենա առաջին զանգի ժամանակ:
    ///
    /// Այս փակումը կրկնիչի յուրաքանչյուր տարրի վրա կիրառելուց հետո `fold()`-ը վերադարձնում է կուտակիչը:
    ///
    /// Այս գործողությունը երբեմն կոչվում է 'reduce' կամ 'inject':
    ///
    /// Փեղկավորումը օգտակար է, երբ որևէ բանի հավաքածու ունեք, և ուզում եք դրանից մեկ արժեք արտադրել:
    ///
    /// Note: `fold()`-ը և նմանատիպ մեթոդները, որոնք անցնում են ամբողջ կրկնիչը, կարող են չվերջանալ անվերջ կրկնիչների համար, նույնիսկ traits-ի վրա, որի արդյունքը որոշելի է վերջավոր ժամանակում:
    ///
    /// Note: [`reduce()`]-ը կարող է օգտագործվել առաջին տարրը որպես նախնական արժեք օգտագործելու համար, եթե կուտակիչի տեսակն ու իրի տեսակը նույնն են:
    ///
    /// # Նշում իրականացնողներին
    ///
    /// (forward)-ի մի քանի այլ մեթոդներ ունեն լռելյայն ներդրումներ այս մեկի առումով, այնպես որ փորձեք իրականացնել սա հստակ, եթե այն կարող է ավելի լավ բան անել, քան լռելյայն `for` հանգույցի իրականացումը:
    ///
    ///
    /// Մասնավորապես, փորձեք ունենալ այս զանգը `fold()` այն ներքին մասերի վրա, որոնցից կազմված է այս կրկնիչը:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // զանգվածի բոլոր տարրերի հանրագումարը
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Եկեք գնանք այստեղ կրկնության յուրաքանչյուր աստիճանի միջոցով.
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Եվ այսպես, մեր վերջնական արդյունքը, `6`.
    ///
    /// Մարդիկ, ովքեր կրկնօրինակներ շատ չեն օգտագործել, սովորական են, որ օգտագործում են `for` օղակ ՝ իրերի ցանկով ՝ արդյունք հավաքելու համար: Դրանք կարող են վերածվել `fold()`s-ի.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // հանգույցի համար.
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // դրանք նույնն են
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Կրճատում է տարրերը մեկին `բազմիցս կիրառելով նվազեցման գործողություն:
    ///
    /// Եթե կրկնիչը դատարկ է, ապա վերադարձնում է [`None`];հակառակ դեպքում վերադարձնում է կրճատման արդյունքը:
    ///
    /// Գոնե մեկ տարր ունեցող կրկնիչների համար սա նույնն է, ինչ [`fold()`]-ը կրկնիչի առաջին տարրով `որպես նախնական արժեք, յուրաքանչյուր հաջորդ տարրը ծալելով մեջը:
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Գտեք առավելագույն արժեքը.
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Փորձարկումներ, եթե կրկնիչի յուրաքանչյուր տարր համընկնում է մի նախդիրի հետ:
    ///
    /// `all()` վերցնում է փակումը, որը վերադարձնում է `true` կամ `false`: Այն կիրառում է այս փակումը կրկնիչի յուրաքանչյուր տարրի նկատմամբ, և եթե բոլորը վերադարձնում են `true`, ապա դա անում է նաև `all()`:
    /// Եթե նրանցից որևէ մեկը վերադարձնի `false`, այն վերադարձնում է `false`:
    ///
    /// `all()` կարճ միացում է;այլ կերպ ասած, այն կդադարի մշակել հենց որ գտնի `false`, հաշվի առնելով, որ ինչ էլ որ պատահի, արդյունքը կլինի նաև `false`:
    ///
    ///
    /// Դատարկ կրկնիչը վերադարձնում է `true`:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Կանգ առնելով առաջին `false`-ին ՝
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // մենք դեռ կարող ենք օգտագործել `iter`, քանի որ կան էլեմենտներ:
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Փորձարկումներ, եթե կրկնիչի որևէ տարր համընկնում է նախդիրի հետ:
    ///
    /// `any()` վերցնում է փակումը, որը վերադարձնում է `true` կամ `false`: Այն կիրառում է այս փակումը կրկնիչի յուրաքանչյուր տարրի նկատմամբ, և եթե նրանցից որևէ մեկը վերադարձնի `true`, ապա դա անում է նաև `any()`:
    /// Եթե բոլորը վերադարձնում են `false`, ապա այն վերադարձնում է `false`:
    ///
    /// `any()` կարճ միացում է;այլ կերպ ասած, այն կդադարի մշակել հենց որ գտնի `true`, հաշվի առնելով, որ ինչ էլ որ պատահի, արդյունքը կլինի նաև `true`:
    ///
    ///
    /// Դատարկ կրկնիչը վերադարձնում է `false`:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Կանգ առնելով առաջին `true`-ին ՝
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // մենք դեռ կարող ենք օգտագործել `iter`, քանի որ կան էլեմենտներ:
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Կատարյալի բավարարող կրկնիչի տարր է որոնում:
    ///
    /// `find()` վերցնում է փակումը, որը վերադարձնում է `true` կամ `false`:
    /// Այն կիրառում է այս փակումը կրկնիչի յուրաքանչյուր տարրի նկատմամբ, և եթե նրանցից որևէ մեկը վերադարձնի `true`, ապա `find()` վերադարձնում է [`Some(element)`]:
    /// Եթե բոլորը վերադարձնում են `false`, ապա այն վերադարձնում է [`None`]:
    ///
    /// `find()` կարճ միացում է;այլ կերպ ասած, այն կդադարեցնի վերամշակումը հենց փակումը վերադառնա `true`:
    ///
    /// Քանի որ `find()`-ը հղում է վերցնում, և շատ կրկնիչներ կրկնում են հղումները, դա հանգեցնում է հնարավոր խառնաշփոթ իրավիճակի, երբ փաստարկը կրկնակի հղում է:
    ///
    /// Այս ազդեցությունը կարող եք տեսնել ստորև բերված օրինակներում, `&&x`-ի հետ:
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Կանգ առնելով առաջին `true`-ին ՝
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // մենք դեռ կարող ենք օգտագործել `iter`, քանի որ կան էլեմենտներ:
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Նշենք, որ `iter.find(f)` համարժեք է `iter.filter(f).next()`-ին:
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Կիրառում է գործառույթը կրկնիչի տարրերին և վերադարձնում է առաջին ոչ մի արդյունքը:
    ///
    ///
    /// `iter.find_map(f)` համարժեք է `iter.filter_map(f).next()`-ին:
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Կիրառում է ֆունկցիան կրկնիչի տարրերին և վերադարձնում է առաջին իսկական արդյունքը կամ առաջին սխալը:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Իտերատորի մեջ տարր է որոնում ՝ վերադարձնելով իր ցուցանիշը:
    ///
    /// `position()` վերցնում է փակումը, որը վերադարձնում է `true` կամ `false`:
    /// Այն կիրառում է այս փակումը կրկնիչի յուրաքանչյուր տարրի նկատմամբ, և եթե դրանցից մեկը վերադարձնում է `true`, ապա `position()` վերադարձնում է [`Some(index)`]:
    /// Եթե բոլորը վերադարձնում են `false`, ապա այն վերադարձնում է [`None`]:
    ///
    /// `position()` կարճ միացում է;այլ կերպ ասած, այն կդադարի մշակել հենց որ գտնի `true`:
    ///
    /// # Հորդառատ վարք
    ///
    /// Մեթոդը չի պաշտպանում վարարումները, այնպես որ եթե կան [`usize::MAX`]-ից ավելի չհամընկնող տարրեր, այն կա՛մ սխալ արդյունք է տալիս, կա՛մ panics:
    ///
    /// Եթե վրիպազերծման պնդումները միացված են, panic-ն երաշխավորված է:
    ///
    /// # Panics
    ///
    /// Այս գործառույթը կարող է լինել panic, եթե կրկնիչը ունի `usize::MAX`-ից ավելի ոչ համապատասխան տարրեր:
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Կանգ առնելով առաջին `true`-ին ՝
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // մենք դեռ կարող ենք օգտագործել `iter`, քանի որ կան էլեմենտներ:
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Վերադարձված ինդեքսը կախված է կրկնիչի վիճակից
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Աջից հետադարձողի մեջ տարր է որոնում ՝ վերադարձնելով իր ցուցանիշը:
    ///
    /// `rposition()` վերցնում է փակումը, որը վերադարձնում է `true` կամ `false`:
    /// Այն կիրառում է այս փակումը կրկնիչի յուրաքանչյուր տարրի նկատմամբ, սկսած վերջից, և եթե նրանցից մեկը վերադարձնում է `true`, ապա `rposition()` վերադարձնում է [`Some(index)`]:
    ///
    /// Եթե բոլորը վերադարձնում են `false`, ապա այն վերադարձնում է [`None`]:
    ///
    /// `rposition()` կարճ միացում է;այլ կերպ ասած, այն կդադարի մշակել հենց որ գտնի `true`:
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Կանգ առնելով առաջին `true`-ին ՝
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // մենք դեռ կարող ենք օգտագործել `iter`, քանի որ կան էլեմենտներ:
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Այստեղ ավելորդ հոսքի ստուգման կարիք չկա, քանի որ `ExactSizeIterator` ենթադրում է, որ տարրերի քանակը տեղավորվում է `usize`-ի մեջ:
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Վերադարձնում է կրկնիչի առավելագույն տարրը:
    ///
    /// Եթե մի քանի տարր հավասարապես առավելագույն են, ապա վերջին տարրը վերադարձվում է:
    /// Եթե կրկնիչը դատարկ է, [`None`]-ը վերադարձվում է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Վերադարձնում է կրկնիչի նվազագույն տարրը:
    ///
    /// Եթե մի քանի տարրեր հավասարապես նվազագույն են, ապա առաջին տարրը վերադարձվում է:
    /// Եթե կրկնիչը դատարկ է, [`None`]-ը վերադարձվում է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Վերադարձնում է այն տարրը, որը տալիս է առավելագույն արժեքը նշված գործառույթից:
    ///
    ///
    /// Եթե մի քանի տարր հավասարապես առավելագույն են, ապա վերջին տարրը վերադարձվում է:
    /// Եթե կրկնիչը դատարկ է, [`None`]-ը վերադարձվում է:
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Վերադարձնում է այն տարրը, որը տալիս է առավելագույն արժեք ՝ նշված համեմատության գործառույթի նկատմամբ:
    ///
    ///
    /// Եթե մի քանի տարր հավասարապես առավելագույն են, ապա վերջին տարրը վերադարձվում է:
    /// Եթե կրկնիչը դատարկ է, [`None`]-ը վերադարձվում է:
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Վերադարձնում է այն տարրը, որը տալիս է նվազագույն արժեքը նշված գործառույթից:
    ///
    ///
    /// Եթե մի քանի տարրեր հավասարապես նվազագույն են, ապա առաջին տարրը վերադարձվում է:
    /// Եթե կրկնիչը դատարկ է, [`None`]-ը վերադարձվում է:
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Վերադարձնում է այն տարրը, որը տալիս է նվազագույն մեծություն նշված համեմատության գործառույթի նկատմամբ:
    ///
    ///
    /// Եթե մի քանի տարրեր հավասարապես նվազագույն են, ապա առաջին տարրը վերադարձվում է:
    /// Եթե կրկնիչը դատարկ է, [`None`]-ը վերադարձվում է:
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Վերափոխում է կրկնիչի ուղղությունը:
    ///
    /// Սովորաբար, կրկնիչները կրկնվում են ձախից աջ:
    /// `rev()`-ը օգտագործելուց հետո կրկնիչը կկրկնվի աջից ձախ:
    ///
    /// Դա հնարավոր է միայն այն դեպքում, եթե կրկնիչի վերջը լինի, ուստի `rev()` աշխատում է միայն [«DoubleEndedIterator»]-երի վրա:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Pairsույգերի կրկնիչը վերածում է զույգի տարաների:
    ///
    /// `unzip()` սպառում է զույգերի մի ամբողջ կրկնիչ ՝ արտադրելով երկու հավաքածու. մեկը զույգերի ձախ տարրերից և մեկը ՝ ճիշտ տարրերից:
    ///
    ///
    /// Այս գործառույթը որոշ իմաստով հակառակն է [`zip`]-ի:
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Ստեղծում է կրկնիչ, որը պատճենում է իր բոլոր տարրերը:
    ///
    /// Սա օգտակար է այն դեպքում, երբ դուք ունեք կրկնապատկեր `&T`-ի վրա, բայց ձեզ անհրաժեշտ է կրկնապատկեր `T`-ով:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // պատճենահանվածը նույնն է, ինչ .map(|&x| x)-ը
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Ստեղծում է կրկնիչ, որը [`կլոնավորում է] իր բոլոր տարրերը:
    ///
    /// Սա օգտակար է այն դեպքում, երբ դուք ունեք կրկնապատկեր `&T`-ի վրա, բայց ձեզ անհրաժեշտ է կրկնապատկեր `T`-ով:
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // կլոնավորվածը նույնն է, ինչ .map(|&x| x)-ը, ամբողջ թվերի համար
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Կրկնում է կրկնիչը անվերջ:
    ///
    /// [`None`]-ում կանգ առնելու փոխարեն, կրկնիչը փոխարենը կսկսի նորից ՝ սկզբից: Կրկին կրկնելուց հետո այն նորից կսկսվի սկզբից:Եւ կրկին.
    /// Եւ կրկին.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Ամփոփում է կրկնիչի տարրերը:
    ///
    /// Վերցնում է յուրաքանչյուր տարր, դրանք միացնում իրար և վերադարձնում արդյունքը:
    ///
    /// Դատարկ կրկնիչը վերադարձնում է տիպի զրոյական արժեքը:
    ///
    /// # Panics
    ///
    /// `sum()` զանգահարելիս և պարզունակ ամբողջ տեսակի տեսակը վերադարձվում է, այս մեթոդը panic կլինի, եթե հաշվարկը գերազանցի և կարգաբերման պնդումները միացված լինեն:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Կրկնում է ամբողջ կրկնիչը, բազմապատկելով բոլոր տարրերը
    ///
    /// Դատարկ կրկնիչը վերադարձնում է տիպի մեկ արժեքը:
    ///
    /// # Panics
    ///
    /// `product()` զանգահարելիս և պարզունակ ամբողջ թվերի տիպը հետ է վերադարձվում, մեթոդը panic-ն է, եթե հաշվարկը գերազանցի և կարգաբերման պնդումները միացված լինեն:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) համեմատում է այս [`Iterator`]-ի տարրերը մյուսի հետ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) նշված [`Iterator`]-ի տարրերը համեմատում է նշված համեմատության գործառույթի հետ:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) համեմատում է այս [`Iterator`]-ի տարրերը մյուսի հետ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) նշված [`Iterator`]-ի տարրերը համեմատում է նշված համեմատության գործառույթի հետ:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Որոշում է, արդյոք այս [`Iterator`]-ի տարրերը հավասար են մյուսի տարրերին:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Որոշում է, արդյոք այս [`Iterator`]-ի տարրերը հավասար են մյուսի տարրերին `նշված հավասարության գործառույթի նկատմամբ:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Որոշում է, արդյոք այս [`Iterator`]-ի տարրերն անհավասար են մյուսի տարրերի հետ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Որոշում է, արդյոք այս [`Iterator`]-ի տարրերը [lexicographically](Ord#lexicographical-comparison)-ով պակաս են, քան մյուսի:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Որոշում է `արդյոք այս [`Iterator`]-ի տարրերը [lexicographically](Ord#lexicographical-comparison)-ով պակաս են կամ հավասար են մյուսի:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Որոշում է, արդյոք այս [`Iterator`]-ի տարրերը [lexicographically](Ord#lexicographical-comparison)-ով ավելի են, քան մյուսի:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Որոշում է `արդյոք այս [`Iterator`]-ի տարրերը [lexicographically](Ord#lexicographical-comparison)-ով մեծ են կամ հավասար են մյուսի:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Ստուգում է, արդյոք այս կրկնիչի տարրերը տեսակավորված են:
    ///
    /// Այսինքն ՝ `a` յուրաքանչյուր տարրի և դրա հետևյալ `b` տարրի համար `a <= b` պետք է պահի: Եթե կրկնիչը տալիս է ուղիղ զրո կամ մեկ տարր, `true`-ը վերադարձվում է:
    ///
    /// Ուշադրություն դարձրեք, որ եթե `Self::Item`-ը միայն `PartialOrd` է, բայց ոչ `Ord`, վերը նշված սահմանումը ենթադրում է, որ այս գործառույթը վերադարձնում է `false`, եթե որևէ երկու անընդմեջ տարրեր համեմատելի չեն:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Ստուգում է `արդյոք այս կրկնիչի տարրերը տեսակավորված են` օգտագործելով տրված համեմատիչ գործառույթը:
    ///
    /// `PartialOrd::partial_cmp`-ի օգտագործման փոխարեն, այս ֆունկցիան օգտագործում է տրված `compare` գործառույթը `որոշելու երկու տարրերի դասավորությունը:
    /// Բացի այդ, դա համարժեք է [`is_sorted`]-ին.տե՛ս դրա փաստաթղթերը ՝ լրացուցիչ տեղեկությունների համար:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Ստուգում է, արդյոք այս կրկնիչի տարրերը տեսակավորված են ՝ օգտագործելով տրված ստեղների արդյունահանման ֆունկցիան:
    ///
    /// Փոխանակ կրկնիչի տարրերն ուղղակիորեն համեմատելու, այս ֆունկցիան համեմատում է տարրերի բանալիները, ինչպես որոշված է `f`-ի կողմից:
    /// Բացի այդ, դա համարժեք է [`is_sorted`]-ին.տե՛ս դրա փաստաթղթերը ՝ լրացուցիչ տեղեկությունների համար:
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Տե՛ս [TrustedRandomAccess]
    // Արտասովոր անվանումն է `խուսափել անունների բախումներից մեթոդի լուծման վրա տե՛ս #76479:
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}