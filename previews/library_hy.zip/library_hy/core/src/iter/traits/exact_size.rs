/// Իտերատոր, որը գիտի դրա ճշգրիտ երկարությունը:
///
/// Շատերը [«Iterator»-ը չգիտեն, թե քանի անգամ են կրկնվելու, բայց ոմանք դա անում են:
/// Եթե կրկնիչը գիտի, թե քանի անգամ կարող է կրկնել, այդ տեղեկատվության հասանելիության ապահովումը կարող է օգտակար լինել:
/// Օրինակ, եթե ուզում եք հետընթաց կրկնել, լավ սկիզբ է իմանալ, թե որտեղ է ավարտը:
///
/// `ExactSizeIterator`-ն իրականացնելիս պետք է նաև իրականացնել [`Iterator`]:
/// Դա անելիս [`Iterator::size_hint`]*-ի իրականացումը պետք է* վերադարձնի կրկնիչի ճշգրիտ չափը:
///
/// [`len`] մեթոդը ունի լռելյայն իրականացում, այնպես որ սովորաբար չպետք է այն իրականացնեք:
/// Այնուամենայնիվ, դուք կարող եք ի վիճակի լինել ապահովել ավելի կատարողական իրականացում, քան լռելյայնը, այնպես որ այս դեպքում գերադասելը իմաստ ունի:
///
///
/// Նշենք, որ այս trait-ն անվտանգ trait է և, որպես այդպիսին,*չի* և *չի կարող* երաշխավորել վերադարձված երկարության ճիշտ լինելը:
/// Սա նշանակում է, որ `unsafe` կոդը **չպետք է** ապավինի [`Iterator::size_hint`]-ի ճիշտությանը:
/// Անկայուն և անվտանգ [`TrustedLen`](super::marker::TrustedLen) trait-ը տալիս է այս լրացուցիչ երաշխիքը:
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// // վերջավոր տիրույթը հստակ գիտի, թե քանի անգամ է կրկնելու
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]-ում մենք իրականացրեցինք [`Iterator`], `Counter`.
/// Եկեք դրա համար `ExactSizeIterator`-ն էլ իրականացնենք.
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Մենք կարող ենք հեշտությամբ հաշվարկել կրկնությունների մնացած քանակը:
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Եվ հիմա մենք կարող ենք օգտագործել այն:
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Վերադարձնում է կրկնիչի ճշգրիտ երկարությունը:
    ///
    /// Իրականացումը երաշխավորում է, որ կրկնիչը կվերադարձնի [`Some(T)`] արժեքից ավելի անգամ `len()` անգամ, նախքան [`None`] վերադարձնելը:
    ///
    /// Այս մեթոդը ունի լռելյայն իրականացում, այնպես որ սովորաբար այն ուղղակիորեն չպետք է իրականացնեք:
    /// Այնուամենայնիվ, եթե կարողանաք ավելի արդյունավետ իրականացում ապահովել, ապա կարող եք դա անել:
    /// Տե՛ս [trait-level] փաստաթղթերը մի օրինակի համար:
    ///
    /// Այս գործառույթը ունի նույն անվտանգության երաշխիքները, ինչ [`Iterator::size_hint`] գործառույթը:
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// // վերջավոր տիրույթը հստակ գիտի, թե քանի անգամ է կրկնելու
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Այս պնդումը չափազանց պաշտպանողական է, բայց ստուգում է անփոփոխը
        // երաշխավորված է trait-ի կողմից:
        // Եթե այս trait-ը լիներ rust-ներքին, մենք կարող ենք օգտագործել debug_assert !;պնդել_eq!կստուգի նաև Rust օգտագործողի բոլոր իրականացումները:
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Վերադառնում է `true`, եթե կրկնիչը դատարկ է:
    ///
    /// Այս մեթոդը ունի լռելյայն իրականացում ՝ օգտագործելով [`ExactSizeIterator::len()`], ուստի անհրաժեշտ չէ այն ինքներդ իրականացնել:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}