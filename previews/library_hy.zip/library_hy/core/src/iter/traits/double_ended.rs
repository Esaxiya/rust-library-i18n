use crate::ops::{ControlFlow, Try};

/// Կրկնիչ, որն ունակ է տարրեր տալ երկու ծայրերից:
///
/// Ինչ-որ բան, որն իրականացնում է `DoubleEndedIterator`, ունի մեկ լրացուցիչ հնարավորություն [`Iterator`]-ի իրագործման նկատմամբ. Հետևից, ինչպես նաև առջևից `« Նյութը »վերցնելու կարողությունը:
///
///
/// Կարևոր է նշել, որ և՛ հետ, և՛ մյուսը աշխատում են նույն տիրույթում և չեն անցնում: կրկնությունն ավարտվում է, երբ դրանք հանդիպում են մեջտեղում:
///
/// [`Iterator`] արձանագրության նման ձևով, մի անգամ `DoubleEndedIterator`-ը [`next_back()`]-ից վերադարձնում է [`None`] ՝ զանգահարելով այն նորից, կարող է և չվերադարձնել [`Some`]:
/// [`next()`] և [`next_back()`]-ն այս նպատակով փոխարինելի են:
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Հիմնական օգտագործում:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Հեռացնում և վերադարձնում է մի տարր կրկնիչի վերջից:
    ///
    /// Վերադարձնում է `None`, երբ այլևս տարրեր չկան:
    ///
    /// [trait-level] փաստաթղթերը պարունակում են ավելի մանրամասն:
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// «DoubleEndedIterator»-ի մեթոդներով ստացված տարրերը կարող են տարբերվել [«Iterator»]-ի մեթոդների բերածներից.
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Իտերատորը առաջ է տանում `n` տարրերով:
    ///
    /// `advance_back_by` [`advance_by`]-ի հակառակ տարբերակն է: Այս մեթոդը անհամբերությամբ շրջանցելու է `n` տարրերը սկսած հետևից ՝ [`next_back`] զանգահարելով մինչև `n` անգամ մինչև [`None`] հանդիպելը:
    ///
    /// `advance_back_by(n)` կվերադարձնի [`Ok(())`], եթե կրկնիչը հաջողությամբ առաջ է շարժվում `n` տարրերով, կամ [`Err(k)`], եթե [`None`] հանդիպում է, որտեղ `k` այն տարրերի թիվն է, որով առաջադրողը առաջ է մղվում նախքան տարրերի սպառումը (այսինքն
    /// կրկնիչի երկարությունը):
    /// Նշենք, որ `k`-ը միշտ պակաս է, քան `n`-ը:
    ///
    /// `advance_back_by(0)` զանգահարելը չի սպառում որևէ տարր և միշտ վերադարձնում է [`Ok(())`]:
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // բաց է թողնվել միայն `&3`-ը
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Վերադարձնում է `n` րդ տարրը կրկնիչի վերջից:
    ///
    /// Ըստ էության, սա [`Iterator::nth()`]-ի հակադարձ տարբերակն է:
    /// Չնայած ինդեքսավորման գործառնությունների մեծամասնության նման, հաշվարկը սկսվում է զրոյից, ուստի `nth_back(0)`-ը վերջից վերադարձնում է առաջին արժեքը, `nth_back(1)`-ը ՝ երկրորդը և այլն:
    ///
    ///
    /// Նշենք, որ վերջի և վերադարձված տարրի միջև բոլոր տարրերը կսպառվեն, ներառյալ վերադարձված տարրը:
    /// Սա նաև նշանակում է, որ `nth_back(0)` մի քանի անգամ նույն կրկնիչի վրա զանգելը կվերադարձնի տարբեր տարրեր:
    ///
    /// `nth_back()` կվերադարձնի [`None`], եթե `n`-ը կրկնիչի երկարությունից մեծ կամ հավասար է:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` բազմակի զանգելը չի փոխում կրկնիչը.
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `None`-ի վերադարձը, եթե `n + 1`-ից պակաս տարրեր կան.
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Սա [`Iterator::try_fold()`]-ի հակառակ տարբերակն է. Այն տանում է տարրեր, սկսած կրկնիչի հետևից:
    ///
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Քանի որ այն կարճ միացվեց, մնացած տարրերը դեռ հասանելի են կրկնիչի միջոցով:
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Իտերատորի մեթոդ, որը իտերատորի տարրերը իջեցնում է մեկ, վերջնական արժեքի ՝ սկսած հետևից:
    ///
    /// Սա [`Iterator::fold()`]-ի հակառակ տարբերակն է. Այն տանում է տարրեր, սկսած կրկնիչի հետևից:
    ///
    /// `rfold()` վերցնում է երկու փաստարկ. նախնական արժեք և փակում երկու փաստարկով. 'accumulator' և տարր:
    /// Փակումը վերադարձնում է այն արժեքը, որը կուտակիչը պետք է ունենա հաջորդ կրկնության համար:
    ///
    /// Նախնական արժեքն այն արժեքն է, որը կուտակիչը կունենա առաջին զանգի ժամանակ:
    ///
    /// Այս փակումը կրկնիչի յուրաքանչյուր տարրի վրա կիրառելուց հետո `rfold()`-ը վերադարձնում է կուտակիչը:
    ///
    /// Այս գործողությունը երբեմն կոչվում է 'reduce' կամ 'inject':
    ///
    /// Փեղկավորումը օգտակար է, երբ որևէ բանի հավաքածու ունեք, և ուզում եք դրանից մեկ արժեք արտադրել:
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ա - ի բոլոր տարրերի հանրագումարը
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Այս օրինակը կառուցում է մի տող ՝ սկսած սկզբնական արժեքից և շարունակելով յուրաքանչյուր տարրից հետևից մինչև ճակատը.
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ետևի կողմից հետադարձի մի տարր է որոնում, որը բավարարում է նախդիրը:
    ///
    /// `rfind()` վերցնում է փակումը, որը վերադարձնում է `true` կամ `false`:
    /// Այն կիրառում է այս փակումը կրկնիչի յուրաքանչյուր տարրի նկատմամբ `սկսած վերջից, և եթե նրանցից որևէ մեկը վերադարձնի `true`, ապա `rfind()` վերադարձնում է [`Some(element)`]:
    /// Եթե բոլորը վերադարձնում են `false`, ապա այն վերադարձնում է [`None`]:
    ///
    /// `rfind()` կարճ միացում է;այլ կերպ ասած, այն կդադարեցնի վերամշակումը հենց փակումը վերադառնա `true`:
    ///
    /// Քանի որ `rfind()`-ը հղում է վերցնում, և շատ կրկնիչներ կրկնում են հղումները, դա հանգեցնում է հնարավոր խառնաշփոթ իրավիճակի, երբ փաստարկը կրկնակի հղում է:
    ///
    /// Այս ազդեցությունը կարող եք տեսնել ստորև բերված օրինակներում, `&&x`-ի հետ:
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Հիմնական օգտագործում:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Կանգ առնելով առաջին `true`-ին ՝
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // մենք դեռ կարող ենք օգտագործել `iter`, քանի որ կան էլեմենտներ:
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}