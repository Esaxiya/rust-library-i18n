//! Traits տիպերի փոխակերպման համար:
//!
//! Այս մոդուլի traits-ն ապահովում է մի տիպից մյուս տիպը փոխարկելու միջոց:
//! Յուրաքանչյուր trait ծառայում է տարբեր նպատակների.
//!
//! - Իրականացրեք [`AsRef`] trait էժան հղում դեպի հղում փոխարկելու համար
//! - Իրականացրեք [`AsMut`] trait էժան փոխարկելիից փոխարկելի փոխակերպումների համար
//! - Իրականացրեք [`From`] trait-ը արժեքից արժեք փոխակերպումներ սպառելու համար
//! - Իրականացրեք [`Into`] trait-ը `ներկայիս crate-ից դուրս տեսակների արժեքը-արժեքը փոխարկելու համար
//! - [`TryFrom`] և [`TryInto`] traits-ն իրեն պահում է ինչպես [`From`] և [`Into`], բայց պետք է իրականացվի, երբ փոխարկումը կարող է ձախողվել:
//!
//! traits-ն այս մոդուլում հաճախ օգտագործվում է որպես trait bounds ընդհանուր գործառույթների համար, որպեսզի աջակցվեն բազմաթիվ տիպի փաստարկներ: Տեսեք յուրաքանչյուր trait-ի փաստաթղթերը օրինակների համար:
//!
//! Որպես գրադարանի հեղինակ, դուք միշտ պետք է նախընտրեք [`From<T>`][`From`] կամ [`TryFrom<T>`][`TryFrom`]-ի ներդրումը, քան [`Into<U>`][`Into`]-ի կամ [`TryInto<U>`][`TryInto`]-ի, քանի որ [`From`]-ը և [`TryFrom`]-ն ավելի մեծ ճկունություն են ապահովում և առաջարկում են համարժեք [`Into`] կամ [`TryInto`] համարժեք իրականացում `ստանդարտ գրադարանում վերմակի իրականացման շնորհիվ:
//! Rust 1.41-ից առաջ մի տարբերակ թիրախավորելիս գուցե անհրաժեշտ լինի իրականացնել [`Into`] կամ [`TryInto`] ուղղակիորեն, երբ ներկայիս crate-ից դուրս գտնվող տիպի փոխարկենք:
//!
//! # Ընդհանուր ներդրումներ
//!
//! - [`AsRef`] և [`AsMut`] ինքնահեռացում, եթե ներքին տեսակը հղում է
//! - [«From-ից]» ` <U>T-ի համար ենթադրում է [« Into »]»</u><T><U>U-ի համար</u>
//! - [«TryFrom»]-ը <U>T-ի համար ենթադրում է [«TryInto»] »</u><T><U>U-ի համար</u>
//! - [`From`] և [`Into`]-ը ռեֆլեկտիվ են, ինչը նշանակում է, որ բոլոր տեսակները կարող են `into`-ը և `from`-ն իրենք
//!
//! Օգտագործման օրինակների համար տես յուրաքանչյուր trait:
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Ինքնության գործառույթը:
///
/// Այս գործառույթի մասին կարևոր է նշել երկու բան.
///
/// - Դա միշտ չէ, որ համարժեք է `|x| x`-ի նման փակմանը, քանի որ փակումը կարող է պարտադրել `x`-ը այլ տեսակի:
///
/// - Այն տեղափոխում է `x` մուտքագրումը, որն անցել է գործառույթին:
///
/// Չնայած կարող է տարօրինակ թվալ գործառույթ ունենալը, որը պարզապես վերադարձնում է մուտքագրումը, կան մի քանի հետաքրքիր գործածություններ:
///
///
/// # Examples
///
/// Օգտագործելով `identity` ՝ ոչինչ չանելու այլ, հետաքրքիր, գործառույթների հաջորդականությամբ.
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Եկեք ձեւացնենք, որ մեկը ավելացնելը հետաքրքիր գործառույթ է:
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Օգտագործելով `identity`-ը որպես "do nothing" բազային պատյան ՝ պայմանականորեն.
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Ավելի հետաքրքիր իրեր արա ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Օգտագործելով `identity` ՝ `Option<T>` իտերատորի `Some` տարբերակները պահելու համար.
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Օգտագործվում է էժան հղում դեպի հղում փոխարկումը կատարելու համար:
///
/// Այս trait-ը նման է [`AsMut`]-ի, որն օգտագործվում է փոփոխական հղումների միջև փոխակերպման համար:
/// Եթե Ձեզ անհրաժեշտ է ծախսատար վերափոխում կատարել, ավելի լավ է [`From`]-ն իրականացնել `&T` տիպի հետ կամ գրել հատուկ գործառույթ:
///
/// `AsRef` ունի նույն ստորագրությունը, ինչ [`Borrow`]-ը, բայց [`Borrow`]-ը տարբեր է մի քանի առումներով.
///
/// - Ի տարբերություն `AsRef`-ի, [`Borrow`]-ը վերմակ ունի ցանկացած `T`-ի համար, և այն կարող է օգտագործվել ընդունելու համար կամ արժեք:
/// - [`Borrow`] պահանջում է նաև, որ փոխառված արժեքի համար [`Hash`], [`Eq`] և [`Ord`] համարժեք լինեն սեփականության արժեքի:
/// Այս պատճառով, եթե ցանկանում եք վերցնել կառուցվածքի միայն մեկ դաշտ, ապա կարող եք իրականացնել `AsRef`, բայց ոչ [`Borrow`]:
///
/// **Note: Այս trait-ը չպետք է ձախողվի **: Եթե փոխարկումը կարող է ձախողվել, օգտագործեք նվիրված մեթոդ, որը վերադարձնում է [`Option<T>`] կամ [`Result<T, E>`]:
///
/// # Ընդհանուր ներդրումներ
///
/// - `AsRef` ինքնահեռացում, եթե ներքին տեսակը հղում է կամ փոփոխական հղում (օրինակ ՝ `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds-ի օգտագործմամբ մենք կարող ենք ընդունել տարբեր տիպի փաստարկներ, քանի դեռ դրանք կարող են փոխարկվել նշված տիպի `T`:
///
/// Օրինակ. Ստեղծելով ընդհանուր գործառույթ, որը տանում է `AsRef<str>`, մենք հայտնում ենք, որ ուզում ենք որպես փաստարկ ընդունել բոլոր հղումները, որոնք կարող են փոխարկվել [`&str`]-ի:
/// Քանի որ [`String`]-ը և [`&str`]-ը իրականացնում են `AsRef<str>`, մենք կարող ենք երկուսն էլ ընդունել որպես մուտքային փաստարկ:
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Կատարում է դարձը:
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Օգտագործվում է էժան փոփոխական-փոփոխվող տեղեկանքի վերափոխում կատարելու համար:
///
/// Այս trait-ը նման է [`AsRef`]-ին, բայց օգտագործվում է փոփոխական հղումների միջև փոխակերպման համար:
/// Եթե Ձեզ անհրաժեշտ է ծախսատար վերափոխում կատարել, ավելի լավ է [`From`]-ն իրականացնել `&mut T` տիպի հետ կամ գրել հատուկ գործառույթ:
///
/// **Note: Այս trait-ը չպետք է ձախողվի **: Եթե փոխարկումը կարող է ձախողվել, օգտագործեք նվիրված մեթոդ, որը վերադարձնում է [`Option<T>`] կամ [`Result<T, E>`]:
///
/// # Ընդհանուր ներդրումներ
///
/// - `AsMut` ինքնահեռացում, եթե ներքին տեսակը փոփոխական հղում է (օրինակ ՝ `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Օգտագործելով `AsMut` որպես trait bound ընդհանուր գործառույթի համար, մենք կարող ենք ընդունել բոլոր փոփոխական տեղեկանքները, որոնք կարող են փոխարկվել `&mut T` տիպի:
/// Քանի որ [`Box<T>`]-ն իրականացնում է `AsMut<T>`, մենք կարող ենք գրել `add_one` գործառույթ, որը վերցնում է բոլոր փաստարկները, որոնք կարող են փոխարկվել `&mut u64`:
/// Քանի որ [`Box<T>`]-ն իրականացնում է `AsMut<T>`, `add_one`-ն ընդունում է նաև `&mut Box<u64>` տիպի փաստարկներ.
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Կատարում է դարձը:
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Արժեքից արժեք փոխարկումը, որը սպառում է մուտքային արժեքը: [`From`]-ի հակառակը:
///
/// Պետք է խուսափել [`Into`]-ի ներդրումից և փոխարենը [`From`]-ի ներդրումից:
/// [`From`]-ի իրականացումը ավտոմատ կերպով ապահովում է [`Into`]-ի իրականացումը `ստանդարտ գրադարանում վերմակի իրականացման շնորհիվ:
///
/// Ընդհանուր գործառույթի վրա trait bounds նշելու ժամանակ նախընտրեք օգտագործել [`Into`]-ը [`From`]-ի նկատմամբ, որպեսզի համոզվեք, որ տեսակները, որոնք միայն [`Into`] են իրականացնում, կարող են օգտագործվել նաև:
///
/// **Note: Այս trait-ը չպետք է ձախողվի **: Եթե փոխարկումը կարող է ձախողվել, օգտագործեք [`TryInto`]:
///
/// # Ընդհանուր ներդրումներ
///
/// - [«From`]»-ից<T>քանի որ U` ենթադրում է `Into<U> for T`
/// - [`Into`] ռեֆլեկտիվ է, ինչը նշանակում է, որ `Into<T> for T`-ն իրականացվում է
///
/// # Rust-ի հին տարբերակներում [`Into`]-ի իրականացում արտաքին տեսակների վերափոխման համար
///
/// Նախքան Rust 1.41-ը, եթե նպատակակետի տեսակը ներկա crate-ի մաս չէր, ապա դուք չէիք կարող ուղղակիորեն իրականացնել [`From`]-ը:
/// Օրինակ, վերցրեք այս կոդը ՝
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Սա չի հաջողվի կազմել լեզվի հին տարբերակներում, քանի որ նախկինում Rust որբերի կանոնները մի փոքր ավելի խիստ էին:
/// Սա շրջանցելու համար դուք կարող եք ուղղակիորեն իրականացնել [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Կարևոր է հասկանալ, որ [`Into`]-ը չի ապահովում [`From`] իրականացում (ինչպես [`From`]-ն է անում [`Into`]-ի հետ):
/// Հետևաբար, միշտ պետք է փորձեք իրականացնել [`From`], այնուհետև հետ ընկնել [`Into`], եթե [`From`] հնարավոր չէ իրականացնել:
///
/// # Examples
///
/// [`String`] իրականացնում է [«Into»] «<"["Vec"]"<"["u8"]">>:
///
/// Որպեսզի արտահայտենք, որ մենք ուզում ենք, որ ընդհանուր ֆունկցիան վերցնի բոլոր փաստարկները, որոնք կարող են փոխարկվել նշված տիպի `T`, մենք կարող ենք օգտագործել trait bound [«Into»]-ից: <T>`
///
/// Օրինակ. `is_hello` ֆունկցիան վերցնում է բոլոր փաստարկները, որոնք կարող են փոխակերպվել [«Vec»] «<"["u8"]">"-ի:
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Կատարում է դարձը:
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Օգտագործվում է արժեքից արժեք փոխարկումներ կատարելու համար ՝ ներածման արժեքը սպառելիս: Դա փոխադարձ է [`Into`]-ի:
///
/// Միշտ պետք է նախընտրել `From`-ի [`Into`]-ի ներդրումը, քանի որ `From`-ի իրականացումը ավտոմատ կերպով ապահովում է [`Into`]-ի իրականացումը `ստանդարտ գրադարանում վերմակի իրականացման շնորհիվ:
///
///
/// Իրականացրեք [`Into`]-ը միայն Rust 1.41-ից առաջ մի տարբերակ թիրախավորելու և ներկայիս crate-ից դուրս մի տիպի վերափոխելու ժամանակ:
/// `From` Rust-ի որբացման կանոնների պատճառով ի վիճակի չէր կատարել այս տիպի փոխակերպումները ավելի վաղ տարբերակներում:
/// Տե՛ս [`Into`] ՝ ավելի մանրամասն:
///
/// Նախընտրեք օգտագործել [`Into`]-ը, քան `From`-ը ՝ ընդհանուր ֆունկցիայի վրա trait bounds նշելիս:
/// Այսպիսով, տիպերը, որոնք ուղղակիորեն իրականացնում են [`Into`]-ը, կարող են օգտագործվել նաև որպես փաստարկներ:
///
/// `From`-ը նույնպես շատ օգտակար է սխալների մշակում կատարելիս: Ֆունկցիա կառուցելիս, որն ունակ է ձախողել, վերադարձի տեսակը, ընդհանուր առմամբ, կլինի `Result<T, E>` ձևի:
/// `From` trait-ը պարզեցնում է սխալի մշակումը `թույլ տալով գործառույթին վերադարձնել սխալի մի տեսակ, որը պարունակում է բազմաթիվ սխալի տեսակներ: Լրացուցիչ մանրամասների համար տե՛ս "Examples" բաժինը և [the book][book]:
///
/// **Note: Այս trait-ը չպետք է ձախողվի **: Եթե փոխարկումը կարող է ձախողվել, օգտագործեք [`TryFrom`]:
///
/// # Ընդհանուր ներդրումներ
///
/// - `From<T> for U` ենթադրում է [«Into»] ` <U>T-ի համար</u>
/// - `From` ռեֆլեկտիվ է, ինչը նշանակում է, որ `From<T> for T`-ն իրականացվում է
///
/// # Examples
///
/// [`String`] իրականացնում է `From<&str>`:
///
/// `&str`-ից տողի բացահայտ վերափոխումը կատարվում է հետևյալ կերպ.
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Սխալների մշակում կատարելիս հաճախ օգտակար է իրականացնել `From` ձեր սեփական սխալի տեսակի համար:
/// Հիմքում ընկած սխալի տեսակները վերափոխելով մեր սեփական սխալի տիպի, որն ամփոփում է հիմքում ընկած սխալի տեսակը, մենք կարող ենք վերադարձնել սխալի մեկ տեսակ ՝ առանց կորցնելու հիմքում ընկած պատճառի մասին տեղեկատվությունը:
/// '?' օպերատորը ավտոմատ կերպով փոխում է հիմքում ընկած սխալի տեսակը մեր մաքսային սխալի տեսակի ՝ զանգահարելով `Into<CliError>::into`, որն ավտոմատ կերպով տրամադրվում է `From`-ն իրականացնելիս:
/// Կազմողն այնուհետև եզրակացնում է, թե `Into`-ի որ գործառնությունն է պետք օգտագործել:
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Կատարում է դարձը:
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Փոխարկման փորձ, որը սպառում է `self`, ինչը կարող է թանկ լինել կամ լինել թանկ:
///
/// Գրադարանի հեղինակները սովորաբար չպետք է ուղղակիորեն կատարեն այս trait-ը, բայց նախընտրեն իրականացնել [`TryFrom`] trait-ն, որն առաջարկում է ավելի մեծ ճկունություն և ապահովում է `TryInto` համարժեք իրականացում անվճար `ստանդարտ գրադարանում վերմակի կիրառման շնորհիվ:
/// Այս մասին լրացուցիչ տեղեկությունների համար տե՛ս [`Into`]-ի փաստաթղթերը:
///
/// # Իրականացնող `TryInto`
///
/// Սա կրում է նույն սահմանափակումներն ու պատճառաբանությունները, ինչ [`Into`]-ի իրականացումը, մանրամասների համար տես այնտեղ:
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Վերադարձման սխալի դեպքում վերադարձված տեսակը:
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Կատարում է դարձը:
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Պարզ և անվտանգ տիպի փոխակերպումներ, որոնք որոշ հանգամանքներում կարող են վերահսկելի կերպով ձախողվել: Դա փոխադարձ է [`TryInto`]-ի:
///
/// Սա օգտակար է այն ժամանակ, երբ դուք կատարում եք տիպի փոխարկում, որը կարող է աննշանորեն հաջողվել, բայց կարող է նաև հատուկ մշակման կարիք ունենալ:
/// Օրինակ [`i64`]-ը [`i32`]-ի [`From`]-ի [`i32`] վերափոխելու ոչ մի եղանակ չկա, որովհետև [`i64`]-ը կարող է պարունակել այնպիսի արժեք, որը [`i32`]-ը չի կարող ներկայացնել, ուստի փոխարկումը կկորցնի տվյալները:
///
/// Դա հնարավոր է կարգավորել [`i64`]-ը [`i32`]-ին կտրելու միջոցով (ըստ էության տալով [i64`] արժեքի [`i32::MAX`] մոդուլը) կամ պարզապես վերադարձնելով [`i32::MAX`]-ը կամ որևէ այլ մեթոդ:
/// [`From`] trait-ը նախատեսված է կատարյալ փոխակերպումների համար, ուստի `TryFrom` trait-ը ծրագրավորողին հայտնում է, թե երբ տիպի փոխարկումը կարող է վատ լինել, և նրանց թույլ է տալիս որոշել, թե ինչպես վարվել դրա հետ:
///
/// # Ընդհանուր ներդրումներ
///
/// - `TryFrom<T> for U` ենթադրում է [«TryInto»] ` <U>T-ի համար</u>
/// - [`try_from`] ռեֆլեքսային է, ինչը նշանակում է, որ `TryFrom<T> for T`-ն իրականացվում է և չի կարող ձախողվել. ասոցացված `Error` տիպը `T::try_from()` `T` տիպի արժեքով `T::try_from()` զանգահարելու համար [`Infallible`] է:
/// Երբ [`!`] տիպը կայունացվի, [`Infallible`]-ը և [`!`]-ը համարժեք կլինեն:
///
/// `TryFrom<T>` կարող է իրականացվել հետևյալ կերպ.
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Ինչպես նկարագրված է, [`i32`]-ն իրականացնում է «TryFrom <"["i64"]">":
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Լուռ կերպով կտրում է `big_number`-ը, պահանջում է փաստը հայտնաբերելուց և կարգավորել կոճղը:
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Վերադարձնում է սխալ, քանի որ `big_number`-ը չափազանց մեծ է `i32`-ի մեջ տեղավորելու համար:
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Վերադառնում է `Ok(3)`:
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Վերադարձման սխալի դեպքում վերադարձված տեսակը:
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Կատարում է դարձը:
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ԸՆԴՀԱՆՈՒՐ ԸՆԿԵՐՈՒԹՅՈՒՆՆԵՐ
////////////////////////////////////////////////////////////////////////////////

// Քանի որ վերելակները և
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Որպես վերելակներ &mut-ի վրայով
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742). Փոխարինեք վերը նշված բառերը և//&mut-ի համար հետևյալ ընդհանուր առմամբ.
// // Քանի որ վերելակներ են Deref
// ենթարկել <D: ?Sized + Deref<Target: AsRef<U>>, U:? Չափավորված> AsRef <U>համար D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut-ը վեր է հանում &mut-ը
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742). &mut-ի համար փոխարինեք վերը նշված ազդանշանը հետևյալ ընդհանուր առմամբ.
// // AsMut-ը վեր է բարձրացնում DerefMut-ի վրա
// ենթարկել <D: ?Sized + Deref<Target: AsMut<U>>, U:? Չափավորված> AsMut <U>համար D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// From-ը ենթադրում է Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (և, այդպիսով, Into) ռեֆլեկտիվ է
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Կայունության նշում.** Այս ազդանշանը դեռ գոյություն չունի, բայց մենք "reserving space" ենք ՝ այն future-ում ավելացնելու համար:
/// Մանրամասների համար տե՛ս [rust-lang/rust#64715][#64715]:
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): փոխարենը կատարեք սկզբունքային շտկում:
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom-ը ենթադրում է TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Անսխալական դարձումները իմաստաբանորեն համարժեք են անբնակ սխալի տեսակ ունեցող սխալ ընկալումներին:
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ԲԵՏՈՆԱՅԻՆ ՄԻMPՈՆԵՐ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ՈՉ ՍԽԱԼԻ ՍԽԱԼԻ ՏԵՍԱԿԸ
////////////////////////////////////////////////////////////////////////////////

/// Սխալի տեսակը սխալների համար, որոնք երբեք չեն կարող պատահել:
///
/// Քանի որ այս թվանշանը տարբերակ չունի, այս տեսակի արժեքը իրականում երբեք չի կարող գոյություն ունենալ:
/// Սա կարող է օգտակար լինել այն ընդհանուր API-ների համար, որոնք օգտագործում են [`Result`] և պարամետրացնում են սխալի տեսակը ՝ ցույց տալու համար, որ արդյունքը միշտ [`Ok`] է:
///
/// Օրինակ, [`TryFrom`] trait (փոխակերպում, որը վերադարձնում է [`Result`]) ունի վերմակի իրականացում բոլոր տեսակների համար, որտեղ կա հակառակ [`Into`] իրականացում:
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future համատեղելիություն
///
/// Այս enum-ն ունի նույն դերը, ինչ [the `!`“never”type][never]-ը, որն անկայուն է Rust-ի այս տարբերակում:
/// Երբ `!`- ը կայունացվի, մենք նախատեսում ենք `Infallible`- ը դարձնել դրա տիպային մականունը.
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Եվ ի վերջո արժեզրկել `Infallible`-ը:
///
/// Այնուամենայնիվ, կա մի դեպք, երբ `!` շարահյուսությունը կարող է օգտագործվել մինչև `!` կայունացումը որպես լիարժեք տեսակ ՝ գործառույթի վերադարձի տիպի դիրքում:
/// Մասնավորապես, հնարավոր է իրականացնել երկու տարբեր գործառույթների ցուցիչի տեսակներ.
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Քանի որ `Infallible` թվանշան է, այս ծածկագիրը վավեր է:
/// Այնուամենայնիվ, երբ `Infallible`-ը never type-ի կեղծանուն դառնա, երկու «իմպլեկտները» կսկսեն համընկնել և հետևաբար կթույլատրվեն trait լեզվի համահունչ կանոններով:
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}