//! Ատոմային տեսակներ
//!
//! Ատոմային տեսակները ապահովում են պարզունակ ընդհանուր հիշողության հաղորդակցություն թելերի միջև և հանդիսանում են այլ զուգահեռ տիպի կառուցվածքային նյութեր:
//!
//! Այս մոդուլը սահմանում է պարզունակ տիպերի, ներառյալ [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] և այլն, ընտրված քանակի ատոմային տարբերակները:
//! Ատոմային տիպերը ներկայացնում են գործողություններ, որոնք ճիշտ օգտագործելիս համաժամացնում են թարմացումները թելերի միջև:
//!
//! Յուրաքանչյուր մեթոդ վերցնում է [`Ordering`], որը ներկայացնում է հիշողության խոչընդոտի ուժը այդ գործողության համար: Այս պատվերները նույնն են, ինչ [C++20 atomic orderings][1]-ը:Լրացուցիչ տեղեկությունների համար տե՛ս [nomicon][2]:
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Ատոմային փոփոխականները անվտանգ են կիսել թելերի միջև (դրանք իրականացնում են [`Sync`]), բայց դրանք իրենք չեն տրամադրում Rust-ի [threading model](../../../std/thread/index.html#the-threading-model)-ի բաժանման մեխանիզմը և հետևում:
//!
//! Ատոմային փոփոխականությունը կիսելու ամենատարածված ձևը այն [`Arc`][arc]-ի մեջ դնելն է (ատոմային-հղումով հաշվարկված ընդհանուր ցուցիչ):
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Ատոմային տիպերը կարող են պահվել ստատիկ փոփոխականներում, նախնականացվել ՝ օգտագործելով [`AtomicBool::new`]-ի նման հաստատուն սկզբնավորող սարքեր: Ատոմային ստատիկան հաճախ օգտագործվում է ծույլ գլոբալ սկզբնավորման համար:
//!
//! # Portability
//!
//! Այս մոդուլի բոլոր ատոմային տեսակները երաշխավորված կլինեն [lock-free], եթե դրանք մատչելի են: Սա նշանակում է, որ նրանք ներքուստ չեն ձեռք բերում գլոբալ մուտեքս:Ատոմային տեսակները և գործողությունները երաշխավորված չեն, որ սպասում են անվճար:
//! Սա նշանակում է, որ `fetch_or`-ի նման գործողությունները կարող են իրականացվել համեմատության և փոխանակման օղակով:
//!
//! Ատոմային գործողությունները կարող են իրականացվել ավելի մեծ չափի ատոմիկներով հրահանգների շերտում: Օրինակ ՝ որոշ պլատֆորմներ օգտագործում են 4 բայթ ատոմային հրահանգներ ՝ `AtomicI8`- ն իրականացնելու համար:
//! Նկատի ունեցեք, որ այս ընդօրինակումը չպետք է ազդեցություն ունենա ծածկագրի ճշգրտության վրա, դա պարզապես տեղյակ է մի բան:
//!
//! Այս մոդուլի ատոմային տեսակները կարող են հասանելի չլինել բոլոր հարթակներում: Ատոմային տեսակները այստեղ բոլորն էլ լայնորեն մատչելի են, և, ընդհանուր առմամբ, կարելի է ապավինել եղածին:Որոշ ուշագրավ բացառություններ են.
//!
//! * PowerPC 32-բիթանոց ցուցիչներով MIPS պլատֆորմները չունեն `AtomicU64` կամ `AtomicI64` տեսակներ:
//! * ARM `armv5te`-ի նման պլատֆորմները, որոնք նախատեսված չեն Linux-ի համար, ապահովում են միայն `load` և `store` գործառնություններ և չեն աջակցում Համեմատել և փոխել (CAS) գործառնություններ, ինչպիսիք են `swap`, `fetch_add` և այլն:
//! Լրացուցիչ Linux-ի վրա, CAS-ի այս գործողություններն իրականացվում են [operating system support]-ի միջոցով, որը կարող է առաջանալ կատարման տույժով:
//! * ARM `thumbv6m` ունեցող թիրախները տրամադրում են միայն `load` և `store` գործողություններ և չեն աջակցում Համեմատել և փոխել (CAS) գործառույթները, ինչպիսիք են `swap`, `fetch_add` և այլն:
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Նշենք, որ future պլատֆորմները կարող են ավելացվել, որոնք նույնպես չունեն աջակցություն որոշ ատոմային գործողությունների համար: Առավելագույն շարժական ծածկագիրը կցանկանա զգույշ լինել, թե որ ատոմային տեսակներն են օգտագործվում:
//! `AtomicUsize` և `AtomicIsize`-ն ընդհանուր առմամբ ամենադյուրակիրն են, բայց նույնիսկ այդ դեպքում դրանք հասանելի չեն ամենուր:
//! Տեղեկանքի համար `std` գրադարանը պահանջում է ցուցիչի չափի ատոմիկա, չնայած `core`-ը `ոչ:
//!
//! Ներկայումս ձեզ հարկավոր է օգտագործել `#[cfg(target_arch)]` հիմնականում ատոմիկայի հետ ծածկագրում պայմանական կազմելու համար: Կա նաև անկայուն `#[cfg(target_has_atomic)]`, որը կարող է կայունացվել future-ում:
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Պարզ պտտաձև
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Սպասեք, որ մյուս թելը ազատի կողպեքը
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Պահպանեք ուղիղ թեմաների ընդհանուր հաշվարկ.
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Բուլյան տեսակ, որը կարող է ապահով կերպով բաժանվել թելերի միջև:
///
/// Այս տեսակն ունի հիշողության նույն ներկայացուցչությունը, ինչ [`bool`]-ը:
///
/// **Նշում**. Այս տեսակը հասանելի է միայն այն պլատֆորմներում, որոնք աջակցում են ատոմային բեռները և `u8` պահեստները:
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Ստեղծում է `AtomicBool` նախադրյալ `false`:
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Ուղարկումը անուղղակիորեն իրականացվում է AtomicBool-ի համար:
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Rawուցանակի հում տեսակ, որը կարող է ապահով կերպով բաժանվել թելերի միջև:
///
/// Այս տեսակն ունի հիշողության նույն ներկայացուցչությունը, ինչ `*mut T`-ը:
///
/// **Նշում**. Այս տեսակը հասանելի է միայն պլատֆորմներում, որոնք աջակցում են ատոմային բեռները և ցուցիչների պահուստները:
/// Դրա չափը կախված է նպատակային ցուցիչի չափից:
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Ստեղծում է զրոյական `AtomicPtr<T>`:
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Ատոմային հիշողության պատվերներ
///
/// Հիշողության կարգերը նշում են, թե ինչպես են ատոմային գործողությունները հիշեցնում համաժամանակացումը:
/// Իր ամենաթույլ [`Ordering::Relaxed`]-ում սինխրոնիզացվում է միայն գործողությունը, որն ուղղակիորեն հուզված է:
/// Մյուս կողմից, խանութի բեռնված [`Ordering::SeqCst`] գործողությունների զույգը համաժամանակացնում է այլ հիշողությունը ՝ միևնույն ժամանակ պահպանելով այդպիսի գործողությունների ընդհանուր կարգը բոլոր թելերի միջև:
///
///
/// Rust-ի հիշողության պատվերները [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) են:
///
/// Լրացուցիչ տեղեկությունների համար տե՛ս [nomicon]:
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Պատվիրող սահմանափակումներ չկան, այլ միայն ատոմային գործողություններ:
    ///
    /// Համապատասխանում է [`memory_order_relaxed`]-ին C++ 20-ով:
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Խանութի հետ զուգորդվելով ՝ նախորդ բոլոր գործողությունները պատվիրվում են մինչև այս արժեքի ցանկացած բեռը [`Acquire`] (կամ ավելի ուժեղ) պատվերով:
    ///
    /// Մասնավորապես, բոլոր նախորդ գրվածքները տեսանելի են դառնում այս արժեքի [`Acquire`] (կամ ավելի ուժեղ) բեռ կատարող բոլոր թելերի համար:
    ///
    /// Ուշադրություն դարձրեք, որ այս պատվերի օգտագործումը բեռների և պահուստների համատեղմամբ գործողության համար հանգեցնում է [`Relaxed`] բեռի գործողության:
    ///
    /// Այս պատվերը կիրառելի է միայն այն գործառնությունների համար, որոնք կարող են խանութ կատարել:
    ///
    /// Համապատասխանում է [`memory_order_release`]-ին C++ 20-ով:
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Երբ բեռի հետ զուգակցվում է, եթե բեռնված արժեքը գրվել է խանութի գործողության միջոցով [`Release`] (կամ ավելի ուժեղ) պատվերով, ապա բոլոր հաջորդ գործողությունները պատվիրվում են այդ խանութից հետո:
    /// Մասնավորապես, հետագա բոլոր բեռներում կտեսնեն խանութից առաջ գրված տվյալները:
    ///
    /// Ուշադրություն դարձրեք, որ բեռների և խանութների համատեղման գործողության համար այս պատվերի օգտագործումը բերում է [`Relaxed`] խանութի շահագործման:
    ///
    /// Այս պատվերը կիրառելի է միայն այն գործողությունների համար, որոնք կարող են բեռ կատարել:
    ///
    /// Համապատասխանում է [`memory_order_acquire`]-ին C++ 20-ով:
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ունի [`Acquire`]-ի և [`Release`]-ի հետևանքները միասին.
    /// Բեռների համար այն օգտագործում է [`Acquire`] պատվեր: Խանութների համար այն օգտագործում է [`Release`] պատվեր:
    ///
    /// Ուշադրություն դարձրեք, որ `compare_and_swap`-ի դեպքում հնարավոր է, որ գործողությունն ավարտի չլինի որևէ խանութ, ուստի այն ունի ընդամենը [`Acquire`] պատվեր:
    ///
    /// Այնուամենայնիվ, `AcqRel`-ը երբեք չի կատարի [`Relaxed`] մուտքեր:
    ///
    /// Այս պատվերը կիրառելի է միայն գործողությունների համար, որոնք համատեղում են ինչպես բեռները, այնպես էլ պահեստները:
    ///
    /// Համապատասխանում է [`memory_order_acq_rel`]-ին C++ 20-ով:
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Like [«Ձեռք բերել]]/[« Ազատել »]/[« AcqRel »](համապատասխանաբար բեռնման, պահեստավորման և խանութի հետ բեռնաթափման համար) ՝ լրացուցիչ երաշխիքով, որ բոլոր թելերը տեսնում են բոլոր հաջորդականորեն հետևողական գործողությունները նույն կարգով ,
    ///
    ///
    /// Համապատասխանում է [`memory_order_seq_cst`]-ին C++ 20-ով:
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`]-ը նախաստորագրվել է `false`-ի:
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Ստեղծում է նոր `AtomicBool`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Վերադարձնում է անփոփոխ հղում հիմքում ընկած [`bool`]-ին:
    ///
    /// Սա անվտանգ է, քանի որ փոփոխական տեղեկանքը երաշխավորում է, որ ոչ մի այլ թեմա միաժամանակ չի մուտք գործում ատոմային տվյալներ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Փոփոխական տեղեկանքը երաշխավորում է եզակի սեփականության իրավունքը:
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Ստացեք ատոմային մուտք դեպի `&mut bool`:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Փոփոխական տեղեկանքը երաշխավորում է եզակի պատկանելությունը, և
        // Ինչպես `bool`-ի, այնպես էլ `Self`-ի հավասարեցումը 1 է:
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Սպառում է ատոմը և վերադարձնում պարունակվող արժեքը:
    ///
    /// Սա անվտանգ է, քանի որ `self`- ով արժեքն անցնելը երաշխավորում է, որ ոչ մի այլ թել միաժամանակ չեն մուտք գործում ատոմային տվյալներ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool-ից արժեք է բեռնում:
    ///
    /// `load` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
    /// Հնարավոր արժեքներն են [`SeqCst`], [`Acquire`] և [`Relaxed`]:
    ///
    /// # Panics
    ///
    /// Panics եթե `order`-ը [`Release`] կամ [`AcqRel`] է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների ցանկացած ռասան կանխարգելվում է ատոմային բնիկների և հումքի միջոցով
        // փոխանցված ցուցիչը վավեր է, քանի որ այն ստացել ենք հղումից:
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Մի արժեք է պահում bool-ում:
    ///
    /// `store` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
    /// Հնարավոր արժեքներն են [`SeqCst`], [`Release`] և [`Relaxed`]:
    ///
    /// # Panics
    ///
    /// Panics եթե `order`-ը [`Acquire`] կամ [`AcqRel`] է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների ցանկացած ռասան կանխարգելվում է ատոմային բնիկների և հումքի միջոցով
        // փոխանցված ցուցիչը վավեր է, քանի որ այն ստացել ենք հղումից:
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Արժեք է պահում bool-ի մեջ ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// `swap` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
    /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
    ///
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// [`bool`]-ի մեջ պահում է մի արժեք, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
    ///
    /// Վերադարձի արժեքը միշտ նախորդ արժեքն է: Եթե այն հավասար է `current`-ին, ապա արժեքը թարմացվել է:
    ///
    /// `compare_and_swap` վերցնում է նաև [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
    /// Ուշադրություն դարձրեք, որ նույնիսկ [`AcqRel`]-ն օգտագործելիս գործողությունը կարող է ձախողվել, ուստի պարզապես կատարել `Acquire` բեռ, բայց չունեն `Release` իմաստաբանություն:
    /// [`Acquire`]-ի օգտագործումը խանութը [`Relaxed`]-ի մաս է դարձնում այս գործողության, եթե դա տեղի է ունենում, իսկ [`Release`]-ի օգտագործումը բեռի մասը դարձնում է [`Relaxed`]:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Միգրացիա դեպի `compare_exchange` և `compare_exchange_weak`
    ///
    /// `compare_and_swap` համարժեք է `compare_exchange`-ին հիշողության պատվերների հետևյալ քարտեզագրմամբ.
    ///
    /// Բնօրինակ |Հաջողություն |Ձախողում
    /// -------- | ------- | -------
    /// Հանգիստ |Հանգիստ |Հանգիստ ձեռքբերում |Ձեռք բերել |Ձեռք բերեք թողարկման |Թողարկում |Հանգիստ AcqRel |AcqRel |Ձեռք բերեք SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` թույլատրվում է կեղծորեն ձախողվել նույնիսկ համեմատության հաջողության դեպքում, ինչը թույլ է տալիս կազմողին ավելի լավ հավաքել կոդ, երբ համեմատությունն ու փոխանակումը օգտագործվում են օղակում:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// [`bool`]-ի մեջ պահում է մի արժեք, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
    ///
    /// Վերադարձի արժեքը արդյունք է, որը ցույց է տալիս ՝ արդյոք նոր արժեքը գրվա՞ծ է, թե՞ պարունակում է նախորդ արժեքը:
    /// Հաջողության դեպքում երաշխավորված է, որ այս արժեքը հավասար կլինի `current`-ին:
    ///
    /// `compare_exchange` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
    /// `success` նկարագրում է կարդալ-փոփոխել-գրել գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում `current`-ի հետ համեմատության հաջողության դեպքում:
    /// `failure` նկարագրում է բեռի գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում, երբ համեմատությունը ձախողվում է:
    /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`] է դարձնում այս գործողության մաս, իսկ [`Release`]-ի օգտագործումը հաջող բեռը դարձնում է [`Relaxed`]:
    ///
    /// Անսարքության պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// [`bool`]-ի մեջ պահում է մի արժեք, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
    ///
    /// Ի տարբերություն [`AtomicBool::compare_exchange`]-ի, այս գործառույթը թույլատրվում է կեղծորեն ձախողվել նույնիսկ համեմատության հաջողության դեպքում, ինչը կարող է հանգեցնել որոշ պլատֆորմների ավելի արդյունավետ կոդի:
    ///
    /// Վերադարձի արժեքը արդյունք է, որը ցույց է տալիս ՝ արդյոք նոր արժեքը գրվա՞ծ է, թե՞ պարունակում է նախորդ արժեքը:
    ///
    /// `compare_exchange_weak` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
    /// `success` նկարագրում է կարդալ-փոփոխել-գրել գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում `current`-ի հետ համեմատության հաջողության դեպքում:
    /// `failure` նկարագրում է բեռի գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում, երբ համեմատությունը ձախողվում է:
    /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`] է դարձնում այս գործողության մաս, իսկ [`Release`]-ի օգտագործումը հաջող բեռը դարձնում է [`Relaxed`]:
    /// Անսարքության պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Տրամաբանական "and" ՝ բուլյան արժեքով:
    ///
    /// Իրականացնում է տրամաբանական "and" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը դնում արդյունքի:
    ///
    /// Վերադարձնում է նախորդ արժեքը:
    ///
    /// `fetch_and` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
    /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
    ///
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Տրամաբանական "nand" ՝ բուլյան արժեքով:
    ///
    /// Իրականացնում է տրամաբանական "nand" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը դնում արդյունքի:
    ///
    /// Վերադարձնում է նախորդ արժեքը:
    ///
    /// `fetch_nand` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
    /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
    ///
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Մենք չենք կարող օգտագործել atomic_nand-ը այստեղ, քանի որ դա կարող է հանգեցնել անվավեր արժեք ունեցող bool-ի:
        // Դա տեղի է ունենում այն պատճառով, որ ատոմային գործողությունն իրականացվում է ներսում 8-բիթանոց ամբողջ թվով, որը սահմանում է վերին 7 բիթը:
        //
        // Այսպիսով, մենք պարզապես օգտագործում ենք fetch_xor կամ փոխանակում դրա փոխարեն:
        if val {
            // ! (x&true)== !x Մենք պետք է շրջենք bool-ը:
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Մենք պետք է bool-ը դնենք ճշմարիտ:
            //
            self.swap(true, order)
        }
    }

    /// Տրամաբանական "or" ՝ բուլյան արժեքով:
    ///
    /// Իրականացնում է տրամաբանական "or" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը դնում արդյունքի:
    ///
    /// Վերադարձնում է նախորդ արժեքը:
    ///
    /// `fetch_or` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
    /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
    ///
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Տրամաբանական "xor" ՝ բուլյան արժեքով:
    ///
    /// Իրականացնում է տրամաբանական "xor" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը դնում արդյունքի:
    ///
    /// Վերադարձնում է նախորդ արժեքը:
    ///
    /// `fetch_xor` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
    /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
    ///
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Վերադարձնում է փոփոխվող ցուցիչը հիմքում ընկած [`bool`]-ին:
    ///
    /// Արդյունքում ստացված ամբողջ թիվի վրա ոչ ատոմային ընթերցումներ և գրումներ կատարելը կարող է լինել տվյալների մրցավազք:
    /// Այս մեթոդը հիմնականում օգտակար է FFI-ի համար, որտեղ ֆունկցիայի ստորագրությունը `&AtomicBool`-ի փոխարեն կարող է օգտագործել `*mut bool`:
    ///
    /// `*mut` ցուցիչի վերադարձը այս ատոմի ընդհանուր հղումից անվտանգ է, քանի որ ատոմային տեսակները աշխատում են ներքին փոփոխականության հետ:
    /// Ատոմի բոլոր փոփոխությունները փոխում են արժեքը ընդհանուր տեղեկանքի միջոցով, և դա կարող են ապահով լինել, քանի դեռ դրանք օգտագործում են ատոմային գործողություններ:
    /// Վերադարձված հում սլաքի ցանկացած օգտագործման համար անհրաժեշտ է `unsafe` բլոկ և դեռ պետք է պահպանել նույն սահմանափակումը. Դրա վրա գործողությունները պետք է լինեն ատոմային:
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Ստանում է արժեքը և դրանում կիրառում գործառույթ, որը վերադարձնում է կամայական նոր արժեք: Վերադարձնում է `Result`-ի `Result`-ը, եթե գործառույթը վերադարձնում է `Some(_)`, այլապես `Err(previous_value)`:
    ///
    /// Note: Սա կարող է գործառույթը մի քանի անգամ զանգահարել, եթե այդ ընթացքում արժեքը փոխվել է այլ թեմաներից, այնքան ժամանակ, քանի դեռ գործառույթը վերադարձնում է `Some(_)`, բայց գործառույթը կիրառվելու է միայն մեկ անգամ պահված արժեքի վրա:
    ///
    ///
    /// `fetch_update` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
    /// Առաջինը նկարագրում է պահանջվող պատվերը, երբ գործողությունը վերջապես հաջողվում է, իսկ երկրորդը նկարագրում է բեռների համար անհրաժեշտ պատվերը:
    /// Դրանք համապատասխանում են համապատասխանաբար [`AtomicBool::compare_exchange`]-ի հաջողության և ձախողման պատվերներին:
    ///
    /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`]-ի այս գործողության մաս է դարձնում, իսկ [`Release`]-ի օգտագործումը վերջին հաջող բեռը դարձնում է [`Relaxed`]:
    /// (failed) բեռնման պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները `u8`-ի վրա:
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Ստեղծում է նոր `AtomicPtr`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Վերադարձնում է փոփոխվող հղումը հիմքում ընկած ցուցիչին:
    ///
    /// Սա անվտանգ է, քանի որ փոփոխական տեղեկանքը երաշխավորում է, որ ոչ մի այլ թեմա միաժամանակ չի մուտք գործում ատոմային տվյալներ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Ստացեք ատոմային մատչիչ ցուցիչ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - փոփոխական տեղեկանքը երաշխավորում է եզակի սեփականություն:
        //  - `*mut T`-ի և `Self`-ի հավասարեցումը նույնն է rust-ի կողմից աջակցվող բոլոր հարթակներում, ինչպես վերը նշված է:
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Սպառում է ատոմը և վերադարձնում պարունակվող արժեքը:
    ///
    /// Սա անվտանգ է, քանի որ `self`- ով արժեքն անցնելը երաշխավորում է, որ ոչ մի այլ թել միաժամանակ չեն մուտք գործում ատոմային տվյալներ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Loուցանիշից արժեք է բեռնում:
    ///
    /// `load` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
    /// Հնարավոր արժեքներն են [`SeqCst`], [`Acquire`] և [`Relaxed`]:
    ///
    /// # Panics
    ///
    /// Panics եթե `order`-ը [`Release`] կամ [`AcqRel`] է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Մի պահում է ցուցիչը արժեքը:
    ///
    /// `store` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
    /// Հնարավոր արժեքներն են [`SeqCst`], [`Release`] և [`Relaxed`]:
    ///
    /// # Panics
    ///
    /// Panics եթե `order`-ը [`Acquire`] կամ [`AcqRel`] է:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Մի արժեք պահում է ցուցիչի մեջ ՝ վերադարձնելով նախորդ արժեքը:
    ///
    /// `swap` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
    /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
    ///
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն պլատֆորմներում, որոնք աջակցում են ատոմային գործողությունները ցուցիչների վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Մի ցուցիչ է պահում ցուցիչը, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
    ///
    /// Վերադարձի արժեքը միշտ նախորդ արժեքն է: Եթե այն հավասար է `current`-ին, ապա արժեքը թարմացվել է:
    ///
    /// `compare_and_swap` վերցնում է նաև [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
    /// Ուշադրություն դարձրեք, որ նույնիսկ [`AcqRel`]-ն օգտագործելիս գործողությունը կարող է ձախողվել, ուստի պարզապես կատարել `Acquire` բեռ, բայց չունեն `Release` իմաստաբանություն:
    /// [`Acquire`]-ի օգտագործումը խանութը [`Relaxed`]-ի մաս է դարձնում այս գործողության, եթե դա տեղի է ունենում, իսկ [`Release`]-ի օգտագործումը բեռի մասը դարձնում է [`Relaxed`]:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն պլատֆորմներում, որոնք աջակցում են ատոմային գործողությունները ցուցիչների վրա:
    ///
    /// # Միգրացիա դեպի `compare_exchange` և `compare_exchange_weak`
    ///
    /// `compare_and_swap` համարժեք է `compare_exchange`-ին հիշողության պատվերների հետևյալ քարտեզագրմամբ.
    ///
    /// Բնօրինակ |Հաջողություն |Ձախողում
    /// -------- | ------- | -------
    /// Հանգիստ |Հանգիստ |Հանգիստ ձեռքբերում |Ձեռք բերել |Ձեռք բերեք թողարկման |Թողարկում |Հանգիստ AcqRel |AcqRel |Ձեռք բերեք SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` թույլատրվում է կեղծորեն ձախողվել նույնիսկ համեմատության հաջողության դեպքում, ինչը թույլ է տալիս կազմողին ավելի լավ հավաքել կոդ, երբ համեմատությունն ու փոխանակումը օգտագործվում են օղակում:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Մի ցուցիչ է պահում ցուցիչը, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
    ///
    /// Վերադարձի արժեքը արդյունք է, որը ցույց է տալիս ՝ արդյոք նոր արժեքը գրվա՞ծ է, թե՞ պարունակում է նախորդ արժեքը:
    /// Հաջողության դեպքում երաշխավորված է, որ այս արժեքը հավասար կլինի `current`-ին:
    ///
    /// `compare_exchange` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
    /// `success` նկարագրում է կարդալ-փոփոխել-գրել գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում `current`-ի հետ համեմատության հաջողության դեպքում:
    /// `failure` նկարագրում է բեռի գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում, երբ համեմատությունը ձախողվում է:
    /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`] է դարձնում այս գործողության մաս, իսկ [`Release`]-ի օգտագործումը հաջող բեռը դարձնում է [`Relaxed`]:
    ///
    /// Անսարքության պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն պլատֆորմներում, որոնք աջակցում են ատոմային գործողությունները ցուցիչների վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Մի ցուցիչ է պահում ցուցիչը, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
    ///
    /// Ի տարբերություն [`AtomicPtr::compare_exchange`]-ի, այս գործառույթը թույլատրվում է կեղծորեն ձախողվել նույնիսկ համեմատության հաջողության դեպքում, ինչը կարող է հանգեցնել որոշ պլատֆորմների ավելի արդյունավետ կոդի:
    ///
    /// Վերադարձի արժեքը արդյունք է, որը ցույց է տալիս ՝ արդյոք նոր արժեքը գրվա՞ծ է, թե՞ պարունակում է նախորդ արժեքը:
    ///
    /// `compare_exchange_weak` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
    /// `success` նկարագրում է կարդալ-փոփոխել-գրել գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում `current`-ի հետ համեմատության հաջողության դեպքում:
    /// `failure` նկարագրում է բեռի գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում, երբ համեմատությունը ձախողվում է:
    /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`] է դարձնում այս գործողության մաս, իսկ [`Release`]-ի օգտագործումը հաջող բեռը դարձնում է [`Relaxed`]:
    /// Անսարքության պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն պլատֆորմներում, որոնք աջակցում են ատոմային գործողությունները ցուցիչների վրա:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Այս ներքինն անվտանգ չէ, քանի որ այն գործում է հում սլաքի վրա
        // բայց մենք հաստատ գիտենք, որ ցուցիչը վավեր է (մենք այն հենց նոր ստացանք `UnsafeCell`-ից, որը մենք ունենք հղումով), և ատոմային գործողությունն ինքնին թույլ է տալիս մեզ անվնաս փոխել `UnsafeCell` պարունակությունը:
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Ստանում է արժեքը և դրանում կիրառում գործառույթ, որը վերադարձնում է կամայական նոր արժեք: Վերադարձնում է `Result`-ի `Result`-ը, եթե գործառույթը վերադարձնում է `Some(_)`, այլապես `Err(previous_value)`:
    ///
    /// Note: Սա կարող է գործառույթը մի քանի անգամ զանգահարել, եթե այդ ընթացքում արժեքը փոխվել է այլ թեմաներից, այնքան ժամանակ, քանի դեռ գործառույթը վերադարձնում է `Some(_)`, բայց գործառույթը կիրառվելու է միայն մեկ անգամ պահված արժեքի վրա:
    ///
    ///
    /// `fetch_update` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
    /// Առաջինը նկարագրում է պահանջվող պատվերը, երբ գործողությունը վերջապես հաջողվում է, իսկ երկրորդը նկարագրում է բեռների համար անհրաժեշտ պատվերը:
    /// Դրանք համապատասխանում են համապատասխանաբար [`AtomicPtr::compare_exchange`]-ի հաջողության և ձախողման պատվերներին:
    ///
    /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`]-ի այս գործողության մաս է դարձնում, իսկ [`Release`]-ի օգտագործումը վերջին հաջող բեռը դարձնում է [`Relaxed`]:
    /// (failed) բեռնման պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
    ///
    /// **Note:** Այս մեթոդը հասանելի է միայն պլատֆորմներում, որոնք աջակցում են ատոմային գործողությունները ցուցիչների վրա:
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool`-ը փոխակերպում է `AtomicBool`-ի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Այս մակրոտն ի վերջո որոշ ճարտարապետությունների վրա չօգտագործված է:
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Ամբողջ թվատեսակ, որը կարող է ապահով կերպով բաժանվել թելերի միջև:
        ///
        /// Այս տեսակն ունի նույն հիշողությունը ներկայացուցչությունը, ինչ հիմքում ընկած ամբողջ թիվն է, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Ատոմային տիպերի և ոչ ատոմային տիպերի տարբերությունների, ինչպես նաև այս տիպի դյուրակիրության մասին տեղեկություններ ստանալու համար տես [module-level documentation]:
        ///
        ///
        /// **Note:** Այս տեսակը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային բեռները և ['պահեստները
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Ատոմային ամբողջ թիվ, որը սկզբնավորվել է `0`-ով:
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Ուղարկումը անուղղակիորեն իրականացվում է:
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Ստեղծում է նոր ատոմային ամբողջ թիվ:
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Վերադարձնում է փոփոխական հղում հիմքում ընկած ամբողջ թվին:
            ///
            /// Սա անվտանգ է, քանի որ փոփոխական տեղեկանքը երաշխավորում է, որ ոչ մի այլ թեմա միաժամանակ չի մուտք գործում ատոմային տվյալներ:
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// թող մի քանի_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// պնդել_eq! (ոմանք_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - փոփոխական տեղեկանքը երաշխավորում է եզակի սեփականություն:
                //  - `$int_type`-ի և `Self`-ի հավասարեցումը նույնն է, ինչպես խոստացել է $cfg_align-ը և վերը ստուգված:
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Սպառում է ատոմը և վերադարձնում պարունակվող արժեքը:
            ///
            /// Սա անվտանգ է, քանի որ `self`- ով արժեքն անցնելը երաշխավորում է, որ ոչ մի այլ թել միաժամանակ չեն մուտք գործում ատոմային տվյալներ:
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Ատոմային ամբողջ թվից բեռ է բերում:
            ///
            /// `load` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
            /// Հնարավոր արժեքներն են [`SeqCst`], [`Acquire`] և [`Relaxed`]:
            ///
            /// # Panics
            ///
            /// Panics եթե `order`-ը [`Release`] կամ [`AcqRel`] է:
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Արժեք է պահում ատոմային ամբողջ թվին:
            ///
            /// `store` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
            ///  Հնարավոր արժեքներն են [`SeqCst`], [`Release`] և [`Relaxed`]:
            ///
            /// # Panics
            ///
            /// Panics եթե `order`-ը [`Acquire`] կամ [`AcqRel`] է:
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Արժեքը պահում է ատոմային ամբողջ թվում ՝ վերադարձնելով նախորդ արժեքը:
            ///
            /// `swap` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Արժեքը պահում է ատոմային ամբողջ թվում, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
            ///
            /// Վերադարձի արժեքը միշտ նախորդ արժեքն է: Եթե այն հավասար է `current`-ին, ապա արժեքը թարմացվել է:
            ///
            /// `compare_and_swap` վերցնում է նաև [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը:
            /// Ուշադրություն դարձրեք, որ նույնիսկ [`AcqRel`]-ն օգտագործելիս գործողությունը կարող է ձախողվել, ուստի պարզապես կատարել `Acquire` բեռ, բայց չունեն `Release` իմաստաբանություն:
            ///
            /// [`Acquire`]-ի օգտագործումը խանութը [`Relaxed`]-ի մաս է դարձնում այս գործողության, եթե դա տեղի է ունենում, իսկ [`Release`]-ի օգտագործումը բեռի մասը դարձնում է [`Relaxed`]:
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Միգրացիա դեպի `compare_exchange` և `compare_exchange_weak`
            ///
            /// `compare_and_swap` համարժեք է `compare_exchange`-ին հիշողության պատվերների հետևյալ քարտեզագրմամբ.
            ///
            /// Բնօրինակ |Հաջողություն |Ձախողում
            /// -------- | ------- | -------
            /// Հանգիստ |Հանգիստ |Հանգիստ ձեռքբերում |Ձեռք բերել |Ձեռք բերեք թողարկման |Թողարկում |Հանգիստ AcqRel |AcqRel |Ձեռք բերեք SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` թույլատրվում է կեղծորեն ձախողվել նույնիսկ համեմատության հաջողության դեպքում, ինչը թույլ է տալիս կազմողին ավելի լավ հավաքել կոդ, երբ համեմատությունն ու փոխանակումը օգտագործվում են օղակում:
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Արժեքը պահում է ատոմային ամբողջ թվում, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
            ///
            /// Վերադարձի արժեքը արդյունք է, որը ցույց է տալիս ՝ արդյոք նոր արժեքը գրվա՞ծ է, թե՞ պարունակում է նախորդ արժեքը:
            /// Հաջողության դեպքում երաշխավորված է, որ այս արժեքը հավասար կլինի `current`-ին:
            ///
            /// `compare_exchange` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
            /// `success` նկարագրում է կարդալ-փոփոխել-գրել գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում `current`-ի հետ համեմատության հաջողության դեպքում:
            /// `failure` նկարագրում է բեռի գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում, երբ համեմատությունը ձախողվում է:
            /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`] է դարձնում այս գործողության մաս, իսկ [`Release`]-ի օգտագործումը հաջող բեռը դարձնում է [`Relaxed`]:
            ///
            /// Անսարքության պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Արժեքը պահում է ատոմային ամբողջ թվում, եթե ընթացիկ արժեքը նույնն է, ինչ `current` արժեքը:
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// այս գործառույթին թույլատրվում է կեղծորեն ձախողվել նույնիսկ համեմատության հաջողության դեպքում, ինչը կարող է հանգեցնել որոշ պլատֆորմների ավելի արդյունավետ կոդի:
            /// Վերադարձի արժեքը արդյունք է, որը ցույց է տալիս ՝ արդյոք նոր արժեքը գրվա՞ծ է, թե՞ պարունակում է նախորդ արժեքը:
            ///
            /// `compare_exchange_weak` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
            /// `success` նկարագրում է կարդալ-փոփոխել-գրել գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում `current`-ի հետ համեմատության հաջողության դեպքում:
            /// `failure` նկարագրում է բեռի գործողության համար անհրաժեշտ պատվերը, որը տեղի է ունենում, երբ համեմատությունը ձախողվում է:
            /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`] է դարձնում այս գործողության մաս, իսկ [`Release`]-ի օգտագործումը հաջող բեռը դարձնում է [`Relaxed`]:
            ///
            /// Անսարքության պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// թող mut հին= val.load(Ordering::Relaxed);
            /// հանգույց {թող նոր=հին * 2;
            ///     համապատասխանում է val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Ավելացնում է ընթացիկ արժեքին ՝ վերադարձնելով նախորդ արժեքը:
            ///
            /// Այս գործողությունը փաթաթվում է վարարման վրա:
            ///
            /// `fetch_add` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Հանվում է ընթացիկ արժեքից ՝ վերադարձնելով նախորդ արժեքը:
            ///
            /// Այս գործողությունը փաթաթվում է վարարման վրա:
            ///
            /// `fetch_sub` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" ՝ ընթացիկ արժեքով:
            ///
            /// Կատարում է բիթային "and" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը սահմանում արդյունքի:
            ///
            /// Վերադարձնում է նախորդ արժեքը:
            ///
            /// `fetch_and` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" ՝ ընթացիկ արժեքով:
            ///
            /// Կատարում է բիթային "nand" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը սահմանում արդյունքի:
            ///
            /// Վերադարձնում է նախորդ արժեքը:
            ///
            /// `fetch_nand` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" ՝ ընթացիկ արժեքով:
            ///
            /// Կատարում է բիթային "or" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը սահմանում արդյունքի:
            ///
            /// Վերադարձնում է նախորդ արժեքը:
            ///
            /// `fetch_or` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" ՝ ընթացիկ արժեքով:
            ///
            /// Կատարում է բիթային "xor" գործողություն ընթացիկ արժեքի և `val` փաստարկի վրա և նոր արժեքը սահմանում արդյունքի:
            ///
            /// Վերադարձնում է նախորդ արժեքը:
            ///
            /// `fetch_xor` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Ստանում է արժեքը և դրանում կիրառում գործառույթ, որը վերադարձնում է կամայական նոր արժեք: Վերադարձնում է `Result`-ի `Result`-ը, եթե գործառույթը վերադարձնում է `Some(_)`, այլապես `Err(previous_value)`:
            ///
            /// Note: Սա կարող է գործառույթը մի քանի անգամ զանգահարել, եթե այդ ընթացքում արժեքը փոխվել է այլ թեմաներից, այնքան ժամանակ, քանի դեռ գործառույթը վերադարձնում է `Some(_)`, բայց գործառույթը կիրառվելու է միայն մեկ անգամ պահված արժեքի վրա:
            ///
            ///
            /// `fetch_update` տանում է երկու [`Ordering`] արգումենտ ՝ այս գործողության հիշողության կարգը նկարագրելու համար:
            /// Առաջինը նկարագրում է պահանջվող պատվերը, երբ գործողությունը վերջապես հաջողվում է, իսկ երկրորդը նկարագրում է բեռների համար անհրաժեշտ պատվերը: Դրանք համապատասխանում են հաջողության և ձախողումների պատվերներին
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`]-ը որպես հաջողության պատվեր օգտագործելը խանութը [`Relaxed`]-ի այս գործողության մաս է դարձնում, իսկ [`Release`]-ի օգտագործումը վերջին հաջող բեռը դարձնում է [`Relaxed`]:
            /// (failed) բեռնման պատվերը կարող է լինել միայն [`SeqCst`], [`Acquire`] կամ [`Relaxed`] և պետք է համարժեք լինի կամ ավելի թույլ լինի, քան հաջողության պատվերը:
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Պատվիրել: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Պատվիրել: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Առավելագույնը ընթացիկ արժեքով:
            ///
            /// Գտնում է ընթացիկ արժեքի առավելագույնը և `val` փաստարկը և նոր արժեքը դնում արդյունքի:
            ///
            /// Վերադարձնում է նախորդ արժեքը:
            ///
            /// `fetch_max` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// թող բար=42;
            /// թող max_foo=foo.fetch_max (բար, Ordering::SeqCst).max(bar);
            /// պնդել! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Նվազագույնը ընթացիկ արժեքով:
            ///
            /// Գտնում է ընթացիկ արժեքի նվազագույնը և `val` փաստարկը և նոր արժեքը դնում արդյունքի:
            ///
            /// Վերադարձնում է նախորդ արժեքը:
            ///
            /// `fetch_min` վերցնում է [`Ordering`] փաստարկ, որը նկարագրում է այս գործողության հիշողության կարգը: Պատվիրելու բոլոր ռեժիմները հնարավոր են:
            /// Նկատի ունեցեք, որ [`Acquire`]-ի օգտագործումը խանութը դարձնում է [`Relaxed`] այս գործողության մի մասը, իսկ [`Release`]-ի օգտագործումը բեռի մասը [`Relaxed`] է դարձնում:
            ///
            ///
            /// **Նշում**. Այս մեթոդը հասանելի է միայն այն պլատֆորմների վրա, որոնք աջակցում են ատոմային գործողությունները
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// թող բար=12;
            /// թող min_foo=foo.fetch_min (բար, Ordering::SeqCst).min(bar);
            /// պնդել_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Տվյալների մրցավազքը կանխվում է ատոմային բնիկների կողմից:
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Վերադարձնում է փոփոխվող ցուցիչը հիմքում ընկած ամբողջ թվին:
            ///
            /// Արդյունքում ստացված ամբողջ թիվի վրա ոչ ատոմային ընթերցումներ և գրումներ կատարելը կարող է լինել տվյալների մրցավազք:
            /// Այս մեթոդը հիմնականում օգտակար է FFI-ի համար, որտեղ կարող է օգտագործվել ֆունկցիայի ստորագրությունը
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// `*mut` ցուցիչի վերադարձը այս ատոմի ընդհանուր հղումից անվտանգ է, քանի որ ատոմային տեսակները աշխատում են ներքին փոփոխականության հետ:
            /// Ատոմի բոլոր փոփոխությունները փոխում են արժեքը ընդհանուր տեղեկանքի միջոցով, և դա կարող են ապահով լինել, քանի դեռ դրանք օգտագործում են ատոմային գործողություններ:
            /// Վերադարձված հում սլաքի ցանկացած օգտագործման համար անհրաժեշտ է `unsafe` բլոկ և դեռ պետք է պահպանել նույն սահմանափակումը. Դրա վրա գործողությունները պետք է լինեն ատոմային:
            ///
            ///
            /// # Examples
            ///
            /// «անտեսեք (extern-declaration)-ը
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// արտաքին "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ապահով, քանի դեռ `my_atomic_op`-ն ատոմային է:
            /// անապահով {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_store`-ի անվտանգության պայմանագիրը:
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_load`-ի անվտանգության պայմանագիրը:
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_swap`-ի անվտանգության պայմանագիրը:
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Վերադարձնում է նախորդ արժեքը (ինչպես __sync_fetch_and_add):
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_add`-ի անվտանգության պայմանագիրը:
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Վերադարձնում է նախորդ արժեքը (ինչպես __sync_fetch_and_sub):
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_sub`-ի անվտանգության պայմանագիրը:
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_compare_exchange`-ի անվտանգության պայմանագիրը:
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_compare_exchange_weak`-ի անվտանգության պայմանագիրը:
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_and`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_nand`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_or`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_xor`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// վերադարձնում է առավելագույն արժեքը (ստորագրված համեմատություն)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_max`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// վերադարձնում է նվազագույն արժեքը (ստորագրված համեմատություն)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_min`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// վերադարձնում է առավելագույն արժեքը (անստորագիր համեմատություն)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_umax`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// վերադարձնում է նվազագույն արժեքը (անստորագիր համեմատություն)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Զանգահարողը պետք է պահպանի `atomic_umin`-ի անվտանգության պայմանագիրը
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Ատոմային ցանկապատ:
///
/// Կախված նշված կարգից ՝ ցանկապատը խանգարում է կազմողին և պրոցեսորին վերադասավորել իր շուրջը հիշողության որոշակի գործողություններ:
/// Դա ստեղծում է սինխրոնիզացված հարաբերություններ դրա և ատոմային գործողությունների կամ այլ թելերի ցանկապատերի հետ:
///
/// 'A' պարիսպը, որն ունի (առնվազն) [`Release`] իմաստաբանություն պատվիրող, սինխրոնիզացված է 'B' ցանկապատի հետ (առնվազն) [`Acquire`] իմաստաբանությամբ, եթե և միայն այն դեպքում, եթե առկա են X և Y գործողություններ, որոնք երկուսն էլ գործում են որոշ 'M' ատոմային օբյեկտի վրա, այնպես, որ Ա-ն հաջորդականորեն սահմանվի X, Y համաժամացվում է նախքան B-ն, իսկ Y-ն դիտում է M-ի փոփոխությունը:
/// Սա ապահովում է A-ի և B-ի միջև եղած կախվածությունը:
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Ատոմային գործողությունները [`Release`] կամ [`Acquire`] իմաստաբանությամբ կարող են նաև համաժամացվել ցանկապատի հետ:
///
/// 00անկապատը, որն ունի [`SeqCst`] կարգավորում, բացի [`Acquire`] և [`Release`] իմաստաբանություն ունենալուց, մասնակցում է [`SeqCst`] մյուս գործողությունների և (կամ) ցանկապատերի գլոբալ ծրագրի կարգին:
///
/// Ընդունում է [`Acquire`], [`Release`], [`AcqRel`] և [`SeqCst`] պատվերները:
///
/// # Panics
///
/// Panics եթե `order` [`Relaxed`] է:
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Փոխադարձ բացառման պարզունակ ՝ հիմնված սպինլոկի վրա:
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Սպասեք, մինչ հին արժեքը լինի `false`:
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Այս ցանկապատը սինխրոնիզացված է խանութի հետ `unlock`-ում:
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ատոմային ցանկապատի օգտագործումը անվտանգ է:
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Կազմողի հիշողության ցանկապատ:
///
/// `compiler_fence` չի արտանետում որևէ մեքենայական կոդ, բայց սահմանափակում է հիշողության տեսակները, որոնք թույլատրվում է կատարել կազմիչը: Մասնավորապես, կախված տվյալ [`Ordering`] իմաստաբանությունից, կազմողը կարող է արգելվել ընթերցումներ կամ գրեր տեղափոխել `compiler_fence` զանգի մյուս կողմին զանգից առաջ կամ հետո:Նկատի ունեցեք, որ դա **չի** խանգարում *ապարատային համակարգչին* այդպիսի վերադասավորում կատարել:
///
/// Սա խնդիր չէ մեկ թեմա ունեցող, կատարման համատեքստում, բայց երբ այլ թեմաները կարող են միաժամանակ փոփոխել հիշողությունը, պահանջվում են ավելի ուժեղ համաժամացման պարզունակներ, ինչպիսիք են [`fence`]-ը:
///
/// Պատվերի տարբեր իմաստաբանությամբ կանխված վերադասավորումն է.
///
///  - [`SeqCst`]-ի հետ, այս կետում ընթերցումների և գրերի վերադասավորում չի թույլատրվում:
///  - [`Release`]-ով, նախորդ ընթերցումները և գրառումները չեն կարող տեղափոխվել հաջորդ գրվածքներից:
///  - [`Acquire`]-ի հետ, հետագա ընթերցումները և գրառումները չեն կարող տեղափոխվել նախորդ ընթերցումներից առաջ:
///  - [`AcqRel`]-ի հետ, վերը նշված երկու կանոններն էլ կիրառվում են:
///
/// `compiler_fence` ընդհանուր առմամբ օգտակար է միայն այն բանի համար, որ թելը չմրցի *իր հետ*: Այսինքն, եթե տվյալ շարանը կատարում է մեկ ծածկագիր, այնուհետև ընդհատվում է, և սկսում է իրականացնել ծածկագիր այլուր (մինչդեռ դեռ նույն թեմայում է, և հայեցակարգային առումով մնում է նույն միջուկում):Ավանդական ծրագրերում դա կարող է առաջանալ միայն այն դեպքում, երբ ազդանշանի կարգավարը գրանցվում է:
/// Ավելի ցածր մակարդակի ծածկագրում նման իրավիճակներ կարող են առաջանալ նաև ընդհատումների գործարկման ժամանակ, կանաչ թելեր նախապատվիրումով իրականացնելիս և այլն:
/// Հետաքրքրասեր ընթերցողներին խրախուսվում է կարդալ Linux միջուկի [memory barriers]-ի քննարկումը:
///
/// # Panics
///
/// Panics եթե `order` [`Relaxed`] է:
///
/// # Examples
///
/// Առանց `compiler_fence`-ի, հետևյալ ծածկագրում նշված `assert_eq!`-ը * ** երաշխավորված չէ հաջողության հասնել, չնայած այն բանին, որ ամեն ինչ տեղի է ունենում մեկ թեմայում:
/// Որպեսզի տեսնեք, թե ինչու, հիշեք, որ կազմողն ազատ է խանութները փոխել `IMPORTANT_VARIABLE` և `IS_READ`, քանի որ դրանք երկուսն էլ `Ordering::Relaxed` են: Եթե դա արվում է, և ազդանշանի կարգավորիչը կանչվում է `IS_READY`-ի թարմացումից անմիջապես հետո, ապա ազդանշանի կառավարիչը կտեսնի `IS_READY=1`, բայց `IMPORTANT_VARIABLE=0`:
/// Օգտագործելով `compiler_fence` ՝ այս իրավիճակը վերականգնում է:
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // կանխել ավելի վաղ գրերի տեղափոխումը այս կետից այն կողմ
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Ատոմային ցանկապատի օգտագործումը անվտանգ է:
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Արձանագրում է պրոցեսորին, որ գտնվում է զբաղված սպասման պտտվող օղակի ներսում («պտտվող կողպեք»):
///
/// Այս գործառույթը մաշված է հօգուտ [`hint::spin_loop`]-ի:
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}