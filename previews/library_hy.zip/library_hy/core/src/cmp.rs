//! Պատվերի և համեմատության ֆունկցիոնալությունը:
//!
//! Այս մոդուլը պարունակում է տարբեր գործիքներ ՝ արժեքները դասավորելու և համեմատելու համար: Արդյունքում:
//!
//! * [`Eq`] և [`PartialEq`]-ը traits են, որոնք թույլ են տալիս համապատասխանաբար սահմանել ընդհանուր և մասնակի հավասարություն արժեքների միջև:
//! Դրանց իրականացումը ծանրաբեռնում է `==` և `!=` օպերատորները:
//! * [`Ord`] և [`PartialOrd`]-ը traits են, որոնք թույլ են տալիս համապատասխանաբար սահմանել ընդհանուր և մասնակի դասավորություններ արժեքների միջև:
//!
//! Դրանց իրականացումը ծանրաբեռնում է `<`, `<=`, `>` և `>=` օպերատորները:
//! * [`Ordering`] [`Ord`] և [`PartialOrd`] հիմնական ֆունկցիաներով վերադարձված թվեր է և նկարագրում է պատվեր:
//! * [`Reverse`] կառուցվածք է, որը թույլ է տալիս հեշտությամբ հետ շրջել պատվերը:
//! * [`max`] և [`min`]-ը գործառույթներ են, որոնք կառուցվում են [`Ord`]-ից և թույլ են տալիս գտնել առավելագույնը կամ նվազագույնը երկու արժեք:
//!
//! Լրացուցիչ մանրամասների համար տե՛ս ցուցակի յուրաքանչյուր կետի համապատասխան փաստաթղթերը:
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait հավասարության համեմատության համար, որոնք [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) են:
///
/// Այս trait-ը թույլ է տալիս մասնակի հավասարություն, այն տեսակների համար, որոնք չունեն լիարժեք համարժեքության կապ:
/// Օրինակ ՝ լողացող կետի `NaN != NaN` համարներում, այնպես որ լողացող կետի տեսակները իրականացնում են `PartialEq`, բայց ոչ [`trait@Eq`]:
///
/// Ձևականորեն հավասարությունը պետք է լինի (բոլոր `a`, `b`, `c` տիպի `A`, `B`, `C` տիպի համար) ՝
///
/// - **սիմետրիկ**. Եթե `A: PartialEq<B>` և `B: PartialEq<A>`, ապա **`a==b` ենթադրում է`b==a`**;և
///
/// - **Տրանզիտիվ**. Եթե `A: PartialEq<B>` և `B: PartialEq<C>` և `A:
///   Մասնակի հավասար<C>`, ապա **` a==b`և `b == c`-ը ենթադրում է`a==c`**:
///
/// Նշենք, որ `B: PartialEq<A>` (symmetric) և `A: PartialEq<C>` (transitive) ազդանշանները ստիպված չեն գոյություն ունենալ, բայց այդ պահանջները կիրառվում են, երբ գոյություն ունեն:
///
/// ## Derivable
///
/// Այս trait-ը կարող է օգտագործվել `#[derive]`-ի հետ: Երբ ստացվում է ՝ d ստատների վրա, երկու դեպք հավասար են, եթե բոլոր դաշտերը հավասար են, և հավասար չեն, եթե որևէ դաշտեր հավասար չեն:Երբ enum-ից `ածանցյալ` d, յուրաքանչյուր տարբերակ հավասար է իրեն և հավասար չէ մյուս տարբերակներին:
///
/// ## Ինչպե՞ս կարող եմ իրականացնել `PartialEq`-ը:
///
/// `PartialEq` պահանջում է միայն [`eq`] մեթոդի ներդրում;[`ne`]-ը դրա տեսանկյունից սահմանվում է լռելյայն: [`ne`]*-ի ցանկացած ձեռքով իրականացումը պետք է* հարգի [`eq`]-ի [`ne`]-ի խիստ հակադարձ կանոնը.այսինքն ՝ `!(a == b)` եթե և միայն եթե `a != b`:
///
/// `PartialEq`, [`PartialOrd`] և [`Ord`]*-ի իրականացումը* պետք է * համաձայնեցված լինեն միմյանց հետ: Դյուրին է պատահաբար ստիպել նրանց չհամաձայնել `դուրս բերելով traits-ի որոշ մասը և ձեռքով իրականացնելով մյուսները:
///
/// Դոմենի իրականացման օրինակ, որի դեպքում երկու գիրք համարվում են նույն գիրքը, եթե դրանց ISBN-ը համընկնում է, նույնիսկ եթե ձևաչափերը տարբեր են.
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Ինչպե՞ս կարող եմ համեմատել երկու տարբեր տեսակներ:
///
/// Այն տեսակը, որի հետ կարող եք համեմատվել, վերահսկվում է «PartialEq» տեսակի պարամետրով:
/// Օրինակ ՝ եկեք մի փոքր շտկենք մեր նախորդ կոդը ՝
///
/// ```
/// // Ածանցումը իրականացնում է<BookFormat>==<BookFormat>համեմատություններ
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Իրականացնել<Book>==<BookFormat>համեմատություններ
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Իրականացնել<BookFormat>==<Book>համեմատություններ
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Փոխելով `impl PartialEq for Book`-ը `impl PartialEq<BookFormat> for Book`, մենք թույլ ենք տալիս `BookFormat`-ը համեմատել` Book's-ի հետ:
///
/// Վերը նշվածի նման համեմատությունը, որն անտեսում է կառուցվածքի որոշ դաշտեր, կարող է վտանգավոր լինել: Դա կարող է հեշտությամբ հանգեցնել մասնակի համարժեքության հարաբերության պահանջների ակամա խախտման:
/// Օրինակ, եթե մենք պահպանեինք `PartialEq<Book>`-ի վերոնշյալ X001-ի ներդրումը և `PartialEq<Book>`-ի համար ավելացնեինք `PartialEq<Book>`-ի իրականացում (կամ `#[derive]`-ի միջոցով կամ առաջին օրինակի ձեռքով կատարման միջոցով), ապա արդյունքը կխախտեր փոխունակությունը
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Այս մեթոդը ստուգում է, որ `self` և `other` արժեքները հավասար լինեն, և այն օգտագործվում է `==`-ի կողմից:
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Այս մեթոդը ստուգում է `!=`-ի համար:
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Ստացեք trait `PartialEq`-ի ազդակ առաջացնող մակրո:
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait հավասարության համեմատության համար, որոնք [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) են:
///
/// Սա նշանակում է, որ բացի `a == b`-ի և `a != b`-ի խիստ հակադարձ լինելուց, հավասարությունը պետք է լինի (բոլոր `a`, `b` և `c`-ի համար).
///
/// - reflexive: `a == a`;
/// - սիմետրիկ. `a == b`-ը ենթադրում է `b == a`;և
/// - անցումային. `a == b` և `b == c` ենթադրում է `a == c`:
///
/// Այս հատկությունը չի կարող ստուգվել կազմողի կողմից, և, հետևաբար, `Eq`-ը ենթադրում է [`PartialEq`], և չունի լրացուցիչ մեթոդներ:
///
/// ## Derivable
///
/// Այս trait-ը կարող է օգտագործվել `#[derive]`-ի հետ:
/// Երբ «ստացվում է» d, քանի որ `Eq`-ը չունի լրացուցիչ մեթոդներ, այն ընդամենը տեղեկացնում է կազմողին, որ սա համարժեքության հարաբերություն է, քան մասնակի համարժեքության հարաբերություն:
///
/// Նշենք, որ `derive` ռազմավարությունը պահանջում է, որ բոլոր դաշտերը `Eq` լինեն, ինչը միշտ չէ, որ ցանկալի է:
///
/// ## Ինչպե՞ս կարող եմ իրականացնել `Eq`-ը:
///
/// Եթե չեք կարող օգտագործել `derive` ռազմավարությունը, նշեք, որ ձեր տեսակը իրականացնում է `Eq`, որը չունի մեթոդներ.
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // այս մեթոդը օգտագործվում է բացառապես#[ստացված] կողմից պնդելու համար, որ տիպի յուրաքանչյուր բաղադրիչ իրականացնում է ինքն իրեն#[ածանցյալ], ներկայիս ստացող ենթակառուցվածքը նշանակում է կատարել այս պնդումը առանց trait-ի վրա մեթոդ օգտագործելու գրեթե անհնար է:
    //
    //
    // Դա երբեք չպետք է իրականացվի ձեռքով:
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Ստացեք trait `Eq`-ի ազդակ առաջացնող մակրո:
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: այս կառուցվածքն օգտագործվում է բացառապես#[derive]-ի կողմից
// պնդեք, որ տիպի յուրաքանչյուր բաղադրիչ իրականացնում է Eq.
//
// Այս կառուցվածքը երբեք չպետք է հայտնվի օգտվողի ծածկագրում:
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering`-ը երկու արժեքների համեմատության արդյունք է:
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Պատվեր, երբ համեմատված արժեքը մյուսից պակաս է:
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Պատվեր, երբ համեմատված արժեքը հավասար է մեկ այլի:
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Պատվեր, երբ համեմատված արժեքը ավելի մեծ է, քան մեկ այլ:
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Վերադարձնում է `true`, եթե պատվերը `Equal` տարբերակն է:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Վերադարձնում է `true`, եթե պատվերը `Equal` տարբերակ չէ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Վերադարձնում է `true`, եթե պատվերը `Less` տարբերակն է:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Վերադարձնում է `true`, եթե պատվերը `Greater` տարբերակն է:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Վերադարձնում է `true`, եթե պատվիրումը կամ `Less` է, կամ `Equal` տարբերակ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Վերադարձնում է `true`, եթե պատվիրումը կամ `Greater` է, կամ `Equal` տարբերակ:
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Վերափոխում է `Ordering`-ը:
    ///
    /// * `Less` դառնում է `Greater`:
    /// * `Greater` դառնում է `Less`:
    /// * `Equal` դառնում է `Equal`:
    ///
    /// # Examples
    ///
    /// Հիմնական վարք:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Այս մեթոդը կարող է օգտագործվել համեմատությունը վերացնելու համար.
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // տեսակավորել զանգվածը ամենամեծից փոքր:
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Շղթաներով երկու պատվեր:
    ///
    /// Վերադարձնում է `self`-ը, երբ `Equal` չէ: Հակառակ դեպքում վերադարձնում է `other`:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Շղթաներով դասավորվածությունը տրված գործառույթով:
    ///
    /// Վերադարձնում է `self`-ը, երբ `Equal` չէ:
    /// Հակառակ դեպքում զանգահարում է `f` և վերադարձնում արդյունքը:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Հակադարձ կարգավորման օգնական կառուցվածք:
///
/// Այս կառուցվածքը օգնական է, որն օգտագործվում է [`Vec::sort_by_key`]-ի նման գործառույթների հետ և կարող է օգտագործվել ստեղնաշարի մի մասը հետադարձելու համար:
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait [total order](https://en.wikipedia.org/wiki/Total_order) կազմող տեսակների համար:
///
/// Պատվերը ընդհանուր պատվեր է, եթե կա (բոլոր `a`, `b` և `c`-ի համար).
///
/// - ընդհանուր և ասիմետրիկ. `a < b`, `a == b` կամ `a > b`- ից ճշգրիտ մեկը.և
/// - անցումային, `a < b` և `b < c` ենթադրում է `a < c`: Նույնը պետք է լինի ինչպես `==`-ի, այնպես էլ `>`-ի համար:
///
/// ## Derivable
///
/// Այս trait-ը կարող է օգտագործվել `#[derive]`-ի հետ:
/// Երբ ստացվում է ՝ փայտերի վրա, այն արտադրելու է [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) պատվեր ՝ հիմնված կառուցվածքի անդամների վերևից ներքև հայտարարագրի կարգի վրա:
///
/// Երբ enum-ից «բխում են», տարբերակները կարգվում են ըստ վերևից ներքև խտրական կարգի:
///
/// ## Բառաբանական համեմատություն
///
/// Բառաբանական համեմատությունը գործողություն է հետևյալ հատկություններով.
///  - Երկու հաջորդականություն համեմատվում է տարր առ տարր:
///  - Առաջին անհամապատասխանության տարրը սահմանում է, թե որ հաջորդականությունն է բառարանագրորեն պակաս կամ մեծ, քան մյուսը:
///  - Եթե մի հաջորդականություն մյուսի նախածանց է, ապա ավելի կարճ հաջորդականությունը բառարանագրորեն պակաս է մյուսից:
///  - Եթե երկու հաջորդականություն ունեն համարժեք տարրեր և ունեն նույն երկարությունը, ապա հաջորդականությունները բառարանագրորեն հավասար են:
///  - Դատարկ հաջորդականությունը բառարանագրորեն պակաս է, քան ցանկացած ոչ դատարկ հաջորդականություն:
///  - Երկու դատարկ հաջորդականություն բառարանագրորեն հավասար են:
///
/// ## Ինչպե՞ս կարող եմ իրականացնել `Ord`-ը:
///
/// `Ord` պահանջում է, որ տեսակը լինի նաև [`PartialOrd`] և [`Eq`] (որը պահանջում է [`PartialEq`]):
///
/// Դրանից հետո դուք պետք է սահմանեք իրականացում [`cmp`]-ի համար: Կարող եք օգտակար համարել օգտագործել [`cmp`] ձեր տեսակի դաշտերում:
///
/// [`PartialEq`], [`PartialOrd`] և `Ord`*-ի իրականացումը* պետք է * համաձայնեցված լինեն միմյանց հետ:
/// Այսինքն ՝ `a.cmp(b) == Ordering::Equal` եթե և միայն եթե `a == b` և `Some(a.cmp(b)) == a.partial_cmp(b)` բոլոր `a` և `b` համարների համար:
/// Դյուրին է պատահաբար ստիպել նրանց չհամաձայնել `դուրս բերելով traits-ի որոշ մասը և ձեռքով իրականացնելով մյուսները:
///
/// Ահա մի օրինակ, երբ ցանկանում եք դասավորել մարդկանց միայն բարձրության վրա ՝ հաշվի չառնելով `id` և `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Այս մեթոդը վերադարձնում է [`Ordering`] `self`-ի և `other`-ի միջև:
    ///
    /// Ըստ պայմանագրի, `self.cmp(&other)`-ը վերադարձնում է `self <operator> other` արտահայտությանը համապատասխանող հերթականությունը, եթե ճիշտ է:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Համեմատում և վերադարձնում է առավելագույնը երկու արժեք:
    ///
    /// Վերադարձնում է երկրորդ փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Համեմատում և վերադարձնում է երկու արժեքի նվազագույնը:
    ///
    /// Վերադարձնում է առաջին փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Սահմանափակեք արժեքը որոշակի ընդմիջումով:
    ///
    /// Վերադարձնում է `max`-ը, եթե `self`-ը `max`-ից մեծ է, և `min`-ը, եթե `self`-ը `min`-ից փոքր է:
    /// Հակառակ դեպքում սա վերադարձնում է `self`:
    ///
    /// # Panics
    ///
    /// Panics եթե `min > max`:
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Ստացեք trait `Ord`-ի ազդակ առաջացնող մակրո:
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait այն արժեքների համար, որոնք կարելի է համեմատել տեսակավորման կարգի համար:
///
/// Համեմատությունը պետք է բավարարի բոլոր `a`, `b` և `c` համարների համար.
///
/// - ասիմետրիա. եթե `a < b` ապա `!(a > b)`, ինչպես նաև `a > b` ենթադրում է `!(a < b)`;և
/// - փոխունակություն. `a < b` և `b < c` ենթադրում է `a < c`: Նույնը պետք է լինի ինչպես `==`-ի, այնպես էլ `>`-ի համար:
///
/// Նշենք, որ այս պահանջները նշանակում են, որ trait-ն ինքը պետք է իրականացվի սիմետրիկ և անցողիկ. Եթե `T: PartialOrd<U>` և `U: PartialOrd<V>`, ապա `U: PartialOrd<T>` և `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Այս trait-ը կարող է օգտագործվել `#[derive]`-ի հետ: Երբ բխում է ՝ փայտերից, այն արտադրելու է բառարանագրական դասավորում ՝ կառուցվածքի անդամների վերևից ներքև հայտարարագրի կարգի հիման վրա:
/// Երբ enum-ից «բխում են», տարբերակները կարգվում են ըստ վերևից ներքև խտրական կարգի:
///
/// ## Ինչպե՞ս կարող եմ իրականացնել `PartialOrd`-ը:
///
/// `PartialOrd` պահանջում է միայն [`partial_cmp`] մեթոդի իրականացում, իսկ մյուսները ՝ ստացված լռելյայն ներդրումներից:
///
/// Այնուամենայնիվ, մնացածը հնարավոր է իրականացնել առանձին `այն տիպերի համար, որոնք ընդհանուր կարգ չունեն:
/// Օրինակ ՝ լողացող կետերի համարների համար `NaN < 0 == false` և `NaN >= 0 == false` (տես.
/// IEEE 754-2008 հատված 5.11):
///
/// `PartialOrd` պահանջում է, որ ձեր տեսակը լինի [`PartialEq`]:
///
/// [`PartialEq`], `PartialOrd` և [`Ord`]*-ի իրականացումը* պետք է * համաձայնեցված լինեն միմյանց հետ:
/// Դյուրին է պատահաբար ստիպել նրանց չհամաձայնել `դուրս բերելով traits-ի որոշ մասը և ձեռքով իրականացնելով մյուսները:
///
/// Եթե ձեր տեսակը [`Ord`] է, կարող եք իրականացնել [`partial_cmp`] ՝ օգտագործելով [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Կարող եք նաև օգտակար համարել օգտագործել [`partial_cmp`] ձեր տեսակի դաշտերում:
/// Ահա `Person` տիպերի օրինակ, որոնք ունեն լողացող կետով `height` դաշտ, որը միակ դաշտն է, որն օգտագործվում է տեսակավորման համար.
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Այս մեթոդը վերադարձնում է պատվեր `self` և `other` արժեքների միջև, եթե գոյություն ունի:
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Երբ համեմատությունն անհնար է.
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Այս մեթոդը ավելի քիչ է փորձարկում, քան (`self` և `other`) և օգտագործվում է `<` օպերատորի կողմից:
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Այս մեթոդը փորձարկում է (`self` և `other` համարների համար պակաս կամ հավասար) և օգտագործվում է `<=` օպերատորի կողմից:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Այս մեթոդը ավելի մեծ է, քան (`self` և `other`-ի համար) և օգտագործվում է `>` օպերատորի կողմից:
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Այս մեթոդը ավելի մեծ է կամ հավասար (`self` և `other`-ի համար) և օգտագործվում է `>=` օպերատորի կողմից:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Ստացեք trait `PartialOrd`-ի ազդակ առաջացնող մակրո:
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Համեմատում և վերադարձնում է երկու արժեքի նվազագույնը:
///
/// Վերադարձնում է առաջին փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
///
/// Ներքինում օգտագործում է [`Ord::min`] կեղծանուն:
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Վերադարձնում է երկու նվազագույն արժեքները `նշված համեմատության գործառույթի նկատմամբ:
///
/// Վերադարձնում է առաջին փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Վերադարձնում է այն տարրը, որը տալիս է նվազագույն արժեքը նշված գործառույթից:
///
/// Վերադարձնում է առաջին փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Համեմատում և վերադարձնում է առավելագույնը երկու արժեք:
///
/// Վերադարձնում է երկրորդ փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
///
/// Ներքինում օգտագործում է [`Ord::max`] կեղծանուն:
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Վերադարձնում է առավելագույնը երկու արժեք `կապված նշված համեմատության գործառույթի հետ:
///
/// Վերադարձնում է երկրորդ փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Վերադարձնում է այն տարրը, որը տալիս է առավելագույն արժեքը նշված գործառույթից:
///
/// Վերադարձնում է երկրորդ փաստարկը, եթե համեմատության արդյունքում որոշվում է, որ դրանք հավասար են:
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// PartialEq, Eq, PartialOrd և Order-ի իրականացումը պարզունակ տիպերի համար
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Այստեղ կարգը կարևոր է առավել օպտիմալ հավաքույթ առաջացնելու համար:
                    // Տե՛ս <https://github.com/rust-lang/rust/issues/63758> հավելյալ տեղեկությունների համար:
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8-ի ձուլումը և տարբերությունը Կարգավորման վերածելը առաջացնում է ավելի օպտիմալ հավաքույթ:
            //
            // Տե՛ս <https://github.com/rust-lang/rust/issues/66780> հավելյալ տեղեկությունների համար:
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. bool-ը, քանի որ i8 վերադարձնում է 0 կամ 1, այնպես որ տարբերությունը չի կարող լինել այլ բան
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &ցուցիչներ

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}