//! SipHash-ի իրականացում:

#![allow(deprecated)] // այս մոդուլի տեսակները մաշված են

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash 1-3-ի իրականացումը:
///
/// Սա ներկայումս ստանդարտ գրադարանի կողմից օգտագործվող կանխադրման հաշմանդամ գործառույթն է (օրինակ, `collections::HashMap`-ն այն օգտագործում է լռելյայն):
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash 2-4-ի իրականացում:
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash 2-4-ի իրականացում:
///
/// See: <https://131002.net/siphash/>
///
/// SipHash-ը ընդհանուր նպատակի hashing գործառույթ է. Այն աշխատում է լավ արագությամբ (մրցունակ է Spooky-ի և City-ի հետ) և թույլ է տալիս ուժեղ _keyed_ կոտրում:
///
/// Սա հնարավորություն է տալիս կոճակի ձեր հեշ սեղանները ուժեղ RNG-ից հավաքել, ինչպիսին է [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html)-ը:
///
/// Չնայած SipHash ալգորիթմը, ընդհանուր առմամբ, ուժեղ է համարվում, այն նախատեսված չէ գաղտնագրման նպատակներով:
/// Որպես այդպիսին, այս իրականացման բոլոր գաղտնագրային օգտագործումները _strongly discouraged_ են:
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // քանի բայթ ենք մշակել
    state: State,  // հաշ պետություն
    tail: u64,     // չմշակված բայթեր le
    ntail: usize,  // քանի բայթ պոչում վավեր է
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2-ը և v1-ը, v3-ը զույգերով հայտնվում են ալգորիթմում, իսկ SipHash-ի simd ներդրումները կօգտագործեն vectors v02-ի և v13-ի:
    //
    // Տեղադրելով դրանք այս հերթականությամբ կառուցվածքում, կազմողը կարող է ինքնուրույն վերցնել ընդամենը մի քանի պարզ օպտիմիզացում:
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Բեյթային հոսքից բեռնում է ցանկալի տիպի ամբողջ թիվ ՝ ըստ հերթականության:
/// Օգտագործում է `copy_nonoverlapping` ՝ թույլ տալու համար, որ կոմպիլյատորը գեներացնի այն ամենաարդյունավետ միջոցը, հնարավոր է, չկարգավորված հասցեից այն բեռնելու համար:
///
///
/// Անվտանգ, քանի որ i..i+size_of(int_ty)-ում չստուգված ինդեքսավորում
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Բեռնում է u64 ՝ օգտագործելով մինչև 7 բայթ բայթ հատված:
/// Կարծես անշնորհք է, բայց տեղի ունեցող `copy_nonoverlapping` զանգերը (`load_int_le!`-ի միջոցով) բոլորն ունեն ֆիքսված չափեր և խուսափում են զանգահարել `memcpy`, ինչը լավ է արագության համար:
///
///
/// Անվտանգ, քանի որ. Սկզբից չստուգված ինդեքսավորումը..սկսել + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // ընթացիկ բայթերի ինդեքս (LSB-ից) u64 արտադրանքի մեջ
    let mut out = 0;
    if i + 3 < len {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `i`-ը չի կարող `len`-ից մեծ լինել, և զանգահարողը պետք է երաշխավորի
        // որ ինդեքսը սկսվի..սկսել + len-ը սահմանների մեջ է:
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նույնն է, ինչ վերևում:
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Նույնն է, ինչ վերևում:
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Ստեղծում է նոր `SipHasher` երկու նախնական ստեղներով, որոնք դրված են 0-ի վրա:
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Ստեղծում է `SipHasher`, որը բանալիներով կտրվում է տրամադրված ստեղներից:
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Ստեղծում է նոր `SipHasher13` երկու նախնական ստեղներով, որոնք դրված են 0-ի վրա:
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Ստեղծում է `SipHasher13`, որը բանալիներով կտրվում է տրամադրված ստեղներից:
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: Սահմանված չէ ամբողջ թվերի հեշացման մեթոդներ (`գրել_u *`, `write_i*`)
    // այս տեսակի համար:
    // Կարող ենք ավելացնել դրանք, պատճենել `short_write` ներդրումը librustc_data_structures/sip128.rs-ում և `write_u *`/`write_i*` մեթոդներ ավելացնել `SipHasher`, `SipHasher13` և `DefaultHasher`:
    //
    // Սա մեծապես կարագացներ այդ պահատուների կողմից ամբողջ թվերի խաշումը, որոշ հենանիշերի վրա կազմելու արագությունների փոքր-ինչ դանդաղեցման գնով:
    // Մանրամասների համար տե՛ս #69152:
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `cmp::min(length, needed)`-ը երաշխավորված է, որ չի լինի `length`-ից բարձր
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Բուֆերային պոչը այժմ ողողված է, մշակեք նոր մուտք:
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Քանի որ `len - left`-ը 8-ի տակ գտնվող ամենամեծ բազմապատիկն է
            // `len`, և քանի որ `i`-ը սկսվում է `needed`-ից, որտեղ `len`-ը `length - needed` է, երաշխավորված է, որ `i + 8`-ը պակաս կամ հավասար է `length`-ին:
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. `i`-ը այժմ `needed + len.div_euclid(8) * 8` է,
        // այնպես որ `i + left` = `needed + len` = `length`, որը ըստ սահմանման հավասար է `msg.len()`-ի:
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Ստեղծում է `Hasher<S>` երկու նախնական ստեղներով, որոնք դրված են 0-ի վրա:
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}