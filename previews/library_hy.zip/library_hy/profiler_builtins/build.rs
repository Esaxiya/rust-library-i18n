//! Կազմում է `compiler-rt` գրադարանի պրոֆիլային մասը:
//!
//! Մանրամասների համար տես build.rs-ը libcompiler_builtins crate-ի համար:

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` հրահանգները ներկայումս չեն արտանետվում և կառուցման սցենարը
    // չի կրկնվի այս աղբյուրի ֆայլերի կամ դրանցում ներառված վերնագրերի փոփոխությունների վրա:
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // Այս ֆայլը վերանվանվեց LLVM 10-ում:
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // Այս ֆայլերն ավելացվեցին LLVM 11-ում:
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // Մի քաշեք լրացուցիչ գրադարաններ MSVC-ի վրա
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // Անջատեք gcc-ի տարբեր առանձնահատկությունները և այլն, որոնք հիմնականում պատճենում են արդեն կազմող-RT կառուցման համակարգը
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // Ենթադրենք, որ Unixes-ը, որի համար մենք կառուցում ենք դա, fnctl() մատչելի է
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // Սա պետք է լինի բավականին լավ էվրիստիկական, երբ ընտրեք COMPILER_RT_HAS_ATOMICS-ը
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // Նշենք, որ սա պետք է գոյություն ունենա, եթե մենք գործարկելու ենք (հակառակ դեպքում մենք պարզապես ընդհանրապես չենք կառուցում պրոֆիլային ներկառուցված համակարգեր):
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}