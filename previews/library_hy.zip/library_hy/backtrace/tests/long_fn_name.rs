use backtrace::Backtrace;

// 50 նիշ մոդուլի անվանում
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50 նիշ կառուցվածքային անուն
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Երկար գործառույթների անունները պետք է կտրված լինեն (MAX_SYM_NAME, 1) նիշերի:
// Այս փորձարկումն անցկացրեք միայն msvc-ի համար, քանի որ gnu-ը տպում է "<no info>" բոլոր շրջանակների համար:
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // Կառուցվածքի անվանման 10 կրկնում, այնպես որ լիովին որակավորված գործառույթի անունը առնվազն 10 *(50 + 50)* 2=2000 նիշ է:
    //
    // Իրականում ավելի երկար է, քանի որ այն պարունակում է նաև `::`, `<>` և ընթացիկ մոդուլի անվանումը
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}