# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust-ի գործարկման ժամանակ հետադարձ կապի ձեռքբերման գրադարան:
Այս գրադարանը նպատակ ունի ընդլայնել ստանդարտ գրադարանի աջակցությունը `ապահովելով աշխատելու համար ծրագրային ինտերֆեյս, բայց այն նաև աջակցում է պարզապես հեշտությամբ տպել ընթացիկ հետադարձ ուղին, ինչպիսին է libstd's panics-ն:

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ուղղակի հետադարձ կապը գրավելու և դրա հետ կապված գործը հետաձգելու համար հետագայում, կարող եք օգտագործել բարձր մակարդակի `Backtrace` տեսակը:

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Եթե, այնուամենայնիվ, ցանկանում եք ավելի շատ հում մուտք ունենալ իրական հետագծման ֆունկցիոնալությանը, կարող եք ուղղակիորեն օգտագործել `trace` և `resolve` գործառույթները:

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Լուծեք այս ցուցումների ցուցիչը խորհրդանիշի անվան վրա
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // շարունակեք անցնել հաջորդ շրջանակին
    });
}
```

# License

Այս նախագիծը լիցենզավորված է որևէ մեկի կողմից

 * Apache լիցենզիա, տարբերակ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) կամ http://www.apache.org/licenses/LICENSE-2.0)
 * MIT լիցենզիա ([LICENSE-MIT](LICENSE-MIT) կամ http://opensource.org/licenses/MIT)

ձեր ընտրությամբ:

### Contribution

Քանի դեռ դուք հստակորեն այլ բան չեք նշել, ձեր կողմից հետադարձ կապի մեջ ներառման համար դիտավորյալ ներկայացված ցանկացած ներդրում, ինչպես սահմանված է Apache-2.0 լիցենզիայում, պետք է կրկնակի լիցենզավորված լինի վերևում, առանց որևէ լրացուցիչ պայմանների:







