//! Խորհրդանշման ռազմավարություն `օգտագործելով DWARF-վերլուծող ծածկագիրը libbacktrace-ում:
//!
//! Libbacktrace C գրադարանը, որը սովորաբար բաշխվում է gcc-ով, աջակցում է ոչ միայն հետադարձ կապի առաջացմանը (որը մենք իրականում չենք օգտագործում), այլ նաև խորհրդանշում է հետադարձ կապը և վարում գաճաճ վրիպազերծող տեղեկատվություն այնպիսի առարկաների մասին, ինչպիսիք են գծագրված շրջանակները և ինչը:
//!
//!
//! Սա համեմատաբար բարդ է այստեղ ՝ կապված բազմաթիվ մտահոգությունների հետ, բայց հիմնական գաղափարը հետևյալն է.
//!
//! * Նախ զանգահարում ենք `backtrace_syminfo`: Սա, եթե կարող ենք, խորհրդանիշների տեղեկատվություն է ստանում դինամիկ խորհրդանիշների աղյուսակից:
//! * Հաջորդը մենք զանգահարում ենք `backtrace_pcinfo`: Սա վերլուծելու է debuginfo աղյուսակները, եթե դրանք մատչելի են, և մեզ թույլ է տալիս վերականգնել տեղեկատվությունը ներմուծված շրջանակների, ֆայլերի անունների, գծերի համարների և այլնի մասին:
//!
//! Գաճաճ սեղանները libbacktrace մեջ մտցնելու վերաբերյալ շատ խորամանկություններ կան, բայց հուսով եմ ՝ դա աշխարհի վերջը չէ և բավականաչափ պարզ է ստորև կարդալիս:
//!
//! Սա ոչ MSVC և ոչ OSX պլատֆորմների խորհրդանշման լռելյայն ռազմավարությունն է: Libstd-ում, չնայած սա OSX-ի կանխադրված ռազմավարությունն է:
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Հնարավորության դեպքում նախընտրեք `function` անունը, որը գալիս է debuginfo-ից և սովորաբար կարող է ավելի ճշգրիտ լինել, օրինակ, ներկապնակների համար:
                // Եթե դա չկա, չնայած վերադառնանք `symname`-ում նշված խորհրդանիշի աղյուսակի անվան:
                //
                // Ուշադրություն դարձրեք, որ երբեմն `function`-ը կարող է իրեն ինչ-որ չափով ավելի քիչ ճշգրիտ զգալ, օրինակ `նշվելով որպես `try<i32,closure>` `std::panicking::try::do_call`-ի փոխարեն:
                //
                // Իրականում պարզ չէ, թե ինչու, բայց ընդհանուր առմամբ `function` անունն ավելի ճշգրիտ է թվում:
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // առայժմ ոչինչ չանել
}

/// `data` ցուցիչի տեսակը փոխանցված է `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Երբ այս զանգը կանչվի `backtrace_syminfo`-ից, երբ մենք սկսում ենք լուծել, մենք ավելի շատ ենք գնում `backtrace_pcinfo` զանգահարելու համար:
    // `backtrace_pcinfo` գործառույթը կխորհրդանշի կարգաբերման տեղեկատվությունը և կփորձի անել այնպիսի բաներ, ինչպիսիք են ՝ file/line տեղեկատվության վերականգնումը, ինչպես նաև ընդգծված շրջանակները:
    // Չնայած նկատեք, որ `backtrace_pcinfo`-ը կարող է ձախողվել կամ շատ բան չանել, եթե սխալների վերացման տեղեկատվություն չկա, այնպես որ, եթե դա տեղի ունենա, մենք անպայման կզանգահարենք հետ կանչը `syminfo_cb`-ի առնվազն մեկ խորհրդանիշով:
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` ցուցիչի տեսակը փոխանցված է `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API-ն աջակցում է պետություն ստեղծելուն, բայց չի աջակցում պետություն ոչնչացնելուն:
// Ես անձամբ սա հասկանում եմ, որ պետությունը ստեղծվելու է, այնուհետև հավերժ ապրելու համար:
//
// Ես կցանկանայի գրանցել at_exit() կարգավար, որը մաքրում է այս վիճակը, բայց libbacktrace-ը դրա համար ոչ մի հնարավորություն չի տալիս:
//
// Այս սահմանափակումների դեպքում այս ֆունկցիան ունի ստատիկորեն պահված վիճակ, որը հաշվարկվում է առաջին անգամ հարցման պահից:
//
// Հիշեք, որ հետ հետ վերցնելը սերիական է (մեկ գլոբալ կողպեք):
//
// Նշենք, որ այստեղ համաժամացման բացակայությունը պայմանավորված է `resolve`-ի արտաքին համաժամացման պահանջով:
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Մի օգտագործեք libbacktrace-ի անվտանգ հնարավորությունները, քանի որ մենք այն միշտ անվանում ենք սինխրոն եղանակով:
        //
        0,
        error_cb,
        ptr::null_mut(), // լրացուցիչ տվյալներ չկան
    );

    return STATE;

    // Նկատի ունեցեք, որ libbacktrace-ն ընդհանրապես գործելու համար անհրաժեշտ է գտնել DWARF վրիպազերծման տվյալները ընթացիկ գործարկելիի համար: Դա սովորաբար անում է դա մի շարք մեխանիզմների միջոցով, ներառյալ, բայց ոչ սահմանափակվածով ՝
    //
    // * /proc/self/exe աջակցվող հարթակներում
    // * Ֆայլի անունը հստակորեն անցավ պետություն ստեղծելիս
    //
    // Libbacktrace գրադարանը C կոդի մեծ կտոր է: Սա, բնականաբար, նշանակում է, որ այն ունի հիշողության անվտանգության խոցելի կողմեր, հատկապես սխալ ձևով կարգաբերում գործելիս:
    // Պատմականորեն Libstd-ը բախվել է դրանցից շատերի հետ:
    //
    // Եթե օգտագործվում է /proc/self/exe, ապա մենք կարող ենք սովորաբար անտեսել դրանք, քանի որ ենթադրում ենք, որ libbacktrace-ը "mostly correct" է, և այլապես տարօրինակ բաներ չի անում "attempted to be correct" գաճաճի կարգաբերման տեղեկատվության հետ:
    //
    //
    // Այնուամենայնիվ, եթե մենք փոխանցում ենք ֆայլի անուն, ապա դա հնարավոր է որոշ հարթակներում (օրինակ ՝ BSD), որտեղ վնասակար դերակատարը կարող է հանգեցնել կամայական ֆայլի տեղադրմանը այդ վայրում:
    // Սա նշանակում է, որ եթե մենք ֆայլի անվանման մասին libbacktrace-ին ասում ենք, որ այն կարող է օգտագործել կամայական ֆայլ, հնարավոր է ՝ առաջացնի պատռվածքներ:
    // Եթե մենք ինչ-որ բան չենք ասում libbacktrace-ին, ապա դա ոչինչ չի անի հարթակներում, որոնք չեն աջակցում /proc/self/exe-ի նման ուղիներին:
    //
    // Հաշվի առնելով այդ ամենը, մենք հնարավորինս ջանում ենք * ֆայլերի անուն չանցնել, բայց մենք պետք է այն հարթակներում, որոնք ընդհանրապես չեն աջակցում /proc/self/exe:
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Նշենք, որ իդեալական տարբերակ մենք կօգտագործեինք `std::env::current_exe`, բայց այստեղ չենք կարող `std` պահանջել:
            //
            // Օգտագործեք `_NSGetExecutablePath` ՝ ընթացիկ գործարկվող ուղին ստատիկ տարածքում բեռնելու համար (որը, եթե դա շատ փոքր է, պարզապես հրաժարվեք):
            //
            //
            // Նկատի ունեցեք, որ մենք լրջորեն վստահում ենք libbacktrace-ին, որպեսզի չմեռնենք կոռումպացված գործադիր կատարողների վրա, բայց դա հաստատ ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ունի ֆայլեր բացելու ռեժիմ, որտեղ այն բացելուց հետո այն հնարավոր չէ ջնջել:
            // Դա, ընդհանուր առմամբ, այն է, ինչ մենք ուզում ենք այստեղ, քանի որ ուզում ենք ապահովել, որ մեր գործարկվողը չի փոխվի մեր տակից այն բանից հետո, երբ մենք այն հանձնում ենք libbacktrace-ին, հուսով եմ `մեղմելով կամայական տվյալները libbacktrace (ինչը կարող է սխալ վարվել) փոխանցելու հնարավորությունը:
            //
            //
            // Հաշվի առնելով, որ մենք այստեղ մի փոքր պարում ենք, որպեսզի փորձենք սեփական պատկերի մի տեսակ արգելափակել:
            //
            // * Բռնեք ընթացիկ գործընթացին, բեռնեք նրա ֆայլի անունը:
            // * Բացեք այդ նիշքի ֆայլը ճիշտ դրոշներով:
            // * Վերաբեռնեք ընթացիկ գործընթացի ֆայլի անունը ՝ համոզվելով, որ այն նույնն է
            //
            // Եթե այդ ամենը անցնի, մենք տեսականորեն իսկապես բացել ենք մեր գործընթացի ֆայլերը և երաշխավորված ենք, որ դրանք չեն փոխվի: FWIW-ն դրա մի փունջ պատմականորեն արտագրված է libstd-ից, ուստի սա իմ լավագույն մեկնությունն է այն ամենի, ինչ տեղի էր ունենում:
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Սա ապրում է ստատիկ հիշողության մեջ, որպեսզի կարողանանք վերադարձնել այն:
                static mut BUF: [i8; N] = [0; N];
                // ... և սա ապրում է տուփի վրա, քանի որ ժամանակավոր է
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // `handle`-ն այստեղ միտումնավոր արտահոսք է կատարում, քանի որ այդ բաց ունենալը պետք է պահպանի մեր ֆայլի անվանման արգելափակումը:
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Մենք ուզում ենք վերադարձնել մի կտոր, որն ավարտվում է անվավեր, այնպես որ, եթե ամեն ինչ լրացված է, և այն հավասար է ընդհանուր երկարությանը, ապա դա հավասարեցրու է ձախողման:
                //
                //
                // Հակառակ դեպքում հաջողությունը վերադառնալիս համոզվեք, որ նուլ բայթը ներառված է կտորում:
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // հետգետնյա սխալները ներկայումս ծածկված են գորգի տակ
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Callանգահարեք `backtrace_syminfo` API-ին, որը (կոդը կարդալուց) պետք է ուղիղ մեկ անգամ զանգի `syminfo_cb` (կամ ենթադրաբար ձախողվի սխալով):
    // Դրանից հետո մենք ավելի շատ բան ենք անում `syminfo_cb`-ի շրջանակներում:
    //
    // Նշենք, որ մենք դա անում ենք, քանի որ `syminfo`-ը խորհրդակցելու է խորհրդանիշների աղյուսակի հետ `գտնելով խորհրդանիշների անուններ, նույնիսկ եթե երկուականում սխալի մասին տեղեկատվություն չկա:
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}