//! Աջակցություն խորհրդանշմանը `օգտագործելով `gimli` crate crates.io-ում
//!
//! Սա Rust-ի խորհրդանշման լռելյայն իրականացումն է:

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // «ստատիկ կյանքի տևողությունը սուտ է ՝ ինքնահղման հարվածների աջակցության բացակայության շուրջ:
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Փոխարկեք «ստատիկ կյանքի տևողության», քանի որ խորհրդանիշները պետք է վերցնեն միայն `map` և `stash`, և մենք դրանք պահպանում ենք ստորև:
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Հայրենի գրադարանները Windows-ով բեռնելու համար տե՛ս rust-lang/rust#71060-ի վերաբերյալ որոշ քննարկումներ այստեղ առկա տարբեր ռազմավարությունների համար:
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW գրադարանները ներկայումս չեն աջակցում ASLR (rust-lang/rust#16514), բայց DLL-ները դեռ կարող են տեղափոխվել հասցեի տարածքում:
            // Պարզվում է, որ կարգաբերման տեղեկատվության հասցեները բոլորը կարծես թե այս գրադարանը բեռնված է եղել իր "image base"-ում, ինչը COFF ֆայլի վերնագրերի դաշտ է:
            // Քանի որ debuginfo-ն թվարկում է հենց սա, մենք վերլուծում ենք խորհրդանիշների աղյուսակը և խանութների հասցեները այնպես, կարծես գրադարանը նույնպես բեռնված էր "image base"-ում:
            //
            // Գրադարանը, հնարավոր է, չի բեռնվում "image base"-ում:
            // (ենթադրաբար այնտեղ կարող է ինչ-որ բան այլ բեռնված լինել) այստեղ է, որ `bias` դաշտը սկսում է գործել, և այստեղ մենք պետք է հասկանանք `bias`-ի արժեքը: Unfortunatelyավոք, չնայած պարզ չէ, թե ինչպես կարելի է դա ձեռք բերել բեռնված մոդուլից:
            // Այն, ինչ ունենք, այն է, իրական բեռնման հասցեն (`modBaseAddr`):
            //
            // Որպես ներկայումս մի փոքր չարաշահում, մենք ֆիքսում ենք ֆայլը, կարդում ենք ֆայլի վերնագրի տեղեկությունները, ապա գցում ենք mmap-ը: Սա անօգուտ է, քանի որ մենք, հավանաբար, հետագայում կբացենք մմապը, բայց այս պահը պետք է բավականաչափ լավ աշխատի:
            //
            // Երբ ունենանք `image_base` (բեռի ցանկալի տեղադրություն) և `base_addr` (իրական բեռի տեղադրություն), մենք կարող ենք լրացնել `bias` (տարբերություն իրականի և ցանկալիի միջև), ապա յուրաքանչյուր հատվածի հայտարարված հասցեն `image_base` է, քանի որ դա այն է, ինչ ասում է ֆայլը:
            //
            //
            // Առայժմ թվում է, որ ի տարբերություն ELF/MachO-ի, մենք կարող ենք բավարարվել մեկ գրադարանի մեկ հատվածով `օգտագործելով `modBaseSize`-ը որպես ամբողջ չափ:
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS օգտագործում է Mach-O ֆայլի ձևաչափը և օգտագործում DYLD-ի հատուկ API-ներ ՝ բեռնման գրադարանների ցանկը, որոնք մաս են կազմում ծրագրի:
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Վերցրեք այս գրադարանի անունը, որը համապատասխանում է այն բեռնման վայրի ուղուն նույնպես:
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Տեղադրեք այս գրադարանի պատկերի վերնագիրը և պատվիրեք `object`-ին `վերլուծելու բեռնման բոլոր հրամանները, որպեսզի կարողանանք պարզել այստեղ ներգրավված բոլոր հատվածները:
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Կրկնեք հատվածները և գրանցեք հայտնի շրջանները մեր գտած հատվածների համար:
            // Լրացուցիչ գրանցեք տեղեկատվության տեքստի հատվածները հետագայում մշակելու համար, տե՛ս ստորև ներկայացված մեկնաբանությունները:
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Որոշեք "slide"-ը այս գրադարանի համար, որն ավարտվում է որպես այն կողմնակալությունը, որը մենք օգտագործում ենք `պարզելու համար, թե որտեղ են բեռնված հիշողության օբյեկտները:
            // Սա, միևնույն է, տարօրինակ հաշվարկ է և արդյունք է մի քանի բան փորձելու վայրի բնության մեջ և տեսնելու, թե ինչն է մնում:
            //
            // Ընդհանուր գաղափարն այն է, որ `bias`-ը գումարած հատվածի `stated_virtual_memory_address`-ը լինելու է այնտեղ, որտեղ իրական հասցեի տարածքում է գտնվում հատվածը:
            // Չնայած մյուս բանը, որին մենք ապավինում ենք, այն է, որ իրական հասցեն հանած `bias`-ը խորհրդանիշների աղյուսակում փնտրելու ցուցիչն է և debuginfo-ն:
            //
            // Պարզվում է, սակայն, որ համակարգով բեռնված գրադարանների համար այս հաշվարկները սխալ են: Սակայն հայրենի գործադիրների համար այն ճիշտ է թվում:
            // Որոշակի տրամաբանություն բարձրացնելով LLDB-ի աղբյուրից `այն ունի որոշակի պատյան` առաջին `__TEXT` հատվածի համար, որը բեռնված է 0 ֆայլերի օֆսեթից `ոչ զրո չափսով:
            // Ինչ-ինչ պատճառով, երբ դա առկա է, թվում է, որ խորհրդանիշների աղյուսակը համեմատական է գրադարանի համար պարզապես vmaddr սլայդի հետ:
            // Եթե դա *չկա*, ապա խորհրդանիշի աղյուսակը համեմատական է vmaddr սլայդի հետ, գումարած հատվածի հայտարարված հասցեն:
            //
            // Այս իրավիճակը կարգավորելու համար, եթե մենք *չենք* գտնում տեքստի բաժինը զրոյական փոխհատուցման ֆայլում, ապա մենք ավելացնում ենք կողմնակալությունը առաջին տեքստի բաժինների նշված հասցեով և բոլոր նշված հասցեները նույնպես նվազեցնում այդ քանակով:
            //
            // Այդ կերպ խորհրդանիշների աղյուսակը միշտ հայտնվում է գրադարանի կողմնակալության չափի համեմատ:
            // Սա, կարծես, ճիշտ արդյունքներ ունի խորհրդանիշ աղյուսակի միջոցով խորհրդանշելու համար:
            //
            // Անկեղծ ասած, ես լիովին համոզված չեմ ՝ արդյո՞ք դա ճիշտ է, թե կա ևս մեկ այլ բան, որը պետք է ցույց տա, թե ինչպես դա անել:
            // Առայժմ, չնայած, կարծես, սա աշխատում է բավականին լավ (?), և անհրաժեշտության դեպքում մենք միշտ պետք է կարողանանք ժամանակի ընթացքում շտկել դա:
            //
            // Լրացուցիչ տեղեկությունների համար տե՛ս #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Այլ Unix (օրինակ
        // Linux) պլատֆորմներն օգտագործում են ELF-ը որպես օբյեկտի ֆայլի ձևաչափ և սովորաբար իրականացնում են `dl_iterate_phdr` անունով API ՝ հայրենի գրադարանները բեռնելու համար:
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` պետք է վավեր ցուցիչներ լինեն:
        // `vec` պետք է լինի վավեր ցուցիչ դեպի `std::Vec`:
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 բնօրինակը չի աջակցում վրիպազերծման տեղեկությունները, բայց կառուցման համակարգը տեղադրելու է վրիպազերծման տեղեկությունները `romfs:/debug_info.elf` ուղու վրա:
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Մնացած ամեն ինչ պետք է օգտագործի ELF, բայց չգիտի, թե ինչպես բեռնել հայրենի գրադարանները:
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Բեռնված բոլոր հայտնի ընդհանուր գրադարանները:
    libraries: Vec<Library>,

    /// Քարտեզագրման պահոց, որտեղ մենք պահպանում ենք վերլուծված գաճաճ տեղեկատվությունը:
    ///
    /// Այս ցուցակն ունի հաստատուն հզորություն իր ամբողջ բարձրացման համար, որը երբեք չի ավելանում:
    /// Յուրաքանչյուր զույգի `usize` տարրը `libraries` ցուցիչ է վերևում, որտեղ `usize::max_value()` ներկայացնում է ընթացիկ գործարկվողը:
    ///
    /// `Mapping`-ը համապատասխան վերլուծված գաճաճ տեղեկատվություն է:
    ///
    /// Նշենք, որ սա հիմնականում LRU քեշ է, և մենք գործերը կտեղափոխենք այստեղ, քանի որ խորհրդանշում ենք հասցեները:
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Այս գրադարանի հատվածները բեռնված են հիշողության մեջ և որտեղ են դրանք բեռնված:
    segments: Vec<LibrarySegment>,
    /// Այս գրադարանի "bias"-ը, սովորաբար այնտեղ, որտեղ այն բեռնված է հիշողության մեջ:
    /// Այս արժեքը ավելացվում է յուրաքանչյուր հատվածի հայտարարված հասցեին `ստանալու այն վիրտուալ հիշողության իրական հասցեն, որի մեջ բեռնված է հատվածը:
    /// Բացի այդ, այս կողմնակալությունը հանվում է իրական վիրտուալ հիշողության հասցեներից ՝ ինդեքսավորելու մեջ debuginfo և խորհրդանիշների աղյուսակ:
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Այս հատվածի նշված հասցեն օբյեկտի ֆայլում:
    /// Իրականում սա բեռնված չէ սեգմենտը, այլ ավելի շուտ այս հասցեն գումարած պարունակող գրադարանի `bias`-ն է, որտեղ կարելի է գտնել:
    ///
    stated_virtual_memory_address: usize,
    /// Հիշողության մեջ այդ հատվածի չափը:
    len: usize,
}

// անապահով, քանի որ սա պահանջվում է արտաքին համաժամացման համար
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // անապահով, քանի որ սա պահանջվում է արտաքին համաժամացման համար
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Շատ փոքր, շատ պարզ LRU հիշապահեստ ՝ վրիպազերծման տեղեկատվության քարտեզագրման համար:
        //
        // Հիթի տոկոսադրույքը պետք է շատ բարձր լինի, քանի որ տիպային բուրգը չի անցնում շատ ընդհանուր գրադարանների միջև:
        //
        // `addr2line::Context` կառուցվածքները ստեղծելը բավականին թանկ է:
        // Ակնկալվում է, որ դրա գինն ամորտիզացվելու է հետագա `locate` հարցումներից, որոնք օգտագործում են «addr2line: : Context»-ը կառուցելիս կառուցված կառուցվածքները `գեղեցիկ արագացում ստանալու համար:
        //
        // Եթե մենք չունեինք այս քեշը, ապա այդ ամորտիզացիան երբեք տեղի չէր ունենա, և հետադարձ հետք խորհրդանշող կլիներ ssssllllooooowwww:
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Սկզբից ստուգեք, արդյոք այս `lib`-ն ունի `addr` պարունակող հատված (բեռնաթափման տեղափոխում): Եթե այս ստուգումն անցնի, ապա մենք կարող ենք շարունակել ստորև և իրականում թարգմանել հասցեն:
                //
                // Նշենք, որ մենք այստեղ օգտագործում ենք `wrapping_add` ՝ արտահոսքի ստուգումներից խուսափելու համար: Բնության մեջ արդեն տեսել են, որ SVMA + կողմնակալության հաշվարկը հորդում է:
                // Թվում է, թե դա մի փոքր տարօրինակ է, բայց դա հսկայական գումար չէ, որ կարող ենք անել այդ հարցում, բացի երևույթից պարզապես անտեսել այդ հատվածները, քանի որ դրանք, ամենայն հավանականությամբ, ուղղվում են դեպի տարածություն:
                //
                // Սա ի սկզբանե հայտնվեց rust-lang/backtrace-rs#329-ում:
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Այժմ, երբ մենք գիտենք, որ `lib` պարունակում է `addr`, մենք կարող ենք փոխհատուցել նշված վիրուսային հիշողության հասցեն գտնելու կողմնակալությունը:
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Անփոփոխ. Այս պայմանականն ավարտվելուց հետո առանց շուտ վերադառնալու
        // սխալից, այս ուղու քեշի մուտքը 0 ինդեքսում է:

        if let Some(idx) = idx {
            // Երբ քարտեզագրումն արդեն պահոցում է, տեղափոխեք այն ճակատ:
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Երբ քարտեզագրումը պահոցում չէ, ստեղծեք նոր քարտեզագրում, տեղադրեք այն քեշի առջևի մասում և անհրաժեշտության դեպքում վտարեք քեշի ամենահին մուտքը:
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // մի արտահոսեք `'static`-ի ողջ կյանքի ընթացքում, համոզվեք, որ այն նախատեսված է միայն մեզ համար
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Ընդլայնել `sym`-ի կյանքը մինչև `'static`, քանի որ մեզանից, ցավոք սրտի, դա մեզանից պահանջվում է, բայց այն երբևէ դուրս է գալիս որպես տեղեկանք, ուստի դրանում ոչ մի հղում այնուամենայնիվ չպետք է պահպանվի:
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Վերջապես, ստացեք պահված քարտեզագրում կամ ստեղծեք նոր քարտեզագրություն այս ֆայլի համար և գնահատեք DWARF-ի տեղեկատվությունը ՝ այս հասցեի համար file/line/name գտնելու համար:
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Մենք կարողացանք գտնել այս խորհրդանիշի վերաբերյալ շրջանակի տեղեկատվությունը, և «addr2line»-ի շրջանակն իր ներքին մասում ունի բոլոր աղքատիկ մանրախիճ մանրամասները:
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Չհաջողվեց գտնել վրիպազերծման տեղեկատվությունը, բայց մենք այն գտանք կատարվող էլֆի խորհրդանիշների աղյուսակում:
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}