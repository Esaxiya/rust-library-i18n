// օգտագործվում է միայն Linux-ի վրա հենց հիմա, այնպես որ թույլ տվեք այլ վայրում մեռնել ծածկագիր
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Պարզ ասպարեզի բաշխիչ բայթ բուֆերների համար:
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Նշված չափի բուֆեր է հատկացնում և վերադարձնում դրան անփոփոխելի հղում:
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Սա միակ գործառույթն է, որը երբևէ փոփոխական է կառուցում
        // հղում `self.buffers`-ին:
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ԱՆՎՏԱՆԳՈՒԹՅՈՒՆ. Մենք երբեք տարրեր չենք հանում `self.buffers`-ից, ուստի հղում
        // ցանկացած բուֆերի ներսում գտնվող տվյալները կապրեն այնքան ժամանակ, որքան ապրում է `self`:
        &mut buffers[i]
    }
}