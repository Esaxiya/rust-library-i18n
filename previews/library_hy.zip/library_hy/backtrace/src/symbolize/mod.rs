use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Հասցեն լուծեք խորհրդանիշի վրա ՝ փոխանցելով խորհրդանիշը նշված փակմանը:
///
/// Այս գործառույթը կփնտրի նշված հասցեն այն վայրերում, ինչպիսիք են տեղական խորհրդանիշների աղյուսակը, դինամիկ խորհրդանիշների աղյուսակը կամ DWARF կարգաբերման կարգի տեղեկատվությունը (կախված ակտիվացված իրականացումից) ՝ գտնելու համար խորհրդանիշներ:
///
///
/// Փակումը չի կարող կանչվել, եթե բանաձևը հնարավոր չէ կատարել, և այն կարող է կանչվել նաև մեկից ավելի անգամ ՝ ընդգծված գործառույթների դեպքում:
///
/// Ստացված խորհրդանիշները ներկայացնում են կատարումը նշված `addr`-ում `այդ հասցեի համար վերադարձնելով file/line զույգեր (առկայության դեպքում):
///
/// Նշենք, որ եթե ունեք `Frame`, ապա խորհուրդ է տրվում օգտագործել այս գործառույթի փոխարեն `resolve_frame` գործառույթը:
///
/// # Պահանջվող հատկություններ
///
/// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
///
/// # Panics
///
/// Այս գործառույթը ձգտում է երբեք panic-ին, բայց եթե `cb`-ը տրամադրում է panics, ապա որոշ պլատֆորմներ կստիպեն կրկնակի panic-ին դադարեցնել գործընթացը:
/// Որոշ պլատֆորմներ օգտագործում են C գրադարան, որն իր մեջ օգտագործում է հետադարձ պատասխաններ, որոնք հնարավոր չէ լուծել, այնպես որ `cb`-ից խուճապը կարող է առաջացնել գործընթացների ընդհատում:
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // միայն նայեք վերին շրջանակին
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Լուծեք նախկինում գրավման շրջանակը խորհրդանիշի վրա, փոխանցելով խորհրդանիշը նշված փակմանը:
///
/// Այս ֆունկցինը կատարում է նույն գործառույթը, ինչ `resolve`-ը, բացառությամբ այն, որ հասցեի փոխարեն որպես փաստարկ է վերցնում `Frame`-ը:
/// Սա կարող է թույլ տալ հետադարձ կապի որոշ պլատֆորմների իրականացում ապահովել ավելի ճշգրիտ տեղեկատվություն խորհրդանիշի մասին կամ, օրինակ, ներքին շրջանակների վերաբերյալ տեղեկություններ:
///
/// Խորհուրդ է տրվում օգտագործել դա, եթե կարող եք:
///
/// # Պահանջվող հատկություններ
///
/// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
///
/// # Panics
///
/// Այս գործառույթը ձգտում է երբեք panic-ին, բայց եթե `cb`-ը տրամադրում է panics, ապա որոշ պլատֆորմներ կստիպեն կրկնակի panic-ին դադարեցնել գործընթացը:
/// Որոշ պլատֆորմներ օգտագործում են C գրադարան, որն իր մեջ օգտագործում է հետադարձ պատասխաններ, որոնք հնարավոր չէ լուծել, այնպես որ `cb`-ից խուճապը կարող է առաջացնել գործընթացների ընդհատում:
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // միայն նայեք վերին շրջանակին
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Դեղերի շրջանակներից ստացված IP արժեքները սովորաբար (always?)-ն են ՝ զանգի հետո * ցուցումը, որը բուրգի իրական հետքն է:
// Դրա վրա խորհրդանշելը հանգեցնում է նրան, որ filename/line համարը մեկից առաջ է և գուցե անվավեր, եթե գործառույթի ավարտին է:
//
// Թվում է, որ հիմնականում դա միշտ է, որ պատահում է բոլոր պլատֆորմների վրա, ուստի մենք միշտ լուծված IP-ից հանում ենք մեկը ՝ այն վերացնելու փոխարեն զանգի նախորդ հրահանգին, այլ ոչ թե հրահանգին վերադարձվի:
//
//
// Իդեալում մենք դա չէինք անի:
// Իդեալում, մենք այստեղ `resolve` API-ների զանգահարողներից կպահանջեին ձեռքով կատարել -1 և հաշվի առնել, որ նրանք ուզում են գտնվելու վայրի վերաբերյալ տեղեկատվություն *նախորդ* հրահանգի համար, ոչ թե ընթացիկ:
// Իդեալում, մենք նաև կբացահայտեինք `Frame`-ի վրա, եթե մենք իսկապես լինեինք հաջորդ հրահանգի կամ հոսանքի հասցեն:
//
// Առայժմ չնայած սա բավականին մտահոգիչ խնդիր է, ուստի մենք պարզապես ներքուստ միշտ հանում ենք մեկը:
// Սպառողները պետք է շարունակեն աշխատել և բավականին լավ արդյունքներ ստանալ, ուստի մենք պետք է բավականաչափ լավ լինենք:
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Նույնն է, ինչ `resolve`-ը, միայն անվտանգ է, քանի որ սինխրոնիզացված չէ:
///
/// Այս գործառույթը չունի համաժամացման երաշխավորներ, բայց մատչելի է, երբ այս crate-ի `std` առանձնահատկությունը կազմված չէ:
/// Տեսեք `resolve` գործառույթը ՝ ավելի շատ փաստաթղթերի և օրինակների համար:
///
/// # Panics
///
/// Տեսեք `resolve`-ի վերաբերյալ տեղեկությունները ՝ `cb` խուճապի զգուշացման համար:
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Նույնն է, ինչ `resolve_frame`-ը, միայն անվտանգ է, քանի որ սինխրոնիզացված չէ:
///
/// Այս գործառույթը չունի համաժամացման երաշխավորներ, բայց մատչելի է, երբ այս crate-ի `std` առանձնահատկությունը կազմված չէ:
/// Տեսեք `resolve_frame` գործառույթը ՝ ավելի շատ փաստաթղթերի և օրինակների համար:
///
/// # Panics
///
/// Տեսեք `resolve_frame`-ի վերաբերյալ տեղեկությունները ՝ `cb` խուճապի զգուշացման համար:
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait, որը ներկայացնում է ֆայլի մեջ խորհրդանիշի լուծումը:
///
/// Այս trait-ն տրվում է որպես trait օբյեկտ `backtrace::resolve` գործառույթին տրված փակմանը, և այն գործնականում ուղարկվում է, քանի որ անհայտ է, թե որ իրականացումն է դրա ետևում:
///
///
/// Սիմվոլը կարող է տալ համատեքստային տեղեկություններ գործառույթի մասին, օրինակ `անունը, ֆայլի անունը, տողի համարը, ճշգրիտ հասցեն և այլն:
/// Այնուամենայնիվ, ոչ բոլոր տեղեկատվությունն է միշտ մատչելի խորհրդանիշով, այնպես որ բոլոր մեթոդները վերադարձնում են `Option`:
///
///
pub struct Symbol {
    // TODO: այս կյանքի տևողությունը պետք է ի վերջո պահպանվի մինչև `Symbol`,
    // բայց դա ներկայումս կտրուկ փոփոխություն է:
    // Առայժմ սա անվտանգ է, քանի որ `Symbol`-ը միայն երբևէ է հանձնվում հղումով և չի կարող կլոնավորվել:
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Վերադարձնում է այս գործառույթի անունը:
    ///
    /// Վերադարձված կառուցվածքը կարող է օգտագործվել խորհրդանիշի անվան վերաբերյալ տարբեր հատկությունների հարցման համար.
    ///
    ///
    /// * `Display` ներդրումը կտպագրի ապամոնտաժված խորհրդանիշը:
    /// * Հնարավոր է մուտք գործել խորհրդանիշի հում `str` արժեք (եթե այն վավեր է utf-8):
    /// * Հնարավոր է մուտք գործել խորհրդանիշի անվան հում բայթ:
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Վերադարձնում է այս գործառույթի մեկնարկային հասցեն:
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Վերադարձնում է հումքի ֆայլի անունը որպես կտոր:
    /// Սա հիմնականում օգտակար է `no_std` միջավայրի համար:
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Վերադարձնում է սյունակի համարը, որտեղ այս խորհրդանիշը ներկայումս կատարվում է:
    ///
    /// Միայն gimli-ն ներկայումս այստեղ արժեք է տրամադրում, և նույնիսկ այն դեպքում, միայն եթե `filename`-ը վերադարձնի `Some`, և հետևաբար, այն հետևաբար ենթակա է նմանատիպ նախազգուշացման:
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Վերադարձնում է այն տողի համարը, որտեղ այս խորհրդանիշը ներկայումս կատարվում է:
    ///
    /// Այս վերադարձի արժեքը սովորաբար `Some` է, եթե `filename` վերադարձնում է `Some`, և, համապատասխանաբար, ենթակա է նմանատիպ նախազգուշացման:
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Վերադարձնում է ֆայլի անունը, որտեղ սահմանվել է այս գործառույթը:
    ///
    /// Այս պահին դա մատչելի է միայն այն ժամանակ, երբ օգտագործվում են libbacktrace կամ gimli (օրինակ
    /// unix պլատֆորմներ այլ) և երբ binary կազմվում է debuginfo-ով:
    /// Եթե այս պայմաններից ոչ մեկը բավարարված չէ, ապա դա, ամենայն հավանականությամբ, կվերադարձնի `None`:
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Գուցե վերլուծված C++ խորհրդանիշ, եթե Rust-ի խզված խորհրդանիշը վերլուծելը ձախողվեց:
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Համոզվեք, որ պահեք այս զրոյական չափը, որպեսզի `cpp_demangle` առանձնահատկությունն անջատված լինի առանց ծախսերի:
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Խորհրդանիշի անվան շուրջ փաթաթում `ապամոնտաժված անունին, հում բայթով, չմշակված տողին և այլն ergonomic accessors ապահովելու համար:
///
// Թույլատրել մեռած ծածկագիրը այն դեպքում, երբ `cpp_demangle` հատկությունը միացված չէ:
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Ստեղծում է նոր խորհրդանիշի անվանում `հիմքում ընկած բայթից:
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Վերադարձնում է հում (mangled) խորհրդանիշի անունը որպես `str`, եթե խորհրդանիշը վավեր է utf-8:
    ///
    /// Օգտագործեք `Display` ներդրումը, եթե ցանկանում եք ապամոնտաժված տարբերակը:
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Վերադարձնում է հում խորհրդանիշի անունը որպես բայթերի ցուցակ
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Սա կարող է տպվել, եթե ապամոնտաժված խորհրդանիշը իրականում վավեր չէ, այնպես որ այստեղ սխալ կերպով վարվեք սխալի հետ ՝ այն չտարածելով դեպի դուրս:
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Փորձված է վերականգնել պահված հիշողությունը, որն օգտագործվում էր հասցեները խորհրդանշելու համար:
///
/// Այս մեթոդը կփորձի ազատել տվյալների գլոբալ որևէ կառույց, որոնք այլ կերպ են պահված գլոբալ կերպով կամ թեմայում, որոնք սովորաբար ներկայացնում են վերլուծված DWARF տեղեկատվություն կամ նմանատիպ այլ տեղեկություններ:
///
///
/// # Caveats
///
/// Չնայած այս գործառույթը միշտ մատչելի է, այն իրականում ոչինչ չի ձեռնարկում իրականացման մեծ մասի համար:
/// Գրադարանները, ինչպիսիք են dbghelp-ը կամ libbacktrace-ը, չեն տրամադրում հատկացված հիշողությունը վիճակը բաշխելու և կառավարելու համար:
/// Առայժմ այս crate-ի `gimli-symbolize` առանձնահատկությունը միակ առանձնահատկությունն է, որտեղ այս գործառույթը որևէ ազդեցություն ունի:
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}