//! Մոդուլ, որն օգնում է կառավարել dbghelp կապակցումը Windows-ի վրա
//!
//! Հետադարձ կապը Windows-ի վրա (համենայն դեպս MSVC-ի համար) հիմնականում սնուցվում է `dbghelp.dll`-ի և այն պարունակող տարբեր գործառույթների միջոցով:
//! Այս գործառույթները ներկայումս բեռնված են *դինամիկ*, այլ ոչ թե ստատիկորեն կապվելով `dbghelp.dll`-ի հետ:
//! Ներկայումս դա արվում է ստանդարտ գրադարանի կողմից (և տեսականորեն այնտեղ պահանջվում է), բայց այն ջանք է, որը կօգնի նվազեցնել գրադարանի ստատիկ DL կախվածությունները, քանի որ հետադարձ գծերը սովորաբար ընտրովի են:
//!
//! Ասելով, որ `dbghelp.dll`-ը գրեթե միշտ հաջողությամբ բեռնվում է Windows-ի վրա:
//!
//! Չնայած նկատենք, որ քանի որ այս ամբողջ աջակցությունը դինամիկորեն բեռնում ենք, մենք իրականում չենք կարող օգտագործել `winapi`-ի հում սահմանումները, այլ պետք է ինքներս սահմանենք գործառույթի ցուցիչի տեսակները և օգտագործենք այն:
//! Մենք իրականում չենք ցանկանում զբաղվել winapi-ի կրկնօրինակման գործով, ուստի մենք ունենք Cargo հատկություն `verify-winapi`, որը պնդում է, որ բոլոր կապակցությունները համընկնում են winapi-ի հետ և այս հատկությունը միացված է CI-ում:
//!
//! Վերջապես, դուք այստեղ նկատելու եք, որ `dbghelp.dll`-ի համար dll-ը երբեք չի բեռնաթափվում, և դա ներկայումս դիտավորյալ է:
//! Մտածողությունն այն է, որ մենք կարող ենք գլոբալ կերպով այն քեշավորել և օգտագործել այն API-ի զանգերի արանքում ՝ խուսափելով թանկարժեք loads/unloads-ից:
//! Եթե դա արտահոսքի դետեկտորների խնդիր է կամ նման մի բան, մենք կարող ենք անցնել կամուրջը, երբ հասնենք այնտեղ:
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Աշխատեք `SymGetOptions`-ի և `SymSetOptions`-ի շուրջ `չլինելով բուն winapi-ում:
// Հակառակ դեպքում սա օգտագործվում է միայն այն ժամանակ, երբ մենք ստուգում ենք winapi-ի դեմ տեսակները:
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapi-ում դեռ սահմանված չէ
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Սա սահմանվում է winapi-ում, բայց դա սխալ է (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapi-ում դեռ սահմանված չէ
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Այս մակրոը օգտագործվում է `Dbghelp` կառուցվածք սահմանելու համար, որը ներսում պարունակում է բոլոր գործառույթների ցուցիչները, որոնք մենք կարող ենք բեռնել:
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Բեռնված DLL `dbghelp.dll`-ի համար
            dll: HMODULE,

            // Յուրաքանչյուր գործառույթի ցուցիչ յուրաքանչյուր գործառույթի համար, որը մենք կարող ենք օգտագործել
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Սկզբնապես մենք չենք բեռնել DLL-ն
            dll: 0 as *mut _,
            // Սկզբնական բոլոր գործառույթները զրոյի են դրված ՝ ասելու համար, որ դրանք պետք է դինամիկ բեռնվեն:
            //
            $($name: 0,)*
        };

        // Հարմարավետ տպագիր յուրաքանչյուր գործառույթի տեսակի համար:
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` բացելու փորձեր:
            /// Վերադառնում է հաջողություն, եթե այն գործում է կամ սխալ է, եթե `LoadLibraryW` ձախողվում է:
            ///
            /// Panics եթե գրադարանն արդեն բեռնված է:
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Յուրաքանչյուր մեթոդի գործառույթը, որը մենք կցանկանայինք օգտագործել:
            // Calledանգահարելիս այն կամ կկարդա պահված գործառույթի ցուցիչը կամ կբեռնարկի այն և կվերադարձնի բեռնված արժեքը:
            // Բեռները պնդում են հաջողության հասնելու համար:
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Մաքրման կողպեքներն օգտագործելու հարմարավետության վստահված անձ dbghelp գործառույթներին հղում կատարելու համար:
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Նախաձեռնեք այս crate-ից `dbghelp` API գործառույթներ մուտք գործելու համար անհրաժեշտ բոլոր աջակցությունները:
///
///
/// Նշենք, որ այս գործառույթը **անվտանգ է**, այն ներքինորեն ունի իր սեփական համաժամացումը:
/// Նշեք նաև, որ անվտանգ է այս գործառույթը մի քանի անգամ ռեկուրսիվ զանգահարելը:
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Առաջին բանը, որ մենք պետք է անենք, այս գործառույթի համաժամացումն է: Սա կարելի է միաժամանակ կոչել այլ թելերից կամ ռեկուրսիվորեն մեկ թեմայի շրջանակներում:
        // Նկատի ունեցեք, որ դա բարդ է դրանից, չնայած այն բանին, որ այն, ինչ մենք օգտագործում ենք այստեղ, `dbghelp`,*նաև* այս գործընթացում անհրաժեշտ է սինքրոնացնել `dbghelp`-ի մյուս բոլոր զանգահարողների հետ:
        //
        // Սովորաբար `dbghelp`-ին նույն գործընթացում այդքան շատ զանգեր չեն լինում, և մենք, հավանաբար, կարող ենք ապահով կերպով ենթադրել, որ միայն մենք ենք դրան մուտք գործում:
        // Այնուամենայնիվ, կա մեկ այլ հիմնական օգտվող, որի համար մենք պետք է անհանգստանանք, որը հեգնանքով մենք ենք, բայց ստանդարտ գրադարանում:
        // Rust ստանդարտ գրադարանը հետադարձ կապի աջակցության համար կախված է այս crate-ից, և այս crate-ն առկա է նաև crates.io-ի վրա:
        // Սա նշանակում է, որ եթե ստանդարտ գրադարանը տպում է panic հետադարձ ուղի, ապա այն կարող է մրցել այս crate-ի հետ, որը գալիս է crates.io-ից ՝ առաջացնելով խցանումներ:
        //
        // Համաժամացման այս խնդիրը լուծելու համար մենք այստեղ օգտագործում ենք Windows-ի հատուկ հնարք (դա, ի վերջո, համաժամացման վերաբերյալ Windows-ի հատուկ սահմանափակում է):
        // Այս զանգը պաշտպանելու համար մենք ստեղծում ենք *session-local* անունով mutex:
        // Նպատակն այստեղ այն է, որ ստանդարտ գրադարանը և այս crate-ն անհրաժեշտ չէ կիսել Rust մակարդակի API-ներ ՝ այստեղ համաժամեցնելու համար, բայց փոխարենը կարող են աշխատել կուլիսներում ՝ համոզվելու, որ դրանք համաժամացվում են միմյանց հետ:
        //
        // Այդ կերպ, երբ այս ֆունկցիան կանչվում է ստանդարտ գրադարանի կամ crates.io-ի միջոցով, մենք կարող ենք վստահ լինել, որ նույն mutex-ը ձեռք է բերվում:
        //
        // Այսպիսով, այդ ամենն այն է, որ ասենք, որ այստեղ առաջին բանը, որ մենք անում ենք, այն է, որ մենք ատոմային եղանակով ստեղծենք `HANDLE`, որը անվանում են mutex Windows-ում:
        // Մենք մի փոքր համաժամացնում ենք այս գործառույթը բաժանող այլ թեմաների հետ և ապահովում ենք, որ միայն մեկ բռնիչ ստեղծվի այս գործառույթի օրինակով:
        // Նշենք, որ բռնակը երբեք չի փակվում, երբ այն պահվում է գլոբալում:
        //
        // Այն բանից հետո, երբ մենք իրականում կողպեքն անցնենք, մենք պարզապես ձեռք ենք բերում այն, և մեր կողմից բաժանվող `Init` բռնիչը պատասխանատու կլինի այն ի վերջո թողնելու համար:
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Լավ, այոԱյժմ, երբ մենք բոլորս ապահով համաժամացված ենք, եկեք սկսենք իրականում մշակել ամեն ինչ:
        // Նախ և առաջ մենք պետք է համոզվենք, որ `dbghelp.dll`-ն իրականում բեռնված է այս գործընթացում:
        // Մենք դա անում ենք դինամիկ կերպով `ստատիկ կախվածությունից խուսափելու համար:
        // Սա պատմականորեն արվել է տարօրինակ կապող հարցերի շուրջ աշխատելու համար և նպատակ ունի երկուական համակարգիչը մի փոքր ավելի դյուրակիր դարձնել, քանի որ դա հիմնականում ընդամենը կարգաբերման գործիք է:
        //
        //
        // `dbghelp.dll`-ը բացելուց հետո մենք պետք է դրանում կանչենք նախնական որոշման գործառույթներ, և դա մանրամասնորեն ստորև:
        // Մենք դա անում ենք միայն մեկ անգամ, ուստի ստացանք գլոբալ բուլյան ծրագիր, որը ցույց է տալիս ՝ դեռ վերջացե՞լ ենք, թե ոչ:
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Համոզվեք, որ `SYMOPT_DEFERRED_LOADS` դրոշը դրված է, քանի որ ըստ MSVC- ի սեփական փաստաթղթերի ՝ "This is the fastest, most efficient way to use the symbol handler.", ուրեմն եկեք դա անենք:
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Փաստորեն նախանշեք խորհրդանիշները MSVC-ով: Նշենք, որ դա կարող է ձախողվել, բայց մենք դա անտեսում ենք:
        // Առկա է դրա համար ոչ մի տոննա նախնական արվեստ, բայց LLVM-ը, ըստ երևույթին, անտեսում է այստեղ վերադարձվող արժեքը, և LLVM-ում մաքրող գրադարաններից մեկը տպում է սարսափելի նախազգուշացում, եթե դա ձախողվի, բայց հիմնականում անտեսում է դա երկարաժամկետ հեռանկարում:
        //
        //
        // Մի դեպք, որը Rust-ի համար շատ է առաջ բերում այն է, որ ստանդարտ գրադարանը և crates.io-ի այս crate-ը երկուսն էլ ցանկանում են մրցել `SymInitializeW`-ի համար:
        // Ստանդարտ գրադարանը պատմականորեն ցանկանում էր սկզբնապես նախ նախ մաքրել, բայց հիմա, երբ այս crate-ն է օգտագործում, նշանակում է, որ ինչ-որ մեկը նախ կգտնի նախնականացման, իսկ մյուսը կվերցնի այդ նախաստորագրումը:
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}