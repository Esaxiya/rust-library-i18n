use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr-ը հետ է կանչում, որը կստանա dl_phdr_info ցուցիչ յուրաքանչյուր գործընթացում միացված DSO-ի համար:
    // dl_iterate_phdr-ը նաև ապահովում է, որ դինամիկ հղիչը կողպված է կրկնության սկզբից մինչև վերջ:
    // Եթե հետադարձ զանգը վերադարձնում է ոչ զրոյական արժեք, կրկնությունը շուտ է դադարեցվում:
    // 'data' կփոխանցվի որպես երրորդ փաստարկ յուրաքանչյուր զանգի հետադարձ կապին:
    // 'size' տալիս է dl_phdr_info-ի չափը:
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Մենք պետք է վերլուծենք կառուցվածքի ID-ն և ծրագրի հիմնական վերնագրի որոշ տվյալներ, ինչը նշանակում է, որ մեզ նույնպես մի փոքր բան է պետք ELF-ի բնութագրից:
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Այժմ մենք պետք է բիտ-բիտ կրկնօրինակենք fuchsia-ի ներկայիս դինամիկ կապակցիչի կողմից օգտագործվող dl_phdr_info տիպի կառուցվածքը:
// Chromium-ն ունի նաև այս ABI սահմանը, ինչպես նաև խափանման բարձիկը:
// Ի վերջո, մենք կցանկանայինք տեղափոխել այս դեպքերը elf-search-ի օգտագործման համար, բայց անհրաժեշտ է, որ դա տրամադրենք SDK-ում, և դա դեռ չի արվել:
//
// Այսպիսով, մենք (և նրանք) ստիպված ենք օգտագործել այս մեթոդը, որը խստորեն զուգակցվում է fuchsia libc-ի հետ:
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Մենք ոչ մի կերպ չենք կարող իմանալ ստուգելու, թե արդյոք e_phoff-ը և e_phnum-ը վավեր են:
    // libc-ը պետք է դա ապահովի մեզ համար, ուստի այստեղ անվտանգ է շերտ ստեղծել:
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr-ը 64-բիթանոց ELF ծրագրի վերնագիր է `նպատակային ճարտարապետության վերջնականության մեջ:
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr-ը ներկայացնում է ELF ծրագրի վավեր վերնագիր և դրա բովանդակությունը:
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Մենք ոչ մի կերպ չենք կարող ստուգել ՝ p_addr-ը կամ p_memsz-ը վավեր են:
    // Fuchsia-ի libc-ն առաջին հերթին վերլուծում է գրառումները, սակայն այստեղ լինելու շնորհիվ այս վերնագրերը պետք է վավեր լինեն:
    //
    // NoteIter-ը չի պահանջում, որ հիմքում ընկած տվյալները լինեն վավեր, բայց պահանջում է, որ սահմանները լինեն վավեր:
    // Մենք հավատում ենք, որ libc-ն ապահովել է, որ այստեղ մեզ մոտ այդպես է:
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Նշման տեսակը կառուցման ID-ների համար:
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr-ը ներկայացնում է ELF նոտայի վերնագիր `թիրախի վերջի վերջում:
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Նշումը ներկայացնում է ELF նշում (վերնագիր + պարունակություն):
// Անունը մնացել է որպես u8 կտոր, քանի որ այն միշտ չէ, որ զրոյացվում է, և rust-ը բավականաչափ հեշտ է դարձնում ստուգել, որ բայթերը միևնույն է, համընկնում են:
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter-ը հնարավորություն է տալիս ապահով կերպով կրկնել գրառումների հատվածը:
// Այն դադարեցվում է հենց որ սխալ է տեղի ունենում կամ այլևս նշումներ չկան:
// Եթե կրկնեք անվավեր տվյալները, դրանք կգործեն այնպես, կարծես ոչ մի նշում չեն գտնվել:
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ֆունկցիայի անփոփոխ է, որ ցուցիչը և տրված չափը նշանակում են բայթերի վավեր տիրույթ, որոնք բոլորը կարող են կարդալ:
    // Այս բայթերի պարունակությունը կարող է լինել ցանկացած այլ, բայց ընդգրկույթը պետք է վավեր լինի, որպեսզի դա անվտանգ լինի:
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to-ն հավասարեցնում է 'x'-ը «to» բայթ հավասարեցմանը `ենթադրելով, որ 'to'-ը 2-ի հզորություն է:
// Սա հետևում է C/C ++ ELF վերլուծության ծածկագրի ստանդարտ օրինակին, որտեղ օգտագործվում է (x + to, 1)&-to:
// Rust-ը թույլ չի տալիս մերժել օգտագործումը, ուստի ես օգտագործում եմ
// 2-ի լրացման փոխակերպում `դա վերստեղծելու համար:
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4-ը սպառում է կտորից թվով բայթ (եթե առկա է) և լրացուցիչ երաշխավորում է, որ վերջնական հատվածը ճիշտ է դասավորված:
// Եթե կամ հայցվող բայթերի քանակը չափազանց մեծ է, կամ դրանից հետո կտորը չի կարող վերադասավորվել `բայթ գոյություն չունեցող բավարար քանակի պատճառով, Ոչ մեկը վերադարձվում է, և կտորը չի փոփոխվում:
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Այս գործառույթը չունի իրական անփոփոխություններ, որոնք զանգահարողը պետք է պահպանի, բացի այն, որ 'bytes'- ը պետք է հավասարեցված լինի կատարման համար (և որոշ ճարտարապետությունների ճշգրտության վրա):
// Elf_Nhdr դաշտերի արժեքները կարող են անհեթեթություն լինել, բայց այս ֆունկցիան չի ապահովում նման բան:
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Սա անվտանգ է, քանի դեռ բավականաչափ տեղ կա, և մենք պարզապես հաստատեցինք, որ վերը նշված հայտարարության մեջ սա չպետք է լինի անվտանգ:
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Նշենք, որ sice_of: :<Elf_Nhdr>() միշտ դասավորված է 4 բայթով:
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Ստուգեք ՝ արդյո՞ք մենք հասել ենք ավարտին:
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Մենք փոխարկում ենք nhdr-ը, բայց ուշադիր քննարկում ենք ստացված կառուցվածքը:
        // Մենք չենք վստահում namesz-ին կամ descsz-ին և ոչ մի անվստահ որոշում չենք ընդունում `ելնելով տեսակից:
        //
        // Այնպես որ, նույնիսկ եթե մենք ամբողջությամբ աղբ դուրս բերենք, մենք դեռ պետք է ապահով լինենք:
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Նշում է, որ հատվածը գործարկելի է:
const PERM_X: u32 = 0b00000001;
/// Նշում է, որ հատվածը գրելի է:
const PERM_W: u32 = 0b00000010;
/// Նշում է, որ հատվածը ընթեռնելի է:
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Գործարկման ժամանակ ներկայացնում է ELF հատված:
struct Segment {
    /// Տալիս է այս հատվածի բովանդակության գործարկման ժամանակավոր վիրտուալ հասցեն:
    addr: usize,
    /// Տալիս է այս հատվածի բովանդակության հիշողության չափը:
    size: usize,
    /// ELF ֆայլով տալիս է այս հատվածի մոդուլի վիրտուալ հասցեն:
    mod_rel_addr: usize,
    /// Տալիս է ELF ֆայլում հայտնաբերված թույլտվությունները:
    /// Այնուամենայնիվ, այս թույլտվությունները պարտադիր չէ, որ առկա են գործարկման ժամանակ:
    flags: Perm,
}

/// Մեկը կրկնենք DSO-ի հատվածների վրա:
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Ներկայացնում է ELF DSO (դինամիկ ընդհանուր օբյեկտ):
/// Այս տեսակն ավելի շուտ հղում է իրական ԴՍՕ-ում պահված տվյալների, քան պատրաստում է իր սեփական պատճենը:
struct Dso<'a> {
    /// Դինամիկ հղիչը միշտ մեզ անուն է տալիս, նույնիսկ եթե անունը դատարկ է:
    /// Հիմնական գործարկելիի դեպքում այս անունը դատարկ կլինի:
    /// Համօգտագործվող օբյեկտի դեպքում դա կլինի սոնոմը (տե՛ս DT_SONAME):
    name: &'a str,
    /// Fuchsia-ի վրա գրեթե բոլոր binaries ունեն կառուցված ID-ներ, բայց դա խիստ պահանջ չէ:
    /// Դրանից հետո DSO-ի տեղեկատվությունը իրական ELF ֆայլի հետ համադրելու ոչ մի տարբերակ չկա, եթե build_id գոյություն չունի, ուստի մենք պահանջում ենք, որ յուրաքանչյուր ՊԱԳ այստեղ ունենա մեկը:
    ///
    /// DSO-ն առանց build_id անտեսվում է:
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Այս DSO-ի հատվածների վրայով վերադարձնում է կրկնիչը:
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Այս սխալները ծածկագրում են այն խնդիրները, որոնք առաջանում են յուրաքանչյուր ՊՍO-ի վերաբերյալ տեղեկատվությունը վերլուծելիս:
///
enum Error {
    /// NameError նշանակում է, որ սխալ է տեղի ունեցել C ոճի տողը rust տողի վերափոխելիս:
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError-ը նշանակում է, որ մենք չենք գտել կառուցման ID:
    /// Դա կարող է լինել այն պատճառով, որ DSO-ն չունի կառուցողական ID, կամ այն պատճառով, որ կառուցվածքի ID-ն պարունակող հատվածը սխալ է:
    ///
    BuildIDError,
}

/// Theանգահարում է կամ 'dso' կամ 'error' յուրաքանչյուր DSO-ի համար, որը գործընթացին միացված է դինամիկ կապակցիչով:
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter-ը, որն ուտում է foreach DSO կոչվող մեթոդներից մեկը:
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr-ն ապահովում է, որ info.name-ը մատնանշի վավեր վայրը:
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Այս գործառույթը տպում է Fuchsia-ի խորհրդանիշի նշագրումը DSO-ում պարունակվող բոլոր տեղեկությունների համար:
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}