//! Backtrace աջակցություն ՝ օգտագործելով libunwind/gcc_s/etc API:
//!
//! Այս մոդուլը պարունակում է լիքը փաթաթելու ունակություն ՝ օգտագործելով libunwind ոճի API-ներ:
//! Նկատի ունեցեք, որ կա libunwind-ի նման API-ի իրականացման մի ամբողջ խումբ, և սա պարզապես փորձում է համատեղելի լինել միանգամից բոլորի հետ `ընտրելու փոխարեն:
//!
//!
//! Libunwind API-ն սնուցվում է `_Unwind_Backtrace`-ով և գործնականում շատ հուսալի է հետադարձ կապ առաջացնելու հարցում:
//! Միանգամայն պարզ չէ, թե ինչպես է դա ստացվում (շրջանակի ցուցիչներ. Eh_frame-ի տեղեկատվություն? Երկուսն էլ), բայց կարծես թե աշխատում է:
//!
//! Այս մոդուլի բարդության մեծ մասը `հարթության տարբեր տարբերությունների լուծումն է libunwind-ի ներդրումներում:
//! Հակառակ դեպքում սա բավականին պարզ Rust-ն է, որը պարտադիր է libunwind API-ներին:
//!
//! Սա ներկայումս բոլոր ոչ-Windows պլատֆորմների համար լռելյայն անջատող API-ն է:
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Libunwind հումքի ցուցիչով այն պետք է հասանելի լինի միայն ընթերցվող թեմաներով անվտանգ եղանակով, ուստի `Sync` է:
// `Clone`-ով այլ թեմաներին ուղարկելիս մենք միշտ անցնում ենք մի տարբերակի, որը չի պահում ներքին ցուցիչները, այնպես որ մենք նույնպես պետք է լինենք `Send`:
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Թվում է, որ OSX-ում `_Unwind_FindEnclosingFunction-ը, ցուցիչը վերադարձնում է ... ինչ-որ անհասկանալի:
        // Դա հաստատապես միշտ չէ, որ կցում է գործառույթը `ինչ-ինչ պատճառով:
        // Ինձ համար միանգամայն պարզ չէ, թե ինչ է կատարվում այստեղ, այնպես որ հիմա դա վատատեսորեն գնահատեք և միշտ վերադարձեք IP-ն:
        //
        // Ուշադրություն դարձրեք, `skip_inner_frames.rs` թեստը բաց է թողնված OSX-ի վրա `այս դրույթի պատճառով, և եթե դա ամրագրված է, տեսականորեն այդ թեստը կարող է անցկացվել OSX-ի վրա:
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Հետադարձ հետադարձ կապի համար օգտագործեք գրադարանի միջերեսը
///
/// Նկատի ունեցեք, որ մահացած կոդը թույլատրվում է, քանի որ այստեղ պարզապես կապակցիչներ են, որոնք iOS-ը չի օգտագործում դրանցից բոլորը, բայց ավելի շատ հատուկ կոնֆիգուրացիաների ավելացումը չափազանց շատ է աղտոտում կոդը
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // օգտագործվում է միայն ARM EABI-ի կողմից
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // IOS-ում ոչ մի բնիկ _Հրապարակել_Բացառություն
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0-ից հասանելի, պետք է լավ լինի մեր նպատակների համար
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Այս ֆունկցիան սխալ անուն է. Այս շրջանակի Canonical Frame Հասցեն ստանալու փոխարեն (զանգահարողի շրջանակի SP-ն) այն վերադարձնում է այս շրջանակի SP-ն:
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x օգտագործում է կողմնակալ CFA արժեք, ուստի մենք պետք է օգտագործենք _Unwind_GetGR-ը `ստույգ ցուցիչը գրանցելու համար (%r15) գրանցելու փոխարեն` _Unwind_GetCFA-ի վրա հույս դնելու համար:
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android-ի և arm-ի վրա `_Unwind_GetIP` ֆունկցիան և մի խումբ այլ խմբեր մակրոներ են, ուստի մենք սահմանում ենք մակրոների ընդլայնում պարունակող գործառույթներ:
    //
    //
    // TODO: հղում դեպի վերնագրի ֆայլը, որը սահմանում է այս մակրոները, եթե կարողանաք գտնել:
    // (Ես, ֆիցցեն, չեմ գտնում վերնագրի ֆայլը, որից այս մակրո ընդլայնումներից որոշները սկզբնապես փոխառվել էին):
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 բազուկի ցուցիչն է թևի վրա:
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Այս գործառույթը նույնպես գոյություն չունի Android-ի կամ ARM/Linux-ի վրա, այնպես որ այն դարձեք ոչ-op:
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}