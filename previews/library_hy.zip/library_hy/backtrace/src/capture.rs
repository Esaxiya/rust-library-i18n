use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Սեփական և ինքնամեկուսացված հետադարձի ներկայացուցչություն:
///
/// Այս կառուցվածքը կարող է օգտագործվել ծրագրի տարբեր կետերում հետադարձ կապ գրավելու համար, այնուհետև օգտագործվել ստուգելու համար, թե որն է եղել այդ ժամանակ հետադարձը:
///
///
/// `Backtrace` իր `Debug` ներդրման միջոցով աջակցում է հետադարձ նյութերի բավականին տպագրությանը:
///
/// # Պահանջվող հատկություններ
///
/// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Շրջանակներն այստեղ թվարկված են տուփի վերևից ներքև
    frames: Vec<BacktraceFrame>,
    // Ինդեքսը, որը, մեր համոզմամբ, հետադարձի իրական մեկնարկն է ՝ բաց թողնելով `Backtrace::new` և `backtrace::trace` շրջանակների նման շրջանակներ:
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Շրջանակի գրավված տարբերակը հետադարձ գծում:
///
/// Այս տեսակը վերադարձվում է որպես ցուցակ `Backtrace::frames`-ից և ներկայացնում է գրավադրված հետադարձ գծի մեկ կույտի շրջանակ:
///
/// # Պահանջվող հատկություններ
///
/// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Խորհրդանիշի գրավված տարբերակը հետադարձ գծում:
///
/// Այս տեսակը վերադարձվում է որպես ցուցակ `BacktraceFrame::symbols`-ից և ներկայացնում է հետադարձի խորհրդանիշի մետատվյալները:
///
/// # Պահանջվող հատկություններ
///
/// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Հետադարձ կապ է գրավում այս գործառույթի զանգի վայրում ՝ վերադարձնելով պատկանող ներկայացուցչություն:
    ///
    /// Այս ֆունկցիան օգտակար է հետադարձ կապը որպես Rust-ի օբյեկտ ներկայացնելու համար: Այս վերադարձված արժեքը կարող է ուղարկվել շղթաների միջով և տպվել այլուր, և այս արժեքի նպատակն է ամբողջովին ինքնամփոփ լինել:
    ///
    /// Նկատենք, որ որոշ հարթակներում ամբողջական հետադարձ կապ ձեռք բերելը և այն լուծելը կարող է չափազանց թանկ նստել:
    /// Եթե ձեր դիմումի համար գինը չափազանց մեծ է, խորհուրդ է տրվում փոխարենը օգտագործել `Backtrace::new_unresolved()`, որը խուսափում է խորհրդանիշի լուծման քայլից (որը սովորաբար տևում է ամենաերկար) և թույլ է տալիս հետաձգել այն ավելի ուշ ժամկետում:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ուզում են համոզվել, որ այստեղ կա շրջանակ, որը պետք է հեռացվի
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new`-ի նման, բացի այն, որ սա չի լուծում որևէ խորհրդանիշ, սա պարզապես գրավում է հետադարձ ուղին որպես հասցեների ցուցակ:
    ///
    /// Ավելի ուշ `resolve` ֆունկցիան կարող է կոչվել լուծել այս հետընտրական խորհրդանիշները ընթերցելի անունների:
    /// Այս գործառույթը գոյություն ունի, քանի որ լուծման գործընթացը երբեմն կարող է զգալի ժամանակ պահանջել, մինչդեռ ցանկացած հետադարձ ուղի կարող է տպագրվել միայն հազվադեպ:
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ոչ մի խորհրդանիշ անուն
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // խորհրդանիշների անունները, որոնք այժմ առկա են
    /// ```
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    ///
    ///
    #[inline(never)] // ուզում են համոզվել, որ այստեղ կա շրջանակ, որը պետք է հեռացվի
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Վերադարձնում է այն շրջանակները, երբ սկսեց նկարել այս հետադարձ ուղին:
    ///
    /// Այս հատվածի առաջին մուտքագրումը, ամենայն հավանականությամբ, `Backtrace::new` գործառույթն է, և վերջին շրջանակը, հավանաբար, մի բան է այն մասին, թե ինչպես է սկսվել այս շարանը կամ հիմնական գործառույթը:
    ///
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Եթե այս հետադարձ կապը ստեղծվել է `new_unresolved`-ից, ապա այս գործառույթը կլուծի հետադարձի բոլոր հասցեները դրանց խորհրդանշական անուններով:
    ///
    ///
    /// Եթե այս հետադարձ գործընթացը նախկինում լուծված է կամ ստեղծվել է `new`-ի միջոցով, այս գործառույթը ոչինչ չի ձեռնարկում:
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Նույնը, ինչ `Frame::ip`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Նույնը, ինչ `Frame::symbol_address`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Նույնը, ինչ `Frame::module_base_address`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Վերադարձնում է այս շրջանակի համապատասխան խորհրդանիշների ցուցակը:
    ///
    /// Սովորաբար յուրաքանչյուր շրջանակում կա միայն մեկ խորհրդանիշ, բայց երբեմն, եթե մի շարք գործառույթներ շարադրված են մեկ շրջանակի մեջ, ապա բազմաթիվ խորհրդանիշներ կվերադարձվեն:
    /// Թվարկված առաջին խորհրդանիշը "innermost function" է, մինչդեռ վերջին խորհրդանիշը ամենահեռինն է (վերջին զանգահարողը):
    ///
    /// Նկատի ունեցեք, որ եթե այս շրջանակը եկել է չլուծված հետադարձ գծից, ապա դա կվերադարձնի դատարկ ցուցակ:
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Նույնը, ինչ `Symbol::name`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Նույնը, ինչ `Symbol::addr`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Նույնը, ինչ `Symbol::filename`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Նույնը, ինչ `Symbol::lineno`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Նույնը, ինչ `Symbol::colno`-ը
    ///
    /// # Պահանջվող հատկություններ
    ///
    /// Այս ֆունկցիայի համար անհրաժեշտ է, որ `backtrace` crate-ի `std` հատկությունը միացված լինի, իսկ `std` հատկությունը ՝ լռելյայն, միացված է:
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Ուղիներ տպելիս մենք փորձում ենք մերկացնել cwd-ն, եթե դա գոյություն ունի, հակառակ դեպքում մենք պարզապես տպում ենք ուղին այնպես, ինչպես կա:
        // Նշենք, որ մենք դա անում ենք նաև միայն կարճ ձևաչափի համար, քանի որ եթե այն լի է, մենք ենթադրաբար ցանկանում ենք տպել ամեն ինչ:
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}