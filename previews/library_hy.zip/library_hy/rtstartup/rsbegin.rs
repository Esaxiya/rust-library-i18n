// rsbegin.o և rsend.o այսպես կոչված "compiler runtime startup objects" են:
// Դրանք պարունակում են կոդ, որն անհրաժեշտ է կազմողի գործարկման ժամանակը ճիշտ նախանշելու համար:
//
// Երբ գործարկվող կամ dylib նկարը միացված է, բոլոր օգտագործողների կոդերը և գրադարանները "sandwiched" են այս երկու օբյեկտի ֆայլերի միջև, այնպես որ կոդը կամ տվյալները rsbegin.o-ից դառնում են առաջինը պատկերի համապատասխան բաժիններում, մինչդեռ rsend.o-ի ծածկագիրը և տվյալները դառնում են վերջինը:
// Այս էֆեկտը կարող է օգտագործվել հատվածի սկզբում կամ վերջում խորհրդանիշներ տեղադրելու, ինչպես նաև ցանկացած անհրաժեշտ վերնագիր կամ էջատակ տեղադրելու համար:
//
// Նկատի ունեցեք, որ մոդուլի փաստացի մուտքի կետը տեղակայված է C գործարկման ժամանակի գործարկման օբյեկտում (սովորաբար կոչվում է `crtX.o`), որն այնուհետև կանչում է գործարկման այլ բաղադրիչների նախնական սկզբնական հետադարձումները (գրանցված մեկ այլ հատուկ պատկերի բաժնի միջոցով):
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Դեպի շրջանակի սկիզբը նշաններն ազատում են տեղեկատվության բաժնից
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Քերծվածքների տարածություն `ցանկանալով պահպանել գրքերի ներքին պահպանումը:
    // Սա սահմանվում է որպես `struct object` $ GCC/unwind-dw2-fde.h:
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Լարել info registration/deregistration ռեժիմները:
    // Տեսեք libpanic_unwind-ի փաստաթղթերը:
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // գրանցել լիցքաթափել տեղեկատվությունը մոդուլի գործարկման մասին
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // անջատման մասին գրանցումը
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-ի հատուկ init/uninit սովորական գրանցում
    pub mod mingw_init {
        // MinGW-ի գործարկման օբյեկտները (crt0.o/dllcrt0.o) կանչելու են գլոբալ կոնստրուկտորները .ctors և .dtors բաժիններում գործարկման և ելքի վերաբերյալ:
        // DLL-ների դեպքում դա արվում է, երբ DLL-ն բեռնվում և բեռնաթափվում է:
        //
        // Կապողը կկարգավորի բաժինները, ինչը հավաստիացնում է, որ մեր հետադարձ կապերը գտնվում են ցուցակի վերջում:
        // Քանի որ կոնստրուկտորները գործում են հակառակ կարգով, դա ապահովում է, որ մեր հետադարձ պատասխանները կատարվեն առաջին և վերջինները:
        //
        //

        #[link_section = ".ctors.65535"] // .եկտորներ. * ՝ C սկզբնական հետադարձ պատասխաններ
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C դադարեցման հետադարձ պատասխաններ
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}