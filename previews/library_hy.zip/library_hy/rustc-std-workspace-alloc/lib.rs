#![feature(no_core)]
#![no_core]

// Տե՛ս rustc-std-workspace-core, թե ինչու է այս crate-ն անհրաժեշտ:

// Վերանվանեք crate-ը `liballoc-ում հատկացված մոդուլի հետ հակասությունից խուսափելու համար:
extern crate alloc as foo;

pub use foo::*;