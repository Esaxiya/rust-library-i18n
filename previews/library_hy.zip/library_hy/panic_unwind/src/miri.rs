//! panics-ի փաթաթում Miri-ի համար:
use alloc::boxed::Box;
use core::any::Any;

// Payանրաբեռնվածության տեսակը, որը Miri շարժիչը տարածում է մեզ համար փաթաթելու միջոցով:
// Պետք է լինի ցուցիչի չափ:
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Լիցքաթափումը սկսելու համար տրամադրված է Miri-ի արտաքին գործառույթը:
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Բեռը, որը մենք անցնում ենք `miri_start_panic`-ին, կլինի հենց այն փաստարկը, որը մենք ստանում ենք ստորև `cleanup`-ում:
    // Այսպիսով, մենք պարզապես մեկ անգամ հավաքում ենք այն, ցուցիչի չափի ինչ-որ բան ստանալու համար:
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Վերականգնել հիմքում ընկած `Box`-ը:
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}