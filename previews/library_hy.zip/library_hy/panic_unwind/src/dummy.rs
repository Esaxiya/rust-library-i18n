//! Լարվում է *wasm32* թիրախի համար:
//!
//! Այս պահին մենք դրան չենք աջակցում, այնպես որ սա պարզապես կոճղեր է:

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}