//! Windows SEH
//!
//! Windows-ի վրա (ներկայումս միայն MSVC-ում), բացառության գործարկման լռելյայն մեխանիզմը Structured Exception Handling (SEH) է:
//! Սա բավականին տարբերվում է, քան Գաճաճի վրա հիմնված բացառությունների մշակումը (օրինակ, այն, ինչ այլ unix պլատֆորմներն են օգտագործում) կազմողի ներքին մասի առումով, ուստի LLVM-ից պահանջվում է ունենալ SEH-ի լրացուցիչ լրացուցիչ աջակցություն:
//!
//! Մի խոսքով, այն, ինչ տեղի է ունենում այստեղ, հետևյալն է.
//!
//! 1. `panic` ֆունկցիան զանգահարում է ստանդարտ Windows ֆունկցիան `_CxxThrowException` ՝ C++ գցելու համար ՝ բացառության նման, հարուցելով լիցքաթափման գործընթացը:
//! 2.
//! Կազմողի կողմից առաջացած բոլոր վայրէջքի բարձիկները օգտագործում են `__CxxFrameHandler3` անհատականության գործառույթ, որը CRT-ի ֆունկցիա է, և Windows-ի անլար ծածկագիրը կօգտագործի այս անհատականության գործառույթը `դեղի վրա մաքրման բոլոր կոդերը կատարելու համար:
//!
//! 3. Կազմողների կողմից առաջ եկած `invoke` զանգերը ունեն վայրէջքի պահոց, որը տեղադրված է որպես `cleanuppad` LLVM հրահանգ, որը ցույց է տալիս մաքրման ռեժիմի մեկնարկը:
//! Անհատականությունը (ՔԿՌ-ով սահմանված 2-րդ քայլում) պատասխանատու է մաքրման ռեժիմները վարելու համար:
//! 4. Ի վերջո, `try` ներքին (որը կազմված է կազմողի կողմից) "catch" ծածկագիրը կատարվում է և ցույց է տալիս, որ վերահսկողությունը պետք է վերադառնա Rust:
//! Դա արվում է `catchswitch` գումարած `catchpad` հրահանգի միջոցով ՝ LLVM IR տերմինով, վերջապես վերադարձնելով նորմալ կառավարումը ծրագրին ՝ `catchret` հրահանգով:
//!
//! Որոշ հատուկ տարբերություններ gcc-ի վրա հիմնված բացառությունների գործածությունից.
//!
//! * Rust-ը չունի անհատականության անհատական գործառույթ, այն փոխարենը *միշտ*`__CxxFrameHandler3` է: Բացի այդ, լրացուցիչ զտիչ չի կատարվում, ուստի մենք ի վերջո որսում ենք ցանկացած C++ բացառություն, որը պատահաբար նման է մեր նետածին:
//! Նկատի ունեցեք, որ Rust-ի մեջ բացառություն գցելն, այնուամենայնիվ, չսահմանված վարք է, ուստի դա պետք է լավ լինի:
//! * Մենք ստացանք որոշ տվյալներ `փաթաթելու սահմանը հատելու միջոցով, մասնավորապես `Box<dyn Any + Send>`-ը: Ինչպես Գաճաճ բացառություններով, այս երկու ցուցիչները նույնպես պահվում են որպես բեռ ՝ բացառությամբ բուն դեպքի:
//! Այնուամենայնիվ, MSVC-ի վրա կույտի լրացուցիչ բաշխման կարիք չկա, քանի որ զանգի բույրը պահպանվում է մինչ ֆիլտրի գործառույթները կատարվում են:
//! Սա նշանակում է, որ ցուցիչները փոխանցվում են ուղղակիորեն `_CxxThrowException`, որոնք այնուհետև վերականգնվում են ֆիլտրի գործառույթում, որը պետք է գրվի `try` ներքինի բուրգի շրջանակում:
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Սա պետք է լինի Ընտրանք, քանի որ մենք վերցնում ենք բացառությունը հղումով, և դրա քայքայողը կատարվում է C++ գործարկման ժամանակով:
    // Երբ մենք վերցնում ենք Տուփը բացառությունից, մենք պետք է բացառությունը թողնենք գործող վիճակում, որպեսզի նրա կործանիչը գործի առանց տուփը կրկնակի նետելու:
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Առաջին հերթին ՝ տիպի սահմանումների մի ամբողջ փունջ: Այստեղ մի քանի հատուկ պլատֆորմի տարօրինակություններ կան, և շատ բան, որոնք պարզապես բացահայտորեն պատճենվել են LLVM-ից:Այս ամենի նպատակն է իրականացնել `panic` ֆունկցիան ստորև `_CxxThrowException`-ին զանգի միջոցով:
//
// Այս ֆունկցիան տանում է երկու փաստարկ: Առաջինը ցուցիչ է դեպի մեր փոխանցած տվյալների, որն այս պարագայում մեր trait օբյեկտն է:Բավականին հեշտ է գտնել:Հաջորդը, սակայն, ավելի բարդ է:
// Սա `_ThrowInfo` կառուցվածքի ցուցիչ է, և այն հիմնականում նախատեսված է պարզապես նկարագրել նետված բացառությունը:
//
// Ներկայումս այս տեսակի [1]-ի սահմանումը մի փոքր մազոտ է, և հիմնական տարօրինակությունը (և տարբերությունը առցանց հոդվածից) այն է, որ 32-բիթանոց ցուցիչները ցուցիչներ են, բայց 64-բիթանոց ցուցիչները արտահայտվում են որպես 32-բիթանոց օֆսեթներ `__ImageBase` խորհրդանիշ:
//
// Ստորև ներկայացված մոդուլներում `ptr_t` և `ptr!` մակրոներն օգտագործվում են դա արտահայտելու համար:
//
// Տիպի սահմանումների լաբիրինթոսը նույնպես սերտորեն հետևում է, թե ինչ է թողարկում LLVM-ն այս տեսակի գործողության համար: Օրինակ, եթե այս C++ կոդը կազմեք MSVC-ի վրա և արտանետեք LLVM IR:
//
//      #include <stdint.h>
//
//      կառուցել ժանգը_ պանիկա {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      անվավեր foo() { rust_panic a = {0, 1};
//          նետել ա;}
//
// Ըստ էության, դա այն է, ինչ մենք փորձում ենք ընդօրինակել: Ստորև բերված հաստատուն արժեքների մեծ մասը ընդօրինակված է LLVM-ից,
//
// Համենայն դեպս, այս կառույցները բոլորն էլ կառուցված են նույն ձևով, և դա մեզ համար պարզապես որոշակիորեն խոսուն է:
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Նկատի ունեցեք, որ մենք միտումնավոր անտեսում ենք այստեղ մանգլինգի կանոնները. Մենք չենք ուզում, որ C++ -ը կարողանա որսալ Rust panics-ը ՝ պարզապես հայտարարելով `struct rust_panic`:
//
//
// Ձևափոխելիս համոզվեք, որ տողի անվան տողը համապատասխանում է `compiler/rustc_codegen_llvm/src/intrinsic.rs`-ում օգտագործվածին:
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Այստեղ առաջատար `\x01` բայթը իրականում կախարդական ազդանշան է LLVM-ին * * չկիրառելու որևէ այլ մանգլինգի նման `_` բնույթով նախածանց:
    //
    //
    // Այս խորհրդանիշը C++ ի `std::type_info`-ի կողմից օգտագործվող սեղանն է:
    // `std::type_info` տիպի օբյեկտները, տիպի նկարագրիչները ցուցիչ ունեն այս աղյուսակի վրա:
    // Տիպի նկարագրիչները վկայակոչվում են վերևում նշված C++ EH կառուցվածքներով, և որոնք մենք կառուցում ենք ստորև:
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Այս տեսակի նկարագրիչը օգտագործվում է միայն բացառություն գցելիս:
// Բռնման մասը մշակվում է փորձի բնույթի միջոցով, որն առաջացնում է իր սեփական TypeDescriptor-ը:
//
// Դա լավ է, քանի որ MSVC գործառույթը օգտագործում է տողի համեմատություն տիպի անվանման համար, որպեսզի համապատասխանի TypeDescript-ին, այլ ոչ թե ցուցիչի հավասարությանը:
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Քայքայիչն օգտագործվում է, եթե C++ կոդը որոշում է գրավել բացառությունը և գցել այն ՝ առանց այն տարածելու:
// Փորձի բնորոշ որսման մասը բացառության օբյեկտի առաջին բառը կդարձնի 0, այնպես, որ այն բաց թողնվի ոչնչացնողի կողմից:
//
// Նշենք, որ x86 Windows-ն օգտագործում է "thiscall" կոչման պայմանագիր C++ անդամ գործառույթների համար ՝ լռելյայն "C" կոչման պայմանագրի փոխարեն:
//
// Բացառություն_պատճեն գործառույթը այստեղ մի փոքր առանձնահատուկ է. Այն կանչվում է MSVC գործառույթի կողմից try/catch բլոկի տակ և panic-ը, որը մենք ստեղծում ենք այստեղ, կօգտագործվի որպես բացառության կրկնօրինակման արդյունք:
//
// Սա օգտագործվում է C++ գործառույթի ժամանակ ՝ std::exception_ptr-ով բացառություններ ֆիքսելու համար, ինչը մենք չենք կարող աջակցել, քանի որ Box<dyn Any>կլոնային չէ
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException-ն ամբողջությամբ կատարում է այս կույտի շրջանակի վրա, այնպես որ այլևս `data`-ը կույտ տեղափոխելու անհրաժեշտություն չկա:
    // Մենք պարզապես ստեկի ցուցիչ ենք փոխանցում այս գործառույթին:
    //
    // ManualDrop-ն այստեղ անհրաժեշտ է, քանի որ մենք չենք ուզում, որ լիցքաթափվելիս բացառությունը հանվի:
    // Փոխարենը, այն կհեռացվի բացառությամբ_ մաքրության, որը կանչվում է C++ գործարկման ժամանակի ընթացքում:
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Սա ... կարող է զարմանալի թվալ, և արդարացիորեն այդպես է:32-բիթանոց MSVC-ի վրա այս կառուցվածքի ցուցիչները հենց դա են, ցուցիչները:
    // 64-բիթանոց MSVC-ի վրա, սակայն, կառույցների միջև ցուցիչները ավելի շուտ արտահայտվում են որպես 32-բիթանոց փոխհատուցում `__ImageBase`-ից:
    //
    // Հետևաբար, 32-բիթանոց MSVC-ի վրա մենք կարող ենք հայտարարագրել այս բոլոր ցուցիչները վերը նշված «ստատիկայում»:
    // 64-բիթանոց MSVC-ով մենք ստիպված կլինենք արտահայտել ցուցիչների հանումը ստատիկայում, ինչը Rust-ը ներկայումս թույլ չի տալիս, ուստի մենք իրականում չենք կարող դա անել:
    //
    // Հաջորդ ամենալավ բանը, ուրեմն, այս գործերը լրացնելն է գործարկման պահին (խուճապը, միևնույն է, արդեն "slow path" է):
    // Այսպիսով, այստեղ մենք բոլոր այդ ցուցիչների դաշտերը վերամեկնաբանում ենք որպես 32-բիթանոց ամբողջ թվեր և հետագայում պահում համապատասխան արժեքը դրանում (ատոմային առումով, քանի որ կարող է տեղի ունենալ զուգահեռ panics):
    //
    // Տեխնիկապես գործառույթը, հավանաբար, կկատարի ոչ ատոմային ընթերցում այս դաշտերի վերաբերյալ, բայց տեսականորեն նրանք երբեք չեն կարդում *սխալ* արժեքը, ուստի այն չպետք է լինի շատ վատ ...
    //
    // Ամեն դեպքում, մենք, ըստ էության, պետք է անենք նման մի բան, քանի դեռ չենք կարողացել ավելի շատ գործողություններ արտահայտել ստատիկայում (և մենք երևի երբեք չենք կարողանա):
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL բեռը այստեղ նշանակում է, որ մենք այստեղ ենք ստացել __վստահության_փորձի (...) բռնելուց:
    // Դա տեղի է ունենում, երբ բռնվում է ոչ Rust օտարերկրյա բացառություն:
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Կազմողի կողմից դա պահանջվում է գոյություն ունենալու համար (օրինակ `դա լեզու է), բայց այն երբեք չի կոչվում կազմողի կողմից, քանի որ __C_specific_handler կամ _except_handler3 անհատականության գործառույթն է, որը միշտ օգտագործվում է:
//
// Ուստի սա պարզապես վիժեցնող կոճղ է:
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}