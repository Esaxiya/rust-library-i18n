# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust üçün iş vaxtı arxa arxalar əldə etmək üçün kitabxana.
Bu kitabxana, işləmək üçün proqramlı bir interfeys təmin edərək standart kitabxananın dəstəyini artırmağı hədəfləyir, eyni zamanda cari geriyə izi asanlıqla libstd's panics kimi çap etməyi dəstəkləyir.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Sadəcə bir geriyə çəkmək və sonrakı bir müddətə qədər bununla məşğul olmağı təxirə salmaq üçün ən üst səviyyəli `Backtrace` tipini istifadə edə bilərsiniz.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Bununla birlikdə, faktiki axtarış funksiyasına daha çox xammal əldə etmək istəyirsinizsə, birbaşa `trace` və `resolve` funksiyalarından istifadə edə bilərsiniz.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Bu təlimat göstəricisini bir simvol adına həll edin
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // növbəti kadrlara davam edin
    });
}
```

# License

Bu layihə hər hansı birinə görə lisenziyalaşdırılmışdır

 * Apache Lisenziyası, Versiya 2.0, ([LICENSE-APACHE](LICENSE-APACHE) və ya http://www.apache.org/licenses/LICENSE-2.0)
 * MIT lisenziyası ([LICENSE-MIT](LICENSE-MIT) və ya http://opensource.org/licenses/MIT)

seçiminizə görə.

### Contribution

Başqa bir şəkildə açıq şəkildə ifadə etmədiyiniz təqdirdə, Apache-2.0 lisenziyasında müəyyənləşdirildiyi kimi arxa plana daxil edilmək üçün qəsdən təqdim olunan hər hansı bir töhfə, əlavə şərt və şərtlər olmadan yuxarıda göstərilən ikili lisenziyaya malik olacaqdır.







