use core::ffi::c_void;
use core::fmt;

/// Cari zəng yığını yoxlayır, bütün aktiv çərçivələri yığın izini hesablamaq üçün verilən qapağa keçir.
///
/// Bu funksiya, bir proqram üçün yığın izlərinin hesablanmasında bu kitabxananın iş atıdır.Verilən bağlanma `cb`, yığındakı zəng çərçivəsi haqqında məlumatı təmsil edən bir `Frame` nümunəsi verilir.
/// Bağlama yuxarıdan aşağıya doğru bir şəkildə verilir (ən son funksiyalar ilk olaraq adlandırılır).
///
/// Bağlanmanın qaytarma dəyəri, arxa izin davam edib etməyəcəyinin bir göstəricisidir.`false` qaytarma dəyəri geri izi sonlandıracaq və dərhal geri dönəcəkdir.
///
/// Bir `Frame` əldə edildikdən sonra, ehtimal ki, `ip` (təlimat göstəricisi) və ya simvol ünvanını ad və/və ya fayl adı/sətir nömrəsinin öyrənilə biləcəyi bir `Symbol`-ə çevirmək üçün `backtrace::resolve`-ə zəng etmək istəyəcəksiniz.
///
///
/// Diqqət yetirin ki, bu nisbətən aşağı səviyyəli bir funksiyadır və məsələn, daha sonra yoxlanılacaq bir geriyə iz götürmək istəsəniz, `Backtrace` növü daha uyğun ola bilər.
///
/// # Tələb olunan xüsusiyyətlər
///
/// Bu funksiya `backtrace` crate-nin `std` xüsusiyyətinin aktiv olmasını tələb edir və `std` xüsusiyyəti varsayılan olaraq aktivdir.
///
/// # Panics
///
/// Bu funksiya heç vaxt panic olmamağa çalışır, lakin `cb` panics təmin edərsə, bəzi platformalar prosesi ləğv etməyə ikiqat panic məcbur edəcəkdir.
/// Bəzi platformalar daxili olaraq geri qaytarılmayan geri çağırışlardan istifadə edən bir C kitabxanasından istifadə edir, buna görə `cb`-dən çaxnaşma bir prosesi ləğv edə bilər.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // geriyə baxmağa davam edin
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` ilə eyni, yalnız sinxronizasiya edildiyi üçün təhlükəlidir.
///
/// Bu funksiyada sinxronizasiya zəmanəti yoxdur, lakin bu crate-nin `std` xüsusiyyəti tərtib edilmədikdə mövcuddur.
/// Daha çox sənəd və nümunə üçün `trace` funksiyasına baxın.
///
/// # Panics
///
/// `cb` panikasında xəbərdarlıqlar üçün `trace` məlumatlarına baxın.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Bir geri çəkilmənin bir çərçivəsini təmsil edən bir trait, bu crate-nin `trace` funksiyasına səbəb oldu.
///
/// İzləmə funksiyasının bağlanması çərçivələr veriləcək və çərçivə praktik olaraq göndərilir, çünki əsas tətbiqetmə həmişə işləmə müddətinə qədər məlum deyildir.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Bu çərçivənin cari təlimat göstəricisini qaytarır.
    ///
    /// Bu normalda kadrda icra ediləcək növbəti təlimatdır, lakin bütün tətbiqetmələr bunu 100% dəqiqliklə göstərmir (lakin ümumiyyətlə olduqca yaxındır).
    ///
    ///
    /// Bu dəyəri bir simvol adına çevirmək üçün `backtrace::resolve`-ə ötürmək məsləhətdir.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Bu çərçivənin cari yığma göstəricisini qaytarır.
    ///
    /// Bir arxa tərəfin bu çərçivə üçün yığın göstəricisini bərpa edə bilməməsi halında, boş bir göstərici qaytarılır.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Bu funksiyanın çərçivəsinin başlanğıc simvolu ünvanını qaytarır.
    ///
    /// Bu, `ip` tərəfindən funksiyanın başlanğıcına qaytarılmış təlimat göstəricisini bu dəyəri geri qaytarmağa çalışacaqdır.
    ///
    /// Bəzi hallarda, arxa tərəflər `ip`-i bu funksiyadan geri qaytaracaqdır.
    ///
    /// Geri qaytarılmış dəyər, `backtrace::resolve` yuxarıda verilmiş `ip`-də uğursuz olduqda bəzən istifadə edilə bilər.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Çərçivənin aid olduğu modulun əsas ünvanını qaytarır.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Bunun ilk növbədə Miri'nin ev sahibi platformadan üstün olmasını təmin etməsi lazımdır
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // yalnız dbghelp-də simvollaşdırmaqda istifadə olunur
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}