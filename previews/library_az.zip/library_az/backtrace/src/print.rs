#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Backtraces üçün formatlayıcı.
///
/// Bu tip, arxa izin haradan gəldiyindən asılı olmayaraq bir geriyə iz yazdırmaq üçün istifadə edilə bilər.
/// `Backtrace` tipiniz varsa, `Debug` tətbiqi bu çap formatını onsuz da istifadə edir.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Çap edə biləcəyimiz çap üslubları
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// İdeal olaraq yalnız müvafiq məlumatları ehtiva edən daha az geriyə izi yazdırır
    Short,
    /// Mümkün olan bütün məlumatları özündə əks etdirən geriyə izi yazdırır
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Verilən `fmt`-ə çıxış yazacaq yeni bir `BacktraceFmt` yaradın.
    ///
    /// `format` arqumenti, arxa cızmanın çap olunduğu stili idarə edəcək və `print_path` arqumenti, `BytesOrWideString` fayl adlarını çap etmək üçün istifadə ediləcək.
    /// Bu növün özü heç bir fayl adının yazdırılmasını etməz, ancaq bunun üçün bu geri çağırış tələb olunur.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Çap olunmaq üzrə olan arxa plan üçün bir giriş yazdırır.
    ///
    /// Backtraces-in daha sonra tam olaraq simvollaşdırılması üçün bəzi platformalarda bu tələb olunur və əks halda bu yalnız `BacktraceFmt` yaratdıqdan sonra çağırdığınız ilk metod olmalıdır.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Backtrace çıxışına bir çərçivə əlavə edir.
    ///
    /// Bu öhdəlik, həqiqətən bir çərçivə çap etmək üçün istifadə edilə bilən bir `BacktraceFrameFmt`-in bir RAII nümunəsini qaytarır və məhv edildikdə çərçivə sayacını artıracaqdır.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Backtrace çıxışı tamamlayır.
    ///
    /// Bu, hazırda qadağandır, lakin future arxa plan formatları ilə uyğunluq üçün əlavə edilmişdir.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Hazırda future əlavələrinə icazə vermək üçün bu hook daxil olmaqla, heç bir işə yaramır.
        Ok(())
    }
}

/// Bir arxa izin yalnız bir çərçivəsi üçün formatlayıcı.
///
/// Bu tip `BacktraceFmt::frame` funksiyası tərəfindən yaradılmışdır.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Bu çərçivə formatlayıcısı ilə `BacktraceFrame` çap edir.
    ///
    /// Bu, `BacktraceFrame` içərisindəki bütün `BacktraceSymbol` nümunələrini təkrarən çap edəcəkdir.
    ///
    /// # Tələb olunan xüsusiyyətlər
    ///
    /// Bu funksiya `backtrace` crate-nin `std` xüsusiyyətinin aktiv olmasını tələb edir və `std` xüsusiyyəti varsayılan olaraq aktivdir.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` daxilində `BacktraceSymbol` yazdırır.
    ///
    /// # Tələb olunan xüsusiyyətlər
    ///
    /// Bu funksiya `backtrace` crate-nin `std` xüsusiyyətinin aktiv olmasını tələb edir və `std` xüsusiyyəti varsayılan olaraq aktivdir.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: bu heç bir şey çap etməyimiz üçün əla deyil
            // utf8 olmayan fayl adları ilə.
            // Şükürlər olsun ki, demək olar ki, hər şey utf8-dir, buna görə bu çox pis olmamalıdır.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Tipik olaraq bu crate-nin xam zəngləri içərisindən xam izlənilmiş `Frame` və `Symbol` çap edir.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Arxa arxa çıxışa xam bir çərçivə əlavə edir.
    ///
    /// Bu metod, əvvəlkindən fərqli olaraq, fərqli yerlərdən qaynaqlandıqları təqdirdə xam arqumentləri götürür.
    /// Diqqət yetirin ki, bu bir çərçivə üçün dəfələrlə deyilə bilər.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Sütun məlumatları da daxil olmaqla arxa arxa çıxışa xam bir çərçivə əlavə edir.
    ///
    /// Bu üsul, əvvəlki kimi, fərqli yerlərdən qaynaqlandıqları təqdirdə xam arqumentləri götürür.
    /// Diqqət yetirin ki, bu bir çərçivə üçün dəfələrlə deyilə bilər.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuşya bir müddət ərzində simvollaşdıra bilmir, ona görə də sonradan simvollaşdırmaq üçün istifadə edilə bilən xüsusi bir formata malikdir.
        // Ünvanları öz formatımızda çap etmək əvəzinə buradan çap edin.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" çərçivələrini çap etməyə ehtiyac yoxdur, bu, sadəcə sistemin geriyə yönəlməsinin super uzaqları izləmək üçün bir az istəkli olduğu deməkdir.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx anklavında TCB ölçüsünü azaltmaq üçün simvol həlli funksiyasını həyata keçirmək istəmirik.
        // Daha doğrusu, daha sonra funksiyanı düzəltmək üçün uyğunlaşdırıla bilən ünvanın ofsetini burada yaza bilərik.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Çerçeve indeksini və həmçinin çərçivənin isteğe bağlı təlimat göstəricisini çap edin.
        // Bu çərçivənin ilk simvolundan kənarda olsaq da, uyğun boşluğu yazdırırıq.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Tamamilə geriyə döndüyümüz təqdirdə daha çox məlumat üçün alternativ formatı istifadə edərək simvol adını yazın.
        // Burada adı olmayan simvolları da idarə edirik,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Və sonda, əgər varsa, filename/line nömrəsini yazdırın.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line simvol adı altında sətirlərə basılır, buna görə özümüzü düz hizalamaq üçün uyğun boşluğu yazdırın.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Fayl adını yazdırmaq və daha sonra sətir nömrəsini yazdırmaq üçün daxili zəngimizə müraciət edin.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Mümkünsə sütun nömrəsini əlavə edin.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Biz yalnız bir çərçivənin ilk simvolu ilə maraqlanırıq
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}