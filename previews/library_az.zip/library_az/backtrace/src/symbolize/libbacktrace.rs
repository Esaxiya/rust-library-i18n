//! Libbacktrace-də DWARF-ayrıştırma kodundan istifadə edərək simvollaşdırma strategiyası.
//!
//! Tipik olaraq gcc ilə paylanan libbacktrace C kitabxanası, yalnız bir geriyə iz yaratmağı (əslində istifadə etmədiyimizi) deyil, həm də arxa planı simvollaşdırmağı və cizgilərli çərçivələr və heç nə kimi şeylər haqqında cırtdan ayıklama məlumatlarını idarə etməyi dəstəkləyir.
//!
//!
//! Buradakı müxtəlif narahatlıqlara görə nisbətən mürəkkəbdir, lakin əsas fikir:
//!
//! * Əvvəlcə `backtrace_syminfo`-ə zəng edirik.İmkan daxilində bu, simvol məlumatlarını dinamik simvol cədvəlindən alır.
//! * Sonra `backtrace_pcinfo`-ə zəng edirik.Bu, mövcud olduqda debuginfo cədvəllərini təhlil edəcək və daxil çərçivələri, fayl adları, sətir nömrələri və s. Haqqında məlumatları bərpa etməyə imkan verir.
//!
//! Cırtdan cədvəlləri libbacktrace halına gətirmək üçün bir çox hiylə var, amma inşallah dünyanın sonu deyil və aşağıda oxuyanda kifayət qədər aydındır.
//!
//! Bu, MSVC olmayan və OSX olmayan platformalar üçün standart simvollaşdırma strategiyasıdır.Libstd-də bu OSX üçün standart strategiyadır.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Mümkünsə debuginfo-dan gələn və tipik olaraq çərçivə çərçivələri üçün daha dəqiq ola bilən `function` adını seçin.
                // Əgər bu mövcud deyilsə, `symname`-də göstərilən simvol cədvəlinə qayıdın.
                //
                // Diqqət yetirin ki, bəzən `function` özünü bir az daha az hiss edə bilər, məsələn `std::panicking::try::do_call`-in `try<i32,closure>` adı verilmir.
                //
                // Niyə həqiqətən aydın deyil, amma ümumilikdə `function` adı daha dəqiq görünür.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // hələlik heç nə etmə
}

/// `syminfo_cb`-ə keçən `data` göstəricisinin növü
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Bu geri çağırış `backtrace_syminfo`-dən çağrıldıqdan sonra həll etməyə başladığımızda `backtrace_pcinfo`-ə zəng etmək üçün daha da irəli gedirik.
    // `backtrace_pcinfo` funksiyası ayıklama məlumatlarına baxacaq və file/line məlumatlarını bərpa etmək kimi bir sıra işlər görmək üçün cəhd edəcək.
    // Qeyd edək ki, `backtrace_pcinfo` uğursuz ola bilər və ya səhv məlumatı olmadığı təqdirdə çox şey edə bilməz, buna görə də bu baş verərsə, geri çağırmağı `syminfo_cb`-dən ən azı bir simvolla çağıracağımıza əminik.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb`-ə keçən `data` göstəricisinin növü
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API bir vəziyyət yaratmağı dəstəkləyir, ancaq bir dövləti məhv etməyi dəstəkləmir.
// Şəxsən mən bunu bir dövlətin yaradılması və sonra əbədi yaşamaq üçün nəzərdə tutulduğu mənasında qəbul edirəm.
//
// Bu vəziyyəti təmizləyən bir at_exit() işləyicisini qeydiyyatdan keçirmək istərdim, lakin libbacktrace buna imkan vermir.
//
// Bu məhdudiyyətlərlə, bu funksiyanın istənildiyi ilk dəfə hesablanan statik olaraq önbelleğe alınmış vəziyyəti vardır.
//
// Backtracing'in hamısının ardıcıl olaraq baş verdiyini unutmayın (bir qlobal kilid).
//
// Qeyd edək ki, burada sinxronizasiya olmaması, `resolve`-nin xaricdən sinxronlaşdırılması tələbi ilə bağlıdır.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Hər zaman sinxronlaşdırılmış bir şəkildə çağırdığımız üçün libbacktrace-in mövzu təhlükəsizliyini istifadə etməyin.
        //
        0,
        error_cb,
        ptr::null_mut(), // əlavə məlumat yoxdur
    );

    return STATE;

    // Qeyd edək ki, libbacktrace-in ümumiyyətlə işləməsi üçün cari yürütülebilir proqram üçün DWARF ayıklama məlumatını tapması lazımdır.Ümumiyyətlə bunu aşağıdakılar daxil olmaqla, bunlarla məhdudlaşmayan bir sıra mexanizmlər vasitəsilə edir.
    //
    // * /proc/self/exe dəstəklənən platformalarda
    // * Dövlət yaratarkən fayl adı açıq şəkildə keçdi
    //
    // Libbacktrace kitabxanası böyük bir C kodudur.Bu, təbii olaraq, xüsusən düzgün qurulmamış debuginfo ilə işləyərkən yaddaş təhlükəsizliyi zəifliklərinə sahib olması deməkdir.
    // Libstd tarixən bunların çoxuna rast gəldi.
    //
    // /proc/self/exe istifadə olunursa, libbacktrace'in "mostly correct" olduğunu və əks halda "attempted to be correct" cırtdan ayıklama məlumatı ilə qəribə şeylər etmədiyini düşündüyümüz üçün bunları ümumiyyətlə görməməzlikdən gələ bilərik.
    //
    //
    // Ancaq bir fayl adından keçsək, zərərli bir aktyorun həmin yerə təsadüfi bir fayl yerləşdirilməsinə səbəb ola biləcəyi bəzi platformalarda (BSD kimi) mümkündür.
    // Bu o deməkdir ki, bir libbacktrace-ə bir fayl adı haqqında danışsaq, ola bilsin segfaultlara səbəb olan təsadüfi bir fayl istifadə edə bilər.
    // Əgər libbacktrace-ə heç nə deməsək də, /proc/self/exe kimi yolları dəstəkləməyən platformalarda heç nə etməyəcəkdir!
    //
    // Mümkün qədər çox çalışdığımızı nəzərə alsaq * bir fayl adından keçməməliyik, amma /proc/self/exe-i heç dəstəkləməyən platformalarda olmalıyıq.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // İdeal olaraq `std::env::current_exe` istifadə edəcəyimizi unutmayın, lakin burada `std` tələb edə bilmərik.
            //
            // Cari yürütülə bilən yolu statik bir sahəyə yükləmək üçün `_NSGetExecutablePath` istifadə edin (çox kiçikdirsə, sadəcə imtina edin).
            //
            //
            // Qeyd edək ki, burada libbacktrace-ə pozulmuş icraedici sənədlərdə ölməməyə ciddi şəkildə inanırıq, amma şübhəsiz ki ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows faylları açma rejiminə malikdir, açıldıqdan sonra silinə bilmir.
            // Ümumiyyətlə burada istədiyimiz budur, çünki libbacktrace-ə təhvil verdikdən sonra icra oluna bilən proqramın altımızdan dəyişməməsini təmin etmək istəyirik, ümid edirəm ki, təsadüfi məlumatları libbacktrace-ə ötürmək qabiliyyətini azaltırıq (səhv istifadə edilə bilər).
            //
            //
            // Nəzərə alsaq ki, öz imicimizə bir növ kilid vurmağa çalışmaq üçün bir az rəqs edirik:
            //
            // * Mövcud prosesi idarə edin, onun adını yükləyin.
            // * Faylın adını sağ bayraqlarla birlikdə açın.
            // * Cari prosesin eyni olduğundan əmin olaraq onun adını yenidən yükləyin
            //
            // Əgər bunların hamısı keçərsə, nəzəri olaraq həqiqətən prosesimizin sənədini açmışıq və dəyişməyəcəyinə zəmanət veririk.FWIW bunun bir dəstəsi tarixən libstd-dən kopyalandı, buna görə də baş verənləri ən yaxşı yozum.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Bu, statik yaddaşda yaşayır, buna görə geri qaytara bilərik ..
                static mut BUF: [i8; N] = [0; N];
                // ... və bu müvəqqəti olduğundan yığının üzərində yaşayır
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // bilərəkdən `handle`-i buradan sızdırın, çünki açıq olması bu fayl adındakı kilidimizi qorumalıdır.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Sıfır bir dilim qaytarmaq istəyirik, buna görə hər şey doldurulubsa və ümumi uzunluğa bərabərdirsə, onu uğursuzluğa bərabərləşdiririk.
                //
                //
                // Əks təqdirdə müvəffəqiyyəti qaytararkən nul baytın dilimə daxil olduğundan əmin olun.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace səhvləri hal-hazırda xalı altında süpürülür
    let state = init_state();
    if state.is_null() {
        return;
    }

    // (Kod oxumaqdan) tam olaraq bir dəfə `syminfo_cb`-ə zəng etməli olan `backtrace_syminfo` API-yə zəng edin (və ya ehtimal ki, bir səhvlə uğursuz ola bilər).
    // Daha sonra `syminfo_cb` çərçivəsində daha çox işləyirik.
    //
    // `syminfo` simvol cədvəlinə müraciət edəcəyi üçün ikili sənədlərdə heç bir səhv məlumatı olmasa da simvol adlarını tapacağından bəri bunu edirik.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}