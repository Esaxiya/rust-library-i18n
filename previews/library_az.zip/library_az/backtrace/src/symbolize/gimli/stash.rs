// yalnız hazırda Linux-də istifadə olunur, buna görə də başqa yerə ölü kodu buraxın
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Bayt tamponlar üçün sadə bir arena ayırıcısı.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Müəyyən edilmiş ölçülü bir tampon ayırır və dəyişdirilə bilən bir istinad gətirir.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // TƏHLÜKƏSİZLİK: indiyə qədər dəyişdirilə bilən bir şey quran yeganə funksiyadır
        // `self.buffers`-ə istinad.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // TƏHLÜKƏSİZLİK: elementləri heç vaxt `self.buffers`-dən çıxarmırıq, ona görə də istinad
        // hər hansı bir tampon içərisindəki məlumatlara `self` olduğu müddətdə yaşayacaqdır.
        &mut buffers[i]
    }
}