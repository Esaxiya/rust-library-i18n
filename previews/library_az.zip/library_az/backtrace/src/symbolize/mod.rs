use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Simvolu göstərilən bağlanmaya ötürərək bir simvolu bir ünvanı həll edin.
///
/// Bu funksiya verilən simvolu tapmaq üçün lokal simvol cədvəli, dinamik simvol cədvəli və ya DWARF debug info (aktivləşdirilmiş tətbiqdən asılı olaraq) kimi sahələrdə verilən ünvanı axtaracaqdır.
///
///
/// Çözünürlük yerinə yetirilə bilmədiyi təqdirdə bağlanma çağırıla bilməz və xətti çəkilmiş funksiyalar halında bir dəfədən çox çağırıla bilər.
///
/// Verilən rəmzlər, göstərilən `addr`-də icrası təmsil edir və həmin ünvan üçün file/line cütlərini qaytarır (əgər varsa).
///
/// `Frame`-yə sahibsinizsə, bu funksiya əvəzinə `resolve_frame` funksiyasından istifadə etməyiniz tövsiyə olunur.
///
/// # Tələb olunan xüsusiyyətlər
///
/// Bu funksiya `backtrace` crate-nin `std` xüsusiyyətinin aktiv olmasını tələb edir və `std` xüsusiyyəti varsayılan olaraq aktivdir.
///
/// # Panics
///
/// Bu funksiya heç vaxt panic olmamağa çalışır, lakin `cb` panics təmin edərsə, bəzi platformalar prosesi ləğv etməyə ikiqat panic məcbur edəcəkdir.
/// Bəzi platformalar daxili olaraq geri qaytarılmayan geri çağırışlardan istifadə edən bir C kitabxanasından istifadə edir, buna görə `cb`-dən çaxnaşma bir prosesi ləğv edə bilər.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // yalnız üst çərçivəyə baxın
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Əvvəlcədən çəkilmiş bir çərçivəni simvolu göstərilən bağlamaya ötürərək bir simvola həll edin.
///
/// Bu funksiya `resolve` ilə eyni funksiyanı yerinə yetirir, istisna olmaqla bir ünvan əvəzinə bir `Frame` arqument kimi qəbul edir.
/// Bu, arxa izləmənin bəzi platforma tətbiqetmələrində daha dəqiq simvol məlumatları və ya daxil olan çərçivələr haqqında məlumat vermələrini təmin edə bilər.
///
/// Mümkünsə bundan istifadə etməyiniz tövsiyə olunur.
///
/// # Tələb olunan xüsusiyyətlər
///
/// Bu funksiya `backtrace` crate-nin `std` xüsusiyyətinin aktiv olmasını tələb edir və `std` xüsusiyyəti varsayılan olaraq aktivdir.
///
/// # Panics
///
/// Bu funksiya heç vaxt panic olmamağa çalışır, lakin `cb` panics təmin edərsə, bəzi platformalar prosesi ləğv etməyə ikiqat panic məcbur edəcəkdir.
/// Bəzi platformalar daxili olaraq geri qaytarılmayan geri çağırışlardan istifadə edən bir C kitabxanasından istifadə edir, buna görə `cb`-dən çaxnaşma bir prosesi ləğv edə bilər.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // yalnız üst çərçivəyə baxın
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Yığma çərçivələrindəki IP dəyərləri, adətən, faktiki yığın izi olan * zəngdən sonra (always?) təlimatıdır.
// Bunu simvollaşdırmaq, filename/line nömrəsinin bir irəlidə olmasına və funksiyanın sonuna yaxın olduğu təqdirdə boşluğa çevrilməsinə səbəb olur.
//
// Bu, əsasən bütün platformalarda həmişə olduğu kimi görünür, buna görə geri qaytarılan təlimat əvəzinə əvvəlki zəng əmrinə həll etmək üçün həll edilmiş ipdən birini çıxardırıq.
//
//
// İdeal olaraq bunu etməzdik.
// İdeal olaraq buradakı `resolve` API-lərini axtaranların -1-i əl ilə etmələrini və cari deyil,*əvvəlki* təlimat üçün yer məlumatları istədiklərini hesab etmələrini tələb edirik.
// İdeal olaraq, həqiqətən növbəti təlimatın və ya cari ünvandan olsaq, `Frame`-ə məruz qalacağıq.
//
// Hələlik bu olduqca niş bir narahatlıq olsa da, daxili olaraq həmişə birini çıxardırıq.
// İstehlakçılar işləməyə və olduqca yaxşı nəticələr əldə etməyə davam etməlidirlər, buna görə də kifayət qədər yaxşı olmalıyıq.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` ilə eyni, yalnız sinxronizasiya edildiyi üçün təhlükəlidir.
///
/// Bu funksiyada sinxronizasiya zəmanəti yoxdur, lakin bu crate-nin `std` xüsusiyyəti tərtib edilmədikdə mövcuddur.
/// Daha çox sənəd və nümunə üçün `resolve` funksiyasına baxın.
///
/// # Panics
///
/// `cb` panikasında xəbərdarlıqlar üçün `resolve` məlumatlarına baxın.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` ilə eyni, yalnız sinxronizasiya edildiyi üçün təhlükəlidir.
///
/// Bu funksiyada sinxronizasiya zəmanəti yoxdur, lakin bu crate-nin `std` xüsusiyyəti tərtib edilmədikdə mövcuddur.
/// Daha çox sənəd və nümunə üçün `resolve_frame` funksiyasına baxın.
///
/// # Panics
///
/// `cb` panikasında xəbərdarlıqlar üçün `resolve_frame` məlumatlarına baxın.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Bir sənəddəki bir simvolun həllini təmsil edən bir trait.
///
/// Bu trait, `backtrace::resolve` funksiyasına verilmiş bir bağlanmaya bir trait obyekti olaraq verilir və bunun arxasında hansı tətbiqetmə olduğu bilinmədiyi üçün faktiki olaraq göndərilir.
///
///
/// Bir simvol bir funksiya haqqında kontekstual məlumat verə bilər, məsələn ad, fayl adı, sətir nömrəsi, dəqiq ünvan və s.
/// Bütün məlumatlar həmişə bir simvolda mövcud deyil, buna görə bütün metodlar bir `Option` qaytarır.
///
///
pub struct Symbol {
    // TODO: bu ömür boyu `Symbol`-ə qədər davam etmək lazımdır,
    // lakin bu hal hazırda qəti bir dəyişiklikdir.
    // `Symbol` yalnız istinad yolu ilə təqdim olunduğundan və klonlaşdırıla bilmədiyi üçün bu hələ təhlükəsizdir.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Bu funksiyanın adını qaytarır.
    ///
    /// Qaytarılmış quruluş simvol adı ilə əlaqədar müxtəlif xassələri sorğu etmək üçün istifadə edilə bilər:
    ///
    ///
    /// * `Display` tətbiqi demangled simvolu yazdıracaq.
    /// * Simvolun xam `str` dəyərinə (utf-8 etibarlıdırsa) daxil olmaq olar.
    /// * Simvol adı üçün xam baytlara daxil olmaq olar.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Bu funksiyanın başlanğıc ünvanını qaytarır.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Ham fayl adını dilim şəklində qaytarır.
    /// Bu, əsasən `no_std` mühitləri üçün faydalıdır.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Bu simvolun hazırda icra olunduğu yer üçün sütun nömrəsini qaytarır.
    ///
    /// Hal-hazırda burada yalnız gimli bir dəyər verir və hətta `filename` `Some` qaytardığı təqdirdə belə bir nəticə verir və buna görə də oxşar xəbərdarlıqlara tabedir.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Bu simvolun hazırda icra olunduğu sətir nömrəsini qaytarır.
    ///
    /// `filename` `Some` qaytararsa, bu qayıtma dəyəri adətən `Some` olur və nəticədə oxşar xəbərdarlıqlara tabedir.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Bu funksiyanın təyin olunduğu fayl adını qaytarır.
    ///
    /// Bu hal hazırda yalnız libbacktrace və ya gimli istifadə edildikdə mümkündür (məsələn
    /// unix platformalar digər) və ikili debuginfo ilə tərtib edildikdə.
    /// Bu şərtlərdən heç biri yerinə yetirilmədikdə, bu, `None`-i qaytaracaqdır.
    ///
    /// # Tələb olunan xüsusiyyətlər
    ///
    /// Bu funksiya `backtrace` crate-nin `std` xüsusiyyətinin aktiv olmasını tələb edir və `std` xüsusiyyəti varsayılan olaraq aktivdir.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Bəlkə ayrılmış bir C++ simvolu, əgər manqolu simvolu Rust olaraq təhlil etmək uğursuz olarsa.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Bu sıfır ölçülü saxladığınızdan əmin olun ki, `cpp_demangle` funksiyası əlil olduqda heç bir xərc çəkməsin.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Sökülmüş ada, xam baytlara, xam sətrə və s.ə erqonomik giriş təmin etmək üçün bir simvol adının ətrafındakı bir sarğı.
///
// `cpp_demangle` xüsusiyyətinin aktiv olmadığı zaman üçün ölü kod verin.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Xam əsaslanan baytlardan yeni bir simvol adı yaradır.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Rəmz utf-8 etibarlıdırsa, xam (mangled) simvol adını `str` olaraq qaytarır.
    ///
    /// Sökülmüş versiyanı istəyirsinizsə `Display` tətbiqetməsindən istifadə edin.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Xam simvol adını bayt siyahısı kimi qaytarır
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Sökülmüş simvol həqiqətən etibarlı deyilsə, bu yazdırıla bilər, buna görə də səhvləri kənara yaymamaqla zərif davranın.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Ünvanları simvollaşdırmaq üçün istifadə olunan yaddaş yaddaşını geri qaytarmağa cəhd edin.
///
/// Bu metod, ümumiyyətlə, ümumiyyətlə təhlil edilmiş DWARF məlumatlarını və ya buna bənzərləri təmsil edən qlobal miqyasda və ya mövzuda önbelleğe alınmış hər hansı bir qlobal məlumat quruluşunu buraxmağa çalışacaqdır.
///
///
/// # Caveats
///
/// Bu funksiya həmişə mövcud olsa da, əksər tətbiqetmələrdə heç bir şey etmir.
/// Dbghelp və ya libbacktrace kimi kitabxanalar vəziyyəti ayırmaq və ayrılmış yaddaşı idarə etmək üçün imkanlar təmin etmir.
/// Hələlik bu crate-in `gimli-symbolize` xüsusiyyəti, bu funksiyanın hər hansı bir təsiri olan yeganə xüsusiyyətdir.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}