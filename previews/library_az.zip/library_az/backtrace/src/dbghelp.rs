//! Windows-də dbghelp bağlamalarının idarə olunmasına kömək edəcək bir modul
//!
//! Windows-də arxa cədvəllər (ən azı MSVC üçün) əsasən `dbghelp.dll` və içərisindəki müxtəlif funksiyalarla işləyir.
//! Bu funksiyalar hazırda `dbghelp.dll`-ə statik olaraq bağlanmaqdansa *dinamik* yüklənir.
//! Bu hal hazırda standart kitabxana tərəfindən edilir (və nəzəri cəhətdən orada tələb olunur), lakin arxa arxa yerlər ümumiyyətlə isteğe bağlı olduğundan kitabxananın statik dll asılılığını azaltmağa kömək etmək üçün bir səydir.
//!
//! Demək olar ki, `dbghelp.dll` demək olar ki, həmişə Windows-də uğurla yüklənir.
//!
//! Bütün bu dəstəyi dinamik bir şəkildə yüklədiyimiz üçün `winapi`-də xammal təriflərini istifadə edə bilməyəcəyimizə diqqət yetirin, əksinə funksiya göstəricisi tiplərini özümüz müəyyənləşdirməliyik və bundan istifadə etməliyik.
//! Biz, həqiqətən, winapi kopyalamaqla məşğul olmaq istəmirik, buna görə bütün bağlamaların winapi ilə uyğunlaşdığını və bu xüsusiyyətin CI-də aktiv olduğunu iddia edən bir Cargo xüsusiyyətimiz `verify-winapi` var.
//!
//! Nəhayət, burada `dbghelp.dll` üçün DLL-in heç vaxt boşaldılmadığını və hazırda qəsdən olduğunu qeyd edəcəksiniz.
//! Düşüncə budur ki, dünya miqyasında önbelleğe ala bilərik və bahalı loads/unloads-dən qaçaraq API-yə zənglər arasında istifadə edə bilərik.
//! Sızma detektorları və ya buna bənzər bir problem varsa, oraya çatdıqda körpüdən keçə bilərik.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Winapinin özündə olmayan `SymGetOptions` və `SymSetOptions` ətrafında işləyin.
// Əks təqdirdə bu, yalnız winapi ilə növləri ikiqat yoxladığımızda istifadə olunur.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapi-də hələ müəyyənləşdirilməyib
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Bu winapi-də müəyyən edilir, lakin səhvdir (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapi-də hələ müəyyənləşdirilməyib
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Bu makro, yükləyə biləcəyimiz bütün funksiya göstəricilərini daxili olaraq ehtiva edən bir `Dbghelp` quruluşunu təyin etmək üçün istifadə olunur.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` üçün yüklənmiş DLL
            dll: HMODULE,

            // İstifadə edə biləcəyimiz hər bir funksiya üçün hər bir işarə göstəricisi
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Əvvəlcə DLL-ni yükləməmişik
            dll: 0 as *mut _,
            // Başlanğıcda bütün funksiyalar dinamik olaraq yüklənməli olduqlarını söyləmək üçün sıfıra ayarlanır.
            //
            $($name: 0,)*
        };

        // Hər bir funksiya növü üçün rahatlıq typedef.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` açma cəhdləri.
            /// İşləsə müvəffəqiyyəti və ya `LoadLibraryW` uğursuz olarsa səhvini qaytarır.
            ///
            /// Kitabxana artıq yüklənmişsə Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // İstifadə etmək istədiyimiz hər bir metod üçün funksiya.
            // Çağırıldığında ya önbelleğe alınmış funksiya göstəricisini oxuyacaq, ya da yükləyəcək və yüklənmiş dəyəri qaytaracaqdır.
            // Yüklərin uğurlu olacağı iddia edilir.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp funksiyalarına istinad etmək üçün təmizlənmə kilidlərindən istifadə etmək üçün rahatlıq müvəkkili.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Bu crate-dən `dbghelp` API funksiyalarına daxil olmaq üçün lazım olan bütün dəstəyi başladın.
///
///
/// Bu funksiyanın **təhlükəsiz** olduğuna diqqət yetirin, daxili olaraq öz sinxronizasiyasına malikdir.
/// Həm də bu funksiyanı bir neçə dəfə təkrarlanan çağırmağın təhlükəsiz olduğunu unutmayın.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Etməli olduğumuz ilk şey bu funksiyanı sinxronizasiya etməkdir.Buna digər mövzulardan eyni vaxtda və ya bir mövzu daxilində rekursiv olaraq zəng etmək olar.
        // Bunun daha hiyləgər olduğuna diqqət yetirin, çünki burada istifadə etdiyimiz `dbghelp`,*ayrıca* bu müddətdə `dbghelp`-yə zəng edənlərin hamısı ilə sinxronlaşdırılmalıdır.
        //
        // Tipik olaraq `dbghelp`-ə eyni müddət ərzində o qədər də çox zəng yoxdur və ehtimal ki, təhlükəsiz olaraq ona daxil olanların olduğunu güman edə bilərik.
        // Bununla birlikdə narahat olmağımız lazım olan bir əsas istifadəçi var ki, bu istehza ilə özümüzdür, ancaq standart kitabxanada.
        // Rust standart kitabxanası arxa arxa dəstək üçün bu crate-yə bağlıdır və bu crate crates.io-də də mövcuddur.
        // Bu o deməkdir ki, standart kitabxana bir panic arxa izi çap edirsə, crates.io-dən gələn bu crate ilə yarışa bilər və seqfalara səbəb ola bilər.
        //
        // Bu sinxronizasiya probleminin həllinə kömək etmək üçün burada Windows-a məxsus bir hiylə tətbiq edirik (nəticədə sinxronizasiya ilə bağlı Windows-a məxsus bir məhdudiyyətdir).
        // Bu çağırışı qorumaq üçün *sessiya-yerli* adlı mutex yaradırıq.
        // Buradakı məqsəd standart kitabxananın və bu crate-nin burada sinxronizasiya etmək üçün Rust səviyyəli API-lərini paylaşması lazım deyil, əksinə bir-biri ilə sinxronizasiya etdiklərinə əmin olmaq üçün pərdə arxasında işləyə bilməkdir.
        //
        // Beləliklə, bu funksiya standart kitabxana və ya crates.io vasitəsi ilə çağırıldıqda, eyni mutex-in əldə olunduğundan əmin ola bilərik.
        //
        // Yəni bunların hamısı, burada etdiyimiz ilk şeyin atomik olaraq Windows-də adlandırılan bir mutex olan bir `HANDLE` yaratdığımızı söyləməkdir.
        // Bu funksiyanı xüsusi olaraq bölüşən digər mövzularla bir az sinxronlaşdırırıq və bu funksiyanın nümunəsi üçün yalnız bir qolun yaradılmasını təmin edirik.
        // Diqqət yetirin ki, qlobalda saxlanıldıqdan sonra tutacaq heç vaxt bağlanmaz.
        //
        // Həqiqətən kiliddən keçdikdən sonra onu əldə edirik və `Init` sapımız nəhayət onu buraxmaqdan məsul olacaq.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Tamam, oğlum!Artıq hamımız təhlükəsiz bir şəkildə sinxronlaşdırıldığımızdan, həqiqətən hər şeyi emal etməyə başlayaq.
        // Əvvəlcə `dbghelp.dll`-in bu müddətdə həqiqətən yükləndiyini təmin etməliyik.
        // Statik asılılıqdan qaçmaq üçün bunu dinamik şəkildə edirik.
        // Bu, tarixən qəribə birləşdirmə məsələləri ətrafında işləmək üçün edilmişdir və ikili sənədləri bir az daha portativ hala gətirmək məqsədi daşıyır, çünki bu, sadəcə bir ayıklama proqramıdır.
        //
        //
        // `dbghelp.dll`-i açdıqdan sonra içindəki bəzi başlatma funksiyalarına zəng etməliyik və bu daha aşağıda daha ətraflı.
        // Bununla birlikdə bunu yalnız bir dəfə edirik, buna görə hələ bitib bitmədiyimizi göstərən qlobal bir boolean var.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` bayrağının qurulduğundan əmin olun, çünki bu barədə MSVC-nin öz sənədlərinə görə: "This is the fastest, most efficient way to use the symbol handler.", gəlin bunu edək!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC ilə əslində simvolları işə salın.Bunun uğursuz ola biləcəyini unutmayın, amma buna məhəl qoymuruq.
        // Bunun üçün əvvəlcədən bir ton sənət yoxdur, ancaq LLVM daxili olaraq geri qaytarma dəyərinə məhəl qoymur və LLVM-dəki təmizləyici kitabxanalardan biri, əgər bu uğursuz olsa da uzun müddətə əsasən bunu görməzdən gəlsə qorxunc bir xəbərdarlıq yazdırır.
        //
        //
        // Bunun Rust üçün çox irəli gəldiyi bir hal budur ki, standart kitabxana və crates.io-dəki bu crate həm `SymInitializeW` üçün rəqabət etmək istəyir.
        // Standart kitabxana tarixən əksər vaxt sonra təmizləməyə başlamaq istəyirdi, amma indi bu crate-dən istifadə olunduğuna görə birisi əvvəlcə işə başlayacaq, digəri isə həmin başlanğıcı götürəcək.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}