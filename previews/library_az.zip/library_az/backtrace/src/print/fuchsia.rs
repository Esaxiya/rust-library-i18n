use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr, prosesə bağlı olan hər bir DSO üçün dl_phdr_info göstəricisi alacaq bir geri çağırış edir.
    // dl_iterate_phdr, dinamik bağlayıcının təkrarlamanın başından sonuna qədər kilidlənməsini də təmin edir.
    // Geri zəng sıfır olmayan bir dəyər qaytararsa, iterasiya erkən dayandırılır.
    // 'data' hər zəngdə geri çağırmanın üçüncü arqumenti kimi qəbul ediləcəkdir.
    // 'size' dl_phdr_info ölçüsünü verir.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Qurma kimliyini və bəzi əsas proqram başlığı məlumatlarını təhlil etməliyik, bu da ELF spesifikasiyasından bir az şeyə ehtiyacımız olduğunu göstərir.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// İndi fuşsiyanın cari dinamik bağlayıcısının istifadə etdiyi dl_phdr_info tipinin quruluşunu bit-bit üçün çoxaltmalıyıq.
// Xromun da bu ABI sərhədləri və cradpad var.
// Nəhayət, bu halları elf-axtarışdan istifadə etmək üçün köçürmək istərdik, amma bunu SDK-da təmin etməliyik və bu hələ edilməyib.
//
// Beləliklə (və onlar) fuşya libc ilə sıx bir birləşmə yaradan bu metodu istifadə etmək məcburiyyətində qalırıq.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff və e_phnum-un etibarlı olub olmadığını yoxlamaq üçün bir yolumuz yoxdur.
    // libc bunu bizim üçün təmin etməlidir, buna görə burada bir dilim yaratmaq təhlükəsizdir.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr, hədəf arxitekturasında yeni 64-bit ELF proqram başlığını təmsil edir.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr, etibarlı bir ELF proqram başlığını və məzmunu təmsil edir.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // P_addr və ya p_memsz-nin etibarlı olub olmadığını yoxlamaq üçün bir yolumuz yoxdur.
    // Fuşsiyanın libc qeydləri əvvəlcə təhlil edir, lakin burada olmağınıza görə bu başlıqlar etibarlı olmalıdır.
    //
    // NoteIter əsas məlumatların etibarlı olmasını tələb etmir, lakin sərhədlərin etibarlı olmasını tələb edir.
    // Libc-in bunun bizim üçün burada olmasını təmin etdiyinə inanırıq.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Qurma şəxsiyyətləri üçün qeyd növü.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr, hədəfin artıqlığındakı bir ELF qeyd başlığını təmsil edir.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Qeyd ELF notunu (başlıq + məzmunu) təmsil edir.
// Ad u8 dilimi olaraq qalır, çünki həmişə null xitam vermir və rust baytların hər halda uyğun olub olmadığını yoxlamağı asanlaşdırır.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter, təhlükəsiz bir qeyd seqmenti üzərində təkrarlamağa imkan verir.
// Bir səhv meydana gəldikdə və ya daha bir qeyd olmadığı anda sona çatır.
// Yalnış məlumatlar üzərində təkrar etsəniz, heç bir qeyd tapılmamış kimi fəaliyyət göstərəcəkdir.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Verilən göstərici və ölçünün hamısını oxuya bilən etibarlı bir bayt aralığını ifadə etməsi funksiyanın dəyişməzliyidir.
    // Bu baytların məzmunu hər hansı bir şey ola bilər, lakin bunun təhlükəsiz olması üçün aralıq etibarlı olmalıdır.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to, 'to' in 2 gücünə sahib olduğunu fərz edərək 'x' yi 'to-bayt hizalamaya bərabərləşdirir.
// Bu, (x + to, 1)&-to istifadə olunduğu C/C ++ ELF ayrıştırma kodunda standart bir nümunəni izləyir.
// Rust istifadə etməməyinizi inkar etməyinizə icazə vermir
// Yenidən yaratmaq üçün 2'yi tamamlayan dönüşüm.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 dilimdən num bayt (əgər varsa) sərf edir və əlavə olaraq son dilimin düzgün bir şəkildə hizalanmasını təmin edir.
// İstənən bayt sayı ya çoxdursa və ya kifayət qədər qalan bayt olmadığından dilim daha sonra yenidən düzəldilə bilmirsə, heç biri qaytarılmır və dilim dəyişdirilmir.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Bu funksiyanın, zəng edənin, bəlkə də 'bytes'-nin performans üçün uyğunlaşdırılmasından başqa (və bəzi arxitekturaların düzgünlüyü) dəstəkləməsi lazım olan həqiqi dəyişməzliyi yoxdur.
// Elf_Nhdr sahələrindəki dəyərlər cəfəngiyat ola bilər, lakin bu funksiya belə bir şey təmin etmir.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Kifayət qədər yer olduğu müddətdə bu təhlükəsizdir və yalnız yuxarıdakı if ifadəsində bunun təhlükəli olmaması lazım olduğunu təsdiqlədik.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Qeyd edək ki, sice_of: :<Elf_Nhdr>() həmişə 4 bayt hizalanır.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Sonuna çatdığımızı yoxlayın.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Bir nhdr ötürürük, lakin nəticədə yaranan strukturu diqqətlə nəzərdən keçiririk.
        // Namesz və ya descsz-ə inanmırıq və növə görə heç bir təhlükəli qərar qəbul etmirik.
        //
        // Yəni tam zibildən çıxsaq da, təhlükəsiz olmalıyıq.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Bir seqmentin icra edilə biləcəyini göstərir.
const PERM_X: u32 = 0b00000001;
/// Bir seqmentin yazılabilir olduğunu göstərir.
const PERM_W: u32 = 0b00000010;
/// Bir seqmentin oxunaqlı olduğunu göstərir.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// İş zamanı ELF seqmentini təmsil edir.
struct Segment {
    /// Bu seqmentin məzmununun iş vaxtı virtual ünvanını verir.
    addr: usize,
    /// Bu seqmentin məzmununun yaddaş ölçüsünü verir.
    size: usize,
    /// ELF faylı ilə bu seqmentin modulun virtual ünvanını verir.
    mod_rel_addr: usize,
    /// ELF sənədində olan icazələri verir.
    /// Lakin bu icazələr mütləq iş vaxtında olan icazələr deyildir.
    flags: Perm,
}

/// Bir DSO-dan Seqmentlər üzərində təkrarlanmağa imkan verir.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO-nu (Dinamik Paylaşılan Obyekt) təmsil edir.
/// Bu tip, öz surətini çıxarmaqdansa, həqiqi DSO-da saxlanılan məlumatlara istinad edir.
struct Dso<'a> {
    /// Dinamik bağlayıcı, ad boş olsa da, həmişə bizə bir ad verir.
    /// Əsas icraedici sənəddə bu ad boş olacaq.
    /// Paylaşılan bir obyekt halında soname olacaq (bax DT_SONAME).
    name: &'a str,
    /// Fuşsiyada demək olar ki, bütün ikili sənədlər şəxsiyyət sənədlərinə malikdir, lakin bu, ciddi tələb deyil.
    /// Hər hansı bir DSO-nun burada olmasını tələb etdiyimizdən sonra build_id olmadığı təqdirdə DSO məlumatlarını real bir ELF faylı ilə uyğunlaşdırmağın bir yolu yoxdur.
    ///
    /// Build_id olmayan DSO'lar nəzərə alınmır.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Bu DSO-da Seqmentlər üzərində təkrarlayıcı qaytarır.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Bu səhvlər hər DSO haqqında məlumatları təhlil edərkən ortaya çıxan problemləri kodlaşdırır.
///
enum Error {
    /// NameError, bir C stil sətirini rust sətirinə çevirərkən bir səhv meydana gəldiyini bildirir.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError deməkdir ki, bir inşa ID tapmadıq.
    /// Bunun səbəbi ya DSO-da birləşdirmə kimliyinin olmaması, ya da inşa kimliyini ehtiva edən seqmentin düzgün qurulmaması ola bilər.
    ///
    BuildIDError,
}

/// Dinamik bağlayıcı tərəfindən prosesə qoşulmuş hər DSO üçün ya 'dso' ya da 'error' zəng edir.
///
///
/// # Arguments
///
/// * `visitor` - Foreach DSO adlı yemək metodlarından birinə sahib olacaq bir DsoPrinter.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr, info.name-nin etibarlı bir yerə işarə etməsini təmin edir.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Bu funksiya DSO-da olan bütün məlumatlar üçün Fuchsia simbolizer işarəsini yazdırır.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}