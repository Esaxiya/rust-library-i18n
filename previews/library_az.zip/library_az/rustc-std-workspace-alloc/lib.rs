#![feature(no_core)]
#![no_core]

// Bu crate-nin nə üçün lazım olduğunu öyrənmək üçün rustc-std-iş sahəsi-nüvəsinə baxın.

// Liballoc-dakı ayırma modulu ilə zidd olmamaq üçün crate adını dəyişdirin.
extern crate alloc as foo;

pub use foo::*;