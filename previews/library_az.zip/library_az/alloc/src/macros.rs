/// Dəlilləri ehtiva edən bir [`Vec`] yaradır.
///
/// `vec!` `Vec`-in sıra ifadələri ilə eyni sintaksis ilə təyin olunmasına imkan verir.
/// Bu makronun iki forması var:
///
/// - Verilmiş elementlər siyahısını ehtiva edən bir [`Vec`] yaradın:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Verilmiş elementdən və ölçüdən [`Vec`] yaradın:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Dizi ifadələrindən fərqli olaraq bu sintaksisin [`Clone`] tətbiq edən bütün elementləri dəstəklədiyini və elementlərin sayının sabit olması lazım olmadığını unutmayın.
///
/// Bu, bir ifadəni kopyalamaq üçün `clone` istifadə edəcək, buna görə standart olmayan bir `Clone` tətbiqinə sahib olan növlərlə bunu istifadə etmək diqqətli olmalıdır.
/// Məsələn, `vec![Rc::new(1);5] `müstəqil olaraq qutulu tam ədədlərə işarə edən beş istinad deyil, eyni qutulu tam ədədin dəyərinə beş istinaddan ibarət vector yaradacaqdır.
///
///
/// Ayrıca `vec![expr; 0]`-ə icazə verildiyini və boş bir vector istehsal etdiyini unutmayın.
/// Bununla birlikdə, bu hələ `expr`-i qiymətləndirəcək və nəticədə yaranan dəyəri dərhal endirəcək, buna görə yan təsirlərə diqqət yetirin.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) ilə bu makro tərifi üçün tələb olunan x01X metodu mövcud deyil.
// Bunun əvəzinə yalnız cfg(test) NB ilə mövcud olan `slice::into_vec` funksiyasından istifadə edin daha çox məlumat üçün slice.rs-də slice::hack moduluna baxın
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// İş vaxtı ifadələrinin interpolasiyasından istifadə edərək `String` yaradır.
///
/// `format!`-nin aldığı ilk arqument format sətiridir.Bu hərfi bir simli olmalıdır.Biçimləndirmə sətrinin gücü "{}" içərisindədir.
///
/// `format!`-ə ötürülən əlavə parametrlər, adlandırılmış və ya mövqe parametrlərindən istifadə edilmədikdə verilən ardıcıllıqla formatlaşdırma sətri içindəki `{} 'ləri əvəz edir;daha çox məlumat üçün [`std::fmt`]-ə baxın.
///
///
/// `format!` üçün ümumi bir istifadə iplərin birləşməsi və interpolasiyasıdır.
/// Eyni konvensiya, simli təyin olunan yerə görə [`print!`] və [`write!`] makroları ilə istifadə olunur.
///
/// Tək bir dəyəri bir simli çevirmək üçün [`to_string`] metodundan istifadə edin.Bu, [`Display`] formatlaşdırma trait istifadə edəcəkdir.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics, trait formatlaşdırma tətbiqində bir səhv qaytarırsa.
/// Bu, `fmt::Write for String`-in heç vaxt səhv etmədiyi üçün səhv bir tətbiq olduğunu göstərir.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Nümunə vəziyyətində diaqnostikanı yaxşılaşdırmaq üçün AST nodu ifadəyə məcbur edin.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}