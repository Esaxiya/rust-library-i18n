//! Unicode simli dilimləri.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` tipi iki əsas simli tipdən biridir, digəri `String`.
//! `String` həmkarından fərqli olaraq, məzmunu borcludur.
//!
//! # Əsas istifadə
//!
//! `&str` tipli əsas sətir bəyannaməsi:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Burada simli dilim olaraq da bilinən bir simli hərfi elan etdik.
//! Simli ədəbiyyatın statik ömrü var, yəni `hello_world` simlinin bütün proqram boyu etibarlı olmasına zəmanət verilir.
//!
//! "Hello_world" in ömrünü də açıq şəkildə deyə bilərik:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Bu moduldakı bir çox istifadə yalnız test konfiqurasiyasında istifadə olunur.
// İstifadə olunmamış_import xəbərdarlığını silməkdənsə, onları silmək daha təmizdir.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>`-də `str` burada mənalı deyil.
/// trait-nin bu tip parametri yalnız başqa bir implenti təmin etmək üçün mövcuddur.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // sabit kodlu ölçülü döngələr daha sürətli işləyir, kiçik ayırıcı uzunluqları olan halları ixtisaslaşdırır
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // özbaşına sıfır olmayan ölçüdə geri dönüş
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Həm Vec üçün işləyən optimize qoşulma tətbiqi<T>(T: Kopyala) və String daxili vec Hal-hazırda (2018-05-13) növü çıxartma və ixtisaslaşma ilə bir səhv var (#36262 sayına baxın) Bu səbəbdən SliceConcat<T>T: Copy və SliceConcat üçün ixtisaslaşdırılmış deyil<str>bu funksiyanın yeganə istifadəçisidir.
// Bunun düzəldildiyi vaxt üçün yerində qalır.
//
// String-join üçün sərhədlər S: Borc<str>və Vec-qoşulmaq üçün Borc <[T]> [T] və str hər ikisi AsRef <[T]> üçün biraz T
// => s.borrow().as_ref() və hər zaman dilimlərimiz var
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ilk dilim ondan əvvəl ayırıcı olmayan yeganə dilimdir
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` hesablaması aşıbsa birləşdirilmiş Vec-in tam ümumi uzunluğunu hesablayın, panic-ni yəqin ki, bitmiş olardıq və qalan funksiya təhlükəsizlik üçün əvvəlcədən ayrılmış bütün Vec-i tələb edir
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // başlanğıc olunmamış bir tampon hazırlayın
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // nüsxə ayırıcı və dilimləri sərhədsiz yoxlayın, kiçik ayırıcıların kütləvi şəkildə yaxşılaşdırılması üçün sərt kodlu ofsetlərlə ilmələr yaradın (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Qəribə bir borc tətbiqi uzunluq hesablanması və həqiqi surəti üçün fərqli dilimləri qaytara bilər.
        //
        // Başlanmamış baytları zəng edənə məruz qoymadığımızdan əmin olun.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Simli dilimlər üçün metodlar.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>`-i kopyalamadan və ayırmadan `Box<[u8]>`-ə çevirir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Bir nümunənin bütün uyğunluqlarını başqa bir simli ilə əvəz edir.
    ///
    /// `replace` yeni bir [`String`] yaradır və bu sətir dilimindəki məlumatları ona köçürür.
    /// Bunu edərkən, bir nümunə uyğunluğu tapmağa çalışır.
    /// Hər hansı bir şey taparsa, onları əvəzli simli dilimlə əvəz edir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Nümunə uyğun gəlmədikdə:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Bir nümunənin ilk N uyğunluğunu başqa bir simli ilə əvəz edir.
    ///
    /// `replacen` yeni bir [`String`] yaradır və bu sətir dilimindəki məlumatları ona köçürür.
    /// Bunu edərkən, bir nümunə uyğunluğu tapmağa çalışır.
    /// Hər hansı bir şey taparsa, onları ən çox `count` dəfə əvəzedici simli dilimlə əvəz edir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Nümunə uyğun gəlmədikdə:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Yenidən ayırma müddətlərinin azaldılmasına ümid edirəm
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Bu simli dilimin kiçik hərfini yeni [`String`] olaraq qaytarır.
    ///
    /// 'Lowercase' Unicode Derived Core Property `Lowercase` şərtlərinə görə müəyyən edilir.
    ///
    /// İşi dəyişdirərkən bəzi simvollar birdən çox simvollara çevrilə bildiyindən, bu funksiya parametri yerində dəyişdirmək əvəzinə [`String`] qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Sigma ilə çətin bir nümunə:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // lakin bir sözün sonunda not deyil, σ olur:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// İşsiz dillər dəyişdirilmir:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ üçün eşlədiyi bir sözün sonunda istisna olmaqla, σ üçün xəritələr.
                // Bu, `SpecialCasing.txt`-də yeganə şərti (contextual), lakin dildən asılı olmayan Xəritəçəkmədir, belə ki, ümumi bir "condition" mexanizminə sahib olmaqdansa, onu sərt şəkildə kodlayın.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` tərifi üçün.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Bu simli dilimin böyük hərfini yeni [`String`] olaraq qaytarır.
    ///
    /// 'Uppercase' Unicode Derived Core Property `Uppercase` şərtlərinə görə müəyyən edilir.
    ///
    /// İşi dəyişdirərkən bəzi simvollar birdən çox simvollara çevrilə bildiyindən, bu funksiya parametri yerində dəyişdirmək əvəzinə [`String`] qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Hərfsiz skriptlər dəyişdirilmir:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Bir simvol çox ola bilər:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`]-i kopyalamadan və ayırmadan [`String`]-ə çevirir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Bir simli `n` dəfə təkrarlayaraq yeni bir [`String`] yaradır.
    ///
    /// # Panics
    ///
    /// Tutumun aşıb-daşması halında bu funksiya panic olacaqdır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Doldurma zamanı bir panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Hər bir simvolun ASCII böyük hərfinə bərabərləşdirildiyi bu sətrin surətini qaytarır.
    ///
    ///
    /// 'a'-'z' arasında ASCII hərfləri 'A'-'Z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Yerdəki dəyəri böyük göstərmək üçün [`make_ascii_uppercase`] istifadə edin.
    ///
    /// ASCII olmayan simvollara əlavə olaraq ASCII simvollarını böyütmək üçün [`to_uppercase`] istifadə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 dəyişməzliyini qoruyur.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Hər bir simvolun ASCII kiçik hərfinə uyğunlaşdırıldığı bu sətrin surətini qaytarır.
    ///
    ///
    /// 'A'-'Z' arasında ASCII hərfləri 'a'-'z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Yerindəki dəyəri azaltmaq üçün [`make_ascii_lowercase`] istifadə edin.
    ///
    /// ASCII olmayan simvollara əlavə olaraq ASCII simvollarını kiçik etmək üçün [`to_lowercase`] istifadə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 dəyişməzliyini qoruyur.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Kutunun bayt dilimini cərgənin etibarlı UTF-8 olduğunu yoxlamadan qutulu simli dilimə çevirir.
///
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}