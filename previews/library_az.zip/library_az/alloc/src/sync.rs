#![stable(feature = "rust1", since = "1.0.0")]

//! Yivə təhlükəsiz istinad sayma göstəriciləri.
//!
//! Daha ətraflı məlumat üçün [`Arc<T>`][Arc] sənədlərinə baxın.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc`-ə müraciət edilə biləcək istinadların həcmində yumşaq bir məhdudiyyət.
///
/// Bu həddən yuxarı getmək, proqramınızı (mütləq olmasa da) _exactly_ `MAX_REFCOUNT + 1` istinadlarında ləğv edəcəkdir.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer yaddaş çəpərlərini dəstəkləmir.
// Arc/Zəif tətbiq sahəsindəki yanlış pozitiv hesabatların qarşısını almaq üçün əvəzinə sinxronizasiya üçün atom yüklərindən istifadə edin.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Mövzu təhlükəsiz bir istinad sayma göstəricisi.'Arc' 'Atomically Reference Counted' mənasını verir.
///
/// `Arc<T>` növü, yığında ayrılmış `T` tipli bir dəyərin paylaşılan mülkiyyətini təmin edir.[`clone`][clone]-i `Arc`-ə çağırmaq, yeni bir `Arc` nümunəsi meydana gətirir ki, bu da istinad sayını artırarkən, `Arc` mənbəyi ilə yığındakı eyni bölgüyə işarə edir.
/// Verilmiş bir ayırmaya son `Arc` göstəricisi məhv edildikdə, bu bölünmədə saxlanılan dəyər (tez-tez "inner value" olaraq da adlandırılır) da düşər.
///
/// Rust-də paylaşılan istinadlar, mütənasib olaraq mutasiyaya icazə vermir və `Arc` istisna deyil: ümumiyyətlə bir `Arc` içərisindəki bir şeyə dəyişkən bir istinad əldə edə bilməzsiniz.Bir `Arc` ilə mutasiya etməlisinizsə, [`Mutex`][mutex], [`RwLock`][rwlock] və ya [`Atomic`][atomic] növlərindən birini istifadə edin.
///
/// ## Mövzu təhlükəsizliyi
///
/// [`Rc<T>`]-dən fərqli olaraq, `Arc<T>` istinad sayılması üçün atom əməliyyatlarından istifadə edir.Bu o deməkdir ki, iplik təhlükəsizdir.Dezavantajı atom əməliyyatlarının adi yaddaş girişlərindən daha bahalı olmasıdır.Mövzular arasında istinad sayılan ayırmalar paylaşmırsınızsa, aşağı xərc üçün [`Rc<T>`] istifadə edin.
/// [`Rc<T>`] təhlükəsiz bir standartdır, çünki tərtibçi mövzuları arasında bir [`Rc<T>`] göndərmə cəhdini tutacaqdır.
/// Bununla birlikdə, kitabxana istehlakçılarına daha çox rahatlıq vermək üçün bir kitabxana `Arc<T>` seçə bilər.
///
/// `Arc<T>` `T` [`Send`] və [`Sync`] tətbiq etdiyi müddətdə [`Send`] və [`Sync`] tətbiq edəcəkdir.
/// Niyə iplik təhlükəsiz `T` tipini `Arc<T>`-ə yerləşdirə bilməzsiniz ki, ipi təhlükəsiz etsin?Bu əvvəlcə bir az əks-intuitiv ola bilər: axı, `Arc<T>` mövzu təhlükəsizliyi deyilmi?Əsas odur ki, `Arc<T>` eyni məlumatların birdən çox sahibliyini təmin edir, lakin məlumatlarına mövzu təhlükəsizliyi əlavə etmir.
///
/// Arc <`[` RefCell<T>"]"> ".
/// [`RefCell<T>`] [`Sync`] deyil və `Arc<T>` həmişə [`Send`] olsaydı, `Arc <` [`RefCell<T>"]">"da olardı.
/// Ancaq sonra bir problemimiz olacaq:
/// [`RefCell<T>`] mövzu təhlükəsiz deyil;atom olmayan əməliyyatlardan istifadə edərək borc sayını izləyir.
///
/// Sonda, bu o deməkdir ki, `Arc<T>`-i bir növ [`std::sync`] tipi ilə, ümumiyyətlə [`Mutex<T>`][mutex] ilə cütləşdirməlisiniz.
///
/// ## `Weak` ilə dövrləri qırmaq
///
/// [`downgrade`][downgrade] metodu sahib olmayan bir [`Weak`] göstəricisi yaratmaq üçün istifadə edilə bilər.Bir [`Weak`] göstəricisi bir `Arc`-ə [`yükseltme '][yükseltme] d ola bilər, lakin bu, ayırmada saxlanılan dəyər əvvəlcədən düşmüşdürsə, bu [`None`]-yə dönəcəkdir.
/// Başqa sözlə, `Weak` göstəriciləri ayırmanın içindəki dəyəri canlı saxlamır;Bununla birlikdə, ayırmanı (dəyər üçün dəstək mağazasını) canlı saxlayırlar.
///
/// `Arc` göstəriciləri arasındakı dövr heç vaxt bölüşdürülməyəcəkdir.
/// Bu səbəbdən, [`Weak`] dövrü qırmaq üçün istifadə olunur.Məsələn, bir ağacın ana qovşaqlarından uşaqlara güclü `Arc` göstəriciləri və uşaqlardan valideynlərinə geri dönən [`Weak`] göstəriciləri ola bilər.
///
/// # İstinadların klonlaşdırılması
///
/// Mövcud bir istinad sayılan göstəricidən yeni bir istinad yaratmaq, [`Arc<T>`][Arc] və [`Weak<T>`][Weak] üçün tətbiq olunan `Clone` trait istifadə edilərək həyata keçirilir.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Aşağıdakı iki sintaksis bərabərdir.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b və foo hamısı eyni yaddaş yerini göstərən Arcsdır
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` avtomatik olaraq `T`-yə ([`Deref`][deref] trait vasitəsi ilə) istinad edilir, beləliklə `Arc<T>` tipli bir qiymətdə `T` metodlarına zəng edə bilərsiniz.`T` metodları ilə ad toqquşmalarının qarşısını almaq üçün `Arc<T>` metodları [fully qualified syntax] istifadə adlanan əlaqəli funksiyalardır:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Qövs<T>traits-nin `Clone` kimi tətbiqetmələrinə tam ixtisaslı sintaksisdən istifadə etmək də adlandırıla bilər.
/// Bəzi insanlar tam ixtisaslı sintaksis istifadə etməyə üstünlük verirlər, bəziləri isə metod-zəng sintaksisindən istifadə etməyə üstünlük verirlər.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metod zəng sintaksis
/// let arc2 = arc.clone();
/// // Tamamilə ixtisaslı sintaksis
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] daxili dəyər onsuz da düşmüş ola biləcəyi üçün `T`-dən avtomatik imtina etmir.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Mövzular arasında bəzi dəyişməz məlumatların paylaşılması:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Qeyd edək ki, bu testləri burada ** aparmırıq.
// windows istehsalçıları, bir iplik əsas sapı ötüb sonra eyni anda çıxırsa (bir şey dalana dirənirsə), bədbəxt olurlar, buna görə bu testləri işə salmamaqla bundan tamamilə qaçırıq.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Dəyişdirilə bilən bir [`AtomicUsize`] paylaşma:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Ümumiyyətlə daha çox istinad sayılması nümunələri üçün [`rc` documentation][rc_examples]-ə baxın.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` idarə olunan ayırmaya sahib olmayan bir istinad verən [`Arc`] versiyasıdır.
/// Ayrılmaya `Weak` göstəricisindəki [`upgrade`] çağırılaraq bir [`Seçim ']` <`[` Arc`]'<T>>".
///
/// Bir `Weak` referansı sahiblik sayılmadığı üçün, ayırmada saxlanılan dəyərin düşməsini maneə törətməyəcək və `Weak` özü hələ də dəyərin mövcudluğuna zəmanət vermir.
///
/// Beləliklə, ['yükseltme'] d olduqda [`None`]-ni geri qaytara bilər.
/// Bununla birlikdə `Weak` referansının * ayırmanın özünün (arxa mağaza) ayrılmasının qarşısını aldığını unutmayın.
///
/// `Weak` göstəricisi, daxili dəyərinin düşməsinin qarşısını almadan [`Arc`] tərəfindən idarə olunan ayırmaya müvəqqəti istinad etmək üçün faydalıdır.
/// Həm də, [`Arc`] göstəriciləri arasında dairəvi istinadların qarşısını almaq üçün istifadə olunur, çünki qarşılıqlı sahiblik referansları heç vaxt [`Arc`]-in düşməsinə imkan verməyəcəkdir.
/// Məsələn, bir ağacın ana qovşaqlarından uşaqlara güclü [`Arc`] göstəriciləri və uşaqlardan valideynlərinə geri dönən `Weak` göstəriciləri ola bilər.
///
/// `Weak` göstəricisini əldə etməyin tipik yolu [`Arc::downgrade`]-ə zəng etməkdir.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Bu, bu növün ölçüsünü enumlarda optimallaşdırmağa imkan verən bir `NonNull`-dir, lakin mütləq etibarlı bir göstərici deyil.
    //
    // `Weak::new` bunu yığın üzərində yer ayırmağa ehtiyac qalmaması üçün `usize::MAX` olaraq təyin edir.
    // RcBox ən azı 2 hizalamasına sahib olduğu üçün həqiqi bir göstəricinin heç alacağı bir dəyər deyil.
    // Bu yalnız `T: Sized` olduqda mümkündür;ölçüsüz `T` heç vaxt sönmür.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Bu, dəyişdirilə bilən daxili növlərin başqa cür təhlükəsiz [into|from]_raw()-inə müdaxilə edəcək mümkün sahə yenidən sifarişinə qarşı repr(C)-future-ə qarşı davamlıdır.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX dəyəri müvəqqəti "locking" zəif göstəriciləri yüksəltmə və ya güclü göstəriciləri aşağı salma qabiliyyəti üçün gözətçi rolunu oynayır;bu `make_mut` və `get_mut`-də yarışların qarşısını almaq üçün istifadə olunur.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Yeni bir `Arc<T>` qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Zəif göstərici sayımını bütün güclü (kinda) göstəricilərinin zəif göstəricisi olan 1 olaraq başlayın, daha çox məlumat üçün std/rc.rs-ə baxın
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Özünə zəif bir müraciət edərək yeni bir `Arc<T>` qurur.
    /// Bu funksiya qaytarılmadan əvvəl zəif referansı yüksəltməyə çalışmaq `None` dəyəri ilə nəticələnəcəkdir.
    /// Lakin zəif istinad sərbəst şəkildə klonlana bilər və daha sonra istifadə üçün saxlanıla bilər.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Tək bir zəif istinadla daxili hissəni "uninitialized" vəziyyətində qurun.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Zəif göstərici sahibliyindən imtina etməməyimiz vacibdir, əks halda `data_fn` qayıtdıqdan sonra yaddaş azad ola bilər.
        // Həqiqətən sahiblikdən keçmək istəsəydik, özümüz üçün əlavə zəif bir göstərici yarada bilərdik, lakin bu, əks halda lazım olmaya biləcək zəif istinad sayında əlavə yeniləmələrlə nəticələnəcəkdir.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // İndi daxili dəyəri düzgün şəkildə işə sala bilərik və zəif istinadımızı güclü bir istinada çevirə bilərik.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Məlumat sahəsinə yuxarıdakı yazı sıfır olmayan güclü sayma müşahidə edən hər hansı bir mövzuya görünməlidir.
            // Buna görə `Weak::upgrade`-də `compare_exchange_weak` ilə sinxronizasiya etmək üçün ən azı "Release" sifarişinə ehtiyacımız var.
            //
            // "Acquire" sifariş tələb olunmur.
            // `data_fn`-nin mümkün davranışlarını nəzərdən keçirərkən yalnız yüksəldilməyən bir `Weak`-ə istinadla nə edə biləcəyinə baxmaq lazımdır:
            //
            // - `Weak`-i *klonlayaraq* zəif istinad sayını artırır.
            // - Zəif istinad sayını azaldaraq (lakin heç vaxt sıfıra enmədən) bu klonları buraxa bilər.
            //
            // Bu yan təsirlər bizə heç bir şəkildə təsir göstərmir və yalnız təhlükəsiz kodla başqa heç bir yan təsir mümkün deyil.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Güclü istinadlar kollektiv olaraq paylaşılan zəif bir referansa sahib olmalıdır, buna görə köhnə zəif istinadımız üçün dağıdıcı işləməyin.
        //
        mem::forget(weak);
        strong
    }

    /// Başlanmamış məzmunu olan yeni bir `Arc` qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yaddaş `0` baytla doldurularaq, başlanğıc olunmamış məzmunu olan yeni bir `Arc` qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yeni bir `Pin<Arc<T>>` qurur.
    /// `T` `Unpin` tətbiq etmirsə, `data` yaddaşa sabitlənəcək və köçürülə bilməz.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Yeni `Arc<T>` qurur, ayırma uğursuz olarsa bir səhv qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Zəif göstərici sayımını bütün güclü (kinda) göstəricilərinin zəif göstəricisi olan 1 olaraq başlayın, daha çox məlumat üçün std/rc.rs-ə baxın
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Başlanmamış məzmunu olan yeni bir `Arc` qurur, ayırma uğursuz olarsa bir səhv qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Yaddaş `0` baytla doldurularaq ayrılma uğursuz olduqda bir səhv qaytararaq başlanğıc olunmamış məzmunu olan yeni bir `Arc` qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc`-də tam bir güclü istinad varsa daxili dəyəri qaytarır.
    ///
    /// Əks təqdirdə, bir [`Err`], ötürülən eyni `Arc` ilə qaytarılır.
    ///
    ///
    /// Görkəmli zəif istinadlar olsa belə bu müvəffəq olacaqdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Gizli güclü-zəif istinadları təmizləmək üçün zəif bir göstərici düzəldin
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Başlanmamış məzmunu olan yeni bir atomik istinad sayılan bir dilim qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Yaddaş `0` baytla doldurularaq, başlanğıc olunmamış məzmunu olan yeni atomik sayılan bir dilim qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>`-ə çevrilir.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-də olduğu kimi, daxili dəyərin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında bunun adlandırılması dərhal təyin olunmayan davranışa səbəb olur.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>`-ə çevrilir.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-də olduğu kimi, daxili dəyərin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında bunun adlandırılması dərhal təyin olunmayan davranışa səbəb olur.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Sarılmış göstəricini geri qaytararaq `Arc`-i istehlak edir.
    ///
    /// Yaddaşın sızmasının qarşısını almaq üçün göstərici [`Arc::from_raw`] istifadə edərək yenidən `Arc`-ə çevrilməlidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Verilənlərə xam bir göstərici təqdim edir.
    ///
    /// Sayılar heç bir şəkildə təsirlənmir və `Arc` tükənmir.
    /// Göstərici `Arc`-də güclü sayımlar olduğu müddətdə etibarlıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // TƏHLÜKƏSİZLİK: Bu, Deref::deref və ya RcBoxPtr::inner-dən keçə bilməz, çünki
        // məsələn raw/mut sınanmasını qorumaq üçün bu lazımdır
        // `get_mut` Rc `from_raw` vasitəsilə bərpa edildikdən sonra göstəricidən yaza bilər.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Xam bir göstəricidən `Arc<T>` qurur.
    ///
    /// Xam göstərici əvvəllər [`Arc<U>::into_raw`][into_raw]-ə bir zəng ilə qaytarılmış olmalıdır, burada `U` `T` ilə eyni ölçüyə və hizaya sahib olmalıdır.
    /// `U` `T` olarsa, bu cüzi şəkildə doğrudur.
    /// Qeyd edək ki, `U` `T` deyilsə, eyni ölçü və hizalamaya sahibdirsə, bu, əsasən müxtəlif növ istinadların ötürülməsinə bənzəyir.
    /// Bu halda hansı məhdudiyyətlərin tətbiq olunduğu barədə daha çox məlumat üçün [`mem::transmute`][transmute]-ə baxın.
    ///
    /// `from_raw` istifadəçisi müəyyən bir `T` dəyərinin yalnız bir dəfə düşməsinə əmin olmalıdır.
    ///
    /// Bu funksiya təhlükəlidir, çünki düzgün olmayan istifadə, geri qaytarılmış `Arc<T>`-ə heç vaxt daxil olmasa belə yaddaşın təhlükəsizliyinə səbəb ola bilər.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Sızıntının qarşısını almaq üçün `Arc`-ə qayıdın.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)`-ə əlavə zənglər yaddaş üçün təhlükəlidir.
    /// }
    ///
    /// // `x` yuxarıdakı əhatə dairəsindən çıxdıqda yaddaş boşaldıldı, buna görə `x_ptr` indi asılır!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Orijinal ArcInner tapmaq üçün ofsetin tərsinə qayıdın.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Bu ayırmaya yeni bir [`Weak`] göstəricisi yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Aşağıdakı CAS-dakı dəyəri yoxladığımız üçün bu rahatdır.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // zəif sayğacın hazırda "locked" olub olmadığını yoxlayın;əgər belədirsə, fırla.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: bu kod hazırda daşma ehtimalını nəzərə almır
            // usize::MAX-ə;ümumiyyətlə həm Rc, həm də Arc daşma ilə mübarizə aparmaq üçün tənzimlənməlidir.
            //

            // Clone()-dən fərqli olaraq, bunun `is_unique`-dən gələn yazı ilə sinxronlaşdırmaq üçün bir Əldə etmə oxumasına ehtiyacımız var, belə ki, əvvəlki hadisələr bu oxunmadan əvvəl baş versin.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Asılı bir Zəif yaratmadığımızdan əmin olun
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Bu ayırmaya [`Weak`] göstərici sayını alır.
    ///
    /// # Safety
    ///
    /// Bu metod öz-özlüyündə təhlükəsizdir, lakin düzgün istifadə etmək daha çox diqqət tələb edir.
    /// Başqa bir mövzu potensial olaraq bu metodu çağırmaq və nəticəyə təsir göstərmək arasında da daxil olmaqla zəif sayını istənilən vaxt dəyişdirə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Bu iddia, deterministikdir, çünki `Arc` və ya `Weak` mövzuları arasında paylaşmadıq.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Zəif sayma hazırda kilidlənibsə, saymanın dəyəri kilidi götürməzdən əvvəl 0 idi.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Bu ayırmaya güclü (`Arc`) göstəricilərinin sayını alır.
    ///
    /// # Safety
    ///
    /// Bu metod öz-özlüyündə təhlükəsizdir, lakin düzgün istifadə etmək daha çox diqqət tələb edir.
    /// Başqa bir mövzu, potensial olaraq bu metodu çağırmaq və nəticəyə əməl etmək arasında da daxil olmaqla hər an güclü sayını dəyişdirə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Bu iddia deterministikdir, çünki `Arc`-i mövzular arasında bölüşmədik.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Təqdim olunan göstərici ilə əlaqəli `Arc<T>`-də güclü istinad sayını bir-bir artırır.
    ///
    /// # Safety
    ///
    /// İşaretçi `Arc::into_raw` vasitəsilə əldə edilmiş və əlaqəli `Arc` nümunəsi etibarlı olmalıdır (yəni
    /// güclü say bu metodun müddəti üçün ən azı 1) olmalıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Bu iddia deterministikdir, çünki `Arc`-i mövzular arasında bölüşmədik.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc'ı saxlayın, ancaq ManuallyDrop-a sararaq yenidən sayma toxunmayın
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // İndi yenidən sayma sayını artırın, lakin yeni yenidən sayma düşməyin
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Təqdim olunan göstərici ilə əlaqəli `Arc<T>`-də güclü istinad sayını azaldır.
    ///
    /// # Safety
    ///
    /// İşaretçi `Arc::into_raw` vasitəsilə əldə edilmiş və əlaqəli `Arc` nümunəsi etibarlı olmalıdır (yəni
    /// bu metodu çağırarkən güclü say ən azı 1) olmalıdır.
    /// Bu metod son `Arc` və arxa ehtiyatı buraxmaq üçün istifadə edilə bilər, lakin son `Arc` buraxıldıqdan sonra ** çağırılmamalıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Bu iddialar deterministikdir, çünki `Arc`-i mövzular arasında bölüşmədik.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Bu təhlükəsizlik təhlükəsizdir, çünki bu qövs sağ ikən daxili göstəricinin etibarlı olduğuna zəmanət veririk.
        // Bundan əlavə, `ArcInner` quruluşunun özünün `Sync` olduğunu bilirik, çünki daxili məlumatlar da `Sync` olduğundan, bu məzmuna dəyişməz bir göstərici təqdim etmək yaxşıdır.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop`-in astarsız hissəsi.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Verilənləri bu anda məhv edin, baxmayaraq ki, qutu ayırmanın özünü azad edə bilmərik (ətrafında zəif göstəricilər ola bilər).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Bütün güclü istinadlar tərəfindən toplu olaraq zəif refü atın
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Hər iki Arc eyni bölgüyə işarə etsə ([`ptr::eq`]-ə bənzər bir damarda) `true` qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Dəyərin təqdim edilmiş tərtibatına sahib olduğu ehtimal olunan ölçüsüz daxili dəyər üçün kifayət qədər boşluq olan bir `ArcInner<T>` ayırır.
    ///
    /// `mem_to_arcinner` funksiyası məlumat göstəricisi ilə çağırılır və `ArcInner<T>` üçün (potensial yağlı) bir göstəriciyə qayıtmalıdır.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Verilən dəyər düzeni istifadə edərək düzəni hesablayın.
        // Əvvəllər yerleşim `&*(ptr as* const ArcInner<T>)` ifadəsi üzərində hesablanmışdı, lakin bu səhv bir istinad yaratdı (bax #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Dəyərin düzəlişinin təmin olunduğu ehtimal olunan ölçüsüz bir daxili dəyər üçün kifayət qədər boşluq olan bir `ArcInner<T>` ayırır və ayırma uğursuz olarsa bir səhv qaytarır.
    ///
    ///
    /// `mem_to_arcinner` funksiyası məlumat göstəricisi ilə çağırılır və `ArcInner<T>` üçün (potensial yağlı) bir göstəriciyə qayıtmalıdır.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Verilən dəyər düzeni istifadə edərək düzəni hesablayın.
        // Əvvəllər yerleşim `&*(ptr as* const ArcInner<T>)` ifadəsi üzərində hesablanmışdı, lakin bu səhv bir istinad yaratdı (bax #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner-i başladın
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Ölçüsüz daxili dəyər üçün kifayət qədər boşluq olan bir `ArcInner<T>` ayırır.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Verilən dəyəri istifadə edərək `ArcInner<T>` üçün ayırın.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Dəyəri bayt şəklində kopyalayın
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Tərkibini tərk etmədən ayırmanı pulsuz edin
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Verilmiş uzunluqda bir `ArcInner<[T]>` ayırır.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Elementləri dilimdən yeni ayrılmış Arc <\[T\]> içərisinə kopyalayın
    ///
    /// Təhlükəsiz deyil, çünki zəng edən şəxs ya sahiblik etməlidir, ya da `T: Copy`-i bağlamalıdır.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Müəyyən bir ölçüdə olduğu bilinən bir iteratordan bir `Arc<[T]>` qurur.
    ///
    /// Ölçüsü səhv olmalıdırsa, davranış təyin olunmur.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T elementlərini klonlayarkən Panic qoruyucu.
        // Bir panic olması halında, yeni ArcInner-ə yazılmış elementlər atılacaq, sonra yaddaş boşaldılacaq.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Birinci elementə göstərici
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Hamısı aydındır.Mühafizəni unudun ki, yeni ArcInner-i azad etməsin.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` üçün istifadə olunan trait ixtisası.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` göstəricisinin klonunu yaradır.
    ///
    /// Bu eyni istinad üçün başqa bir göstərici yaradır və güclü istinad sayını artırır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Rahat bir sifarişdən istifadə etmək yaxşıdır, çünki orijinal istinad haqqında məlumat digər mövzuların obyektin səhvən silinməsinin qarşısını alır.
        //
        // [Boost documentation][1]-də izah edildiyi kimi, istinad sayğacını artırmaq həmişə memory_order_relaxed ilə edilə bilər: Bir obyektə yeni istinadlar yalnız mövcud bir istinaddan meydana gələ bilər və mövcud bir arayışdan digərinə ötürülməsi lazım olan hər hansı bir sinxronizasiyanı təmin etməlidir.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Bununla birlikdə kiminsə "mem: : unut" unutduqda olması halında kütləvi yenidən hesablamalardan qorunmalıyıq.
        // Bunu etməsək, sayma aça bilər və istifadəçilər sonradan pulsuz istifadə edəcəklər.
        // Referans sayını bir dəfəyə artıran ~2 milyard mövzu olmadığı fərziyyəsi ilə `isize::MAX`-yə doymuşuq.
        //
        // Bu branch heç vaxt heç bir realist proqramda alınmayacaq.
        //
        // Abort edirik, çünki belə bir proqram inanılmaz dərəcədə degenerativdir və onu dəstəkləməyimizə əhəmiyyət vermirik.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Verilən `Arc`-ə dəyişkən bir istinad edir.
    ///
    /// Eyni ayırmaya başqa `Arc` və ya [`Weak`] göstəriciləri varsa, `make_mut` yeni bir ayırma yaradacaq və unikal sahibliyi təmin etmək üçün daxili dəyərdə [`clone`][clone] çağıracaq.
    /// Buna yaz-klon yazma da deyilir.
    ///
    /// Qeyd edək ki, bu, qalan `Weak` göstəricilərini ayıran [`Rc::make_mut`] davranışından fərqlənir.
    ///
    /// Klonlaşdırmaqdansa uğursuz olacaq [`get_mut`][get_mut]-ə də baxın.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Heç bir şey klonlamayacaq
    /// let mut other_data = Arc::clone(&data); // Daxili məlumatlar klonlanmayacaq
    /// *Arc::make_mut(&mut data) += 1;         // Daxili məlumatları klonlaşdırır
    /// *Arc::make_mut(&mut data) += 1;         // Heç bir şey klonlamayacaq
    /// *Arc::make_mut(&mut other_data) *= 2;   // Heç bir şey klonlamayacaq
    ///
    /// // İndi `data` və `other_data` fərqli ayırmalara işarə edirlər.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Həm güclü bir istinad, həm də zəif bir istinad etdiyimizi unutmayın.
        // Beləliklə, güclü istinadımızı yayımlamaq, öz-özlüyündə yaddaşın ayrılmasına səbəb olmaz.
        //
        // `strong`-ə yazılmadan (yəni azalmalar) başlamazdan əvvəl baş verən `weak`-ə hər hansı bir yazı yazdığımızı təmin etmək üçün Əldə edin.
        // Zəif bir sayma apardığımız üçün ArcInner-in özünün bölüşdürülmə şansı yoxdur.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Başqa bir güclü göstərici mövcuddur, buna görə klonlaşdırmalıyıq.
            // Klonlanmış dəyəri birbaşa yazmağa imkan vermək üçün əvvəlcədən yaddaş ayırın.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Yuxarıda sadalananlar kifayətdir, çünki bu, əsas etibarilə bir optimallaşdırmadır: hər zaman zəif göstəricilərin atılması ilə yarışırıq.
            // Ən pis halda, lazımsız bir şəkildə yeni bir Arc ayırdıq.
            //

            // Son güclü refi sildik, ancaq əlavə zəif reflər qaldı.
            // Məzmunu yeni bir Qövsə köçürəcəyik və digər zəif referatları etibarsız edəcəyik.
            //

            // `weak`-in oxunuşunun usize::MAX (yəni kilidli) verməsi mümkün olmadığını unutmayın, çünki zəif sayma yalnız güclü bir istinadla bir iplə kilidlənə bilər.
            //
            //

            // ArcInner-i lazım olduqda təmizləyə bilməsi üçün gizli zəif göstəricimizi maddi hala gətirin.
            //
            let _weak = Weak { ptr: this.ptr };

            // Yalnız məlumatları oğurlaya bilər, yalnız Zəiflər qalır
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Hər növün yeganə referansı biz idik;güclü ref sayını geri çəkin.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()`-də olduğu kimi, təhlükəsizlik də yaxşıdır, çünki istinadımız ya bənzərsizdi, ya da məzmunu klonlaşdırdıqdan sonra oldu.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Eyni bölüşdürmə üçün başqa `Arc` və ya [`Weak`] göstəriciləri olmadığı təqdirdə, verilə bilən `Arc`-ə dəyişdirilə bilən bir referansı qaytarır.
    ///
    ///
    /// Əks təqdirdə [`None`] qaytarır, çünki paylaşılan bir dəyəri dəyişdirmək təhlükəsiz deyil.
    ///
    /// Digər göstəricilər olduqda daxili dəyəri [`clone`][clone] edəcək olan [`make_mut`][make_mut]-ə də baxın.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Bu təhlükəsizlik tamamilə yaxşıdır, çünki qaytarılmış göstəricinin T-yə qaytarılacaq *yeganə* göstəricisinə zəmanət veririk.
            // Bu nöqtədə istinad sayımızın 1 olacağına zəmanət verilir və Arcın özünün `mut` olmasını tələb edirdik, buna görə daxili məlumatlara mümkün olan tək istinadı qaytarırıq.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Verilən `Arc`-ə heç bir yoxlama olmadan dəyişdirilə bilən bir referansı qaytarır.
    ///
    /// Təhlükəsiz və uyğun yoxlamalar aparan [`get_mut`]-ə də baxın.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Eyni bölüşdürmə üçün hər hansı digər `Arc` və ya [`Weak`] göstəriciləri, qaytarılmış borc müddəti üçün ayrılmamalıdır.
    ///
    /// Bu cür göstəricilər yoxdursa, məsələn, `Arc::new`-dən dərhal sonra belədir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" sahələrini əhatə edən bir arayış yaratmamağa * ehtiyatlıyıq, çünki bu, istinad sayımlarına paralel giriş ilə takma ad verəcəkdir (məs.
        // `Weak` tərəfindən).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bunun altındakı məlumatlara bənzərsiz istinad (zəif istinadlar daxil olmaqla) olub olmadığını müəyyənləşdirin.
    ///
    ///
    /// Bunun zəif ref sayının kilidlənməsini tələb etdiyini unutmayın.
    fn is_unique(&mut self) -> bool {
        // yeganə zəif göstərici sahibi olduğumuz halda zəif göstərici sayını kilidləyin.
        //
        // Buradakı əldə etmə etiketi, `weak` sayının azalmasından (azad istifadə edən `Weak::drop` vasitəsi ilə) əvvəl `strong`-ə (xüsusən `Weak::upgrade`-də) hər hansı bir yazı ilə əlaqəli bir əlaqəni təmin edir.
        // Yenilənmiş zəif ref heç vaxt düşməyibsə, buradakı CAS uğursuz olacaq, buna görə sinxronizasiya etməyimiz vacib deyil.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Bunun `drop`-də `strong` sayğacının azalması ilə sinxronizasiya etmək üçün bir `Acquire` olması lazımdır-son referansdan başqa hər hansı bir kəsildikdə baş verən yeganə giriş.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Buradakı buraxılış `downgrade`-də bir oxu ilə sinxronizasiya edir və yuxarıdakı `strong` oxumasının yazıdan sonra baş verməsinin qarşısını alır.
            //
            //
            self.inner().weak.store(1, Release); // kilidi buraxın
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` düşür.
    ///
    /// Bu güclü istinad sayını azaldır.
    /// Güclü istinad sayı sıfıra çatırsa, digər istinadlar (varsa) [`Weak`]-dir, buna görə daxili dəyəri `drop` edirik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Heç bir şey çap etmir
    /// drop(foo2);   // "dropped!" çap edir
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` onsuz da atomik olduğundan, obyekti silməyəcəyik halda, digər mövzu ilə sinxronizasiya etməyimizə ehtiyac yoxdur.
        // Eyni məntiq aşağıda göstərilən `fetch_sub` üçün `weak` sayımı üçün tətbiq olunur.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Bu çəpər məlumatların istifadəsi və məlumatların silinməsinin qarşısını almaq üçün lazımdır.
        // `Release` olaraq qeyd olunduğundan, referans sayının azalması bu `Acquire` çit ilə sinxronizasiya olunur.
        // Bu, məlumatların istifadəsi məlumatların silinməsindən əvvəl baş verən bu hasardan əvvəl baş verən istinad sayının azalmasından əvvəl baş verdiyi deməkdir.
        //
        // [Boost documentation][1]-də izah edildiyi kimi,
        //
        // > Mümkün olan hər hansı bir girişi birində tətbiq etmək vacibdir
        // > mövzu (mövcud istinad vasitəsi ilə) * silinmədən əvvəl baş verəcəkdir
        // > fərqli bir mövzuda obyekt.Buna bir "release" nail olur
        // > bir istinad buraxıldıqdan sonra əməliyyat (obyektə hər hansı bir giriş
        // > bu arayış vasitəsilə açıq şəkildə əvvəl baş verməli idi) və bir
        // > "acquire" obyekti silmədən əvvəl əməliyyat.
        //
        // Xüsusilə, bir Qövsün məzmunu ümumiyyətlə dəyişməz olsa da, Mutex kimi bir şeyə daxili yazıların olması mümkündür.<T>.
        // Mutex silindikdə əldə olunmadığından, A mövzuya yazmağı B işləyən bir destruktora görünən etmək üçün onun sinxronizasiya məntiqinə etibar edə bilmərik.
        //
        //
        // Buradakı Alın hasarının, ehtimal ki, yüksək mübahisəli vəziyyətlərdə performansı artıra biləcək bir yükləmə ilə əvəz edilə biləcəyini unutmayın.[2]-ə baxın.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>`-i konkret bir növə endirməyə cəhd edin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Heç bir yaddaş ayırmadan yeni bir `Weak<T>` qurur.
    /// Qaytarma dəyərində [`upgrade`] çağırmaq həmişə [`None`] verir.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Məlumat sahəsi ilə bağlı heç bir iddia vermədən istinad sayımlarına daxil olmağa imkan verən köməkçi növü.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Bu `Weak<T>` tərəfindən göstərilən `T` obyektinə xam bir göstəricini qaytarır.
    ///
    /// Göstərici yalnız bəzi güclü istinadlar olduqda etibarlıdır.
    /// İşaretçi asma, düzəldilməmiş və ya başqa bir şəkildə [`null`] ola bilər.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Hər ikisi eyni obyekti göstərir
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Buradakı güclülər onu canlı saxlayır, buna görə də obyektə hələ də daxil ola bilərik.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ancaq daha çox deyil.
    /// // weak.as_ptr() edə bilərik, ancaq göstəriciyə daxil olmaq müəyyən olmayan bir davranışa səbəb olardı.
    /// // assert_eq! ("salam", təhlükəli {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Göstərici asılırsa, biz gözətçini birbaşa qaytarırıq.
            // Yük, ən azı ArcInner (usize) qədər hizalanmış olduğundan, bu, etibarlı bir yük ünvanı ola bilməz.
            ptr as *const T
        } else {
            // TƏHLÜKƏSİZLİK: əgər is_dangling yalnış nəticə verərsə, o zaman göstərici ayrılır.
            // Bu nöqtədə faydalı yük düşə bilər və biz sınanma səviyyəsini qorumalıyıq, buna görə xam göstərici manipulyasiyasından istifadə edin.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>`-i istehlak edir və xam bir göstəriciyə çevirir.
    ///
    /// Bu, zəif göstəricini xam göstəriciyə çevirir, eyni zamanda bir zəif istinadın sahibliyini qoruyur (zəif say bu əməliyyatla dəyişdirilmir).
    /// [`from_raw`] ilə yenidən `Weak<T>`-ə çevrilə bilər.
    ///
    /// [`as_ptr`] ilə göstəricinin hədəfinə eyni məhdudiyyətlər tətbiq olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] tərəfindən əvvəllər yaradılmış xam göstəricini yenidən `Weak<T>`-ə çevirir.
    ///
    /// Bu, güclü bir istinad əldə etmək üçün (daha sonra [`upgrade`]-yə zəng edərək) və ya `Weak<T>`-i salmaqla zəif sayını ayırmaq üçün istifadə edilə bilər.
    ///
    /// Bir zəif referansın sahibliyini tələb edir ([`new`] tərəfindən yaradılmış göstəricilər istisna olmaqla, bunlar heç bir şeyə sahib deyildir; metod hələ də onların üzərində işləyir).
    ///
    /// # Safety
    ///
    /// Göstərici [`into_raw`]-dən qaynaqlanmış və potensial zəif istinadına sahib olmalıdır.
    ///
    /// Buna zəng edərkən güclü saymanın 0 olmasına icazə verilir.
    /// Buna baxmayaraq, bu, hazırda xammal göstəricisi kimi təmsil olunan bir zəif referansın sahibliyini alır (zəif say bu əməliyyatla dəyişdirilmir) və bu səbəbdən əvvəlki [`into_raw`] çağırışı ilə cütləşdirilməlidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Son zəif sayını azaldır.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Giriş göstəricisinin necə əldə edildiyi barədə kontekst üçün Weak::as_ptr-ə baxın.

        let ptr = if is_dangling(ptr as *mut T) {
            // Bu, asılan bir Zəifdir.
            ptr as *mut ArcInner<T>
        } else {
            // Əks təqdirdə, göstəriciyə qulaq asmayan bir Zəifdən gəldiyinə zəmanət veririk.
            // TƏHLÜKƏSİZLİK: data_offset zəng etmək təhlükəsizdir, çünki ptr həqiqi (potensial olaraq düşmüş) T-yə istinad edir.
            let offset = unsafe { data_offset(ptr) };
            // Beləliklə, bütün RcBox-u əldə etmək üçün ofseti tərsinə çeviririk.
            // TƏHLÜKƏSİZLİK: göstərici zəifdir, bu ofset təhlükəsizdir.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // TƏHLÜKƏSİZLİK: orijinal Zəif göstəricini bərpa etdik, Zəifləri yarada bilərik.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` göstəricisini [`Arc`]-ə yüksəltmək cəhdləri, müvəffəq olarsa daxili dəyərin düşməsini təxirə salır.
    ///
    ///
    /// Daxili dəyər o vaxtdan bəri düşmüşdürsə [`None`] qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Bütün güclü göstəriciləri məhv edin.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Bu funksiya heç vaxt istinad sayını sıfırdan birə götürməməsi üçün bir fetch_add əvəzinə güclü sayını artırmaq üçün CAS döngəsindən istifadə edirik.
        //
        //
        let inner = self.inner()?;

        // Rahat yük, çünki müşahidə edə biləcəyimiz hər hansı bir 0 yazısı sahəni həmişəlik sıfır vəziyyətdə qoyur (beləliklə 0-un "stale" oxunuşu yaxşıdır) və digər dəyərlər aşağıdakı CAS vasitəsilə təsdiqlənir.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Bunu niyə etdiyimiz üçün `Arc::clone`-də şərhlərə baxın (`mem::forget` üçün).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed, uğursuzluq işi üçün yaxşıdır, çünki yeni vəziyyətlə bağlı heç bir gözləntimiz yoxdur.
            // Əldə etmə, `Weak` istinadları yaradıldıqdan sonra daxili dəyər başlanğıc oluna biləcəyi zaman müvəffəqiyyət vəziyyətinin `Arc::new_cyclic` ilə sinxronlaşdırması üçün lazımdır.
            // Bu vəziyyətdə, tamamilə başlanmış dəyəri müşahidə edəcəyimizi gözləyirik.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // yuxarıda yoxlanıldı
                Err(old) => n = old,
            }
        }
    }

    /// Bu ayırmaya işarə edən güclü (`Arc`) göstəricilərinin sayını alır.
    ///
    /// `self` [`Weak::new`] istifadə edərək yaradılmışdırsa, bu 0 qaytaracaqdır.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Bu ayırmaya işarə edən `Weak` göstəricilərinin sayına yaxınlaşma əldə edir.
    ///
    /// `self` [`Weak::new`] istifadə edərək yaradılıbsa və ya qalan güclü göstəricilər yoxdursa, bu 0-a dönəcəkdir.
    ///
    /// # Accuracy
    ///
    /// Tətbiq detallarına görə, digər iplər hər hansı bir "Arc`s"və ya"Weak`s" eyni ayırmaya işarə edərkən hər iki istiqamətdə də 1-ə söndürülə bilər.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Zəif sayını oxuduqdan sonra ən azı bir güclü göstəricinin olduğunu müşahidə etdiyimiz üçün, zəif sayını müşahidə etdiyimiz zaman gizli zəif referansın (hər hansı bir güclü istinad yaşandıqda mövcuddur) hələ də mövcud olduğunu bilirik və buna görə də onu etibarlı şəkildə çıxara bilərik.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// İşaretçi asıldıqda və ayrılmış `ArcInner` olmadığı zaman `None` qaytarır (yəni bu `Weak` `Weak::new` tərəfindən yaradıldıqda).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" sahəsini əhatə edən bir referans yaratmamağa * ehtiyatlıyıq, çünki sahə eyni zamanda mutasiya edilə bilər (məsələn, son `Arc` düşərsə, məlumat sahəsi yerində düşəcək).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// İki Zəif eyni ayırmaya ([`ptr::eq`]-ə bənzər) işarə etsə və ya hər ikisi heç bir ayırmaya işarə etmirsə (`Weak::new()`) ilə yaradıldıqları üçün) `true` qaytarır.
    ///
    ///
    /// # Notes
    ///
    /// Bu göstəriciləri müqayisə etdiyindən, `Weak::new()`-nin hər hansı bir ayırmaya işarə etməmələrinə baxmayaraq bir-birlərinə bərabər olacağı deməkdir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ilə müqayisə.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` göstəricisindən eyni bölgüyə işarə edən bir klon edir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Bunun rahat olması üçün Arc::clone()-də şərhlərə baxın.
        // Bu bir fetch_add istifadə edə bilər (kilidi görməməzlikdən), çünki zəif say yalnız mövcudluqda *başqa* zəif göstəricilərin olmadığı yerdə kilidlənir.
        //
        // (Yəni bu halda bu kodu işlədə bilmərik).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Bunu niyə etdiyimiz üçün Arc::clone()-də şərhlərə baxın (mem::forget üçün).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Yaddaş ayırmadan yeni bir `Weak<T>` qurur.
    /// Qaytarma dəyərində [`upgrade`] çağırmaq həmişə [`None`] verir.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` göstəricisini atır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Heç bir şey çap etmir
    /// drop(foo);        // "dropped!" çap edir
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Son zəif göstərici olduğumuzu bilsək, məlumatları tamamilə bölüşdürmə vaxtıdır.Arc::drop()-də yaddaş sifarişləri ilə bağlı müzakirələrə baxın
        //
        // Burada kilidlənmiş vəziyyəti yoxlamaq lazım deyil, çünki zəif sayma dəqiq bir zəif ref olduğu təqdirdə kilidlənə bilər, yəni düşmə yalnız sonradan qalan zəif refü açar, yalnız kilid buraxıldıqdan sonra baş verə bilər.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Bu uzmanlığı burada edirik və `&T`-də daha ümumi bir optimallaşdırma kimi deyil, çünki əks təqdirdə bütün bərabərlik yoxlamalarına bir maliyyət əlavə edəcəkdir.
/// Arc`-lərin klonlaşdırılması yavaş, eyni zamanda bərabərliyi yoxlamaq üçün ağır olan böyük dəyərləri saxlamaq üçün istifadə edildiyini və bu xərcin daha asan ödənilməsinə səbəb olduğunu düşünürük.
///
/// Eyni dəyərə işarə edən iki `Arc` klonunun olması, iki "T" dən daha yüksəkdir.
///
/// Bunu yalnız `T: Eq` bir `PartialEq` olaraq bilərəkdən irəliləməz ola biləcəyi zaman edə bilərik.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// İki Arc üçün bərabərlik.
    ///
    /// İki `Arc`, fərqli dəyərlərdə saxlanılsa da daxili dəyərləri bərabər olduqda bərabərdir.
    ///
    /// `T` eyni zamanda `Eq` (bərabərliyin refleksivliyini nəzərdə tutur) tətbiq edərsə, eyni bölgüyə işarə edən iki "Arc" həmişə bərabərdir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// İki Arc üçün bərabərsizlik.
    ///
    /// İki "Arc" bərabər deyil, daxili dəyərləri bərabər deyilsə.
    ///
    /// `T` eyni zamanda `Eq` (bərabərliyin refleksivliyini nəzərdə tutur) tətbiq edərsə, eyni dəyərə işarə edən iki "Arc" heç vaxt bərabər deyil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// İki Arc üçün qismən müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `partial_cmp()` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// İki Arc üçün müqayisədən daha azdır.
    ///
    /// İkisi daxili dəyərlərinə görə `<` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// İki Arc üçün 'az və ya bərabər' müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `<=` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// İki Arc üçün müqayisədən daha böyükdür.
    ///
    /// İkisi daxili dəyərlərinə görə `>` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// İki Arc üçün 'daha böyük və ya bərabər' müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `>=` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// İki Arc üçün müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `cmp()` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` üçün `Default` dəyəri ilə yeni bir `Arc<T>` yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Bir istinad sayılan dilimi ayırın və "v" maddələrini klonlayaraq doldurun.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Bir istinad sayılmış `str` ayırın və içərisinə `v` kopyalayın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Bir istinad sayılmış `str` ayırın və içərisinə `v` kopyalayın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Qutulu bir obyekti yeni, istinad sayılan ayırmaya köçürün.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Referans sayılan bir dilimi ayırın və içərisinə "v" maddələrini köçürün.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec-in yaddaşını boşaltmasına icazə verin, lakin tərkibini məhv etməyin
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Hər bir elementi `Iterator`-də götürür və `Arc<[T]>`-ə yığır.
    ///
    /// # Performans xüsusiyyətləri
    ///
    /// ## Ümumi vəziyyət
    ///
    /// Ümumiyyətlə, `Arc<[T]>`-ə toplama əvvəlcə `Vec<T>`-ə toplanmaqla həyata keçirilir.Yəni aşağıdakıları yazarkən:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// bu sanki yazmış kimi davranırıq:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // İlk ayırmalar dəsti burada olur.
    ///     .into(); // `Arc<[T]>` üçün ikinci bir ayırma burada olur.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bu, `Vec<T>`-i qurmaq üçün lazım olan qədər ayıracaq və sonra `Vec<T>`-i `Arc<[T]>`-ə çevirmək üçün bir dəfə ayıracaq.
    ///
    ///
    /// ## Uzunluğu məlum olan təkrarlayıcılar
    ///
    /// `Iterator` cihazınız `TrustedLen` tətbiq etdikdə və tam ölçüdə olduqda, `Arc<[T]>` üçün tək bir ayırma ediləcəkdir.Misal üçün:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Burada yalnız bir ayırma olur.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>`-ə yığmaq üçün istifadə olunan trait ixtisası.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Bu bir `TrustedLen` iterator üçün belədir.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // TƏHLÜKƏSİZLİK: Yineleyicinin dəqiq bir uzunluğuna sahib olduğumuzu təmin etməliyik.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Normal həyata qayıt.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Bir göstəricinin arxasındakı faydalı yük üçün `ArcInner`-də ofset alın.
///
/// # Safety
///
/// Göstərici əvvəlcədən etibarlı olan T nümunəsinə işarə etməlidir (və bunun üçün etibarlı metadata sahib olmalıdır), lakin T-nin atılmasına icazə verilir.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ölçüsüz dəyəri ArcInner sonuna düzəldin.
    // RcBox repr(C) olduğundan, yaddaşdakı həmişə son sahə olacaqdır.
    // TƏHLÜKƏSİZLİK: yalnız ölçüsüz növlər dilimlər olduğundan, trait obyektləri,
    // və xarici növlər, giriş təhlükəsizliyi tələbi hazırda align_of_val_raw tələblərini ödəmək üçün kifayətdir;bu dilin std xaricində etibar edilə bilməyəcək bir tətbiq detalıdır.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}