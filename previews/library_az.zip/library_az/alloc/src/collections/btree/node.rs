// Bu, idealdan sonra həyata keçirilməyə cəhddir
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust-nin əslində asılı tipləri və polimorfik rekursiyası olmadığından, bir çox təhlükəsizliyi təmin edirik.
//

// Bu modulun əsas məqsədi ağaca ümumi (qəribə formalı olduqda) bir qab kimi baxaraq B-Tree dəyişməzlərinin çoxu ilə işləməkdən çəkinərək mürəkkəbliyin qarşısını almaqdır.
//
// Beləliklə, bu modul girişlərin çeşidlənib-ayrılmaması, hansı qovşaqların az doldura bilməsi və ya hətta dolğunluq mənasını vermir.Bununla birlikdə, bir neçə dəyişməzə etibar edirik:
//
// - Ağaclarda vahid depth/height olmalıdır.Bu o deməkdir ki, müəyyən bir qovşaqdan bir yarpağa enən hər yol eyni uzunluqdadır.
// - `n` uzunluğunda bir düyünün `n` düymələri, `n` dəyərləri və `n + 1` kənarları vardır.
//   Bu, boş bir qovşaqda belə ən azı bir edge olduğuna işarə edir.
//   Bir yarpaq nodu üçün "having an edge" yalnız qovşaqdakı bir yeri müəyyənləşdirə bilərik, çünki yarpaq kənarları boşdur və heç bir məlumat təqdimatına ehtiyac yoxdur.
// Daxili bir qovşaqda bir edge həm bir mövqeyi təyin edir, həm də bir uşaq düyünə bir göstərici ehtiva edir.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Yarpaq düyünlərinin və daxili düyünlərin bir hissəsinin təməl nümayişi.
struct LeafNode<K, V> {
    /// `K` və `V`-də dəyişkən olmaq istəyirik.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Bu qovşaq indeksini ana düyünün `edges` massivinə daxil edir.
    /// `*node.parent.edges[node.parent_idx]` `node` ilə eyni şey olmalıdır.
    /// Bunun yalnız `parent` sıfır olduqda başlanğıc edilməsi təmin edilir.
    parent_idx: MaybeUninit<u16>,

    /// Bu qovşağın saxladığı düymələrin və dəyərlərin sayı.
    len: u16,

    /// Düyünün həqiqi məlumatlarını saxlayan massivlər.
    /// Hər bir massivin yalnız ilk `len` elementləri işə salındı və etibarlıdır.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Yerində yeni bir `LeafNode` başlatır.
    unsafe fn init(this: *mut Self) {
        // Ümumi bir siyasət olaraq, ola biləcəyi təqdirdə sahələri başlanğıcsız buraxırıq, çünki Valgrind-də izləmək biraz daha sürətli və daha asan olmalıdır.
        //
        unsafe {
            // parent_idx, düymələr və valslar bəlkə də birdir
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Yeni qutulu `LeafNode` yaradır.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Daxili qovşaqların təməl nümayişi.`LeafNode`larda olduğu kimi, başlanğıc olunmamış düymələrin və dəyərlərin düşməsinin qarşısını almaq üçün bunlar 'BoxedNode`un arxasında gizlənməlidir.
/// Bir `InternalNode`-ə hər hansı bir göstərici birbaşa qovşağın altındakı `LeafNode` hissəsinə bir göstəriciyə atıla bilər, bu da kodun bir göstəricidən hansının göstərildiyini yoxlamadan da yarpaq və daxili qovşaqlarda ümumiyyətlə hərəkət etməsinə imkan verir.
///
/// Bu xüsusiyyət, `repr(C)` istifadə edərək effektivdir.
///
#[repr(C)]
// gdb_providers.py introspection üçün bu tip addan istifadə edir.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Bu düyünün uşaqlarına işarə.
    /// `len + 1` bunlardan bəziləri başlanğıc və etibarlı sayılır, istisna olmaqla sona yaxın, ağac `Dying` borc növü ilə tutulursa, bu göstəricilərin bəziləri asılır.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Yeni qutulu `InternalNode` yaradır.
    ///
    /// # Safety
    /// Daxili düyünlərin dəyişməzliyi, ən azı bir başlanğıc və etibarlı edge olmasıdır.
    /// Bu funksiya belə bir edge qurmur.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Yalnız məlumatları işə salmalıyıq;kənarları Bəlkə Uninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Bir düyünə idarə olunan, boş olmayan bir göstərici.Bu ya `LeafNode<K, V>`-ə məxsus bir göstəricidir, ya da `InternalNode<K, V>`-ə məxsus bir göstəricidir.
///
/// Bununla birlikdə, `BoxedNode`, iki növ qovşaqdan hansını ehtiva etdiyinə dair bir məlumat içermir və qismən bu məlumat çatışmazlığı səbəbindən ayrı bir tip deyil və heç bir destruktoru yoxdur.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Sahib olunan ağacın kök düyünü.
///
/// Bunun destruktoru olmadığını və əl ilə təmizlənməsini unutmayın.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Başlanğıcda boş olan öz kök düyünlü yeni bir ağacı qaytarır.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` sıfır olmamalıdır.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Müvafiq olaraq sahib olduğunuz kök nodu borcludur.
    /// `reborrow_mut`-dən fərqli olaraq, bu təhlükəsizdir, çünki qaytarma dəyəri kökü məhv etmək üçün istifadə edilə bilməz və ağac üçün başqa istinadlar ola bilməz.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Sahib olan kök düyününü bir qədər dəyişə bilər.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Geri dönməz şəkildə keçməyə icazə verən və dağıdıcı metodlar təklif edən və daha az şey təklif edən bir referansa keçid.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Əvvəlki kök qovşağına işarə edən tək bir edge ilə yeni bir daxili düyün əlavə edir, bu yeni düyünü kök düyününə çevirin və geri qaytarın.
    /// Bu hündürlüyü 1 artırır və `pop_internal_level`-in əksinədir.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, istisna olmaqla, indi daxili olduğumuzu unutmuşuq:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// İlk kökünü yeni kök nodu kimi istifadə edərək daxili kök düyününü silir.
    /// Yalnız kök qovşağında bir uşaq olduqda çağırılması nəzərdə tutulduğundan, düymələrin, dəyərlərin və digər uşaqların heç birində təmizlənmə aparılmır.
    ///
    /// Bu hündürlüyü 1 azaldır və `push_internal_level`-in əksinədir.
    ///
    /// `Root` obyektinə eksklüziv giriş tələb edir, lakin kök düyünə deyil;
    /// digər tutacaqları və ya kök qovşağına istinadları etibarsız saymaz.
    ///
    /// Panics daxili səviyyə yoxdursa, yəni kök düyünü bir yarpaqdırsa.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // TƏHLÜKƏSİZLİK: daxili olduğumuzu iddia etdik.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // TƏHLÜKƏSİZLİK: yalnız `self` borc almışıq və borc növü müstəsnadır.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // GÜVƏNLİK: ilk edge daima başlatılır.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef`, `BorrowType` `Mut` olmasına baxmayaraq, həmişə `K` və `V`-də dəyişkəndir.
// Bu texniki cəhətdən səhvdir, lakin `NodeRef`-in daxili istifadəsi səbəbindən hər hansı bir təhlükəsizliklə nəticələnə bilməz, çünki `K` və `V` üzərində tamamilə ümumi qalırıq.
//
// Bununla birlikdə, hər hansı bir ümumi tip `NodeRef`-i bağladıqda, onun düzgün dispersiyasına malik olduğundan əmin olun.
//
/// Bir düyünə istinad.
///
/// Bu tip, hərəkət qaydalarını idarə edən bir sıra parametrlərə malikdir:
/// - `BorrowType`: Borc növünü təsvir edən və ömür boyu daşıyan bir kukla növü.
///    - Bu `Immut<'a>` olduqda, `NodeRef` təxminən `&'a Node` kimi davranır.
///    - Bu `ValMut<'a>` olduqda, `NodeRef` düymələrə və ağac quruluşuna görə təxminən `&'a Node` kimi davranır, eyni zamanda ağacdakı dəyərlərə bir çox dəyişkən istinadların bir yerdə yaşamasına imkan verir.
///    - Bu `Mut<'a>` olduqda, `NodeRef` təxminən `&'a mut Node` kimi davranır, baxmayaraq ki, insert metodları dəyişdirilə bilən bir göstəricinin bir dəyərlə yanaşı yaşamasına imkan verir.
///    - Bu `Owned` olduqda, `NodeRef` təxminən `Box<Node>` kimi davranır, lakin bir destruktoru yoxdur və əl ilə təmizlənməlidir.
///    - Bu `Dying` olduqda, `NodeRef` hələ də təxminən `Box<Node>` kimi davranır, ancaq ağacı hissə-hissə məhv etmək üsullarına malikdir və adi metodlar zəng etmək üçün təhlükəli kimi qeyd olunmasa da, səhv çağırıldıqda UB-yə müraciət edə bilər.
///
///   Hər hansı bir `NodeRef` ağacda gəzməyə imkan verdiyindən, `BorrowType` yalnız düyünün özünə deyil, bütün ağaca aiddir.
/// - `K` və `V`: Bunlar qovşaqlarda saxlanılan açar və dəyər növləridir.
/// - `Type`: Bu `Leaf`, `Internal` və ya `LeafOrInternal` ola bilər.
/// Bu `Leaf` olduqda, `NodeRef` bir yarpaq nodunu, `Internal` olduqda `NodeRef` daxili nodu göstərir və bu `LeafOrInternal` olduqda `NodeRef` hər hansı bir nod növünü göstərə bilər.
///   `Type` `NodeRef` xaricində istifadə edildikdə `NodeType` adlandırılır.
///
/// Həm `BorrowType`, həm də `NodeType`, statik tip təhlükəsizlikdən istifadə etmək üçün tətbiq etdiyimiz metodları məhdudlaşdırır.Bu cür məhdudiyyətləri tətbiq etmək üçün məhdudiyyətlər var:
/// - Hər növ parametr üçün yalnız ümumi və ya müəyyən bir növ üçün bir metod müəyyən edə bilərik.
/// Məsələn, `into_kv` kimi bir metodu bütün `BorrowType`-lər üçün ümumiyyətlə və ya ömür boyu daşıyan bütün növlər üçün bir dəfə tərif edə bilmərik, çünki `&'a` istinadlarını qaytarmaq istəyirik.
///   Buna görə, onu yalnız ən az güclü `Immut<'a>` tipi üçün təyin edirik.
/// - `Mut<'a>`-dən `Immut<'a>`-ə qədər gizli bir məcburiyyət ala bilmərik.
///   Buna görə `into_kv` kimi bir üsula çatmaq üçün daha güclü bir `NodeRef`-də `reborrow`-i açıq şəkildə çağırmalıyıq.
///
/// `NodeRef`-də bir növ istinad gətirən bütün metodlar:
/// - `self`-i dəyərinə görə götürün və `BorrowType`-in daşıdığı ömrü qaytarın.
///   Bəzən belə bir metodu tətbiq etmək üçün `reborrow_mut`-ə zəng etməliyik.
/// - `self`-i referansla götürün və (implicitly), `BorrowType`-in daşıdığı ömür əvəzinə həmin istinadın ömrünü qaytarın.
/// Bu şəkildə borc yoxlayıcısı, qaytarılmış istinaddan istifadə edildiyi müddətdə `NodeRef`-nin borclu qalmasına zəmanət verir.
///   Əlavəni dəstəkləyən metodlar bu qaydanı xam bir göstəricini, yəni heç bir ömrü olmayan bir referansı geri qaytararaq əyirlər.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Düyün və yarpaq səviyyəsinin ayrı olduğu səviyyə sayı, tamamilə `Type` tərəfindən təsvir edilə bilməyən və düyünün özündə saxlamayan düyünün sabitidir.
    /// Yalnız kök düyününün hündürlüyünü saxlamalıyıq və hər bir düyünün hündürlüyünü ondan əldə etməliyik.
    /// `Type` `Leaf` olarsa sıfır, `Type` `Internal` olarsa sıfır olmamalıdır.
    ///
    ///
    height: usize,
    /// Yarpağa və ya daxili düyünə işarə.
    /// `InternalNode` tərifi göstəricinin hər iki halda da etibarlı olmasını təmin edir.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` olaraq doldurulmuş bir düyün istinadını paketdən çıxarın.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Daxili bir düyünün məlumatlarını açıqlayır.
    ///
    /// Bu node digər istinadları etibarsız saymamaq üçün xam ptr qaytarır.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // TƏHLÜKƏSİZLİK: statik düyün növü `Internal`-dir.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Daxili bir düyünün məlumatlarına müstəsna giriş borc verir.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Düyünün uzunluğunu tapır.Bu düymələrin və ya dəyərlərin sayıdır.
    /// Kənarların sayı `len() + 1`-dir.
    /// Təhlükəsiz olmasına baxmayaraq, bu funksiyanı çağırmağın təhlükəli kodun yaratdığı dəyişdirilə bilən istinadların etibarsız olmasının yan təsiri ola biləcəyini unutmayın.
    ///
    pub fn len(&self) -> usize {
        // Kritik olaraq, burada yalnız `len` sahəsinə daxil oluruq.
        // BorrowType marker::ValMut-dirsə, etibarsız saymamalı olduğumuz dəyərlərə əla dəyişkən istinadlar ola bilər.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Düyün və yarpaqların ayrı olduğu səviyyələrin sayını qaytarır.
    /// Sıfır hündürlük düyünün bir yarpağın özü olduğunu bildirir.
    /// Kökü üstündəki ağacları təsəvvür edirsinizsə, rəqəm düyünün hansı yüksəklikdə göründüyünü göstərir.
    /// Üzərində yarpaqları olan ağacları təsəvvür edirsinizsə, rəqəm ağacın düyünün üstündə nə qədər uzandığını göstərir.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Müvəqqəti olaraq eyni düyünə başqa, dəyişməz bir istinad çıxarır.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hər hansı bir yarpağın və ya daxili düyünün yarpaq hissəsini ortaya qoyur.
    ///
    /// Bu node digər istinadları etibarsız saymamaq üçün xam ptr qaytarır.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Düyün ən azı LeafNode hissəsi üçün etibarlı olmalıdır.
        // Bu NodeRef tipində bir istinad deyil, çünki unikal və ya paylaşılmalı olduğunu bilmirik.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Cari düyünün valideynini tapır.
    /// Cari düyünün həqiqətən bir valideyn varsa `Ok(handle)` qaytarır, burada `handle` cari düyünü göstərən valideynin edge-yə işarə edir.
    ///
    /// Mövcud qovşaqda valideyn yoxdursa, orijinal `NodeRef`-i qaytararaq `Err(self)` qaytarır.
    ///
    /// Metod adı yuxarıda kök düyünü olan ağacları təsvir etdiyinizi düşünür.
    ///
    /// `edge.descend().ascend().unwrap()` və `node.ascend().unwrap().descend()` hər ikisi də müvəffəq olduqdan sonra heç bir şey etməməlidir.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Düyünlər üçün xam göstəricilərdən istifadə etməliyik, çünki BorrowType marker::ValMut olarsa, etibarsız saymamalı olduğumuz dəyərlərə əla dəyişdirilə bilən istinadlar ola bilər.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self`-in boş olmamalı olduğunu unutmayın.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self`-in boş olmamalı olduğunu unutmayın.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Dəyişməz bir ağacdakı hər hansı bir yarpağın və ya daxili düyünün yarpaq hissəsini ortaya qoyur.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // TƏHLÜKƏSİZLİK: `Immut` olaraq götürülmüş bu ağaca dəyişdirilə bilən istinadlar ola bilməz.
        unsafe { &*ptr }
    }

    /// Düyündə saxlanılan düymələrə bir görünüş borc verir.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend`-ə bənzər bir düyünün ana qovşağına istinad alır, həm də prosesdəki cari nodu ayırır.
    /// Bu təhlükəlidir, çünki ayrılmış olmasına baxmayaraq cari qovşaq hələ də əldə edilə bilər.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Təhlükəsiz olaraq bu düyünün `Leaf` olduğu statik məlumatları tərtibçiyə təsdiqləyir.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Təhlükəsiz olaraq bu düyünün `Internal` olduğu statik məlumatları tərtibçiyə təsdiqləyir.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Müvəqqəti olaraq eyni düyünə başqa, dəyişdirilə bilən bir istinad çıxarır.Diqqət edin, bu metod çox təhlükəlidir, çünki dərhal təhlükəli görünə bilməyəcəyi üçün ikiqat.
    ///
    /// Dəyişdirilə bilən göstəricilər ağacın ətrafında hər yerdə gəzə bildiyindən, qaytarılmış göstərici asanlıqla orijinal göstəricini asılmış, sərhədsiz və ya yığılmış borc qaydaları altında etibarsız hala gətirmək üçün istifadə edilə bilər.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef`-ə yenidən gətirilən göstəricilərdə naviqasiya metodlarının istifadəsini məhdudlaşdıran və bu təhlükəsizliyin qarşısını alan başqa bir növ parametr əlavə etməyi düşünün.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hər hansı bir yarpağın və ya daxili düyünün yarpaq hissəsinə müstəsna giriş imkanı verir.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // TƏHLÜKƏSİZLİK: bütün qovşağa xüsusi giriş imkanımız var.
        unsafe { &mut *ptr }
    }

    /// Hər hansı bir yarpağın və ya daxili düyünün yarpaq hissəsinə xüsusi giriş təklif edir.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // TƏHLÜKƏSİZLİK: bütün qovşağa xüsusi giriş imkanımız var.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Açar saxlama sahəsinin bir elementinə müstəsna giriş imkanı verir.
    ///
    /// # Safety
    /// `index` 0 hüdudlarında ... KAPASİTƏ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // TƏHLÜKƏSİZLİK: zəng edən şəxs öz-özünə əlavə metodlara müraciət edə bilməyəcək
        // borc ömrü boyu unikal bir girişə sahib olduğumuz üçün əsas dilim referansı atılana qədər.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Düyünün dəyər saxlama sahəsinin bir elementinə və ya diliminə xüsusi giriş borc verir.
    ///
    /// # Safety
    /// `index` 0 hüdudlarında ... KAPASİTƏ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // TƏHLÜKƏSİZLİK: zəng edən şəxs öz-özünə əlavə metodlara müraciət edə bilməyəcək
        // borc ömrü boyu unikal bir girişə sahib olduğumuz üçün dəyər dilimi referansı düşənə qədər.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge məzmunu üçün qovşaq saxlama sahəsinin bir elementinə və ya diliminə müstəsna giriş imkanı verir.
    ///
    /// # Safety
    /// `index` 0 hüdudlarında ... KAPASİTƏ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // TƏHLÜKƏSİZLİK: zəng edən şəxs öz-özünə əlavə metodlara müraciət edə bilməyəcək
        // borc ömrü boyu unikal erişimimiz olduğu üçün edge dilim referansı atılana qədər.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Düyünün `idx`-dən çox başlanğıc elementi var.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Digər elementlərə, xüsusən də əvvəlki təkrarlamalarda zəng edənə qaytarılanlara əlamətdar istinadlar verməklə qarşısını almaq üçün yalnız maraqlandığımız bir elementə istinad yaradırıq.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust #74679 problemi səbəbi ilə ölçüsüz dizi göstəricilərinə məcbur etməliyik.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Düyünün uzunluğuna xüsusi giriş borc verir.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Düyünün digər istinadlarını etibarsızlaşdırmadan, qovşağın ana edge ilə əlaqəsini qurur.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Kökün ana edge ilə əlaqəsini silir.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Düyünün sonuna bir əsas dəyər cütü əlavə edir.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` tərəfindən qaytarılmış hər bir maddə, düyün üçün etibarlı bir edge indeksidir.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Bir düymə cütü və bu cütün sağ tərəfinə, düyünün sonuna getmək üçün bir edge əlavə edir.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Düyünün `Internal` düyünü və ya `Leaf` düyünü olub olmadığını yoxlayır.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Düyün içərisində müəyyən bir açar dəyər cütünə və ya edge-ə istinad.
/// `Node` parametri bir `NodeRef` olmalıdır, `Type` ya `KV` (bir əsas dəyər cütü üzərində bir qolu işarələyir) ya da `Edge` (bir edge üzərindəki bir qolu işarələyir) ola bilər.
///
/// Qeyd edək ki, `Leaf` qovşaqlarında belə `Edge` tutacaqları ola bilər.
/// Uşaq düyününə bir göstəricini göstərmək əvəzinə, bu, uşaq göstəricilərinin açar dəyər cütləri arasında keçəcəyi boşluqları əks etdirir.
/// Məsələn, uzunluğu 2 olan bir düyündə biri mümkün olan 3 edge yeri olardı, biri düyünün solunda, biri iki cüt arasında, digəri də düyünün sağında.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// `#[derive(Clone)]`-in tam ümumiliyinə ehtiyacımız yoxdur, çünki `Node`-in tək vaxtı Klon olacaq, dəyişməz bir istinad olduğu zaman və buna görə `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Bu işarə etdiyi edge və ya açar dəyər cütü olan nodu alır.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Bu qolun qovşaqdakı vəziyyətini qaytarır.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node`-də bir əsas dəyər cütü üçün yeni bir qol yaradır.
    /// Təhlükəsiz deyil, çünki zəng edən `idx < node.len()` olduğundan əmin olmalıdır.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq-in ümumi tətbiqi ola bilər, ancaq yalnız bu modulda istifadə olunur.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Müvəqqəti olaraq eyni yerdə başqa, dəyişməz bir qolu çıxarır.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Handle::new_kv və ya Handle::new_edge istifadə edə bilmərik, çünki növümüzü bilmirik
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Təhlükəsiz olaraq tərtibçiyə sapın düyününün bir `Leaf` olduğu statik məlumatları təsdiqləyir.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Müvəqqəti olaraq eyni yerdə başqa, dəyişdirilə bilən bir qolu çıxarır.
    /// Diqqət edin, bu metod çox təhlükəlidir, çünki dərhal təhlükəli görünə bilməyəcəyi üçün ikiqat.
    ///
    ///
    /// Ətraflı məlumat üçün `NodeRef::reborrow_mut`-ə baxın.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Handle::new_kv və ya Handle::new_edge istifadə edə bilmərik, çünki növümüzü bilmirik
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node`-də edge üçün yeni bir qol yaradır.
    /// Təhlükəsiz deyil, çünki zəng edən `idx <= node.len()` olduğundan əmin olmalıdır.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Tutumu doldurulmuş bir düyünə daxil etmək istədiyimiz bir edge indeksi nəzərə alınaraq, bölünmə nöqtəsinin həssas bir KV indeksini və yerləşdirmənin harada aparılacağını hesablayır.
///
/// Bölünmüş nöqtənin məqsədi açarının və dəyərinin bir ana qovşaqda qalmasıdır;
/// bölünmə nöqtəsinin solundakı düymələr, dəyərlər və kənarlar sol uşağa çevrilir;
/// bölünmə nöqtəsinin sağındakı düymələr, dəyərlər və kənarlar düzgün uşaq olur.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust məsələsi #74834 bu simmetrik qaydaları izah etməyə çalışır.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bu edge-dən sağa və sola açar dəyər cütləri arasında yeni bir əsas dəyər cütü əlavə edir.
    /// Bu metod, düyündə yeni cütün sığması üçün kifayət qədər yer olduğunu düşünür.
    ///
    /// Qaytarılmış göstərici daxil edilmiş dəyəri göstərir.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bu edge-dən sağa və sola açar dəyər cütləri arasında yeni bir əsas dəyər cütü əlavə edir.
    /// Bu metod kifayət qədər yer olmadığı təqdirdə düyünü bölər.
    ///
    /// Qaytarılmış göstərici daxil edilmiş dəyəri göstərir.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Bu edge-nin əlaqələndirdiyi uşaq düyünündə ana göstəricini və indeksini düzəldir.
    /// Bu, kənarların sırası dəyişdirildikdə faydalıdır,
    fn correct_parent_link(self) {
        // Düyünə digər istinadları etibarsız qoymadan arxa göstərici yaradın.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Bu edge ilə bu edge-nin sağındakı açar dəyər cütü arasında yeni cütün sağına gedəcək yeni bir əsas dəyər cütü və bir edge əlavə edir.
    /// Bu metod, düyündə yeni cütün sığması üçün kifayət qədər yer olduğunu düşünür.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Bu edge ilə bu edge-nin sağındakı açar dəyər cütü arasında yeni cütün sağına gedəcək yeni bir əsas dəyər cütü və bir edge əlavə edir.
    /// Bu metod kifayət qədər yer olmadığı təqdirdə düyünü bölər.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bu edge-dən sağa və sola açar dəyər cütləri arasında yeni bir əsas dəyər cütü əlavə edir.
    /// Bu metod kifayət qədər yer olmadığı təqdirdə düyünü bölər və bölünmüş hissəni kökünə çatana qədər ana düyünə rekursiv şəkildə daxil etməyə çalışır.
    ///
    ///
    /// Döndürülən nəticə bir `Fit` olarsa, sapının düyünü bu edge düyünü və ya əcdadı ola bilər.
    /// Döndürülən nəticə `Split` olarsa, `left` sahəsi kök düyünü olacaqdır.
    /// Qaytarılmış göstərici daxil edilmiş dəyəri göstərir.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Bu edge tərəfindən göstərilən qovluğu tapır.
    ///
    /// Metod adı yuxarıda kök düyünü olan ağacları təsvir etdiyinizi düşünür.
    ///
    /// `edge.descend().ascend().unwrap()` və `node.ascend().unwrap().descend()` hər ikisi də müvəffəq olduqdan sonra heç bir şey etməməlidir.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Düyünlər üçün xam göstəricilərdən istifadə etməliyik, çünki BorrowType marker::ValMut olarsa, etibarsız saymamalı olduğumuz dəyərlərə əla dəyişdirilə bilən istinadlar ola bilər.
        // Hündürlük sahəsinə girişdə narahatlıq yoxdur, çünki bu dəyər kopyalanır.
        // Diqqət yetirin ki, düyün göstəricisindən imtina edildikdən sonra kənar nöqtələrə bir istinadla (Rust buraxılışı #73987) daxil oluruq və massivin içərisindəki digər istinadları etibarsız hesab edirik.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ayrı açar və dəyər metodlarını çağıra bilmərik, çünki ikincisini çağırmaq birincinin qaytardığı referansı etibarsız sayır.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV sapının istinad etdiyi açarı və dəyəri dəyişdirin.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Yarpaq məlumatlarına baxaraq müəyyən bir `NodeType` üçün `split` tətbiqetmələrinə kömək edir.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Əsas düyünü üç hissəyə ayırır:
    ///
    /// - Düyün yalnız bu sapın solundakı açar dəyər cütlərini ehtiva etmək üçün kəsilir.
    /// - Bu sapla göstərilən açar və dəyər çıxarılır.
    /// - Bu qolun sağındakı bütün açar dəyər cütləri yeni ayrılmış bir qovşağa qoyulur.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Bu sapla göstərilən açar dəyər cütünü silir və açar dəyər cütünün çökdüyü edge ilə birlikdə qaytarır.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Əsas düyünü üç hissəyə ayırır:
    ///
    /// - Düyün yalnız bu sapın solundakı kənarları və açar dəyər cütlərini ehtiva etmək üçün kəsilir.
    /// - Bu sapla göstərilən açar və dəyər çıxarılır.
    /// - Bu sapın sağındakı bütün kənar və açar dəyər cütləri yeni ayrılmış bir qovşağa qoyulur.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Daxili bir əsas dəyər cütü ətrafında bir balans əməliyyatı qiymətləndirmək və yerinə yetirmək üçün bir seansı təmsil edir.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Düyünü uşaq olaraq əhatə edən tarazlaşdırma kontekstini seçir, beləliklə KV arasında ana qovşaqda dərhal sola və ya sağa.
    /// Valideyn olmadıqda bir `Err` qaytarır.
    /// Valideyn boşdursa Panics.
    ///
    /// Verilən düyün bir şəkildə azdırsa, sol tərəfi, optimal olmağı üstün tutur, burada yalnız sol bacıdan və əgər mövcuddursa, bacıdan daha az elementə sahib olması deməkdir.
    /// Bu vəziyyətdə, sol qardaşla birləşmək daha sürətli olur, çünki yalnız qovşağın N elementlərini hərəkətə gətirməliyik, əksinə onları sağa çevirmək və öndəki N elementdən çox hərəkət etmək yerinə.
    /// Sol qardaşdan oğurluq da ümumiyyətlə daha sürətli olur, çünki qardaşın elementlərindən ən azı N-i sola dəyişdirmək əvəzinə yalnız qovşağın N elementlərini sağa çəkməliyik.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Birləşmənin mümkün olub olmadığını, yəni mərkəzi KV-ni həm bitişik uşaq düyünləri ilə birləşdirmək üçün bir qovşaqda kifayət qədər yerin olub olmadığını qaytarır.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Birləşdirmə həyata keçirir və bağlanmanın nəyin qaytarılacağına qərar verməsinə imkan verir.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // TƏHLÜKƏSİZLİK: birləşdirilən qovşaqların hündürlüyü hündürlüyün altındadır
                // bu edge-nin nodunun, beləliklə sıfırın üstündə olduğu üçün daxilidirlər.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Valideynin açar dəyər cütünü və hər iki bitişik uşaq qovşağını sol uşaq düyününə birləşdirir və kiçiltilmiş ana düyünü qaytarır.
    ///
    ///
    /// Biz `.can_merge()` olmadıqca Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Valideynin açar dəyər cütünü və hər iki bitişik uşaq qovşağını sol uşaq qovşağına birləşdirir və bu uşaq qovşağını qaytarır.
    ///
    ///
    /// Biz `.can_merge()` olmadıqca Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Valideynin açar dəyər cütünü və hər iki bitişik uşaq qovşağını sol uşaq düyününə birləşdirir və izlənmiş uşağın edge bitdiyi yerdəki uşaq düyünündə edge sapını qaytarır,
    ///
    ///
    /// Biz `.can_merge()` olmadıqca Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Bir əsas dəyər cütünü soldan çıxarır və valideynin əsas dəyər yaddaşına yerləşdirir, eyni zamanda köhnə ana açar dəyər cütünü sağ uşağa itələyir.
    ///
    /// `track_right_edge_idx` tərəfindən göstərilən orijinal edge-nin bitdiyi yerə uyğun sağ uşaqdakı edge-ə bir sapı qaytarır.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Bir əsas dəyər cütünü sağdakı uşaqdan çıxarır və valideynin açar dəyər yaddaşına yerləşdirir, eyni zamanda köhnə ana açar dəyər cütünü sol uşağa basdırır.
    ///
    /// `track_left_edge_idx` tərəfindən göstərilən sol uşağın içərisindəki edge-ə bir sapı qaytarır.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Bu, `steal_left`-ə bənzər bir oğurluq edir, lakin birdən çox elementi oğurlayır.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Təhlükəsiz oğurlaya biləcəyimizə əmin olun.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Yarpaq məlumatlarını köçürün.
            {
                // Doğru uşaqdakı oğurlanmış elementlərə yer ayırın.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Elementləri sol uşaqdan sağa aparın.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Ən çox oğurlanmış cütü valideynə aparın.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Valideynin açar dəyər cütünü doğru uşağa aparın.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Oğurlanmış kənarlara yer ayırın.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Kənarları oğurlayın.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` simmetrik klon.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Təhlükəsiz oğurlaya biləcəyimizə əmin olun.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Yarpaq məlumatlarını köçürün.
            {
                // Ən çox oğurlanmış cütü valideynə aparın.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Valideynin açar dəyər cütünü sol uşağa aparın.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Elementləri sağ uşaqdan sola aparın.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Əvvəllər oğurlanmış elementlərin olduğu boşluğu doldurun.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Kənarları oğurlayın.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Əvvəllər oğurlanmış kənarların olduğu yeri doldurun.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Bu düyünün `Leaf` düyünü olduğunu təsdiqləyən statik məlumatları silir.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Bu düyünün `Internal` düyünü olduğunu təsdiqləyən statik məlumatları silir.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Əsas düyünün `Internal` düyünü və ya `Leaf` düyünü olub olmadığını yoxlayır.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self`-dən sonra şəkilçi bir qovşaqdan digərinə keçir.`right` boş olmalıdır.
    /// `right`-in ilk edge-i dəyişməz olaraq qalır.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Bir qovşaq öz qabiliyyətini aşmaq üçün lazım olduqda yerləşdirmə nəticəsidir.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv`-in soluna aid elementləri və kənarları olan mövcud ağacdakı dəyişdirilmiş node.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Bəzi düymələr və dəyərlər başqa yerə yerləşdirilmək üçün bölünür.
    pub kv: (K, V),
    // `kv`-in sağına aid olan elementləri və kənarları olan sahibsiz, əlavə edilməmiş, yeni bir qovşaq.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Bu borc tipli düyün istinadlarının ağacdakı digər qovşaqlara keçməsinə imkan verib-verməməsi.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal lazım deyil, `borrow_mut` nəticəsini istifadə edərək baş verir.
        // Keçiddən kənarlaşdıraraq və yalnız köklərə yeni istinadlar yaradaraq, `Owned` tipli hər bir istinadın kök düyününə aid olduğunu bilirik.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Başlanğıc elementlərinin bir diliminə bir dəyər əlavə edir, ardından bir başlanğıc edilməmiş element.
///
/// # Safety
/// Dilimdə `idx`-dən çox element var.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Bütün başlanğıc edilmiş elementlərin bir dilimindən bir dəyəri silir və qaytarır, arxada bir başlanğıc edilməmiş element qoyur.
///
///
/// # Safety
/// Dilimdə `idx`-dən çox element var.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Dilimdəki elementləri `distance` mövqelərini sola keçirir.
///
/// # Safety
/// Dilim ən azı `distance` elementə malikdir.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Elementləri bir dilim `distance` mövqeyində sağa keçir.
///
/// # Safety
/// Dilim ən azı `distance` elementə malikdir.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Bütün dəyərləri başlanğıc elementlərinin bir dilimindən başlanğıc olunmamış elementlərin bir diliminə keçir və bütün başlanğıc olunmamış olaraq `src` geridə qoyur.
///
/// `dst.copy_from_slice(src)` kimi işləyir, lakin `T`-in `Copy` olmasını tələb etmir.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;