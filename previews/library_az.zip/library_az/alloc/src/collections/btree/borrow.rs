use core::marker::PhantomData;
use core::ptr::NonNull;

/// Yenidən doğma və onun bütün nəsillərinin (yəni bütün göstəricilərdən və ondan qaynaqlanan istinadların) bir anda artıq istifadə olunmayacağını bildiyiniz zaman bəzi unikal istinadların yenidən doğulmasını modelləşdirir, bundan sonra yenidən orijinal nadir istinaddan istifadə etmək istəyirsiniz. .
///
///
/// Borc yoxlayıcısı ümumiyyətlə sizin üçün borc yığımını idarə edir, lakin bu yığmağı yerinə yetirən bəzi nəzarət axınları tərtibçinin izləməsi üçün çox mürəkkəbdir.
/// `DormantMutRef`, yığılmış təbiətini ifadə edərkən və bunun üçün təyin olunan xammal göstərici kodunu tərifsiz davranış olmadan əhatə edərkən özünüzü borc götürməyinizi yoxlamağa imkan verir.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Bənzərsiz bir borc tutun və dərhal yenidən doğun.
    /// Tərtibçi üçün yeni istinadın ömrü orijinal istinadın ömrü ilə eynidir, ancaq daha qısa müddət ərzində istifadə etməyiniz üçün promise.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // TƏHLÜKƏSİZ: borcları 'a `_marker` vasitəsilə tuturuq və ifşa edirik
        // yalnız bu istinad, buna görə də bənzərsizdir.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Əvvəlcə tutulan unikal borca qayıdın.
    ///
    /// # Safety
    ///
    /// Yenidən doğma bitmiş olmalıdır, yəni `new` tərəfindən qaytarılmış istinad və ondan çıxarılan bütün göstəricilər və istinadlar artıq istifadə edilməməlidir.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // TƏHLÜKƏSİZLİK: öz təhlükəsizlik şərtlərimiz bu istinadın təkrarolunmaz olduğunu göstərir.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;