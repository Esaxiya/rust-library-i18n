use core::intrinsics;
use core::mem;
use core::ptr;

/// Bu, müvafiq funksiyanı çağıraraq `v` unikal istinadının arxasındakı dəyəri əvəz edir.
///
///
/// `change` bağlanmasında bir panic baş verərsə, bütün proses ləğv ediləcəkdir.
#[allow(dead_code)] // illüstrasiya şəklində və future istifadəsi üçün saxlayın
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Bu, müvafiq funksiyanı çağıraraq `v` unikal istinadının arxasındakı dəyəri əvəz edir və yol boyunca əldə edilmiş nəticəni qaytarır.
///
///
/// `change` bağlanmasında bir panic baş verərsə, bütün proses ləğv ediləcəkdir.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}