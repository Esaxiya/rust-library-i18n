use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Bir qardaşla birləşərək və ya oğurlayaraq ehtimal olunan dolğun bir qovşaq saxlayır.
    /// Uğurlu olsa da, ana düyünü kiçiltmək bahasına başa gəlsə, büzülmüş ana düyünü qaytarır.
    /// Düyün boş bir kök olduqda `Err` qaytarır.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ehtimal olunan az dolu bir düyünü ehtiyata qoyur və bu, onun ana düyününün kiçilməsinə səbəb olarsa, ana vərdişini rekursiv olaraq ehtiyatlaşdırır.
    /// Ağacı düzəldirsə `true`, kök düyünü boşaldığına görə edə bilmədiyi halda `false` qaytarır.
    ///
    /// Bu metod, əcdadların girişdə artıq dolmağı və boş bir əcdadla qarşılaşdıqda panics gözləmir.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Üst hissədəki boş səviyyələri götürür, ancaq bütün ağac boş olarsa boş yarpaq saxlayır.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Ağacın sağ hüdudundakı az dolğun qovşaqları birləşdirir və ya birləşdirir.
    /// Kök və ya ən sağ edge olmayan digər qovşaqlarda onsuz da ən azı MIN_LEN element olmalıdır.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` simmetrik klon.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Ağacın sağ sərhədindəki az dolğun qovşaqları yığın.
    /// Kök və ya ən sağ edge olmayan digər qovşaqlar ən çox MIN_LEN elementin oğurlanmasına hazır olmalıdır.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Ən çox sağ uşağın az olduğunu yoxlayın.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Oğurlamalıyıq.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Daha aşağıya gedin.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Doğru uşağın az olduğunu düşünərək sol uşağı ehtiyatla doldurur və övladlarını az dolmadan öz növbəsində birləşdirməyə imkan verən əlavə bir element hazırlayır.
    ///
    /// Sol uşağı qaytarır.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` birləşmə növbəti səviyyədə baş verərsə yenidən tənzimlənməməsi üçün.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Sol uşağın əskik olmadığını düşünərək sağ uşağı ehtiyatla doldurur və övladlarını az dolmadan öz növbəsində birləşdirməyə imkan verən əlavə bir element hazırlayır.
    ///
    /// Doğru uşağın bitdiyi yerə qayıdır.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` birləşmə növbəti səviyyədə baş verərsə yenidən tənzimlənməməsi üçün.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}