use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Yolda bir `length` dəyişənini artıraraq iki artan iteratorun birləşməsindən bütün açar dəyər cütlərini əlavə edir.İkincisi, bir damcı işləyən şəxs çaxnaşma edəndə zəng edən şəxsin sızıntının qarşısını almağı asanlaşdırır.
    ///
    /// Hər iki təkrarlayıcı eyni açarı istehsal edirsə, bu üsul cütü sol iteratordan düşür və cütü sağ iteratordan əlavə edir.
    ///
    /// Ağacın `BTreeMap` üçün olduğu kimi ciddi şəkildə artan bir qaydada bitməsini istəyirsinizsə, hər iki təkrarlayıcı girişdə ağacda olan hər hansı bir düyməni daxil olmaqla, hər biri ağacdakı bütün düymələrdən daha böyük açar sırası ilə istehsal etməlidir.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // `left` və `right`-ni xətti vaxtda sıralanmış bir ardıcıllıqla birləşdirməyə hazırlaşırıq.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Bu vaxt, xətti vaxtda sıralanmış ardıcıllıqla bir ağac qururuq.
        self.bulk_push(iter, length)
    }

    /// Yol boyu `length` dəyişənini artıraraq bütün açar dəyər cütlərini ağacın ucuna itələyir.
    /// İkincisi, təkrarlayıcı çaxnaşma edəndə zəng edənin sızıntının qarşısını almağı asanlaşdırır.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Bütün əsas dəyər cütlərini təkrarlayın, onları lazımi səviyyədə qovşaqlara itələyin.
        for (key, value) in iter {
            // Açar dəyər cütünü cari yarpaq düyününə sıxmağa çalışın.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Yer qalmadı, qalxın və ora itələyin.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Yer boşluğu olan bir qovşaq tapdı, buraya vurun.
                                open_node = parent;
                                break;
                            } else {
                                // Yenidən qalxın.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Üstdəyik, yeni bir kök nodu yaradırıq və oraya basırıq.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Açar dəyər cütü və yeni sağ alt ağacı itələyin.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Yenidən ən sağ yarpağa enin.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Təkrarlayıcı irəliləməyə baxmayaraq, xəritənin əlavə edilmiş elementləri saldığından əmin olmaq üçün hər təkrarlamanı artırın.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// İki sıralanmış ardıcıllığı birinə birləşdirmək üçün bir iterator
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// İki düymə bərabərdirsə, açar dəyər cütünü sağ mənbədən qaytarır.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}