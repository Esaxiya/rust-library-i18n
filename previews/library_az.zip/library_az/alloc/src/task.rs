#![stable(feature = "wake_trait", since = "1.51.0")]
//! Asinxron tapşırıqlarla işləmək üçün növləri və Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Bir icraçıda bir tapşırığın oyanmasının həyata keçirilməsi.
///
/// Bu trait bir [`Waker`] yaratmaq üçün istifadə edilə bilər.
/// İcraçı bu trait-nin tətbiqini müəyyənləşdirə bilər və bundan istifadə edərək icraçıda yerinə yetirilən tapşırıqlara keçmək üçün Waker qura bilər.
///
/// Bu trait, [`RawWaker`] qurmağın yaddaşa təhlükəsiz və erqonomik alternatividir.
/// Bir işi oyandırmaq üçün istifadə olunan məlumatların [`Arc`]-də saxlanıldığı ümumi icraçı dizaynını dəstəkləyir.
/// Bəzi icraçılar (xüsusilə əlaqədar sistemlər üçün) bu API istifadə edə bilmirlər, bu səbəbdən [`RawWaker`] bu sistemlər üçün alternativ olaraq mövcuddur.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Bir future götürən və cari mövzuda tamamlanana qədər işləyən əsas `block_on` funksiyası.
///
/// **Note:** Bu misal doğruluğu sadəliklə dəyişir.
/// Tıxanmaların qarşısını almaq üçün istehsal səviyyəli tətbiqetmələr iç içə çağırışlarla yanaşı `thread::unpark`-ə aralıq zəngləri də idarə etməlidir.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Çağırıldığı zaman cari ipliyi oyadan bir oynatıcı.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Mövcud mövzuda tamamlamaq üçün bir future çalıştırın.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future-ni pinləyin, belə ki anket edilə bilər.
///     let mut fut = Box::pin(fut);
///
///     // future-yə ötürülən yeni bir kontekst yaradın.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future-i başa çatdırmaq üçün çalıştırın.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Bu vəzifəni oyandırın.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Bu işi tapşırığı istehlak etmədən oyadın.
    ///
    /// Bir icraçı, oynatıcı istifadə etmədən daha ucuz bir şəkildə oyanmağın yolunu dəstəkləyirsə, bu metodu ləğv etməlidir.
    /// Varsayılan olaraq, [`Arc`]-i klonlayır və klonda [`wake`] çağırır.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // TƏHLÜKƏSİZLİK: Təhlükəsizdir, çünki raw_waker təhlükəsiz şəkildə qurur
        // Arc-dan bir RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker qurmaq üçün bu xüsusi funksiyadan çox istifadə olunur
// `From<Arc<W>> for Waker`-in təhlükəsizliyinin düzgün trait göndərilməsindən asılı olmamasını təmin etmək üçün bunu `From<Arc<W>> for RawWaker` impl-a daxil edərək, bunun əvəzinə hər iki impls bu funksiyanı birbaşa və açıq şəkildə çağırır.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Klonlamaq üçün qövsün istinad sayını artırın.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Yayı Wake::wake funksiyasına keçirərək dəyərinə görə oyanın
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Referansla oyanın, düşməyin qarşısını almaq üçün stəkanı ManualDrop-a sarın
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Arcın istinad sayını azaldıqda azaldır
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}