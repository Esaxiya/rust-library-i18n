//! Tək yivli istinad sayma göstəriciləri.'Rc' 'Referansdır
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] növü, yığında ayrılmış `T` tipli bir dəyərin paylaşılan mülkiyyətini təmin edir.
//! [`clone`][clone]-i [`Rc`]-ə çağırmaq, yığındakı eyni bölgüyə yeni bir işarə yaradır.
//! Verilmiş bir ayırmaya son [`Rc`] göstəricisi məhv edildikdə, bu bölünmədə saxlanılan dəyər (tez-tez "inner value" olaraq da adlandırılır) da düşər.
//!
//! Rust-də paylaşılan istinadlar, mütənasib olaraq mutasiyaya icazə vermir və [`Rc`] istisna deyil: ümumiyyətlə bir [`Rc`] içərisindəki bir şeyə dəyişkən bir istinad əldə edə bilməzsiniz.
//! Dəyişkənliyə ehtiyacınız varsa, [`Rc`]-in içinə [`Cell`] və ya [`RefCell`] qoyun;bax [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] atom olmayan istinad sayımından istifadə edir.
//! Bu o deməkdir ki, yerüstü xərc çox azdır, lakin [`Rc`] iplər arasında göndərilə bilməz və nəticədə [`Rc`] [`Send`][send] tətbiq etmir.
//! Nəticədə, Rust kompilyatoru *tərtib vaxtı* mövzuları arasında [`Rc`] göndərmədiyinizi yoxlayacaq.
//! Çox yivli, atomik istinad sayılmasına ehtiyacınız varsa, [`sync::Arc`][arc] istifadə edin.
//!
//! [`downgrade`][downgrade] metodu sahib olmayan bir [`Weak`] göstəricisi yaratmaq üçün istifadə edilə bilər.
//! [`Weak`] göstəricisi bir [`Rc`]-ə [`yükseltme '][yükseltme] d ola bilər, lakin bu, ayırmada saxlanılan dəyər artıq düşmüşdürsə [`None`]-yə dönəcəkdir.
//! Başqa sözlə, `Weak` göstəriciləri ayırmanın içindəki dəyəri canlı saxlamır;Bununla birlikdə, ayırmağı (daxili dəyər üçün dəstək mağazası) canlı saxlayırlar.
//!
//! [`Rc`] göstəriciləri arasındakı dövr heç vaxt bölüşdürülməyəcəkdir.
//! Bu səbəbdən, [`Weak`] dövrü qırmaq üçün istifadə olunur.
//! Məsələn, bir ağacın ana qovşaqlarından uşaqlara güclü [`Rc`] göstəriciləri və uşaqlardan valideynlərinə geri dönən [`Weak`] göstəriciləri ola bilər.
//!
//! `Rc<T>` avtomatik olaraq `T`-yə istinad edir ([`Deref`] trait vasitəsilə), beləliklə [`Rc<T>`][`Rc`] tipli bir qiymətdə `T` metodlarına zəng edə bilərsiniz.
//! `T` metodları ilə ad toqquşmalarının qarşısını almaq üçün [`Rc<T>`][`Rc`] metodlarının özü [fully qualified syntax] istifadə adlanan əlaqəli funksiyalardır:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! "Rc<T>traits-nin `Clone` kimi tətbiqetmələrinə tam ixtisaslı sintaksisdən istifadə etmək də adlandırıla bilər.
//! Bəzi insanlar tam ixtisaslı sintaksis istifadə etməyə üstünlük verirlər, bəziləri isə metod-zəng sintaksisindən istifadə etməyə üstünlük verirlər.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metod zəng sintaksis
//! let rc2 = rc.clone();
//! // Tamamilə ixtisaslı sintaksis
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] daxili dəyər onsuz da düşmüş ola biləcəyi üçün `T`-dən avtomatik imtina etmir.
//!
//! # İstinadların klonlaşdırılması
//!
//! Mövcud bir istinad sayılan göstərici ilə eyni bölgüyə yeni bir istinad yaratmaq [`Rc<T>`][`Rc`] və [`Weak<T>`][`Weak`] üçün tətbiq olunan `Clone` trait istifadə edilərək həyata keçirilir.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Aşağıdakı iki sintaksis bərabərdir.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a və b hər ikisi foo ilə eyni yaddaş yerini göstərir.
//! ```
//!
//! `Rc::clone(&from)` sintaksisi ən idiomatikdir, çünki kodun mənasını daha açıq şəkildə ifadə edir.
//! Yuxarıdakı nümunədə, bu sintaksis, bu kodun foo-nun bütün məzmununu kopyalamaqdansa, yeni bir istinad yaratdığını görməyi asanlaşdırır.
//!
//! # Examples
//!
//! Bir sıra Gadget'ların müəyyən bir `Owner`-ə məxsus olduğu bir ssenarini nəzərdən keçirin.
//! Gadget'ımızın `Owner`-lərini göstərməsini istəyirik.Bunu unikal sahibliklə edə bilmərik, çünki eyni `Owner`-ə birdən çox gadget aid ola bilər.
//! [`Rc`] bir çox Gadget arasında bir `Owner` bölüşməyimizə və `Owner`-in hər hansı bir `Gadget` nöqtəsi olduğu müddətdə ayrılmasına imkan verir.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... digər sahələr
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... digər sahələr
//! }
//!
//! fn main() {
//!     // Bir istinad sayılan `Owner` yaradın.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner`-ə aid `Gadget` yaradın.
//!     // `Rc<Owner>`-nin klonlaşdırılması, prosesdəki istinad sayını artıraraq, eyni `Owner` ayırmasına yeni bir göstərici verir.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Yerli `gadget_owner` dəyişənimizi atın.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner`-in düşməsinə baxmayaraq, yenə də Gadget'ların `Owner` adını çap edə bilərik.
//!     // Bunun səbəbi, göstərdiyi `Owner`-i yox, yalnız bir `Rc<Owner>`-i endirdiyimizdir.
//!     // Eyni `Owner` ayırmasına işarə edən digər `Rc<Owner>` olduğu müddətcə canlı olaraq qalacaq.
//!     // Sahə proyeksiyası `gadget1.owner.name` işləyir, çünki `Rc<Owner>` avtomatik olaraq `Owner`-ə istinad edir.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Funksiyanın sonunda `gadget1` və `gadget2` məhv edilir və onlarla birlikdə `Owner`-yə son sayılan istinadlar.
//!     // Gadget Man indi də məhv olur.
//!     //
//! }
//! ```
//!
//! Tələblərimiz dəyişərsə və `Owner`-dən `Gadget`-ə keçə bilməliyiksə, problemlərlə qarşılaşacağıq.
//! `Owner`-dən `Gadget`-ə qədər olan bir [`Rc`] göstəricisi dövrü təqdim edir.
//! Bu o deməkdir ki, onların istinad sayıları heç vaxt 0-a çata bilməz və ayrılma heç vaxt məhv olmayacaqdır:
//! yaddaş sızması.Bu vəziyyətdən keçmək üçün [`Weak`] göstəricilərindən istifadə edə bilərik.
//!
//! Rust, ilk növbədə bu döngəni istehsal etməyi bir qədər çətinləşdirir.Bir-birinə işarə edən iki dəyərlə başa çatmaq üçün onlardan birinin dəyişdirilə bilməsi lazımdır.
//! Bu, çətindir, çünki [`Rc`] yaddaşdakı təhlükəsizliyi yalnız bükdüyü dəyərə ortaq istinadlar verərək tətbiq edir və bunlar birbaşa mutasiyaya imkan vermir.
//! Mutasiya etmək istədiyimiz dəyərin bir hissəsini *daxili dəyişkənlik* təmin edən bir [`RefCell`]-də bağlamalıyıq: paylaşılan bir istinad yolu ilə dəyişkənliyə nail olmaq üçün bir metod.
//! [`RefCell`] iş vaxtında Rust-nin borc alma qaydalarını tətbiq edir.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... digər sahələr
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... digər sahələr
//! }
//!
//! fn main() {
//!     // Bir istinad sayılan `Owner` yaradın.
//!     // Qeyd edək ki, Gadget'ın sahibinin vector-ini bir `RefCell`-in içinə qoyduq ki, paylaşılan bir istinadla mutasiya edə bilək.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Əvvəlki kimi `gadget_owner`-ə aid `Gadget` yaradın.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Gadget'ları `Owner`-lərinə əlavə edin.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamik borc burada bitir.
//!     }
//!
//!     // Gadget'larımızı təkrarlayın, detallarını çap edin.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` bir `Weak<Gadget>`.
//!         // `Weak` göstəriciləri ayırmanın hələ də mövcud olmasına zəmanət vermədiyi üçün, `Option<Rc<Gadget>>` qaytaran `upgrade`-ə zəng etməliyik.
//!         //
//!         //
//!         // Bu vəziyyətdə ayırmanın hələ də mövcud olduğunu bilirik, buna görə X001-i `unwrap` edirik.
//!         // Daha mürəkkəb bir proqramda, `None` nəticəsi üçün zərif bir səhv işlənməsinə ehtiyac ola bilər.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Funksiyanın sonunda `gadget_owner`, `gadget1` və `gadget2` məhv edilir.
//!     // İndi cihazlara güclü bir (`Rc`) göstəricisi olmadığına görə məhv edildi.
//!     // Bu, Gadget Man-a istinad sayını sıfırlayır, beləliklə o da məhv olur.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Bu, dəyişdirilə bilən daxili növlərin başqa cür təhlükəsiz [into|from]_raw()-inə müdaxilə edəcək mümkün sahə yenidən sifarişinə qarşı repr(C)-future-ə qarşı davamlıdır.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Tək yivli bir istinad sayma göstəricisi.'Rc' 'Referansdır
/// Counted'.
///
/// Daha ətraflı məlumat üçün [module-level documentation](./index.html)-ə baxın.
///
/// `Rc`-in xas metodları hamısı əlaqəli funksiyalardır, yəni onları `value.get_mut()` əvəzinə [`Rc::get_mut(&mut value)`][get_mut] adlandırmalısınız.
/// Bu, daxili `T` tipli metodlarla ziddiyyətlərin qarşısını alır.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Bu təhlükəsizlik tamamilə yaxşıdır, çünki bu Rc sağ ikən daxili göstəricinin etibarlı olduğuna zəmanət veririk.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Yeni bir `Rc<T>` qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Bütün güclü göstəricilərə məxsus olan gizli bir zəif göstərici var ki, bu da zəif göstəricinin güclü içəridə saxlanmasına baxmayaraq güclü destruktor işləyərkən heç vaxt ayırmanı azad etməməsini təmin edir.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Özünə zəif bir müraciət edərək yeni bir `Rc<T>` qurur.
    /// Bu funksiya qaytarılmadan əvvəl zəif referansı yüksəltməyə çalışmaq `None` dəyəri ilə nəticələnəcəkdir.
    ///
    /// Lakin zəif istinad sərbəst şəkildə klonlana bilər və daha sonra istifadə üçün saxlanıla bilər.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... daha çox sahə
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Tək bir zəif istinadla daxili hissəni "uninitialized" vəziyyətində qurun.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Zəif göstərici sahibliyindən imtina etməməyimiz vacibdir, əks halda `data_fn` qayıtdıqdan sonra yaddaş azad ola bilər.
        // Həqiqətən sahiblikdən keçmək istəsəydik, özümüz üçün əlavə zəif bir göstərici yarada bilərdik, lakin bu, əks halda lazım olmaya biləcək zəif istinad sayında əlavə yeniləmələrlə nəticələnəcəkdir.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Güclü istinadlar kollektiv olaraq paylaşılan zəif bir referansa sahib olmalıdır, buna görə köhnə zəif istinadımız üçün dağıdıcı işləməyin.
        //
        mem::forget(weak);
        strong
    }

    /// Başlanmamış məzmunu olan yeni bir `Rc` qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yaddaş `0` baytla doldurularaq, başlanğıc olunmamış məzmunu olan yeni bir `Rc` qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yeni `Rc<T>` qurur, ayırma uğursuz olarsa bir səhv qaytarır
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Bütün güclü göstəricilərə məxsus olan gizli bir zəif göstərici var ki, bu da zəif göstəricinin güclü içəridə saxlanmasına baxmayaraq güclü destruktor işləyərkən heç vaxt ayırmanı azad etməməsini təmin edir.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Başlanmamış məzmunu olan yeni bir `Rc` qurur, ayırma uğursuz olarsa bir səhv qaytarır
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Yaddaş `0` baytla doldurularaq ayrılma uğursuz olduqda bir səhv qaytararaq başlanğıc olunmamış məzmunu olan yeni bir `Rc` qurur
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Yeni bir `Pin<Rc<T>>` qurur.
    /// `T` `Unpin` tətbiq etmirsə, `value` yaddaşa sabitlənəcək və köçürülə bilməz.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc`-də tam bir güclü istinad varsa daxili dəyəri qaytarır.
    ///
    /// Əks təqdirdə, bir [`Err`], ötürülən eyni `Rc` ilə qaytarılır.
    ///
    ///
    /// Görkəmli zəif istinadlar olsa belə bu müvəffəq olacaqdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // olan obyekti kopyalayın

                // Zəiflərə güclü sayını azaltmaqla yüksəldə bilməyəcəklərini göstərin və sonra gizli "strong weak" göstəricisini silin, eyni zamanda yalnız saxta Zəifləri hazırlayaraq düşmə məntiqini idarə edin.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Başlanğıcsız məzmunu olan yeni bir istinad sayılan dilim qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Yaddaş `0` baytla doldurularaq, başlanğıc olunmamış məzmunu olan yeni bir istinad sayılan dilim qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>`-ə çevrilir.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-də olduğu kimi, daxili dəyərin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında bunun adlandırılması dərhal təyin olunmayan davranışa səbəb olur.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>`-ə çevrilir.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-də olduğu kimi, daxili dəyərin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında bunun adlandırılması dərhal təyin olunmayan davranışa səbəb olur.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Sarılmış göstəricini geri qaytararaq `Rc`-i istehlak edir.
    ///
    /// Yaddaşın sızmasının qarşısını almaq üçün göstərici [`Rc::from_raw`][from_raw] istifadə edərək yenidən `Rc`-ə çevrilməlidir.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Verilənlərə xam bir göstərici təqdim edir.
    ///
    /// Sayılar heç bir şəkildə təsirlənmir və `Rc` tükənmir.
    /// Göstərici `Rc`-də güclü saymalar olduğu müddət üçün etibarlıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // TƏHLÜKƏSİZLİK: Bu, Deref::deref və ya Rc::inner-dən keçə bilməz, çünki
        // məsələn raw/mut sınanmasını qorumaq üçün bu lazımdır
        // `get_mut` Rc `from_raw` vasitəsilə bərpa edildikdən sonra göstəricidən yaza bilər.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Xam bir göstəricidən `Rc<T>` qurur.
    ///
    /// Xam göstərici əvvəllər [`Rc<U>::into_raw`][into_raw]-ə bir zəng ilə qaytarılmış olmalıdır, burada `U` `T` ilə eyni ölçüyə və hizaya sahib olmalıdır.
    /// `U` `T` olarsa, bu cüzi şəkildə doğrudur.
    /// Qeyd edək ki, `U` `T` deyilsə, eyni ölçü və hizalamaya sahibdirsə, bu, əsasən müxtəlif növ istinadların ötürülməsinə bənzəyir.
    /// Bu halda hansı məhdudiyyətlərin tətbiq olunduğu barədə daha çox məlumat üçün [`mem::transmute`][transmute]-ə baxın.
    ///
    /// `from_raw` istifadəçisi müəyyən bir `T` dəyərinin yalnız bir dəfə düşməsinə əmin olmalıdır.
    ///
    /// Bu funksiya təhlükəlidir, çünki səhv istifadə, geri qaytarılmış `Rc<T>`-ə heç vaxt daxil olmasa belə yaddaşın təhlükəsizliyinə səbəb ola bilər.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Sızıntının qarşısını almaq üçün `Rc`-ə qayıdın.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)`-ə əlavə zənglər yaddaş üçün təhlükəlidir.
    /// }
    ///
    /// // `x` yuxarıdakı əhatə dairəsindən çıxdıqda yaddaş boşaldıldı, buna görə `x_ptr` indi asılır!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Orijinal RcBoxu tapmaq üçün ofsetin tərsinə qayıdın.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Bu ayırmaya yeni bir [`Weak`] göstəricisi yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Asılı bir Zəif yaratmadığımızdan əmin olun
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Bu ayırmaya [`Weak`] göstərici sayını alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Bu ayırmaya güclü (`Rc`) göstəricilərinin sayını alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Bu ayırmaya başqa bir `Rc` və ya [`Weak`] göstəricisi yoxdursa `true` qaytarır.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Eyni bölüşdürmə üçün başqa `Rc` və ya [`Weak`] göstəriciləri olmadığı təqdirdə, verilə bilən `Rc`-ə dəyişdirilə bilən bir referansı qaytarır.
    ///
    ///
    /// Əks təqdirdə [`None`] qaytarır, çünki paylaşılan bir dəyəri dəyişdirmək təhlükəsiz deyil.
    ///
    /// Digər göstəricilər olduqda daxili dəyəri [`clone`][clone] edəcək olan [`make_mut`][make_mut]-ə də baxın.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Verilən `Rc`-ə heç bir yoxlama olmadan dəyişdirilə bilən bir referansı qaytarır.
    ///
    /// Təhlükəsiz və uyğun yoxlamalar aparan [`get_mut`]-ə də baxın.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Eyni bölüşdürmə üçün hər hansı digər `Rc` və ya [`Weak`] göstəriciləri, qaytarılmış borc müddəti üçün ayrılmamalıdır.
    ///
    /// Bu cür göstəricilər yoxdursa, məsələn, `Rc::new`-dən dərhal sonra belədir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" sahələrini əhatə edən bir arayış yaratmamağa * ehtiyatlıyıq, çünki bu istinad saylarına girişlə zidd ola bilər (məs.
        // `Weak` tərəfindən).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Hər iki Rc eyni bölgüyə işarə edərsə ([`ptr::eq`]-ə bənzər bir damarda) `true` qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Verilən `Rc`-ə dəyişkən bir istinad edir.
    ///
    /// Eyni bölüşdürmə üçün digər `Rc` göstəriciləri varsa, `make_mut`, unikal sahibliyi təmin etmək üçün daxili dəyəri yeni bir ayırmaya [`clone`] edəcəkdir.
    /// Buna yaz-klon yazma da deyilir.
    ///
    /// Bu ayırmaya başqa bir `Rc` göstəricisi yoxdursa, bu ayırmaya aid [`Weak`] göstəriciləri ayrılacaqdır.
    ///
    /// Klonlaşdırmaqdansa uğursuz olacaq [`get_mut`]-ə də baxın.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Heç bir şey klonlamayacaq
    /// let mut other_data = Rc::clone(&data);    // Daxili məlumatlar klonlanmayacaq
    /// *Rc::make_mut(&mut data) += 1;        // Daxili məlumatları klonlaşdırır
    /// *Rc::make_mut(&mut data) += 1;        // Heç bir şey klonlamayacaq
    /// *Rc::make_mut(&mut other_data) *= 2;  // Heç bir şey klonlamayacaq
    ///
    /// // İndi `data` və `other_data` fərqli ayırmalara işarə edirlər.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] göstəricilər ayrılacaq:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Veriləri klonlaşdırmalıyam, başqa Rcs var.
            // Klonlanmış dəyəri birbaşa yazmağa imkan vermək üçün əvvəlcədən yaddaş ayırın.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Yalnız məlumatları oğurlaya bilər, yalnız Zəiflər qalır
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Gizli güclü və zəif bir refü çıxarın (burada saxta Zəif bir sənətkarlıq etməyə ehtiyac yoxdur-digər Zəiflərin bizim üçün təmizlənə biləcəyini bilirik)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Bu təhlükəsizlik tamamilə yaxşıdır, çünki qaytarılmış göstəricinin T-yə qaytarılacaq *yeganə* göstəricisinə zəmanət veririk.
        // Bu nöqtədə istinad sayımızın 1 olacağına zəmanət verilir və `Rc<T>`-in özünün `mut` olmasını tələb etdik, bu səbəbdən ayırmaya mümkün olan yeganə istinadı qaytarırıq.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>`-i konkret bir növə endirməyə cəhd edin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Dəyərin təqdim edilmiş tərtibatına sahib olduğu ehtimal olunan ölçüsüz daxili dəyər üçün kifayət qədər boşluq olan bir `RcBox<T>` ayırır.
    ///
    /// `mem_to_rcbox` funksiyası məlumat göstəricisi ilə çağırılır və `RcBox<T>` üçün (potensial yağlı) bir göstəriciyə qayıtmalıdır.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Verilən dəyər düzeni istifadə edərək düzəni hesablayın.
        // Əvvəllər yerleşim `&*(ptr as* const RcBox<T>)` ifadəsi üzərində hesablanmışdı, lakin bu səhv bir istinad yaratdı (bax #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Dəyərin düzəlişinin təmin olunduğu ehtimal olunan ölçüsüz bir daxili dəyər üçün kifayət qədər boşluq olan bir `RcBox<T>` ayırır və ayırma uğursuz olarsa bir səhv qaytarır.
    ///
    ///
    /// `mem_to_rcbox` funksiyası məlumat göstəricisi ilə çağırılır və `RcBox<T>` üçün (potensial yağlı) bir göstəriciyə qayıtmalıdır.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Verilən dəyər düzeni istifadə edərək düzəni hesablayın.
        // Əvvəllər yerleşim `&*(ptr as* const RcBox<T>)` ifadəsi üzərində hesablanmışdı, lakin bu səhv bir istinad yaratdı (bax #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Düzən üçün ayırın.
        let ptr = allocate(layout)?;

        // RcBoxu işə salın
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Ölçüsüz daxili dəyər üçün kifayət qədər boşluq olan bir `RcBox<T>` ayırır
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Verilən dəyəri istifadə edərək `RcBox<T>` üçün ayırın.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Dəyəri bayt şəklində kopyalayın
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Tərkibini tərk etmədən ayırmanı pulsuz edin
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Verilmiş uzunluqda bir `RcBox<[T]>` ayırır.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Elementləri dilimdən yeni ayrılmış Rc <\[T\]> içərisinə kopyalayın
    ///
    /// Təhlükəsiz deyil, çünki zəng edən şəxs ya sahiblik etməlidir, ya da `T: Copy`-i bağlamalıdır
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Müəyyən bir ölçüdə olduğu bilinən bir iteratordan bir `Rc<[T]>` qurur.
    ///
    /// Ölçüsü səhv olmalıdırsa, davranış təyin olunmur.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T elementlərini klonlayarkən Panic qoruyucu.
        // Bir panic olması halında, yeni RcBox-a yazılmış elementlər atılacaq, sonra yaddaş boşaldılacaq.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Birinci elementə göstərici
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Hamısı aydındır.Mühafizəni unutun ki, yeni RcBox'u boşaltmasın.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` üçün istifadə olunan trait ixtisası.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` düşür.
    ///
    /// Bu güclü istinad sayını azaldır.
    /// Güclü istinad sayı sıfıra çatırsa, digər istinadlar (varsa) [`Weak`]-dir, buna görə daxili dəyəri `drop` edirik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Heç bir şey çap etmir
    /// drop(foo2);   // "dropped!" çap edir
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // olan obyekti məhv etmək
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // məzmunu məhv etdiyimizə görə gizli "strong weak" göstəricisini götürün.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` göstəricisinin klonunu yaradır.
    ///
    /// Bu eyni istinad üçün başqa bir göstərici yaradır və güclü istinad sayını artırır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` üçün `Default` dəyəri ilə yeni bir `Rc<T>` yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq`-in bir metodu olmasına baxmayaraq `Eq`-də ixtisaslaşmağa imkan vermək üçün hack.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Bu uzmanlığı burada edirik və `&T`-də daha ümumi bir optimallaşdırma kimi deyil, çünki əks təqdirdə bütün bərabərlik yoxlamalarına bir maliyyət əlavə edəcəkdir.
/// "Rc" lərin klonlaşdırılması yavaş, eyni zamanda bərabərliyi yoxlamaq üçün ağır olan böyük dəyərləri saxlamaq üçün istifadə edildiyini və bu xərcin daha asan ödənilməsinə səbəb olduğunu düşünürük.
///
/// Eyni dəyərə işarə edən iki `Rc` klonunun olması, iki "T" dən daha yüksəkdir.
///
/// Bunu yalnız `T: Eq` bir `PartialEq` olaraq bilərəkdən irəliləməz ola biləcəyi zaman edə bilərik.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// İki "Rc" üçün bərabərlik.
    ///
    /// İki `Rc`, fərqli ölçülərdə saxlanılsa da daxili dəyərləri bərabər olduqda bərabərdir.
    ///
    /// `T` eyni zamanda `Eq` (bərabərliyin refleksivliyini nəzərdə tutur) tətbiq edərsə, eyni bölgüyə işarə edən iki "Rc" həmişə bərabərdir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// İki Rc üçün bərabərsizlik.
    ///
    /// Daxili dəyərlər bərabər deyilsə, iki `Rc` bərabər deyil.
    ///
    /// `T` eyni zamanda `Eq` (bərabərliyin refleksivliyini nəzərdə tutur) tətbiq edərsə, eyni bölgüyə işarə edən iki "Rc" heç vaxt bərabər deyil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// İki "Rc" üçün qismən müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `partial_cmp()` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// İki "Rc" üçün müqayisədən daha azdır.
    ///
    /// İkisi daxili dəyərlərinə görə `<` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// İki Rc üçün 'az və ya bərabər' müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `<=` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// İki Rc üçün müqayisədən daha böyükdür.
    ///
    /// İkisi daxili dəyərlərinə görə `>` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// İki "Rc" üçün 'daha böyük və ya bərabər' müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `>=` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// İki Rc üçün müqayisə.
    ///
    /// İkisi daxili dəyərlərinə görə `cmp()` çağıraraq müqayisə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Bir istinad sayılan dilimi ayırın və "v" maddələrini klonlayaraq doldurun.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Bir istinad sayılmış simli dilim ayırın və içərisinə `v` kopyalayın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Bir istinad sayılmış simli dilim ayırın və içərisinə `v` kopyalayın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Qutulu bir obyekti yeni, istinad sayılan, ayırmaya aparın.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Referans sayılan bir dilimi ayırın və içərisinə "v" maddələrini köçürün.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec-in yaddaşını boşaltmasına icazə verin, lakin tərkibini məhv etməyin
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Hər bir elementi `Iterator`-də götürür və `Rc<[T]>`-ə yığır.
    ///
    /// # Performans xüsusiyyətləri
    ///
    /// ## Ümumi vəziyyət
    ///
    /// Ümumiyyətlə, `Rc<[T]>`-ə toplama əvvəlcə `Vec<T>`-ə toplanmaqla həyata keçirilir.Yəni aşağıdakıları yazarkən:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// bu sanki yazmış kimi davranırıq:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // İlk ayırmalar dəsti burada olur.
    ///     .into(); // `Rc<[T]>` üçün ikinci bir ayırma burada olur.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bu, `Vec<T>`-i qurmaq üçün lazım olan qədər ayıracaq və sonra `Vec<T>`-i `Rc<[T]>`-ə çevirmək üçün bir dəfə ayıracaq.
    ///
    ///
    /// ## Uzunluğu məlum olan təkrarlayıcılar
    ///
    /// `Iterator` cihazınız `TrustedLen` tətbiq etdikdə və tam ölçüdə olduqda, `Rc<[T]>` üçün tək bir ayırma ediləcəkdir.Misal üçün:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Burada yalnız bir ayırma olur.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>`-ə yığmaq üçün istifadə olunan trait ixtisası.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Bu bir `TrustedLen` iterator üçün belədir.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // TƏHLÜKƏSİZLİK: Yineleyicinin dəqiq bir uzunluğuna sahib olduğumuzu təmin etməliyik.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Normal həyata qayıt.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` idarə olunan ayırmaya sahib olmayan bir istinad verən [`Rc`] versiyasıdır.Ayrılmaya `Weak` göstəricisindəki [`upgrade`] çağırılaraq bir [`Seçim ']` <`[` Rc`]`<T>> ".
///
/// Bir `Weak` referansı sahiblik sayılmadığı üçün, ayırmada saxlanılan dəyərin düşməsini maneə törətməyəcək və `Weak` özü hələ də dəyərin mövcudluğuna zəmanət vermir.
/// Beləliklə, ['yükseltme'] d olduqda [`None`]-ni geri qaytara bilər.
/// Bununla birlikdə `Weak` referansının * ayırmanın özünün (arxa mağaza) ayrılmasının qarşısını aldığını unutmayın.
///
/// `Weak` göstəricisi, daxili dəyərinin düşməsinin qarşısını almadan [`Rc`] tərəfindən idarə olunan ayırmaya müvəqqəti istinad etmək üçün faydalıdır.
/// Həm də, [`Rc`] göstəriciləri arasında dairəvi istinadların qarşısını almaq üçün istifadə olunur, çünki qarşılıqlı sahiblik referansları heç vaxt [`Rc`]-in düşməsinə imkan verməyəcəkdir.
/// Məsələn, bir ağacın ana qovşaqlarından uşaqlara güclü [`Rc`] göstəriciləri və uşaqlardan valideynlərinə geri dönən `Weak` göstəriciləri ola bilər.
///
/// `Weak` göstəricisini əldə etməyin tipik yolu [`Rc::downgrade`]-ə zəng etməkdir.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Bu, bu növün ölçüsünü enumlarda optimallaşdırmağa imkan verən bir `NonNull`-dir, lakin mütləq etibarlı bir göstərici deyil.
    //
    // `Weak::new` bunu yığın üzərində yer ayırmağa ehtiyac qalmaması üçün `usize::MAX` olaraq təyin edir.
    // RcBox ən azı 2 hizalamasına sahib olduğu üçün həqiqi bir göstəricinin heç alacağı bir dəyər deyil.
    // Bu yalnız `T: Sized` olduqda mümkündür;ölçüsüz `T` heç vaxt sönmür.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Heç bir yaddaş ayırmadan yeni bir `Weak<T>` qurur.
    /// Qaytarma dəyərində [`upgrade`] çağırmaq həmişə [`None`] verir.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Məlumat sahəsi ilə bağlı heç bir iddia vermədən istinad sayımlarına daxil olmağa imkan verən köməkçi növü.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Bu `Weak<T>` tərəfindən göstərilən `T` obyektinə xam bir göstəricini qaytarır.
    ///
    /// Göstərici yalnız bəzi güclü istinadlar olduqda etibarlıdır.
    /// İşaretçi asma, düzəldilməmiş və ya başqa bir şəkildə [`null`] ola bilər.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Hər ikisi eyni obyekti göstərir
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Buradakı güclülər onu canlı saxlayır, buna görə də obyektə hələ də daxil ola bilərik.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ancaq daha çox deyil.
    /// // weak.as_ptr() edə bilərik, ancaq göstəriciyə daxil olmaq müəyyən olmayan bir davranışa səbəb olardı.
    /// // assert_eq! ("salam", təhlükəli {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Göstərici asılırsa, biz gözətçini birbaşa qaytarırıq.
            // Yük, ən azı RcBox (usize) qədər hizalanmış olduğundan bu, etibarlı bir yük ünvanı ola bilməz.
            ptr as *const T
        } else {
            // TƏHLÜKƏSİZLİK: əgər is_dangling yalnış nəticə verərsə, o zaman göstərici ayrılır.
            // Bu nöqtədə faydalı yük düşə bilər və biz sınanma səviyyəsini qorumalıyıq, buna görə xam göstərici manipulyasiyasından istifadə edin.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>`-i istehlak edir və xam bir göstəriciyə çevirir.
    ///
    /// Bu, zəif göstəricini xam göstəriciyə çevirir, eyni zamanda bir zəif istinadın sahibliyini qoruyur (zəif say bu əməliyyatla dəyişdirilmir).
    /// [`from_raw`] ilə yenidən `Weak<T>`-ə çevrilə bilər.
    ///
    /// [`as_ptr`] ilə göstəricinin hədəfinə eyni məhdudiyyətlər tətbiq olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] tərəfindən əvvəllər yaradılmış xam göstəricini yenidən `Weak<T>`-ə çevirir.
    ///
    /// Bu, güclü bir istinad əldə etmək üçün (daha sonra [`upgrade`]-yə zəng edərək) və ya `Weak<T>`-i salmaqla zəif sayını ayırmaq üçün istifadə edilə bilər.
    ///
    /// Bir zəif referansın sahibliyini tələb edir ([`new`] tərəfindən yaradılmış göstəricilər istisna olmaqla, bunlar heç bir şeyə sahib deyildir; metod hələ də onların üzərində işləyir).
    ///
    /// # Safety
    ///
    /// Göstərici [`into_raw`]-dən qaynaqlanmış və potensial zəif istinadına sahib olmalıdır.
    ///
    /// Buna zəng edərkən güclü saymanın 0 olmasına icazə verilir.
    /// Buna baxmayaraq, bu, hazırda xammal göstəricisi kimi təmsil olunan bir zəif referansın sahibliyini alır (zəif say bu əməliyyatla dəyişdirilmir) və bu səbəbdən əvvəlki [`into_raw`] çağırışı ilə cütləşdirilməlidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Son zəif sayını azaldır.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Giriş göstəricisinin necə əldə edildiyi barədə kontekst üçün Weak::as_ptr-ə baxın.

        let ptr = if is_dangling(ptr as *mut T) {
            // Bu, asılan bir Zəifdir.
            ptr as *mut RcBox<T>
        } else {
            // Əks təqdirdə, göstəriciyə qulaq asmayan bir Zəifdən gəldiyinə zəmanət veririk.
            // TƏHLÜKƏSİZLİK: data_offset zəng etmək təhlükəsizdir, çünki ptr həqiqi (potensial olaraq düşmüş) T-yə istinad edir.
            let offset = unsafe { data_offset(ptr) };
            // Beləliklə, bütün RcBox-u əldə etmək üçün ofseti tərsinə çeviririk.
            // TƏHLÜKƏSİZLİK: göstərici zəifdir, bu ofset təhlükəsizdir.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // TƏHLÜKƏSİZLİK: orijinal Zəif göstəricini bərpa etdik, Zəifləri yarada bilərik.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` göstəricisini [`Rc`]-ə yüksəltmək cəhdləri, müvəffəq olarsa daxili dəyərin düşməsini təxirə salır.
    ///
    ///
    /// Daxili dəyər o vaxtdan bəri düşmüşdürsə [`None`] qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Bütün güclü göstəriciləri məhv edin.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Bu ayırmaya işarə edən güclü (`Rc`) göstəricilərinin sayını alır.
    ///
    /// `self` [`Weak::new`] istifadə edərək yaradılmışdırsa, bu 0 qaytaracaqdır.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Bu ayırmaya işarə edən `Weak` göstərici sayını alır.
    ///
    /// Güclü göstəricilər qalmazsa, bu sıfır olacaqdır.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // gizli zəif ptr çıxart
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// İşaretçi asıldıqda və ayrılmış `RcBox` olmadığı zaman `None` qaytarır (yəni bu `Weak` `Weak::new` tərəfindən yaradıldıqda).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" sahəsini əhatə edən bir referans yaratmamağa * ehtiyatlıyıq, çünki sahə eyni zamanda mutasiya edilə bilər (məsələn, son `Rc` düşərsə, məlumat sahəsi yerində düşəcək).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// İki Zəif eyni ayırmaya ([`ptr::eq`]-ə bənzər) işarə etsə və ya hər ikisi heç bir ayırmaya işarə etmirsə (`Weak::new()`) ilə yaradıldıqları üçün) `true` qaytarır.
    ///
    ///
    /// # Notes
    ///
    /// Bu göstəriciləri müqayisə etdiyindən, `Weak::new()`-nin hər hansı bir ayırmaya işarə etməmələrinə baxmayaraq bir-birlərinə bərabər olacağı deməkdir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ilə müqayisə.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` göstəricisini atır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Heç bir şey çap etmir
    /// drop(foo);        // "dropped!" çap edir
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // zəif say 1-dən başlayır və yalnız bütün güclü göstəricilər yoxa çıxdıqda sıfıra gedəcəkdir.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` göstəricisindən eyni bölgüyə işarə edən bir klon edir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Yeni bir `Weak<T>` qurur, başlanğıc etmədən `T` üçün yaddaş ayırır.
    /// Qaytarma dəyərində [`upgrade`] çağırmaq həmişə [`None`] verir.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget ilə etibarlı bir şəkildə məşğul olmaq üçün buraya daxil olduq.Xüsusilə
// mem::forget Rcs (və ya Zəif) varsa, ref-count aça bilər və sonra görkəmli Rcs (və ya Zəif) mövcud olarkən ayırmanı azad edə bilərsiniz.
//
// Abortu dayandırırıq, çünki bu o qədər degenerativ bir ssenaridir ki, nə olacağına baxmırıq-heç bir real proqram bunu yaşamamalıdır.
//
// Bunun əhəmiyyətsiz xərcləri olmalıdır, çünki sahiblik və hərəkət semantikası sayəsində Rust-də bu qədər klonlaşdırmağa ehtiyac yoxdur.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Dəyəri salmaq əvəzinə daşqını dayandırmaq istəyirik.
        // Bu çağırıldıqda istinad sayı heç vaxt sıfır olmaz;
        // buna baxmayaraq LLVM-yə başqa bir şəkildə buraxılmış bir optimallaşdırmaya işarə etmək üçün bir abort edirik.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Dəyəri salmaq əvəzinə daşqını dayandırmaq istəyirik.
        // Bu çağırıldıqda istinad sayı heç vaxt sıfır olmaz;
        // buna baxmayaraq LLVM-yə başqa bir şəkildə buraxılmış bir optimallaşdırmaya işarə etmək üçün bir abort edirik.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Bir göstəricinin arxasındakı faydalı yük üçün `RcBox`-də ofset alın.
///
/// # Safety
///
/// Göstərici əvvəlcədən etibarlı olan T nümunəsinə işarə etməlidir (və bunun üçün etibarlı metadata sahib olmalıdır), lakin T-nin atılmasına icazə verilir.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ölçüsüz dəyəri RcBox sonuna düzəldin.
    // RcBox repr(C) olduğundan, yaddaşdakı həmişə son sahə olacaqdır.
    // TƏHLÜKƏSİZLİK: yalnız ölçüsüz növlər dilimlər olduğundan, trait obyektləri,
    // və xarici növlər, giriş təhlükəsizliyi tələbi hazırda align_of_val_raw tələblərini ödəmək üçün kifayətdir;bu dilin std xaricində etibar edilə bilməyəcək bir tətbiq detalıdır.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}