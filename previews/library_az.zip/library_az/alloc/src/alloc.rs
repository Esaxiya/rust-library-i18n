//! Yaddaş ayırma API'ləri

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Bunlar qlobal ayırıcıya zəng etmək üçün sehrli simvollardır.rustc onları `__rg_alloc` və s. Zəng etmək üçün yaradır.
    // bir `#[global_allocator]` atributu varsa (bu xüsusiyyət makrosunu genişləndirən kod bu funksiyaları yaradır) və ya libstd (`__rdl_alloc` və s.
    //
    // `library/std/src/alloc.rs`-də) əks halda.
    // LLVM-nin rustc fork-si də bu funksiya adlarını `malloc`, `realloc` və `free` kimi optimallaşdırmaq üçün xüsusi hallar verir.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Qlobal yaddaş ayırıcısı.
///
/// Bu tip [`Allocator`] trait varsa, `#[global_allocator]` atributu ilə qeydiyyatdan keçmiş ayırıcıya və ya `std` crate-nin varsayılan zənglərini yönləndirərək həyata keçirir.
///
///
/// Note: bu tip qeyri-sabit olsa da, təmin etdiyi funksionallığa [free functions in `alloc`](self#functions) vasitəsilə çatmaq olar.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Qlobal ayırıcı ilə yaddaş ayırın.
///
/// Bu funksiya, əgər varsa, `#[global_allocator]` atributu ilə qeydiyyatdan keçmiş ayırıcının [`GlobalAlloc::alloc`] metoduna və ya `std` crate çağırışlarına yönəldir.
///
///
/// Bu funksiyanın və [`Allocator`] trait sabit olduqda, [`Global`] tipli `alloc` metodunun lehinə köhnəlməsi gözlənilir.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`]-ə baxın.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Qlobal ayırıcı ilə yaddaş ayırın.
///
/// Bu funksiya, əgər varsa, `#[global_allocator]` atributu ilə qeydiyyatdan keçmiş ayırıcının [`GlobalAlloc::dealloc`] metoduna və ya `std` crate çağırışlarına yönəldir.
///
///
/// Bu funksiyanın və [`Allocator`] trait sabit olduqda, [`Global`] tipli `dealloc` metodunun lehinə köhnəlməsi gözlənilir.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`]-ə baxın.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Qlobal ayırıcı ilə yaddaşı yenidən bölüşdürün.
///
/// Bu funksiya, əgər varsa, `#[global_allocator]` atributu ilə qeydiyyatdan keçmiş ayırıcının [`GlobalAlloc::realloc`] metoduna və ya `std` crate çağırışlarına yönəldir.
///
///
/// Bu funksiyanın və [`Allocator`] trait sabit olduqda, [`Global`] tipli `realloc` metodunun lehinə köhnəlməsi gözlənilir.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`]-ə baxın.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Sıfır başlanğıc yaddaşını qlobal ayırıcı ilə ayırın.
///
/// Bu funksiya, əgər varsa, `#[global_allocator]` atributu ilə qeydiyyatdan keçmiş ayırıcının [`GlobalAlloc::alloc_zeroed`] metoduna və ya `std` crate çağırışlarına yönəldir.
///
///
/// Bu funksiyanın və [`Allocator`] trait sabit olduqda, [`Global`] tipli `alloc_zeroed` metodunun lehinə köhnəlməsi gözlənilir.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`]-ə baxın.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // TƏHLÜKƏSİZLİK: `layout` ölçüsü sıfır deyil,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // TƏHLÜKƏSİZLİK: `Allocator::grow` ilə eyni
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // TƏHLÜKƏSİZLİK: `new_size` sıfır deyil, çünki `old_size` `new_size`-dən böyük və ya bərabərdir
            // təhlükəsizlik şərtlərinin tələb etdiyi kimi.Digər şərtlər zəng edən tərəfindən təmin edilməlidir
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` yəqin ki, `new_size >= old_layout.size()` və ya oxşar bir şey yoxlayır.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // TƏHLÜKƏSİZLİK: `new_layout.size()` `old_size`-dən böyük və ya bərabər olmalıdır,
            // həm köhnə, həm də yeni yaddaş ayırması `old_size` bayt üçün oxumaq və yazmaq üçün etibarlıdır.
            // Ayrıca, köhnə ayırma hələ ayrılmadığından, `new_ptr` ilə üst-üstə düşə bilməz.
            // Beləliklə, `copy_nonoverlapping`-ə zəng təhlükəsizdir.
            // `dealloc` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən dəstəklənməlidir.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // TƏHLÜKƏSİZLİK: `layout` ölçüsü sıfır deyil,
            // digər şərtlər zəng edən tərəfindən təmin edilməlidir
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TƏHLÜKƏSİZLİK: bütün şərtlər zəng edən tərəfindən təmin edilməlidir
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TƏHLÜKƏSİZLİK: bütün şərtlər zəng edən tərəfindən təmin edilməlidir
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // TƏHLÜKƏSİZLİK: şərtlər zəng edən tərəfindən təmin edilməlidir
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // TƏHLÜKƏSİZLİK: `new_size` sıfır deyil.Digər şərtlər zəng edən tərəfindən təmin edilməlidir
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` yəqin ki, `new_size <= old_layout.size()` və ya oxşar bir şey yoxlayır.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // TƏHLÜKƏSİZLİK: `new_size` `old_layout.size()`-dən kiçik və ya ona bərabər olmalıdır,
            // həm köhnə, həm də yeni yaddaş ayırması `new_size` bayt üçün oxumaq və yazmaq üçün etibarlıdır.
            // Ayrıca, köhnə ayırma hələ ayrılmadığından, `new_ptr` ilə üst-üstə düşə bilməz.
            // Beləliklə, `copy_nonoverlapping`-ə zəng təhlükəsizdir.
            // `dealloc` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən dəstəklənməlidir.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Unikal göstəricilər üçün ayırıcı.
// Bu funksiya açılmamalıdır.Bunu edərsə, MIR kodlaşdırıcısı uğursuz olacaq.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Bu imza `Box` ilə eyni olmalıdır, əks halda bir ICE meydana gələcək.
// `Box`-ə əlavə bir parametr əlavə edildikdə (`A: Allocator` kimi), buraya da əlavə edilməlidir.
// Məsələn, `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`-ə dəyişdirilirsə, bu funksiya `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`-ə də dəyişdirilməlidir.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Ayrılma xətası işləyicisi

extern "Rust" {
    // Bu, qlobal ayırma xətası işləyicisini çağırmaq üçün sehrli simvoldur.
    // rustc, bir `#[alloc_error_handler]` varsa `__rg_oom` i çağırmağı və ya əks halda (`__rdl_oom`) altındakı standart tətbiqləri çağırmağı əmələ gətirir.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Yaddaş ayırma xətası və ya uğursuzluqdan imtina edin
///
/// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən yaddaş ayırma API-lərini axtaranlar birbaşa `panic!` və ya buna bənzərləri çağırmaq əvəzinə bu funksiyanı çağırmaları tövsiyə olunur.
///
///
/// Bu funksiyanın standart davranışı standart bir səhv mesajı yazdırmaq və prosesi ləğv etməkdir.
/// [`set_alloc_error_hook`] və [`take_alloc_error_hook`] ilə əvəz edilə bilər.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Ayrılma testi üçün `std::alloc::handle_alloc_error` birbaşa istifadə edilə bilər.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // yaradılan `__rust_alloc_error_handler` vasitəsilə çağırılır

    // `#[alloc_error_handler]` yoxdursa
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // bir `#[alloc_error_handler]` varsa
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Klonları əvvəlcədən ayrılmış, başlanğıc olunmamış yaddaşa ixtisaslaşdırın.
/// `Box::clone` və `Rc`/`Arc::make_mut` tərəfindən istifadə olunur.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *Əvvəl* ayırmaq, optimallaşdırıcıya lokal atlayaraq hərəkət etmək üçün yerində klonlanmış dəyər yaratmağa imkan verə bilər.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Həmişə yerli bir dəyər daxil etmədən hər zaman yerində kopyalaya bilərik.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}