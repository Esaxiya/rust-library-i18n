//! Prelude ayırın
//!
//! Bu modulun məqsədi, modulların üstünə bir glob idxal əlavə edərək `alloc` crate-nin çox istifadə olunan əşyalarının idxalını azaltmaqdır:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;