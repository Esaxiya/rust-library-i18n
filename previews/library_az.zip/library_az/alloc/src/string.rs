//! UTF-8 kodlu, böyüyə bilən bir simli.
//!
//! Bu modulda [`String`] tipi, simlərə çevrilmək üçün [`ToString`] trait və [`String`] lərlə işləməklə nəticələnə biləcək bir neçə səhv növü var.
//!
//!
//! # Examples
//!
//! Simli bir simvoldan yeni bir [`String`] yaratmağın bir çox yolu var:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! İlə birləşərək mövcud birindən yeni bir [`String`] yarada bilərsiniz
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Bir vector etibarlı UTF-8 bayt varsa, ondan bir [`String`] edə bilərsiniz.Bunun əksini də edə bilərsiniz.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Bu baytların etibarlı olduğunu bildiyimiz üçün `unwrap()` istifadə edəcəyik.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8 kodlu, böyüyə bilən bir simli.
///
/// `String` növü, sətrin məzmunu üzərində mülkiyyətə sahib olan ən çox yayılmış sətir növüdür.Borc götürdüyü həmkarı ibtidai [`str`] ilə yaxın bir əlaqəsi var.
///
/// # Examples
///
/// [`String::from`] ilə [a literal string][`str`]-dən `String` yarada bilərsiniz:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// [`push`] metodu ilə `String`-ə bir [`char`] əlavə edə və [`push_str`] üsulu ilə [`&str`] əlavə edə bilərsiniz:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// UTF-8 baytlıq vector varsa, [`from_utf8`] metodu ilə ondan `String` yarada bilərsiniz:
///
/// ```
/// // bəzi baytlar, bir vector-də
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Bu baytların etibarlı olduğunu bildiyimiz üçün `unwrap()` istifadə edəcəyik.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// String hər zaman etibarlıdır UTF-8.Bunun bir neçə təsiri var, bunlardan birincisi, UTF-8 olmayan bir sətirə ehtiyacınız varsa, [`OsString`] hesab edin.Bənzərdir, lakin UTF-8 məhdudiyyəti olmadan.İkinci nəticə, `String`-ə indeksləşdirə bilməməyinizdir:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// İndeksləşdirmə daimi işləmə məqsədi daşıyır, lakin UTF-8 kodlaşdırması buna imkan vermir.Bundan əlavə, indeksin hansı bir şeyi qaytarması lazım olduğu aydın deyil: bir bayt, bir kod nöqtəsi və ya bir qrafik qrupu.
/// [`bytes`] və [`chars`] metodları, sırasıyla ilk ikisində təkrarlayıcıları qaytarır.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s [`Deref`] '' tətbiq edir<Target=str>və buna görə [[str`] 'in bütün metodlarını miras alaq.Bundan əlavə, bu, (`&`) işarəsini istifadə edərək [`&str`] alan bir funksiyaya bir `String` ötürə biləcəyiniz deməkdir:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Bu, `String`-dən bir [`&str`] yaradacaq və onu ötürəcəkdir. Bu dönüşüm çox ucuzdur və ümumiyyətlə funksiyalar, müəyyən bir səbəbdən `String`-ə ehtiyacları olmadığı təqdirdə ['&str`]' i arqument kimi qəbul edəcəkdir.
///
/// Bəzi hallarda Rust, [`Deref`] məcburetmə olaraq bilinən bu dönüşümü etmək üçün kifayət qədər məlumata sahib deyil.Aşağıdakı nümunədə [`&'a str`][`&str`] simli dilim trait `TraitExample`-i tətbiq edir və `example_func` funksiyası trait-i tətbiq edən hər şeyi alır.
/// Bu vəziyyətdə Rust-nin Rust-nin etmək imkanı olmayan iki gizli dönüşüm etməsi lazımdır.
/// Bu səbəbdən aşağıdakı nümunə tərtib olunmayacaq.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Bunun əvəzinə işləyən iki seçim var.Birincisi, simli ehtiva edən sətir dilimini açıq şəkildə çıxarmaq üçün [`as_str()`] metodundan istifadə edərək `example_func(&example_string);` xəttini `example_func(example_string.as_str());`-ə dəyişdirmək olar.
/// İkinci yol `example_func(&example_string);`-i `example_func(&*example_string);`-ə dəyişdirir.
/// Bu vəziyyətdə bir `String` yi bir [`str`][`&str`] ye ayırır, sonra [`str`][`&str`] i [`&str`] ye geri döndürürük.
/// İkinci yol daha idiomatikdir, lakin hər ikisi də konversiyanı gizli örtüklərə etibar etmək əvəzinə açıq şəkildə etmək üçün çalışırlar.
///
/// # Representation
///
/// `String` üç komponentdən ibarətdir: bəzi baytlara işarə, uzunluq və tutum.Göstərici, məlumatlarını saxlamaq üçün istifadə etdiyi daxili `String` buferinə işarə edir.Uzunluq, buferdə hazırda saxlanılan bayt sayıdır və tutum buferin bayt ölçüsündədir.
///
/// Beləliklə, uzunluq həmişə tutumdan az və ya bərabər olacaqdır.
///
/// Bu tampon həmişə yığında saxlanılır.
///
/// Bunlara [`as_ptr`], [`len`] və [`capacity`] metodları ilə baxa bilərsiniz:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts sabitləşdikdə bunu yeniləyin.
/// // String məlumatlarının avtomatik olaraq düşməsinin qarşısını alın
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // hekayənin on doqquz baytı var
/// assert_eq!(19, len);
///
/// // Ptr, len və tutumdan bir String yenidən qura bilərik.
/// // Komponentlərin etibarlı olduğundan əmin olmaqdan məsul olduğumuz üçün hamısı təhlükəlidir.
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// `String`-in kifayət qədər tutumu varsa, ona elementlər əlavə edilməyəcəkdir.Məsələn, bu proqramı nəzərdən keçirin:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Bu aşağıdakıları verəcəkdir:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Əvvəlcə ümumiyyətlə ayrılmış bir yaddaşımız yoxdur, ancaq simli əlavə etdikdə tutumu uyğun şəkildə artırır.Əvvəlcə düzgün tutumu ayırmaq üçün [`with_capacity`] metodundan istifadə etsək:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Sonda fərqli bir nəticə əldə edirik:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Budur, loop içərisində daha çox yaddaş ayırmağa ehtiyac yoxdur.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// `String`-i UTF-8 bayt vector-dən çevirərkən mümkün bir səhv dəyəri.
///
/// Bu tip, [`String`]-də [`from_utf8`] metodu üçün səhv növüdür.
/// Yenidən bölgülərin qarşısını almaq üçün belə bir şəkildə hazırlanmışdır: [`into_bytes`] üsulu, dönüşüm cəhdində istifadə olunan vector baytını geri qaytaracaqdır.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] tərəfindən təmin edilən [`Utf8Error`] tipi, bir dilim [`u8 '] nin [`&str`]-ə çevrilməsi zamanı yarana biləcək bir səhvdir.
/// Bu mənada `FromUtf8Error`-in analoqudur və `FromUtf8Error`-dən [`utf8_error`] metodu ilə əldə edə bilərsiniz.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// // bəzi etibarsız baytlar, bir vector-də
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// `String`-i UTF-16 bayt dilimindən çevirərkən mümkün bir səhv dəyəri.
///
/// Bu tip, [`String`]-də [`from_utf16`] metodu üçün səhv növüdür.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Yeni boş bir `String` yaradır.
    ///
    /// `String`-in boş olduğunu nəzərə alsaq, bu heç bir ilkin tampon ayırmayacaqdır.Bu ilk əməliyyatın çox ucuz olduğu mənasına gəlsə də, daha sonra məlumat əlavə etdikdə həddindən artıq ayrılmasına səbəb ola bilər.
    ///
    /// `String`-in nə qədər məlumat saxlayacağına dair bir fikriniz varsa, həddindən artıq təkrar ayrılmanın qarşısını almaq üçün [`with_capacity`] metodunu nəzərdən keçirin.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Müəyyən bir tutuma sahib yeni boş bir `String` yaradır.
    ///
    /// `String`s məlumatlarını saxlamaq üçün daxili buferə malikdir.
    /// Tutum bu tamponun uzunluğudur və [`capacity`] metodu ilə sorğu edilə bilər.
    /// Bu metod boş bir `String` yaradır, lakin `capacity` bayt tuta bilən ilkin buferə sahibdir.
    /// Bu, `String`-ə bir dəstə məlumat əlavə edərkən yerinə yetirməli olduğu yenidən ayırma sayını azaltdığınız zaman faydalıdır.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Verilən tutum `0` olarsa, heç bir bölgü baş verməz və bu metod [`new`] üsulu ilə eynidir.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String, daha çox qabiliyyətə sahib olmasına baxmayaraq heç bir boşluq içermir
    /// assert_eq!(s.len(), 0);
    ///
    /// // Bunların hamısı yenidən bölünmədən edilir ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ancaq bu sətri yenidən bölüşdürə bilər
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) ilə bu metod tərifi üçün tələb olunan x01X metodu mövcud deyil.
    // Bu üsulu test məqsədləri üçün tələb etmədiyimiz üçün daha çox məlumat üçün XB-yə slice::hack moduluna baxın.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Bir vector baytını `String`-ə çevirir.
    ///
    /// ([`String`]) simli ([`u8`]) baytlarından, ([`Vec<u8>`]) baytlarından bir vector baytdan hazırlandığından bu funksiya ikisi arasında çevrilir.
    /// Bütün bayt dilimləri `String`s etibarlı deyil, lakin: `String` bunun UTF-8 etibarlı olmasını tələb edir.
    /// `from_utf8()` baytların UTF-8-nin etibarlı olmasını yoxlayır və sonra çevirmə edir.
    ///
    /// Bayt diliminin UTF-8-nin etibarlı olduğuna əminsəniz və etibarlılıq yoxlanışının yuxarı xərclərini çəkmək istəmirsinizsə, bu funksiyanın eyni davranışa sahib olan, lakin çeki atlayan təhlükəli bir versiyası [`from_utf8_unchecked`] var.
    ///
    ///
    /// Bu metod səmərəliliyi naminə vector-ni kopyalamamağa diqqət yetirəcəkdir.
    ///
    /// Bir `String` əvəzinə bir [`&str`] ehtiyacınız varsa, [`str::from_utf8`] düşünün.
    ///
    /// Bu metodun tərsi [`into_bytes`]-dir.
    ///
    /// # Errors
    ///
    /// Dilim UTF-8 deyilsə, verilən baytların UTF-8 olmadığına dair bir açıqlama ilə [`Err`] qaytarır.Köçürdüyünüz vector da daxildir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // bəzi baytlar, bir vector-də
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Bu baytların etibarlı olduğunu bildiyimiz üçün `unwrap()` istifadə edəcəyik.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Yanlış baytlar:
    ///
    /// ```
    /// // bəzi etibarsız baytlar, bir vector-də
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Bu səhvlə nə edə biləcəyiniz barədə daha ətraflı məlumat üçün [`FromUtf8Error`] sənədlərinə baxın.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Yanlış simvollar daxil olmaqla bir dilim baytı sətrə çevirir.
    ///
    /// Sıralar ([`u8`]) baytlardan, ([`&[u8]`][byteslice]) baytlardan bir dilim baytlardan hazırlandığından bu funksiya ikisi arasında çevrilir.Bütün bayt dilimləri etibarlı sətir deyildir, lakin UTF-8-nin etibarlı olması üçün sətirlər tələb olunur.
    /// Bu dönüşüm zamanı `from_utf8_lossy()` hər hansı bir etibarsız UTF-8 ardıcıllığını [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ilə əvəz edəcək, belə görünür:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Bayt diliminin UTF-8-nin etibarlı olduğuna əminsəniz və dönüşümün üst-üstə düşməsini istəmirsinizsə, bu funksiyanın [`from_utf8_unchecked`]-in eyni davranışa sahib olan, lakin çekləri atlayan təhlükəli bir versiyası var.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Bu funksiya bir [`Cow<'a, str>`] qaytarır.Bayt dilimimiz UTF-8 etibarsızdırsa, simlin ölçüsünü dəyişdirəcək və buna görə `String` tələb edəcək əvəzedici simvollar əlavə etməliyik.
    /// Ancaq onsuz da etibarlı bir UTF-8 varsa, yeni bir ayırmaya ehtiyacımız yoxdur.
    /// Bu qayıtma növü hər iki işi də idarə etməyə imkan verir.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // bəzi baytlar, bir vector-də
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Yanlış baytlar:
    ///
    /// ```
    /// // bəzi etibarsız baytlar
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Bir UTF-16 kodlu vector `v` kodunu `String`-ə kodlayın, `v`-də hər hansı bir etibarsız məlumat varsa [`Err`]-i qaytarın.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Bu toplama yolu ilə edilmir: : <Result<_, _>> () performans səbəblərinə görə.
        // FIXME: #48994 bağlandıqda funksiya yenidən sadələşdirilə bilər.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// UTF-16 kodlu `v` dilimini `String` halına gətirin, etibarsız məlumatları [the replacement character (`U+FFFD`)][U+FFFD] ilə əvəzləyin.
    ///
    /// [`Cow<'a, str>`] qaytaran [`from_utf8_lossy`]-dən fərqli olaraq, `from_utf16_lossy` `String` verir, çünki UTF-16-dən UTF-8-ə çevrilmə yaddaş ayırma tələb edir.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String`-ni xam komponentlərinə ayırır.
    ///
    /// Xam göstəricini əsas məlumatlara, sətrin uzunluğuna (baytla) və verilənlərin ayrılmış tutumuna (baytla) qaytarır.
    /// Bunlar [`from_raw_parts`] arqumentləri ilə eyni qaydada eyni arqumentlərdir.
    ///
    /// Bu funksiyanı axtardıqdan sonra zəng edən `String` tərəfindən əvvəllər idarə olunan yaddaşdan məsuldur.
    /// Bunun yeganə yolu, xam göstəricini, uzunluğu və tutumu [`from_raw_parts`] funksiyası ilə yenidən `String`-ə çevirmək və destruktorun təmizləməsini həyata keçirməkdir.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Uzunluq, tutum və göstəricidən yeni bir `String` yaradır.
    ///
    /// # Safety
    ///
    /// Yoxlanmayan dəyişənlərin sayına görə bu olduqca təhlükəlidir:
    ///
    /// * `buf`-dəki yaddaşın əvvəllər standart kitabxananın istifadə etdiyi eyni ayırıcı tərəfindən dəqiq 1-ə uyğun hizalanması ilə ayrılması lazımdır.
    /// * `length` `capacity`-dən az və ya bərabər olmalıdır.
    /// * `capacity` doğru dəyər olmalıdır.
    /// * `buf`-də ilk `length` baytlarının UTF-8 etibarlı olması lazımdır.
    ///
    /// Bunların pozulması, ayırıcının daxili məlumat strukturlarını pozmaq kimi problemlərə səbəb ola bilər.
    ///
    /// `buf`-nin mülkiyyəti, effektiv olaraq `String`-ə ötürülür ki, bu da göstəricinin istədiyi kimi göstərilən yaddaşın məzmununu bölüşdürə, yenidən bölüşə və ya dəyişdirə bilər.
    /// Bu funksiyanı çağırdıqdan sonra göstəricidən başqa heç bir şey istifadə etməməsinə əmin olun.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts sabitləşdikdə bunu yeniləyin.
    ///     // String məlumatlarının avtomatik olaraq düşməsinin qarşısını alın
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// vector baytını sətrin etibarlı UTF-8 olduğunu yoxlamadan `String`-ə çevirir.
    ///
    /// Daha ətraflı məlumat üçün təhlükəsiz versiyaya, [`from_utf8`] baxın.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki ona ötürülən baytların UTF-8 etibarlı olduğunu yoxlamır.
    /// Bu məhdudiyyət pozulursa, `String`-in future istifadəçiləri ilə yaddaş təhlükəsizliyi problemlərinə səbəb ola bilər, çünki standart kitabxananın qalan hissəsi `String`-lərin UTF-8 etibarlı olduğunu düşünür.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // bəzi baytlar, bir vector-də
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String`-i bir vector baytına çevirir.
    ///
    /// Bu, `String`-i istehlak edir, buna görə içindəkiləri kopyalamağımıza ehtiyac yoxdur.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Bütün `String`-i ehtiva edən bir simli dilimi çıxarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String`-i dəyişdirilə bilən simli dilimə çevirir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Verilən bir simli dilimi bu `String`-in sonuna əlavə edir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Bu `String` tutumunu baytda qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Bu `String`in tutumunun uzunluğundan ən az `additional` bayt daha böyük olmasını təmin edir.
    ///
    /// İstədiyi təqdirdə, tez-tez yenidən bölüşmələrin qarşısını almaq üçün tutumu `additional` baytdan çox artırıla bilər.
    ///
    ///
    /// Bu "at least" davranışını istəmirsinizsə, [`reserve_exact`] metoduna baxın.
    ///
    /// # Panics
    ///
    /// Panics, yeni tutum [`usize`]-i aşarsa.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Bu faktiki olaraq tutumu artıra bilməz:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s-nin uzunluğu 2, tutumu 10-dur
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Artıq əlavə 8 gücümüz olduğundan, bunu ...
    /// s.reserve(8);
    ///
    /// // ... əslində artmır.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Bu `String`in tutumunun uzunluğundan `additional` bayt daha böyük olmasını təmin edir.
    ///
    /// Dağıtıcıdan daha yaxşı bilmədiyiniz təqdirdə [`reserve`] metodundan istifadə etməyi düşünün.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, yeni tutum `usize`-i aşarsa.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Bu faktiki olaraq tutumu artıra bilməz:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s-nin uzunluğu 2, tutumu 10-dur
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Artıq əlavə 8 gücümüz olduğundan, bunu ...
    /// s.reserve_exact(8);
    ///
    /// // ... əslində artmır.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Verilən `String`-ə ən azı `additional` element əlavə etmək üçün ehtiyat tutmağa çalışır.
    /// Kolleksiya tez-tez yenidən bölüşdürməmək üçün daha çox yer ayıra bilər.
    /// `reserve`-ə zəng etdikdən sonra tutum `self.len() + additional`-dən böyük və ya ona bərabər olacaqdır.
    /// Tutumu onsuz da kifayətdirsə heç nə etmir.
    ///
    /// # Errors
    ///
    /// Tutum aşıbsa və ya ayırıcı bir uğursuzluq barədə məlumat verərsə, bir səhv qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Yaddaşa əvvəlcədən ayırın, bacarmırıqsa çıxırıq
    ///     output.try_reserve(data.len())?;
    ///
    ///     // İndi bilirik ki, bu, kompleks işimizin ortasında OOM ola bilməz
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Verilən `String`-də tam olaraq `additional` daha çox elementin yerləşdirilməsi üçün minimum tutumu saxlamağa çalışır.
    ///
    /// `reserve_exact`-ə zəng etdikdən sonra tutum `self.len() + additional`-dən böyük və ya ona bərabər olacaqdır.
    /// Tutumu onsuz da kifayətdirsə heç nə etmir.
    ///
    /// Qeyd edək ki, ayırıcı kolleksiyaya istədiyindən daha çox yer verə bilər.
    /// Bu səbəbdən tutumun tam olaraq minimal olduğuna inanmaq olmaz.
    /// future əlavələri gözlənilirsə `reserve`-yə üstünlük verin.
    ///
    /// # Errors
    ///
    /// Tutum aşıbsa və ya ayırıcı bir uğursuzluq barədə məlumat verərsə, bir səhv qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Yaddaşa əvvəlcədən ayırın, bacarmırıqsa çıxırıq
    ///     output.try_reserve(data.len())?;
    ///
    ///     // İndi bilirik ki, bu, kompleks işimizin ortasında OOM ola bilməz
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Bu `String`-in uzunluğuna uyğun tutumu azalır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Bu `String`-in tutumunu aşağı sərhədlə azaldır.
    ///
    /// Tutum ən azı həm uzunluq, həm də verilən dəyər qədər qalacaq.
    ///
    ///
    /// Mövcud tutum aşağı həddən azdırsa, bu, əlverişsizdir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Verilən [`char`]-i bu `String`-in sonuna əlavə edir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Bu `Sətrin 'məzmununun bir bayt dilimini qaytarır.
    ///
    /// Bu metodun tərsi [`from_utf8`]-dir.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Bu `String`-i göstərilən uzunluğa qısaldır.
    ///
    /// `new_len` sətrin cari uzunluğundan böyükdürsə, bunun heç bir təsiri yoxdur.
    ///
    ///
    /// Bu metodun simli ayrılmış tutumu üzərində heç bir təsiri olmadığını unutmayın
    ///
    /// # Panics
    ///
    /// `new_len` bir [`char`] sərhədində yerləşmirsə Panics.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Son simli simli buferdən çıxarır və qaytarır.
    ///
    /// Bu `String` boş olduqda [`None`] qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// [`char`]-i bu `String`-dən bayt mövqeyində çıxarır və geri qaytarır.
    ///
    /// Bu *O*(*n*) əməliyyatıdır, çünki buferdəki hər elementin kopyalanmasını tələb edir.
    ///
    /// # Panics
    ///
    /// Panics, `idx`, `String` uzunluğundan daha böyük və ya ona bərabərdirsə və ya [`char`] sərhədində deyilsə.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String`-də `pat` modelinin bütün uyğunluqlarını silin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Uyğunluqlar aşkar edilərək iterativ şəkildə silinəcəkdir, buna görə naxışların üst-üstə düşdüyü hallarda yalnız ilk naxış silinəcəkdir:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // TƏHLÜKƏSİZLİK: başlanğıc və bitiş utf8 bayt hüdudlarında olacaq
        // axtarış sənədləri
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Yalnız predikat tərəfindən göstərilən simvolları saxlayır.
    ///
    /// Başqa sözlə, `c`-in `false`-ni qaytarması üçün bütün `c` simvollarını silin.
    /// Bu metod hər bir obrazı orijinal qaydada tam bir dəfə ziyarət edərək yerində işləyir və saxlanılan simvolların sırasını qoruyur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Dəqiq sifariş, indeks kimi xarici vəziyyəti izləmək üçün faydalı ola bilər.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // İdx-i növbəti xana yönəldin
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Bu `String`-ə bir bayt mövqeyində bir xarakter əlavə edir.
    ///
    /// Bu *O*(*n*) əməliyyatıdır, çünki buferdəki hər elementin kopyalanmasını tələb edir.
    ///
    /// # Panics
    ///
    /// Panics, `idx` `String` uzunluğundan daha böyükdürsə və ya [`char`] sərhədində deyilsə.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Bu `String`-ə bir bayt mövqeyində bir simli dilim əlavə edir.
    ///
    /// Bu *O*(*n*) əməliyyatıdır, çünki buferdəki hər elementin kopyalanmasını tələb edir.
    ///
    /// # Panics
    ///
    /// Panics, `idx` `String` uzunluğundan daha böyükdürsə və ya [`char`] sərhədində deyilsə.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Bu `String`-in məzmununa dəyişdirilə bilən bir istinad qaytarır.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki ona ötürülən baytların UTF-8 etibarlı olduğunu yoxlamır.
    /// Bu məhdudiyyət pozulursa, `String`-in future istifadəçiləri ilə yaddaş təhlükəsizliyi problemlərinə səbəb ola bilər, çünki standart kitabxananın qalan hissəsi `String`-lərin UTF-8 etibarlı olduğunu düşünür.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Bu `String`-nin uzunluğunu [`char`] s və ya qrafemlər deyil, baytlarla qaytarır.
    /// Başqa sözlə, bir insanın ipin uzunluğunu düşündüyü şey olmaya bilər.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Bu `String`-nin sıfır uzunluğu varsa `true`, əksinə `false` qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Verilən bayt indeksində sətri ikiyə bölür.
    ///
    /// Yeni ayrılmış `String` qaytarır.
    /// `self` `[0, at)` baytları və qaytarılmış `String` `[at, len)` baytları ehtiva edir.
    /// `at` bir UTF-8 kod nöqtəsinin sərhədində olmalıdır.
    ///
    /// `self`-in tutumunun dəyişmədiyini unutmayın.
    ///
    /// # Panics
    ///
    /// Panics, `at` bir `UTF-8` kod nöqtəsi sərhədində deyilsə və ya sətrin son kod nöqtəsindən kənardadırsa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Bütün məzmunu silərək bu `String`-ni kəsir.
    ///
    /// Bu, `String`-nin sıfır uzunluğa sahib olacağı mənasına gəlsə də, tutumuna toxunmur.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String`-də göstərilən aralığı aradan qaldıran və çıxarılan `chars`-ni verən bir boşaltma iteratoru yaradır.
    ///
    ///
    /// Note: İterator sona qədər tükənməsə də element aralığı silinir.
    ///
    /// # Panics
    ///
    /// Panics, başlanğıc nöqtəsi və ya bitiş nöqtəsi [`char`] sərhədində yerləşmirsə və ya sərhədləri xaricindədirsə.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Aralığı simdən β-ə qədər qaldırın
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Tam bir sıra ipi təmizləyir
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Yaddaş təhlükəsizliyi
        //
        // Drain-nin String versiyasında vector versiyasının yaddaş təhlükəsizliyi problemləri yoxdur.
        // Məlumat sadəcə baytdır.
        // Aralığın qaldırılması Drop-da baş verdiyi üçün, Drain iterator sızsa, silmə olmayacaq.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Eyni vaxtda iki borc götürün.
        // &mut Stringə, təkrarlama bitənə qədər, Drop olaraq əldə edilə bilməz.
        let self_ptr = self as *mut _;
        // TƏHLÜKƏSİZLİK: `slice::range` və `is_char_boundary` müvafiq sərhəd yoxlamalarını həyata keçirirlər.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Sətirdə göstərilən aralığı silir və verilən sətirlə əvəz edir.
    /// Verilən sətrin aralıq ilə eyni uzunluğa ehtiyacı yoxdur.
    ///
    /// # Panics
    ///
    /// Panics, başlanğıc nöqtəsi və ya bitiş nöqtəsi [`char`] sərhədində yerləşmirsə və ya sərhədləri xaricindədirsə.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Aralığı simdən β-ə qədər dəyişdirin
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Yaddaş təhlükəsizliyi
        //
        // Replace_range bir vector Splice yaddaş təhlükəsizliyi problemi yoxdur.
        // vector versiyasının.Məlumat sadəcə baytdır.

        // XƏBƏRDARLIQ: Bu dəyişənin üst-üstə salınması səssiz (#81138) olacaqdır
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // XƏBƏRDARLIQ: Bu dəyişənin üst-üstə salınması səssiz (#81138) olacaqdır
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Yenidən `range` istifadə etmək əsassız olardı (#81138), `range` tərəfindən bildirilən sərhədlərin eyni qaldığını düşünürük, lakin ziddiyyətli tətbiq zənglər arasında dəyişə bilər
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Bu `String` yi [`Box`]`<`[`str`] `>` 'şəklinə çevirir.
    ///
    /// Bu artıq tutumu azaldır.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String`-ə çevrilməyə cəhd edilmiş [`u8`] s bayt dilimini qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // bəzi etibarsız baytlar, bir vector-də
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String`-ə çevrilməyə cəhd edilmiş baytları qaytarır.
    ///
    /// Bu metod ayrılmamaq üçün diqqətlə qurulur.
    /// Baytların bir nüsxəsinin çıxarılmasına ehtiyac qalmaması üçün baytları köçürərək xətanı yeyəcək.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // bəzi etibarsız baytlar, bir vector-də
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Dönüşüm uğursuzluğu haqqında daha ətraflı məlumat almaq üçün `Utf8Error` götürün.
    ///
    /// [`std::str`] tərəfindən təmin edilən [`Utf8Error`] tipi, bir dilim [`u8 '] nin [`&str`]-ə çevrilməsi zamanı yarana biləcək bir səhvdir.
    /// Bu mənada `FromUtf8Error`-in analoqudur.
    /// İstifadəsi ilə bağlı daha ətraflı məlumat üçün sənədlərinə baxın.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // bəzi etibarsız baytlar, bir vector-də
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ilk bayt burada səhvdir
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // "String`s" üzərində təkrarladığımız üçün, ilk simli iteratordan alaraq və sonrakı bütün simlərə əlavə edərək ən azı bir ayırmanın qarşısını ala bilərik.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // CoW-lər üzərində təkrarladığımız üçün (potentially) ilk elementi əldə edərək bütün sonrakı maddələrə əlavə edərək ən azı bir ayırmanın qarşısını ala bilərik.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` üçün implenti təmsil edən bir rahatlıq imalı.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Boş bir `String` yaradır.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// İki simli birləşdirmək üçün `+` operatorunu həyata keçirir.
///
/// Bu, sol tərəfdəki `String`-ni istehlak edir və buferini yenidən istifadə edir (lazım olduqda böyüyür).
/// Bu, yeni bir `String` ayırmaqdan və hər bir əməliyyatdakı bütün məzmunu kopyalamaqdan qaçmaq üçün edilir ki, bu da *n*-bayt sətirini təkrar birləşdirmə ilə qurarkən *O*(*n*^ 2) işləmə müddətinə gətirib çıxaracaqdır.
///
///
/// Sağ tərəfdəki simli yalnız borc götürülmüşdür;məzmunu qaytarılmış `String`-ə kopyalanır.
///
/// # Examples
///
/// İki "Sətir" in birləşməsi birincisini dəyərinə görə alır və ikincisini borc alır:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` köçürülüb və artıq burada istifadə edilə bilməz.
/// ```
///
/// İlk `String`-dən istifadə etməyə davam etmək istəyirsinizsə, onu klonlaya və əvəzinə klon əlavə edə bilərsiniz:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` burada hələ də qüvvədədir.
/// ```
///
/// `&str` dilimlərini birləşdirmək, birincisini `String`-ə çevirməklə edilə bilər:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String`-ə əlavə etmək üçün `+=` operatorunu həyata keçirir.
///
/// Bu, [`push_str`][String::push_str] metodu ilə eyni davranışa sahibdir.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] üçün bir növ takma ad.
///
/// Bu takma ad geriyə uyğunluq üçün mövcuddur və nəticədə köhnəlmiş ola bilər.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Bir dəyəri `String`-ə çevirmək üçün bir trait.
///
/// Bu trait, [`Display`] trait tətbiq edən hər hansı bir növ üçün avtomatik olaraq tətbiq olunur.
/// Beləliklə, `ToString` birbaşa tətbiq edilməməlidir:
/// [`Display`] əvəzinə həyata keçirilməlidir və `ToString` tətbiqini pulsuz əldə edəcəksiniz.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Verilən dəyəri `String`-ə çevirir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Bu tətbiqdə, `Display` tətbiqi bir səhv qaytararsa, `to_string` metodu panics.
/// Bu səhv bir `Display` tətbiqetməsini göstərir, çünki `fmt::Write for String` heç vaxt öz xətasını qaytarmır.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Ümumi bir təlimat, ümumi funksiyaları sıraya salmamaqdır.
    // Lakin `#[inline]`-in bu metoddan çıxarılması əhəmiyyətsiz geriləmələrə səbəb olur.
    // <https://github.com/rust-lang/rust/pull/74852>-ə baxın, onu silmək üçün son cəhd.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str`-i `String`-ə çevirir.
    ///
    /// Nəticə yığına ayrılır.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test burada səhvlərə səbəb olan libstd-ni çəkir
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Verilmiş qutulu `str` dilimini `String`-ə çevirir.
    /// `str` diliminin sahib olduğu diqqət çəkir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Verilən `String`-yə sahib olan qutulu bir `str` diliminə çevirir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Simli dilimi Borc götürülmüş varianta çevirir.
    /// Heç bir yığma aparılmır və sətir kopyalanmır.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Bir simli məxsus varianta çevirir.
    /// Heç bir yığma aparılmır və sətir kopyalanmır.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Bir String istinadını Borc götürülmüş varianta çevirir.
    /// Heç bir yığma aparılmır və sətir kopyalanmır.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Verilən `String`-i `u8` tipli dəyərlərə sahib olan vector `Vec`-ə çevirir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` üçün boşaltma iteratoru.
///
/// Bu struktur [`String`]-də [`drain`] metodu ilə yaradılmışdır.
/// Daha çox məlumat üçün sənədlərinə baxın.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Dağıdıcıda&'mut String olaraq istifadə ediləcək
    string: *mut String,
    /// Silinəcək hissənin başlanğıcı
    start: usize,
    /// Silinəcək hissənin sonu
    end: usize,
    /// Cari qalan silinəcək aralıq
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain istifadə edin.
            // "Reaffirm" sərhədlər yenidən panic kodunun daxil edilməməsi üçün yoxlanılır.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Bu iteratorun qalan (alt) sətrini dilim şəklində qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: qeyri-sabitlik AsRef sabitləşdikdə aşağıya aiddir.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str`-i sabitləşdirərkən fikir bildirməyin.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain üçün <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> for Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}