#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Yeni yaddaşın məzmunu başlanğıclaşdırılmamışdır.
    Uninitialized,
    /// Yeni yaddaşın sıfırlanmasına zəmanət verilir.
    Zeroed,
}

/// Yaddaşın bir tamponunu daha çox erqonomik olaraq ayırmaq, yenidən bölüşdürmək və yığma yerdəki bütün künc hallarından narahat olmayaraq ayırmaq üçün aşağı səviyyəli bir yardım proqramı.
///
/// Bu tip, Vec və VecDeque kimi öz məlumat strukturlarınızı yaratmaq üçün əladır.
/// Xüsusilə:
///
/// * Sıfır ölçülü tiplərdə `Unique::dangling()` istehsal edir.
/// * Sıfır uzunluqlu ayırmalarda `Unique::dangling()` istehsal edir.
/// * `Unique::dangling()`-in boşaldılmasının qarşısını alır.
/// * Tutum hesablamalarında bütün daşqınları tutur (onları "capacity overflow" panics səviyyəsinə çatdırır).
/// * isize::MAX baytdan çox ayıran 32 bit sistemlərə qarşı qorunur.
/// * Uzunluğunuzun aşmasına qarşı qoruyan.
/// * Yanlış ayırmalar üçün `handle_alloc_error` çağırır.
/// * Bir `ptr::Unique` ehtiva edir və beləliklə istifadəçiyə bütün əlaqəli üstünlükləri təqdim edir.
/// * Mövcud ən böyük potensialdan istifadə etmək üçün ayırıcıdan qaytarılmış artıqdan istifadə edir.
///
/// Bu tip hər halda idarə etdiyi yaddaşı yoxlamır.Düşürdükdə *yaddaşını* boşaldacaq, ancaq içindəkiləri atmağa çalışmayacaq.
/// Bir `RawVec` içərisində *saxlanan* həqiqi şeyləri idarə etmək `RawVec` istifadəçisinə aiddir.
///
/// Sıfır ölçülü tiplərin artıqlığının hər zaman sonsuz olduğundan `capacity()` həmişə `usize::MAX`-yə döndüyünü unutmayın.
/// Bu o deməkdir ki, bu tipi `Box<[T]>` ilə açarkən diqqətli olmalısınız, çünki `capacity()` uzunluğu vermir.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Bu, `#[unstable]` `const fn`s-nin `min_const_fn`-ə uyğun olmaması səbəbindən mövcuddur və buna görə də bunlar min_const_fn`-də çağırıla bilməz.
    ///
    /// `RawVec<T>::new` və ya asılılıqları dəyişdirsəniz, `min_const_fn`-i həqiqətən pozacaq bir şey təqdim etməməyinizə diqqət yetirin.
    ///
    /// NOTE: Bu hackdən qaça bilərik və `min_const_fn` ilə uyğunluq tələb edən bəzi `#[rustc_force_min_const_fn]` atributu ilə uyğunluğu yoxlaya bilərik, lakin `stable(...) const fn`/`#[rustc_const_unstable(feature = "foo", issue = "01234")]` mövcud olduqda `foo`-ə imkan verməyən istifadəçi kodunda çağırılmasına icazə vermirik.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Mümkün olan ən böyük `RawVec`-i (sistem yığınında) ayırmadan yaradır.
    /// `T` müsbət ölçüyə malikdirsə, bu, `0` tutumlu bir `RawVec` edir.
    /// `T` sıfır ölçülüdürsə, `usize::MAX` tutumlu bir `RawVec` edir.
    /// Gecikmiş ayırmanın həyata keçirilməsi üçün faydalıdır.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Bir `[T; capacity]` üçün tam tutum və hizalama tələblərinə uyğun bir `RawVec` (sistem yığınında) yaradır.
    /// Bu, `capacity` `0` olduqda və ya `T` sıfır ölçülü olduqda `RawVec::new` çağırmağa bərabərdir.
    /// Qeyd edək ki, `T` sıfır ölçülüdürsə, bu, tələb olunan həcmdə bir `RawVec` almayacağınız deməkdir.
    ///
    /// # Panics
    ///
    /// Panics, tələb olunan həcm `isize::MAX` baytdan çox olarsa.
    ///
    /// # Aborts
    ///
    /// OOM-da ləğv edir.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` kimi, lakin buferin sıfırlanmasına zəmanət verir.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Bir göstəricidən və tutumdan bir `RawVec` qurur.
    ///
    /// # Safety
    ///
    /// `ptr` (sistem yığınında) və verilmiş `capacity` ilə ayrılmalıdır.
    /// `capacity` ölçülü növlər üçün `isize::MAX`-dən çox ola bilməz.(yalnız 32 bit sistemlərlə əlaqəli bir problem).
    /// ZST vectors, `usize::MAX`-ə qədər tutuma sahib ola bilər.
    /// `ptr` və `capacity` bir `RawVec`-dən gəlirsə, buna zəmanət verilir.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Kiçik Veclər laldır.Keçid:
    // - 8 element ölçüsü 1 olarsa, çünki hər hansı bir yığın ayırıcı ən azı 8 baytdan 8 bayta qədər bir sorğu toplaya bilər.
    //
    // - 4 elementlər orta ölçülüdürsə (<=1 KiB).
    // - 1 əks halda, çox qısa Vecs üçün çox yer boşaltmamaq üçün.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` kimi, lakin qaytarılmış `RawVec` üçün ayırıcı seçimi üzərində parametrlənmişdir.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" deməkdir.sıfır ölçülü növlər nəzərə alınmır.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` kimi, lakin qaytarılmış `RawVec` üçün ayırıcı seçimi üzərində parametrlənmişdir.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` kimi, lakin qaytarılmış `RawVec` üçün ayırıcı seçimi üzərində parametrlənmişdir.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>`-i `RawVec<T>`-ə çevirir.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Bütün buferi göstərilən `len` ilə `Box<[MaybeUninit<T>]>`-ə çevirir.
    ///
    /// Diqqət yetirin ki, bu, həyata keçirilmiş ola biləcək `cap` dəyişikliklərini düzgün şəkildə bərpa edəcəkdir.(Ətraflı məlumat üçün növün təsvirinə baxın.)
    ///
    /// # Safety
    ///
    /// * `len` ən son tələb olunan tutumdan böyük və ya bərabər olmalıdır və
    /// * `len` `self.capacity()`-dən az və ya bərabər olmalıdır.
    ///
    /// Diqqət yetirin ki, tələb olunan həcm və `self.capacity()` fərqlənə bilər, çünki bir ayırıcı həddindən artıq bölə bilər və tələb olunduğundan daha çox yaddaş blokunu qaytara bilər.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sağlamlıq-təhlükəsizlik tələbinin yarısını yoxlayın (digər yarısını yoxlaya bilmərik).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Burada yaradılan LLVM IR miqdarını şişirddiyindən `unwrap_or_else`-dən qaçırıq.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Bir göstəricidən, tutumdan və ayırıcıdan bir `RawVec` qurur.
    ///
    /// # Safety
    ///
    /// `ptr` (verilmiş `alloc` ayırıcı vasitəsi ilə) və verilmiş `capacity` ilə ayrılmalıdır.
    /// `capacity` ölçülü növlər üçün `isize::MAX`-dən çox ola bilməz.
    /// (yalnız 32 bit sistemlərlə əlaqəli bir problem).
    /// ZST vectors, `usize::MAX`-ə qədər tutuma sahib ola bilər.
    /// `ptr` və `capacity`, `alloc` vasitəsilə yaradılan bir `RawVec`-dən gəlirsə, buna zəmanət verilir.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ayrılmanın başlanğıcına xam bir göstərici alır.
    /// `capacity == 0` və ya `T` sıfır ölçülü olduqda bunun `Unique::dangling()` olduğunu unutmayın.
    /// Əvvəlki vəziyyətdə diqqətli olmalısınız.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ayrılma qabiliyyətini alır.
    ///
    /// `T` sıfır ölçülü olduqda bu həmişə `usize::MAX` olacaqdır.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Bu `RawVec`-i dəstəkləyən ayırıcıya paylaşılan bir istinad qaytarır.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Yaddaşın ayrılmış bir hissəsinə sahibik, buna görə hazırkı düzənimizi almaq üçün iş vaxtı yoxlamalarını atlaya bilərik.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Tamponda `len + additional` elementlərini tutmaq üçün ən azı kifayət qədər yer olmasını təmin edir.
    /// Əgər onsuz da kifayət qədər tutumu yoxdursa, amortizasiya olunmuş *O*(1) davranışı üçün kifayət qədər yer və rahat boş yer yenidən bölüşdürəcəkdir.
    ///
    /// Özünü panic-ə səbəb olacağı təqdirdə bu davranışı məhdudlaşdıracaqdır.
    ///
    /// `len` `self.capacity()`-i aşarsa, bu, həqiqətən tələb olunan yeri ayırmaq üçün uğursuz ola bilər.
    /// Bu, həqiqətən təhlükəli deyil, ancaq bu funksiyanın davranışına güvəndiyiniz * yazdığınız təhlükəli kod pozula bilər.
    ///
    /// Bu, `extend` kimi toplu basma əməliyyatını həyata keçirmək üçün idealdır.
    ///
    /// # Panics
    ///
    /// Panics, yeni tutum `isize::MAX` baytdan çox olarsa.
    ///
    /// # Aborts
    ///
    /// OOM-da ləğv edir.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ehtiyatı len `isize::MAX`-dən çox olsaydı ləğv edərdi və ya çaxnaşmış olardı, buna görə də indi yoxlanılmaq təhlükəsizdir.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` ilə eyni, lakin çaxnaşma və ya ləğv etmək əvəzinə səhvlərə qayıdır.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Tamponda `len + additional` elementlərini tutmaq üçün ən azı kifayət qədər yer olmasını təmin edir.
    /// Zaten deyilsə, lazım olan minimum mümkün yaddaş həcmini yenidən bölüşdürəcəkdir.
    /// Ümumiyyətlə bu, lazım olan yaddaş miqdarı olacaqdır, lakin prinsipcə ayırıcı istədiyimizdən daha çoxunu geri qaytarmaqda sərbəstdir.
    ///
    ///
    /// `len` `self.capacity()`-i aşarsa, bu, həqiqətən tələb olunan yeri ayırmaq üçün uğursuz ola bilər.
    /// Bu, həqiqətən təhlükəli deyil, ancaq bu funksiyanın davranışına güvəndiyiniz * yazdığınız təhlükəli kod pozula bilər.
    ///
    /// # Panics
    ///
    /// Panics, yeni tutum `isize::MAX` baytdan çox olarsa.
    ///
    /// # Aborts
    ///
    /// OOM-da ləğv edir.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` ilə eyni, lakin çaxnaşma və ya ləğv etmək əvəzinə səhvlərə qayıdır.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Ayrılan məbləği göstərilən məbləğə qədər azaldır.
    /// Verilən məbləğ 0-dırsa, həqiqətən tamamilə bölüşdürülür.
    ///
    /// # Panics
    ///
    /// Verilən məbləğ cari tutumdan * daha böyükdürsə Panics.
    ///
    /// # Aborts
    ///
    /// OOM-da ləğv edir.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Lazım olan əlavə tutumu yerinə yetirmək üçün tamponun böyüməsi lazım olduqda qayıdır.
    /// Əsasən, `grow`-i sıralamadan, daxili ehtiyat zənglərini mümkün etmək üçün istifadə olunur.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Bu üsul ümumiyyətlə dəfələrlə təhrik olunur.Buna görə kompilyasiya müddətlərini yaxşılaşdırmaq üçün mümkün qədər kiçik olmasını istəyirik.
    // Bununla yanaşı, yaradılan kodun daha sürətli işləməsini təmin etmək üçün içindəkilərin mümkün qədər statik olaraq hesablanmasını istəyirik.
    // Buna görə də, bu metod `T`-dən asılı olan bütün kodlar onun daxilində olması üçün diqqətlə yazılır, `T`-dən asılı olmayan kodların çox hissəsi `T`-dən çox olmayan funksiyalardadır.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Bu zəng kontekstləri ilə təmin edilir.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` olduqda `usize::MAX` tutumunu qaytardığımız üçün
            // 0, buraya gəlmək mütləq `RawVec`-in həddən artıq olması deməkdir.
            return Err(CapacityOverflow);
        }

        // Təəssüf ki, bu çeklərlə bağlı həqiqətən heç nə edə bilmərik.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Bu, eksponent böyüməyə zəmanət verir.
        // `cap <= isize::MAX` və `cap` növü `usize` olduğu üçün ikiqat aşıla bilməz.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` üzərində ümumi deyil.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Bu metoddakı məhdudiyyətlər `grow_amortized`-dəki ilə eynidir, lakin bu metod ümumiyyətlə daha az təsirləndirilir, buna görə daha az kritikdir.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Tip ölçüsü olduqda `usize::MAX` tutumu qaytardığımız üçün
            // 0, buraya gəlmək mütləq `RawVec`-in həddən artıq olması deməkdir.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` üzərində ümumi deyil.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Bu funksiya tərtib müddətlərini minimuma endirmək üçün `RawVec` xaricindədir.Ətraflı məlumat üçün yuxarıdakı `RawVec::grow_amortized` şərhinə baxın.
// (`A` parametri əhəmiyyətli deyil, çünki praktikada görünən fərqli `A` növlərinin sayı `T` növlərinin sayından çox azdır.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` ölçüsünü minimuma endirmək üçün burada səhv olub olmadığını yoxlayın.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Dağıtıcı hizalama bərabərliyini yoxlayır
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*-ə məxsus yaddaşı* məzmunu salmağa çalışmadan * azad edir.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Ehtiyat səhvləri ilə işləmə mərkəzi funksiyası.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Aşağıdakılara zəmanət verməyimiz lazımdır:
// * Heç vaxt `> isize::MAX` bayt ölçülü obyektlər ayırmırıq.
// * `usize::MAX`-i aşmırıq və əslində çox az ayırırıq.
//
// 64-bitdə `> isize::MAX` bayt ayırmağa çalışdığımız üçün uğursuz olacağından daşma olub olmadığını yoxlamalıyıq.
// 32 bit və 16 bitlik yerlərdə, məsələn, PAE və ya x32 istifadəçi məkanında bütün 4 GB-dan istifadə edə biləcəyimiz bir platformada işləməyimiz üçün əlavə qoruyucu əlavə etməliyik.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Hesabat tutumunun daşması üçün cavabdeh olan bir mərkəzi funksiya.
// Bu, bu panics ilə əlaqəli kod istehsalının minimal olmasını təmin edəcəkdir, çünki modul boyu bir dəstə əvəzinə panics olan yalnız bir yer var.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}