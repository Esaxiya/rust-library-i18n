//! Bitişik bir ardıcıllığa dinamik ölçüdə bir görünüş, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Dilimlər bir göstərici və uzunluq kimi təmsil olunan yaddaş blokuna baxışdır.
//!
//! ```
//! // bir Vec dilimlənməsi
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // bir dilimi bir dilimə məcbur etmək
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Dilimlər ya dəyişdirilə bilər, ya da paylaşılır.
//! Paylaşılan dilim növü `&[T]`, dəyişdirilə bilən dilim növü `&mut [T]`, burada `T` element tipini təmsil edir.
//! Məsələn, dəyişdirilə bilən dilimin göstərdiyi yaddaş blokunu dəyişdirə bilərsiniz:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Bu modulun içərisində olan bəzi şeylər:
//!
//! ## Structs
//!
//! Dilimlər üçün faydalı olan bir neçə quruluş var, məsələn, bir dilim üzərində təkrarlamanı təmsil edən [`Iter`].
//!
//! ## Trait Tətbiqləri
//!
//! Dilimlər üçün ümumi traits-nin bir neçə tətbiqi var.Bəzi nümunələrə aşağıdakılar daxildir:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], element növü [`Eq`] və ya [`Ord`] olan dilimlər üçün.
//! * [`Hash`] - element növü [`Hash`] olan dilimlər üçün.
//!
//! ## Iteration
//!
//! Dilimlər `IntoIterator` tətbiq edir.İterator, dilim elementlərinə istinadlar verir.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Dəyişdirilə bilən dilim elementlərə dəyişkən istinadlar verir:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Bu təkrarlayıcı dilim elementlərinə dəyişdirilə bilən istinadlar verir, beləliklə dilimin element növü `i32` olduğu halda, iteratorun element növü `&mut i32`-dir.
//!
//!
//! * [`.iter`] və [`.iter_mut`], standart təkrarlayıcıları qaytarmaq üçün açıq üsullardır.
//! * Təkrarlayıcıları qaytaran başqa metodlar [`.split`], [`.splitn`], [`.chunks`], [`.windows`] və daha çoxdur.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Bu moduldakı bir çox istifadə yalnız test konfiqurasiyasında istifadə olunur.
// İstifadə olunmamış_import xəbərdarlığını silməkdənsə, onları silmək daha təmizdir.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Əsas dilim genişləndirmə metodları
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB testi zamanı `vec!` makrosunun tətbiqi üçün lazım olsa, daha çox məlumat üçün bu fayldakı `hack` moduluna baxın.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB-nin sınanması zamanı `Vec::clone`-nin tətbiqi üçün lazımlıdır, daha çox məlumat üçün bu sənəddəki `hack` moduluna baxın.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` mövcud olmadığı üçün bu üç funksiya əslində `impl [T]`-də olan, lakin `core::slice::SliceExt`-də olmayan metodlardır, bu funksiyaları `test_permutations` testi üçün təmin etməliyik
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Buna əsasən satır atributu əlavə etməməliyik, çünki bu, `vec!` makrosunda daha çox istifadə olunur və mükəmməl reqressiyaya səbəb olur.
    // Müzakirə və mükəmməl nəticələr üçün #71204-ə baxın.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // maddələr aşağıdakı döngədə başlanğıc şəklində qeyd edildi
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM-nin sərhəd yoxlamalarını aradan qaldırması üçün lazımdır və zipdən daha yaxşı kodlaşdırıcıya malikdir.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ayrılmış və yuxarıda ən azı bu uzunluğa başlamışdır.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // yuxarıda `s` tutumu ilə ayrılmış və aşağıdakı ptr::copy_to_non_overlapping-də `s.len()`-ə başlayın.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Dilimi çeşidləyir.
    ///
    /// Bu növ sabitdir (yəni bərabər elementləri yenidən sıralamır) və *O*(*n*\*log(* n*)) ən pis halda).
    ///
    /// Tətbiq olunduqda, qeyri-sabit çeşidlənməyə üstünlük verilir, çünki ümumiyyətlə sabit çeşidlənmədən daha sürətli və köməkçi yaddaş ayırmır.
    /// [`sort_unstable`](slice::sort_unstable)-ə baxın.
    ///
    /// # Cari tətbiq
    ///
    /// Mövcud alqoritm, [timsort](https://en.wikipedia.org/wiki/Timsort)-dən ilham alan uyğunlaşma, təkrarlanan birləşmə növüdür.
    /// Dilimin az qala çeşidlənməsi və ya bir-birinin ardınca birləşdirilmiş iki və ya daha çox sıralanmış ardıcıllıqdan ibarət olduğu hallarda çox sürətli olması üçün hazırlanmışdır.
    ///
    ///
    /// Ayrıca, müvəqqəti saxlama üçün `self` ölçüsünün yarısını ayırır, ancaq qısa dilimlər üçün ayrılmayan bir əlavə növü istifadə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Dilimi bir müqayisə funksiyası ilə sıralayır.
    ///
    /// Bu növ sabitdir (yəni bərabər elementləri yenidən sıralamır) və *O*(*n*\*log(* n*)) ən pis halda).
    ///
    /// Müqayisələndirici funksiya dilimdəki elementlər üçün ümumi sifariş təyin etməlidir.Sifariş cəmi deyilsə, elementlərin sırası dəqiqləşdirilməyib.
    /// Sifariş cəmi sifarişdir (bütün `a`, `b` və `c` üçün):
    ///
    /// * ümumi və antisimetrik: `a < b`, `a == b` və ya `a > b`-dən tam biri doğrudur və
    /// * keçici, `a < b` və `b < c`, `a < c`-ni nəzərdə tutur.Həm `==`, həm də `>` üçün eyni olmalıdır.
    ///
    /// Məsələn, [`f64`] [`Ord`] tətbiq etmədiyi üçün `NaN != NaN`, dilimdə `NaN` olmadığını bildiyimiz zaman `partial_cmp`-i sıralama funksiyamız kimi istifadə edə bilərik.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Tətbiq olunduqda, qeyri-sabit çeşidlənməyə üstünlük verilir, çünki ümumiyyətlə sabit çeşidlənmədən daha sürətli və köməkçi yaddaş ayırmır.
    /// [`sort_unstable_by`](slice::sort_unstable_by)-ə baxın.
    ///
    /// # Cari tətbiq
    ///
    /// Mövcud alqoritm, [timsort](https://en.wikipedia.org/wiki/Timsort)-dən ilham alan uyğunlaşma, təkrarlanan birləşmə növüdür.
    /// Dilimin az qala çeşidlənməsi və ya bir-birinin ardınca birləşdirilmiş iki və ya daha çox sıralanmış ardıcıllıqdan ibarət olduğu hallarda çox sürətli olması üçün hazırlanmışdır.
    ///
    /// Ayrıca, müvəqqəti saxlama üçün `self` ölçüsünün yarısını ayırır, ancaq qısa dilimlər üçün ayrılmayan bir əlavə növü istifadə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // tərs çeşidləmə
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Dilimi açar çıxarma funksiyası ilə sıralayır.
    ///
    /// Bu növ sabitdir (yəni bərabər elementləri yenidən sıralamır) və *O*(*m*\* * n *\* log(*n*)) ən pis halda, burada əsas funksiya *O*(*m*) olur.
    ///
    /// Bahalı əsas funksiyalar üçün (məsələn
    /// sadə mülkiyyət girişləri və ya əsas əməliyyatlar olmayan funksiyalar), [`sort_by_cached_key`](slice::sort_by_cached_key) element düymələrini yenidən hesablamadığı üçün əhəmiyyətli dərəcədə daha sürətli olacaq.
    ///
    ///
    /// Tətbiq olunduqda, qeyri-sabit çeşidlənməyə üstünlük verilir, çünki ümumiyyətlə sabit çeşidlənmədən daha sürətli və köməkçi yaddaş ayırmır.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key)-ə baxın.
    ///
    /// # Cari tətbiq
    ///
    /// Mövcud alqoritm, [timsort](https://en.wikipedia.org/wiki/Timsort)-dən ilham alan uyğunlaşma, təkrarlanan birləşmə növüdür.
    /// Dilimin az qala çeşidlənməsi və ya bir-birinin ardınca birləşdirilmiş iki və ya daha çox sıralanmış ardıcıllıqdan ibarət olduğu hallarda çox sürətli olması üçün hazırlanmışdır.
    ///
    /// Ayrıca, müvəqqəti saxlama üçün `self` ölçüsünün yarısını ayırır, ancaq qısa dilimlər üçün ayrılmayan bir əlavə növü istifadə olunur.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Dilimi açar çıxarma funksiyası ilə sıralayır.
    ///
    /// Sıralama zamanı düymə funksiyası element başına yalnız bir dəfə çağırılır.
    ///
    /// Bu növ sabitdir (yəni bərabər elementləri yenidən sıralamır) və *O*(*m*\* * n *+* n *\* log(*n*)) ən pis vəziyyətdədir, burada əsas funksiya *O*(*m*) .
    ///
    /// Sadə əsas funksiyalar üçün (məsələn, əmlaka giriş və ya əsas əməliyyatlar olan funksiyalar) [`sort_by_key`](slice::sort_by_key) daha sürətli olacaq.
    ///
    /// # Cari tətbiq
    ///
    /// Mövcud alqoritm, Orson Peters-in [pattern-defeating quicksort][pdqsort]-yə əsaslanır ki, bu da müəyyən naxışlarla dilimlərdə xətti müddət əldə edərkən, təsadüfi sürətləmə sürətini və ən sürətli ən pis vəziyyəti birləşdirir.
    /// Degenerasiya hallarının qarşısını almaq üçün bəzi təsadüfi istifadə edir, lakin sabit seed ilə daima determinist davranış təmin edir.
    ///
    /// Ən pis halda, alqoritm dilim uzunluğunda `Vec<(K, usize)>` müvəqqəti saxlama yeri ayırır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Ayrılmanı azaltmaq üçün vector-ni mümkün olan ən kiçik növə görə indeksləşdirmək üçün köməkçi makro.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` elementləri indeksləşdirildiyi üçün unikaldır, buna görə orijinal dilimlə bağlı hər cür sabit olacaqdır.
                // Burada `sort_unstable` istifadə edirik, çünki daha az yaddaş ayırma tələb olunur.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self`-i yeni `Vec`-ə köçürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Burada `s` və `x` müstəqil olaraq dəyişdirilə bilər.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self`-i ayırıcı ilə yeni bir `Vec`-ə köçürür.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Burada `s` və `x` müstəqil olaraq dəyişdirilə bilər.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, daha çox məlumat üçün bu sənəddəki `hack` moduluna baxın.
        hack::to_vec(self, alloc)
    }

    /// `self`-i klonlaşdırmadan və ayırmadan vector-ə çevirir.
    ///
    /// Nəticədə vector, `Vec vasitəsilə yenidən bir qutuya çevrilə bilər<T>`into_boxed_slice` metodu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` `x`-ə çevrildiyi üçün artıq istifadə edilə bilməz.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, daha çox məlumat üçün bu sənəddəki `hack` moduluna baxın.
        hack::into_vec(self)
    }

    /// Bir dilimi `n` dəfə təkrarlayaraq bir vector yaradır.
    ///
    /// # Panics
    ///
    /// Tutumun aşıb-daşması halında bu funksiya panic olacaqdır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Doldurma zamanı bir panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` sıfırdan böyükdürsə, `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` olaraq bölünə bilər.
        // `2^expn` `n`-in ən soldakı '1' biti ilə təmsil olunan rəqəmdir və `rem`, `n`-in qalan hissəsidir.
        //
        //

        // `set_len()`-ə daxil olmaq üçün `Vec` istifadə.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` təkrar `buf` ni iki dəfə artırmaqla edilir.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` varsa, ən sol '1'-ə qədər qalan bitlər var.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` tutumlu.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) təkrarlama ilk `rem` təkrarlamaları `buf` in özündən kopyalayaraq həyata keçirilir.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Bu, `2^expn > rem`-dən bəri üst-üstə düşmür.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()`-ə bərabərdir (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` dilimini tək bir `Self::Output` dəyərinə düzəldir.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` dilimini tək bir `Self::Output` dəyərinə düzəldir və hər biri arasında müəyyən bir ayırıcı yerləşdirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` dilimini tək bir `Self::Output` dəyərinə düzəldir və hər biri arasında müəyyən bir ayırıcı yerləşdirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Hər bir baytın ASCII böyük hərfinə bərabərləşdirildiyi bu dilimin bir nüsxəsini ehtiva edən bir vector qaytarır.
    ///
    ///
    /// 'a'-'z' arasında ASCII hərfləri 'A'-'Z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Yerdəki dəyəri böyük göstərmək üçün [`make_ascii_uppercase`] istifadə edin.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Hər bir baytın ASCII kiçik hərfinə bərabərləşdirildiyi bu dilimin bir nüsxəsini ehtiva edən bir vector qaytarır.
    ///
    ///
    /// 'A'-'Z' arasında ASCII hərfləri 'a'-'z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Yerindəki dəyəri azaltmaq üçün [`make_ascii_lowercase`] istifadə edin.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Xüsusi məlumat növləri üzərində dilimlər üçün traits uzantısı
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](dilim::concat) üçün trait köməkçisi.
///
/// Note: `Item` tipli parametr bu trait-də istifadə edilmir, lakin impllərin daha ümumi olmasına imkan verir.
/// Onsuz bu səhv olur:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Bunun səbəbi birdən çox `Borrow<[_]>` təsiri olan `V` tipləri ola bilər, belə ki, bir çox `T` tipləri tətbiq oluna bilər:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Birləşdirildikdən sonra yaranan növ
    type Output;

    /// [`[T]: : concat`](dilim::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`](dilim::join) üçün trait köməkçisi
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Birləşdirildikdən sonra yaranan növ
    type Output;

    /// [`[T]: : qoşulma](dilim::qoşulmaq)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Dilimlər üçün standart trait tətbiqetmələri
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // üzərinə yazılmayacaq bir şeyi atın
        target.truncate(self.len());

        // target.len <= self.len yuxarıdakı kəsik səbəbiylə buradakı dilimlər həmişə məhduddur.
        //
        let (init, tail) = self.split_at(target.len());

        // olan dəyərləri yenidən istifadə edin allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]`-i əvvəlcədən sıralanmış `v[1..]` ardıcıllığına daxil edir ki, bütün `v[..]` sıralanır.
///
/// Bu yerləşdirmə növünün ayrılmaz alt proqramıdır.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Burada əlavə etmənin üç yolu var:
            //
            // 1. Birincisi son təyinat yerinə çatana qədər bitişik elementləri dəyişdirin.
            //    Bununla birlikdə, bu şəkildə məlumatları lazım olduğundan daha çox kopyalayırıq.
            //    Elementlər böyük strukturlardırsa (kopyalamaq baha başa gəlirsə), bu metod yavaş olacaq.
            //
            // 2. İlk element üçün doğru yer tapılana qədər təkrarlayın.
            // Sonra ona yer ayırmaq üçün uğurlu elementləri dəyişdirin və sonda qalan çuxura qoyun.
            // Bu yaxşı bir üsuldur.
            //
            // 3. İlk elementi müvəqqəti dəyişənə kopyalayın.Bunun üçün uyğun yer tapılana qədər təkrarlayın.
            // Yol gedərkən hər keçən elementi əvvəlki yuvaya kopyalayın.
            // Nəhayət, müvəqqəti dəyişəndən məlumatları qalan çuxura kopyalayın.
            // Bu metod çox yaxşıdır.
            // Qiymətləndirmələr 2-ci metodla müqayisədə bir az daha yaxşı performans nümayiş etdirdi.
            //
            // Bütün metodlar müqayisə edildi və üçüncüsü ən yaxşı nəticələr göstərdi.Beləliklə, birini seçdik.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Yerləşdirmə prosesinin aralıq vəziyyəti həmişə iki məqsədə xidmət edən `hole` tərəfindən izlənir:
            // 1. `v`-in bütövlüyünü `is_less`-də panics-dən qoruyur.
            // 2. Sonda `v`-də qalan çuxuru doldurur.
            //
            // Panic təhlükəsizliyi:
            //
            // `is_less` panics prosesi əsnasında hər hansı bir nöqtədə olarsa, `hole` düşəcək və `v`-dəki boşluğu `tmp` ilə dolduracaq, beləliklə `v`-in əvvəlcə tutduğu hər bir obyekti tam olaraq bir dəfə saxladığını təmin edəcəkdir.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` düşür və beləliklə `tmp`-i `v`-də qalan çuxura köçürür.
        }
    }

    // Düşdükdə, `src`-dən `dest`-ə kopyalanır.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Azalan olmayan `v[..mid]` və `v[mid..]` işlərini müvəqqəti saxlama olaraq `buf` istifadə edərək birləşdirir və nəticəni `v[..]`-ə saxlayır.
///
/// # Safety
///
/// İki dilim boş olmamalı və `mid` sərhəddə olmalıdır.
/// Buffer `buf` daha qısa dilimin bir nüsxəsini saxlayacaq qədər uzun olmalıdır.
/// Ayrıca, `T` sıfır ölçülü bir tip olmamalıdır.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Birləşmə prosesi əvvəlcə `buf`-ə daha qısa müddətə köçürülür.
    // Sonra yeni kopyalanan qaçışı və daha uzun qaçışı (və ya geri) izləyir, növbəti istehlak olunmayan elementlərini müqayisə edir və daha kiçik (və ya daha böyük) birini `v`-ə kopyalayır.
    //
    // Qısa müddət tam istehlak edildikdə, proses tamamlanır.Daha uzun qaçış əvvəlcə tükənirsə, daha qısa qaçışdan qalanı `v`-də qalan çuxura köçürməliyik.
    //
    // Prosesin orta vəziyyəti həmişə iki məqsədə xidmət edən `hole` tərəfindən izlənir:
    // 1. `v`-in bütövlüyünü `is_less`-də panics-dən qoruyur.
    // 2. Daha uzun müddət əvvəl tükənərsə `v`-də qalan çuxuru doldurur.
    //
    // Panic təhlükəsizliyi:
    //
    // Əgər proses zamanı hər hansı bir nöqtədə `is_less` panics olarsa, `hole` düşəcək və `v`-dəki boşluğu `buf`-də istehlak olunmayan aralıqla dolduracaq və beləliklə `v`-in əvvəlcə tutduğu hər bir obyektin tam olaraq bir dəfə saxlanmasını təmin edəcəkdir.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Sol qaçış daha qısadır.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Başlanğıcda bu göstəricilər massivlərinin başlanğıcını göstərir.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Daha az tərəfi istehlak edin.
            // Bərabər olduqda, sabitliyi qorumaq üçün sol qaçışa üstünlük verin.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Sağ qaçış daha qısadır.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Əvvəlcə bu göstəricilər massivlərinin uclarını göstərir.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Daha böyük tərəfi istehlak edin.
            // Bərabər olduqda, sabitliyi qorumaq üçün düzgün qaçışa üstünlük verin.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Nəhayət, `hole` düşür.
    // Daha qısa müddət tam tükənməsəydi, qalıqları artıq `v`-də olan çuxura köçürüləcəkdir.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Düşdükdə, `start..end` aralığını `dest..`-ə kopyalayır.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` sıfır ölçülü bir növ deyil, buna görə də ölçüsünə bölmək yaxşıdır.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Bu birləşmə növü, [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt)-də ətraflı təsvir olunan TimSort'dan bəzi (lakin hamısı deyil) fikirlər götürür.
///
///
/// Alqoritm təbii qaçışlar adlanan ciddi şəkildə enən və enməyən ardıcıllıqları müəyyənləşdirir.Hələ birləşdirilməli olan gözləyən qaçışlar yığını var.
/// Hər yeni tapılmış qaçış yığının üzərinə sürülür və bu iki dəyişməz qane olanadək bəzi qonşu qaçış cütləri birləşdirilir:
///
/// 1. `1..runs.len()`-də hər `i` üçün: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()`-də hər `i` üçün: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Dəyişməzlər, ümumi işləmə müddətinin *O*(*n*\*log(* n*)) ən pis olduğunu) təmin edir.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Bu uzunluğa qədər dilimlər yerləşdirmə növündən istifadə edərək çeşidlənir.
    const MAX_INSERTION: usize = 20;
    // Ən azı bu qədər elementi əhatə etmək üçün çox qısa qaçışlar yerləşdirmə növündən istifadə edərək uzadılır.
    const MIN_RUN: usize = 10;

    // Sıralamanın sıfır ölçülü növlərdə mənalı davranışı yoxdur.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Qisa massivlər ayırmaların qarşısını almaq üçün yerləşdirmə növü ilə yerində sıralanır.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Sıfırdan yaddaş kimi istifadə etmək üçün bir tampon ayırın.0 uzunluğunu saxlayırıq, beləliklə `is_less` panics olduqda nüsxə üzərində işləyən dtorları riskə atmadan `v`-in tərkibindəki dayaz nüsxələri saxlaya bilərik.
    //
    // İki sıralanmış işləmə birləşdirildikdə, bu tampon hər zaman ən çox `len / 2` uzunluğa sahib olacaq daha qısa müddətin bir nüsxəsini saxlayır.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`-də təbii qaçışları müəyyən etmək üçün onu geriyə keçirik.
    // Bu qəribə bir qərar kimi görünə bilər, ancaq birləşmənin daha tez-tez əks istiqamətdə (forwards)-ə getdiyini düşünün.
    // Qiymətləndiricilərə görə, irəli birləşmək geriyə doğru birləşməkdən biraz daha sürətli olur.
    // Nəticə olaraq, arxadan keçərək qaçışları müəyyənləşdirmək performansı artırır.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Növbəti təbii qaçışı tapın və ciddi şəkildə enirsə, onu dəyişdirin.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Çox qısadırsa, daha çox element əlavə edin.
        // Yerləşdirmə növü, qısa ardıcıllıqla birləşmə sortundan daha sürətli olur, buna görə də performansı əhəmiyyətli dərəcədə yaxşılaşdırır.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Bu qaçışı yığının üzərinə itələyin.
        runs.push(Run { start, len: end - start });
        end = start;

        // İnvariantları təmin etmək üçün bəzi qonşu qaçış cütlərini birləşdirin.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Nəhayət, yığında tam olaraq bir qaçış qalmalıdır.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Qaçışlar yığını araşdırır və birləşmək üçün növbəti qaçış cütlüyünü müəyyənləşdirir.
    // Daha konkret olaraq, `Some(r)` geri qaytarılırsa, bu, `runs[r]` və `runs[r + 1]`-nin birləşdirilməsi lazım olduğunu göstərir.
    // Alqoritm əvəzinə yeni bir işə başlamağa davam edərsə, `None` qaytarılır.
    //
    // TimSort, burada təsvir edildiyi kimi arabalı tətbiqetmələri ilə məşhurdur:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Hekayənin mahiyyəti budur: yığının üstündəki dörd qaçışdakı dəyişməzləri tətbiq etməliyik.
    // Onları yalnız ilk üçlükdə tətbiq etmək, dəyişməzlərin yığının içindəki *bütün* qaçışları davam etdirməsini təmin etmək üçün kifayət deyil.
    //
    // Bu funksiya, dördüncü dövr üçün dəyişməzləri düzgün şəkildə yoxlayır.
    // Əlavə olaraq, ən yaxşı işləmə indeks 0-dan başlayarsa, çeşidi tamamlamaq üçün yığın tamamilə çökənə qədər hər zaman birləşdirmə əməliyyatı tələb edəcəkdir.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}