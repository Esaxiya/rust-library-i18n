//! `Vec<T>` yazılmış yığın ayrılmış məzmunu ilə bitişik böyüyən bir sıra növü.
//!
//! Vectors, `O(1)` indeksləşdirmə, amortizasiya olunmuş `O(1)` basma (sona qədər) və `O(1)` popa (sondan) malikdir.
//!
//!
//! Vectors heç vaxt `isize::MAX` baytdan çox ayırmayacaqlarını təmin edir.
//!
//! # Examples
//!
//! [`Vec::new`] ilə açıq şəkildə bir [`Vec`] yarada bilərsiniz:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ya da [`vec!`] makrosundan istifadə edərək:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // on sıfır
//! ```
//!
//! [`push`] dəyərlərini bir vector-nin sonuna bilər (vector-ni lazım olduqda böyüyəcəkdir):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Yarma dəyərləri eyni şəkildə işləyir:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ([`Index`] və [`IndexMut`] traits vasitəsilə) indeksləşdirməni də dəstəkləyir:
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` kimi yazılmış və 'vector' kimi səslənən bitişik bir böyüyən bir sıra növü.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Başlanğıcın daha rahat olmasını təmin etmək üçün [`vec!`] makrosu təqdim olunur:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Həm də verilmiş bir dəyəri olan bir `Vec<T>`-nin hər bir elementini işə sala bilər.
/// Bu, ayrı-ayrı addımlarda ayırma və başlanğıc işi yerinə yetirməkdən daha təsirli ola bilər, xüsusən sıfırdan bir vector başlatdıqda:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Aşağıdakı ekvivalentdir, lakin potensial olaraq daha yavaşdır:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Daha çox məlumat üçün [Capacity and Reallocation](#capacity-and-reallocation)-ə baxın.
///
/// Effektiv bir yığın olaraq bir `Vec<T>` istifadə edin:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 çap edir
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` növü, dəyərlərə indekslə daxil olmağa imkan verir, çünki [`Index`] trait tətbiq edir.Bir nümunə daha açıq olacaq:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // '2' göstərəcək
/// ```
///
/// Bununla birlikdə diqqətli olun: `Vec`-də olmayan bir indeksə girməyə çalışarsanız, proqramınız panic olacaq!Bunu edə bilməzsiniz:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// İndeksin `Vec`-də olub olmadığını yoxlamaq istəyirsinizsə [`get`] və [`get_mut`] istifadə edin.
///
/// # Slicing
///
/// `Vec` dəyişdirilə bilər.Digər tərəfdən, dilimlər yalnız oxunan obyektlərdir.
/// [slice][prim@slice] əldə etmək üçün [`&`] istifadə edin.Misal:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... və bu hamısı!
/// // bunu belə edə bilərsiniz:
/// let u: &[usize] = &v;
/// // və ya belə:
/// let u: &[_] = &v;
/// ```
///
/// Rust-də dilimləri vectors-dən çox arqument kimi ötürmək daha çox yayılmışdır, sadəcə oxumaq üçün giriş təmin etmək istədiyiniz zaman.Eyni şey [`String`] və [`&str`] üçün də tətbiq olunur.
///
/// # Tutum və yenidən bölüşdürmə
///
/// Bir vector-nin tutumu, vector-yə əlavə ediləcək hər hansı bir future elementi üçün ayrılmış yer miqdarıdır.Bu, vector içərisindəki həqiqi elementlərin sayını göstərən bir vector-nin *uzunluğu* ilə qarışdırılmamalıdır.
/// Bir vector uzunluğu tutumunu aşarsa, tutumu avtomatik olaraq artırılacaq, ancaq elementləri yenidən bölüşdürülməlidir.
///
/// Məsələn, tutumu 10 və uzunluğu 0 olan bir vector, daha 10 element üçün yer olan boş bir vector olardı.10 və ya daha az elementin vector üzərinə basılması onun tutumunu dəyişdirməyəcək və yenidən bölüşdürülmənin baş verməsinə səbəb olmaz.
/// Bununla birlikdə, vector-nin uzunluğu 11-ə qədər artırılarsa, yenidən bölüşdürülməli olacaq, yavaş ola bilər.Bu səbəbdən vector-nin nə qədər böyük olacağını təyin etmək üçün mümkün olduqda [`Vec::with_capacity`] istifadə etməyiniz tövsiyə olunur.
///
/// # Guarantees
///
/// İnanılmaz dərəcədə təməl olması sayəsində `Vec` dizaynı ilə bağlı çox zəmanət verir.Bu, ümumi vəziyyətdə mümkün qədər aşağı hava yükünün olmasını və təhlükəli kodla ibtidai yollarla düzgün şəkildə idarə olunmasını təmin edir.Qeyd edək ki, bu zəmanətlər ixtisaslı olmayan `Vec<T>`-yə aiddir.
/// Əlavə növ parametrləri əlavə edilərsə (məsələn, xüsusi ayırıcıları dəstəkləmək üçün), onların standart parametrlərini ləğv etmək davranışı dəyişdirə bilər.
///
/// Ən əsası `Vec` (göstərici, tutum, uzunluq) üçlüdür və həmişə olacaqdır.Artıq, az deyil.Bu sahələrin sırası tamamilə dəqiqləşdirilməyib və bunları dəyişdirmək üçün uyğun metodlardan istifadə etməlisiniz.
/// Göstərici heç vaxt sıfır olmaz, buna görə də bu tip sıfır göstərici üçün optimize edilmişdir.
///
/// Lakin göstərici əslində ayrılmış yaddaşa işarə edə bilməz.
/// Xüsusilə, [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] vasitəsilə 0 tutumlu bir `Vec` qurarsanız və ya boş bir Vecdə [`shrink_to_fit`] çağırarsanız, yaddaş ayırmaz.Eynilə, bir `Vec` içərisində sıfır ölçülü tipləri saxlasanız, onlar üçün yer ayırmır.
/// *Xatırladaq ki, bu halda `Vec` bir [`capacity`]-i 0* hesabatında göstərə bilməz.
/// `Vec` əgər ayıracaqsa və yalnız [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Ümumiyyətlə, 'Vec`-in ayırma detalları çox incədir-bir `Vec` istifadə edərək yaddaş ayırmaq və başqa bir şey üçün istifadə etmək istəyirsinizsə (ya təhlükəli kodu ötürmək, ya da öz yaddaş dəstəkli kolleksiyanızı yaratmaq üçün), əmin olun `Vec`-i bərpa etmək üçün `from_raw_parts` istifadə edərək və sonra buraxaraq bu yaddaşı ayırmaq.
///
/// Bir `Vec`*-də* ayrılmış yaddaş varsa, işarə etdiyi yaddaş yığındadır (ayırıcı Rust tərəfindən təyin olunduğu kimi varsayılan olaraq istifadə üçün konfiqurasiya edilmişdir) və göstəricisi [`len`] başlanğıcda, bitişik elementləri ardıcıl olaraq göstərir (nə edərdiniz?) onu bir dilimə məcbur etdiyinizə baxın), ardından [`tutum`] '',`[`len`] məntiqi olaraq başlanğıc olunmamış, bitişik elementlər.
///
///
/// Tutumu 4 olan `'a'` və `'b'` elementlərini ehtiva edən bir vector aşağıdakı kimi görünə bilər.Üst hissə `Vec` strukturudur, yığın, uzunluq və tutumdakı bölmənin başlığına bir işarə edir.
/// Alt hissə, bitişik bir yaddaş bloku olan yığındakı ayırmadır.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** başlanğıc edilməmiş yaddaşı təmsil edir, bax [`MaybeUninit`].
/// - Note: ABI sabit deyil və `Vec` yaddaş düzümü ilə bağlı zəmanət vermir (sahələrin sırası daxil olmaqla).
///
/// `Vec` elementlərin əslində iki səbəbə görə yığında saxlandığı bir "small optimization" əsla yerinə yetirməyəcəkdir:
///
/// * Təhlükəli kodun `Vec`-i düzgün şəkildə idarə etməsini daha çətinləşdirəcəkdir.`Vec`-in məzmunu yalnız köçürülsəydi sabit bir ünvana sahib olmazdı və `Vec`-in həqiqətən yaddaş ayırıb-ayırmadığını müəyyənləşdirmək daha çətin olardı.
///
/// * Hər bir girişdə əlavə branch çəkərək ümumi işi cəzalandıracaqdı.
///
/// `Vec` tamamilə boş olsa da, heç vaxt avtomatik olaraq kiçilməyəcəkdir.Bu, lazımsız ayırmaların və ya bölüşdürmələrin baş verməməsini təmin edir.Bir `Vec`-i boşaltın və sonra yenidən eyni [`len`]-ə doldurun, ayırıcıya heç bir zəng edilməməlidir.İstifadəsiz yaddaşı boşaltmaq istəyirsinizsə, [`shrink_to_fit`] və ya [`shrink_to`] istifadə edin.
///
/// [`push`] və [`insert`] bildirilən tutum kifayət edərsə, heç vaxt (yenidən) ayırmayacaqdır.[`push`] və [`insert`]*, [[len`]`==`[`tutum`] olduqda*(yenidən) ayıracaqdır.Yəni bildirilən tutum tamamilə dəqiqdir və etibar etmək olar.İstədiyində `Vec` tərəfindən ayrılmış yaddaşın əl ilə boşaldılması üçün də istifadə edilə bilər.
/// Toplu daxiletmə metodları * lazım olmadıqda belə yenidən bölüşdürülə bilər.
///
/// `Vec` nə dolduğunda yenidən bölüşdürərkən, nə də [`reserve`] çağırıldığında hər hansı bir xüsusi böyümə strategiyasına zəmanət vermir.Mövcud strategiya təməldir və davamlı olmayan böyümə amilindən istifadə etmək arzu oluna bilər.Hansı strategiyadan istifadə olunsa, əlbəttə *O*(1) amortizasiya olunmuş [`push`]-yə zəmanət verəcəkdir.
///
/// `vec![x; n]`, `vec![a, b, c, d]` və [`Vec::with_capacity(n)`][`Vec::with_capacity`], hamısı tam olaraq istənilən gücü ilə bir `Vec` istehsal edəcəkdir.
/// [`Len`]`==`[`tutum`], ([`vec!`] makrosunda olduğu kimi), onda `Vec<T>` elementləri yenidən bölüşdürmədən və ya hərəkət etdirmədən [`Box<[T]>`][owned slice]-ə və ondan çevrilə bilər.
///
/// `Vec` ondan silinmiş hər hansı bir məlumatın üzərinə xüsusi olaraq yazmayacaq, həm də xüsusi olaraq qorumayacaqdır.Başlanğıc olmayan yaddaş, istədiyi halda istifadə edə biləcəyi cızma yeridir.Ümumiyyətlə, ən səmərəli və ya tətbiqi asan olan hər şeyi edəcəkdir.Təhlükəsizlik məqsədi ilə silinəcək məlumatlara etibar etməyin.
/// Bir `Vec` atsanız belə, onun tamponu başqa bir `Vec` tərəfindən yenidən istifadə edilə bilər.
/// Əvvəlcə bir "Vec" yaddaşını sıfırlasanız da, bu həqiqətən baş verməyə bilər, çünki optimizator bunu qorunmalı olan yan təsir saymır.
/// Sındırmayacağımız bir vəziyyət var: `unsafe` kodundan artıq tutuma yazmaq və sonra uyğunluğu artırmaq hər zaman etibarlıdır.
///
/// Hal-hazırda `Vec`, elementlərin düşmə sırasına zəmanət vermir.
/// Sifariş keçmişdə dəyişdi və yenidən dəyişə bilər.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Doğru metodlar
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Yeni, boş bir `Vec<T>` qurur.
    ///
    /// vector elementlər üzərinə itilənə qədər ayırmayacaq.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Müəyyən edilmiş tutumlu yeni, boş bir `Vec<T>` qurur.
    ///
    /// vector tam olaraq `capacity` elementlərini yenidən bölüşdürmədən saxlaya biləcəkdir.
    /// `capacity` 0 olarsa, vector ayrılmaz.
    ///
    /// Qeyd etmək vacibdir ki, qaytarılmış vector göstərilən *tutuma* sahib olsa da, vector sıfır *uzunluğa* sahib olacaqdır.
    ///
    /// Uzunluq və tutum arasındakı fərqin izahı üçün baxın *[Tutum və yenidən bölüşdürmə]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector, daha çox şeyə sahib olmasına baxmayaraq heç bir maddə ehtiva etmir
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Bunların hamısı yenidən bölünmədən edilir ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lakin bu, vector-nin yenidən yerləşməsinə səbəb ola bilər
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Bir başqa vector-nin xam komponentlərindən birbaşa `Vec<T>` yaradır.
    ///
    /// # Safety
    ///
    /// Yoxlanmayan dəyişənlərin sayına görə bu olduqca təhlükəlidir:
    ///
    /// * `ptr` əvvəllər [`String`]/`Vec vasitəsilə ayrılmalıdır<T>"(heç olmasa, olmasaydı səhv olma ehtimalı böyükdür).
    /// * `T` `ptr`-in ayrıldığı ilə eyni ölçüyə və uyğunlaşmaya ehtiyac duyur.
    ///   (Daha az sərt bir hizalamaya sahib olan `T` kifayət deyil, yaddaşın eyni tərtiblə ayrılması və ayrılması lazım olduğu [`dealloc`] tələbini təmin etmək üçün hizalanmanın həqiqətən bərabər olması lazımdır.)
    ///
    /// * `length` `capacity`-dən az və ya bərabər olmalıdır.
    /// * `capacity` göstəricinin ayrıldığı tutum olmalıdır.
    ///
    /// Bunların pozulması, ayırıcının daxili məlumat strukturlarını pozmaq kimi problemlərə səbəb ola bilər.Məsələn, bir göstəricidən `size_t` uzunluğunda bir C `char` massivinə bir `Vec<u8>` qurmaq ** ** təhlükəsiz deyil.
    /// `Vec<u16>`-dən və onun uzunluğundan birini düzəltmək də təhlükəsiz deyil, çünki ayırıcı hizalanma ilə maraqlanır və bu iki növ fərqli hizalara malikdir.
    /// Tampon hizalama 2 ilə (`u16` üçün) ayrıldı, ancaq `Vec<u8>`-ə çevirdikdən sonra hizalama 1 ilə ayrılacaq.
    ///
    /// `ptr`-nin mülkiyyəti, effektiv olaraq `Vec<T>`-ə ötürülür ki, bu da göstəricinin istədiyi kimi göstərilən yaddaşın məzmununu bölüşdürə, yenidən bölüşə və ya dəyişdirə bilər.
    /// Bu funksiyanı çağırdıqdan sonra göstəricidən başqa heç bir şey istifadə etməməsinə əmin olun.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME vec_into_raw_parts sabitləşdikdə bunu yeniləyin.
    ///     // "V" nin destruktorunun işləməsinin qarşısını alın, beləliklə ayırmaya tam nəzarət edirik.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` haqqında müxtəlif vacib məlumatları çəkin
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4, 5, 6 ilə yaddaşın üzərinə yazın
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Hər şeyi yenidən bir Vec-ə qoyun
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Yeni, boş bir `Vec<T, A>` qurur.
    ///
    /// vector elementlər üzərinə itilənə qədər ayırmayacaq.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Təqdim olunan ayırıcı ilə təyin olunmuş tutumu olan yeni, boş bir `Vec<T, A>` qurur.
    ///
    /// vector tam olaraq `capacity` elementlərini yenidən bölüşdürmədən saxlaya biləcəkdir.
    /// `capacity` 0 olarsa, vector ayrılmaz.
    ///
    /// Qeyd etmək vacibdir ki, qaytarılmış vector göstərilən *tutuma* sahib olsa da, vector sıfır *uzunluğa* sahib olacaqdır.
    ///
    /// Uzunluq və tutum arasındakı fərqin izahı üçün baxın *[Tutum və yenidən bölüşdürmə]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector, daha çox şeyə sahib olmasına baxmayaraq heç bir maddə ehtiva etmir
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Bunların hamısı yenidən bölünmədən edilir ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lakin bu, vector-nin yenidən yerləşməsinə səbəb ola bilər
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Bir başqa vector-nin xam komponentlərindən birbaşa `Vec<T, A>` yaradır.
    ///
    /// # Safety
    ///
    /// Yoxlanmayan dəyişənlərin sayına görə bu olduqca təhlükəlidir:
    ///
    /// * `ptr` əvvəllər [`String`]/`Vec vasitəsilə ayrılmalıdır<T>"(heç olmasa, olmasaydı səhv olma ehtimalı böyükdür).
    /// * `T` `ptr`-in ayrıldığı ilə eyni ölçüyə və uyğunlaşmaya ehtiyac duyur.
    ///   (Daha az sərt bir hizalamaya sahib olan `T` kifayət deyil, yaddaşın eyni tərtiblə ayrılması və ayrılması lazım olduğu [`dealloc`] tələbini təmin etmək üçün hizalanmanın həqiqətən bərabər olması lazımdır.)
    ///
    /// * `length` `capacity`-dən az və ya bərabər olmalıdır.
    /// * `capacity` göstəricinin ayrıldığı tutum olmalıdır.
    ///
    /// Bunların pozulması, ayırıcının daxili məlumat strukturlarını pozmaq kimi problemlərə səbəb ola bilər.Məsələn, bir göstəricidən `size_t` uzunluğunda bir C `char` massivinə bir `Vec<u8>` qurmaq ** ** təhlükəsiz deyil.
    /// `Vec<u16>`-dən və onun uzunluğundan birini düzəltmək də təhlükəsiz deyil, çünki ayırıcı hizalanma ilə maraqlanır və bu iki növ fərqli hizalara malikdir.
    /// Tampon hizalama 2 ilə (`u16` üçün) ayrıldı, ancaq `Vec<u8>`-ə çevirdikdən sonra hizalama 1 ilə ayrılacaq.
    ///
    /// `ptr`-nin mülkiyyəti, effektiv olaraq `Vec<T>`-ə ötürülür ki, bu da göstəricinin istədiyi kimi göstərilən yaddaşın məzmununu bölüşdürə, yenidən bölüşə və ya dəyişdirə bilər.
    /// Bu funksiyanı çağırdıqdan sonra göstəricidən başqa heç bir şey istifadə etməməsinə əmin olun.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME vec_into_raw_parts sabitləşdikdə bunu yeniləyin.
    ///     // "V" nin destruktorunun işləməsinin qarşısını alın, beləliklə ayırmaya tam nəzarət edirik.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` haqqında müxtəlif vacib məlumatları çəkin
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4, 5, 6 ilə yaddaşın üzərinə yazın
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Hər şeyi yenidən bir Vec-ə qoyun
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>`-ni xam komponentlərinə ayırır.
    ///
    /// Xam göstəricini əsas məlumatlara, vector uzunluğuna (elementlərdə) və verilənlərin ayrılmış tutumuna (elementlərdə) qaytarır.
    /// Bunlar [`from_raw_parts`] arqumentləri ilə eyni qaydada eyni arqumentlərdir.
    ///
    /// Bu funksiyanı axtardıqdan sonra zəng edən `Vec` tərəfindən əvvəllər idarə olunan yaddaşdan məsuldur.
    /// Bunun yeganə yolu, xam göstəricini, uzunluğu və tutumu [`from_raw_parts`] funksiyası ilə yenidən `Vec`-ə çevirmək və destruktorun təmizləməsini həyata keçirməkdir.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Artıq xam göstəricini uyğun bir tipə çevirmək kimi komponentlərdə dəyişiklik edə bilərik.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>`-ni xam komponentlərinə ayırır.
    ///
    /// Xam göstəricini əsas məlumatlara, vector uzunluğuna (elementlərdə), verilənlərin ayrılmış tutumuna (elementlərdə) və ayırıcıya qaytarır.
    /// Bunlar [`from_raw_parts_in`] arqumentləri ilə eyni qaydada eyni arqumentlərdir.
    ///
    /// Bu funksiyanı axtardıqdan sonra zəng edən `Vec` tərəfindən əvvəllər idarə olunan yaddaşdan məsuldur.
    /// Bunun yeganə yolu, xam göstəricini, uzunluğu və tutumu [`from_raw_parts_in`] funksiyası ilə yenidən `Vec`-ə çevirmək və destruktorun təmizləməsini həyata keçirməkdir.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Artıq xam göstəricini uyğun bir tipə çevirmək kimi komponentlərdə dəyişiklik edə bilərik.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector-nin yenidən bölüşdürmədən saxlaya biləcəyi element sayını qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Verilən `Vec<T>`-ə əlavə ediləcək ən azı `additional` element üçün ehtiyat tutumu.
    /// Kolleksiya tez-tez yenidən bölüşdürməmək üçün daha çox yer ayıra bilər.
    /// `reserve`-ə zəng etdikdən sonra tutum `self.len() + additional`-dən böyük və ya ona bərabər olacaqdır.
    /// Tutumu onsuz da kifayətdirsə heç nə etmir.
    ///
    /// # Panics
    ///
    /// Panics, yeni tutum `isize::MAX` baytdan çox olarsa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Verilən `Vec<T>`-də tam olaraq `additional` daha çox elementin yerləşdirilməsi üçün minimum tutumu qoruyur.
    ///
    /// `reserve_exact`-ə zəng etdikdən sonra tutum `self.len() + additional`-dən böyük və ya ona bərabər olacaqdır.
    /// Tutumu onsuz da kifayətdirsə heç nə etmir.
    ///
    /// Qeyd edək ki, ayırıcı kolleksiyaya istədiyindən daha çox yer verə bilər.
    /// Bu səbəbdən tutumun tam olaraq minimal olduğuna inanmaq olmaz.
    /// future əlavələri gözlənilirsə `reserve`-yə üstünlük verin.
    ///
    /// # Panics
    ///
    /// Panics, yeni tutum `usize`-i aşarsa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Verilən `Vec<T>`-ə ən azı `additional` element əlavə etmək üçün ehtiyat tutmağa çalışır.
    /// Kolleksiya tez-tez yenidən bölüşdürməmək üçün daha çox yer ayıra bilər.
    /// `try_reserve`-ə zəng etdikdən sonra tutum `self.len() + additional`-dən böyük və ya bərabər olacaqdır.
    /// Tutumu onsuz da kifayətdirsə heç nə etmir.
    ///
    /// # Errors
    ///
    /// Tutum aşıbsa və ya ayırıcı bir uğursuzluq barədə məlumat verərsə, bir səhv qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Yaddaşa əvvəlcədən ayırın, bacarmırıqsa çıxırıq
    ///     output.try_reserve(data.len())?;
    ///
    ///     // İndi bilirik ki, bu, kompleks işimizin ortasında OOM ola bilməz
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // çox mürəkkəbdir
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Verilən `Vec<T>`-də tam olaraq `additional` elementlərinin yerləşdirilməsi üçün minimum tutumu saxlamağa çalışır.
    /// `try_reserve_exact`-ə zəng etdikdən sonra, `Ok(())`-yə qayıdırsa, tutum `self.len() + additional`-dən çox və ya ona bərabər olacaqdır.
    ///
    /// Tutumu onsuz da kifayətdirsə heç nə etmir.
    ///
    /// Qeyd edək ki, ayırıcı kolleksiyaya istədiyindən daha çox yer verə bilər.
    /// Bu səbəbdən tutumun tam olaraq minimal olduğuna inanmaq olmaz.
    /// future əlavələri gözlənilirsə `reserve`-yə üstünlük verin.
    ///
    /// # Errors
    ///
    /// Tutum aşıbsa və ya ayırıcı bir uğursuzluq barədə məlumat verərsə, bir səhv qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Yaddaşa əvvəlcədən ayırın, bacarmırıqsa çıxırıq
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // İndi bilirik ki, bu, kompleks işimizin ortasında OOM ola bilməz
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // çox mürəkkəbdir
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector-nin tutumunu mümkün qədər azaldır.
    ///
    /// Uzunluğa mümkün qədər yaxın enəcək, lakin ayırıcı hələ də vector-yə bir neçə element üçün yer olduğunu bildirə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Tutum heç vaxt uzunluqdan az olmur və bərabər olduqda ediləcək bir şey yoxdur, buna görə `RawVec::shrink_to_fit`-dəki panic halını yalnız daha böyük tutumlu çağıraraq qarşısını ala bilərik.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector-nin tutumunu aşağı sərhədlə azaldır.
    ///
    /// Tutum ən azı həm uzunluq, həm də verilən dəyər qədər qalacaq.
    ///
    ///
    /// Mövcud tutum aşağı həddən azdırsa, bu, əlverişsizdir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector-i [`Box<[T]>`][owned slice]-ə çevirir.
    ///
    /// Bunun hər hansı bir artıq tutumu itirəcəyini unutmayın.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Artıq tutum aradan qaldırılır:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// İlk `len` elementlərini saxlayaraq qalan hissəsini ataraq vector-ni qısaldır.
    ///
    /// `len`, vector-nin mövcud uzunluğundan böyükdürsə, bunun heç bir təsiri yoxdur.
    ///
    /// [`drain`] metodu `truncate`-ni təqlid edə bilər, lakin artıq elementlərin düşmə yerinə qaytarılmasına səbəb olur.
    ///
    ///
    /// Bu metodun vector-nin ayrılmış tutumu üzərində heç bir təsiri olmadığını unutmayın.
    ///
    /// # Examples
    ///
    /// Beş element vector-ni iki elementə ayırmaq:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len`, vector-nin cari uzunluğundan böyük olduqda heç bir kəsilmə baş vermir:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0`, [`clear`] metodunu çağırmağa bərabər olduqda kəsilir.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Bu təhlükəsizdir, çünki:
        //
        // * `drop_in_place`-ə keçən dilim etibarlıdır;`len > self.len` işi etibarsız bir dilim yaratmağın qarşısını alır və
        // * vector-nin `len`-si `drop_in_place`-yə zəng vurmadan əvvəl kiçilir, belə ki `drop_in_place`-in bir dəfə panic olması halında heç bir dəyər iki dəfə düşməyəcəkdir (əgər panics iki dəfə olarsa, proqram ləğv olunur).
        //
        //
        //
        unsafe {
            // Note: Qəsdən bunun X001 deyil `>` olmasıdır.
            //       `>=`-ə dəyişdirilməsi bəzi hallarda mənfi performans təsirləri göstərir.
            //       Daha çox məlumat üçün #78884-ə baxın.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Bütün vector-ni ehtiva edən bir dilim çıxarır.
    ///
    /// `&s[..]`-ə bərabərdir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Bütün vector-nin dəyişkən bir dilimini çıxarır.
    ///
    /// `&mut s[..]`-ə bərabərdir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// X0 göstəricisini vector tamponuna qaytarır.
    ///
    /// Zəng edən vector-nin bu funksiyanın geri döndüyü göstəricidən artıq olmasını təmin etməlidir, əks halda zibilə işarə edəcəkdir.
    /// vector-nin dəyişdirilməsi onun tamponunun yenidən bölünməsinə səbəb ola bilər ki, bu da ona işarə edənləri etibarsız hala gətirəcəkdir.
    ///
    /// Zəng edən həm də (non-transitively) göstəricisinin göstərdiyi yaddaşın bu göstəricidən və ya ondan irəli gələn hər hansı bir göstəricidən istifadə edilərək (`UnsafeCell` daxilində) yazılmamasını təmin etməlidir.
    /// Dilimin içindəkiləri mutasiya etməlisinizsə, [`as_mut_ptr`] istifadə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Aralıq bir istinad yaradan `deref`-dən keçməmək üçün eyni adlı dilim metodunu kölgələyirik.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Təhlükəsiz dəyişdirilə bilən bir göstəricini vector tamponuna qaytarır.
    ///
    /// Zəng edən vector-nin bu funksiyanın geri döndüyü göstəricidən artıq olmasını təmin etməlidir, əks halda zibilə işarə edəcəkdir.
    ///
    /// vector-nin dəyişdirilməsi onun tamponunun yenidən bölünməsinə səbəb ola bilər ki, bu da ona işarə edənləri etibarsız hala gətirəcəkdir.
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 element üçün kifayət qədər böyük vector ayırın.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Elementləri xam göstərici yazıları ilə başladın, sonra uzunluğu təyin edin.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Aralıq bir istinad yaradan `deref_mut`-dən keçməmək üçün eyni adlı dilim metodunu kölgələyirik.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Əsas ayırıcıya bir istinad qaytarır.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector uzunluğunu `new_len`-ə məcbur edir.
    ///
    /// Bu tip normal dəyişməzlərin heç birini qorumayan aşağı səviyyəli bir əməliyyatdır.
    /// Normalda bir vector uzunluğunun dəyişdirilməsi, bunun əvəzinə [`truncate`], [`resize`], [`extend`] və ya [`clear`] kimi etibarlı əməliyyatlardan biri istifadə edilir.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`]-dən az və ya bərabər olmalıdır.
    /// - `old_len..new_len`-dəki elementlər başlanğıc vəziyyətinə gətirilməlidir.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Bu metod, vector-nin digər kodlar üçün, xüsusən də FFI üzərində bir tampon kimi xidmət etdiyi hallar üçün faydalı ola bilər:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Bu sənəd nümunəsi üçün yalnız minimal bir skeletdir;
    /// # // bundan həqiqi kitabxana üçün başlanğıc nöqtəsi kimi istifadə etməyin.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI metodunun sənədlərinə əsasən, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // TƏHLÜKƏSİZLİK: `deflateGetDictionary` `Z_OK` qaytardıqda, bunu təmin edir:
    ///     // 1. `dict_length` elementlər işə salındı.
    ///     // 2.
    ///     // `dict_length` <= `set_len`-i zəng etmək üçün təhlükəsiz edən (32_768) tutumu.
    ///     unsafe {
    ///         // FFI-yə zəng edin ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... və başlanğıcın başlanğıcına qədər uzunluğu yeniləyin.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Aşağıdakı nümunə səsli olsa da, daxili vectors `set_len` çağırışından əvvəl azad edilmədiyi üçün yaddaş sızması var:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` boşdur, buna görə heç bir elementin başlanğıc edilməsinə ehtiyac yoxdur.
    /// // 2. `0 <= capacity` həmişə `capacity` nə olursa olsun.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalda, burada məzmunu düzgün bir şəkildə atmaq və beləliklə yaddaşa sızmamaq üçün [`clear`] istifadə ediləcək.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Bir elementi vector-dən çıxarır və qaytarır.
    ///
    /// Çıxarılan element vector-nin son elementi ilə əvəz olunur.
    ///
    /// Bu sifariş qorumur, lakin O(1)-dir.
    ///
    /// # Panics
    ///
    /// `index` hüdudlarından kənarda olduqda Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Self [index]-ni son elementlə əvəz edirik.
            // Qeyd edək ki, yuxarıdakı sərhəd yoxlaması müvəffəq olarsa, son element olmalıdır (özünü [indeks] özü ola bilər).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Bütün elementləri ondan sonra sağa keçirərək vector içərisinə `index` mövqeyində bir element əlavə edir.
    ///
    ///
    /// # Panics
    ///
    /// `index > len` olarsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // yeni element üçün yer
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // məsum Yeni dəyəri qoymaq üçün yer
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Yer açmaq üçün hər şeyi dəyişdirin.
                // (`İndex`th elementinin ardıcıl iki yerə kopyalanması.)
                ptr::copy(p, p.offset(1), len - index);
                // "İndex`th" elementinin ilk nüsxəsinin üstünə yazın.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Elementi vector içərisində `index` mövqeyində çıxarır və geri qaytarır, sonra bütün elementləri sola keçirir.
    ///
    ///
    /// # Panics
    ///
    /// `index` hüdudlarından kənarda olduqda Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // götürdüyümüz yer.
                let ptr = self.as_mut_ptr().add(index);
                // yığın və eyni zamanda vector-də dəyərin bir kopyasına sahib olaraq təhlükəsiz şəkildə çıxarın.
                //
                ret = ptr::read(ptr);

                // O nöqtəni doldurmaq üçün hər şeyi aşağıya çevirin.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Yalnız predikat tərəfindən göstərilən elementləri saxlayır.
    ///
    /// Başqa sözlə, `e`-in `false`-ni qaytarması üçün bütün `e` elementlərini çıxarın.
    /// Bu metod, hər bir elementi orijinal qaydada tam bir dəfə ziyarət edərək yerində işləyir və saxlanılan elementlərin sırasını qoruyur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Elementlər orijinal qaydada dəqiq bir dəfə ziyarət olunduğundan, hansı elementlərin saxlanılacağına qərar vermək üçün xarici vəziyyətdən istifadə edilə bilər.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Damla qoruyucusu icra edilmirsə, ikiqat düşmədən çəkinin, çünki proses zamanı bəzi deşiklər edə bilərik.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-işlənmiş len-> |^-yoxlamanın yanında
        //                  | <-silinmiş cnt-> |
        //      | <-original_len-> |Saxladı: predikat verən elementlər geriyə qayıdır.
        //
        // Delik: Element yuvası köçürüldü və ya düşdü.
        // Yoxlanılmamış: Yoxlanmamış etibarlı elementlər.
        //
        // Bu damla qoruyucusu, predikat və ya `drop` elementi çaxnaşmaya məruz qaldıqda çağırılacaq.
        // Delikləri örtmək üçün yoxlanılmamış elementləri və `set_len`-ni düzgün uzunluğa keçirir.
        // Predikat və `drop`-in heç vaxt panikaya düşmədiyi hallarda, optimallaşdırılacaqdır.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // TƏHLÜKƏSİZLİK: Yoxlanılmayan əşyalar arxada qalmalıdır, çünki onlara heç vaxt toxunmuruq.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // TƏHLÜKƏSİZLİK: Çuxurları doldurduqdan sonra bütün əşyalar bitişik yaddaşdadır.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // TƏHLÜKƏSİZLİK: Seçilməmiş element etibarlı olmalıdır.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` çaxnaşma halında ikiqat düşmənin qarşısını almaq üçün erkən irəliləyin.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // TƏHLÜKƏSİZLİK: Düşdükdən sonra bu elementə bir daha toxunmuruq.
                unsafe { ptr::drop_in_place(cur) };
                // Artıq sayğacı inkişaf etdirdik.
                continue;
            }
            if g.deleted_cnt > 0 {
                // TƏHLÜKƏSİZLİK: `deleted_cnt`> 0, buna görə dəlik yuvası cari elementlə üst-üstə düşməməlidir.
                // Kopyalamaq üçün hərəkət edirik və bu elementə bir daha toxunmayın.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Bütün məhsullar işlənir.Bu LLVM tərəfindən `set_len`-ə uyğunlaşdırıla bilər.
        drop(g);
    }

    /// vector-də eyni açarda həll olunan ilk ardıcıl elementlərdən başqa hamısını silir.
    ///
    ///
    /// vector sıralanırsa, bu bütün dublikatları silər.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Verilmiş bərabərlik münasibətini təmin edən vector-də ardıcıl elementlərdən birincisini xaric edir.
    ///
    /// `same_bucket` funksiyası vector-dən iki elementə istinadlar ötürülür və elementlərin bərabər müqayisə edib-etmədiyini müəyyənləşdirməlidir.
    /// Elementlər dilimdəki sıralarından əks qaydada ötürülür, buna görə `same_bucket(a, b)` `true` qaytararsa, `a` çıxarılır.
    ///
    ///
    /// vector sıralanırsa, bu bütün dublikatları silər.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Kolleksiyanın arxasına bir element əlavə edir.
    ///
    /// # Panics
    ///
    /// Panics, yeni tutum `isize::MAX` baytdan çox olarsa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // > isize::MAX bayt ayırsaq və ya sıfır ölçülü tiplər üçün uzunluq artımı daşsaydı, bu panic və ya ləğv edəcəkdir.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Son elementi vector-dən silib qaytarır və ya boş olduqda [`None`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other`-in bütün elementlərini `Self`-ə köçürür və `other`-i boş buraxır.
    ///
    /// # Panics
    ///
    /// vector-dəki elementlərin sayı bir `usize`-ı aşarsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Digər tampondan elementləri `Self`-ə əlavə edir.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// vector-də göstərilən aralığı aradan qaldıran və çıxarılan əşyaları verən bir boşaltma iteratoru yaradır.
    ///
    /// Təkrarlayıcı ** düşdükdə, təkrarlayıcı tam istehlak olunmasa da, aralıqdakı bütün elementlər vector-dən çıxarılır.
    /// Təkrarlayıcı ** düşməyibsə (məsələn [`mem::forget`] ilə), neçə elementin silindiyi dəqiqləşdirilməyib.
    ///
    /// # Panics
    ///
    /// Panics, başlanğıc nöqtəsi son nöqtədən böyükdürsə və ya son nöqtə vector uzunluğundan böyükdürsə.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Tam bir sıra vector-ni təmizləyir
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Yaddaş təhlükəsizliyi
        //
        // Drain ilk dəfə yaradıldıqda, Drain-nin destruktoru heç vaxt işə düşməsə, başlanğıc olunmamış və ya köçürülən elementlərin ümumiyyətlə əlçatan olmamasına əmin olmaq üçün vector mənbəyinin uzunluğunu qısaldır.
        //
        //
        // Drain silmək üçün dəyərləri ptr::read edəcəkdir.
        // Bitirdikdən sonra vecin qalan quyruğu çuxuru örtmək üçün geri kopyalanır və vector uzunluğu yeni uzunluğa qaytarılır.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // self.vec uzunluğunu təyin edin, Drain sızması halında etibarlı olsun
            self.set_len(start);
            // Bütün Drain iteratorunun borc alma davranışını göstərmək üçün IterMut-da borc istifadə edin (&mut T kimi).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Bütün dəyərləri silərək vector'yi təmizləyir.
    ///
    /// Bu metodun vector-nin ayrılmış tutumu üzərində heç bir təsiri olmadığını unutmayın.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// 'length' olaraq da adlandırılan vector-dəki element sayını qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector elementi olmadıqda `true` qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Verilən indeksdə kolleksiyanı ikiyə ayırır.
    ///
    /// `[at, len)` aralığında elementləri olan yeni ayrılmış vector qaytarır.
    /// Çağırışdan sonra orijinal vector əvvəlki tutumu dəyişmədən `[0, at)` elementlərini ehtiva edəcəkdir.
    ///
    ///
    /// # Panics
    ///
    /// `at > len` olarsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // yeni vector orijinal tamponu götürə bilər və surətinin qarşısını alır
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Təhlükəsiz `set_len` və `other`-ə kopyalayın.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec`-in yerini dəyişdirərək `len`-in `new_len`-ə bərabər olmasını təmin edir.
    ///
    /// `new_len` `len`-dən böyükdürsə, `Vec` fərqlə uzadılır və hər əlavə yuva `f` bağlanmasının çağırılması nəticəsində doldurulur.
    ///
    /// `f`-dən qayıdan dəyərlər yaradıldıqları sırada `Vec`-də başa çatacaqdır.
    ///
    /// `new_len` `len`-dən azdırsa, `Vec` sadəcə kəsilir.
    ///
    /// Bu metod, hər itələmədə yeni dəyərlər yaratmaq üçün bir bağlanma istifadə edir.Verilmiş bir dəyəri [`Clone`] istəsəniz, [`Vec::resize`] istifadə edin.
    /// Dəyərlər yaratmaq üçün [`Default`] trait istifadə etmək istəyirsinizsə, ikinci arqument kimi [`Default::default`] keçə bilərsiniz.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec`-i istehlak edir və sızdırır, məzmuna dəyişkən bir istinad gətirir, `&'a mut [T]`.
    /// Qeyd edək ki, `T` növü seçilmiş ömür boyu `'a`-dən çox olmalıdır.
    /// Tip yalnız statik istinadlara malikdirsə və ya ümumiyyətlə yoxdursa, bu `'static` olaraq seçilə bilər.
    ///
    /// Bu funksiya, [`Box`] üzərindəki [`leak`][Box::leak] funksiyasına bənzəyir, ancaq sızan yaddaşı bərpa etməyin yolu yoxdur.
    ///
    ///
    /// Bu funksiya əsasən proqramın ömrü boyunca qalan məlumatlar üçün faydalıdır.
    /// Geri qaytarılan istinadın atılması yaddaş sızıntısına səbəb olacaqdır.
    ///
    /// # Examples
    ///
    /// Sadə istifadə:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// `MaybeUninit<T>` dilimi olaraq vector-nin qalan ehtiyat tutumunu qaytarır.
    ///
    /// Geri qaytarılan dilim vector-ı məlumatlarla doldurmaq üçün istifadə edilə bilər (məsələn
    /// məlumatları [`set_len`] metodundan istifadə edərək başlanğıc kimi qeyd etməzdən əvvəl).
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 element üçün kifayət qədər böyük vector ayırın.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // İlk 3 elementi doldurun.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector-nin ilk 3 elementini başlanğıc olaraq qeyd edin.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Tampon üçün göstəricilərin etibarsız olmasının qarşısını almaq üçün bu metod `split_at_spare_mut` baxımından tətbiq edilmir.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector məzmunu,`MaybeUninit<T>` dilimi olaraq vector-nin qalan ehtiyat tutumu ilə birlikdə `T` dilimi olaraq qaytarır.
    ///
    /// Geri qaytarılmış ehtiyat tutumu dilimi, məlumatları [`set_len`] metodundan istifadə edərək başlanğıc olaraq qeyd etməzdən əvvəl vector-i məlumatlarla doldurmaq üçün istifadə edilə bilər (məsələn, bir sənəddən oxuyaraq).
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Qeyd edək ki, bu, optimallaşdırma məqsədləri üçün ehtiyatla istifadə olunmalı olan aşağı səviyyəli bir API.
    /// `Vec`-ə məlumat əlavə etməyiniz lazımdırsa, dəqiq ehtiyaclarınıza görə [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] və ya [`resize_with`] istifadə edə bilərsiniz.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 element üçün kifayət qədər böyük əlavə yer ayırın.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Növbəti 4 elementi doldurun.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector-nin 4 elementini başlanğıc olaraq qeyd edin.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len nəzərə alınmır və buna görə heç vaxt dəyişdirilmir
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Təhlükəsizlik: qaytarılmış .2 (&mut usize) dəyişdirmə `.set_len(_)` çağırmaqla eyni sayılır.
    ///
    /// Bu metod `extend_from_within`-də bir anda bütün vec hissələrinə unikal bir giriş əldə etmək üçün istifadə olunur.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` elementləri üçün etibarlı olmasına zəmanət verilir
        // - `spare_ptr` bir elementi buferin yanından keçirir, ona görə də `initialized` ilə üst-üstə düşmür
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec`-in yerini dəyişdirərək `len`-in `new_len`-ə bərabər olmasını təmin edir.
    ///
    /// `new_len` `len`-dən böyükdürsə, `Vec` fərqlə uzadılır və hər əlavə yuva `value` ilə doldurulur.
    ///
    /// `new_len` `len`-dən azdırsa, `Vec` sadəcə kəsilir.
    ///
    /// Bu metod, ötürülmüş dəyəri klonlaya bilmək üçün [`Clone`] tətbiq etməsi üçün `T` tələb edir.
    /// Daha çox rahatlığa ehtiyacınız varsa (və ya [`Clone`] əvəzinə [`Default`]-ə etibar etmək istəyirsinizsə), [`Vec::resize_with`] istifadə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Bütün elementləri bir dilimdə klonlayır və `Vec`-ə əlavə edir.
    ///
    /// Dilim `other` üzərində təkrarlanır, hər elementi klonlayır və sonra bu `Vec`-ə əlavə edir.
    /// `other` vector ardıcıllıqla keçir.
    ///
    /// Bu funksiyanın [`extend`] ilə eyni olduğunu, bunun əvəzinə dilimlərlə işləmək üçün ixtisaslaşmış olduğunu unutmayın.
    ///
    /// Rust ixtisaslaşdıqda və nə vaxt bu funksiya ləğv ediləcək (lakin hələ də mövcuddur).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` elementlərini vector-nin sonuna qədər kopyalayır.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` verilmiş aralığın özünü indeksləşdirmək üçün etibarlı olmasını təmin edir
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Bu kod `extend_with_{element,default}`-i ümumiləşdirir.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Verilən generatordan istifadə edərək vector-i `n` dəyərləri ilə uzatın.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Derleyicinin `ptr`-dən self.set_len()-yə qədər təxəllüs etmədiyi mağazanı həyata keçirə bilməyəcəyi səhvləri işləmək üçün SetLenOnDrop istifadə edin.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Sonuncusu xaricində bütün elementləri yazın
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics vəziyyətində hər addımda uzunluğu artırın
                local_len.increment_len(1);
            }

            if n > 0 {
                // Son elementi lüzumsuz bir şəkildə klonlaşdırmadan birbaşa yaza bilərik
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len əhatə dairəsi tərəfindən təyin edilmişdir
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait tətbiqinə görə vector-də ardıcıl təkrarlanan elementləri silir.
    ///
    ///
    /// vector sıralanırsa, bu bütün dublikatları silər.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Daxili metodlar və funksiyalar
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` etibarlı bir indeks olmalıdır
    /// - `self.capacity() - self.len()` `>= src.len()` olmalıdır
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len yalnız elementləri işə saldıqdan sonra artır
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - zəng edən src-nin etibarlı bir göstərici olduğunu təsdiqləyir
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element yalnız `MaybeUninit::write` ilə işə salındı, buna görə leni artırmaq yaxşıdır
            // - sızıntının qarşısını almaq üçün hər elementdən sonra len artırılır (bax #82533 nömrəsinə)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - zəng edən `src`-nin etibarlı bir indeks olduğunu söyləyir
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Hər iki göstərici bənzərsiz dilim istinadlarından ("&mut [_]") yaradılmışdır, beləliklə etibarlıdır və üst-üstə düşmür.
            //
            // - Elementlər bunlardır: Kopyalayın, buna görə orijinal dəyərlərlə heç bir şey etmədən onları kopyalamaq yaxşıdır
            // - `count` `source` len-ə bərabərdir, buna görə də `count` oxumaq üçün etibarlıdır
            // - `.reserve(count)` `spare.len() >= count`-nin bu qədər ehtiyatın `count` yazıları üçün etibarlı olmasını təmin edir
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementlər yalnız `copy_nonoverlapping` tərəfindən işə salındı
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec üçün ümumi trait tətbiqetmələri
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) ilə bu metod tərifi üçün tələb olunan x01X metodu mövcud deyil.
    // Bunun əvəzinə yalnız cfg(test) NB ilə mövcud olan `slice::to_vec` funksiyasından istifadə edin daha çox məlumat üçün slice.rs-də slice::hack moduluna baxın
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // yazılmayacaq bir şey buraxın
        self.truncate(other.len());

        // self.len <= other.len yuxarıdakı kəsik səbəbiylə buradakı dilimlər həmişə məhduddur.
        //
        let (init, tail) = other.split_at(self.len());

        // olan dəyərləri yenidən istifadə edin allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// İstehlakçı bir iterator yaradır, yəni hər bir dəyəri vector-dən kənarlaşdıran (başlanğıcdan sona qədər).
    /// vector buna zəng etdikdən sonra istifadə edilə bilməz.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // lərin &String deyil, növü var
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // müxtəlif SpecFrom/SpecExtend tətbiqetmələrinin tətbiq ediləcək daha çox optimallaşdırma olmadığı zaman nümayəndə olduqları yarpaq üsulu
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Bu ümumi iterator üçün belədir.
        //
        // Bu funksiya aşağıdakıların mənəvi ekvivalenti olmalıdır:
        //
        //      iteratordakı element üçün {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Ünvan boşluğu ayırmaq məcburiyyətində qaldığımız üçün NB aça bilməz
                self.set_len(len + 1);
            }
        }
    }

    /// vector-də göstərilən diapazonu verilmiş `replace_with` iteratoru ilə əvəzləyən və çıxarılan elementləri verən bir ekləmə iteratoru yaradır.
    ///
    /// `replace_with` `range` ilə eyni uzunluğa ehtiyac yoxdur.
    ///
    /// `range` iterator sona qədər tükənməsə də çıxarılır.
    ///
    /// `Splice` dəyəri sızsa, vector-dən neçə element çıxarıldığı dəqiqləşdirilməyib.
    ///
    /// `replace_with` giriş iteratoru yalnız `Splice` dəyəri düşdükdə istehlak olunur.
    ///
    /// Bu optimaldır:
    ///
    /// * Quyruq (`range`-dən sonra vector-dəki elementlər) boşdur,
    /// * və ya `replace_with`, "aralığın" uzunluğundan az və ya bərabər element verir
    /// * ya da `size_hint()`-nin alt sərhədi dəqiqdir.
    ///
    /// Əks təqdirdə, müvəqqəti bir vector ayrılır və quyruq iki dəfə köçürülür.
    ///
    /// # Panics
    ///
    /// Panics, başlanğıc nöqtəsi son nöqtədən böyükdürsə və ya son nöqtə vector uzunluğundan böyükdürsə.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Elementin silinib-çıxarılmamasını müəyyənləşdirmək üçün qapanmadan istifadə edən təkrarlayıcı yaradır.
    ///
    /// Bağlama doğru qayıdırsa, element çıxarılır və verilmişdir.
    /// Bağlanma səhv olaraq dönərsə, element vector-də qalacaq və təkrarlayıcı tərəfindən verilməyəcəkdir.
    ///
    /// Bu metoddan istifadə aşağıdakı kodla bərabərdir:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kodunuz burada
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ancaq `drain_filter`-in istifadəsi daha asandır.
    /// `drain_filter` massivin elementlərini toplu şəkildə dəyişdirə biləcəyi üçün daha səmərəlidir.
    ///
    /// `drain_filter`-in filtr bağlamasında saxlamağınızdan və ya silməyinizdən asılı olmayaraq hər elementi mutasiya etməyə imkan verdiyini unutmayın.
    ///
    ///
    /// # Examples
    ///
    /// Bir massivi cütlərə və nisbətlərə bölmək, orijinal ayırmanı yenidən istifadə etmək:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Sızmağımızdan qoruyun (sızma gücləndirilməsi)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Vec-ə basmadan əvvəl elementləri istinadlardan çıxaran tətbiqetməni genişləndirin.
///
/// Bu tətbiq dilim təkrarlayıcıları üçün ixtisaslaşdırılmışdır, burada [`copy_from_slice`]-dən bütün dilimi bir anda əlavə etmək üçün istifadə edir.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors müqayisəsini həyata keçirir, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors sifarişini həyata keçirir, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] üçün damla istifadə vector elementlərini ən zəif lazımlı növ kimi göstərmək üçün xam bir dilim istifadə edin;
            //
            // müəyyən hallarda etibarlılıq suallarından çəkinə bilər
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec bölüşdürmə işlərini idarə edir
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Boş bir `Vec<T>` yaradır.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test burada səhvlərə səbəb olan libstd-ni çəkir
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test burada səhvlərə səbəb olan libstd-ni çəkir
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>`-un bütün məzmununu bir sıra olaraq alır, əgər onun ölçüsü tələb olunan massivlə tam uyğun gəlirsə.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Uzunluq uyğun gəlmirsə, giriş `Err`-də geri qayıdır:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Yalnız `Vec<T>` prefiksini almaqla yaxşısınızsa, əvvəlcə [`.truncate(N)`](Vec::truncate)-ə zəng edə bilərsiniz.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // TƏHLÜKƏSİZLİK: `.set_len(0)` həmişə sağlamdır.
        unsafe { vec.set_len(0) };

        // TƏHLÜKƏSİZLİK: Bir `Vec` göstəricisi həmişə düzgün bir şəkildə hizalanır və
        // massivin ehtiyac duyduğu hizalama maddələrlə eynidir.
        // Əvvəllər yoxladıq ki, kifayət qədər məhsulumuz var.
        // `set_len`, `Vec`-ə onları atmamağı söylədiyindən əşyalar ikiqat düşməyəcəkdir.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}