use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Mənbə ayırmasını təkrar istifadə edərkən bir iterator boru kəmərini bir Vec-ə yığmaq üçün ixtisaslaşma işarəsi, yəni
/// boru kəmərinin yerinə yetirilməsi.
///
/// SourceIter ana trait, yenidən istifadə ediləcək ayırmaya daxil olmaq üçün ixtisaslaşmış funksiya üçün lazımdır.
/// Ancaq ixtisasın etibarlı olması üçün kifayət deyil.
/// Çıxışda əlavə sərhədlərə baxın.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std daxili SourceIter/InPlaceIterable traits yalnız Adapter zəncirləri tərəfindən həyata keçirilir <Adapter<Adapter<IntoIter>>> (hamısı core/std-ə məxsusdur).
// Adapter tətbiqetmələrindəki əlavə məhdudiyyətlər (`impl<I: Trait> Trait for Adapter<I>`-dən çox) yalnız traits (Copy, TrustedRandomAccess, FusedIterator) kimi ixtisaslaşmış digər traits-dən asılıdır.
//
// I.e. marker istifadəçi tərəfindən verilən növlərin ömründən asılı deyil.Bir neçə digər ixtisasın onsuz da asılı olduğu Kopyalama çuxurunu modullayın.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds vasitəsilə ifadə edilə bilməyən əlavə tələblər.Bunun əvəzinə const eval-ə etibar edirik:
        // a) təkrar istifadə üçün bir ayırma olmayacağı və panic olacağı üçün ZST olmaması b) Alloc müqaviləsinin tələb etdiyi ölçü ilə uyğunlaşmaq c) Alloc müqaviləsinin tələb etdiyi kimi uyğunlaşma
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // daha ümumi tətbiqetmələrə qayıtmaq
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // bəri sınayın
        // - bəzi iterator adapterləri üçün daha yaxşı vektorlaşdırır
        // - əksər daxili təkrarlama metodlarından fərqli olaraq, yalnız bir &mut özünü tələb edir
        // - yazma işarəçisini içəriyə keçirtməyimizə və sonunda geri qaytarmağımıza imkan verir
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // təkrarlama uğurlu oldu, başınızı aşağı salmayın
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter müqaviləsinin qorunub saxlanmadığını yoxlayın: əgər olmasaydılar, bu nöqtəyə gələ bilmərik
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable müqaviləsini yoxlayın.Bu yalnız təkrarlayıcı mənbə göstəricisini ümumiyyətlə inkişaf etdirdiyi təqdirdə mümkündür.
        // TrustedRandomAccess vasitəsi ilə yoxlanılmamış girişdən istifadə edərsə, mənbə göstəricisi ilkin vəziyyətində qalacaq və biz onu istinad kimi istifadə edə bilmərik
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // Qalan dəyərləri mənbənin quyruğuna atın, ancaq bir dəfə IntoIter, panics düşməsi əhatəsindən çıxsa, ayrılmanın özünün düşməsinin qarşısını alın, sonra dst_buf-da toplanan elementləri də sızdırırıq.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable müqaviləsi burada dəqiq bir şəkildə təsdiqlənə bilməz, çünki try_fold mənbə göstəricisinə müstəsna istinad edir, edə biləcəyimiz tək şey onun hələ də məsafədə olduğunu yoxlamaqdır.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}