//! # Rust əsas ayırma və kolleksiyalar kitabxanası
//!
//! Bu kitabxana yığın ayrılmış dəyərləri idarə etmək üçün ağıllı göstəricilər və kolleksiyalar təqdim edir.
//!
//! Bu kitabxana, libcore kimi, normal olaraq birbaşa istifadə edilməsinə ehtiyac yoxdur, çünki məzmunu [`std` crate](../std/index.html)-də yenidən ixrac olunur.
//! `#![no_std]` atributunu istifadə edən Crates, ümumiyyətlə `std`-dən asılı olmayacaq, buna görə də bunun əvəzinə bu crate-dən istifadə edəcəklər.
//!
//! ## Qutulu dəyərlər
//!
//! [`Box`] tipi ağıllı bir göstərici növüdür.Yalnız bir [`Box`] sahibi ola bilər və sahibi yığın üzərində yaşayan məzmunu dəyişdirməyə qərar verə bilər.
//!
//! Bu tip bir `Box` dəyərinin ölçüsü bir göstəricinin ölçüsü ilə eyni olduğundan təsirli şəkildə mövzuları arasında göndərilə bilər.
//! Ağaca bənzər məlumat strukturları tez-tez qutularla düzəldilir, çünki hər bir düyünün çox vaxt yalnız bir sahibi var.
//!
//! ## İstinad göstəriciləri sayıldı
//!
//! [`Rc`] növü, bir mövzu daxilində yaddaşın bölüşülməsi üçün nəzərdə tutulmuş, təhlükəsiz olmayan bir istinad sayılan göstərici növüdür.
//! [`Rc`] göstəricisi `T` tipini sarar və yalnız paylaşılan bir istinad olan `&T`-ə giriş imkanı verir.
//!
//! Bu növ, irsi dəyişkənlik (məsələn, [`Box`] istifadə) bir tətbiq üçün çox məhdud olduqda faydalıdır və mutasiyaya icazə vermək üçün tez-tez [`Cell`] və ya [`RefCell`] növləri ilə cütləşir.
//!
//!
//! ## Atomik sayılan göstəricilərə istinad
//!
//! [`Arc`] tipi, [`Rc`] tipinin işgüzar ekvivalentidir.[`Rc`]-in eyni funksiyasını təmin edir, yalnız `T` tipinin paylaşıla bilməsi tələb olunmur.
//! Əlavə olaraq, [`Arc<T>`][`Arc`] özü göndərilə bilər, [`Rc<T>`][`Rc`] deyil.
//!
//! Bu tip, mövcud məlumatlara ortaq giriş imkanı verir və paylaşılan mənbələrin mutasiyasına imkan vermək üçün tez-tez mutexes kimi sinxronizasiya primitivləri ilə cütləşir.
//!
//! ## Collections
//!
//! Ən çox yayılmış ümumi təyinatlı məlumat strukturlarının tətbiqləri bu kitabxanada müəyyən edilmişdir.[standard collections library](../std/collections/index.html) vasitəsilə yenidən ixrac olunurlar.
//!
//! ## Yığın interfeysləri
//!
//! [`alloc`](alloc/index.html) modulu, aşağı səviyyəli interfeysi standart qlobal ayırıcıya təyin edir.Libc ayırıcı API ilə uyğun deyil.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Texniki cəhətdən bu, rustdoc-da bir səhvdir: rustdoc, `#[lang = slice_alloc]` bloklarındakı sənədləri `&[T]` üçün görür və bu xüsusiyyəti `core`-də istifadə edən sənədlərə malikdir və xüsusiyyət qapısının effektiv olmadığına görə dəli olur.
// İdeal olaraq, digər crates sənədləri üçün xüsusiyyət qapısını yoxlamaq olmaz, ancaq bu yalnız lang elementləri üçün görünə biləcəyi üçün düzəltməyə dəyməz.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Bu kitabxananın sınanmasına icazə verin

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Digər modullar tərəfindən istifadə edilən daxili makrolarla modul (digər modullardan əvvəl daxil edilməlidir).
#[macro_use]
mod macros;

// Yığıncaqlar aşağı səviyyəli ayırma strategiyaları üçün nəzərdə tutulmuşdur

pub mod alloc;

// Yuxarıdakı yığınlardan istifadə edilən ibtidai növlər

// Test cfg-də qurarkən lang-maddələrin təkrarlanmasının qarşısını almaq üçün `boxed.rs`-dən modu şərti olaraq təyin etməlisiniz;həm də kodun `use boxed::Box;` bəyannamələrinə sahib olmasına icazə vermək lazımdır.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}