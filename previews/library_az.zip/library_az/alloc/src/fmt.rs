//! Formatlaşdırma və çap üçün köməkçi proqramlar `String`s.
//!
//! Bu modul, [`format!`] sintaksis uzantısı üçün işləmə müddətini dəstəkləyir.
//! Bu makro, iş vaxtı arqumentləri simlərə formatlaşdırmaq üçün bu modula çağırışlar yaymaq üçün kompilyatorda tətbiq olunur.
//!
//! # Usage
//!
//! [`format!`] makrosunun C-nin `printf`/`fprintf` funksiyalarından və ya Python-nin `str.format` funksiyasından gələnlərə tanış olması nəzərdə tutulur.
//!
//! [`format!`] uzantısına bəzi nümunələr:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" aparıcı sıfırlar ilə
//! ```
//!
//! Bunlardan ilk arqumentin format sətri olduğunu görə bilərsiniz.Tərtibçi tərəfindən bunun bir simli hərfi olması tələb olunur;ötürülmüş bir dəyişən ola bilməz (etibarlılıq yoxlanışını həyata keçirmək üçün).
//! Bundan sonra tərtibçi format sətrini təhlil edəcək və verilən arqumentlər siyahısının bu format sətrinə keçmək üçün uyğun olub olmadığını müəyyən edəcəkdir.
//!
//! Tək bir dəyəri bir simli çevirmək üçün [`to_string`] metodundan istifadə edin.Bu, [`Display`] formatlaşdırma trait istifadə edəcəkdir.
//!
//! ## Mövqe parametrləri
//!
//! Hər bir formatlaşdırma arqumentinin hansı dəyər arqumentinə istinad etdiyini təyin etməsinə icazə verilir və buraxıldığı təqdirdə "the next argument" olduğu qəbul edilir.
//! Məsələn, `{} {} {}` format sətri üç parametr götürəcək və onlar verildiyi qaydada formatlanacaqdı.
//! Format sətri `{2} {1} {0}`, arqumentləri tərs qaydada biçimləndirəcəkdir.
//!
//! İki növ mövqeli spesifikatorları qarışdırmağa başladıqdan sonra işlər bir az çətinləşə bilər."next argument" göstəricisi arqument üzərində təkrarlayıcı kimi qəbul edilə bilər.
//! Hər dəfə bir "next argument" göstəricisi görünəndə təkrarlayıcı irəliləyir.Bu belə bir davranışa səbəb olur:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Arqument üzərində daxili iterator ilk `{}` göründüyü vaxta qədər inkişaf etdirilməyib, ona görə də ilk arqumenti yazdırır.Sonra ikinci `{}`-ə çatdıqdan sonra təkrarlayıcı ikinci arqumentə keçdi.
//! Əslində, arqumentlərini açıq şəkildə adlandıran parametrlər, mövqe göstəriciləri baxımından arqument adlandırmayan parametrləri təsir etmir.
//!
//! Bütün dəlilləri istifadə etmək üçün bir format sətri tələb olunur, əks halda bu tərtib zamanı səhvidir.Format sətrində eyni arqumentə bir dəfədən çox müraciət edə bilərsiniz.
//!
//! ## Adı verilən parametrlər
//!
//! Rust-nin özündə Python-a bənzər parametrlərin bir funksiyaya ekvivalenti yoxdur, lakin [`format!`] makrosu, adlandırılmış parametrlərdən yararlanmağa imkan verən bir sintaksis uzantısıdır.
//! Adı verilən parametrlər arqument siyahısının sonunda verilmişdir və sintaksisə malikdir:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Məsələn, aşağıdakı [`format!`] ifadələrində hamısı adlı arqument istifadə olunur:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Adları olan mübahisələrdən sonra mövqe parametrlərinin (adları olmayanların) qoyulması düzgün deyil.Mövqe parametrləri kimi, format sətri tərəfindən istifadə olunmayan adlandırılmış parametrlərin verilməsi etibarlı deyil.
//!
//! # Parametrlərin formatlanması
//!
//! Formatlaşdırılan hər bir arqument bir sıra formatlama parametrləri ilə dəyişdirilə bilər ([the syntax](#syntax))-də `format_spec`-ə uyğun gəlir. Bu parametrlər formatlandıqların sətir təmsilçiliyinə təsir göstərir.
//!
//! ## Width
//!
//! ```
//! // Bütün bunlar "Hello x !" çap edir
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Bu formatın qəbul etməsi lazım olan "minimum width" üçün bir parametrdir.
//! Dəyərin sətri bu qədər simvolu doldurmursa, fill/alignment tərəfindən göstərilən dolğunluq lazımi yeri tutmaq üçün istifadə olunur (aşağıya bax).
//!
//! Genişlik üçün dəyər, ikinci arqumentin eni təyin edən bir [`usize`] olduğunu göstərərək `$` postfiksi əlavə etməklə parametrlər siyahısına [`usize`] kimi də verilə bilər.
//!
//! Dollar sintaksisinin mübahisəsinə istinad etmək "next argument" sayğacını təsir etmir, buna görə arqumentlərə mövqelərə istinad etmək və ya adlanan arqumentlərdən istifadə etmək adətən yaxşıdır.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! İsteğe bağlı doldurma xarakteri və hizalama normal olaraq [`width`](#width) parametri ilə birlikdə verilir.`width`-dən əvvəl, dərhal `:`-dən sonra müəyyənləşdirilməlidir.
//! Bu, formatlanan dəyərin `width`-dən kiçik olduqda, ətrafına əlavə simvolların yazıldığını göstərir.
//! Doldurma müxtəlif hizalamalar üçün aşağıdakı variantlarda verilir:
//!
//! * `[fill]<` - arqument `width` sütunlarında sola düzəldilmişdir
//! * `[fill]^` - arqument `width` sütunlarında mərkəzə uyğunlaşdırılır
//! * `[fill]>` - arqument `width` sütunlarında sağa düzəldilmişdir
//!
//! Sayısal olmayan üçün standart [fill/alignment](#fillalignment) boşluqdur və sola hizalanır.Rəqəmsal formatlaşdırıcılar üçün standart bir boşluq xarakteridir, lakin sağa uyğunlaşdırma ilə.
//! Rəqəmlər üçün `0` bayrağı (aşağıya bax) təyin olunduqda, dolğunluq işarəsi `0`-dir.
//!
//! Hizalanmanın bəzi növlər tərəfindən həyata keçirilə bilməyəcəyini unutmayın.Xüsusilə, `Debug` trait üçün ümumiyyətlə tətbiq edilmir.
//! Dolgu tətbiq olunmasının yaxşı bir yolu, girişinizi formatlaşdırmaqdır, sonra nəticəni əldə etmək üçün bu sətri doldurun:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Salam Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Bunların hamısı formatlaşdırıcının davranışını dəyişdirən bayraqlardır.
//!
//! * `+` - Bu ədədi növlər üçün nəzərdə tutulub və işarənin hər zaman çap olunmalı olduğunu göstərir.Pozitiv işarələr heç vaxt standart olaraq yazılmır və mənfi işarələr yalnız `Signed` trait üçün standart olaraq yazdırılır.
//! Bu bayraq hər zaman düzgün işarənin (`+` və ya `-`) yazdırılmalı olduğunu göstərir.
//! * `-` - Hal hazırda istifadə olunmur
//! * `#` - Bu bayraq "alternate" çap formasından istifadə edilməli olduğunu göstərir.Alternativ formalar:
//!     * `#?` - [`Debug`] formatını olduqca yaxşı çap edin
//!     * `#x` - bir `0x` ilə mübahisədən əvvəl
//!     * `#X` - bir `0x` ilə mübahisədən əvvəl
//!     * `#b` - bir `0b` ilə mübahisədən əvvəl
//!     * `#o` - `0o` ilə mübahisədən əvvəl
//! * `0` - Bu, tam formatlar üçün `width`-ə doldurulmanın həm `0` işarəsi ilə edilməli olduğunu, həm də işarələrdən xəbərdar olduğunu göstərmək üçün istifadə olunur.
//! `{:08}` kimi bir format tam `1` üçün `00000001`, eyni format isə `-1` tam üçün `-0000001` verəcəkdir.
//! Diqqət yetirin ki, mənfi versiyada müsbət versiyadan bir sıfır daha azdır.
//!         Doldurma sıfırlarının hər zaman işarədən sonra (varsa) və rəqəmlərdən əvvəl yerləşdirildiyini unutmayın.`#` bayrağı ilə birlikdə istifadə edildikdə, bənzər bir qayda tətbiq olunur: doldurma sıfırları prefiksdən sonra rəqəmlərdən əvvəl əlavə edilir.
//!         Prefiks ümumi genişliyə daxil edilmişdir.
//!
//! ## Precision
//!
//! Sayısal olmayan növlər üçün bu bir "maximum width" hesab edilə bilər.
//! Nəticədə sətir bu genişlikdən uzundursa, bu qədər simvol qədər kəsilir və bu parametrlər təyin olunarsa, kəsilmiş dəyər müvafiq `fill`, `alignment` və `width` ilə yayılır.
//!
//! İntegral növlər üçün bu nəzərə alınmır.
//!
//! Üzən nöqtə növləri üçün bu, onluq nöqtədən sonra neçə rəqəmin yazılmalı olduğunu göstərir.
//!
//! İstədiyiniz `precision`-i göstərməyin üç yolu var:
//!
//! 1. Tam bir `.N`:
//!
//!    tam `N` özü dəqiqdir.
//!
//! 2. Bir tam və ya ad, ardından `.N$` dollar işarəsi:
//!
//!    format *argument*`N` (bir `usize` olmalıdır) kimi dəqiq istifadə edin.
//!
//! 3. Bir ulduz `.*`:
//!
//!    `.*` bu `{...}`-nin bir deyil,*iki* formatlı girişlə əlaqəli olduğu deməkdir: birinci giriş `usize` dəqiqliyini, ikincisi isə yazdırmaq üçün dəyəri saxlayır.
//!    Qeyd edək ki, bu halda `{<arg>:<spec>.*}` format sətrindən istifadə olunursa, `<arg>` hissəsi yazdırmaq üçün* dəyərinə * istinad edir və `precision` `<arg>`-dən əvvəlki girişə daxil olmalıdır.
//!
//! Məsələn, aşağıdakı zənglərin hamısı `Hello x is 0.01000` ilə eyni şeyi yazdırır:
//!
//! ```
//! // Salam {arg 0 ("x")} {arg 1 (0.01) with precision specified inline (5)}-dir
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Salam {arg 1 ("x")} {arg 2 (0.01) with precision specified in arg 0 (5)}-dir
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Salam {arg 0 ("x")} {arg 2 (0.01) with precision specified in arg 1 (5)}-dir
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Salam {next arg ("x")} {second of next two args (0.01) with precision specified in first of next two args (5)}-dir
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Salam {next arg ("x")} {arg 2 (0.01) with precision specified in its predecessor (5)}-dir
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Salam {next arg ("x")} {arg "number" (0.01) with precision specified in arg "prec" (5)}-dir
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Halbuki bunlar:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! üç fərqli şey çap edin:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Bəzi proqramlaşdırma dillərində simli formatlama funksiyalarının davranışı əməliyyat sisteminin lokal parametrlərindən asılıdır.
//! Rust-nin standart kitabxanasının təqdim etdiyi format funksiyaları heç bir yerli konsepsiya daşımır və istifadəçi konfiqurasiyasından asılı olmayaraq bütün sistemlərdə eyni nəticələr verəcəkdir.
//!
//! Məsələn, sistem kodu nöqtə xaricində onluq ayırıcı istifadə etsə də, aşağıdakı kod həmişə `1.5` yazdıracaqdır.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! `{` və `}` hərfi simvolları eyni simvolla əvvəlcədən sətrə daxil etmək olar.Məsələn, `{` karakteri `{{` ilə, `}` xarakteri `}}` ilə qaçır.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Xülasə etmək üçün burada format simlərinin tam qrammatikasını tapa bilərsiniz.
//! İstifadə olunan formatlaşdırma dili üçün sintaksis digər dillərdən götürülmüşdür, buna görə çox yad olmamalıdır.Mübahisələr Python kimi sintaksis ilə formatlanır, yəni arqumentlər C kimi `%` əvəzinə `{}` ilə əhatə olunur.
//! Formatlaşdırma sintaksisinin həqiqi qrammatikası:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Yuxarıda göstərilən qrammatikada `text` heç bir `'{'` və ya `'}'` simvol ehtiva edə bilməz.
//!
//! # Formatlaşdırma traits
//!
//! Bir arqumentin müəyyən bir növlə formatlanmasını tələb edərkən, həqiqətən bir arqumentin müəyyən bir trait-yə aid edilməsini tələb edirsiniz.
//! Bu, bir çox faktiki növün `{:x}` ([`i8`] və [`isize`] kimi) vasitəsilə formatlanmasına imkan verir.traits-yə növlərin cari xəritəsi:
//!
//! * *heç bir şey* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` Lower kiçik onaltılı tam ədədlərlə [`Debug`]
//! * `X?` Upper Böyük hərfli onaltılı tam ədədlərlə [`Debug`]
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Bunun mənası budur ki, [`fmt::Binary`][`Binary`] trait tətbiq edən hər hansı bir mübahisə növü daha sonra `{:b}` ilə formatlana bilər.Bu traits üçün standart kitabxana tərəfindən bir sıra ibtidai növlər üçün tətbiqetmələr təmin edilmişdir.
//!
//! Heç bir format göstərilmirsə (`{}` və ya `{:6}`-də olduğu kimi), istifadə olunan trait formatı [`Display`] trait-dir.
//!
//! Öz tipiniz üçün trait formatını tətbiq edərkən imza metodunu tətbiq etməlisiniz:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // bizim xüsusi növümüz
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Növünüz `self` referans olaraq qəbul ediləcək və sonra funksiya `f.buf` axınına nəticə çıxarmalıdır.Tələb olunan formatlaşdırma parametrlərinə düzgün əməl etmək hər trait formatında tətbiqetmədədir.
//! Bu parametrlərin dəyərləri [`Formatter`] strukturunun sahələrində veriləcəkdir.Buna kömək etmək üçün [`Formatter`] strukturu bəzi köməkçi metodlar da təqdim edir.
//!
//! Əlavə olaraq, bu funksiyanın qaytarma dəyəri [`Nəticə ']` <(), `[` std: : fmt::Error`]`>` tip bir təxəllüsü olan [`fmt::Result`]-dir.
//! Formatlaşdırma tətbiqetmələri [`Formatter`]-dən səhvlərin yayılmasını təmin etməlidir (məsələn, [`write!`] çağırarkən).
//! Bununla birlikdə səhvləri heç vaxt yalançı şəkildə qaytarmamalıdırlar.
//! Yəni, bir formatlaşdırma tətbiqi, yalnız ötürülmüş [`Formatter`] bir səhv qaytararsa bir səhv verməlidir və verə bilər.
//! Bunun səbəbi, funksiya imzasının təklif edə biləcəyinin əksinə olaraq, simli formatlaşdırma səhvsiz bir əməliyyatdır.
//! Bu funksiya yalnız bir nəticə verir, çünki əsas axını yazmaq uğursuz ola bilər və yığının ehtiyat hissəsində bir səhv meydana gəldiyini yaymağın bir yolunu təmin etməlidir.
//!
//! traits formatlamasını həyata keçirmək üçün bir nümunə belə görünür:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` dəyəri `Write` trait-ni tətbiq edir, yazmaq budur!makro gözləyir.
//!         // Qeyd edək ki, bu formatlama simləri formatlaşdırmaq üçün verilən müxtəlif bayraqları məhəl qoymur.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Fərqli traits bir növün müxtəlif çıxış formalarına imkan verir.
//! // Bu formatın mənası bir vector böyüklüyünü çap etməkdir.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Formatter obyektindəki `pad_integral` köməkçi metodundan istifadə edərək formatlama bayraqlarına hörmət edin.
//!         // Ətraflı məlumat üçün metod sənədinə baxın və `pad` funksiyası dizələri doldurmaq üçün istifadə edilə bilər.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Bu iki formatlaşdırma traits-nin fərqli məqsədləri var:
//!
//! - [`fmt::Display`][`Display`] tətbiqetmələr, növün hər zaman bir UTF-8 simli kimi sədaqətlə təmsil oluna biləcəyini iddia edir.Bütün növlərin [`Display`] trait tətbiq etməsi ** gözlənilmir.
//! - [`fmt::Debug`][`Debug`] tətbiqetmələr **bütün** ictimai növlər üçün həyata keçirilməlidir.
//!   Çıxış ümumiyyətlə daxili vəziyyəti mümkün qədər sədaqətlə təmsil edəcəkdir.
//!   [`Debug`] trait-in məqsədi Rust kodunun səhvini asanlaşdırmaqdır.Əksər hallarda `#[derive(Debug)]` istifadə etmək kifayətdir və tövsiyə olunur.
//!
//! Hər iki traits-dən çıxan bəzi nümunələr:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Əlaqəli makrolar
//!
//! [`format!`] ailəsində bir sıra əlaqəli makrolar var.Hal-hazırda həyata keçirilənlər bunlardır:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Bu və [`writeln!`] format sətrini müəyyən bir axına yaymaq üçün istifadə olunan iki makrodur.Bu format sətirlərinin aralıq ayırmalarının qarşısını almaq və nəticəni birbaşa yazmaq üçün istifadə olunur.
//! Başlıq altında, bu funksiya həqiqətən [`std::io::Write`] trait-də müəyyənləşdirilmiş [`write_fmt`] funksiyasını işə salır.
//! Nümunə istifadə:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Bu və [`println!`] öz çıxışlarını stdout-ə yayır.[`write!`] makrosuna bənzər şəkildə, bu makroların məqsədi çıktıları çap edərkən ara ayırmalardan qaçınmaqdır.Nümunə istifadə:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] və [`eprintln!`] makroları [`print!`] və [`println!`] ilə eynidır, yalnız stderr-ə çıxışları xaricindədir.
//!
//! ### `format_args!`
//!
//! Bu format sətrini təsvir edən qeyri-şəffaf bir obyektin ətrafında təhlükəsiz keçmək üçün istifadə olunan maraqlı bir makrodur.Bu obyektin yaradılması üçün hər hansı bir yığın ayırması tələb olunmur və yalnız yığındakı məlumatlara istinad edilir.
//! Başlıq altında, əlaqədar bütün makrolar bu baxımdan həyata keçirilir.
//! Birincisi, bəzi nümunə istifadəsi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] makrosunun nəticəsi [`fmt::Arguments`] tipli bir dəyərdir.
//! Bu quruluş daha sonra format simli işləmək üçün bu modulun içərisindəki [`write`] və [`format`] funksiyalarına ötürülə bilər.
//! Bu makronun məqsədi, formatlaşdırma simləri ilə işləyərkən aralıq ayırmaların daha da qarşısını almaqdır.
//!
//! Məsələn, qeyd kitabxanası standart formatlaşdırma sintaksisindən istifadə edə bilər, lakin nəticənin hara getməli olduğu müəyyənləşənə qədər bu strukturun içərisindən keçər.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format` funksiyası bir [`Arguments`] strukturunu alır və nəticədə formatlanmış sətri qaytarır.
///
///
/// [`Arguments`] nümunəsi [`format_args!`] makrosu ilə yaradıla bilər.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format!`]-dən istifadənin daha yaxşı ola biləcəyini unutmayın.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}