//! Yığın ayrılması üçün göstərici növü.
//!
//! [`Box<T>`], təsadüfən bir 'box' olaraq adlandırılan Rust-də ən sadə yığın formasını təmin edir.Qutular bu ayırma üçün mülkiyyət təmin edir və əhatə dairəsindən çıxdıqda məzmunu buraxır.Qutular ayrıca heç vaxt `isize::MAX` baytdan çox ayırmayacaqlarını təmin edir.
//!
//! # Examples
//!
//! [`Box`] yaradaraq bir dəyəri yığından yığına köçürün:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Bir dəyəri [`Box`]-dən [dereferencing] ilə yığına geri köçürün:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Rekursiv bir məlumat strukturu yaratmaq:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Bu "Cons (1, Cons(2, Nil))`.
//!
//! Rekursiv strukturlar qutuda olmalıdır, çünki `Cons` tərifi belə görünürsə:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Bu işə yaramazdı.Bunun səbəbi bir `List` ölçüsünün siyahıda neçə elementin olmasından asılı olmasıdır və bu səbəbdən bir `Cons` üçün nə qədər yaddaş ayıracağımızı bilmirik.Müəyyən edilmiş bir ölçülü bir [`Box<T>`] təqdim edərək, `Cons`-in nə qədər böyük olacağını bilirik.
//!
//! # Yaddaş düzeni
//!
//! Sıfır olmayan ölçülü dəyərlər üçün [`Box`], ayırması üçün [`Global`] ayırıcısını istifadə edəcəkdir.[`Box`] və [`Global`] ayırıcısı ilə ayrılmış xam bir göstərici arasında hər iki yolu çevirmək üçün etibarlıdır, çünki ayırıcı ilə istifadə olunan [`Layout`] tip üçün düzgündür.
//!
//! Daha doğrusu, `Layout::for_value(&*value)` ilə [`Global`] ayırıcı ilə ayrılmış bir `value:* mut T`, [`Box::<T>::from_raw(value)`] istifadə edərək bir qutuya çevrilə bilər.
//! Əksinə, [`Box::<T>::into_raw`]-dən alınan bir `value:*mut T`-i dəstəkləyən yaddaş, [`Layout::for_value(&* value)`] ilə [`Global`] ayırıcı istifadə edilərək bölüşdürülə bilər.
//!
//! Sıfır ölçülü dəyərlər üçün `Box` göstəricisi oxumaq və yazmaq üçün hələ də [valid] olmalıdır və kifayət qədər hizalanır.
//! Xüsusilə, hər hansı bir hizalanmış sıfır olmayan tam ədədi xammal göstəriciyə tökmək etibarlı bir göstərici əmələ gətirir, lakin əvvəllər ayrılmış yaddaşa yönəlmiş bir göstərici etibarlı deyil.
//! `Box::new` istifadə edilə bilməyəcəyi təqdirdə ZST-ə bir qutu qurmağın tövsiyə olunan yolu [`ptr::NonNull::dangling`] istifadə etməkdir.
//!
//! `T: Sized` olduğu müddətdə, bir `Box<T>`-in tək bir göstərici kimi təmsil olunmasına zəmanət verilir və eyni zamanda C göstəriciləri ilə ABI ilə uyğundur (yəni C tipi `T*`).
//! Bu o deməkdir ki, C-dən çağırılacaq xarici "C" Rust funksiyalarınız varsa, `Box<T>` tiplərindən istifadə edərək həmin Rust funksiyalarını müəyyənləşdirə və C tərəfində uyğun tip olaraq `T*` istifadə edə bilərsiniz.
//! Nümunə olaraq, bir növ `Foo` dəyərini yaradan və məhv edən funksiyaları elan edən bu C başlığını nəzərdən keçirin:
//!
//! ```c
//! /* C başlığı */
//!
//! /* Sahibliyi zəng edənə qaytarır */
//! struct Foo* foo_new(void);
//!
//! /* Zəng edəndən mülkiyyət alır;NULL ilə çağırıldıqda op-op */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Bu iki funksiya Rust-də aşağıdakı kimi həyata keçirilə bilər.Burada C-dən `struct Foo*` növü, mülkiyyət məhdudiyyətlərini tutan `Box<Foo>`-ə çevrilir.
//! `foo_delete` ilə əlaqələndirilə bilən arqumentin Rust-da `Option<Box<Foo>>` olaraq təmsil olunduğuna da diqqət yetirin, çünki `Box<Foo>` sıfır ola bilməz.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! `Box<T>`, C göstəricisi ilə eyni təqdimata və C ABI-yə sahib olsa da, bu, təsadüfi bir `T*`-i bir `Box<T>`-ə çevirə biləcəyiniz və işlərin işləyəcəyini gözlədiyiniz anlamına gəlmir.
//! `Box<T>` dəyərlər həmişə tamamilə hizalanacaq, boş olmayan göstəricilər olacaqdır.Bundan əlavə, `Box<T>` üçün destruktor qlobal ayırıcı ilə dəyəri azad etməyə çalışacaq.Ümumiyyətlə, ən yaxşı təcrübə yalnız qlobal ayırıcıdan yaranan göstəricilər üçün `Box<T>` istifadə etməkdir.
//!
//! **Vacibdir.** Heç olmasa, C dilində müəyyən edilmiş, lakin Rust-dən çağırılan funksiyalar üçün `Box<T>` növlərindən istifadə etməməlisiniz.Bu hallarda C tiplərini mümkün qədər yaxından əks etdirməlisiniz.
//! C tərifinin yalnız `T*` istifadə etdiyi `Box<T>` kimi növlərin istifadəsi, [rust-lang/unsafe-code-guidelines#198][ucg#198]-də təsvir edildiyi kimi müəyyən edilməmiş davranışa səbəb ola bilər.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Yığın ayrılması üçün göstərici növü.
///
/// Daha çox məlumat üçün [module-level documentation](../../std/boxed/index.html)-ə baxın.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Yığıncaqda yaddaş ayırır və sonra `x` yerləşdirir.
    ///
    /// `T` sıfır ölçülüdürsə, bu, həqiqətən ayrılmaz.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Başlanmamış məzmunu olan yeni bir qutu qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Yaddaş `0` baytla doldurularaq, başlanğıc olunmamış məzmunu olan yeni bir `Box` qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Yeni bir `Pin<Box<T>>` qurur.
    /// `T` `Unpin` tətbiq etmirsə, `x` yaddaşa sabitlənəcək və köçürülə bilməz.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Yığıncaqda yaddaş ayırır, sonra `x` yerləşdirir və ayırma uğursuz olarsa bir səhv qaytarır
    ///
    ///
    /// `T` sıfır ölçülüdürsə, bu, həqiqətən ayrılmaz.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Yığındakı başlanğıc edilməmiş məzmunu olan yeni bir qutu qurur, ayırma uğursuz olarsa bir səhv qaytarır
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Yaddaş yığındakı `0` baytla doldurularaq, başlanğıc olunmamış məzmunu olan yeni bir `Box` qurur
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Verilən ayırıcıda yaddaş ayırır və sonra `x` yerləşdirir.
    ///
    /// `T` sıfır ölçülüdürsə, bu, həqiqətən ayrılmaz.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Verilən ayırıcıda yaddaş ayırır və sonra `x` yerləşdirir, ayırma uğursuz olarsa bir səhv qaytarır
    ///
    ///
    /// `T` sıfır ölçülüdürsə, bu, həqiqətən ayrılmaz.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Təqdim olunan ayırıcıda başlanmamış məzmunu olan yeni bir qutu qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Bağlanmanın bəzən cizgi çəkilməməsi səbəbindən matçı unwrap_or_else-dən üstün tutun.
        // Kod ölçüsünü daha da böyüdər.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Təqdim olunan ayırıcıda başlanğıc olunmamış məzmunu olan yeni bir qutu qurur və ayırma uğursuz olarsa bir səhv qaytarır
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Təqdim olunan ayırıcıda yaddaş `0` baytla doldurularaq, başlanğıc olunmamış məzmunu olan yeni bir `Box` qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Bağlanmanın bəzən cizgi çəkilməməsi səbəbindən matçı unwrap_or_else-dən üstün tutun.
        // Kod ölçüsünü daha da böyüdər.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Təqdim olunan ayırıcıda yaddaş `0` baytla doldurulmaqla, başlanğıc olunmamış məzmunu ilə yeni bir `Box` qurur və ayırma uğursuz olarsa bir səhv qaytarır,
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Yeni bir `Pin<Box<T, A>>` qurur.
    /// `T` `Unpin` tətbiq etmirsə, `x` yaddaşa sabitlənəcək və köçürülə bilməz.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>`-i `Box<[T]>`-ə çevirir
    ///
    /// Bu dönüşüm yığına ayrılmır və yerində olur.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Sarılmış dəyəri qaytararaq `Box`-i istehlak edir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Başlanmamış məzmunu olan yeni bir qutulu dilim qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Yaddaş `0` baytla doldurulmuş, başlanğıc olunmamış məzmunu olan yeni bir qutulu dilim qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Təqdim olunan ayırıcıda başlanmamış məzmunu olan yeni bir qutulu dilim qurur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Yaddaş `0` baytla doldurularaq təmin edilmiş ayırıcıda başlanğıc olunmamış məzmunu olan yeni qutulu bir dilim qurur.
    ///
    ///
    /// Bu metodun düzgün və səhv istifadəsi nümunələri üçün [`MaybeUninit::zeroed`][zeroed]-ə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>`-ə çevrilir.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-də olduğu kimi, dəyərin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında bunun adlandırılması dərhal təyin olunmayan davranışa səbəb olur.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>`-ə çevrilir.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-də olduğu kimi, dəyərlərin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında bunun adlandırılması dərhal təyin olunmayan davranışa səbəb olur.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Təxirə salınmış başlatma:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Xam bir göstəricidən bir qutu düzəldir.
    ///
    /// Bu funksiyanı çağırdıqdan sonra, xam göstərici ortaya çıxan `Box`-ə məxsusdur.
    /// Xüsusi olaraq, `Box` destruktoru `T`-in destruktorunu çağıracaq və ayrılmış yaddaşı boşaldacaqdır.
    /// Bunun təhlükəsiz olması üçün yaddaş `Box` tərəfindən istifadə olunan [memory layout]-ə uyğun olaraq ayrılmış olmalıdır.
    ///
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki düzgün olmayan istifadə yaddaş problemlərinə səbəb ola bilər.
    /// Məsələn, funksiya eyni xam göstəricidə iki dəfə çağırılsa, ikiqat sərbəstlik meydana çıxa bilər.
    ///
    /// Təhlükəsizlik şərtləri [memory layout] bölməsində təsvir edilmişdir.
    ///
    /// # Examples
    ///
    /// [`Box::into_raw`] istifadə edərək əvvəllər xam göstəriciyə çevrilmiş bir `Box` yaradın:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Qlobal ayırıcıdan istifadə edərək sıfırdan əl ilə bir `Box` yaradın:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Ümumiyyətlə .write, `ptr`-in əvvəlki (uninitialized) məzmununun məhv edilməsinə cəhd edilməməsi üçün tələb olunur, lakin bu sadə nümunə üçün `*ptr = 5` də işləyəcəkdi.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Verilmiş ayırıcıda xammal göstəricidən bir qutu düzəldir.
    ///
    /// Bu funksiyanı çağırdıqdan sonra, xam göstərici ortaya çıxan `Box`-ə məxsusdur.
    /// Xüsusi olaraq, `Box` destruktoru `T`-in destruktorunu çağıracaq və ayrılmış yaddaşı boşaldacaqdır.
    /// Bunun təhlükəsiz olması üçün yaddaş `Box` tərəfindən istifadə olunan [memory layout]-ə uyğun olaraq ayrılmış olmalıdır.
    ///
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki düzgün olmayan istifadə yaddaş problemlərinə səbəb ola bilər.
    /// Məsələn, funksiya eyni xam göstəricidə iki dəfə çağırılsa, ikiqat sərbəstlik meydana çıxa bilər.
    ///
    /// # Examples
    ///
    /// [`Box::into_raw_with_allocator`] istifadə edərək əvvəllər xam göstəriciyə çevrilmiş bir `Box` yaradın:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Sistem ayırıcısını istifadə edərək sıfırdan əl ilə bir `Box` yaradın:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Ümumiyyətlə .write, `ptr`-in əvvəlki (uninitialized) məzmununun məhv edilməsinə cəhd edilməməsi üçün tələb olunur, lakin bu sadə nümunə üçün `*ptr = 5` də işləyəcəkdi.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box`-i istehlak edir, bükülmüş xam göstəricini qaytarır.
    ///
    /// Göstərici düzgün hizalanacaq və sıfır olmayacaq.
    ///
    /// Bu funksiyanı axtardıqdan sonra zəng edən `Box` tərəfindən əvvəllər idarə olunan yaddaşdan məsuldur.
    /// Xüsusilə, zəng edən `Box` tərəfindən istifadə olunan [memory layout] nəzərə alınaraq `T`-i düzgün şəkildə məhv etməli və yaddaşı buraxmalıdır.
    /// Bunun ən asan yolu, `Box` destruktorunun təmizləməsini həyata keçirməsinə imkan verən xam göstəricini [`Box::from_raw`] funksiyası ilə yenidən `Box`-ə çevirməkdir.
    ///
    ///
    /// Note: bu əlaqəli bir funksiyadır, yəni `b.into_raw()` əvəzinə `Box::into_raw(b)` adlandırmalısınız.
    /// Bu, daxili tipdəki bir metodla heç bir ziddiyyət olmaması üçündür.
    ///
    /// # Examples
    /// Xam göstəricini avtomatik təmizləmə üçün [`Box::from_raw`] ilə yenidən `Box`-ə çevirmək:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Dağıdıcıyı açıq şəkildə işə salmaq və yaddaşın ayrılması ilə əl ilə təmizləmə:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box`-i istehlak edir, bükülmüş xam göstəricini və ayırıcıyı qaytarır.
    ///
    /// Göstərici düzgün hizalanacaq və sıfır olmayacaq.
    ///
    /// Bu funksiyanı axtardıqdan sonra zəng edən `Box` tərəfindən əvvəllər idarə olunan yaddaşdan məsuldur.
    /// Xüsusilə, zəng edən `Box` tərəfindən istifadə olunan [memory layout] nəzərə alınaraq `T`-i düzgün şəkildə məhv etməli və yaddaşı buraxmalıdır.
    /// Bunun ən asan yolu, `Box` destruktorunun təmizləməsini həyata keçirməsinə imkan verən xam göstəricini [`Box::from_raw_in`] funksiyası ilə yenidən `Box`-ə çevirməkdir.
    ///
    ///
    /// Note: bu əlaqəli bir funksiyadır, yəni `b.into_raw_with_allocator()` əvəzinə `Box::into_raw_with_allocator(b)` kimi çağırmalısınız.
    /// Bu, daxili tipdəki bir metodla heç bir ziddiyyət olmaması üçündür.
    ///
    /// # Examples
    /// Xam göstəricini avtomatik təmizləmə üçün [`Box::from_raw_in`] ilə yenidən `Box`-ə çevirmək:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Dağıdıcıyı açıq şəkildə işə salmaq və yaddaşın ayrılması ilə əl ilə təmizləmə:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box, Yığılmış Borclar tərəfindən "unique pointer" olaraq tanınır, lakin daxili olaraq tip sistemi üçün xam göstəricidir.
        // Doğrudan xam bir göstəriciyə çevirmək "releasing" yalnış xammal girişlərinə icazə verən unikal göstərici kimi tanınmayacaq, buna görə bütün xam göstərici metodları `Box::leak`-dən keçməlidir.
        //
        // *Bu* nu xam bir göstəriciyə çevirmək düzgün davranır.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Əsas ayırıcıya bir istinad qaytarır.
    ///
    /// Note: bu əlaqəli bir funksiyadır, yəni `b.allocator()` əvəzinə `Box::allocator(&b)` kimi çağırmalısınız.
    /// Bu, daxili tipdəki bir metodla heç bir ziddiyyət olmaması üçündür.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box`-i istehlak edir və sızdırır, dəyişdirilə bilən bir referansı qaytarır, `&'a mut T`.
    /// Qeyd edək ki, `T` növü seçilmiş ömür boyu `'a`-dən çox olmalıdır.
    /// Tip yalnız statik istinadlara malikdirsə və ya ümumiyyətlə yoxdursa, bu `'static` olaraq seçilə bilər.
    ///
    /// Bu funksiya əsasən proqramın ömrü boyunca qalan məlumatlar üçün faydalıdır.
    /// Geri qaytarılan istinadın atılması yaddaş sızıntısına səbəb olacaqdır.
    /// Bu məqbul deyilsə, istinad əvvəlcə `Box` istehsal edən [`Box::from_raw`] funksiyası ilə bükülməlidir.
    ///
    /// Daha sonra bu `Box` atıla bilər ki, bu da `T`-i düzgün şəkildə məhv edəcək və ayrılmış yaddaşı buraxacaqdır.
    ///
    /// Note: bu əlaqəli bir funksiyadır, yəni `b.leak()` əvəzinə `Box::leak(b)` kimi çağırmalısınız.
    /// Bu, daxili tipdəki bir metodla heç bir ziddiyyət olmaması üçündür.
    ///
    /// # Examples
    ///
    /// Sadə istifadə:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Ölçüsüz məlumatlar:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>`-i `Pin<Box<T>>`-ə çevirir
    ///
    /// Bu dönüşüm yığına ayrılmır və yerində olur.
    ///
    /// Bu [`From`] vasitəsilə də mövcuddur.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` olduqda `Pin<Box<T>>`-in içərisini hərəkət etdirmək və ya dəyişdirmək mümkün deyil, buna görə əlavə tələblər olmadan birbaşa sancmaq təhlükəsizdir.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Heç bir şey etmə, düşmə hazırda kompilyator tərəfindən həyata keçirilir.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// T üçün `Default` dəyəri ilə bir `Box<T>` yaradır.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Bu qutunun tərkibindəki `clone()` ilə yeni bir qutu qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Dəyər eynidir
    /// assert_eq!(x, y);
    ///
    /// // Ancaq bunlar unikal obyektlərdir
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Klonlanmış dəyəri birbaşa yazmağa imkan vermək üçün əvvəlcədən yaddaş ayırın.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Yeni bir ayırma yaratmadan "mənbənin" məzmununu `self`-ə köçürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Dəyər eynidir
    /// assert_eq!(x, y);
    ///
    /// // Və heç bir ayrılma baş vermədi
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // bu məlumatların bir nüsxəsini çıxarır
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Ümumi bir `T` tipini bir `Box<T>`-ə çevirir
    ///
    /// Dönüşüm yığına ayrılır və `t`-ı yığından içərisinə keçir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>`-i `Pin<Box<T>>`-ə çevirir
    ///
    /// Bu dönüşüm yığına ayrılmır və yerində olur.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]`-i `Box<[T]>`-ə çevirir
    ///
    /// Bu dönüşüm yığına ayırır və `slice`-nin bir nüsxəsini yerinə yetirir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // bir qutu yaratmaq üçün istifadə ediləcək&[u8] yaradın <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str`-i `Box<str>`-ə çevirir
    ///
    /// Bu dönüşüm yığına ayırır və `s`-nin bir nüsxəsini yerinə yetirir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>`-i `Box<[u8]>`-ə çevirir
    /// Bu dönüşüm yığına ayrılmır və yerində olur.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // bir qutu yaradın<str>bir qutu yaratmaq üçün istifadə olunacaq <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // bir qutu yaratmaq üçün istifadə ediləcək&[u8] yaradın <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]`-i `Box<[T]>`-ə çevirir
    /// Bu dönüşüm massivi yeni yığılmış yaddaşa köçürür.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Qutunu konkret bir növə salmaq cəhdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Qutunu konkret bir növə salmaq cəhdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Qutunu konkret bir növə salmaq cəhdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Daxili Uniq-i birbaşa Qutudan çıxarmaq mümkün deyil, bunun əvəzinə Unique-yə xas olan * const-a atırıq
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Varsayılan əvəzinə `last()` tətbiqini istifadə edən ölçülü "I" lər üçün ixtisas.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}