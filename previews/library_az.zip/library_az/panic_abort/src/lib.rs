//! Rust panics-nin proses ləğvi yolu ilə tətbiqi
//!
//! Açma yolu ilə tətbiqetmə ilə müqayisədə bu crate *çox* daha sadədir!Deyilənə görə, o qədər də çox yönlü deyil, amma burada!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" yüklənmə və sözügedən platformadakı müvafiq abortla əlaqələndirin.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal-ə zəng edin
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows-də, prosessora xas olan __fastfail mexanizmindən istifadə edin.Windows 8 və sonrakı dövrlərdə, bu, hər hansı bir əməliyyatda istisna işləyicilərini işə salmadan prosesi dərhal dayandıracaqdır.
            // Windows-in əvvəlki versiyalarında bu təlimat ardıcıllığı, prosesi sonlandıran, lakin bütün istisna işləyicilərindən mütləq yan keçmədən giriş pozuntusu kimi qəbul ediləcəkdir.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: bu libstd-nin `abort_internal`-dəki kimi tətbiqdir
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Bu ... biraz qəribədir.Tl; dr;bunun düzgün bir şəkildə bağlanması üçün tələb olunduğudur, daha uzun izahat aşağıdadır.
//
// Hal-hazırda göndərdiyimiz libcore/libstd ikili sənədlərinin hamısı `-C panic=unwind` ilə tərtib edilmişdir.Bu, ikili sənədlərin mümkün qədər çox vəziyyətə uyğun olmasını təmin etmək üçün edilir.
// Bununla yanaşı, kompilyator `-C panic=unwind` ilə tərtib edilmiş bütün funksiyalar üçün "personality function" tələb edir.Bu şəxsiyyət funksiyası `rust_eh_personality` simvolu ilə kodlaşdırılır və `eh_personality` lang elementi ilə müəyyən edilir.
//
// So...
// niyə yalnız bu lang maddəsini burada müəyyənləşdirməyək?Yaxşı sual!panic iş vaxtlarının bir-birinə bağlanma tərzi əslində biraz incədir, çünki kompilyatorun crate mağazasında "sort of", ancaq başqa birinin həqiqətən əlaqəli olmadığı təqdirdə əlaqələndirilir.
//
// Bu, həm bu crate, həm də panic_unwind crate-nin kompilyatorun crate mağazasında görünə biləcəyi mənasını verir və hər ikisi `eh_personality` lang elementini təyin edərsə, o zaman səhv olur.
//
// Bu işi yerinə yetirmək üçün kompilyatorun yalnız bağlanması lazım olan panic işləmə vaxtı olduğu təqdirdə `eh_personality`-in müəyyənləşdirilməsini tələb edir və əks halda onun təyin olunması tələb olunmur (haqlı olaraq).
// Bu halda, bu kitabxana yalnız bu simvolu müəyyənləşdirir, belə ki, bir yerdə ən azı bir şəxsiyyət var.
//
// Əslində bu simvol libcore/libstd ikili sənədlərə qoşulmaq üçün yalnız müəyyənləşdirilmişdir, lakin heç vaxt açılmayan iş vaxtı arasında əlaqə yaratmadığımız üçün heç vaxt buna çağırmamalıyıq.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu-də bütün kadrlarımızı ötürərkən `ExceptionContinueSearch`-i qaytarmalı olan öz şəxsiyyət funksiyamızdan istifadə edirik.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Yuxarıdakı kimi, bu, hazırda yalnız Emscripten-də istifadə olunan `eh_catch_typeinfo` lang elementinə cavab verir.
    //
    // panics istisnalar yaratmadığından və xarici istisnalar hazırda -C panic=abort ilə UB olduğundan (bu dəyişə bilər), istənilən catch_unwind zəngləri heç vaxt bu tip məlumatı istifadə etməyəcəkdir.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Bu ikisini i686-pc-windows-gnu-dəki başlanğıc obyektlərimiz adlandırırlar, lakin cəsədlərin nops olması üçün bir şey etmələrinə ehtiyac yoxdur.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}