// rsbegin.o və rsend.o sözdə "compiler runtime startup objects"-dir.
// Tərtibçi iş vaxtını düzgün şəkildə başlatmaq üçün lazım olan kodu ehtiva edirlər.
//
// Yürütülə bilən və ya dylib bir şəkil əlaqələndirildikdə, bütün istifadəçi kodları və kitabxanaları bu iki obyekt dosyası arasında "sandwiched" olur, buna görə rsbegin.o-dən kod və ya məlumatlar görüntünün müvafiq hissələrində birinci olur, kod və rsend.o-dən olanlar sonuncusu olur.
// Bu effekt bir hissənin əvvəlində və ya sonunda simvollar yerləşdirmək, həmçinin istənilən başlıqları və ya altbilgiləri daxil etmək üçün istifadə edilə bilər.
//
// Həqiqi modul giriş nöqtəsinin C işləmə vaxtı başlanğıc obyektində (adətən `crtX.o` adlanır) yerləşdiyini və daha sonra digər iş vaxtı komponentlərinin başlatma çağırışlarını (başqa bir xüsusi şəkil bölməsi ilə qeydiyyatdan keçirildiyini) çağırır.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Yığın çərçivəsinin başlanğıcını açın məlumat hissəsini açın
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Açıqcının daxili mühasibat uçotu üçün yer cızın.
    // $ GCC/unwind-dw2-fde.h-də `struct object` olaraq təyin olunur.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // registration/deregistration rutinlərini açın.
    // Libpanic_unwind sənədlərinə baxın.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // modulun işə salınması haqqında məlumatları qeyd edin
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // bağlanma zamanı qeydiyyatdan keçin
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW xüsusi init/uninit rutin qeydiyyatı
    pub mod mingw_init {
        // MinGW-nin başlanğıc obyektləri (crt0.o/dllcrt0.o) .ctors və .dtors başlanğıc və çıxış hissələrində qlobal konstruktorlara müraciət edəcəkdir.
        // DLL-lərdə bu, DLL yükləndikdə və boşaldılanda edilir.
        //
        // Bağlayıcı bölmələri sıralayacaq ki, bu da geri zənglərimizin siyahının sonunda yerləşməsini təmin edir.
        // Konstruktorlar tərs qaydada işlədildiyi üçün geri çağırmalarımızın ilk və sonuncusu olmasını təmin edir.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C başlatma geri çağırışları
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C ləğvi geri çağırışları
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}