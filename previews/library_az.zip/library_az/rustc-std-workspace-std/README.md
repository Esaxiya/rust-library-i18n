# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate sənədlərinə baxın.