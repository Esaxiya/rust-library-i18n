# `rustc-std-workspace-core` crate

Bu crate, sadəcə `libcore`-dən asılı olan və bütün məzmunu yenidən ixrac edən bir parıldayan və boş crate-dir.
crate, standart kitabxananın crates.io-dən crates-dən asılı olmasını gücləndirməyin əsas nöqtəsidir.

Standart kitabxananın asılı olduğu crates.io-də Crates, boş olan crates.io-dən `rustc-std-workspace-core` crate-dən asılı olmalıdır.

Bu depoda bu crate-nin əvəzinə `[patch]` istifadə edirik.
Nəticədə, crates.io-dəki crates, bu depoda müəyyən edilmiş versiya olan edge-dən `libcore`-ə bir asılılıq çəkəcəkdir.
Bu Cargo-nin crates-ni uğurla qurmasını təmin etmək üçün bütün asılılıq kənarlarını çəkməlidir!

crates.io-dəki crates-nin hər şeyin düzgün işləməsi üçün `core` adının verildiyi bu crate-dən asılı olması lazım olduğunu unutmayın.Bunu etmək üçün istifadə edə bilərlər:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` düyməsinin istifadəsi sayəsində crate `core` olaraq dəyişdirildi, yəni belə görünəcək

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo kompilyatoru çağırdıqda, kompilyator tərəfindən enjekte edilmiş gizli `extern crate core` direktivini təmin edir.




