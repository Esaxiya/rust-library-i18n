//! Windows SEH
//!
//! Windows-də (hazırda yalnız MSVC-də), standart istisna işləmə mexanizmi Structured Exception Handling (SEH) dir.
//! Bu, derleyici daxili baxımından Cırtdan əsaslı istisna işlənməsindən (məsələn, digər unix platformalarının istifadə etdiyi) tamamilə fərqlidir, buna görə də LLVM'nin SEH üçün yaxşı bir əlavə dəstəyə sahib olması tələb olunur.
//!
//! Bir sözlə, burada nə baş verir:
//!
//! 1. `panic` funksiyası, standart Windows `_CxxThrowException` funksiyasını C++ atmaq üçün çağırır-istisna kimi, açma prosesini tetikler.
//! 2.
//! Tərtibçi tərəfindən yaradılan bütün açılış yastıqları CRT-dəki bir funksiya olan `__CxxFrameHandler3` şəxsiyyət funksiyasından istifadə edir və Windows-dəki açma kodu bu şəxsiyyət funksiyasından yığındakı bütün təmizləmə kodlarını yerinə yetirmək üçün istifadə edəcəkdir.
//!
//! 3. `invoke`-ə tərtibçi tərəfindən yaradılan bütün zənglər, təmizlənmə rutininin başlanğıcını göstərən `cleanuppad` LLVM təlimatı olaraq quraşdırılmış bir enmə yastığına malikdir.
//! Şəxsiyyət (CRT-də müəyyən edilmiş 2-ci addımda) təmizlənmə qaydalarını həyata keçirməkdən məsuldur.
//! 4. Nəhayət, `try` daxili (tərtibçi tərəfindən yaradılan) içərisindəki "catch" kodu icra edilir və nəzarətin Rust-ə qayıtmasını göstərir.
//! Bu, `catchswitch` və LLVM IR şərtlərində bir `catchpad` təlimatı vasitəsilə həyata keçirilir və sonda `catchret` təlimatı ilə normal nəzarəti proqrama qaytarır.
//!
//! gcc əsaslı istisna işlənməsindən bəzi spesifik fərqlər bunlardır:
//!
//! * Rust-də xüsusi bir şəxsiyyət funksiyası yoxdur, bunun əvəzinə *həmişə*`__CxxFrameHandler3`.Əlavə olaraq əlavə filtrləmə aparılmır, buna görə atdığımız növə bənzər C++ istisnalarını əldə edəcəyik.
//! Bir istisnanın Rust-yə atılmasının hər halda müəyyən edilməmiş bir davranış olduğunu unutmayın, buna görə də bu yaxşı olmalıdır.
//! * Sərbəst sərhəddən ötürmək üçün bəzi məlumatlara sahibik, xüsusən də bir `Box<dyn Any + Send>`.Cırtdan istisnalarda olduğu kimi, bu iki göstərici də istisnanın özündə yük kimi saxlanılır.
//! MSVC-də filtr funksiyaları yerinə yetirilərkən zəng yığını qorunub saxlanıldığı üçün əlavə yığın ayrılmasına ehtiyac yoxdur.
//! Bu o deməkdir ki, göstəricilər birbaşa `_CxxThrowException`-ə ötürülür və sonra filtr funksiyasında bərpa edilərək `try` daxili yığın çərçivəsinə yazılır.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Bunun bir Seçim olması lazımdır, çünki istisnanı istinadla tuturuq və onun məhvçisi C++ iş vaxtı tərəfindən icra olunur.
    // Qutunu istisna halından çıxardıqda, dağıdıcısının Qutu ikiqat salmadan çalışması üçün istisnanı etibarlı vəziyyətdə qoymalıyıq.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Əvvəlcə bir növ dəst təriflər.Burada bir neçə platformaya xas qəribəliklər var və LLVM-dən açıqca kopyalanan bir çox şey var.Bütün bunların məqsədi `_CxxThrowException`-ə zəng edərək aşağıdakı `panic` funksiyasını həyata keçirməkdir.
//
// Bu funksiya iki arqument tələb edir.Birincisi, ötürdüyümüz məlumatların göstəricisi, bu halda trait obyektimizdir.Tapmaq olduqca asandır!Növbəti isə daha mürəkkəbdir.
// Bu, `_ThrowInfo` quruluşuna işarədir və ümumiyyətlə yalnız atılan istisnanı təsvir etmək üçündür.
//
// Hal-hazırda bu tip [1] tərifi bir az tüklüdür və əsas qəribəlik (və onlayn məqalədən fərqi) 32 bitdə göstəricilərin, 64 bitdə göstəricilərin 32 bit ofset kimi ifadə edilməsidir. `__ImageBase` işarəsi.
//
// Bunu ifadə etmək üçün aşağıdakı modullardakı `ptr_t` və `ptr!` makrosundan istifadə olunur.
//
// Tip təriflərinin labirenti, LLVM-nin bu cür əməliyyat üçün nələr buraxdığını da yaxından izləyir.Məsələn, bu C++ kodunu MSVC-də tərtib etsəniz və LLVM IR yayarsanız:
//
//      #include <stdint.h>
//
//      struct pas_panik {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      boşluq foo() { rust_panic a = {0, 1};
//          atmaq;}
//
// Əslində biz təqlid etməyə çalışdığımız budur.Aşağıdakı sabit dəyərlərin çoxu yalnız LLVM-dən kopyalandı,
//
// Hər halda, bu strukturların hamısı bənzər bir şəkildə inşa edilmişdir və bu bizim üçün bir qədər açıqdır.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Burada adların dəyişdirilməsi qaydalarını qəsdən görməməzlikdən gəldiyimizi nəzərə alaq: C++ 'un sadəcə `struct rust_panic` elan edərək Rust panics-i tutmasını istəmirik.
//
//
// Dəyişdirərkən, tip ad sətrinin `compiler/rustc_codegen_llvm/src/intrinsic.rs`-də istifadə olunanla tam uyğun olduğundan əmin olun.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Buradakı aparıcı `\x01` bayt, həqiqətən LLVM-yə `_` xarakterli prefiks kimi başqa bir manqurt tətbiq etməmək üçün * sehrli bir siqnaldır.
    //
    //
    // Bu simvol C++ 'ın `std::type_info` tərəfindən istifadə olunan vtabledır.
    // `std::type_info` tipli obyektlər, tip descriptorlar, bu cədvələ işarə edir.
    // Tip təsvirçiləri yuxarıda müəyyən edilmiş və aşağıda qurduğumuz C++ EH strukturları tərəfindən istinad olunur.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Bu tip descriptor yalnız bir istisna atdıqda istifadə olunur.
// Tutma hissəsi, özünün TypeDescriptorunu yaradan, özünəməxsus cəhətdən idarə olunur.
//
// Bu yaxşıdır, çünki MSVC iş vaxtı göstərici bərabərliyinə deyil, TypeDescriptors-a uyğunlaşmaq üçün tip adında simli müqayisədən istifadə edir.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// C ++ kodu istisnanı ələ keçirməyə və yaymadan atmağa qərar verərsə istifadə olunan məhvedici.
// Yerli cəhətdən tutma hissəsi istisna obyektinin ilk sözünü məhv edən tərəfindən atlanacağı üçün 0 olaraq təyin edəcəkdir.
//
// x86 Windows, standart "C" çağırış konvensiyası əvəzinə C++ üzv funksiyaları üçün "thiscall" çağırış konvensiyasından istifadə etdiyini unutmayın.
//
// Exception_copy funksiyası burada bir qədər özəldir: MSVC iş vaxtı tərəfindən try/catch bloku altında çağırılır və burada yaratdığımız panic istisna nüsxəsi nəticəsində istifadə olunur.
//
// Bu, C++ işləmə vaxtı, std::exception_ptr ilə istisnaların ələ keçirilməsini dəstəkləmək üçün istifadə olunur<dyn Any>klonlaşdırıla bilməz.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException tamamilə bu yığın çərçivədə icra olunur, beləliklə `data`-i yığına köçürməyə ehtiyac yoxdur.
    // Bu funksiyaya sadəcə bir yığın göstəricisi ötürürük.
    //
    // ManuallyDrop burada lazımdır, çünki açarkən istisnanın düşməsini istəmirik.
    // Bunun əvəzinə, C++ iş vaxtı tərəfindən çağırılan exception_cleanup tərəfindən buraxılacaq.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Bu ... təəccüblü görünə bilər və haqlı olaraq belədir.32-bit MSVC-də bu quruluş arasındakı göstəricilər məhz bu, göstəricilərdir.
    // 64-bit MSVC-də isə strukturlar arasındakı göstəricilər `__ImageBase`-dən 32-bit ofset kimi ifadə olunur.
    //
    // Nəticə olaraq 32 bitlik MSVC-də bütün bu göstəriciləri yuxarıdakı statiklərdə elan edə bilərik.
    // 64-bit MSVC-də Rust-nin hal-hazırda icazə vermədiyi statikdə göstəricilərin çıxarılmasını ifadə etməliyik, buna görə əslində bunu edə bilmərik.
    //
    // Növbəti ən yaxşı şey, bu strukturları iş vaxtında doldurmaqdır (çaxnaşma onsuz da "slow path"-dir).
    // Beləliklə, burada bu göstərici sahələrinin hamısını 32 bitlik tam ədədlər kimi yenidən şərh edirik və sonra müvafiq dəyəri ona saxlayırıq (eyni zamanda panics baş verə bilər).
    //
    // Texniki cəhətdən iş müddəti bu sahələrin atomik olmayan bir oxumasını edəcək, lakin nəzəri olaraq heç vaxt *səhv* dəyəri oxumurlar, buna görə çox pis olmamalıdır ...
    //
    // Hər halda, statikdə daha çox əməliyyat ifadə edə bilməyincə (və heç vaxt edə bilməyəcəyimizə) əsasən belə bir şey etməliyik.
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Buradakı NULL yükü o deməkdir ki, __rust_try-nin (...) tutmasından gəldik.
    // Bu, Rust olmayan bir xarici istisna tutulduqda olur.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Bu, kompilyatorun mövcud olması üçün tələb olunur (məsələn, bu lang elementidir), lakin __C_specific_handler və ya_except_handler3 həmişə istifadə olunan şəxsiyyət funksiyası olduğu üçün əsla tərtibçi tərəfindən çağırılmır.
//
// Beləliklə, bu yalnız abort edən bir stubdur.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}