//! Miri üçün panics açılır.
use alloc::boxed::Box;
use core::any::Any;

// Miri mühərrikinin bizim üçün açılması yolu ilə yaydığı faydalı yük növü.
// Göstərici ölçülü olmalıdır.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri tərəfindən təqdim olunan extern funksiyası açılmağa başlayacaq.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic`-ə keçdiyimiz yük tam olaraq aşağıdakı `cleanup`-də əldə etdiyimiz arqument olacaqdır.
    // Beləliklə, göstərici ölçülü bir şey əldə etmək üçün yalnız bir dəfə qutuya qoyuruq.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Əsas `Box`-i bərpa edin.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}