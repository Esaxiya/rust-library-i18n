use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri çox ləngdir
fn exact_sanity_test() {
    // Bu test yalnız istifadə etdiyim hər hansı C işləmə müddətində təyin olunan `exp2` kitabxana funksiyasının bəzi künc işi olduğunu düşünə biləcəyimi işlədir.
    // VS 2013-də bu funksiyada bir səhv var idi, çünki bu test əlaqələndirildikdə uğursuz oldu, lakin VS 2015 ilə səhv çox yaxşı işlədiyindən səhv düzəldi.
    //
    // Hata, `exp2(-1057)` dönüş dəyərindəki bir fərq kimi görünür, burada VS 2013-də 0x2 bit naxışı ilə ikiqat, VS 2015-də 0x20000 qaytarır.
    //
    //
    // Hələlik başqa bir yerdə test edildiyi üçün bu testi tamamilə MSVC-də görməməzlikdən gəlin və hər bir platformanın exp2 tətbiqetməsini sınamaq çox maraqlı deyildir.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}