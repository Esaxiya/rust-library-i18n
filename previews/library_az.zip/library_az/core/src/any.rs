//! Bu modul, iş vaxtı əks olunmaqla istənilən `'static` tipinin dinamik yazılmasına imkan verən `Any` trait tətbiq edir.
//!
//! `Any` özü bir `TypeId` əldə etmək üçün istifadə edilə bilər və trait obyekti kimi istifadə edildikdə daha çox xüsusiyyətə malikdir.
//! `&dyn Any` (borc götürülmüş trait obyekti) olaraq `is` və `downcast_ref` metodlarına malikdir, ehtiva olunan dəyərin müəyyən bir tipdə olub olmadığını yoxlamaq və bir növ kimi daxili dəyərə istinad etmək.
//! `&mut dyn Any` olaraq daxili dəyərə dəyişdirilə bilən bir istinad almaq üçün `downcast_mut` metodu da mövcuddur.
//! `Box<dyn Any>` `Box<T>`-ə çevrilməyə çalışan `downcast` metodunu əlavə edir.
//! Tam ətraflı məlumat üçün [`Box`] sənədlərinə baxın.
//!
//! Qeyd edək ki, `&dyn Any` dəyərin müəyyən bir beton növü olub olmadığını yoxlamaqla məhdudlaşır və bir növün trait tətbiq edib etmədiyini yoxlamaq üçün istifadə edilə bilməz.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Ağıllı göstəricilər və `dyn Any`
//!
//! `Any` i trait obyekti olaraq istifadə edərkən, xüsusən də `Box<dyn Any>` və ya `Arc<dyn Any>` kimi tiplərdə nəzərə alınmalı bir davranış budur ki, `.type_id()`-i sadəcə trait obyektini deyil,*konteynerin*`TypeId`-ini istehsal edəcəkdir.
//!
//! Bunun əvəzinə ağıllı göstəricini `&dyn Any`-ə çevirməklə obyektin `TypeId`-i qaytaracaq.
//! Misal üçün:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Bunu istəmək ehtimalı daha yüksəkdir:
//! let actual_id = (&*boxed).type_id();
//! // ... bundan:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Bir funksiyaya ötürülən bir dəyəri çıxmaq istədiyimiz bir vəziyyəti düşünün.
//! Çalışdığımız dəyəri Debug tətbiq etdiyini bilirik, lakin konkret növünü bilmirik.Müəyyən növlərə xüsusi müalicə vermək istəyirik: bu vəziyyətdə String dəyərlərinin dəyərindən əvvəl uzunluğunu çap edin.
//! Kompilyasiya zamanı dəyərimizin konkret növünü bilmirik, bunun əvəzinə işləmə müddətinin əks olunmasını istifadə etməliyik.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Debug tətbiq edən hər hansı bir növ üçün qeydiyyatçı funksiyası.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Dəyərimizi `String`-ə çevirməyə çalışın.
//!     // Uğurlu olarsa, simlin uzunluğunu və dəyərini çıxarmaq istəyirik.
//!     // Əks təqdirdə, fərqli bir növdür: sadəcə bəzədilmədən çap edin.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Bu funksiya onunla iş görməmişdən əvvəl parametrini çıxarmaq istəyir.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... başqa bir iş gör
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Hər hansı bir trait
///////////////////////////////////////////////////////////////////////////////

/// Dinamik yazmanı təqlid etmək üçün bir trait.
///
/// Çox növ `Any` tətbiq edir.Bununla birlikdə, qeyri-statik bir istinad olan hər hansı bir növdə yoxdur.
/// Daha ətraflı məlumat üçün [module-level documentation][mod]-ə baxın.
///
/// [mod]: crate::any
// Bu trait təhlükəli deyil, lakin təhlükəli koddakı yeganə impl-nin `type_id` funksiyasının xüsusiyyətlərinə etibar edirik (məsələn, `downcast`).Normalda bu bir problem olardı, ancaq `Any`-in tək örtüyü örtük tətbiqi olduğu üçün başqa heç bir kod `Any` tətbiq edə bilməz.
//
// Bu trait-ni təhlükəli vəziyyətə gətirə bilərik-bu, qırılmaya səbəb olmaz, çünki bütün tətbiqetmələrə nəzarət edirik-amma bunun həm lazım olmadığını, həm də istifadəçiləri təhlükəli traits və təhlükəli metodların fərqləndirməsi ilə qarışdırdığını seçirik (yəni, `type_id` hələ də zəng etmək üçün təhlükəsiz olardı, ancaq sənədlərdə bunu göstərmək istərdik).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self`-in `TypeId`-ini alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Hər hansı bir trait obyekti üçün genişləndirmə metodları.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Məsələn, bir mövzuya qoşulma nəticəsinin `unwrap` ilə yazdırıla biləcəyinə və bu səbəbdən istifadə olunmasına əmin olun.
// Göndərmə upcasting ilə işləyirsə, nəticədə artıq ehtiyac olmaya bilər.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Qutulu tip `T` ilə eynidirsə, `true` qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Bu funksiyanın hazırlandığı tipdən `TypeId` alın.
        let t = TypeId::of::<T>();

        // trait obyekti (`self`)-də `TypeId` alın.
        let concrete = self.type_id();

        // Hər iki "TypeId" bərabərliyi ilə müqayisə edin.
        t == concrete
    }

    /// `T` tipindədirsə, qutuda göstərilən dəyərə, yoxsa `None`-ə istinad edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // TƏHLÜKƏSİZLİK: düzgün növü göstərdiyimizi yoxlayın və etibar edə bilərik
            // yaddaş təhlükəsizliyini yoxlayın, çünki hər növü hər hansı birini tətbiq etdik;bizim təəssüratımızla ziddiyyət təşkil etdiyi kimi başqa fikirlər mövcud ola bilməz.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// `T` tipindədirsə, qutuda göstərilən dəyərə bəzi dəyişdirilə bilən və ya olmadıqda `None` qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // TƏHLÜKƏSİZLİK: düzgün növü göstərdiyimizi yoxlayın və etibar edə bilərik
            // yaddaş təhlükəsizliyini yoxlayın, çünki hər növü hər hansı birini tətbiq etdik;bizim təəssüratımızla ziddiyyət təşkil etdiyi kimi başqa fikirlər mövcud ola bilməz.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` tipində müəyyən edilmiş metoda yönəldir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` tipində müəyyən edilmiş metoda yönəldir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` tipində müəyyən edilmiş metoda yönəldir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` tipində müəyyən edilmiş metoda yönəldir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` tipində müəyyən edilmiş metoda yönəldir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` tipində müəyyən edilmiş metoda yönəldir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID və onun metodları
///////////////////////////////////////////////////////////////////////////////

/// `TypeId`, bir növ üçün qlobal olaraq unikal bir identifikatoru təmsil edir.
///
/// Hər `TypeId`, içərisində olanların yoxlanılmasına imkan verməyən, klonlama, müqayisə, çap və nümayiş etdirmə kimi əsas əməliyyatlara imkan verən qeyri-şəffaf bir obyektdir.
///
///
/// `TypeId` hazırda yalnız `'static`-yə aid olan növlər üçün mövcuddur, lakin bu məhdudiyyət future-də qaldırıla bilər.
///
/// `TypeId`, `Hash`, `PartialOrd` və `Ord` tətbiq edərkən, karmağın və sifarişin Rust buraxılışları arasında dəyişəcəyini qeyd etmək lazımdır.
/// Kodunuzun içərisində onlara etibar etməkdən çəkinin!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Bu ümumi funksiyanın hazırlandığı tip `TypeId`-i qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Bir növün adını simli dilim kimi qaytarır.
///
/// # Note
///
/// Bu diaqnostik istifadə üçün nəzərdə tutulmuşdur.
/// Döndürülən sətrin dəqiq məzmunu və formatı, növün ən yaxşı səciyyəvi təsviri xaricində göstərilmir.
/// Məsələn, `type_name::<Option<String>>()`-in qayıda biləcəyi simlər arasında `"Option<String>"` və `"std::option::Option<std::string::String>"` var.
///
///
/// Qaytarılmış sətir bir növün unikal identifikatoru hesab edilməməlidir, çünki birdən çox növ eyni tip adına uyğunlaşa bilər.
/// Eynilə, bir növün bütün hissələrinin qaytarılmış sətirdə görünməsinə zəmanət yoxdur: məsələn, ömür boyu göstəricilər hal-hazırda daxil deyil.
/// Bundan əlavə, nəticə kompilyatorun versiyaları arasında dəyişə bilər.
///
/// Mövcud tətbiq kompilyator diaqnostikası və debuginfo ilə eyni infrastrukturdan istifadə edir, lakin buna zəmanət verilmir.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Sivri göstərilən dəyər növünün adını simli dilim kimi qaytarır.
/// Bu, `type_name::<T>()` ilə eynidir, lakin dəyişən tipinin asanlıqla əldə olunmadığı yerdə istifadə edilə bilər.
///
/// # Note
///
/// Bu diaqnostik istifadə üçün nəzərdə tutulmuşdur.Sətrin ən yaxşı səy göstəricisindən başqa, sətrin dəqiq məzmunu və formatı göstərilmir.
/// Məsələn, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` və ya `"std::option::Option<std::string::String>"`-i qaytara bilər, lakin `"foobar"` deyil.
///
/// Bundan əlavə, nəticə kompilyatorun versiyaları arasında dəyişə bilər.
///
/// Bu funksiya trait obyektlərini həll etmir, yəni `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"`-i qaytara bilər, lakin `"u32"` deyil.
///
/// Tip adı bir növün unikal identifikatoru hesab edilməməlidir;
/// birdən çox növ eyni tipli ad paylaşa bilər.
///
/// Mövcud tətbiq kompilyator diaqnostikası və debuginfo ilə eyni infrastrukturdan istifadə edir, lakin buna zəmanət verilmir.
///
/// # Examples
///
/// Varsayılan tam və float növlərini çap edir.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}