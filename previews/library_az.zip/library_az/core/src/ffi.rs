#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Xarici funksiya interfeysi (FFI) bağlamaları ilə əlaqəli köməkçi proqramlar.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] kimi istifadə edildikdə C-nin `void` tipinə bərabərdir.
///
/// Əslində `*const c_void` C-nin `const void*`-ə, `*mut c_void` isə C-nin `void*`-yə bərabərdir.
/// Dedi ki, bu, Rust-nin `()` tipi olan C-nin `void` qayıtma tipi ilə eyni deyil *.
///
/// FFI-də qeyri-şəffaf növlərə göstəriciləri modelləşdirmək üçün `extern type` sabitləşənə qədər boş bir bayt massivinin ətrafında newtype sarğı istifadə etmək məsləhət görülür.
///
/// Ətraflı məlumat üçün [Nomicon]-ə baxın.
///
/// Köhnə Rust kompilyatorunu 1.1.0-ə qədər dəstəkləmək istəsələr `std::os::raw::c_void` istifadə edə bilər.
/// Rust 1.30.0-dən sonra bu təriflə yenidən ixrac edildi.
/// Daha çox məlumat üçün [RFC 2521] oxuyun.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, LLVM'nin boş göstərici tipini tanıması və malloc() kimi uzantı funksiyalarına görə LLVM bit kodunda i8 * kimi təqdim edilməsinə ehtiyac var.
// Burada istifadə edilən enum bunu təmin edir və "raw" tipinin yalnız xüsusi variantlara sahib olmasının qarşısını alır.
// İki varianta ehtiyacımız var, çünki tərtibçi əks halda repr atributundan şikayətlənir və ən azı bir varianta ehtiyacımız var, çünki əks halda enum yaşayış olmayacaq və ən azı bu cür göstəricilərin tərifi UB olacaqdır.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Bir `va_list` əsas tətbiqi.
// Adı XIP-dən istifadə edərək WIP-dir.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f`-dən çox dəyişməzdir, buna görə hər bir `VaListImpl<'f>` obyekti təyin olunduğu funksiyanın bölgəsinə bağlıdır
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Bir `va_list`-in ABI tətbiqi.
/// Daha ətraflı məlumat üçün [AArch64 Procedure Call Standard]-ə baxın.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Bir `va_list`-in ABI tətbiqi.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Bir `va_list`-in ABI tətbiqi.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` üçün sarğı
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Bir `VaListImpl`-i C-lərin `va_list` ilə ikili uyğun bir `VaList`-ə çevirin.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Bir `VaListImpl`-i C-lərin `va_list` ilə ikili uyğun bir `VaList`-ə çevirin.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait-nin ümumi interfeyslərdə istifadə edilməsi lazımdır, lakin trait-in özünün bu modul xaricində istifadəsinə icazə verilməməlidir.
// İstifadəçilərin trait-ni yeni bir növ üçün tətbiq etməsinə icazə vermək (bununla da va_arg özünəməxsusluğunun yeni bir növdə istifadə edilməsinə imkan vermək), ehtimal ki, təyin olunmamış bir davranışa səbəb ola bilər.
//
// FIXME(dlrobertson): VaArgSafe trait-ni ümumi bir interfeysdə istifadə etmək, həm də başqa yerdə istifadə edilə bilməməsini təmin etmək üçün trait-nin xüsusi bir modulda açıq olması lazımdır.
// RFC 2145 tətbiq edildikdən sonra bunu yaxşılaşdırmağa baxın.
//
//
//
//
mod sealed_trait {
    /// [super::VaListImpl::arg] ilə icazə verilən növlərin istifadəsinə icazə verən Trait.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Növbəti arq üçün irəliləyin.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // TƏHLÜKƏSİZLİK: zəng edən `va_arg` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { va_arg(self) }
    }

    /// `va_list`-i cari yerdə kopyalayır.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // TƏHLÜKƏSİZLİK: zəng edən `va_end` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // TƏHLÜKƏSİZLİK: `MaybeUninit`-ə yazırıq, beləliklə işə salındı və `assume_init` qanuni oldu
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: bu `va_end`-yə zəng etməlidir, amma təmiz bir yolu yoxdur
        // `drop`-nin daima zəng edənin içərisinə daxil olmasına zəmanət verir, buna görə `va_end` birbaşa müvafiq `va_copy` ilə eyni funksiyadan çağırılır.
        // `man va_end` C'nin bunu tələb etdiyini və LLVM'nin əsasən C semantikasını izlədiyini, buna görə `va_end` in daima `va_copy` ilə eyni funksiyadan çağırıldığından əmin olmalıyıq.
        //
        // Daha ətraflı məlumat üçün see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // `va_end`, mövcud LLVM hədəflərinin hamısından imtina etdiyindən bu, hələlik işləyir.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` və ya `va_copy` ilə işə salındıqdan sonra `ap` mübahisəli siyahısını məhv edin.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Arqlist `src`-in mövcud yerini argüman siyahısı `dst`-ə kopyalayır.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `T` tipli arqumenti `va_list` `ap`-dən yükləyir və arqumenti `ap`-ə qədər artırın.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}