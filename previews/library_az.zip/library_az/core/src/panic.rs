//! Standart kitabxanada Panic dəstəyi.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Bir panic haqqında məlumat verən bir quruluş.
///
/// `PanicInfo` quruluş [`set_hook`] funksiyası tərəfindən təyin olunmuş panic hook-yə ötürülür.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic ilə əlaqəli faydalı yükü qaytarır.
    ///
    /// Bu, ümumiyyətlə, həmişə deyil, `&'static str` və ya [`String`] olacaqdır.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate-dən (`std`-dən deyil) `panic!` makrosu formatlama sətri və bəzi əlavə arqumentlərlə istifadə edilmişdirsə, bu mesajı, məsələn, [`fmt::write`] ilə istifadə olunmağa hazır qaytarır.
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Mümkünsə, panic-in mənşəyi olduğu yer haqqında məlumat verir.
    ///
    /// Bu metod hal-hazırda [`Some`]-i həmişə qaytaracaq, lakin bu future versiyalarında dəyişə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Bu bəzən heç birini qaytarmaq üçün dəyişdirilirsə,
        // bu işi std::panicking::default_hook və std::panicking::begin_panic_fmt-də həll edin.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: downcast_ref istifadə edə bilmərik: :<String>() burada
        // String libcore'da mövcud olmadığından!
        // `std::panic!` çoxsaylı arqumentlərlə çağırıldıqda faydalı yük bir Stringdir, lakin bu halda mesaj da mövcuddur.
        //

        self.location.fmt(formatter)
    }
}

/// Bir panic-nin yeri haqqında məlumatları ehtiva edən bir struktur.
///
/// Bu quruluş [`PanicInfo::location()`] tərəfindən yaradılmışdır.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Bərabərlik və sifariş üçün müqayisələr faylda, sətirdə, sonra sütun prioritetində aparılır.
/// Fayllar `Path` deyil, strings kimi müqayisə olunur ki, bu da gözlənilməz ola bilər.
/// Daha çox müzakirə üçün [`Location: : file`] sənədlərinə baxın.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Bu funksiyanı axtaranın mənbə yerini qaytarır.
    /// Bu funksiyanın zəng edəninə şərh verildiyi təqdirdə zəng yeri qaytarılacaq və izlənilməyən bir funksiya gövdəsindəki ilk çağırışa qədər yığını geri qaytaracaq.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Çağırıldığı [`Location`]-i qaytarır.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Bu funksiyanın tərifindən bir [`Location`] qaytarır.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // eyni izlənməmiş funksiyanı fərqli bir yerdə çalıştırmaq bizə eyni nəticəni verir
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // İzlənən funksiyanı fərqli bir yerdə işlətmək fərqli bir dəyər yaradır
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic-in mənşəli olduğu mənbə sənədinin adını qaytarır.
    ///
    /// # `&str`, `&Path` deyil
    ///
    /// Döndürülen ad, tərtib sistemindəki bir qaynaq yoluna istinad edir, ancaq bunu birbaşa `&Path` olaraq təmsil etmək etibarlı deyil.
    /// Tərtib edilmiş kod, məzmunu təmin edən sistemdən fərqli bir fərqli `Path` tətbiqetmə ilə fərqli bir sistemdə işləyə bilər və bu kitabxananın hazırda fərqli bir "host path" tipi yoxdur.
    ///
    /// Ən təəccüblü davranış, "the same" faylına modul sistemindəki bir çox yoldan (ümumiyyətlə `#[path = "..."]` atributundan və ya bənzərindən istifadə edərək) əl çatdıqda baş verir, bu da eyni kod kimi görünən şeyin bu funksiyadan fərqli dəyərləri qaytarmasına səbəb ola bilər.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Bu dəyər, ana platforma və hədəf platforması fərqli olduqda `Path::new` və ya oxşar konstruktorlara keçid üçün uyğun deyil.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic-in yarandığı sətir nömrəsini qaytarır.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic-in yarandığı sütunu qaytarır.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd-dən libstd-dən `panic_unwind`-ə və digər panic iş vaxtlarına məlumat ötürmək üçün istifadə olunan daxili trait.
/// Tezliklə sabitləşməsi nəzərdə tutulmayıb, istifadə etməyin.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Məzmunun tam mülkiyyətini götürün.
    /// Dönüş növü əslində `Box<dyn Any + Send>` dir, lakin libcore'da `Box` istifadə edə bilmərik.
    ///
    /// Bu metod çağırıldıqdan sonra `self`-də yalnız bəzi saxta default dəyər qalır.
    /// Bu metodu iki dəfə çağırmaq və ya bu metodu çağırdıqdan sonra `get` çağırmaq səhvdir.
    ///
    /// Arqument götürülür, çünki panic işləmə müddəti (`__rust_start_panic`) yalnız borc götürülmüş `dyn BoxMeUp` alır.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Yalnız məzmunu borc.
    fn get(&mut self) -> &(dyn Any + Send);
}