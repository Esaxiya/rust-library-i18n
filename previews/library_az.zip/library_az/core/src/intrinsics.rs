//! Tərtibçi daxili.
//!
//! Müvafiq təriflər `compiler/rustc_codegen_llvm/src/intrinsic.rs`-dədir.
//! Müvafiq konstruksiyalar `compiler/rustc_mir/src/interpret/intrinsics.rs`-dədir
//!
//! # Daxili daxili
//!
//! Note: daxili şəxslərin konstliktindəki dəyişikliklər dil komandası ilə müzakirə olunmalıdır.
//! Buraya darlığın sabitliyindəki dəyişikliklər daxildir.
//!
//! Kompilyasiya vaxtında daxili istifadə edilə bilən hala gətirmək üçün tətbiqetməni <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>-dən `compiler/rustc_mir/src/interpret/intrinsics.rs`-ə kopyalamaq və daxili bir `#[rustc_const_unstable(feature = "foo", issue = "01234")]` əlavə etmək lazımdır.
//!
//!
//! Bir daxili bir `rustc_const_stable` atributu olan bir `const fn`-dən istifadə ediləcəyi təqdirdə, daxili bir atribut `rustc_const_stable` olmalıdır.
//! Belə bir dəyişiklik T-lang məsləhətləşmədən edilməməlidir, çünki istifadəçi kodunda kompilyator dəstəyi olmadan təkrarlana bilməyən bir xüsusiyyəti dilə gətirir.
//!
//! # Volatiles
//!
//! Uçucu intrinsika, I/O yaddaşında işləmək üçün nəzərdə tutulan əməliyyatlar təmin edir ki, bu da digər uçucu daxili sistemlər arasında kompilyator tərəfindən yenidən sifariş edilməməsinə zəmanət verilir.[[volatile]]-də LLVM sənədlərinə baxın.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atom daxili xüsusiyyətləri bir çox mümkün yaddaş sifarişləri ilə maşın sözləri üzərində ümumi atom əməliyyatları təmin edir.C ++ 11 ilə eyni semantikaya tabe olurlar.[[atomics]]-də LLVM sənədlərinə baxın.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Yaddaş sifarişinə dair sürətli bir yeniləmə:
//!
//! * Bir kilid əldə etmək üçün bir maneə əldə edin.Ardından oxumaq və yazmaq baryerdən sonra baş verir.
//! * Sərbəst buraxın, bir kilidi buraxmaq üçün bir maneədir.Əvvəlki oxumaq və yazmaq baryerdən əvvəl baş verir.
//! * Ardıcıl ardıcıl, ardıcıl ardıcıl əməliyyatların nizamında baş verməsi təmin edilir.Bu atom tipləri ilə işləmək üçün standart rejimdir və Java-nin `volatile`-nə bərabərdir.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Bu idxal sənədlərarası əlaqələrin sadələşdirilməsi üçün istifadə olunur
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // TƏHLÜKƏSİZLİK: bax `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, bu daxili maddələr xam göstəriciləri alır, çünki `&` və ya `&mut` üçün etibarlı olmayan yalnış yaddaşa mutasiya edirlər.
    //

    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`] yi həm `success`, həm də `failure` parametrləri olaraq keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    ///
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, `success` və `failure` parametrləri olaraq [`Ordering::Acquire`] keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    ///
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`] yi həm `success`, həm də `failure` parametrləri olaraq keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    ///
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`] yi həm `success`, həm də `failure` parametrləri olaraq keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    ///
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`] yi həm `success`, həm də `failure` parametrləri olaraq keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    ///
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`] yi həm `success`, həm də `failure` parametrləri olaraq keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    ///
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Cari dəyər `old` dəyəri ilə eyni olduqda bir dəyəri saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-dən `success`-ə və `failure`-dən `failure`-ə keçərək `compare_exchange_weak` metodu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Göstəricinin cari dəyərini yükləyir.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `load` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Göstəricinin cari dəyərini yükləyir.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-i `order` olaraq keçərək `load` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Göstəricinin cari dəyərini yükləyir.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `load` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Dəyəri göstərilən yaddaş yerində saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `store` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Dəyəri göstərilən yaddaş yerində saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-i `order` olaraq keçərək `store` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Dəyəri göstərilən yaddaş yerində saxlayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `store` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Dəyəri müəyyən edilmiş yaddaş yerində saxlayır və köhnə dəyəri qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `swap` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dəyəri müəyyən edilmiş yaddaş yerində saxlayır və köhnə dəyəri qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-i `order` olaraq keçərək `swap` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dəyəri müəyyən edilmiş yaddaş yerində saxlayır və köhnə dəyəri qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-i `order` olaraq keçərək `swap` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dəyəri müəyyən edilmiş yaddaş yerində saxlayır və köhnə dəyəri qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-i `order` olaraq keçərək `swap` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dəyəri müəyyən edilmiş yaddaş yerində saxlayır və köhnə dəyəri qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `swap` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Əvvəlki dəyəri qaytararaq cari dəyərə əlavə olunur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_add` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərə əlavə olunur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_add` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərə əlavə olunur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-i `order` olaraq keçərək `fetch_add` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərə əlavə olunur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_add` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərə əlavə olunur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_add` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Əvvəlki dəyəri qaytararaq cari dəyərdən çıxarın.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_sub` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərdən çıxarın.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_sub` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərdən çıxarın.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-i `order` olaraq keçərək `fetch_sub` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərdən çıxarın.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_sub` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərdən çıxarın.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_sub` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise və cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_and` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_and` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-i `order` olaraq keçərək `fetch_and` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_and` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_and` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bit nand.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_nand` metodu ilə [`AtomicBool`] tipində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bit nand.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_nand` metodu ilə [`AtomicBool`] tipində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bit nand.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Release`]-i `order` olaraq keçərək `fetch_nand` metodu ilə [`AtomicBool`] tipində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bit nand.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_nand` metodu ilə [`AtomicBool`] tipində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bit nand.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_nand` metodu ilə [`AtomicBool`] tipində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise və ya cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_or` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və ya cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_or` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və ya cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-i `order` olaraq keçərək `fetch_or` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və ya cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_or` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise və ya cari dəyərlə əvvəlki dəyəri qaytararaq.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_or` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bitwise xor.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_xor` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bitwise xor.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_xor` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bitwise xor.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Release`]-i `order` olaraq keçərək `fetch_xor` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bitwise xor.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_xor` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Əvvəlki dəyəri qaytararaq cari dəyərlə bitwise xor.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası, [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_xor` üsulu ilə [`atomic`] tiplərində mövcuddur.
    /// Misal üçün, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İmzalanmış bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzalanmış bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzalanmış bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Release`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzalanmış bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İmzalı bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzalı bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzalı bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Release`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzalı bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzalı bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] işarəli tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İmzasız bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Release`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyərlə minimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_min` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// İmzasız bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Release`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// İmzasız bir müqayisə istifadə edərək cari dəyər ilə maksimum.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Relaxed`]-i `order` olaraq keçərək `fetch_max` metodu ilə [`atomic`] imzasız tam ədəd növlərində mövcuddur.
    /// Misal üçün, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Yerli `prefetch` kod istehsalçısına dəstək verildiyi təqdirdə bir əvvəlcədən təlimat əlavə etmək üçün bir işarədir;Əks təqdirdə, bu qadağandır.
    /// Prefetches proqramın davranışına heç bir təsir göstərmir, lakin performans xüsusiyyətlərini dəyişdirə bilər.
    ///
    /// `locality` arqumenti sabit bir tam olmalıdır və (0)-dən, heç bir lokalizasiyadan, (3)-ə qədər olan, müvəqqəti bir lokasiya göstəricisidir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Yerli `prefetch` kod istehsalçısına dəstək verildiyi təqdirdə bir əvvəlcədən təlimat əlavə etmək üçün bir işarədir;Əks təqdirdə, bu qadağandır.
    /// Prefetches proqramın davranışına heç bir təsir göstərmir, lakin performans xüsusiyyətlərini dəyişdirə bilər.
    ///
    /// `locality` arqumenti sabit bir tam olmalıdır və (0)-dən, heç bir lokalizasiyadan, (3)-ə qədər olan, müvəqqəti bir lokasiya göstəricisidir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Yerli `prefetch` kod istehsalçısına dəstək verildiyi təqdirdə bir əvvəlcədən təlimat əlavə etmək üçün bir işarədir;Əks təqdirdə, bu qadağandır.
    /// Prefetches proqramın davranışına heç bir təsir göstərmir, lakin performans xüsusiyyətlərini dəyişdirə bilər.
    ///
    /// `locality` arqumenti sabit bir tam olmalıdır və (0)-dən, heç bir lokalizasiyadan, (3)-ə qədər olan, müvəqqəti bir lokasiya göstəricisidir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Yerli `prefetch` kod istehsalçısına dəstək verildiyi təqdirdə bir əvvəlcədən təlimat əlavə etmək üçün bir işarədir;Əks təqdirdə, bu qadağandır.
    /// Prefetches proqramın davranışına heç bir təsir göstərmir, lakin performans xüsusiyyətlərini dəyişdirə bilər.
    ///
    /// `locality` arqumenti sabit bir tam olmalıdır və (0)-dən, heç bir lokalizasiyadan, (3)-ə qədər olan, müvəqqəti bir lokasiya göstəricisidir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atom çəpəri.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-i `order` olaraq keçərək [`atomic::fence`]-də mövcuddur.
    ///
    ///
    pub fn atomic_fence();
    /// Atom çəpəri.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-i `order` olaraq keçərək [`atomic::fence`]-də mövcuddur.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atom çəpəri.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Release`]-i `order` olaraq keçərək [`atomic::fence`]-də mövcuddur.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atom çəpəri.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-i `order` olaraq keçərək [`atomic::fence`]-də mövcuddur.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Yalnızca tərtibçi yaddaş baryeri.
    ///
    /// Yaddaş girişləri heç vaxt tərtibçi tərəfindən bu baryerdən yenidən sıralanmayacaq, lakin bunun üçün heç bir təlimat verilməyəcəkdir.
    /// Bu, siqnal işləyiciləri ilə qarşılıqlı əlaqədə olduğu kimi əvvəlcədən görünə bilən eyni iplikdəki əməliyyatlar üçün uyğundur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::SeqCst`]-i `order` olaraq keçərək [`atomic::compiler_fence`]-də mövcuddur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Yalnızca tərtibçi yaddaş baryeri.
    ///
    /// Yaddaş girişləri heç vaxt tərtibçi tərəfindən bu baryerdən yenidən sıralanmayacaq, lakin bunun üçün heç bir təlimat verilməyəcəkdir.
    /// Bu, siqnal işləyiciləri ilə qarşılıqlı əlaqədə olduğu kimi əvvəlcədən görünə bilən eyni iplikdəki əməliyyatlar üçün uyğundur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Acquire`]-i `order` olaraq keçərək [`atomic::compiler_fence`]-də mövcuddur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Yalnızca tərtibçi yaddaş baryeri.
    ///
    /// Yaddaş girişləri heç vaxt tərtibçi tərəfindən bu baryerdən yenidən sıralanmayacaq, lakin bunun üçün heç bir təlimat verilməyəcəkdir.
    /// Bu, siqnal işləyiciləri ilə qarşılıqlı əlaqədə olduğu kimi əvvəlcədən görünə bilən eyni iplikdəki əməliyyatlar üçün uyğundur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::Release`]-i `order` olaraq keçərək [`atomic::compiler_fence`]-də mövcuddur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Yalnızca tərtibçi yaddaş baryeri.
    ///
    /// Yaddaş girişləri heç vaxt tərtibçi tərəfindən bu baryerdən yenidən sıralanmayacaq, lakin bunun üçün heç bir təlimat verilməyəcəkdir.
    /// Bu, siqnal işləyiciləri ilə qarşılıqlı əlaqədə olduğu kimi əvvəlcədən görünə bilən eyni iplikdəki əməliyyatlar üçün uyğundur.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`Ordering::AcqRel`]-i `order` olaraq keçərək [`atomic::compiler_fence`]-də mövcuddur.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Mənasını funksiyaya bağlı atributlardan əldə edən daxili sehr.
    ///
    /// Məsələn, dataflow bundan statik iddiaları yeritmək üçün istifadə edir ki, `rustc_peek(potentially_uninitialized)` həqiqətən verilənlər axınının idarəetmə axınının həmin nöqtəsində başlanğıcsız qaldığını hesabladığını iki dəfə yoxlasın.
    ///
    ///
    /// Bu daxili kompilyator xaricində istifadə edilməməlidir.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Prosesin icrasını ləğv edir.
    ///
    /// Bu əməliyyatın daha rahat və dayanıqlı bir versiyası [`std::process::abort`](../../std/process/fn.abort.html)-dir.
    ///
    pub fn abort() -> !;

    /// Koddakı bu nöqtənin əlçatan olmadığını optimizatora bildirir və daha da optimallaşdırma imkanı yaradır.
    ///
    /// NB, bu `unreachable!()` makrosundan çox fərqlidir: panics icra edildiyi makrodan fərqli olaraq, bu funksiya ilə işarələnmiş kodu əldə etmək * təyin olunmamış davranışdır.
    ///
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked)-dir.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Optimizatora bir şərtin hər zaman doğru olduğunu bildirir.
    /// Vəziyyət yalan olarsa, davranış müəyyənləşdirilmir.
    ///
    /// Bu daxili üçün heç bir kod yaradılmır, lakin optimallaşdırıcı ətrafdakı kodun optimallaşdırılmasına müdaxilə edə və performansı azalda biləcək keçidlər arasında onu (və vəziyyətini) qorumağa çalışacaqdır.
    /// İnvariant öz-özünə optimizator tərəfindən kəşf oluna bilərsə və ya heç bir əhəmiyyətli optimallaşdırmaya imkan vermirsə istifadə edilməməlidir.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch vəziyyətinin doğru olacağı ehtimalına dair tərtibçiyə göstərişlər.
    /// Keçmiş dəyəri qaytarır.
    ///
    /// `if` ifadələrindən başqa hər hansı bir istifadənin yəqin ki, təsiri olmayacaqdır.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch şərtinin yalan ola biləcəyi barədə tərtibçiyə göstərişlər.
    /// Keçmiş dəyəri qaytarır.
    ///
    /// `if` ifadələrindən başqa hər hansı bir istifadənin yəqin ki, təsiri olmayacaqdır.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Ayıklayıcı tərəfindən yoxlanılması üçün bir kəsmə nöqtəsi tələsi yerinə yetirir.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn breakpoint();

    /// Bir növün bayt ölçüsü.
    ///
    /// Daha spesifik olaraq, bu, hizalama doldurma da daxil olmaqla eyni tipli ardıcıl maddələr arasındakı bayt əvəzliyi.
    ///
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::mem::size_of`](crate::mem::size_of)-dir.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Bir növün minimum hizalanması.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::mem::align_of`](crate::mem::align_of)-dir.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Bir növün üstünlük təşkil etdiyi hizalama.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// İstinad olunan dəyərin bayt ölçüsü.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`mem::size_of_val`]-dir.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// İstinad olunan dəyərin tələb olunan uyğunluğu.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::mem::align_of_val`](crate::mem::align_of_val)-dir.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Bir növün adını ehtiva edən statik bir simli dilim alır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::any::type_name`](crate::any::type_name)-dir.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Müəyyən edilmiş növə görə dünya miqyasında unikal olan bir identifikator alır.
    /// Bu funksiya hansının crate olmasından asılı olmayaraq bir növ üçün eyni dəyəri qaytaracaqdır.
    ///
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::any::TypeId::of`](crate::any::TypeId::of)-dir.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T`-də yaşayış olmadığı təqdirdə heç vaxt icra edilə bilməyən təhlükəli funksiyalar üçün qoruyucu:
    /// Bu statik olaraq ya panic, ya da heç bir şey etməyəcəkdir.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` sıfır başlanğıc üçün icazə vermirsə, heç vaxt yerinə yetirilə bilməyən təhlükəli funksiyalar üçün qoruyucu: Bu statik olaraq ya panic, ya da heç bir şey etməyəcəkdir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn assert_zero_valid<T>();

    /// `T`-də etibarsız bit nümunələri varsa, heç vaxt icra edilə bilməyən təhlükəli funksiyalar üçün qoruyucu: Bu statik olaraq ya panic olacaq, ya da heç bir şey etməyəcəkdir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn assert_uninit_valid<T>();

    /// Harada çağırıldığını göstərən statik bir `Location`-ə istinad edir.
    ///
    /// Bunun əvəzinə [`core::panic::Location::caller`](crate::panic::Location::caller) istifadə etməyi düşünün.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Dəyişdirmə yapışqan işləmədən bir dəyəri əhatə dairəsindən kənarlaşdırır.
    ///
    /// Bu yalnız [`mem::forget_unsized`] üçün mövcuddur;normal `forget` əvəzinə `ManuallyDrop` istifadə edir.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Bir növün dəyərinin bitlərini başqa bir növ kimi yenidən şərh edir.
    ///
    /// Hər iki növün də eyni ölçüsü olmalıdır.
    /// Nə orijinal, nə də nəticə [invalid value](../../nomicon/what-unsafe-does.html) ola bilməz.
    ///
    /// `transmute` semantik cəhətdən bir növün digərinə bitliklə keçməsinə bərabərdir.Bitləri mənbə dəyərindən təyinat dəyərinə köçürür, sonra orijinalını unudur.
    /// Eynən `transmute_copy` kimi, başlıq altında C-nin `memcpy`-nə bərabərdir.
    ///
    /// `transmute` bir dəyər əməliyyatı olduğundan,*köçürülmüş dəyərlərin özlərinin* uyğunlaşdırılması narahatlıq doğurmur.
    /// Digər hər hansı bir funksiyada olduğu kimi, kompilyator artıq həm `T`, həm də `U`-nin düzgün hizalanmasını təmin edir.
    /// Bununla birlikdə,*başqa bir yerə işarə edən* dəyərləri ötürərkən (göstəricilər, istinadlar, qutular ...), zəng edən şəxs işarələnmiş dəyərlərin düzgün uyğunlaşdırılmasını təmin etməlidir.
    ///
    /// `transmute` **inanılmaz dərəcədə** təhlükəlidir.Bu funksiya ilə [undefined behavior][ub]-ə səbəb olmağın bir çox yolu var.`transmute` mütləq son çarə olmalıdır.
    ///
    /// [nomicon](../../nomicon/transmutes.html)-də əlavə sənədlər var.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute`-nin həqiqətən faydalı olduğu bir neçə şey var.
    ///
    /// Bir göstəricini funksiya göstəricisinə çevirmək.Bu funksiya göstəricilərinin və məlumat göstəricilərinin fərqli ölçülərə sahib olduğu maşınlar üçün * portativ deyil.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Bir ömrü uzatmaq və ya dəyişməz bir ömrü qısaltmaq.Bu inkişaf etmiş, çox təhlükəli Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ümidsiz olma: `transmute`-in bir çox istifadəsinə başqa vasitələrlə də nail olmaq olar.
    /// Aşağıda daha etibarlı konstruksiyalarla əvəzlənə bilən ümumi `transmute` tətbiqləri var.
    ///
    /// bytes(`&[u8]`)-i `u32`, `f64` vs.-ə çevirmək.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // əvəzinə `u32::from_ne_bytes` istifadə edin
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // və ya endianness təyin etmək üçün `u32::from_le_bytes` və ya `u32::from_be_bytes` istifadə edin
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Bir göstəricini `usize`-ə çevirmək:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Bunun əvəzinə `as` aktyor istifadə edin
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T`-i `&mut T`-ə çevirmək:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Bunun əvəzinə yenidən doğma istifadə edin
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T`-i `&mut U`-ə çevirmək:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // İndi `as`-i bir araya gətirin və yenidən doğun, `as` `as`-nin zəncirinin keçid olmadığını unutmayın.
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str`-i `&[u8]`-ə çevirmək:
    ///
    /// ```
    /// // bunu etmək üçün yaxşı bir yol deyil.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // `str::as_bytes` istifadə edə bilərsiniz
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Yoxsa sətir hərfi üzərində nəzarətiniz varsa, sadəcə bir bayt sətrindən istifadə edin
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>`-i `Vec<Option<&T>>`-ə çevirmək.
    ///
    /// Bir konteynerin içindəki növü dəyişdirmək üçün, konteynerin heç bir dəyişməzliyini pozmadığınızdan əmin olmalısınız.
    /// `Vec` üçün bu, daxili tiplərin həm ölçüsü *, həm də hizalanması* uyğun olmalıdır deməkdir.
    /// Digər konteynerlər tipin ölçüsünə, hizalanmasına və ya hətta `TypeId`-yə etibar edə bilər, bu halda konteyner dəyişməzliyini pozmadan transmisyon etmək ümumiyyətlə mümkün olmayacaqdır.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // daha sonra yenidən istifadə edəcəyimiz üçün vector-ni klonlayın
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute istifadə etmək: bu, pis bir fikir olan və Tərifsiz Davranışa səbəb ola biləcək `Vec`-in təyin olunmamış məlumat tərtibatına əsaslanır.
    /////
    /// // Bununla birlikdə, nüsxə yoxdur.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Bu təklif olunan, etibarlı yoldur.
    /// // vector-un hamısını yeni bir massivə kopyalayır.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Bu, məlumat tərtibatına etibar etmədən "transmuting" və `Vec`-in düzgün surətini çıxarmayan, təhlükəli bir yoldur.
    /// // Hərfi mənada `transmute` çağırmaq əvəzinə bir göstərici atışı yerinə yetiririk, lakin orijinal daxili (`&i32`) tipini yenisinə (`Option<&i32>`)-ə çevirmək baxımından bunun eyni xəbərdarlıqları var.
    /////
    /// // Yuxarıda göstərilən məlumatlardan əlavə [`from_raw_parts`] sənədlərinə də baxın.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts sabitləşdikdə bunu yeniləyin.
    ///     // Orijinal vector-nin atılmadığından əmin olun.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` tətbiq:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Bunu etmək üçün bir çox yol var və aşağıdakı (transmute) yolu ilə bir çox problem var.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // birinci: transmute tip təhlükəsiz deyil;təkcə T və
    ///         // U eyni ölçüdədir.
    ///         // İkincisi, burada, eyni yaddaşa işarə edən iki dəyişkən referansınız var.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Bu tip təhlükəsizlik problemlərindən qurtulur;`&mut *` sizə* yalnız *`&mut T` və ya `* mut T`-dən `&mut T` verəcəkdir.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Bununla birlikdə, eyni yaddaşa işarə edən iki dəyişkən referansınız var.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Standart kitabxana bunu belə edir.
    /// // Buna bənzər bir şey etməlisinizsə bu ən yaxşı metoddur
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // İndi eyni yaddaşa işarə edən üç dəyişkən referans var.`slice`, dəyər ret.0 və dəyər ret.1.
    ///         // `slice` `let ptr = ...`-dən sonra heç vaxt istifadə edilmir və buna görə "dead" kimi qəbul edilə bilər və bu səbəbdən yalnız iki dəyişkən dilim var.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Bu, daxili konstu stabil olmasına baxmayaraq, const fn-də bəzi xüsusi kodlarımız var
    // `const fn` daxilində istifadəsinə mane olan çeklər.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` olaraq verilən həqiqi tip damla yapışqan tələb edirsə `true` qaytarır;`T` üçün verilən faktiki tip `Copy` tətbiq edərsə `false` qaytarır.
    ///
    ///
    /// Həqiqi tip nə açılan yapışqan tələb etmirsə və ya `Copy` tətbiq etmirsə, bu funksiyanın qaytarma dəyəri dəqiqləşdirilməyib.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`mem::needs_drop`](crate::mem::needs_drop)-dir.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Bir göstəricidən ofset hesablayır.
    ///
    /// Bu, tam ədədə çevrilməmək üçün daxili olaraq tətbiq olunur, çünki konversiya yalnış məlumatları atacaq.
    ///
    /// # Safety
    ///
    /// Həm başlanğıc, həm də nəticələnən göstərici hüdudlarda və ya ayrılmış bir obyektin sonundan bir bayt keçməlidir.
    /// Hər hansı bir göstərici sərhəd xaricindədirsə və ya arifmetik daşqın baş verərsə, qaytarılmış dəyərin hər hansı bir sonrakı istifadəsi təyin olunmamış davranışla nəticələnir.
    ///
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`pointer::offset`]-dir.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Potensial olaraq bükülmüş bir göstəricidən ofset hesablayır.
    ///
    /// Konversiya müəyyən optimallaşdırmaları maneə törətdiyindən, bu, tam ədədə çevrilməkdən qorunmaq üçün daxili olaraq həyata keçirilir.
    ///
    /// # Safety
    ///
    /// `offset` daxili fərqli olaraq, bu daxili, yaranan göstəricini ayrılmış bir obyektin ucuna və ya bir bayta yaxınlaşmağı məhdudlaşdırmır və ikisinin tamamlayıcı hesabı ilə sarılır.
    /// Yaranan dəyər, həqiqətən yaddaşa daxil olmaq üçün istifadə olunmaq üçün mütləq etibarlı deyil.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`pointer::wrapping_offset`]-dir.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` ölçüsü və uyğunluğu ilə uyğun daxili `llvm.memcpy.p0i8.0i8.*`-ə bərabərdir.
    ///
    /// `min_align_of::<T>()`
    ///
    /// Uçucu parametr `true` olaraq təyin olunduğundan ölçüsü sıfıra bərabər olmadığı müddətdə optimallaşdırılmayacaq.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Müvafiq `llvm.memmove.p0i8.0i8.*`-ə bərabərdir, ölçüsü `count* size_of::<T>()` və hizalanması ilə
    ///
    /// `min_align_of::<T>()`
    ///
    /// Uçucu parametr `true` olaraq təyin olunduğundan ölçüsü sıfıra bərabər olmadığı müddətdə optimallaşdırılmayacaq.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` ölçüsü və `min_align_of::<T>()` uyğunluğu ilə uyğun daxili `llvm.memset.p0i8.*`-ə bərabərdir.
    ///
    ///
    /// Uçucu parametr `true` olaraq təyin olunduğundan ölçüsü sıfıra bərabər olmadığı müddətdə optimallaşdırılmayacaq.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` göstəricisindən uçucu bir yük yerinə yetirir.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::ptr::read_volatile`](crate::ptr::read_volatile)-dir.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` göstəricisinə uçucu bir mağaza həyata keçirir.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::ptr::write_volatile`](crate::ptr::write_volatile)-dir.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` göstəricisindən uçucu bir yük yerinə yetirir Göstəricinin hizalanması tələb olunmur.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` göstəricisinə uçucu bir mağaza həyata keçirir.
    /// İşarənin hizalanması tələb olunmur.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32`-in kvadrat kökünü qaytarır
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64`-in kvadrat kökünü qaytarır
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32`-i tam gücə qaldırır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64`-i tam gücə qaldırır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` sinusunu qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` sinusunu qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Bir `f32` kosinusunu qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Bir `f64` kosinusunu qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32`-i `f32` gücünə qaldırır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64`-i `f64` gücünə qaldırır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32`-in eksponentini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64`-in eksponentini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` gücünə qaldırılan 2-ni qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` gücünə qaldırılan 2-ni qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32`-in təbii loqaritmasını qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64`-in təbii loqaritmasını qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32`-in əsas 10 loqaritmasını qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64`-in əsas 10 loqaritmasını qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32`-in əsas 2 loqaritmasını qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64`-in əsas 2 loqaritmasını qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` dəyərləri üçün `a * b + c` qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` dəyərləri üçün `a * b + c` qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32`-in mütləq dəyərini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64`-in mütləq dəyərini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Minimum iki `f32` dəyərini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Minimum iki `f64` dəyərini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Maksimum iki `f32` dəyərini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Maksimum iki `f64` dəyərini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` dəyərləri üçün işarəni `y`-dən `x`-ə kopyalayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` dəyərləri üçün işarəni `y`-dən `x`-ə kopyalayır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32`-dən az və ya bərabər olan ən böyük tam ədədi qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64`-dən az və ya bərabər olan ən böyük tam ədədi qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32`-dən böyük və ya bərabər olan ən kiçik tam ədədi qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64`-dən böyük və ya bərabər olan ən kiçik tam ədədi qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32`-in tam hissəsini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64`-in tam hissəsini qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Ən yaxın tam ədədi `f32`-ə qaytarır.
    /// Arqument tam deyilsə, qeyri-dəqiq bir üzən nöqtə istisnası yarada bilər.
    pub fn rintf32(x: f32) -> f32;
    /// Ən yaxın tam ədədi `f64`-ə qaytarır.
    /// Arqument tam deyilsə, qeyri-dəqiq bir üzən nöqtə istisnası yarada bilər.
    pub fn rintf64(x: f64) -> f64;

    /// Ən yaxın tam ədədi `f32`-ə qaytarır.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ən yaxın tam ədədi `f64`-ə qaytarır.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Ən yaxın tam ədədi `f32`-ə qaytarır.Yarım yollu halları sıfırdan uzaqlaşdırır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Ən yaxın tam ədədi `f64`-ə qaytarır.Yarım yollu halları sıfırdan uzaqlaşdırır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Cəbri qaydalara əsaslanan optimallaşdırmalara imkan verən şamandıra əlavə.
    /// Girişlərin sonlu olduğunu qəbul edə bilər.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Cəbri qaydalara əsaslanan optimallaşdırmalara imkan verən şamandıra çıxarma.
    /// Girişlərin sonlu olduğunu qəbul edə bilər.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Cəbri qaydalara əsaslanan optimallaşdırmalara imkan verən şamandıra vurma.
    /// Girişlərin sonlu olduğunu qəbul edə bilər.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Cəbri qaydalara əsaslanan optimallaşdırmalara imkan verən üzmə bölməsi.
    /// Girişlərin sonlu olduğunu qəbul edə bilər.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Cəbri qaydalara əsaslanan optimallaşdırmalara imkan yaradan qalıq.
    /// Girişlərin sonlu olduğunu qəbul edə bilər.
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Sıra xaricində olan dəyərlər üçün undef verə bilən LLVM-nin fptoui/fptosi ilə dəyişdirin
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] və [`f64::to_int_unchecked`] kimi sabitləşdirilmişdir.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// `T` tipli tam ədədə qoyulmuş bit sayını qaytarır
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `count_ones` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Tam bir `T` tipli (zeroes) qabaqcıl ayarlanmamış bitlərin sayını qaytarır.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `leading_zeros` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` dəyəri olan bir `x`, `T`-nin bit genişliyini qaytaracaqdır.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` kimi, lakin `0` dəyəri olan bir `x` verildikdə `undef` döndüyü üçün çox təhlükəlidir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Tam bir `T` tipində (zeroes) bitməmiş bitlərin sayını qaytarır.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `trailing_zeros` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` dəyəri olan bir `x`, `T`-nin bit genişliyini qaytaracaqdır:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` kimi, lakin `0` dəyəri olan bir `x` verildikdə `undef` döndüyü üçün çox təhlükəlidir.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// `T` tam tipli baytları tərsinə çevirir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `swap_bytes` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Tam bir `T` tipində bitləri tərsinə çevirir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `reverse_bits` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Yoxlanılan tam ədədi əlavə edir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `overflowing_add` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yoxlanılan tam çıxmağı həyata keçirir
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `overflowing_sub` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yoxlanılan tam ədədi vurmağı həyata keçirir
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `overflowing_mul` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// `x % y != 0` və ya `y == 0` və ya `x == T::MIN && y == -1` olduğu yerlərdə müəyyən bir davranışla nəticələnən dəqiq bir bölmə həyata keçirir
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// `y == 0` və ya `x == T::MIN && y == -1` olduğu yerlərdə təyin olunmayan bir davranışla nəticələnən yoxlanılmamış bir bölmə həyata keçirir
    ///
    ///
    /// Bu daxili üçün etibarlı sarmallar, `checked_div` metodu ilə tam ibtidalarda mövcuddur.
    /// Misal üçün,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` və ya `x == T::MIN && y == -1` olduqda təyin olunmayan davranışla nəticələnən yoxlanılmamış bölmənin qalan hissəsini qaytarır
    ///
    ///
    /// Bu daxili üçün etibarlı sarmallar, `checked_rem` metodu ilə tam ibtidalarda mövcuddur.
    /// Misal üçün,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Yoxlanılmamış sola keçid həyata keçirir və `y < 0` və ya `y >= N` olduqda təyin olunmayan davranışla nəticələnir, burada N bitlərin T-nin enidir.
    ///
    ///
    /// Bu daxili üçün etibarlı sarmallar, `checked_shl` metodu ilə tam ibtidalarda mövcuddur.
    /// Misal üçün,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Yoxlanılmamış sağa keçid həyata keçirir və `y < 0` və ya `y >= N` olduqda təyin olunmayan davranışla nəticələnir, burada N bitlərin T-nin enidir.
    ///
    ///
    /// Bu daxili üçün etibarlı sarmallar, `checked_shr` metodu ilə tam ibtidalarda mövcuddur.
    /// Misal üçün,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// `x + y > T::MAX` və ya `x + y < T::MIN` olduqda təyin olunmayan davranışla nəticələnən yoxlanılmamış bir əlavə nəticəsini qaytarır.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// `x - y > T::MAX` və ya `x - y < T::MIN` olduqda təyin olunmayan davranışla nəticələnən, yoxlanılmayan bir çıxarma nəticəsini qaytarır.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// `x *y > T::MAX` və ya `x* y < T::MIN` olduqda təyin olunmayan davranışla nəticələnən yoxlanılmamış vurma nəticəsini qaytarır.
    ///
    ///
    /// Bu daxili sabit bir həmkarı yoxdur.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Sola döndərir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `rotate_left` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Sağ döndürmə həyata keçirir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `rotate_right` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (A + b) mod 2 <sup>N</sup> qaytarır, burada N bitlərin T-nin enidir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `wrapping_add` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (A, b) mod 2 <sup>N-i</sup> qaytarır, burada N bitlərin T-dəki enidir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `wrapping_sub` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (A * b) mod 2 <sup>N-i</sup> qaytarır, burada N bitlərin T-dəki enidir.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `wrapping_mul` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Rəqəmsal hədlərdə doymuş `a + b` hesablayır.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `saturating_add` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Rəqəmsal hədlərdə doymuş `a - b` hesablayır.
    ///
    /// Bu daxili stabilləşdirilmiş versiyaları `saturating_sub` metodu ilə tam ibtidalar mövcuddur.
    /// Misal üçün,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v'-də variant üçün diskriminantın dəyərini qaytarır;
    /// `T`-də heç bir diskriminant yoxdursa, `0` qaytarır.
    ///
    /// Bu daxili versiyanın sabitləşdirilmiş versiyası [`core::mem::discriminant`](crate::mem::discriminant)-dir.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` tipinin `usize`-ə ötürülmüş variant sayını qaytarır;
    /// `T`-in heç bir variantı yoxdursa, `0` verir.Yaşayış olmayan variantlar sayılacaqdır.
    ///
    /// Bu daxili versiyanın sabitləşdiriləcək versiyası [`mem::variant_count`]-dir.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust-nin "try catch" konstruksiyası, X002 məlumat göstəricisi ilə `try_fn` funksiya göstəricisini işə salır.
    ///
    /// Üçüncü arqument bir panic meydana gəldiyi təqdirdə çağırılan bir funksiyadır.
    /// Bu funksiya, məlumat göstəricisini və bir göstəricini tutulmuş hədəfə məxsus istisna obyektinə aparır.
    ///
    /// Daha çox məlumat üçün kompilyatorun mənbəyinə və std-nin tutma tətbiqinə baxın.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM-ə uyğun olaraq `!nontemporal` mağazası buraxır (sənədlərinə baxın).
    /// Yəqin ki, heç vaxt sabitləşməyəcəkdir.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Ətraflı məlumat üçün `<*const T>::offset_from` sənədlərinə baxın.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Ətraflı məlumat üçün `<*const T>::guaranteed_eq` sənədlərinə baxın.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Ətraflı məlumat üçün `<*const T>::guaranteed_ne` sənədlərinə baxın.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Tərtib zamanı ayırın.İş vaxtında çağırılmamalıdır.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Bəzi funksiyalar burada təsadüfən bu modulda sabit vəziyyətə gətirildikləri üçün müəyyən edilmişdir.
// <https://github.com/rust-lang/rust/issues/15702>-ə baxın.
// (`transmute` də bu kateqoriyaya aiddir, lakin `T` və `U`-in eyni ölçüyə sahib olması səbəbindən bükülə bilməz.)
//

/// `ptr`-in `align_of::<T>()` ilə uyğun olaraq uyğunlaşdırıldığını yoxlayır.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` baytını `src`-dən `dst`-ə kopyalayır.Mənbə və təyinat yeri* üst-üstə düşməməlidir *.
///
/// Yaddaşın üst-üstə düşə biləcəyi bölgələri əvəzinə [`copy`] istifadə edin.
///
/// `copy_nonoverlapping` semantik cəhətdən C-nin [`memcpy`]-nə bərabərdir, lakin mübahisə qaydası dəyişdirildi.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `src` `count * size_of::<T>()` bayt oxunması üçün [valid] olmalıdır.
///
/// * `dst` `count * size_of::<T>()` bayt yazmaq üçün [valid] olmalıdır.
///
/// * Həm `src`, həm də `dst` düzgün şəkildə uyğunlaşdırılmalıdır.
///
/// * `src`-dən başlayan yaddaş bölgəsi, "ölçüsü" ilə *
///   ölçüsü: :<T>() `bayt eyni ölçüdə `dst`-də başlayan yaddaş bölgəsi ilə *üst-üstə düşməməlidir*.
///
/// [`read`] kimi, `copy_nonoverlapping` də `T`-nin [`Copy`] olub-olmamasından asılı olmayaraq `T`-in bit-kopyasını yaradır.
/// `T` [`Copy`] deyilsə,*hər ikisini* istifadə edərək bölgədəki `*src`-dən başlayan və `* dst`-dən başlayan bölgədəki dəyərlər [violate memory safety][read-ownership] ola bilər.
///
///
/// Nəzərə alın ki, effektiv surətdə kopyalanan ölçü də olsa ("count * size_of: :<T>()`) `0`, göstəricilər NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`]-i əl ilə tətbiq edin:
///
/// ```
/// use std::ptr;
///
/// /// `src`-in bütün elementlərini `dst`-ə köçürür və `src`-i boş buraxır.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst`-in bütün `src`-i tutmaq üçün kifayət qədər gücə malik olduğundan əmin olun.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Ofset çağırışı həmişə təhlükəsizdir, çünki `Vec` heç vaxt `isize::MAX` baytdan çox ayırmayacaqdır.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Tərkibini salmadan `src` kəsin.
///         // Bunu əvvəlcə panics-də daha aşağı bir şey olması halında problemlərin qarşısını almaq üçün edirik.
///         src.set_len(0);
///
///         // İki bölgə üst-üstə düşə bilməz, çünki dəyişdirilə bilən istinadlar başqa ad vermir və iki fərqli vectors eyni yaddaşa sahib ola bilməz.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Artıq `src` məzmununa sahib olduğunu `dst`-ə bildirin.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Bu çekləri yalnız işləmə vaxtında həyata keçirin
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Kodgen təsirini daha kiçik tutmaq üçün çaxnaşma deyil.
        abort();
    }*/

    // TƏHLÜKƏSİZLİK: `copy_nonoverlapping` üçün təhlükəsizlik müqaviləsi olmalıdır
    // zəng edən tərəfindən dəstəkləndi.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` baytını `src`-dən `dst`-ə kopyalayır.Mənbə və təyinat yeri üst-üstə düşə bilər.
///
/// Mənbə və təyinat yeri *heç vaxt* üst-üstə düşməzsə, bunun əvəzinə [`copy_nonoverlapping`] istifadə edilə bilər.
///
/// `copy` semantik cəhətdən C-nin [`memmove`]-nə bərabərdir, lakin mübahisə qaydası dəyişdirildi.
/// Kopyalama sanki baytlar `src`-dən müvəqqəti bir massivə kopyalanmış və sonra massivdən `dst`-ə kopyalanmış kimi baş verir.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `src` `count * size_of::<T>()` bayt oxunması üçün [valid] olmalıdır.
///
/// * `dst` `count * size_of::<T>()` bayt yazmaq üçün [valid] olmalıdır.
///
/// * Həm `src`, həm də `dst` düzgün şəkildə uyğunlaşdırılmalıdır.
///
/// [`read`] kimi, `copy` də `T`-nin [`Copy`] olub-olmamasından asılı olmayaraq `T`-in bit-kopyasını yaradır.
/// `T` [`Copy`] deyilsə, həm bölgədəki `*src`-dən başlayan dəyərlərdən, həm də `* dst`-dən başlayan bölgədən istifadə edərək [violate memory safety][read-ownership] edə bilərsiniz.
///
///
/// Nəzərə alın ki, effektiv surətdə kopyalanan ölçü də olsa ("count * size_of: :<T>()`) `0`, göstəricilər NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Təhlükəsiz bir tampondan səmərəli bir Rust vector yaradın:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` növü və sıfır üçün düzgün hizalanmalıdır.
/// /// * `ptr` `T` tipli bitişik `elts` elementlərinin oxunuşları üçün etibarlı olmalıdır.
/// /// * `T: Copy` olmadıqca, bu funksiya çağırıldıqdan sonra həmin elementlər istifadə edilməməlidir.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // TƏHLÜKƏSİZLİK: Ön şərtimiz mənbənin hizalanmasını və etibarlı olmasını təmin edir,
///     // və `Vec::with_capacity` bunları yazmaq üçün əlverişli məkanımızın olmasını təmin edir.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // TƏHLÜKƏSİZLİK: Bunu əvvəllər bu qədər tutumla yaratdıq,
///     // və əvvəlki `copy` bu elementləri işə saldı.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Bu çekləri yalnız işləmə vaxtında həyata keçirin
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Kodgen təsirini daha kiçik tutmaq üçün çaxnaşma deyil.
        abort();
    }*/

    // TƏHLÜKƏSİZLİK: `copy` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən təmin edilməlidir.
    unsafe { copy(src, dst, count) }
}

/// `dst`-dən `val`-ə qədər başlayan yaddaşın `count * size_of::<T>()` baytını təyin edir.
///
/// `write_bytes` C-nin [`memset`]-nə bənzəyir, lakin `count * size_of::<T>()` baytını `val`-ə təyin edir.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `dst` `count * size_of::<T>()` bayt yazmaq üçün [valid] olmalıdır.
///
/// * `dst` düzgün uyğunlaşdırılmalıdır.
///
/// Əlavə olaraq, zəng edən şəxs verilən yaddaş bölgəsinə `count * size_of::<T>()` bayt yazmağın etibarlı bir `T` dəyərinə səbəb olmasını təmin etməlidir.
/// `T` dəyərini ehtiva edən `T` kimi yazılmış yaddaş bölgəsini istifadə etmək, təyin olunmamış davranışdır.
///
/// Nəzərə alın ki, effektiv surətdə kopyalanan ölçü də olsa ("count * size_of: :<T>()`) `0`, göstərici NULL olmamalı və düzgün hizalanmalıdır.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Yanlış bir dəyər yaratmaq:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>`-i sıfır göstərici ilə yazaraq əvvəllər tutulan dəyəri sızdırır.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Bu nöqtədə `v` istifadə və ya düşmə, təyin olunmamış davranışla nəticələnir.
/// // drop(v); // ERROR
///
/// // `v` "uses"-dən belə sızdırmaq və buna görə də müəyyən olmayan bir davranışdır.
/// // mem::forget(v); // ERROR
///
/// // Əslində, `v`, əsas tip düzeni dəyişməzlərinə görə etibarsızdır, buna görə *hər hansı bir* əməliyyat, ona toxunulmayan bir davranışdır.
/////
/// // v2 =v olsun;//XATA
///
/// unsafe {
///     // Bunun əvəzinə etibarlı bir dəyər qoyaq
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // İndi qutu yaxşıdır
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // TƏHLÜKƏSİZLİK: `write_bytes` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən təmin edilməlidir.
    unsafe { write_bytes(dst, val, count) }
}