//! Xam göstəricilər vasitəsilə yaddaşı əl ilə idarə edin.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Bu moduldakı bir çox funksiya xam göstəriciləri arqument kimi qəbul edir və oxuyur və ya onlara yazır.Bunun təhlükəsiz olması üçün bu göstəricilər *etibarlı* olmalıdır.
//! Bir göstəricinin etibarlı olub olmaması, istifadə olunduğu əməliyyatdan (oxumaq və ya yazmaq) və əldə olunan yaddaşın həcmindən (yəni read/written neçə bayt olduğu) asılıdır.
//! Əksər funksiyalar `*mut T` və `* const T`-dən yalnız bir dəyərə daxil olmaq üçün istifadə edirlər, bu halda sənədlər ölçünü buraxır və dolayısı ilə `size_of::<T>()` bayt olaraq qəbul edir.
//!
//! Keçid üçün dəqiq qaydalar hələ müəyyənləşdirilməyib.Bu nöqtədə verilən zəmanətlər çox azdır:
//!
//! * Bir [null] göstəricisi *heç vaxt* etibarlı deyil, hətta [size zero][zst] girişləri üçün belə.
//! * Bir göstəricinin etibarlı olması üçün göstəricinin *tərif edilə bilən* olması zəruridir, lakin hər zaman kifayət deyil: göstəricidən başlayan verilən ölçünün yaddaş aralığı hamısı ayrılmış bir obyektin hüdudlarında olmalıdır.
//!
//! Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
//! * [size zero][zst] əməliyyatları üçün belə göstərici ayrılmış yaddaşa işarə etməməlidir, yəni ayırma sıfır ölçülü əməliyyatlar üçün göstəriciləri etibarsız edir.
//! Bununla birlikdə, hər hansı bir sıfır olmayan tam ədədi *hərf* bir göstəriciyə tökmək, həmin ünvanda bəzi yaddaşlar baş versə və ayrılsa da, sıfır ölçülü girişlər üçün etibarlıdır.
//! Bu, öz ayırıcınızı yazmağa uyğundur: sıfır ölçülü obyektlərin ayrılması çox çətin deyil.
//! Sıfır ölçülü girişlər üçün etibarlı bir göstərici əldə etməyin kanonik yolu [`NonNull::dangling`]-dir.
//! * Bu moduldakı funksiyalar tərəfindən həyata keçirilən bütün girişlər, mövzuları arasında sinxronizasiya etmək üçün istifadə olunan [atomic operations] mənasında *atomik deyil*.
//! Bu, hər iki giriş yalnız yaddaşdan oxunmadığı təqdirdə, fərqli mövzulardan eyni yerə iki paralel girişin həyata keçirilməsinin qeyri-müəyyən bir davranış olduğu deməkdir.
//! Bunun açıq şəkildə [`read_volatile`] və [`write_volatile`] ehtiva etdiyinə diqqət yetirin: Uçucu girişlər mövzuarası sinxronizasiya üçün istifadə edilə bilməz.
//! * İstinad göstəricisinə istinadın nəticəsi, əsas obyekt canlı olduğu müddətdə etibarlıdır və eyni yaddaşı əldə etmək üçün heç bir istinad (yalnız xam göstəricilər) istifadə olunmur.
//!
//! Bu aksiomalar, göstərici hesabı üçün [`offset`]-in ehtiyatlı istifadəsi ilə yanaşı, bir çox faydalı şeyi təhlükəli kodda düzgün tətbiq etmək üçün kifayətdir.
//! [aliasing] qaydaları müəyyənləşdirildiyi üçün nəticədə daha güclü zəmanətlər veriləcək.
//! Daha çox məlumat üçün [book]-ə və istinaddakı [undefined behavior][ub]-ə həsr olunmuş hissəyə baxın.
//!
//! ## Alignment
//!
//! Yuxarıda göstərildiyi kimi etibarlı xammal göstəriciləri mütləq düzgün bir şəkildə hizalanmır (burada "proper" düzəliş pointee növü ilə təyin olunur, yəni `*const T` `mem::align_of::<T>()`-ə uyğunlaşdırılmalıdır).
//! Bununla birlikdə, əksər funksiyalar arqumentlərinin düzgün uyğunlaşdırılmasını tələb edir və sənədlərdə bu tələbi açıq şəkildə göstərəcəkdir.
//! Bunun nəzərə çarpan istisnaları [`read_unaligned`] və [`write_unaligned`]-dir.
//!
//! Bir funksiya uyğun bir uyğunlaşma tələb etdikdə, girişin ölçüsü 0 olsa da, yəni yaddaşa həqiqətən toxunulmasa belə bunu edir.Belə hallarda [`NonNull::dangling`] istifadə etməyi düşünün.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// İşarəli dəyərin destruktorunu (əgər varsa) icra edir.
///
/// Bu, semantik cəhətdən [`ptr::read`]-i axtarmağa və nəticəni ləğv etməyə bərabərdir, lakin aşağıdakı üstünlüklərə malikdir:
///
/// * trait obyektləri kimi ölçüsüz tipləri buraxmaq üçün `drop_in_place` istifadə etmək * tələb olunur, çünki yığın üzərində oxunub normal düşə bilməzlər.
///
/// * Əl ilə ayrılmış yaddaşı (məsələn, `Box`/`Rc`/`Vec` tətbiqlərində) buraxarkən bunu [`ptr::read`]-dən çox etmək optimizator üçün daha rahatdır, çünki tərtibçinin nüsxəni ələ keçirmək üçün səs olduğunu sübut etməyə ehtiyac yoxdur.
///
///
/// * `T` `repr(packed)` olmadığı zaman [pinned] məlumatlarını buraxmaq üçün istifadə edilə bilər (sabitlənmiş məlumatlar düşmədən əvvəl köçürülməməlidir).
///
/// Hizalanmamış dəyərlər yerə atıla bilməz, əvvəlcə [`ptr::read_unaligned`] istifadə edərək hizalanmış bir yerə kopyalanmalıdır.Paketli quruluşlar üçün bu hərəkət avtomatik olaraq tərtibçi tərəfindən həyata keçirilir.
/// Bu o deməkdir ki, dolu konstruksiyaların sahələri yerində atılmayacaq.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `to_drop` həm oxumaq həm də yazmaq üçün [valid] olmalıdır.
///
/// * `to_drop` düzgün uyğunlaşdırılmalıdır.
///
/// * `to_drop` göstəricilərinin düşməsi üçün etibarlı olmalıdır, yəni əlavə dəyişməzləri dəstəkləməsi lazım ola bilər, bu növdən asılıdır.
///
/// Əlavə olaraq, `T` [`Copy`] deyilsə, `drop_in_place` çağırıldıqdan sonra işarələnmiş dəyəri istifadə etmək, təyin olunmamış davranışa səbəb ola bilər.`*to_drop = foo` in dəyərin yenidən düşməsinə səbəb olacağı üçün bir istifadə saydığını unutmayın.
/// [`write()`] məlumatların düşməsinə səbəb olmadan onu yazmaq üçün istifadə edilə bilər.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Son elementi vector-dan əl ilə silin:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // `v`-də son elementə xam bir göstərici əldə edin.
///     let ptr = &mut v[1] as *mut _;
///     // Son elementin atılmasının qarşısını almaq üçün `v` qısaltın.
///     // Əvvəlcə panics altındakı `drop_in_place` probleminin qarşısını almaq üçün edirik.
///     v.set_len(1);
///     // `drop_in_place` zəngi olmasa, sonuncu maddə heç vaxt atılmayacaq və idarə etdiyi yaddaş sızacaqdır.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Son maddənin atıldığından əmin olun.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Diqqət yetirin ki, kompilyator bu nüsxəni qablaşdırılmış konstruksiyaları atarkən avtomatik olaraq həyata keçirir, yəni `drop_in_place`-yə əl ilə zəng etmədiyiniz təqdirdə ümumiyyətlə bu kimi məsələlər barədə narahat olmağınız lazım deyil.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Buradakı kodun heç bir əhəmiyyəti yoxdur, bunu tərtibçi tərəfindən həqiqi damla yapışqan əvəz edir.
    //

    // TƏHLÜKƏSİZLİK: yuxarıdakı şərhə baxın
    unsafe { drop_in_place(to_drop) }
}

/// Sıf xam bir göstərici yaradır.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Sıfır dəyişdirilə bilən xam göstərici yaradır.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// `T: Clone` bağlanmaması üçün əl ilə göstərmə lazımdır.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// `T: Copy` bağlanmaması üçün əl ilə göstərmə lazımdır.
impl<T> Copy for FatPtr<T> {}

/// Bir göstəricidən və bir uzunluqdan xam bir dilim meydana gətirir.
///
/// `len` arqumenti, bayt sayı deyil,**element** sayıdır.
///
/// Bu funksiya təhlükəsizdir, lakin həqiqətən qaytarma dəyərindən istifadə etmək təhlükəlidir.
/// Dilim təhlükəsizliyi tələbləri üçün [`slice::from_raw_parts`] sənədlərinə baxın.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // ilk elementə bir göstərici ilə başlayarkən bir dilim göstəricisi yaradın
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // TƏHLÜKƏSİZLİK: `Repr` birləşməsindən alınan dəyər * const [T]-dən etibarən etibarlıdır
        //
        // və FatPtr eyni yaddaş planlarına sahibdir.Bu zəmanəti yalnız std edə bilər.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// [`slice_from_raw_parts`] ilə eyni funksiyanı yerinə yetirir, ancaq xam dəyişməz dilimdən fərqli olaraq xam dəyişkən dilim qaytarılır.
///
///
/// Daha ətraflı məlumat üçün [`slice_from_raw_parts`] sənədlərinə baxın.
///
/// Bu funksiya təhlükəsizdir, lakin həqiqətən qaytarma dəyərindən istifadə etmək təhlükəlidir.
/// Dilim təhlükəsizliyi tələbləri üçün [`slice::from_raw_parts_mut`] sənədlərinə baxın.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // dilimdəki bir indeksdə bir dəyər təyin edin
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // TƏHLÜKƏSİZLİK: `Repr` birləşməsindən alınan dəyər * mut [T]-dən etibarən etibarlıdır
        // və FatPtr eyni yaddaş planlarına sahibdir
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Həm deinisallaşdırmadan eyni tipli iki dəyişkən yerdə dəyərləri dəyişdirir.
///
/// Ancaq aşağıdakı iki istisna üçün bu funksiya [`mem::swap`]-ə semantik cəhətdən bərabərdir:
///
///
/// * Referanslar əvəzinə xam göstəricilərdə işləyir.
/// Referanslar olduqda [`mem::swap`] seçim edilməlidir.
///
/// * İki işarəli dəyər üst-üstə düşə bilər.
/// Dəyərlər üst-üstə düşürsə, `x`-dən üst-üstə düşən yaddaş bölgəsi istifadə olunur.
/// Bu, aşağıdakı ikinci nümunədə göstərilmişdir.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * Həm oxumaq həm də yazmaq üçün həm `x`, həm də `y` [valid] olmalıdır.
///
/// * Həm `x`, həm də `y` düzgün şəkildə uyğunlaşdırılmalıdır.
///
/// `T` `0` ölçüsünə sahib olsa da, göstəricilərin NULL olmamalı və düzgün bir şəkildə hizalanmalı olduğunu unutmayın.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Çakışmayan iki bölgənin dəyişdirilməsi:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // bu `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // bu `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Çakışan iki bölgənin dəyişdirilməsi:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // bu `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // bu `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Dilimin `1..3` indeksləri `x` ilə `y` arasında üst-üstə düşür.
///     // Makul nəticələr onlar üçün `[2, 3]` olmalıdır, beləliklə `0..3` indeksləri `[1, 2, 3]` (`swap`-dən əvvəl `y` ilə uyğunlaşır);ya da `[0, 1]` göstəricilərinin `[0, 1, 2]` olması üçün `[0, 1]` olması (`swap` dan əvvəl `x` ilə uyğunlaşması).
/////
///     // Bu tətbiq sonuncu seçim etmək üçün müəyyən edilmişdir.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Özümüzə işləmək üçün bir az cızmaq yeri verin.
    // Damla barədə narahat olmağımız lazım deyil: `MaybeUninit` düşəndə heç bir şey etməz.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Dəyişdirmə TƏHLÜKƏSİZLİYİNİ yerinə yetirin: zəng edən `x` və `y` yazıları üçün etibarlı və düzgün hizalanmış olduğuna zəmanət verməlidir.
    // `tmp` `x` və ya `y` üst-üstə düşə bilməz, çünki `tmp` yalnız ayrı bir ayrılmış obyekt kimi yığına ayrılmışdı.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` və `y` üst-üstə düşə bilər
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// `x` və `y`-dən başlayan iki yaddaş bölgəsi arasında `count * size_of::<T>()` baytları dəyişdirir.
/// İki bölgə *üst-üstə düşməməlidir*.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * Həm saymaq həm oxumaq, həm də yazmaq üçün həm `x`, həm də `y` [valid] olmalıdır *
///   ölçüsü: :<T>() `bayt.
///
/// * Həm `x`, həm də `y` düzgün şəkildə uyğunlaşdırılmalıdır.
///
/// * `x`-dən başlayan yaddaş bölgəsi, "ölçüsü" ilə *
///   ölçüsü: :<T>() `bayt eyni ölçüdə `y`-də başlayan yaddaş bölgəsi ilə *üst-üstə düşməməlidir*.
///
/// Nəzərə alın ki, effektiv surətdə kopyalanan ölçü də olsa ("count * size_of: :<T>()`) `0`, göstəricilər NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // TƏHLÜKƏSİZLİK: zəng edən `x` və `y` olduqlarına zəmanət verməlidir
    // yazılar üçün etibarlı və düzgün bir şəkildə hizalanmışdır.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Aşağıdakı blok optimallaşdırmasından kiçik növlər üçün, kodlaşdırıcıyı pessimizasiya etməmək üçün birbaşa dəyişdirin.
    //
    if mem::size_of::<T>() < 32 {
        // TƏHLÜKƏSİZLİK: zəng edən `x` və `y`-in etibarlı olmasına zəmanət verməlidir
        // yazılar, düzgün bir şəkildə hizalanmış və üst-üstə düşməyənlər üçün.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // TƏHLÜKƏSİZLİK: zəng edən `swap_nonoverlapping` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Buradakı yanaşma x&y-ni səmərəli dəyişdirmək üçün simd-dən istifadə etməkdir.
    // Test, bir anda 32 bayt və ya 64 bayt dəyişdirməyin Intel Haswell E prosessorları üçün ən təsirli olduğunu göstərir.
    // LLVM, bir quruluşa bir #[repr(simd)] verdiyimiz təqdirdə, bu quruluşu birbaşa istifadə etməməyimizə baxmayaraq daha çox optimallaşdırmağı bacarır.
    //
    //
    // FIXME repr(simd) yazılmış və redoksda qırılmışdır
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // X&y arasında dövr edin, onları `Block`-ni eyni anda kopyalayın Optimizator əksər növlər üçün döngəni tam açmalıdır NB
    // `range` implinin `mem::swap`-i rekursiv olaraq çağırdığı üçün for for istifadə edə bilmirik
    //
    let mut i = 0;
    while i + block_size <= len {
        // Çizilmə yeri olduğu üçün bəzi başlanğıc olunmamış yaddaş yaradın, burada `t` elan etmək, bu döngə istifadə edilmədikdə yığının düzəldilməsinin qarşısını alır.
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // TƏHLÜKƏSİZLİK: `i < len` olaraq və zəng edən `x` və `y`-in etibarlı olmasına zəmanət verməlidir.
        // `len` bayt üçün `x + i` və `y + i`, `add` üçün təhlükəsizlik müqaviləsini yerinə yetirən etibarlı ünvanlar olmalıdır.
        //
        // Ayrıca, zəng edən `x` və `y`-in `copy_nonoverlapping` üçün təhlükəsizlik müqaviləsini yerinə yetirən yazılar, düzgün bir şəkildə hizalanması və üst-üstə düşməməsi üçün etibarlı olmasını təmin etməlidir.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // T-ni müvəqqəti tampon olaraq istifadə edərək bir x bayt blokunu dəyişdirin Bu mövcud olduğu yerlərdə səmərəli SIMD əməliyyatlarında optimallaşdırılmalıdır
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Qalan baytları dəyişdirin
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // TƏHLÜKƏSİZLİK: əvvəlki təhlükəsizlik şərhinə baxın.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// `src`-i əvvəlki `dst` dəyərini qaytararaq sivri `dst`-ə keçir.
///
/// Heç bir dəyər düşmür.
///
/// Bu funksiya, istinadlar əvəzinə xam göstəricilərdə işləməsi xaricində [`mem::replace`]-ə bərabərdir.
/// Referanslar olduqda [`mem::replace`] seçim edilməlidir.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `dst` həm oxumaq həm də yazmaq üçün [valid] olmalıdır.
///
/// * `dst` düzgün uyğunlaşdırılmalıdır.
///
/// * `dst` `T` tipli düzgün başlanğıc edilmiş bir dəyəri göstərməlidir.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` təhlükəli blok tələb etmədən eyni təsiri olardı.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `dst`-nin etibarlı olduğuna zəmanət verməlidir
    // dəyişdirilə bilən bir referansa atılır (yazmaq, hizalamaq, işə salmaq üçün etibarlıdır) və X001 üst-üstə düşə bilməz, çünki `dst` ayrı bir ayrılmış obyektə işarə etməlidir.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // üst-üstə düşə bilməz
    }
    src
}

/// Dəyəri hərəkət etdirmədən `src`-dən oxuyur.Bu, `src` yaddaşını dəyişməz vəziyyətə gətirir.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `src` oxumaq üçün [valid] olmalıdır.
///
/// * `src` düzgün uyğunlaşdırılmalıdır.Əgər belə deyilsə [`read_unaligned`] istifadə edin.
///
/// * `src` `T` tipli düzgün başlanğıc edilmiş bir dəyəri göstərməlidir.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`]-i əl ilə tətbiq edin:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp`-də `a` dəyərinin bir bitlik surətini yaradın.
///         let tmp = ptr::read(a);
///
///         // Bu nöqtədən çıxmaq (açıq şəkildə geri qayıtmaqla və ya panics funksiyasını çağırmaqla) `tmp`-də dəyərin düşməsinə səbəb olarkən eyni dəyər hələ də `a` tərəfindən istinad edilir.
///         // `T` `Copy` deyilsə, bu, təyin olunmamış davranışı tetikleyebilir.
/////
/////
///
///         // `a`-də `b` dəyərinin bir bitlik surətini yaradın.
///         // Bu təhlükəsizdir, çünki dəyişdirilə bilən istinadlar taxma ad verə bilməz.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Yuxarıda olduğu kimi, buradan çıxmaq, təyin olunmamış davranışı tetikleyebilir, çünki eyni dəyər `a` və `b` tərəfindən istinad edilir.
/////
///
///         // `tmp`-i `b`-ə köçürün.
///         ptr::write(b, tmp);
///
///         // `tmp` köçürüldü (`write` ikinci arqumentin sahibliyini öz üzərinə götürür), buna görə burada heç bir şey dolayı şəkildə buraxılmır.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Geri qaytarılmış dəyərin mülkiyyəti
///
/// `read` `T`-nin [`Copy`] olub-olmamasından asılı olmayaraq `T`-in bir bitlik surətini yaradır.
/// `T` [`Copy`] deyilsə, həm qaytarılmış dəyərdən, həm də `*src`-dəki dəyərdən istifadə etmək yaddaş təhlükəsizliyini poza bilər.
/// `*src`-ə atamağın `* src`-də dəyərini azaltmağa çalışacağı üçün bir istifadə sayacağını unutmayın.
///
/// [`write()`] məlumatların düşməsinə səbəb olmadan onu yazmaq üçün istifadə edilə bilər.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` indi `s` ilə eyni əsas yaddaşa işarə edir.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // `s2`-ə təyin etmək orijinal dəyərinin düşməsinə səbəb olur.
///     // Bu nöqtədən kənarda `s` artıq istifadə edilməməlidir, çünki əsas yaddaş azad edilmişdir.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // `s`-ə təyin etmək, köhnə dəyərin yenidən düşməsinə və müəyyən olmayan davranışla nəticələnməsinə səbəb olardı.
/////
///     // s= String::from("bar");//XATA
///
///     // `ptr::write` bir dəyəri düşmədən onun üzərinə yazmaq üçün istifadə edilə bilər.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // TƏHLÜKƏSİZLİK: zəng edən `src`-nin oxunması üçün etibarlı olduğuna zəmanət verməlidir.
    // `src` `tmp` üst-üstə düşə bilməz, çünki `tmp` yalnız ayrı bir ayrılmış obyekt kimi yığına ayrılmışdı.
    //
    //
    // Bundan əlavə, `tmp`-ə etibarlı bir dəyər yazdığımızdan, düzgün başlanğıcın verilməsi təmin edilir.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Dəyəri hərəkət etdirmədən `src`-dən oxuyur.Bu, `src` yaddaşını dəyişməz vəziyyətə gətirir.
///
/// [`read`]-dən fərqli olaraq, `read_unaligned` hizalanmamış göstəricilərlə işləyir.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `src` oxumaq üçün [valid] olmalıdır.
///
/// * `src` `T` tipli düzgün başlanğıc edilmiş bir dəyəri göstərməlidir.
///
/// [`read`] kimi, `read_unaligned` də `T`-nin [`Copy`] olub-olmamasından asılı olmayaraq `T`-in bit-kopyasını yaradır.
/// `T` [`Copy`] deyilsə, həm qaytarılmış dəyəri, həm də `*src`-dəki dəyəri istifadə edərək [violate memory safety][read-ownership] edə bilərsiniz.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalıdır.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed` quruluşlarında
///
/// Dolu bir strukturun hizalanmamış sahələrinə xammal göstəriciləri yaratmaq hazırda mümkün deyil.
///
/// `&packed.unaligned as *const FieldType` kimi bir ifadə ilə bir `unaligned` struct sahəsinə xam bir göstərici yaratmağa cəhd etmək, onu xam bir göstəriciyə çevirmədən əvvəl aralıq düzəldilməmiş bir istinad yaradır.
///
/// Bu arayışın müvəqqəti olması və dərhal aktarmanın əhəmiyyətsiz olmasıdır, çünki tərtibçi həmişə istinadların düzgün bir şəkildə uyğunlaşdırılmasını gözləyir.
/// Nəticədə, `&packed.unaligned as *const FieldType` istifadə edərək proqramınızda dərhal* təyin olunmayan davranışa səbəb olur.
///
/// Nə edilməməli və bunun `read_unaligned` ilə necə əlaqəli olduğuna bir nümunədir:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Burada hizalanmamış 32 bitlik tam ədədin adresini götürməyə çalışırıq.
///     let unaligned =
///         // Burada müvəqqəti imzalanmamış bir istinad yaradılır və bu, istinaddan istifadə edilib edilməməsindən asılı olmayaraq müəyyən olmayan bir davranışla nəticələnir.
/////
///         &packed.unaligned
///         // Xam bir göstəriciyə tökmə kömək etmir;səhv onsuz da baş verdi.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Lakin, məsələn, `packed.unaligned` ilə birbaşa işarələnməmiş sahələrə giriş təhlükəsizdir.
///
///
///
///
///
///
// FIXME: RFC #2582 və dostlarının nəticələrinə əsasən sənədləri yeniləyin.
/// # Examples
///
/// Bir bayt buferindən istifadə dəyərini oxuyun:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // TƏHLÜKƏSİZLİK: zəng edən `src`-nin oxunması üçün etibarlı olduğuna zəmanət verməlidir.
    // `src` `tmp` üst-üstə düşə bilməz, çünki `tmp` yalnız ayrı bir ayrılmış obyekt kimi yığına ayrılmışdı.
    //
    //
    // Bundan əlavə, `tmp`-ə etibarlı bir dəyər yazdığımızdan, düzgün başlanğıcın verilməsi təmin edilir.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Köhnə dəyəri oxumadan və ya düşmədən verilmiş dəyərlə yaddaş yerini yenidən yazır.
///
/// `write` `dst` məzmunu düşmür.
/// Bu təhlükəsizdir, ancaq ayırmalar və ya qaynaqlar sıza bilər, buna görə atılmalı olan bir obyektin üzərinə yazmamağa diqqət yetirilməlidir.
///
///
/// Əlavə olaraq, `src` düşmür.Semantik olaraq, `src`, `dst` tərəfindən göstərilən yerə köçürülür.
///
/// Bu, başlanğıc olunmamış yaddaşın başlanğıc edilməsi və ya əvvəllər [`read`] olan yaddaşın üzərində yazılması üçün uygundur.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `dst` yazmaq üçün [valid] olmalıdır.
///
/// * `dst` düzgün uyğunlaşdırılmalıdır.Əgər belə deyilsə [`write_unaligned`] istifadə edin.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`]-i əl ilə tətbiq edin:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp`-də `a` dəyərinin bir bitlik surətini yaradın.
///         let tmp = ptr::read(a);
///
///         // Bu nöqtədən çıxmaq (açıq şəkildə geri qayıtmaqla və ya panics funksiyasını çağırmaqla) `tmp`-də dəyərin düşməsinə səbəb olarkən eyni dəyər hələ də `a` tərəfindən istinad edilir.
///         // `T` `Copy` deyilsə, bu, təyin olunmamış davranışı tetikleyebilir.
/////
/////
///
///         // `a`-də `b` dəyərinin bir bitlik surətini yaradın.
///         // Bu təhlükəsizdir, çünki dəyişdirilə bilən istinadlar taxma ad verə bilməz.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Yuxarıda olduğu kimi, buradan çıxmaq, təyin olunmamış davranışı tetikleyebilir, çünki eyni dəyər `a` və `b` tərəfindən istinad edilir.
/////
///
///         // `tmp`-i `b`-ə köçürün.
///         ptr::write(b, tmp);
///
///         // `tmp` köçürüldü (`write` ikinci arqumentin sahibliyini öz üzərinə götürür), buna görə burada heç bir şey dolayı şəkildə buraxılmır.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // `intrinsics::copy_nonoverlapping` bir sarmalayıcı funksiyası olduğu üçün yaradılan koddakı funksiya çağırışlarından qaçınmaq üçün daxili şəxsləri birbaşa çağırırıq.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // TƏHLÜKƏSİZLİK: zəng edən `dst`-nin yazılar üçün etibarlı olduğuna zəmanət verməlidir.
    // `dst` `src` ilə üst-üstə düşə bilməz, çünki `src` bu funksiyaya sahib olduğu halda, zəng edənin `dst`-ə dəyişkən girişi var.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Köhnə dəyəri oxumadan və ya düşmədən verilmiş dəyərlə yaddaş yerini yenidən yazır.
///
/// [`write()`]-dən fərqli olaraq, göstərici hizalanmamış ola bilər.
///
/// `write_unaligned` `dst` məzmunu düşmür.Bu təhlükəsizdir, ancaq ayırmalar və ya qaynaqlar sıza bilər, buna görə atılmalı olan bir obyektin üzərinə yazmamağa diqqət yetirilməlidir.
///
/// Əlavə olaraq, `src` düşmür.Semantik olaraq, `src`, `dst` tərəfindən göstərilən yerə köçürülür.
///
/// Bu, başlanğıc olunmamış yaddaşın başlanğıc edilməsi və ya əvvəllər [`read_unaligned`] ilə oxunan yaddaşın üzərinə yazılması üçün uyğundur.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `dst` yazmaq üçün [valid] olmalıdır.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalıdır.
///
/// [valid]: self#safety
///
/// ## `packed` quruluşlarında
///
/// Dolu bir strukturun hizalanmamış sahələrinə xammal göstəriciləri yaratmaq hazırda mümkün deyil.
///
/// `&packed.unaligned as *const FieldType` kimi bir ifadə ilə bir `unaligned` struct sahəsinə xam bir göstərici yaratmağa cəhd etmək, onu xam bir göstəriciyə çevirmədən əvvəl aralıq düzəldilməmiş bir istinad yaradır.
///
/// Bu arayışın müvəqqəti olması və dərhal aktarmanın əhəmiyyətsiz olmasıdır, çünki tərtibçi həmişə istinadların düzgün bir şəkildə uyğunlaşdırılmasını gözləyir.
/// Nəticədə, `&packed.unaligned as *const FieldType` istifadə edərək proqramınızda dərhal* təyin olunmayan davranışa səbəb olur.
///
/// Nə edilməməli və bunun `write_unaligned` ilə necə əlaqəli olduğuna bir nümunədir:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Burada hizalanmamış 32 bitlik tam ədədin adresini götürməyə çalışırıq.
///     let unaligned =
///         // Burada müvəqqəti imzalanmamış bir istinad yaradılır və bu, istinaddan istifadə edilib edilməməsindən asılı olmayaraq müəyyən olmayan bir davranışla nəticələnir.
/////
///         &mut packed.unaligned
///         // Xam bir göstəriciyə tökmə kömək etmir;səhv onsuz da baş verdi.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Lakin, məsələn, `packed.unaligned` ilə birbaşa işarələnməmiş sahələrə giriş təhlükəsizdir.
///
///
///
///
///
///
///
///
///
// FIXME: RFC #2582 və dostlarının nəticələrinə əsasən sənədləri yeniləyin.
/// # Examples
///
/// Bir bayt tamponuna bir istifadə dəyəri yazın:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // TƏHLÜKƏSİZLİK: zəng edən `dst`-nin yazılar üçün etibarlı olduğuna zəmanət verməlidir.
    // `dst` `src` ilə üst-üstə düşə bilməz, çünki `src` bu funksiyaya sahib olduğu halda, zəng edənin `dst`-ə dəyişkən girişi var.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Yaradılan kodda funksiya çağırışlarının qarşısını almaq üçün birbaşa daxili çağırırıq.
        intrinsics::forget(src);
    }
}

/// `src`-dən dəyəri dəyişmədən oxumaq yerinə yetirir.Bu, `src` yaddaşını dəyişməz vəziyyətə gətirir.
///
/// Uçucu əməliyyatlar I/O yaddaşında işləmək üçün nəzərdə tutulur və digər uçucu əməliyyatlar zamanı kompilyator tərəfindən seçilməməsi və ya yenidən sıralanmaması təmin edilir.
///
/// # Notes
///
/// Rust hazırda ciddi və rəsmi olaraq müəyyən edilmiş bir yaddaş modelinə sahib deyil, buna görə "volatile"-in burada mənasını verən dəqiq semantikası zamanla dəyişə bilər.
/// Demək olar ki, semantik demək olar ki, həmişə [C11's definition of volatile][c11]-ə bənzəyir.
///
/// Tərtibçi dəyişkən yaddaş əməliyyatlarının nisbi qaydasını və ya sayını dəyişdirməməlidir.
/// Bununla birlikdə, sıfır ölçülü tiplər üzərində uçucu yaddaş əməliyyatları (məsələn, sıfır ölçülü bir tip `read_volatile`-ə ötürülürsə) noops və laqeyd edilə bilər.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `src` oxumaq üçün [valid] olmalıdır.
///
/// * `src` düzgün uyğunlaşdırılmalıdır.
///
/// * `src` `T` tipli düzgün başlanğıc edilmiş bir dəyəri göstərməlidir.
///
/// [`read`] kimi, `read_volatile` də `T`-nin [`Copy`] olub-olmamasından asılı olmayaraq `T`-in bit-kopyasını yaradır.
/// `T` [`Copy`] deyilsə, həm qaytarılmış dəyəri, həm də `*src`-dəki dəyəri istifadə edərək [violate memory safety][read-ownership] edə bilərsiniz.
/// Bununla birlikdə, ['Kopyala'] olmayan növlərin uçucu yaddaşda saxlanması demək olar ki, səhvdir.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Eynilə C-də olduğu kimi, əməliyyatın dəyişkən olub-olmaması, birdən çox mövzudan paralel girişlə bağlı suallara heç bir təsir göstərmir.Uçucu girişlər bu baxımdan atom olmayan girişlər kimi davranır.
///
/// Xüsusilə, `read_volatile` ilə eyni yerə yazma əməliyyatı arasındakı bir yarış, təyin olunmamış davranışdır.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Kodgen təsirini daha kiçik tutmaq üçün çaxnaşma deyil.
        abort();
    }
    // TƏHLÜKƏSİZLİK: zəng edən `volatile_load` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe { intrinsics::volatile_load(src) }
}

/// Köhnə dəyəri oxumadan və ya düşmədən verilmiş dəyərlə yaddaş yerini dəyişkən yazmağı həyata keçirir.
///
/// Uçucu əməliyyatlar I/O yaddaşında işləmək üçün nəzərdə tutulur və digər uçucu əməliyyatlar zamanı kompilyator tərəfindən seçilməməsi və ya yenidən sıralanmaması təmin edilir.
///
/// `write_volatile` `dst` məzmunu düşmür.Bu təhlükəsizdir, ancaq ayırmalar və ya qaynaqlar sıza bilər, buna görə atılmalı olan bir obyektin üzərinə yazmamağa diqqət yetirilməlidir.
///
/// Əlavə olaraq, `src` düşmür.Semantik olaraq, `src`, `dst` tərəfindən göstərilən yerə köçürülür.
///
/// # Notes
///
/// Rust hazırda ciddi və rəsmi olaraq müəyyən edilmiş bir yaddaş modelinə sahib deyil, buna görə "volatile"-in burada mənasını verən dəqiq semantikası zamanla dəyişə bilər.
/// Demək olar ki, semantik demək olar ki, həmişə [C11's definition of volatile][c11]-ə bənzəyir.
///
/// Tərtibçi dəyişkən yaddaş əməliyyatlarının nisbi qaydasını və ya sayını dəyişdirməməlidir.
/// Bununla birlikdə, sıfır ölçülü tiplər üzərində uçucu yaddaş əməliyyatları (məsələn, sıfır ölçülü bir tip `write_volatile`-ə ötürülürsə) noops və laqeyd edilə bilər.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `dst` yazmaq üçün [valid] olmalıdır.
///
/// * `dst` düzgün uyğunlaşdırılmalıdır.
///
/// Qeyd edək ki, `T` `0` ölçüsündə olsa da, göstərici NULL olmamalı və düzgün bir şəkildə hizalanmalıdır.
///
/// [valid]: self#safety
///
/// Eynilə C-də olduğu kimi, əməliyyatın dəyişkən olub-olmaması, birdən çox mövzudan paralel girişlə bağlı suallara heç bir təsir göstərmir.Uçucu girişlər bu baxımdan atom olmayan girişlər kimi davranır.
///
/// Xüsusilə, `write_volatile` ilə eyni yerdəki hər hansı bir əməliyyat (oxu və ya yazma) arasındakı bir yarış, təyin olunmamış davranışdır.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Kodgen təsirini daha kiçik tutmaq üçün çaxnaşma deyil.
        abort();
    }
    // TƏHLÜKƏSİZLİK: zəng edən `volatile_store` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// `p` göstəricisini düzəldin.
///
/// `p` göstəricisinə `a` ilə uyğunlaşması üçün `p` göstəricisinə tətbiq olunmalı olan ofseti (`stride` addımının elementləri baxımından) hesablayın.
///
/// Note: Bu tətbiq diqqətlə panic olaraq hazırlanmışdır.Bunun üçün panic üçün UB.
/// Burada edilə bilən yeganə real dəyişiklik `INV_TABLE_MOD_16` və əlaqəli sabitlərin dəyişməsidir.
///
/// Heç birinin ikisinin gücü olmayan `a` ilə daxili çağırmağı mümkün etməyə qərar verdiyimiz təqdirdə, bu dəyişikliyə uyğunlaşmağa çalışmaqdansa, sadəcə sadəlövh bir tətbiqetməyə keçmək daha ağıllı olar.
///
///
/// Hər hansı bir sualınız@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Bu daxili maddələrin birbaşa istifadəsi optogen səviyyə <=səviyyəsində kodgeni əhəmiyyətli dərəcədə yaxşılaşdırır
    // 1, bu əməliyyatların metod versiyalarının üstü çizilmədiyi.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// `x` modulunun `m`-nin vurma modul tərsini hesablayın.
    ///
    /// Bu tətbiq `align_offset` üçün hazırlanmışdır və aşağıdakı şərtlərə malikdir:
    ///
    /// * `m` ikinin gücüdür;
    /// * `x < m`; (`x ≥ m` olarsa, `x % m`-ə keçin)
    ///
    /// Bu funksiyanın həyata keçirilməsi panic olmayacaqdır.Həmişə.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Çarpan modul tərs cədvəl modulu 2⁴=16.
        ///
        /// Diqqət yetirin, bu cədvəldə tərsinin olmadığı dəyərlər yoxdur (yəni `0⁻¹ mod 16`, `2⁻¹ mod 16` və s. Üçün).
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` üçün nəzərdə tutulmuş modul.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // TƏHLÜKƏSİZLİK: `m`-in ikiqat gücü olması, buna görə sıfır olmaması lazımdır.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Aşağıdakı formulu istifadə edərək "up"-i təkrarlayırıq:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // qədər 2²ⁿ ≥ m.Sonra `mod m` nəticəsini alaraq istədiyimiz `m`-ə endirə bilərik.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Buradakı sarma əməliyyatlarını qəsdən istifadə etdiyimizə diqqət yetirin-orijinal formulda, məsələn, `mod n` çıxarma istifadə olunur.
                // Bunun yerinə `mod usize::MAX` etmək tamamilə yaxşıdır, çünki nəticədə `mod n` nəticəsini alırıq.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // TƏHLÜKƏSİZLİK: `a` ikisinin gücüdür, buna görə sıfır deyil.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` hal `-p (mod a)` ilə daha sadə hesablana bilər, lakin bunu etmək LLVM-nin `lea` kimi təlimatları seçmək qabiliyyətini maneə törədir.Bunun əvəzinə hesablayırıq
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // əməliyyatları yük daşıyan ətrafa paylayır, lakin LLVM-nin bildiyi müxtəlif optimallaşdırmalardan istifadə edə bilməsi üçün `and`-i kifayət qədər pessimizasiya edir.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Artıq hizalanmışdır.Hey!
        return 0;
    } else if stride == 0 {
        // Göstərici düzəldilməyibsə və element sıfır ölçülüdürsə, heç bir element heç vaxt göstəricini düzəldə bilməz.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // TƏHLÜKƏSİZLİK: a ikisinin gücü, bu səbəbdən sıfır deyil.stride==0 halda yuxarıda baxılır.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // TƏHLÜKƏSİZLİK: gcdpow, ən çox istifadə səviyyəsində bit sayına bərabər olan yuxarı sərhədlidir.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // TƏHLÜKƏSİZLİK: gcd həmişə böyük və ya 1-ə bərabərdir.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Bu branch aşağıdakı xətti uyğunluq tənliyini həll edir:
        //
        // ` p + so = 0 mod a `
        //
        // `p` burada göstərici dəyəri, `s`, `T` addım, `o` ofset `T`s və `a`, tələb olunan hizalama.
        //
        // `g = gcd(a, s)` ilə və yuxarıdakı şərtlə `p`-in də `g`-ə bölündüyünü təsdiqləyərək `a' = a/g`, `s' = s/g`, `p' = p/g`-i qeyd edə bilərik, onda bu bərabərdir:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Birinci müddət "the relative alignment of `p` to `a`" (bölünən `g`), ikinci müddət "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (yenidən `g` bölünür).
        //
        // `g` ilə bölünmə, `a` və `s`-lərin bərabər səviyyəli olmadığı təqdirdə tərs yaxşı əmələ gəlməsi üçün lazımdır.
        //
        // Bundan əlavə, bu həll yolu ilə çıxarılan nəticə "minimal" deyil, buna görə `o mod lcm(s, a)` nəticəsini almaq lazımdır.`lcm(s, a)`-i yalnız `a'` ilə əvəz edə bilərik.
        //
        //
        //
        //
        //

        // TƏHLÜKƏSİZLİK: `gcdpow`, `a`-də arxada qalan 0-bit sayından çox olmayan yuxarı sərhədlidir.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // TƏHLÜKƏSİZLİK: `a2` sıfır deyil.`a`-dən `gcdpow`-ə keçmək, müəyyən edilmiş bitlərdən heç birini dəyişə bilməz
        // `a`-də (bunlardan tam biri var).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // TƏHLÜKƏSİZLİK: `gcdpow`, `a`-də arxada qalan 0-bit sayından çox olmayan yuxarı sərhədlidir.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // TƏHLÜKƏSİZLİK: `gcdpow`, arxadakı 0-bit sayından çox olmayan yuxarı sərhədlidir
        // `a`.
        // Bundan əlavə, çıxarma aça bilməz, çünki `a2 = a >> gcdpow` həmişə `(p % a) >> gcdpow`-dən çox böyük olacaqdır.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // TƏHLÜKƏSİZLİK: `a2`, yuxarıda sübut edildiyi kimi ikiqat gücdür.`s2` tamamilə `a2`-dən azdır
        // çünki `(s % a) >> gcdpow` tamamilə `a >> gcdpow`-dən azdır.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Heç bir şəkildə düzəldilə bilməz.
    usize::MAX
}

/// Bərabərlik üçün göstəriciləri müqayisə edir.
///
/// Bu, `==` operatorunu istifadə etməklə eynidir, lakin daha az ümumi:
/// arqumentlər X001 tətbiq edən heç bir şey deyil, `*const T` xam göstəriciləri olmalıdır.
///
/// Bu, `&T` istinadlarını (dolayısıyla `*const T`-ə məcbur edən) göstərdikləri dəyərləri müqayisə etmək əvəzinə ünvanları ilə müqayisə etmək üçün istifadə edilə bilər (bu, `PartialEq for &T` tətbiqetməsini edir).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Dilimlər uzunluqlarına (yağ göstəricilərinə) görə də müqayisə olunur:
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits tətbiqləri ilə də müqayisə olunur:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Göstəricilərin bərabər ünvanları var.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Nesnələrin bərabər ünvanları var, lakin `Trait` fərqli tətbiqlərə malikdir.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // İstinadın bir `*const u8`-ə çevrilməsi ünvanı ilə müqayisə olunur.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Xam bir göstəricini yuyun.
///
/// Bu, bir `&T` referansını (`*const T`-ə dolayısı ilə məcbur edən) göstərdiyi dəyərdən daha çox ünvanı (`Hash for &T` tətbiqetməsini yerinə yetirən) ilə qarışdırmaq üçün istifadə edilə bilər.
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Funksiya göstəriciləri üçün impls
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR üçün usize kimi orta aktyor tələb olunur
                // mənbə funksiyası göstəricisinin ünvan sahəsi son funksiya göstəricisində qorunması üçün.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR üçün usize kimi orta aktyor tələb olunur
                // mənbə funksiyası göstəricisinin ünvan sahəsi son funksiya göstəricisində qorunması üçün.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 0 parametrli variadik funksiyalar yoxdur
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Aralıq bir istinad yaratmadan bir yerə bir `const` xammal göstəricisi yaradın.
///
/// `&`/`&mut` ilə istinad yaratmağa yalnız göstərici düzgün hizalandıqda və başlanğıc verilənləri göstərdikdə icazə verilir.
/// Bu tələblərin yerinə yetirilmədiyi hallarda, əvəzinə xam göstəricilər istifadə olunmalıdır.
/// Bununla birlikdə, `&expr as *const _`, xam bir göstəriciyə tökmədən əvvəl bir istinad yaradır və bu istinad bütün digər istinadlarla eyni qaydalara tabedir.
///
/// Bu makro əvvəlcə bir istinad yaratmadan * bir xam göstərici yarada bilər.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` imzasız bir istinad yaratacaq və beləliklə Müəyyən Olmayan Davranış olacaqdır!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Aralıq bir istinad yaratmadan bir yerə bir `mut` xammal göstəricisi yaradın.
///
/// `&`/`&mut` ilə istinad yaratmağa yalnız göstərici düzgün hizalandıqda və başlanğıc verilənləri göstərdikdə icazə verilir.
/// Bu tələblərin yerinə yetirilmədiyi hallarda, əvəzinə xam göstəricilər istifadə olunmalıdır.
/// Bununla birlikdə, `&mut expr as *mut _`, xam bir göstəriciyə tökmədən əvvəl bir istinad yaradır və bu istinad bütün digər istinadlarla eyni qaydalara tabedir.
///
/// Bu makro əvvəlcə bir istinad yaratmadan * bir xam göstərici yarada bilər.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` imzasız bir istinad yaratacaq və beləliklə Müəyyən Olmayan Davranış olacaqdır!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` arayış yaratmaq əvəzinə sahəni kopyalamağa məcbur edir.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}