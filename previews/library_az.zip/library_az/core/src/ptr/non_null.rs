use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` lakin sıfır olmayan və dəyişəndir.
///
/// Bu, tez-tez xammal göstəricilərindən istifadə edərək məlumat strukturları qurarkən istifadə edilən düzgün bir şeydir, lakin əlavə xüsusiyyətlərinə görə istifadə etmək son nəticədə daha təhlükəlidir.`NonNull<T>` istifadə etməyinizə əmin deyilsinizsə, `*mut T` istifadə edin!
///
/// `*mut T`-dən fərqli olaraq, göstərici heç vaxt istinad edilməməsinə baxmayaraq, göstərici hər zaman sıfır olmalıdır.Enumların bu qadağan edilmiş dəyərdən bir diskriminant kimi istifadə edə bilməsi üçün-`Option<NonNull<T>>`, `* mut T` ilə eyni ölçüyə malikdir.
/// Buna baxmayaraq, göstərici verilmədiyi təqdirdə göstərici hələ də sürünə bilər.
///
/// `*mut T`-dən fərqli olaraq, `NonNull<T>`, `T`-dən fərqli olaraq seçilmişdir.Bu, kovariant növləri qurarkən `NonNull<T>`-dən istifadə etməyi mümkün edir, lakin kovariant olmamalı bir növdə istifadə olunarsa, səssizlik riski yaranır.
/// (Texniki cəhətdən əsassızlığa yalnız təhlükəli funksiyaları çağırmaq səbəb ola bilsə də, əks seçim `*mut T` üçün edildi.)
///
/// Kovaryans, `Box`, `Rc`, `Arc`, `Vec` ve `LinkedList` kimi ən təhlükəsiz soyutlamalar üçün doğrudur.Bu, normal Rust-nin paylaşılan XOR dəyişkən qaydalarına riayət edən ümumi bir API təmin etdikləri üçün belədir.
///
/// Tipiniz təhlükəsiz bir şəkildə dəyişə bilmirsə, dəyişməzliyi təmin etmək üçün əlavə bir sahə ehtiva etməlisiniz.Tez-tez bu sahə `PhantomData<Cell<T>>` və ya `PhantomData<&'a mut T>` kimi bir [`PhantomData`] tipi olacaqdır.
///
/// `NonNull<T>`-in `&T` üçün `From` nümunəsinə sahib olduğuna diqqət yetirin.Bununla birlikdə, bu, bir mutasiyanın [`UnsafeCell<T>`] içərisində olmadığı təqdirdə (a-dan əldə edilmiş göstərici) paylaşılan istinad vasitəsilə mutasiyanın təyin olunmamış bir davranış olmasını dəyişdirmir.Eyni, paylaşılan bir istinaddan dəyişdirilə bilən bir istinad yaratmaq üçün də tətbiq olunur.
///
/// Bu `From` nümunəsini `UnsafeCell<T>` olmadan istifadə edərkən, `as_mut`-in heç vaxt çağırılmamasını və `as_ptr`-in mutasiya üçün istifadə edilməməsini təmin etmək sizin məsuliyyətinizdir.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` göstəricilər `Send` deyil, çünki istinad etdikləri məlumatlar yumşaq ola bilər.
// NB, bu işarə lazım deyil, ancaq daha yaxşı səhv mesajları verməlidir.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` göstəricilər `Sync` deyil, çünki istinad etdikləri məlumatlar yumşaq ola bilər.
// NB, bu işarə lazım deyil, ancaq daha yaxşı səhv mesajları verməlidir.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Asılı, lakin yaxşı hizalanmış yeni bir `NonNull` yaradır.
    ///
    /// Bu, `Vec::new` kimi tənbəlliklə ayıran növləri işə salmaq üçün faydalıdır.
    ///
    /// Qeyd edək ki, göstərici dəyəri potensial olaraq `T` üçün etibarlı bir göstəricini təmsil edə bilər, yəni bunun "not yet initialized" nəzarətçi dəyəri kimi istifadə edilməməsi lazımdır.
    /// Tənbəlliklə ayıran növlər başlanğıc vəziyyətini başqa yollarla izləməlidir.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // TƏHLÜKƏSİZLİK: mem::align_of(), sıfır olmayan bir istifadəni geri qaytarır
        // a * mut T.
        // Bu səbəbdən `ptr` sıfır deyil və new_unchecked() çağırma şərtlərinə hörmət edilir.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Dəyər üçün paylaşılan istinadları qaytarır.[`as_ref`]-dən fərqli olaraq, bu dəyərin başlanğıc edilməsini tələb etmir.
    ///
    /// Dəyişdirilə bilən həmkar üçün [`as_uninit_mut`]-ə baxın.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən aşağıdakıların hamısının doğru olduğundan əmin olmalısınız:
    ///
    /// * Göstərici düzgün bir şəkildə hizalanmalıdır.
    ///
    /// * [the module documentation]-də müəyyən edilmiş mənada "dereferencable" olmalıdır.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaş mutasiyaya uğramamalıdır (`UnsafeCell` içərisi xaricində).
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in bütün tələblərə cavab verdiyinə zəmanət verməlidir
        // istinad üçün tələblər.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Dəyərə bənzərsiz bir istinad gətirir.[`as_mut`]-dən fərqli olaraq, bu dəyərin başlanğıc edilməsini tələb etmir.
    ///
    /// Paylaşılan həmkar üçün [`as_uninit_ref`]-ə baxın.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən aşağıdakıların hamısının doğru olduğundan əmin olmalısınız:
    ///
    /// * Göstərici düzgün bir şəkildə hizalanmalıdır.
    ///
    /// * [the module documentation]-də müəyyən edilmiş mənada "dereferencable" olmalıdır.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaşa başqa bir göstərici vasitəsilə daxil olmaq (oxumaq və ya yazmaq) lazım deyil.
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in bütün tələblərə cavab verdiyinə zəmanət verməlidir
        // istinad üçün tələblər.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Yeni `NonNull` yaradır.
    ///
    /// # Safety
    ///
    /// `ptr` sıfır olmamalıdır.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // TƏHLÜKƏSİZLİK: zəng edən `ptr`-nin boş olmadığını təmin etməlidir.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` sıfır olduqda yeni bir `NonNull` yaradır.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // TƏHLÜKƏSİZLİK: Göstərici artıq yoxlanılıb və boş deyil
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] ilə eyni funksiyanı yerinə yetirir, yalnız bir `*const` göstəricisindən fərqli olaraq bir `NonNull` göstəricisi qaytarılır.
    ///
    ///
    /// Daha ətraflı məlumat üçün [`std::ptr::from_raw_parts`] sənədlərinə baxın.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // TƏHLÜKƏSİZLİK: `ptr::from::raw_parts_mut`-in nəticəsi sıfırdır, çünki `data_address`-dir.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// (Geniş ola bilər) bir göstəricini ünvan və metadata komponentlərinə ayırın.
    ///
    /// Göstərici daha sonra [`NonNull::from_raw_parts`] ilə yenidən qurula bilər.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Əsas `*mut` göstəricisini alır.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dəyər üçün paylaşılan bir istinad qaytarır.Qiymət başlanğıc edilə bilməzsə, bunun əvəzinə [`as_uninit_ref`] istifadə edilməlidir.
    ///
    /// Dəyişdirilə bilən həmkar üçün [`as_mut`]-ə baxın.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən aşağıdakıların hamısının doğru olduğundan əmin olmalısınız:
    ///
    /// * Göstərici düzgün bir şəkildə hizalanmalıdır.
    ///
    /// * [the module documentation]-də müəyyən edilmiş mənada "dereferencable" olmalıdır.
    ///
    /// * Göstərici `T` başlanğıc nümunəsini göstərməlidir.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaş mutasiyaya uğramamalıdır (`UnsafeCell` içərisi xaricində).
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    /// (Başlanğıcla əlaqəli bir hissə hələ tam olaraq həll edilməmişdir, amma bu qədər yeganə etibarlı yanaşma, həqiqətən başlanğıc verildiyini təmin etməkdir.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in bütün tələblərə cavab verdiyinə zəmanət verməlidir
        // istinad üçün tələblər.
        unsafe { &*self.as_ptr() }
    }

    /// Dəyərə bənzərsiz bir istinad qaytarır.Qiymət başlanğıc edilə bilməzsə, bunun əvəzinə [`as_uninit_mut`] istifadə edilməlidir.
    ///
    /// Paylaşılan həmkar üçün [`as_ref`]-ə baxın.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən aşağıdakıların hamısının doğru olduğundan əmin olmalısınız:
    ///
    /// * Göstərici düzgün bir şəkildə hizalanmalıdır.
    ///
    /// * [the module documentation]-də müəyyən edilmiş mənada "dereferencable" olmalıdır.
    ///
    /// * Göstərici `T` başlanğıc nümunəsini göstərməlidir.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaşa başqa bir göstərici vasitəsilə daxil olmaq (oxumaq və ya yazmaq) lazım deyil.
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    /// (Başlanğıcla əlaqəli bir hissə hələ tam olaraq həll edilməmişdir, amma bu qədər yeganə etibarlı yanaşma, həqiqətən başlanğıc verildiyini təmin etməkdir.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in bütün tələblərə cavab verdiyinə zəmanət verməlidir
        // dəyişdirilə bilən bir istinad üçün tələblər.
        unsafe { &mut *self.as_ptr() }
    }

    /// Başqa tipli bir göstəriciyə atılır.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // TƏHLÜKƏSİZLİK: `self` mütləq sıfır olmayan bir `NonNull` göstəricisidir
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// İncə bir göstəricidən və uzunluqdan sıfır olmayan xam dilim yaradır.
    ///
    /// `len` arqumenti, bayt sayı deyil,**element** sayıdır.
    ///
    /// Bu funksiya təhlükəsizdir, lakin qaytarma dəyərinin ayrılması təhlükəlidir.
    /// Dilim təhlükəsizliyi tələbləri üçün [`slice::from_raw_parts`] sənədlərinə baxın.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ilk elementə bir göstərici ilə başlayarkən bir dilim göstəricisi yaradın
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Diqqət yetirin ki, bu nümunə süni şəkildə bu metodun istifadəsini nümayiş etdirir, ancaq `dilim= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // TƏHLÜKƏSİZLİK: `data` mütləq sıfır olmayan bir `NonNull` göstəricisidir
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Sıfır olmayan xam dilimin uzunluğunu qaytarır.
    ///
    /// Qaytarılan dəyər, bayt sayı deyil,**element** sayındadır.
    ///
    /// Sıfır olmayan xam dilim bir dilimə verilə bilmədiyi halda belə, bu funksiya təhlükəsizdir, çünki göstəricinin etibarlı bir ünvanı yoxdur.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Boş olmayan bir göstəricini dilimin tamponuna qaytarır.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // TƏHLÜKƏSİZLİK: `self`-in sıfır olduğunu bilirik.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Çiy göstəricini dilimin tamponuna qaytarır.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Bəlkə də başlanğıc edilməmiş dəyərlərin bir diliminə paylaşılan bir istinad gətirir.[`as_ref`]-dən fərqli olaraq, bu dəyərin başlanğıc edilməsini tələb etmir.
    ///
    /// Dəyişdirilə bilən həmkar üçün [`as_uninit_slice_mut`]-ə baxın.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən aşağıdakıların hamısının doğru olduğundan əmin olmalısınız:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` çox bayt oxumaq üçün göstərici [valid] olmalıdır və düzgün hizalanmalıdır.Bu xüsusən:
    ///
    ///     * Bu dilimin bütün yaddaş aralığı ayrılmış bir obyekt daxilində olmalıdır!
    ///       Dilimlər heç vaxt bir çox ayrılmış obyekt arasında yayıla bilməz.
    ///
    ///     * Sıfır uzunluqlu dilimlər üçün də göstərici hizalanmalıdır.
    ///     Bunun bir səbəbi, enum layout optimallaşdırmalarının digər məlumatlardan fərqləndirmək üçün hizalanmış və boş olmayan istinadlara (istənilən uzunluqdakı dilimlər daxil olmaqla) etibar edə bilməsi.
    ///
    ///     [`NonNull::dangling()`] istifadə edərək sıfır uzunluqlu dilimlər üçün `data` kimi istifadə edilə bilən bir göstərici əldə edə bilərsiniz.
    ///
    /// * Dilimin ümumi ölçüsü `ptr.len() * mem::size_of::<T>()`, `isize::MAX`-dən böyük olmamalıdır.
    ///   [`pointer::offset`] təhlükəsizlik sənədlərinə baxın.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaş mutasiyaya uğramamalıdır (`UnsafeCell` içərisi xaricində).
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    ///
    /// [`slice::from_raw_parts`]-ə də baxın.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // TƏHLÜKƏSİZLİK: zəng edən `as_uninit_slice` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Bəlkə də başlanğıc olunmamış dəyərlərin bir diliminə bənzərsiz bir istinad gətirir.[`as_mut`]-dən fərqli olaraq, bu dəyərin başlanğıc edilməsini tələb etmir.
    ///
    /// Paylaşılan həmkar üçün [`as_uninit_slice`]-ə baxın.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən aşağıdakıların hamısının doğru olduğundan əmin olmalısınız:
    ///
    /// * Göstərici `ptr.len() * mem::size_of::<T>()` çox bayt oxumaq və yazmaq üçün [valid] olmalıdır və düzgün hizalanmalıdır.Bu xüsusən:
    ///
    ///     * Bu dilimin bütün yaddaş aralığı ayrılmış bir obyekt daxilində olmalıdır!
    ///       Dilimlər heç vaxt bir çox ayrılmış obyekt arasında yayıla bilməz.
    ///
    ///     * Sıfır uzunluqlu dilimlər üçün də göstərici hizalanmalıdır.
    ///     Bunun bir səbəbi, enum layout optimallaşdırmalarının digər məlumatlardan fərqləndirmək üçün hizalanmış və boş olmayan istinadlara (istənilən uzunluqdakı dilimlər daxil olmaqla) etibar edə bilməsi.
    ///
    ///     [`NonNull::dangling()`] istifadə edərək sıfır uzunluqlu dilimlər üçün `data` kimi istifadə edilə bilən bir göstərici əldə edə bilərsiniz.
    ///
    /// * Dilimin ümumi ölçüsü `ptr.len() * mem::size_of::<T>()`, `isize::MAX`-dən böyük olmamalıdır.
    ///   [`pointer::offset`] təhlükəsizlik sənədlərinə baxın.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaşa başqa bir göstərici vasitəsilə daxil olmaq (oxumaq və ya yazmaq) lazım deyil.
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    ///
    /// [`slice::from_raw_parts_mut`]-ə də baxın.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory`, `memory.len()` üçün çox bayt oxumaq və yazmaq üçün etibarlı olduğu üçün təhlükəsizdir.
    /// // `memory.as_mut()`-in zəng edilməsinə icazə verilmədiyini nəzərə alsaq, məzmun başlanğıc ola bilməz.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // TƏHLÜKƏSİZLİK: zəng edən `as_uninit_slice_mut` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Xammal göstəricisini sərhədləri yoxlamadan bir elementə və ya alt hissəyə qaytarır.
    ///
    /// Bu metodu sərhəd xaricində bir indekslə çağırmaq və ya `self`-nin təyin edilmədiyi zaman * *[təyin olunmamış davranış] * nəticə çıxarılan göstərici istifadə olunmasa da.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in ayrılabilməsini və `index`-in sərhədsiz olmasını təmin edir.
        // Nəticə olaraq, yaranan göstərici NULL ola bilməz.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // TƏHLÜKƏSİZLİK: Benzersiz bir göstərici sıfır ola bilməz, buna görə şərtlər
        // new_unchecked() hörmətlidirlər.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // TƏHLÜKƏSİZLİK: Dəyişdirilə bilən bir istinad sıfır ola bilməz.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // TƏHLÜKƏSİZLİK: Bir istinad boş ola bilməz, buna görə şərtlər
        // new_unchecked() hörmətlidirlər.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}