use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Xam bir sıfır olmayan `*mut T`-in ətrafındakı bu sarğı sahibinin referentə sahib olduğunu göstərən bir sarğı.
/// `Box<T>`, `Vec<T>`, `String` və `HashMap<K, V>` kimi soyutlamalar qurmaq üçün faydalıdır.
///
/// `*mut T`-dən fərqli olaraq, `Unique<T>` "as if" davranır, bu `T` nümunəsidir.
/// `T` `Send`/`Sync` olarsa `Send`/`Sync` tətbiq edir.
/// Bununla yanaşı, `T` nümunəsinin gözləyə biləcəyi güclü aliasing zəmanətləri də nəzərdə tutulur:
/// göstəricinin referenti, Unikal-a sahib olmaq üçün unikal bir yol olmadan dəyişdirilməməlidir.
///
/// Məqsədləriniz üçün `Unique` istifadə etməyin düzgün olub-olmadığını bilmirsinizsə, zəif semantikası olan `NonNull` istifadə etməyi düşünün.
///
///
/// `*mut T`-dən fərqli olaraq, göstərici heç vaxt istinad edilməməsinə baxmayaraq, göstərici həmişə boş olmalıdır.
/// Enumların bu qadağan edilmiş dəyəri bir diskriminant kimi istifadə edə bilməsi üçün-`Option<Unique<T>>`, `Unique<T>` ilə eyni ölçüyə malikdir.
/// Buna baxmayaraq, göstərici verilmədiyi təqdirdə göstərici hələ də sürünə bilər.
///
/// `*mut T`-dən fərqli olaraq, `Unique<T>`, `T`-dən çox dəyişkəndir.
/// Bu, Unique-nin aliasing tələblərini dəstəkləyən hər hansı bir növ üçün həmişə düzgün olmalıdır.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: bu markerin varyans üçün heç bir nəticəsi yoxdur, amma lazımdır
    // Məntiqi olaraq bir `T`-ə sahib olduğumuzu anlamaq üçün dropck üçün.
    //
    // Ətraflı məlumat üçün baxın:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` göstəricilər istinad etdikləri üçün `T` `Send` olduqda göstəricilər `Send`-dir.
/// Qeyd edək ki, bu aliasing dəyişməz növü sistemi tərəfindən tətbiq olunmur;`Unique` istifadə edərək soyutlama tətbiq etməlidir.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` göstəricilər istinad etdikləri üçün `T` `Sync` olduqda göstəricilər `Sync`-dir.
/// Qeyd edək ki, bu aliasing dəyişməz növü sistemi tərəfindən tətbiq olunmur;`Unique` istifadə edərək soyutlama tətbiq etməlidir.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Asılı, lakin yaxşı hizalanmış yeni bir `Unique` yaradır.
    ///
    /// Bu, `Vec::new` kimi tənbəlliklə ayıran növləri işə salmaq üçün faydalıdır.
    ///
    /// Qeyd edək ki, göstərici dəyəri potensial olaraq `T` üçün etibarlı bir göstəricini təmsil edə bilər, yəni bunun "not yet initialized" nəzarətçi dəyəri kimi istifadə edilməməsi lazımdır.
    /// Tənbəlliklə ayıran növlər başlanğıc vəziyyətini başqa yollarla izləməlidir.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // TƏHLÜKƏSİZLİK: mem::align_of(), etibarlı, sıfır olmayan bir göstərici qaytarır.The
        // new_unchecked()-yə zəng etmək şərtlərinə belə əməl olunur.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Yeni `Unique` yaradır.
    ///
    /// # Safety
    ///
    /// `ptr` sıfır olmamalıdır.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // TƏHLÜKƏSİZLİK: zəng edən `ptr`-nin boş olmadığını təmin etməlidir.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` sıfır olduqda yeni bir `Unique` yaradır.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // TƏHLÜKƏSİZLİK: Göstərici artıq yoxlanılıb və sıfır deyil.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Əsas `*mut` göstəricisini alır.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Məzmunu tərkibi.
    ///
    /// Nəticədə ömür öz-özünə bağlıdır, beləliklə "as if" davranır, bu, həqiqətən borc alan bir T nümunəsidir.
    /// Daha uzun bir (unbound) ömrü lazımdırsa, `&*my_ptr.as_ptr()` istifadə edin.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in bütün tələblərə cavab verdiyinə zəmanət verməlidir
        // istinad üçün tələblər.
        unsafe { &*self.as_ptr() }
    }

    /// Tərkibində məzmunu dəyişir.
    ///
    /// Nəticədə ömür öz-özünə bağlıdır, beləliklə "as if" davranır, bu, həqiqətən borc alan bir T nümunəsidir.
    /// Daha uzun bir (unbound) ömrü lazımdırsa, `&mut *my_ptr.as_ptr()` istifadə edin.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in bütün tələblərə cavab verdiyinə zəmanət verməlidir
        // dəyişdirilə bilən bir istinad üçün tələblər.
        unsafe { &mut *self.as_ptr() }
    }

    /// Başqa tipli bir göstəriciyə atılır.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // TƏHLÜKƏSİZLİK: Unique::new_unchecked() yeni bir unikal və ehtiyac yaradır
        // verilmiş göstərici sıfır olmamalıdır.
        // Özümüzü bir göstərici olaraq keçdiyimiz üçün sıfır ola bilməz.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // TƏHLÜKƏSİZLİK: Dəyişdirilə bilən bir istinad sıfır ola bilməz
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}