#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Hər hansı bir işarəli tip göstərici metadata növü təmin edir.
///
/// # Göstərici metadata
///
/// Rust-də xam göstərici növləri və istinad növləri iki hissədən ibarət kimi qəbul edilə bilər:
/// dəyərin yaddaş ünvanını və bəzi metadataları ehtiva edən bir məlumat göstəricisi.
///
/// Statik ölçülü tiplər üçün (`Sized` traits tətbiq edən) və `extern` növləri üçün göstəricilərin "incə" olduğu deyilir: metadata sıfır ölçülüdür və növü `()`-dir.
///
///
/// [dynamically-sized types][dst]-ə işarə edənlərin `geniş` və ya `yağlı` olduğu deyilir, sıfır ölçülü olmayan metadataya sahibdirlər:
///
/// * Son sahəsi DST olan strukturlar üçün metadata son sahənin meta məlumatlarıdır
/// * `str` növü üçün metadata `usize` olaraq bayt uzunluğudur
/// * `[T]` kimi dilim növləri üçün metadata `usize` olaraq maddələrdəki uzunluqdur
/// * `dyn SomeTrait` kimi trait obyektləri üçün metadata [`DynMetadata<Self>`][DynMetadata] (məs. `DynMetadata<dyn SomeTrait>`)
///
/// future-də Rust dili fərqli göstərici metadatasına sahib yeni növ növləri əldə edə bilər.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Bu trait-nin nöqtəsi yuxarıda göstərildiyi kimi `()` və ya `usize` və ya `DynMetadata<_>` olan `Metadata` əlaqəli növüdür.
/// Hər növ üçün avtomatik olaraq tətbiq olunur.
/// Müvafiq bir sərhəd olmadan da ümumi bir kontekstdə həyata keçirildiyi güman edilə bilər.
///
/// # Usage
///
/// Xam göstəricilər [`to_raw_parts`] metodu ilə məlumat ünvanı və metadata komponentlərinə ayrılır.
///
/// Alternativ olaraq, [`metadata`] funksiyası ilə yalnız metadata çıxarıla bilər.
/// Bir istinad [`metadata`]-ə ötürülə bilər və dolayısı ilə məcbur edilə bilər.
///
/// (possibly-wide) göstəricisi [`from_raw_parts`] və ya [`from_raw_parts_mut`] ilə ünvanından və metadatalarından birləşdirilə bilər.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Göstəricilərdəki metadata növü və `Self`-ə istinadlar.
    #[lang = "metadata_type"]
    // NOTE: trait bounds-ni `static_assert_expected_bounds_for_metadata`-də saxlayın
    //
    // burada olanlarla senkronize olaraq `library/core/src/ptr/metadata.rs`-də:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Bu trait təxəllüsünü tətbiq edən növlərə işarə edənlər `incə` dir.
///
/// Buraya statik olaraq `Ölçülü` tiplər və `extern` tiplər daxildir.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: bunu trait takma adları dildə sabit qalmadan əvvəl sabitləşdirməyin?
pub trait Thin = Pointee<Metadata = ()>;

/// Bir göstəricinin metadata komponentini çıxarın.
///
/// `*mut T`, `&T` və ya `&mut T` tipli dəyərlər birbaşa `* const T`-ə məcbur edildiyi üçün birbaşa bu funksiyaya ötürülə bilər.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // TƏHLÜKƏSİZLİK: `PtrRepr` birləşməsindən dəyərə giriş * const T-dən etibarən etibarlıdır
    // və PtrComponentlər<T>eyni yaddaş planlarına sahibdir.
    // Bu zəmanəti yalnız std edə bilər.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Bir məlumat ünvanı və metadatadan bir (possibly-wide) xammal göstəricisi meydana gətirir.
///
/// Bu funksiya təhlükəsizdir, lakin qaytarılmış göstərici seçimdən imtina etmək üçün mütləq təhlükəsiz deyil.
/// Dilimlər üçün təhlükəsizlik tələbləri üçün [`slice::from_raw_parts`] sənədlərinə baxın.
/// trait obyektləri üçün metadata bir göstəricidən eyni yatırılmış tipə gəlməlidir.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // TƏHLÜKƏSİZLİK: `PtrRepr` birləşməsindən dəyərə giriş * const T-dən etibarən etibarlıdır
    // və PtrComponentlər<T>eyni yaddaş planlarına sahibdir.
    // Bu zəmanəti yalnız std edə bilər.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] ilə eyni funksiyanı yerinə yetirir, ancaq xam `*const` göstəricisindən fərqli olaraq xam `* mut` göstəricisi qaytarılır.
///
///
/// Daha ətraflı məlumat üçün [`from_raw_parts`] sənədlərinə baxın.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // TƏHLÜKƏSİZLİK: `PtrRepr` birləşməsindən dəyərə giriş * const T-dən etibarən etibarlıdır
    // və PtrComponentlər<T>eyni yaddaş planlarına sahibdir.
    // Bu zəmanəti yalnız std edə bilər.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` bağlanmaması üçün əl ilə göstərmə lazımdır.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` bağlanmaması üçün əl ilə göstərmə lazımdır.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait obyekt növü üçün metadata.
///
/// Bir trait obyektinin içərisində saxlanan beton növünü idarə etmək üçün bütün lazımi məlumatları əks etdirən bir vtable (virtual çağırış cədvəli) işarəsidir.
/// Xüsusilə içərisində olan vtable:
///
/// * tip ölçüsü
/// * tip hizalama
/// * növün `drop_in_place` göstəricisinə işarə (düz köhnə məlumatlar üçün əlverişsiz ola bilər)
/// * tip trait-nin tətbiqi üçün bütün metodlara işarə edir
///
/// İlk üçünün xüsusi olduğunu unutmayın, çünki hər hansı bir trait obyektini ayırmaq, buraxmaq və ayırmaq lazımdır.
///
/// Bu quruluşu `dyn` trait obyekti olmayan (məsələn `DynMetadata<u64>`) tip parametri ilə adlandırmaq, lakin bu strukturun mənalı bir dəyərini əldə etmək mümkün deyil.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Bütün vtableların ümumi prefiksi.Ardınca trait metodları üçün funksiya göstəriciləri gəlir.
///
/// `DynMetadata::size_of` və s. Xüsusi tətbiq detalı
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Bu vtable ilə əlaqəli növün ölçüsünü qaytarır.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Bu vtable ilə əlaqəli növün hizalanmasını qaytarır.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` olaraq ölçüsü və hizalamayı birlikdə qaytarır
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // TƏHLÜKƏSİZLİK: kompilyator bu vtable-ı beton Rust tipi üçün yaymışdır
        // etibarlı bir quruluşa sahib olduğu bilinir.`Layout::for_value`-də olduğu kimi əsas.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` hüdudlarından qaçmaq üçün lazım olan manüel təsirlər.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}