use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Göstərici sıfırsa, `true` qaytarır.
    ///
    /// Diqqət yetirin ki, ölçüsüz tiplərin bir çox mümkün sıfır göstəriciləri var, çünki onların uzunluğu, vtable və s. Deyil, yalnız xam məlumat göstəricisi nəzərə alınır.
    /// Buna görə, sıfır olan iki göstərici hələ də bir-birinə bərabər tutula bilməz.
    ///
    /// ## Konst qiymətləndirmə zamanı davranış
    ///
    /// Bu funksiya konst qiymətləndirmə zamanı istifadə edildikdə, iş zamanı sıfır çıxan göstəricilər üçün `false` qaytara bilər.
    /// Konkret olaraq, bəzi yaddaşa bir göstərici hüdudlarından kənara çıxdıqda, nəticədə yaranan göstərici sıfır olarsa, funksiya yenə də `false` qaytaracaqdır.
    ///
    /// CTFE-nin bu yaddaşın mütləq vəziyyətini bilməsi üçün bir yol yoxdur, buna görə göstəricinin boş olub olmadığını deyə bilmərik.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Gips ilə incə bir göstəriciyə müqayisə edin, buna görə yağ göstəriciləri yalnız boşluq üçün "data" hissəsini nəzərə alırlar.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Başqa tipli bir göstəriciyə atılır.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// (Geniş ola bilər) bir göstəricini ünvan və metadata komponentlərinə ayırın.
    ///
    /// Göstərici daha sonra [`from_raw_parts`] ilə yenidən qurula bilər.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Göstərici sıfırsa `None` qaytarır və ya başqa bir şəkildə `Some`-ə bükülmüş dəyərə ortaq bir istinad verir.Qiymət başlanğıc edilə bilməzsə, bunun yerinə [`as_uninit_ref`] istifadə edilməlidir.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən,* * göstəricinin NULL * və ya aşağıdakıların hamısının doğruluğundan əmin olmalısınız:
    ///
    /// * Göstərici düzgün bir şəkildə hizalanmalıdır.
    ///
    /// * [the module documentation]-də müəyyən edilmiş mənada "dereferencable" olmalıdır.
    ///
    /// * Göstərici `T` başlanğıc nümunəsini göstərməlidir.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaş mutasiyaya uğramamalıdır (`UnsafeCell` içərisi xaricində).
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    /// (Başlanğıcla əlaqəli bir hissə hələ tam olaraq həll edilməmişdir, amma bu qədər yeganə etibarlı yanaşma, həqiqətən başlanğıc verildiyini təmin etməkdir.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null yoxlanılmış versiya
    ///
    /// İşarənin heç vaxt sıfır ola bilməyəcəyindən əminsəniz və `Option<&T>` əvəzinə `&T`-i qaytaran bir növ `as_ref_unchecked` axtarırsınızsa, göstəricidən birbaşa imtina edə biləcəyinizi unutmayın.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-nin etibarlı olmasına zəmanət verməlidir
        // sıfır deyilsə istinad üçün.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Göstərici sıfırsa `None` qaytarır və ya başqa bir şəkildə `Some`-ə bükülmüş dəyərə ortaq bir istinad verir.
    /// [`as_ref`]-dən fərqli olaraq, bu dəyərin başlanğıc edilməsini tələb etmir.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən,* * göstəricinin NULL * və ya aşağıdakıların hamısının doğruluğundan əmin olmalısınız:
    ///
    /// * Göstərici düzgün bir şəkildə hizalanmalıdır.
    ///
    /// * [the module documentation]-də müəyyən edilmiş mənada "dereferencable" olmalıdır.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaş mutasiyaya uğramamalıdır (`UnsafeCell` içərisi xaricində).
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in bütün tələblərə cavab verdiyinə zəmanət verməlidir
        // istinad üçün tələblər.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Bir göstəricidən ofset hesablayır.
    ///
    /// `count` T vahidindədir;məsələn, 3-ün `count`-i, `3 * size_of::<T>()` baytlıq bir göstərici ofsetini təmsil edir.
    ///
    /// # Safety
    ///
    /// Aşağıdakı şərtlərdən biri pozulursa, nəticə Tərifsiz Davranış olur:
    ///
    /// * Həm başlanğıc, həm də nəticələnən göstərici hüdudlarda və ya eyni ayrılmış obyektin sonundan bir bayt olmalıdır.
    /// Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
    ///
    /// * Hesablanmış ofset,**baytla**, bir `isize`-i aşa bilməz.
    ///
    /// * Sınırda olan ofset, "wrapping around" ünvan sahəsinə etibar edə bilməz.Yəni, ** baytda olan sonsuz dəqiqlik cəmi bir usize uyğun olmalıdır.
    ///
    /// Tərtibçi və standart kitabxana ümumiyyətlə ayırmaların ofsetin narahat olduğu ölçülərə çatmamasını təmin etməyə çalışır.
    /// Məsələn, `Vec` və `Box` heç vaxt `isize::MAX` baytdan çox ayırmayacaqlarını təmin edirlər, buna görə `vec.as_ptr().add(vec.len())` həmişə təhlükəsizdir.
    ///
    /// Əksər platformalar təməl olaraq belə bir ayırma da qura bilmir.
    /// Məsələn, bilinən heç bir 64-bit platforma, səhifə cədvəlindəki məhdudiyyətlər və ya ünvan boşluğunun bölünməsi səbəbindən 2 <sup>63</sup> baytlıq bir istəyə xidmət edə bilməz.
    /// Bununla birlikdə, bəzi 32-bit və 16-bit platformalar, Fiziki Ünvan Uzatması kimi şeylərlə `isize::MAX` baytdan çox bir istəyə müvəffəqiyyətlə xidmət edə bilər.
    ///
    /// Beləliklə, birbaşa ayırıcılardan və ya yaddaşla uyğunlaşdırılmış sənədlərdən əldə edilmiş yaddaş * bu funksiyanı idarə etmək üçün çox böyük ola bilər.
    ///
    /// Bu məhdudiyyətləri təmin etmək çətindirsə, bunun əvəzinə [`wrapping_offset`] istifadə etməyi düşünün.
    /// Bu metodun yeganə üstünlüyü, daha aqressiv kompilyator optimallaşdırmasına imkan verməsidir.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `offset` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Sarma hesabını istifadə edərək göstəricidən ofseti hesablayır.
    ///
    /// `count` T vahidindədir;məsələn, 3-ün `count`-i, `3 * size_of::<T>()` baytlıq bir göstərici ofsetini təmsil edir.
    ///
    /// # Safety
    ///
    /// Bu əməliyyatın özü həmişə təhlükəsizdir, lakin ortaya çıxan göstəricini istifadə etmək olmaz.
    ///
    /// Nəticədə göstərici `self`-nin göstərdiyi eyni ayrılmış obyektə əlavə olaraq qalır.
    /// Fərqli bir ayrılmış obyektə daxil olmaq üçün *istifadə edilə bilməz*.Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
    ///
    /// Başqa sözlə, `T`-in `1` ölçüsünə sahib olduğunu və heç bir daşma olmadığını düşünsək də, `let z = x.wrapping_offset((y as isize) - (x as isize))`, `z`-i `y`-lə eyni etmir: `z` hələ də `x` obyektinə yapışdırılır və bunun tərif edilməsi, `x` və `y` eyni ayrılmış obyektə işarə edir.
    ///
    /// [`offset`] ilə müqayisədə bu metod əsasən ayrılmış eyni obyektdə qalma tələbini təxirə salır: [`offset`], obyekt sərhədlərini keçərkən dərhal Müəyyən Olmayan Davranışdır;`wrapping_offset` bir göstərici əmələ gətirir, ancaq əlavə edilmiş obyektin hüdudlarından kənar olduqda bir göstərici seçildiyi təqdirdə hələ də Müəyyən Olmayan Davranışa yol açır.
    /// [`offset`] daha yaxşı optimallaşdırıla bilər və bu səbəbdən performansa həssas kodda üstünlük verilir.
    ///
    /// Gecikmiş yoxlama yalnız nəticənin hesablanması zamanı istifadə olunan aralıq dəyərləri deyil, yalnız göstərilən göstəricinin dəyərini nəzərə alır.
    /// Məsələn, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` həmişə `x` ilə eynidır.Başqa sözlə, ayrılmış obyektdən ayrılmağa və sonra yenidən daxil olmağa icazə verilir.
    ///
    /// Əgər obyekt hüdudlarını keçməlisinizsə, göstəricini bir ədədə atın və orada hesabı aparın.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // Xam bir göstəricini iki element artımında təkrarlayın
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Bu döngə "1, 3, 5, " yazdırır
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: daxili `arith_offset`-in çağırılması üçün heç bir şərt yoxdur.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// İki göstərici arasındakı məsafəni hesablayır.Qaytarılan dəyər T vahidindədir: baytlardakı məsafə `mem::size_of::<T>()`-ə bölünür.
    ///
    /// Bu funksiya [`offset`]-in tərsidir.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Aşağıdakı şərtlərdən biri pozulursa, nəticə Tərifsiz Davranış olur:
    ///
    /// * Həm başlanğıc, həm də digər göstərici hüdudlarda və ya eyni ayrılmış obyektin sonundan bir bayt olmalıdır.
    /// Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
    ///
    /// * Hər iki göstərici eyni obyekt üçün bir göstəricidən * əldə edilməlidir.
    ///   (Bir nümunə üçün aşağıya baxın.)
    ///
    /// * Baytlarla göstəricilər arasındakı məsafə, `T` ölçüsündə dəqiq bir çox olmalıdır.
    ///
    /// * Göstəricilər arasındakı məsafə,**baytla**, bir `isize`-i aşa bilməz.
    ///
    /// * Hüdudlarda olan məsafə "wrapping around" ünvan boşluğuna etibar edə bilməz.
    ///
    /// Rust növləri heç vaxt `isize::MAX`-dən böyük deyil və Rust ayırmaları heç vaxt ünvan boşluğunu əhatə etmir, beləliklə hər hansı bir Rust tip `T`-in bəzi dəyərləri daxilində iki göstərici həmişə son iki şərti təmin edəcəkdir.
    ///
    /// Standart kitabxana ümumiyyətlə ayırmaların ofsetin narahat olduğu ölçülərə çatmamasını da təmin edir.
    /// Məsələn, `Vec` və `Box` heç vaxt `isize::MAX` baytdan çox ayırmayacaqlarını təmin edirlər, buna görə `ptr_into_vec.offset_from(vec.as_ptr())` həmişə son iki şərti təmin edir.
    ///
    /// Əksər platformalar kökündən belə böyük bir ayırma da qura bilmir.
    /// Məsələn, bilinən heç bir 64-bit platforma, səhifə cədvəlindəki məhdudiyyətlər və ya ünvan boşluğunun bölünməsi səbəbindən 2 <sup>63</sup> baytlıq bir istəyə xidmət edə bilməz.
    /// Bununla birlikdə, bəzi 32-bit və 16-bit platformalar, Fiziki Ünvan Uzatması kimi şeylərlə `isize::MAX` baytdan çox bir istəyə müvəffəqiyyətlə xidmət edə bilər.
    /// Beləliklə, birbaşa ayırıcılardan və ya yaddaşla uyğunlaşdırılmış sənədlərdən əldə edilmiş yaddaş * bu funksiyanı idarə etmək üçün çox böyük ola bilər.
    /// ([`offset`] və [`add`]-in də bənzər bir məhdudiyyətə sahib olduğunu və bu səbəbdən belə böyük ayırmalarda istifadə edilə bilməyəcəyini unutmayın.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Bu funksiya panics, əgər `T` sıfır ölçülü tip ("ZST") olarsa.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Yanlış* istifadə:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ptr2_other bir "alias" bir "alias" olun, lakin ptr1 əldə.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ptr2_other və ptr2 göstəricilərdən fərqli obyektlərə aid olduğundan, eyni ünvana işarə etsələr də, onların əvəzləşdirilməsini hesablamaq, təyin olunmamış davranışdır!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Tərifsiz davranış
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // TƏHLÜKƏSİZLİK: zəng edən `ptr_offset_from` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// İki göstəricinin bərabər olmasına zəmanət verilib-verilməməsini qaytarır.
    ///
    /// İş zamanı bu funksiya `self == other` kimi davranır.
    /// Bununla birlikdə, bəzi kontekstlərdə (məsələn, tərtib vaxtının qiymətləndirilməsi) iki göstəricinin bərabərliyini təyin etmək həmişə mümkün deyil, bu səbəbdən bu funksiya daha sonra həqiqətən bərabər çıxan göstəricilər üçün `false`-i saxtakarlıqla qaytara bilər.
    ///
    /// Ancaq `true` döndüyündə göstəricilərin bərabər olmasına zəmanət verilir.
    ///
    /// Bu funksiya [`guaranteed_ne`]-in aynasıdır, əksinə deyil.Hər iki funksiyanın `false`-yə döndüyü göstərici müqayisələri var.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Qaytarma dəyəri kompilyator versiyasına görə dəyişə bilər və təhlükəli kod bu funksiyanın nəticəsinə etibarlı olmaya bilər.
    /// Bu funksiyadan yalnız saxta `false` qaytarma dəyərlərinin nəticəyə təsir etmədiyi performans optimallaşdırması üçün istifadə edilməsi tövsiyə olunur, sadəcə performans.
    /// Bu metodun işləmə və tərtib etmə vaxtı kodlarının fərqli davranması üçün istifadə edilməsinin nəticələri araşdırılmamışdır.
    /// Bu cür fərqləri tətbiq etmək üçün bu metoddan istifadə edilməməli və bu məsələni daha yaxşı başa düşməyimizdən əvvəl sabitləşdirilməməlidir.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// İki göstəricinin qeyri-bərabər olmasına zəmanət verildiyini qaytarır.
    ///
    /// İş zamanı bu funksiya `self != other` kimi davranır.
    /// Bununla birlikdə, bəzi kontekstlərdə (məsələn, tərtib vaxtının qiymətləndirilməsi) iki göstəricinin bərabərsizliyini təyin etmək həmişə mümkün deyil, buna görə də bu funksiya sonradan həqiqətən qeyri-bərabər çıxan göstəricilər üçün saxta şəkildə `false` qaytara bilər.
    ///
    /// Ancaq `true` qaytardıqda göstəricilərin bərabər olmamasına zəmanət verilir.
    ///
    /// Bu funksiya [`guaranteed_eq`]-in aynasıdır, əksinə deyil.Hər iki funksiyanın `false`-yə döndüyü göstərici müqayisələri var.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Qaytarma dəyəri kompilyator versiyasına görə dəyişə bilər və təhlükəli kod bu funksiyanın nəticəsinə etibarlı olmaya bilər.
    /// Bu funksiyadan yalnız saxta `false` qaytarma dəyərlərinin nəticəyə təsir etmədiyi performans optimallaşdırması üçün istifadə edilməsi tövsiyə olunur, sadəcə performans.
    /// Bu metodun işləmə və tərtib etmə vaxtı kodlarının fərqli davranması üçün istifadə edilməsinin nəticələri araşdırılmamışdır.
    /// Bu cür fərqləri tətbiq etmək üçün bu metoddan istifadə edilməməli və bu məsələni daha yaxşı başa düşməyimizdən əvvəl sabitləşdirilməməlidir.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Bir göstəricidən ofseti hesablayır (`.offset(count as isize)`) üçün rahatlıq.
    ///
    /// `count` T vahidindədir;məsələn, 3-ün `count`-i, `3 * size_of::<T>()` baytlıq bir göstərici ofsetini təmsil edir.
    ///
    /// # Safety
    ///
    /// Aşağıdakı şərtlərdən biri pozulursa, nəticə Tərifsiz Davranış olur:
    ///
    /// * Həm başlanğıc, həm də nəticələnən göstərici hüdudlarda və ya eyni ayrılmış obyektin sonundan bir bayt olmalıdır.
    /// Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
    ///
    /// * Hesablanmış ofset,**baytla**, bir `isize`-i aşa bilməz.
    ///
    /// * Sınırda olan ofset, "wrapping around" ünvan sahəsinə etibar edə bilməz.Yəni sonsuz dəqiqlik cəmi bir `usize`-ə uyğun olmalıdır.
    ///
    /// Tərtibçi və standart kitabxana ümumiyyətlə ayırmaların ofsetin narahat olduğu ölçülərə çatmamasını təmin etməyə çalışır.
    /// Məsələn, `Vec` və `Box` heç vaxt `isize::MAX` baytdan çox ayırmayacaqlarını təmin edirlər, buna görə `vec.as_ptr().add(vec.len())` həmişə təhlükəsizdir.
    ///
    /// Əksər platformalar təməl olaraq belə bir ayırma da qura bilmir.
    /// Məsələn, bilinən heç bir 64-bit platforma, səhifə cədvəlindəki məhdudiyyətlər və ya ünvan boşluğunun bölünməsi səbəbindən 2 <sup>63</sup> baytlıq bir istəyə xidmət edə bilməz.
    /// Bununla birlikdə, bəzi 32-bit və 16-bit platformalar, Fiziki Ünvan Uzatması kimi şeylərlə `isize::MAX` baytdan çox bir istəyə müvəffəqiyyətlə xidmət edə bilər.
    ///
    /// Beləliklə, birbaşa ayırıcılardan və ya yaddaşla uyğunlaşdırılmış sənədlərdən əldə edilmiş yaddaş * bu funksiyanı idarə etmək üçün çox böyük ola bilər.
    ///
    /// Bu məhdudiyyətləri təmin etmək çətindirsə, bunun əvəzinə [`wrapping_add`] istifadə etməyi düşünün.
    /// Bu metodun yeganə üstünlüyü, daha aqressiv kompilyator optimallaşdırmasına imkan verməsidir.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `offset` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { self.offset(count as isize) }
    }

    /// Bir göstəricidən ofseti hesablayır (".offset üçün rahatlıq ((isize).wrapping_neg())`) kimi sayın.)
    ///
    /// `count` T vahidindədir;məsələn, 3-ün `count`-i, `3 * size_of::<T>()` baytlıq bir göstərici ofsetini təmsil edir.
    ///
    /// # Safety
    ///
    /// Aşağıdakı şərtlərdən biri pozulursa, nəticə Tərifsiz Davranış olur:
    ///
    /// * Həm başlanğıc, həm də nəticələnən göstərici hüdudlarda və ya eyni ayrılmış obyektin sonundan bir bayt olmalıdır.
    /// Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
    ///
    /// * Hesablanmış ofset `isize::MAX`**baytdan** keçə bilməz.
    ///
    /// * Sınırda olan ofset, "wrapping around" ünvan sahəsinə etibar edə bilməz.Yəni sonsuz dəqiqlik cəmi bir usize uyğun olmalıdır.
    ///
    /// Tərtibçi və standart kitabxana ümumiyyətlə ayırmaların ofsetin narahat olduğu ölçülərə çatmamasını təmin etməyə çalışır.
    /// Məsələn, `Vec` və `Box` heç vaxt `isize::MAX` baytdan çox ayırmayacaqlarını təmin edirlər, buna görə `vec.as_ptr().add(vec.len()).sub(vec.len())` həmişə təhlükəsizdir.
    ///
    /// Əksər platformalar təməl olaraq belə bir ayırma da qura bilmir.
    /// Məsələn, bilinən heç bir 64-bit platforma, səhifə cədvəlindəki məhdudiyyətlər və ya ünvan boşluğunun bölünməsi səbəbindən 2 <sup>63</sup> baytlıq bir istəyə xidmət edə bilməz.
    /// Bununla birlikdə, bəzi 32-bit və 16-bit platformalar, Fiziki Ünvan Uzatması kimi şeylərlə `isize::MAX` baytdan çox bir istəyə müvəffəqiyyətlə xidmət edə bilər.
    ///
    /// Beləliklə, birbaşa ayırıcılardan və ya yaddaşla uyğunlaşdırılmış sənədlərdən əldə edilmiş yaddaş * bu funksiyanı idarə etmək üçün çox böyük ola bilər.
    ///
    /// Bu məhdudiyyətləri təmin etmək çətindirsə, bunun əvəzinə [`wrapping_sub`] istifadə etməyi düşünün.
    /// Bu metodun yeganə üstünlüyü, daha aqressiv kompilyator optimallaşdırmasına imkan verməsidir.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `offset` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Sarma hesabını istifadə edərək göstəricidən ofseti hesablayır.
    /// (`.wrapping_offset(count as isize)`) üçün rahatlıq
    ///
    /// `count` T vahidindədir;məsələn, 3-ün `count`-i, `3 * size_of::<T>()` baytlıq bir göstərici ofsetini təmsil edir.
    ///
    /// # Safety
    ///
    /// Bu əməliyyatın özü həmişə təhlükəsizdir, lakin ortaya çıxan göstəricini istifadə etmək olmaz.
    ///
    /// Nəticədə göstərici `self`-nin göstərdiyi eyni ayrılmış obyektə əlavə olaraq qalır.
    /// Fərqli bir ayrılmış obyektə daxil olmaq üçün *istifadə edilə bilməz*.Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
    ///
    /// Başqa sözlə, X0 `T`-in `1` ölçüsündə olduğunu və heç bir daşqının olmadığını düşünsək də, `let z = x.wrapping_add((y as usize) - (x as usize))`, `z`-i `y`-lə eyni etmir: `z` hələ də `x` obyektinə yapışdırılır və bunun tərif edilməsi, `x` və `y` eyni ayrılmış obyektə işarə edir.
    ///
    /// [`add`] ilə müqayisədə bu metod əsasən ayrılmış eyni obyektdə qalma tələbini təxirə salır: [`add`], obyekt sərhədlərini keçərkən dərhal Müəyyən Olmayan Davranışdır;`wrapping_add` bir göstərici əmələ gətirir, ancaq əlavə edilmiş obyektin hüdudlarından kənar olduqda bir göstərici seçildiyi təqdirdə hələ də Müəyyən Olmayan Davranışa yol açır.
    /// [`add`] daha yaxşı optimallaşdırıla bilər və bu səbəbdən performansa həssas kodda üstünlük verilir.
    ///
    /// Gecikmiş yoxlama yalnız nəticənin hesablanması zamanı istifadə olunan aralıq dəyərləri deyil, yalnız göstərilən göstəricinin dəyərini nəzərə alır.
    /// Məsələn, `x.wrapping_add(o).wrapping_sub(o)` həmişə `x` ilə eynidır.Başqa sözlə, ayrılmış obyektdən ayrılmağa və sonra yenidən daxil olmağa icazə verilir.
    ///
    /// Əgər obyekt hüdudlarını keçməlisinizsə, göstəricini bir ədədə atın və orada hesabı aparın.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // Xam bir göstəricini iki element artımında təkrarlayın
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Bu döngə "1, 3, 5, " yazdırır
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Sarma hesabını istifadə edərək göstəricidən ofseti hesablayır.
    /// (.wrapping_offset üçün rahatlıq ((isize).wrapping_neg())`) olaraq hesablayın
    ///
    /// `count` T vahidindədir;məsələn, 3-ün `count`-i, `3 * size_of::<T>()` baytlıq bir göstərici ofsetini təmsil edir.
    ///
    /// # Safety
    ///
    /// Bu əməliyyatın özü həmişə təhlükəsizdir, lakin ortaya çıxan göstəricini istifadə etmək olmaz.
    ///
    /// Nəticədə göstərici `self`-nin göstərdiyi eyni ayrılmış obyektə əlavə olaraq qalır.
    /// Fərqli bir ayrılmış obyektə daxil olmaq üçün *istifadə edilə bilməz*.Qeyd edək ki, Rust-də hər (stack-allocated) dəyişən ayrı ayrılmış obyekt hesab olunur.
    ///
    /// Başqa sözlə, X0 `T`-in `1` ölçüsündə olduğunu və heç bir daşqının olmadığını düşünsək də, `let z = x.wrapping_sub((x as usize) - (y as usize))`, `z`-i `y`-lə eyni etmir: `z` hələ də `x` obyektinə yapışdırılır və bunun tərif edilməsi, `x` və `y` eyni ayrılmış obyektə işarə edir.
    ///
    /// [`sub`] ilə müqayisədə bu metod əsasən ayrılmış eyni obyektdə qalma tələbini təxirə salır: [`sub`], obyekt sərhədlərini keçərkən dərhal Müəyyən Olmayan Davranışdır;`wrapping_sub` bir göstərici əmələ gətirir, ancaq əlavə edilmiş obyektin hüdudlarından kənar olduqda bir göstərici seçildiyi təqdirdə hələ də Müəyyən Olmayan Davranışa yol açır.
    /// [`sub`] daha yaxşı optimallaşdırıla bilər və bu səbəbdən performansa həssas kodda üstünlük verilir.
    ///
    /// Gecikmiş yoxlama yalnız nəticənin hesablanması zamanı istifadə olunan aralıq dəyərləri deyil, yalnız göstərilən göstəricinin dəyərini nəzərə alır.
    /// Məsələn, `x.wrapping_add(o).wrapping_sub(o)` həmişə `x` ilə eynidır.Başqa sözlə, ayrılmış obyektdən ayrılmağa və sonra yenidən daxil olmağa icazə verilir.
    ///
    /// Əgər obyekt hüdudlarını keçməlisinizsə, göstəricini bir ədədə atın və orada hesabı aparın.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // (backwards) iki element artımlarında xam bir göstərici istifadə edərək təkrarlayın
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Bu döngə "5, 3, 1, " yazdırır
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Göstərici dəyərini `ptr` olaraq təyin edir.
    ///
    /// `self`-in ölçüsüz bir tipə bir (fat) göstəricisi olması halında, bu əməliyyat yalnız göstərici hissəsini təsir edəcəkdir, (thin) ölçülü tiplərə göstəriciləri üçün bu, sadə bir tapşırıqla eyni təsirə malikdir.
    ///
    /// Nəticədə göstərici `val` sınanmasına sahib olacaq, yəni bir yağ göstəricisi üçün bu əməliyyat semantik olaraq `val` məlumat göstəricisi dəyəri ilə `self` metadatalı yeni bir yağ göstəricisi yaratmaqla eynidir.
    ///
    ///
    /// # Examples
    ///
    /// Bu funksiya, ilk növbədə, potensial yağ göstəricilərində bayt müdrik göstəricinin hesablanmasına imkan vermək üçün faydalıdır:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // "3" çap edəcək
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // TƏHLÜKƏSİZLİK: İncə bir göstərici olması halında bu əməliyyatlar eynidır
        // sadə bir tapşırığa.
        // Yağ göstəricisi halında, mövcud yağ göstəricisi düzeni tətbiqi ilə, belə bir göstəricinin ilk sahəsi hər zaman eyni şəkildə təyin edilmiş məlumat göstəricisidir.
        //
        unsafe { *thin = val };
        self
    }

    /// `self`-dən dəyəri hərəkət etdirmədən oxuyur.
    /// Bu, `self` yaddaşını dəyişməz hala gətirir.
    ///
    /// Təhlükəsizlik məsələləri və nümunələr üçün [`ptr::read`]-ə baxın.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `read` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { read(self) }
    }

    /// `self`-dən dəyəri dəyişmədən oxumaq yerinə yetirir.Bu, `self` yaddaşını dəyişməz vəziyyətə gətirir.
    ///
    /// Uçucu əməliyyatlar I/O yaddaşında işləmək üçün nəzərdə tutulur və digər uçucu əməliyyatlar zamanı kompilyator tərəfindən seçilməməsi və ya yenidən sıralanmaması təmin edilir.
    ///
    ///
    /// Təhlükəsizlik məsələləri və nümunələr üçün [`ptr::read_volatile`]-ə baxın.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `read_volatile` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { read_volatile(self) }
    }

    /// `self`-dən dəyəri hərəkət etdirmədən oxuyur.
    /// Bu, `self` yaddaşını dəyişməz hala gətirir.
    ///
    /// `read`-dən fərqli olaraq göstərici hizalanmamış ola bilər.
    ///
    /// Təhlükəsizlik məsələləri və nümunələr üçün [`ptr::read_unaligned`]-ə baxın.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `read_unaligned` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { read_unaligned(self) }
    }

    /// `count * size_of<T>` baytını `self`-dən `dest`-ə kopyalayır.
    /// Mənbə və təyinat yeri üst-üstə düşə bilər.
    ///
    /// NOTE: bunun [`ptr::copy`] ilə *eyni* arqument qaydası var.
    ///
    /// Təhlükəsizlik məsələləri və nümunələr üçün [`ptr::copy`]-ə baxın.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `copy` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { copy(self, dest, count) }
    }

    /// `count * size_of<T>` baytını `self`-dən `dest`-ə kopyalayır.
    /// Mənbə və təyinat yeri üst-üstə düşə bilməz *.
    ///
    /// NOTE: bunun [`ptr::copy_nonoverlapping`] ilə *eyni* arqument qaydası var.
    ///
    /// Təhlükəsizlik məsələləri və nümunələr üçün [`ptr::copy_nonoverlapping`]-ə baxın.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `copy_nonoverlapping` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// `align`-ə uyğunlaşdırılması üçün göstəriciyə tətbiq edilməsi lazım olan ofseti hesablayır.
    ///
    /// İşarəni düzəltmək mümkün deyilsə, tətbiq `usize::MAX` qaytarır.
    /// Tətbiqin *həmişə*`usize::MAX` qayıtmasına icazə verilir.
    /// Yalnız alqoritminizin performansı burada düzgün ofset əldə etməkdən asılı ola bilər, doğruluğundan deyil.
    ///
    /// Ofset bayt yox, `T` element sayında ifadə olunur.Geri qaytarılmış dəyər `wrapping_add` metodu ilə istifadə edilə bilər.
    ///
    /// Göstəricinin əvəzləşdirilməsinin daşıyacağına və ya göstəricinin göstərdiyi yerdən kənara çıxmayacağına dair heç bir zəmanət yoxdur.
    ///
    /// Geri qaytarılmış ofsetin hizalama xaricindəki bütün şərtlər daxilində düzgün olmasını təmin etmək zəng edənin əlindədir.
    ///
    /// # Panics
    ///
    /// `align` ikisinin gücü deyilsə panics funksiyası.
    ///
    /// # Examples
    ///
    /// Bitişik `u8`-ə `u16` olaraq daxil olmaq
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // göstərici `offset` vasitəsilə hizalana bilsə də, ayırmanın xaricinə işarə edəcəkdir
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // TƏHLÜKƏSİZLİK: `align`-in yuxarıda 2 güc olduğu yoxlanılıb
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Çiy dilimin uzunluğunu qaytarır.
    ///
    /// Qaytarılan dəyər, bayt sayı deyil,**element** sayındadır.
    ///
    /// Xam dilim bir dilim istinadına atıla bilmədiyi zaman belə, bu funksiya təhlükəsizdir, çünki göstərici sıfır və ya hizalanmamışdır.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // TƏHLÜKƏSİZLİK: `*const [T]` və `FatPtr<T>` eyni tərtibata sahib olduğu üçün təhlükəsizdir.
            // Bu zəmanəti yalnız `std` verə bilər.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Çiy göstəricini dilimin tamponuna qaytarır.
    ///
    /// Bu, `self`-dən `*const T`-ə tökmə ilə bərabərdir, lakin daha təhlükəsizdir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Xammal göstəricisini sərhədləri yoxlamadan bir elementə və ya alt hissəyə qaytarır.
    ///
    /// Bu metodu sərhəd xaricində bir indekslə çağırmaq və ya `self`-nin təyin edilmədiyi zaman * *[təyin olunmamış davranış] * nəticə çıxarılan göstərici istifadə olunmasa da.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in ayrılabilməsini və `index`-in sərhədsiz olmasını təmin edir.
        unsafe { index.get_unchecked(self) }
    }

    /// Göstərici sıfırsa `None` qaytarır və ya başqa bir paylaşılan dilimi `Some`-ə bükülmüş dəyərə qaytarır.
    /// [`as_ref`]-dən fərqli olaraq, bu dəyərin başlanğıc edilməsini tələb etmir.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Bu metodu çağırarkən,* * göstəricinin NULL * və ya aşağıdakıların hamısının doğruluğundan əmin olmalısınız:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` çox bayt oxumaq üçün göstərici [valid] olmalıdır və düzgün hizalanmalıdır.Bu xüsusən:
    ///
    ///     * Bu dilimin bütün yaddaş aralığı ayrılmış bir obyekt daxilində olmalıdır!
    ///       Dilimlər heç vaxt bir çox ayrılmış obyekt arasında yayıla bilməz.
    ///
    ///     * Sıfır uzunluqlu dilimlər üçün də göstərici hizalanmalıdır.
    ///     Bunun bir səbəbi, enum layout optimallaşdırmalarının digər məlumatlardan fərqləndirmək üçün hizalanmış və boş olmayan istinadlara (istənilən uzunluqdakı dilimlər daxil olmaqla) etibar edə bilməsi.
    ///
    ///     [`NonNull::dangling()`] istifadə edərək sıfır uzunluqlu dilimlər üçün `data` kimi istifadə edilə bilən bir göstərici əldə edə bilərsiniz.
    ///
    /// * Dilimin ümumi ölçüsü `ptr.len() * mem::size_of::<T>()`, `isize::MAX`-dən böyük olmamalıdır.
    ///   [`pointer::offset`] təhlükəsizlik sənədlərinə baxın.
    ///
    /// * Geri qaytarılmış ömür `'a` özbaşına seçildiyindən və məlumatların həqiqi ömrünü əks etdirmədiyi üçün Rust-nin yalnış qaydalarını tətbiq etməlisiniz.
    ///   Xüsusilə, bu ömür boyu göstəricinin göstərdiyi yaddaş mutasiyaya uğramamalıdır (`UnsafeCell` içərisi xaricində).
    ///
    /// Bu metodun nəticəsi istifadə olunmasa belə tətbiq olunur!
    ///
    /// [`slice::from_raw_parts`][]-ə də baxın.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // TƏHLÜKƏSİZLİK: zəng edən `as_uninit_slice` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Göstəricilər üçün bərabərlik
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Göstəricilər üçün müqayisə
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}