//! Birləşən asinxron təkrarlama.
//!
//! futures asenkron dəyərlərdirsə, axınlar asinxron təkrarlayıcıdır.
//! Əgər özünüzü bir növ asinxron bir kolleksiya ilə qarşıladıysanız və bu kolleksiyanın elementləri üzərində bir əməliyyat keçirməyiniz lazım olsa, tez bir zamanda 'streams'-ə girəcəksiniz.
//! Axınlar idiomatik asenkron Rust kodunda çox istifadə olunur, buna görə onlarla tanış olmağa dəyər.
//!
//! Daha çox izah etməzdən əvvəl bu modulun necə qurulduğu barədə danışaq:
//!
//! # Organization
//!
//! Bu modul əsasən növə görə təşkil edilmişdir:
//!
//! * [Traits] əsas hissə bunlardır: bu traits hansı axınların mövcud olduğunu və onlarla nə edə biləcəyinizi müəyyənləşdirir.Bu traits metodları əlavə iş vaxtı sərf etməyə dəyər.
//! * Funksiyalar bəzi əsas axınlar yaratmaq üçün bəzi faydalı yollar təqdim edir.
//! * Quruluşlar tez-tez bu modulun traits-dəki müxtəlif metodların qaytarma növləridir.Ümumiyyətlə `struct`-nin özünə deyil, `struct`-i yaradan metoda baxmaq istəyəcəksiniz.
//! Səbəbi barədə daha ətraflı məlumat üçün, '[İcra edici axın](#tətbiq akışı)' na baxın.
//!
//! [Traits]: #traits
//!
//! Bu belədir!Gəlin axınlara girək.
//!
//! # Stream
//!
//! Bu modulun ürəyi və ruhu [`Stream`] trait-dir.[`Stream`] nüvəsi belə görünür:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! `Iterator`-dən fərqli olaraq, `Stream`, `Stream` tətbiq edilərkən istifadə olunan [`poll_next`] metodu ilə axın istehlak edərkən istifadə olunan (to-be-implemented) `next` metodu arasında fərq qoyur.
//!
//! `Stream` istehlakçıları yalnız `next` hesab etməlidirlər ki, bu da çağırıldıqda `Option<Stream::Item>` verən bir future qaytarır.
//!
//! `next` tərəfindən qaytarılmış future, elementlər olduğu müddətdə `Some(Item)` verəcək və hamısı bitdikdən sonra iterasiyanın bitdiyini bildirmək üçün `None` verəcəkdir.
//! Asenkron bir problemi həll etmək üçün gözləyiriksə, future axın yenidən verməyə hazır olana qədər gözləyəcəkdir.
//!
//! Ayrı-ayrı axınlar təkrarlamanı davam etdirməyi seçə bilər və buna görə də `next`-ə yenidən zəng vurmaq bir nöqtədə yenidən `Some(Item)` verə bilər və ya verməyəcəkdir.
//!
//! ['Stream'] in tam tərifi bir sıra digər metodları da əhatə edir, lakin bunlar [`poll_next`]-in üstündə qurulmuş standart metodlardır və beləliklə onları pulsuz əldə edirsiniz.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Stream həyata keçirir
//!
//! Özünüzə məxsus bir axın yaratmaq iki mərhələdən ibarətdir: axının vəziyyətini saxlamaq üçün bir `struct` yaratmaq və sonra bu `struct` üçün [`Stream`] tətbiq etmək.
//!
//! `1`-dən `5`-ə qədər sayan `Counter` adlı bir axın edək:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Birincisi, struktur:
//!
//! /// Birdən beşə qədər sayan bir axın
//! struct Counter {
//!     count: usize,
//! }
//!
//! // saymamızın birdən başlamasını istəyirik, buna görə kömək üçün bir new() metodu əlavə edək.
//! // Bu qətiliklə lazım deyil, ancaq əlverişlidir.
//! // `count`-i sıfırdan başladığımızı nəzərə alsaq, bunun səbəbini aşağıda `poll_next()`'s tətbiqində görəcəyik.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sonra `Counter` üçün `Stream` tətbiq edirik:
//!
//! impl Stream for Counter {
//!     // usize ilə hesablayacağıq
//!     type Item = usize;
//!
//!     // poll_next() yeganə tələb olunan metoddur
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Sayımızı artırın.Buna görə sıfırdan başladıq.
//!         self.count += 1;
//!
//!         // Saymağı bitirib bitmədiyimizi yoxlayın.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Axınlar *tənbəldir*.Bu o deməkdir ki, sadəcə bir axın yaratmaq _do_-ni çox etmir.`next`-ə zəng edənə qədər həqiqətən heç bir şey olmur.
//! Yalnız bəzən yan təsirləri üçün bir axın yaratarkən bu bəzən qarışıqlıq mənbəyidir.
//! Tərtibçi bu cür davranışlar barədə bizi xəbərdar edəcək:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;