use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Asenkron təkrarlayıcılarla işləmək üçün bir interfeys.
///
/// Bu trait əsas axınıdır.
/// Ümumiyyətlə axınlar konsepsiyası haqqında daha çox məlumat üçün [module-level documentation]-ə baxın.
/// Xüsusilə, [implement `Stream`][impl] necə edəcəyinizi bilmək istəyə bilərsiniz.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Axının verdiyi məhsul növü.
    type Item;

    /// Bu axının növbəti dəyərini çıxartmağa cəhd edin, dəyər hələ mövcud deyilsə oyanmaq üçün cari tapşırığı qeyd edin və axın bitmişsə `None` qaytarın.
    ///
    /// # Qaytarma dəyəri
    ///
    /// Hər biri fərqli bir axın vəziyyətini göstərən bir neçə mümkün qaytarma dəyəri var:
    ///
    /// - `Poll::Pending` bu axının növbəti dəyərinin hələ hazır olmadığı deməkdir.Tətbiqlər cari tapşırığın növbəti dəyər hazır ola biləcəyi zaman bildirilməsini təmin edəcəkdir.
    ///
    /// - `Poll::Ready(Some(val))` axının uğurla bir `val` dəyərini yaratdığını və sonrakı `poll_next` zənglərində əlavə dəyərlər yarada biləcəyini bildirir.
    ///
    /// - `Poll::Ready(None)` axının dayandırıldığı və `poll_next`-ə bir daha çağırılmaması lazım olduğunu göstərir.
    ///
    /// # Panics
    ///
    /// Bir axın bitdikdən sonra (`Ready(None)` from `poll_next`)-i qaytardı, `poll_next` metodunu yenidən çağıraraq panic, əbədi bloklaşma və ya digər problemlərə səbəb ola bilər; `Stream` trait belə bir çağırışın təsirlərinə heç bir tələb qoymur.
    ///
    /// Bununla birlikdə, `poll_next` metodu `unsafe` olaraq qeyd olunmadığı üçün Rust-nin adi qaydaları tətbiq olunur: axın vəziyyətindən asılı olmayaraq çağırışlar heç vaxt təyin olunmayan davranışa (yaddaş pozulması, `unsafe` funksiyalarının səhv istifadəsi və ya bu kimi) səbəb olmamalıdır.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Axının qalan uzunluğundakı sərhədləri qaytarır.
    ///
    /// Xüsusi olaraq, `size_hint()`, birinci elementin alt sərhəd, ikinci elementin isə yuxarı sərhəd olduğu bir qayıq qaytarır.
    ///
    /// Döndürülən bağlamanın ikinci yarısı [`Seçim`]`<`[`usize`] `>` dir.
    /// Buradakı [`None`], bilinən bir yuxarı sərhəd olmadığı və ya yuxarı sərhədin [`usize`]-dən daha böyük olduğu anlamına gəlir.
    ///
    /// # Tətbiq qeydləri
    ///
    /// Bir axın tətbiqinin elan edilmiş element sayını təmin etməsi məcbur edilmir.Bir arabalı axın elementlərin alt sərhədlərindən az və ya yuxarı sərhədlərindən daha çox məhsul verə bilər.
    ///
    /// `size_hint()` ilk növbədə axın elementləri üçün yer ayırmaq kimi optimallaşdırma üçün istifadə olunmaq üçün nəzərdə tutulmuşdur, lakin məsələn, təhlükəli kodda məhdudiyyətləri yoxlamaq üçün etibar edilməməlidir.
    /// `size_hint()`-in səhv tətbiqi yaddaş təhlükəsizliyi pozuntularına səbəb olmamalıdır.
    ///
    /// Yəni tətbiq düzgün bir qiymətləndirmə təmin etməlidir, çünki əks halda trait protokolunun pozulması olardı.
    ///
    /// Varsayılan tətbiq hər hansı bir axın üçün düzgün olan "(0,` [`None`]`)"qayıdır.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}