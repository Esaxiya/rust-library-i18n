//! 'Dolayısıyla kopyalanamayan' növlər üçün `Clone` trait.
//!
//! Rust-də bəzi sadə növlər "implicitly copyable"-dir və onları təyin etdikdə və ya arqument kimi verdiyiniz zaman alıcı orijinal dəyərini yerində saxlayaraq bir nüsxə əldə edəcəkdir.
//! Bu tiplər kopyalamaq üçün ayırma tələb etmir və yekunlaşdırıcıları yoxdur (yəni sahib olduqları qutuları içermir və ya [`Drop`] tətbiq edirlər), buna görə tərtibçi onları kopyalamaq üçün ucuz və təhlükəsiz hesab edir.
//!
//! Digər növlər üçün [`Clone`] trait tətbiq edilərək [`clone`] metodunu çağıraraq konvensiyaya əsasən açıq surətdə kopyalanmalıdır.
//!
//! [`clone`]: Clone::clone
//!
//! Əsas istifadə nümunəsi:
//!
//! ```
//! let s = String::new(); // Simli tip Klonu tətbiq edir
//! let copy = s.clone(); // buna görə onu klonlaya bilərik
//! ```
//!
//! Clone trait-i asanlıqla tətbiq etmək üçün `#[derive(Clone)]`-dən də istifadə edə bilərsiniz.Misal:
//!
//! ```
//! #[derive(Clone)] // Morpheus struct-a Clone trait əlavə edirik
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // və indi onu klonlaya bilərik!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Bir obyekti açıq şəkildə kopyalamaq qabiliyyəti üçün ümumi bir trait.
///
/// [`Copy`]-dən fərqli olan [`Copy`] gizli və son dərəcə ucuzdur, `Clone` isə həmişə açıqdır və baha ola da bilər.
/// Bu xüsusiyyətləri tətbiq etmək üçün Rust, [`Copy`] yi yenidən tətbiq etməyinizə icazə vermir, ancaq `Clone` yi yenidən tətbiq edə və ixtiyari kodu işlədə bilərsiniz.
///
/// `Clone`, [`Copy`]-dən daha ümumi olduğundan [`Copy`]-i avtomatik olaraq `Clone` kimi bir şey edə bilərsiniz.
///
/// ## Derivable
///
/// Bütün sahələr `Clone` olduqda, bu trait `#[derive]` ilə istifadə edilə bilər.[`Clone`]-in "əldə etmə" tətbiqi hər sahədə [`clone`] çağırır.
///
/// [`clone`]: Clone::clone
///
/// Ümumi bir quruluş üçün `#[derive]`, ümumi parametrlərə bağlı `Clone` əlavə edərək şərti olaraq `Clone` tətbiq edir.
///
/// ```
/// // `derive` Oxumaq üçün Klon tətbiq edir<T>T klon olduqda.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone`-i necə tətbiq edə bilərəm?
///
/// [`Copy`] olan növlər `Clone`-nin əhəmiyyətsiz bir tətbiqinə sahib olmalıdır.Daha rəsmi:
/// `T: Copy`, `x: T` və `y: &T` varsa, `let x = y.clone();` `let x = *y;`-ə bərabərdir.
/// Manuel tətbiqetmələr bu dəyişməzliyi dəstəkləmək üçün diqqətli olmalıdır;Bununla birlikdə, təhlükəli kod yaddaş təhlükəsizliyini təmin etmək üçün ona etibar etməməlidir.
///
/// Nümunə funksiya göstəricisini tutan ümumi bir strukturdur.Bu vəziyyətdə, `Clone`-nin tətbiqi `əldə edilə bilməz ', lakin aşağıdakı kimi həyata keçirilə bilər:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Əlavə icraçılar
///
/// [implementors listed below][impls] ilə yanaşı, aşağıdakı növlər də `Clone` tətbiq edir:
///
/// * Funksiya növü (yəni, hər bir funksiya üçün müəyyən edilmiş növlər)
/// * Funksiya göstəricisi növləri (məsələn, `fn() -> i32`)
/// * Maddə növü `Clone` tətbiq edərsə (məsələn, `[i32; 123456]`), bütün ölçülər üçün massiv növləri.
/// * Tuple növləri, əgər hər bir komponent `Clone` tətbiq edərsə (məsələn, `()`, `(i32, bool)`)
/// * Bağlanma növləri, ətraf mühitdən heç bir dəyər əldə etmədikləri təqdirdə və ya alınan bütün bu dəyərlər `Clone`-i özləri tətbiq edirlər.
///   Qeyd edək ki, paylaşılan istinadla tutulan dəyişənlər hər zaman `Clone` tətbiq edir (referent olmasa belə), dəyişilə bilən istinadla tutulan dəyişənlər heç vaxt `Clone` tətbiq etmir.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Dəyərin bir nüsxəsini qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Klon tətbiq edir
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source`-dən kopyalama tapşırığını yerinə yetirir.
    ///
    /// `a.clone_from(&b)` funksionallığı baxımından `a = b.clone()`-ə bərabərdir, lakin lazımsız ayırmaların qarşısını almaq üçün `a` mənbələrini yenidən istifadə etmək üçün ləğv edilə bilər.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone`-in bir görünüşünü yaradan makro əldə edin.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): bu konstruksiyalar yalnız bir növün hər komponentinin Klonlama və ya Kopyalamağı tətbiq etdiyini iddia etmək üçün#[əldə etmək] tərəfindən istifadə olunur.
//
//
// Bu quruluşlar heç vaxt istifadəçi kodunda görünməməlidir.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// İbtidai tiplər üçün `Clone` tətbiqləri.
///
/// Rust-də təsvir edilə bilməyən tətbiqetmələr `rustc_trait_selection`-də `traits::SelectionContext::copy_clone_conditions()`-də həyata keçirilir.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Paylaşılan istinadlar klonlaşdırıla bilər, lakin dəyişdirilə bilən istinadlar *mümkün deyil*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Paylaşılan istinadlar klonlaşdırıla bilər, lakin dəyişdirilə bilən istinadlar *mümkün deyil*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}