use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Bu funksiya bir yerdə istifadə edildiyində və onun tətbiqi xəttləndirilə bilsə də, əvvəlki cəhdlər rustc-nı yavaşlatdı:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Yaddaş blokunun düzeni.
///
/// `Layout` nümunəsi müəyyən bir yaddaş planını təsvir edir.
/// Bir ayırıcıya vermək üçün bir giriş olaraq `Layout` düzəldirsiniz.
///
/// Bütün düzülüşlər əlaqəli bir ölçüyə və iki gücə uyğun bir hizaya malikdir.
///
/// (`GlobalAlloc`-in bütün yaddaş istəklərinin sıfır olmayan ölçüdə olmasını tələb etməsinə baxmayaraq, layoutların sıfır olmayan ölçüyə sahib olması üçün * tələb olunmadığını unutmayın.
/// Zəng edən ya bu kimi şərtlərin yerinə yetirilməsini təmin etməli, daha gərgin tələblərə sahib olan xüsusi ayırıcılardan istifadə etməli və ya daha yumşaq `Allocator` interfeysindən istifadə etməlidir.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // baytla ölçülən tələb olunan yaddaş blokunun ölçüsü.
    size_: usize,

    // baytla ölçülən tələb olunan yaddaş blokunun hizalanması.
    // bunun hər zaman ikiqat gücü olmasını təmin edirik, çünki API kimi `posix_memalign` buna ehtiyac duyur və Layout konstruktorlarına tətbiq etmək ağlabatan bir məhdudiyyətdir.
    //
    //
    // (Bununla birlikdə analoji olaraq 'align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) tələb etmirik
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Verilmiş bir `size` və `align`-dən bir `Layout` qurur və ya aşağıdakı şərtlərdən biri yerinə yetirilmədikdə `LayoutError` verir:
    ///
    /// * `align` sıfır olmamalı,
    ///
    /// * `align` iki güc olmalıdır,
    ///
    /// * `size`, ən yaxın `align` qatına qədər yuvarlandıqda, daşmamalı (yəni yuvarlaqlaşdırılmış dəyər `usize::MAX`-dən az və ya bərabər olmalıdır).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (ikisinin gücü hizalanma deməkdir!=0.)

        // Yuvarlaqlaşdırılmış ölçüsü:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Hizalanmanın yuxarıdan bilirik!=0.
        // Əlavə etmək (hizalamak, 1) daşmazsa, yuvarlaqlaşdırma yaxşı olar.
        //
        // Əksinə, və (ilə düzəldin, 1) ilə maska çəkmək yalnız aşağı sifarişli bitləri çıxardacaq.
        // Beləliklə, cəmi ilə daşma baş verərsə,&-mask bu daşqını geri qaytaracaq qədər çıxa bilməz.
        //
        //
        // Yuxarıda, məcmu daşqınının yoxlanılmasının həm lazımlı, həm də yetərli olduğu nəzərdə tutulur.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // TƏHLÜKƏSİZLİK: `from_size_align_unchecked` üçün şərtlər olmuşdur
        // yuxarıda yoxlanıldı.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Bütün yoxlamaları atlayaraq bir tərtibat yaradır.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki [`Layout::from_size_align`]-dən irəli şərtləri təsdiqləmir.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // TƏHLÜKƏSİZLİK: zəng edən `align`-nin sıfırdan böyük olmasını təmin etməlidir.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Bu tərtibin yaddaş bloku üçün baytda minimum ölçü.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Bu tərtibin yaddaş bloku üçün minimum bayt hizalaması.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` tipli bir dəyəri tutmaq üçün uyğun bir `Layout` qurur.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // TƏHLÜKƏSİZLİK: hizalanmanın Rust tərəfindən iki və
        // size + align combo ünvan məkanımıza sığacağına zəmanət verilir.
        // Nəticədə, panics kodunu kifayət qədər optimallaşdırmadıqda onu daxil etməmək üçün işarələnməmiş konstruktordan istifadə edin.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` üçün dəstək quruluşu ayırmaq üçün istifadə edilə bilən bir qeydi təsvir edən bir düzəliş hazırlayır (bir trait və ya bir dilim kimi ölçüsüz tip ola bilər).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // TƏHLÜKƏSİZLİK: bunun təhlükəli variantdan istifadə etməsi üçün `new`-də əsaslandırmaya baxın
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` üçün dəstək quruluşu ayırmaq üçün istifadə edilə bilən bir qeydi təsvir edən bir düzəliş hazırlayır (bir trait və ya bir dilim kimi ölçüsüz tip ola bilər).
    ///
    /// # Safety
    ///
    /// Bu funksiya yalnız aşağıdakı şərtlər olduqda zəng etmək üçün təhlükəsizdir:
    ///
    /// - `T` `Sized`-dirsə, bu funksiya hər zaman zəng etmək üçün təhlükəsizdir.
    /// - `T`-in ölçüsüz quyruğu:
    ///     - bir [slice], daha sonra dilim quyruğunun uzunluğu intallaşdırılmış bir tam ədəd olmalıdır və *bütün dəyərin* ölçüsü (dinamik quyruq uzunluğu + statik ölçülü prefiks) `isize`-ə uyğun olmalıdır.
    ///     - bir [trait object], daha sonra göstəricinin vtable hissəsi ölçüsüz bir koersiya ilə əldə edilmiş `T` tipi üçün etibarlı bir vtable-ı göstərməli və *bütün dəyər*(dinamik quyruq uzunluğu + statik ölçülü prefiks) ölçüsü `isize`-ə uyğun olmalıdır.
    ///
    ///     - bir (unstable) [extern type], bu funksiyanı çağırmaq həmişə təhlükəsizdir, ancaq xarici tipin düzeni bilinmədiyi üçün panic və ya başqa bir şəkildə səhv dəyəri qaytara bilər.
    ///     Xarici tip quyruğa istinad [`Layout::for_value`] ilə eyni davranışdır.
    ///     - əks halda mühafizəkar olaraq bu funksiyanı çağırmağa icazə verilmir.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // TƏHLÜKƏSİZLİK: bu funksiyaların şərtlərini arayana ötürürük
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // TƏHLÜKƏSİZLİK: bunun təhlükəli variantdan istifadə etməsi üçün `new`-də əsaslandırmaya baxın
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Asılı, lakin bu Layout üçün yaxşı hizalanmış bir `NonNull` yaradır.
    ///
    /// Qeyd edək ki, göstərici dəyəri potensial olaraq etibarlı bir göstəricini təmsil edə bilər, yəni bunun "not yet initialized" gözətçi dəyəri kimi istifadə edilməməsi lazımdır.
    /// Tənbəlliklə ayıran növlər başlanğıc vəziyyətini başqa yollarla izləməlidir.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // TƏHLÜKƏSİZLİK: hizalanmanın sıfır olmaması təmin edilir
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` ilə eyni tərtib dəyərini tuta bilən, eyni zamanda `align` düzəlişinə (baytla ölçülən) uyğunlaşdırılan qeydləri təsvir edən bir düzən yaradır.
    ///
    ///
    /// `self` əvvəlcədən təyin edilmiş hizalamaya cavab verirsə, o zaman `self` qaytarır.
    ///
    /// Qaytarılan düzənin fərqli bir uyğunlaşma olub-olmamasından asılı olmayaraq, bu metod ümumi ölçüyə heç bir dolğunluq əlavə etmədiyini unutmayın.
    /// Başqa sözlə, `K` 16 ölçüyə sahibdirsə, `K.align_to(32)`*yenə də* 16 ölçüyə sahib olacaqdır.
    ///
    /// `self.size()` və verilmiş `align` birləşməsi [`Layout::from_size_align`]-də göstərilən şərtləri pozduqda bir səhv qaytarır.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Aşağıdakı adresin `align`-i (baytla ölçülən) təmin etməsini təmin etmək üçün `self`-dən sonra taxmalı olduğumuz dolğunluq miqdarını qaytarır.
    ///
    /// məsələn, `self.size()` 9-dursa, `self.padding_needed_for(4)` 3-ü qaytarır, çünki bu, 4 hizalı bir ünvan əldə etmək üçün lazım olan minimum bayt dolma sayıdır (uyğun yaddaş blokunun 4 hizalı bir ünvandan başlayacağını düşünsək).
    ///
    ///
    /// `align` ikisinin gücü deyilsə, bu funksiyanın qaytarma dəyərinin heç bir mənası yoxdur.
    ///
    /// Qaytarılmış dəyərin faydası, `align`-nin ayrılmış bütün yaddaş bloku üçün başlanğıc ünvanının hizalanmasından az və ya bərabər olmasını tələb edir.Bu məhdudiyyəti təmin etməyin bir yolu `align <= self.align()` təmin etməkdir.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Yuvarlaqlaşdırılmış dəyər:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // və sonra dolgu fərqini qaytarırıq: `len_rounded_up - len`.
        //
        // Biz modul hesabdan istifadə edirik:
        //
        // 1. hizanın> 0 olmasına zəmanət verilir, buna görə hizalama, 1 həmişə etibarlıdır.
        //
        // 2.
        // `len + align - 1` ən çox `align - 1` aça bilər, buna görə də `!(align - 1)` ilə&-mask, daşma halında `len_rounded_up`-in özünün 0 olmasını təmin edəcəkdir.
        //
        //    Beləliklə, `len`-ə əlavə edildikdə, geri qaytarılan `align` uyğunlaşmasını xırda dərəcədə təmin edən 0 verir.
        //
        // (Əlbəttə ki, yuxarıda göstərilən qaydada ölçüsü və dolması çox olan yaddaş bloklarının ayrılması cəhdləri, ayırıcının onsuz da səhv etməsinə səbəb olmalıdır.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Bu düzənin ölçüsünü düzənin düzəldilməsinin qatına qədər yuvarlaqlaşdıraraq bir düzən yaradır.
    ///
    ///
    /// Bu, `padding_needed_for` nəticəsini tərtibatın mövcud ölçüsünə əlavə etməyə bərabərdir.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Bu aça bilməz.Layout invariantından sitat:
        // > `size`, `align`-in ən yaxın qatına qədər yuvarlandıqda,
        // > daşmamalıdır (yəni, yuvarlaqlaşdırılmış dəyər az olmalıdır
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` `n` nümunələri üçün qeydləri təsvir edən bir düzəliş yaradır, hər bir nümunənin istədiyi ölçü və hizalanma verilməsini təmin etmək üçün hər biri arasında uyğun miqdarda dolğu ilə.
    /// Uğurla `(k, offs)` qaytarır, burada `k` sıra düzümüdür və `offs` massivdəki hər elementin başlanğıcı arasındakı məsafədir.
    ///
    /// Aritmetik daşqında `LayoutError` qaytarır.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Bu aça bilməz.Layout invariantından sitat:
        // > `size`, `align`-in ən yaxın qatına qədər yuvarlandıqda,
        // > daşmamalıdır (yəni, yuvarlaqlaşdırılmış dəyər az olmalıdır
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // TƏHLÜKƏSİZLİK: self.align artıq etibarlı olduğu bilinir və ayırma_ölçüsü olmuşdur
        // onsuz da doludur.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `next`-in düzgün bir şəkildə düzəldilməsini təmin etmək üçün lazımlı hər hansı bir doldurulma daxil olmaqla `self` üçün qeydləri və ardından `next`-i qeyd edən bir yerleşim yaradır, lakin *arxada dolğu yoxdur*.
    ///
    /// C nümayəndəliyi düzənini `repr(C)` ilə uyğunlaşdırmaq üçün düzəni bütün sahələrlə genişləndirdikdən sonra `pad_to_align`-ə zəng etməlisiniz.
    /// (Varsayılan Rust təmsil düzeni `repr(Rust)`, as it is unspecified.) ilə uyğunlaşmağın bir yolu yoxdur
    ///
    /// Hər iki hissənin hizalanmasını təmin etmək üçün ortaya çıxan düzenin hizalanmasının maksimum `self` və `next` olacağını unutmayın.
    ///
    /// `Ok((k, offset))`-i qaytarır, burada `k` birləşdirilmiş qeydin düzənidir və `offset`, əlaqələndirilmiş qeydin içərisinə qoyulmuş `next` başlanğıcının nisbi yeri (qeyd özü 0 ofsetdən başlayır).
    ///
    ///
    /// Aritmetik daşqında `LayoutError` qaytarır.
    ///
    /// # Examples
    ///
    /// Bir `#[repr(C)]` quruluşunun düzənini və sahələrin sahələrindəki sahələrdəki yerləri hesablamaq üçün:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` ilə yekunlaşdırmağı unutmayın!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // işlədiyini test edin
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` `n` nümunələri üçün qeydləri təsvir edən bir düzən yaradır, hər bir nümunə arasında heç bir dolğu yoxdur.
    ///
    /// `repeat`-dən fərqli olaraq, `repeat_packed`, müəyyən bir `self` nümunəsi düzgün bir şəkildə düzəldilmiş olsa da, təkrarlanan `self` nümunələrinin düzgün bir şəkildə hizalanacağına zəmanət vermir.
    /// Başqa sözlə, `repeat_packed` tərəfindən qaytarılmış düzül bir sıra ayırmaq üçün istifadə olunursa, massivdəki bütün elementlərin düzgün bir şəkildə düzəldilməsinə zəmanət verilmir.
    ///
    /// Aritmetik daşqında `LayoutError` qaytarır.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` üçün qeydləri və ardından `next`-i təsvir edən bir düzəliş yaradır, ikisi arasında əlavə dolğu yoxdur.
    /// Heç bir dolgu qoyulmadığından, `next`-nin hizalanması əhəmiyyətsizdir və nəticədə düzəldilməyə *ümumiyyətlə* daxil edilmir.
    ///
    ///
    /// Aritmetik daşqında `LayoutError` qaytarır.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` üçün qeydləri təsvir edən bir düzən yaradır.
    ///
    /// Aritmetik daşqında `LayoutError` qaytarır.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` və ya başqa bir `Layout` konstruktoruna verilən parametrlər sənədləşdirilmiş məhdudiyyətlərini təmin etmir.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait Xətrinin aşağı axını üçün buna ehtiyacımız var)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}