//! Yaddaş ayırma API'ləri

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` xətası, mənbənin tükənməsi və ya bu ayırıcı ilə verilən giriş arqumentlərini birləşdirərkən səhv bir şey səbəb ola bilən bir ayırma uğursuzluğunu göstərir.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (trait Xətrinin aşağı axını üçün buna ehtiyacımız var)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` tətbiqi, [`Layout`][] vasitəsilə təsvir olunan təsadüfi məlumat bloklarını ayırmaq, böyütmək, kiçiltmək və bölüşdürmək olar.
///
/// `Allocator` ZST-lərdə, istinadlarda və ya ağıllı göstəricilərdə tətbiq edilməsi üçün nəzərdə tutulmuşdur, çünki `MyAlloc([u8; N])` kimi bir ayırıcıya sahib olanlar göstərilən yaddaşa yenilənmədən köçürülə bilməz.
///
/// [`GlobalAlloc`][]-dən fərqli olaraq, `Allocator`-də sıfır ölçülü ayırmalara icazə verilir.
/// Əsas bir ayırıcı bunu dəstəkləmirsə (məsələn, jemalloc) və ya boş bir göstəricini (məsələn, `libc::malloc`) qaytarırsa, bu tətbiqetmə tərəfindən tutulmalıdır.
///
/// ### Hazırda ayrılmış yaddaş
///
/// Bəzi metodlar bir yaddaş blokunun bir ayırıcı vasitəsi ilə *hal-hazırda ayrılmasını* tələb edir.Bu o deməkdir ki:
///
/// * bu yaddaş bloku üçün başlanğıc ünvanı əvvəllər [`allocate`], [`grow`] və ya [`shrink`] tərəfindən qaytarılmış və
///
/// * yaddaş bloku sonradan ayrılmamışdır, burada bloklar ya birbaşa [`deallocate`]-ə ötürülməklə bölüşdürülür, ya da `Ok` qaytaran [`grow`] və ya [`shrink`]-ə ötürülərək dəyişdirilir.
///
/// `grow` və ya `shrink` `Err` qaytardılarsa, ötürülən göstərici qüvvədə qalır.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Yaddaşa uyğun
///
/// Bəzi metodlar bir planın *yaddaş blokuna uyğun gəlməsini* tələb edir.
/// "fit"-ə düzəliş üçün bir yaddaş bloku deməkdir (və ya ekvivalent olaraq, bir yaddaş bloku üçün "fit"-a bir düzən) aşağıdakı şərtlərin yerinə yetirilməsi lazımdır:
///
/// * Blok [`layout.align()`] ilə eyni hizalanma ilə ayrılmalıdır və
///
/// * Təqdim olunan [`layout.size()`], `min ..= max` aralığına düşməlidir, burada:
///   - `min` bloku ayırmaq üçün ən son istifadə edilən düzənin ölçüsüdür və
///   - `max` [`allocate`], [`grow`] və ya [`shrink`]-dən qaytarılmış son faktiki ölçüsüdür.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Bir ayırıcıdan qaytarılan yaddaş blokları etibarlı yaddaşa işarə etməli və nümunə və bütün klonları düşənə qədər etibarlılığını saxlamalıdır,
///
/// * ayırıcının klonlaşdırılması və ya köçürülməsi bu ayırıcıdan qaytarılan yaddaş bloklarını ləğv etməməlidir.Klonlaşdırılmış ayırıcı eyni ayırıcı kimi davranmalı və
///
/// * [*currently allocated*] olan bir yaddaş blokuna hər hansı bir göstərici ayırıcının başqa hər hansı bir metoduna keçə bilər.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Bir yaddaş bloku ayırmaq cəhdləri.
    ///
    /// Uğurla `layout` ölçüsü və hizalama zəmanətlərinə cavab verən bir [`NonNull<[u8]>`][NonNull] qaytarır.
    ///
    /// Qaytarılmış blok `layout.size()` tərəfindən göstəriləndən daha böyük bir ölçüyə sahib ola bilər və ya içindəkiləri başlanğıc edə bilər.
    ///
    /// # Errors
    ///
    /// `Err`-in qaytarılması, yaddaşın tükəndiyini və ya `layout`-nin ayırıcının ölçüsünə və ya hizalama məhdudiyyətlərinə cavab vermədiyini göstərir.
    ///
    /// Tətbiqlər, `Err`-i çaxnaşma və ya abort etmək əvəzinə yaddaş tükənməsinə qaytarması tövsiyə olunur, lakin bu, ciddi bir şərt deyil.
    /// (Xüsusilə: bu trait-ni yaddaşın tükənməsini dayandıran əsas yerli ayırma kitabxanasının üstündə tətbiq etmək *qanuni*).
    ///
    /// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` kimi davranır, eyni zamanda qaytarılmış yaddaşın sıfır başlanğıc olmasını təmin edir.
    ///
    /// # Errors
    ///
    /// `Err`-in qaytarılması, yaddaşın tükəndiyini və ya `layout`-nin ayırıcının ölçüsünə və ya hizalama məhdudiyyətlərinə cavab vermədiyini göstərir.
    ///
    /// Tətbiqlər, `Err`-i çaxnaşma və ya abort etmək əvəzinə yaddaş tükənməsinə qaytarması tövsiyə olunur, lakin bu, ciddi bir şərt deyil.
    /// (Xüsusilə: bu trait-ni yaddaşın tükənməsini dayandıran əsas yerli ayırma kitabxanasının üstündə tətbiq etmək *qanuni*).
    ///
    /// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // TƏHLÜKƏSİZLİK: `alloc` etibarlı bir yaddaş blokunu qaytarır
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` tərəfindən istinad olunan yaddaş bölüşdürülür.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı vasitəsilə [*currently allocated*] yaddaş blokunu bildirməlidir və
    /// * `layout` yaddaş blokunu [*fit*] olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Yaddaş blokunu genişləndirmək cəhdləri.
    ///
    /// Bir göstərici və ayrılmış yaddaşın həqiqi ölçüsü olan yeni bir [`NonNull<[u8]>`][NonNull] qaytarır.Göstərici `new_layout` tərəfindən təsvir edilmiş məlumatları saxlamaq üçün uygundur.
    /// Bunu həyata keçirmək üçün, ayırıcı `ptr` tərəfindən istinad edilən ayırmanı yeni düzüşə uyğun olaraq genişləndirə bilər.
    ///
    /// Bu `Ok` qaytararsa, `ptr` tərəfindən istinad edilən yaddaş blokunun mülkiyyəti bu ayırıcıya köçürülmüşdür.
    /// Yaddaş sərbəst buraxılmış və ya olmamış ola bilər və bu metodun geri qaytarma dəyəri ilə yenidən zəngçiyə köçürülmədiyi halda istifadəyə yararsız hesab edilməlidir.
    ///
    /// Bu metod `Err` qaytararsa, yaddaş blokunun mülkiyyəti bu ayırıcıya keçməmişdir və yaddaş blokunun məzmunu dəyişdirilməmişdir.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı vasitəsi ilə [*currently allocated*] yaddaş blokunu bildirməlidir.
    /// * `old_layout` bu yaddaş blokunu [*fit*] olmalıdır (`new_layout` arqumentinin ona uyğun olmaması lazımdır.)
    /// * `new_layout.size()` `old_layout.size()`-dən böyük və ya bərabər olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yeni düzən ayırıcının ölçüsünə və ayırıcının məhdudlaşdırma məhdudiyyətlərinə cavab vermirsə və ya başqa bir şəkildə böyüməsə, `Err` qaytarır.
    ///
    /// Tətbiqlər, `Err`-i çaxnaşma və ya abort etmək əvəzinə yaddaş tükənməsinə qaytarması tövsiyə olunur, lakin bu, ciddi bir şərt deyil.
    /// (Xüsusilə: bu trait-ni yaddaşın tükənməsini dayandıran əsas yerli ayırma kitabxanasının üstündə tətbiq etmək *qanuni*).
    ///
    /// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // TƏHLÜKƏSİZLİK: `new_layout.size()`-dən böyük və ya bərabər olmalıdır
        // `old_layout.size()`, həm köhnə, həm də yeni yaddaş ayırması `old_layout.size()` bayt üçün oxumaq və yazmaq üçün etibarlıdır.
        // Ayrıca, köhnə ayırma hələ ayrılmadığından, `new_ptr` ilə üst-üstə düşə bilməz.
        // Beləliklə, `copy_nonoverlapping`-ə zəng təhlükəsizdir.
        // `dealloc` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən dəstəklənməlidir.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` kimi davranır, eyni zamanda yeni məzmunun qaytarılmadan əvvəl sıfıra qoyulmasını təmin edir.
    ///
    /// Yaddaş bloku, uğurlu bir zəngdən sonra aşağıdakı məzmunu ehtiva edəcəkdir
    /// `grow_zeroed`:
    ///   * `0..old_layout.size()` baytlar orijinal ayrılmadan qorunur.
    ///   * Bayt `old_layout.size()..old_size`, ayırıcının tətbiqindən asılı olaraq ya qorunacaq, ya da sıfırlanacaq.
    ///   `old_size` `grow_zeroed` çağırışından əvvəl yaddaş blokunun ölçüsünə aiddir, bu, ayrıldıqda əvvəlcə tələb olunduğundan daha böyük ola bilər.
    ///   * `old_size..new_size` baytları sıfırlanır.`new_size`, `grow_zeroed` çağırışı ilə qaytarılmış yaddaş blokunun ölçüsünə istinad edir.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı vasitəsi ilə [*currently allocated*] yaddaş blokunu bildirməlidir.
    /// * `old_layout` bu yaddaş blokunu [*fit*] olmalıdır (`new_layout` arqumentinin ona uyğun olmaması lazımdır.)
    /// * `new_layout.size()` `old_layout.size()`-dən böyük və ya bərabər olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yeni düzən ayırıcının ölçüsünə və ayırıcının məhdudlaşdırma məhdudiyyətlərinə cavab vermirsə və ya başqa bir şəkildə böyüməsə, `Err` qaytarır.
    ///
    /// Tətbiqlər, `Err`-i çaxnaşma və ya abort etmək əvəzinə yaddaş tükənməsinə qaytarması tövsiyə olunur, lakin bu, ciddi bir şərt deyil.
    /// (Xüsusilə: bu trait-ni yaddaşın tükənməsini dayandıran əsas yerli ayırma kitabxanasının üstündə tətbiq etmək *qanuni*).
    ///
    /// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // TƏHLÜKƏSİZLİK: `new_layout.size()`-dən böyük və ya bərabər olmalıdır
        // `old_layout.size()`, həm köhnə, həm də yeni yaddaş ayırması `old_layout.size()` bayt üçün oxumaq və yazmaq üçün etibarlıdır.
        // Ayrıca, köhnə ayırma hələ ayrılmadığından, `new_ptr` ilə üst-üstə düşə bilməz.
        // Beləliklə, `copy_nonoverlapping`-ə zəng təhlükəsizdir.
        // `dealloc` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən dəstəklənməlidir.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Yaddaş blokunu kiçiltmək cəhdləri.
    ///
    /// Bir göstərici və ayrılmış yaddaşın həqiqi ölçüsü olan yeni bir [`NonNull<[u8]>`][NonNull] qaytarır.Göstərici `new_layout` tərəfindən təsvir edilmiş məlumatları saxlamaq üçün uygundur.
    /// Bunu həyata keçirmək üçün, ayırıcı `ptr`-in istinad etdiyi ayırmanı yeni tərtibata uyğunlaşdırmaq üçün azalda bilər.
    ///
    /// Bu `Ok` qaytararsa, `ptr` tərəfindən istinad edilən yaddaş blokunun mülkiyyəti bu ayırıcıya köçürülmüşdür.
    /// Yaddaş sərbəst buraxılmış və ya olmamış ola bilər və bu metodun geri qaytarma dəyəri ilə yenidən zəngçiyə köçürülmədiyi halda istifadəyə yararsız hesab edilməlidir.
    ///
    /// Bu metod `Err` qaytararsa, yaddaş blokunun mülkiyyəti bu ayırıcıya keçməmişdir və yaddaş blokunun məzmunu dəyişdirilməmişdir.
    ///
    /// # Safety
    ///
    /// * `ptr` bu ayırıcı vasitəsi ilə [*currently allocated*] yaddaş blokunu bildirməlidir.
    /// * `old_layout` bu yaddaş blokunu [*fit*] olmalıdır (`new_layout` arqumentinin ona uyğun olmaması lazımdır.)
    /// * `new_layout.size()` `old_layout.size()`-dən kiçik və ya ona bərabər olmalıdır.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yeni düzən ayırıcının ölçüsünə və ayırıcının hizalama məhdudiyyətlərinə cavab vermədikdə və ya başqa bir şəkildə kiçilmədikdə `Err` qaytarır.
    ///
    /// Tətbiqlər, `Err`-i çaxnaşma və ya abort etmək əvəzinə yaddaş tükənməsinə qaytarması tövsiyə olunur, lakin bu, ciddi bir şərt deyil.
    /// (Xüsusilə: bu trait-ni yaddaşın tükənməsini dayandıran əsas yerli ayırma kitabxanasının üstündə tətbiq etmək *qanuni*).
    ///
    /// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // TƏHLÜKƏSİZLİK: `new_layout.size()`-dən aşağı və ya bərabər olmalıdır
        // `old_layout.size()`, həm köhnə, həm də yeni yaddaş ayırması `new_layout.size()` bayt üçün oxumaq və yazmaq üçün etibarlıdır.
        // Ayrıca, köhnə ayırma hələ ayrılmadığından, `new_ptr` ilə üst-üstə düşə bilməz.
        // Beləliklə, `copy_nonoverlapping`-ə zəng təhlükəsizdir.
        // `dealloc` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən dəstəklənməlidir.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Bu `Allocator` nümunəsi üçün "by reference" adapter yaradır.
    ///
    /// Geri qaytarılan adapter `Allocator`-i də tətbiq edir və sadəcə borc alacaq.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // TƏHLÜKƏSİZLİK: təhlükəsizlik müqaviləsi axtaran tərəfindən təmin edilməlidir
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TƏHLÜKƏSİZLİK: təhlükəsizlik müqaviləsi axtaran tərəfindən təmin edilməlidir
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TƏHLÜKƏSİZLİK: təhlükəsizlik müqaviləsi axtaran tərəfindən təmin edilməlidir
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TƏHLÜKƏSİZLİK: təhlükəsizlik müqaviləsi axtaran tərəfindən təmin edilməlidir
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}