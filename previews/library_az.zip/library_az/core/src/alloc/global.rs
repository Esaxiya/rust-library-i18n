use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// `#[global_allocator]` atributu vasitəsilə standart kitabxananın standart olaraq qeyd edilə biləcəyi bir yaddaş ayırıcısı.
///
/// Bəzi metodlar bir yaddaş blokunun bir ayırıcı vasitəsi ilə *hal-hazırda ayrılmasını* tələb edir.Bu o deməkdir ki:
///
/// * bu yaddaş bloku üçün başlanğıc ünvanı əvvəllər əvvəlki bir zəng ilə `alloc` kimi bir ayırma metoduna qaytarılmış və
///
/// * yaddaş bloku sonradan ayrılmamışdır, burada bloklar ya `dealloc` kimi bir bölüşdürmə metoduna keçməklə ya da sıfır olmayan bir göstəricini qaytaran bir yenidən bölüşdürmə metoduna keçməklə bölüşdürülür.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait, bir sıra səbəblərdən bir `unsafe` trait'dir və icraçılar bu müqavilələrə riayət etmələrini təmin etməlidirlər:
///
/// * Qlobal ayırıcılar açılsa, bu təyin olunmamış davranışdır.Bu məhdudiyyət future-də qaldırıla bilər, lakin hal hazırda bu funksiyalardan hər hansı birinin panic yaddaşın təhlükəsizliyinə səbəb ola bilər.
///
/// * `Layout` sorğular və ümumiyyətlə hesablamalar düzgün olmalıdır.Bu trait-ə zəng edənlərin hər bir metod üzrə müəyyən edilmiş müqavilələrə etibar etməsinə icazə verilir və icraçılar bu cür müqavilələrin həqiqiliyini təmin etməlidirlər.
///
/// * Mənbədə açıq yığın ayırmalar olsa da, əslində baş verən ayırmalara etibar edə bilməzsiniz.
/// Optimizator ya tamamilə aradan qaldıracağı, ya da yığına keçə biləcəyi istifadə olunmayan ayırmalar aşkar edə bilər və beləliklə ayırıcıya heç vaxt müraciət edə bilməz.
/// Optimizator ayrıca ayırmanın səhv olmadığını düşünə bilər, buna görə əvvəllər ayırıcı arızaları səbəbindən uğursuz olan kod indi birdən işləyə bilər, çünki optimizator ayırmaya ehtiyac ətrafında işləyir.
/// Daha konkret olaraq, xüsusi ayırıcınızın nə qədər ayırmanın baş verdiyini hesablamağa icazə verməsindən asılı olmayaraq aşağıdakı kod nümunəsi səssizdir.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Yuxarıda göstərilən optimallaşdırmaların tətbiq edilə bilən tək optimallaşdırma olmadığını unutmayın.Proqram davranışı dəyişdirilmədən silinə bilsələr, ümumiyyətlə yığın ayırmalarının baş verməsinə etibar edə bilməzsiniz.
///   Ayrışmaların çap edilərək izlənən və ya başqa bir şəkildə əks təsir göstərən bir ayırıcı vasitəsi ilə aşkarlanmasına baxmayaraq ayırmaların baş verib-verməməsi proqram davranışının bir hissəsi deyil.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Verilən `layout` tərəfindən təsvir olunduğu kimi yaddaş ayırın.
    ///
    /// Bir göstəricini yeni ayrılmış yaddaşa qaytarır və ya ayırma uğursuzluğunu göstərmək üçün boşdur.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki zəng edən `layout`-in sıfır olmayan ölçüyə sahib olmasını təmin etmirsə, təyin olunmamış davranış yarana bilər.
    ///
    /// (Uzatma alt yazıları davranış üçün daha spesifik sərhədlər təmin edə bilər, məsələn, sıfır ölçülü ayırma tələbinə cavab olaraq bir gözətçi ünvanı və ya sıfır göstəriciyə zəmanət verə bilər.)
    ///
    /// Ayrılmış yaddaş bloku işə salına bilər və ya olmaya bilər.
    ///
    /// # Errors
    ///
    /// Sıf bir göstəricinin qaytarılması, yaddaşın tükəndiyini və ya `layout`-nin bu ayırıcının ölçüsünə və ya hizalama məhdudiyyətlərinə cavab vermədiyini göstərir.
    ///
    /// Tətbiqatlar abort etməkdənsə yaddaşın tükənməsinə təsirsiz vəziyyətə gətirmək üçün tövsiyə olunur, lakin bu ciddi bir şərt deyil.
    /// (Xüsusilə: bu trait-ni yaddaşın tükənməsini dayandıran əsas yerli ayırma kitabxanasının üstündə tətbiq etmək *qanuni*).
    ///
    /// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Verilən `ptr` göstəricisindəki yaddaş blokunu verilmiş `layout` ilə bölüşdürün.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki zəng edən aşağıdakıların hamısını təmin etmirsə, təyin olunmamış davranış yarana bilər:
    ///
    ///
    /// * `ptr` hal hazırda bu ayırıcı vasitəsilə ayrılmış yaddaş blokunu göstərməlidir,
    ///
    /// * `layout` bu yaddaş blokunu ayırmaq üçün istifadə edilən eyni sxem olmalıdır.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// `alloc` kimi davranır, eyni zamanda məzmunun qaytarılmadan əvvəl sıfıra qoyulmasını təmin edir.
    ///
    /// # Safety
    ///
    /// Bu funksiya `alloc` ilə eyni səbəblərdən təhlükəlidir.
    /// Bununla birlikdə ayrılmış yaddaş blokunun başlanğıc üçün zəmanət verilir.
    ///
    /// # Errors
    ///
    /// Sıf bir göstəricinin qaytarılması, yaddaşın tükəndiyini və ya `layout`-nin `alloc`-də olduğu kimi ayırıcının ölçüsünə və ya hizalama məhdudiyyətlərinə cavab vermədiyini göstərir.
    ///
    /// Bir ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // TƏHLÜKƏSİZLİK: `alloc` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən təmin edilməlidir.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // TƏHLÜKƏSİZLİK: bölgü müvəffəq olduqda, bölgə `ptr`-dən
            // `size` ölçülü yazıların etibarlı olmasına zəmanət verilir.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Verilən `new_size`-ə bir yaddaş blokunu kiçilt və ya böyüt.
    /// Blok verilmiş `ptr` göstəricisi və `layout` tərəfindən təsvir edilmişdir.
    ///
    /// Bu boş olmayan bir göstəricini qaytararsa, `ptr` tərəfindən istinad edilən yaddaş blokunun mülkiyyəti bu ayırıcıya köçürülmüşdür.
    /// Yaddaş bölüşdürülmüş və ya ayrılmamış ola bilər və istifadəyə yararsız hesab edilməlidir (əlbəttə ki, bu metodun qaytarma dəyəri ilə yenidən zəngçiyə köçürülməyibsə).
    /// Yeni yaddaş bloku `layout` ilə ayrılır, lakin `size` ilə `new_size`-ə yenilənir.
    /// Bu yeni tərtibat yeni yaddaş blokunu `dealloc` ilə ayırarkən istifadə olunmalıdır.
    /// Yeni yaddaş blokunun `0..min(layout.size(), new_size) `aralığının orijinal blokla eyni dəyərlərə sahib olmasına zəmanət verilir.
    ///
    /// Bu metod null qaytararsa, yaddaş blokunun mülkiyyəti bu ayırıcıya keçməmişdir və yaddaş blokunun məzmunu dəyişdirilməmişdir.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir, çünki zəng edən aşağıdakıların hamısını təmin etmirsə, təyin olunmamış davranış yarana bilər:
    ///
    /// * `ptr` hal hazırda bu ayırıcı vasitəsi ilə ayrılmalıdır,
    ///
    /// * `layout` bu yaddaş blokunu ayırmaq üçün istifadə edilən eyni düzəltmə olmalıdır,
    ///
    /// * `new_size` sıfırdan böyük olmalıdır.
    ///
    /// * `new_size`, ən yaxın `layout.align()` qatına qədər yuvarlandıqda, daşmamalı (yəni yuvarlaqlaşdırılmış dəyər `usize::MAX`-dən az olmalıdır).
    ///
    /// (Uzatma alt yazıları davranış üçün daha spesifik sərhədlər təmin edə bilər, məsələn, sıfır ölçülü ayırma tələbinə cavab olaraq bir gözətçi ünvanı və ya sıfır göstəriciyə zəmanət verə bilər.)
    ///
    /// # Errors
    ///
    /// Yeni düzəliş ayırıcının ölçüsü və hizalama məhdudiyyətlərinə cavab vermirsə və ya başqa yerdəyişmə uğursuz olarsa sıfır qaytarır.
    ///
    /// Tətbiqlər, çaxnaşma və ya abortdan çox, yaddaşın tükənməsinə təsirsiz hala gətirilməsinə təşviq edilir, lakin bu ciddi bir şərt deyil.
    /// (Xüsusilə: bu trait-ni yaddaşın tükənməsini dayandıran əsas yerli ayırma kitabxanasının üstündə tətbiq etmək *qanuni*).
    ///
    /// Yenidən ayırma səhvinə cavab olaraq hesablamanı ləğv etmək istəyən müştərilər, birbaşa `panic!` və ya bənzərini çağırmaqdansa, [`handle_alloc_error`] funksiyasına zəng etmələri tövsiyə olunur.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // TƏHLÜKƏSİZLİK: zəng edən `new_size`-in aşmamasını təmin etməlidir.
        // `layout.align()` bir `Layout`-dən gəlir və beləliklə etibarlı olmasına zəmanət verilir.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // TƏHLÜKƏSİZLİK: zəng edən `new_layout`-nin sıfırdan böyük olmasını təmin etməlidir.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // TƏHLÜKƏSİZLİK: əvvəllər ayrılmış blok yeni ayrılmış blokla üst-üstə düşə bilməz.
            // `dealloc` üçün təhlükəsizlik müqaviləsi zəng edən tərəfindən dəstəklənməlidir.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}