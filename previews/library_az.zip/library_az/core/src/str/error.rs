//! utf8 səhv tipini təyin edir.

use crate::fmt;

/// [`u8`] ardıcıllığını bir simli kimi şərh etməyə çalışarkən baş verə biləcək səhvlər.
///
/// Beləliklə, `from_utf8` ailəsi, həm [`String`] s, həm də [`&str`] üçün funksiya və metodlar bu səhvdən istifadə edirlər.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Bu səhv növünün metodları, yığın yaddaşını ayırmadan `String::from_utf8_lossy`-ə bənzər bir iş yaratmaq üçün istifadə edilə bilər:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Müvafiq UTF-8-nin doğrulandığı verilmiş sətirdəki indeksi qaytarır.
    ///
    /// `from_utf8(&input[..index])`-in `Ok(_)`-yə dönməsi üçün maksimum indeksdir.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::str;
    ///
    /// // bəzi etibarsız baytlar, bir vector-də
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 bir Utf8Error qaytarır
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ikinci bayt burada səhvdir
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Hata haqqında daha çox məlumat verir:
    ///
    /// * `None`: girişin sonu gözlənilmədən əldə edildi.
    ///   `self.valid_up_to()` girişin sonundan 1 ilə 3 bayt arasındadır.
    ///   Bir bayt axını (məsələn, bir fayl və ya şəbəkə yuvası) artımlı olaraq dekodlanırsa, bu, UTF-8 bayt ardıcıllığı birdən çox hissəni əhatə edən etibarlı bir `char` ola bilər.
    ///
    ///
    /// * `Some(len)`: gözlənilməz bir bayta rast gəlindi.
    ///   Təqdim olunan uzunluq, `valid_up_to()` tərəfindən verilən indeksdən başlayan etibarsız bayt sırasıdır.
    ///   Kod itkisi itkisi halında həmin ardıcıllıqdan sonra ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] qoyulduqdan sonra) davam etməlidir.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] istifadə edərək bir `bool`-i təhlil edərkən bir səhv geri dönmədi
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}