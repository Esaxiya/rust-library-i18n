//! Simli manipulyasiya.
//!
//! Daha ətraflı məlumat üçün [`std::str`] moduluna baxın.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. hüdudlarından kənarda
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. başla <=son
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. simvol hüdudu
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // xarakteri tap
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` lendən az və bir sərhəd hüdudu olmalıdır
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` uzunluğunu qaytarır.
    ///
    /// Bu uzunluq [`char`] lər və ya qrafemlər deyil, baytlardadır.
    /// Başqa sözlə, bir insanın ipin uzunluğunu düşündüyü şey olmaya bilər.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // xülya f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self`-in sıfır bayt uzunluğu varsa `true` qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// `İndeks`-baytın UTF-8 kod nöqtəsi ardıcıllığındakı və ya sətrin sonundakı ilk bayt olduğunu yoxlayır.
    ///
    ///
    /// Sətrin başlanğıcı və sonu (`indeks== self.len()`) sərhəd sayıldığı zaman.
    ///
    /// `index` `self.len()`-dən böyük olduqda `false` qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` başlanğıcı
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // ikinci bayt `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // üçüncü bayt `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 və len həmişə yaxşıdır.
        // Çeki asanlıqla optimallaşdırması və bu halda oxu sətri məlumatlarını atlaya bilməsi üçün açıq şəkildə 0 üçün test edin.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Bu bit sehrinə bərabərdir: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Simli dilimi bayt diliminə çevirir.
    /// Bayt dilimini yenidən simli dilimə çevirmək üçün [`from_utf8`] funksiyasından istifadə edin.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // TƏHLÜKƏSİZLİK: const səsi, çünki eyni tərtiblə iki növü ötürürük
        unsafe { mem::transmute(self) }
    }

    /// Dəyişdirilə bilən simli dilimi dəyişdirilə bilən bayt diliminə çevirir.
    ///
    /// # Safety
    ///
    /// Zəng edən, borcun bitməsindən və əsas `str`-dən istifadə edilməzdən əvvəl dilimin məzmununun UTF-8 etibarlı olmasını təmin etməlidir.
    ///
    ///
    /// Məzmunu UTF-8 etibarlı olmayan bir `str`-in istifadəsi, təyin olunmamış davranışdır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // TƏHLÜKƏSİZLİK: `&str`-dən `&[u8]`-ə aktyorlar, `str`-dən etibarən etibarlıdır
        // `&[u8]` ilə eyni tərtibata malikdir (bu zəmanəti yalnız libstd verə bilər).
        // Göstəricidən imtina təhlükəsizdir, çünki yazı üçün etibarlı olduğu zəmanət verilən dəyişkən bir istinaddan gəlir.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Bir simli dilimi xam bir göstəriciyə çevirir.
    ///
    /// Simli dilimlər bir dilim bayt olduğundan, xam göstərici bir [`u8`]-ə işarə edir.
    /// Bu göstərici simli dilimin ilk baytına işarə edəcəkdir.
    ///
    /// Zəng edən, qaytarılmış göstəricinin heç vaxt yazılmadığından əmin olmalıdır.
    /// Simli dilimin məzmununu dəyişdirmək lazımdırsa, [`as_mut_ptr`] istifadə edin.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Dəyişdirilə bilən simli dilimi xam göstəriciyə çevirir.
    ///
    /// Simli dilimlər bir dilim bayt olduğundan, xam göstərici bir [`u8`]-ə işarə edir.
    /// Bu göstərici simli dilimin ilk baytına işarə edəcəkdir.
    ///
    /// Simli dilimin yalnız etibarlı UTF-8 olaraq qalacaq şəkildə dəyişdirildiyindən əmin olmaq sizin məsuliyyətinizdir.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` sublice qaytarır.
    ///
    /// Bu, `str`-i indeksləşdirmək üçün çaxnaşmayan alternativdir.
    /// Ekvivalent indeksləmə əməliyyatı panic olduqda [`None`] qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // UTF-8 sıra hüdudlarında olmayan göstəricilər
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // hüdudlarından kənarda
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` dəyişdirilə bilən sublice qaytarır.
    ///
    /// Bu, `str`-i indeksləşdirmək üçün çaxnaşmayan alternativdir.
    /// Ekvivalent indeksləmə əməliyyatı panic olduqda [`None`] qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // düzgün uzunluq
    /// assert!(v.get_mut(0..5).is_some());
    /// // hüdudlarından kənarda
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` yoxlanılmamış bir sublice qaytarır.
    ///
    /// Bu, `str`-i indeksləşdirmək üçün yoxlanılmamış alternativdir.
    ///
    /// # Safety
    ///
    /// Bu funksiyanı axtaranlar bu şərtlərin yerinə yetirilməsindən məsuldurlar:
    ///
    /// * Başlanğıc indeks bitmə indeksini aşmamalıdır;
    /// * İndekslər orijinal dilimin hüdudlarında olmalıdır;
    /// * İndekslər UTF-8 sıra hüdudlarında olmalıdır.
    ///
    /// Bunu etmədikdə, geri qaytarılan dilim etibarsız yaddaşa istinad edə bilər və ya `str` tipi ilə əlaqələndirilən dəyişməzləri poza bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // TƏHLÜKƏSİZLİK: zəng edən `get_unchecked` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır;
        // `self` etibarlı bir istinad olduğu üçün dilim ayrılır.
        // Geri qaytarılan göstərici təhlükəsizdir, çünki `SliceIndex`-in imlaları buna zəmanət verməlidir.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str`-in dəyişdirilə bilən, yoxlanılmamış bir sublice qaytarır.
    ///
    /// Bu, `str`-i indeksləşdirmək üçün yoxlanılmamış alternativdir.
    ///
    /// # Safety
    ///
    /// Bu funksiyanı axtaranlar bu şərtlərin yerinə yetirilməsindən məsuldurlar:
    ///
    /// * Başlanğıc indeks bitmə indeksini aşmamalıdır;
    /// * İndekslər orijinal dilimin hüdudlarında olmalıdır;
    /// * İndekslər UTF-8 sıra hüdudlarında olmalıdır.
    ///
    /// Bunu etmədikdə, geri qaytarılan dilim etibarsız yaddaşa istinad edə bilər və ya `str` tipi ilə əlaqələndirilən dəyişməzləri poza bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // TƏHLÜKƏSİZLİK: zəng edən `get_unchecked_mut` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır;
        // `self` etibarlı bir istinad olduğu üçün dilim ayrılır.
        // Geri qaytarılan göstərici təhlükəsizdir, çünki `SliceIndex`-in imlaları buna zəmanət verməlidir.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Təhlükəsizlik yoxlamalarını atlayaraq başqa bir simli dilimdən bir simli dilim yaradır.
    ///
    /// Bu ümumiyyətlə tövsiyə edilmir, ehtiyatla istifadə edin!Təhlükəsiz alternativ üçün [`str`] və [`Index`]-ə baxın.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Bu yeni dilim, `begin` daxil olmaqla `end` xaricində `begin`-dən `end`-ə keçir.
    ///
    /// Bunun əvəzinə dəyişdirilə bilən bir simli dilim almaq üçün [`slice_mut_unchecked`] metoduna baxın.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Bu funksiyanı axtaranlar üç şərtin yerinə yetirilməsindən məsuldurlar:
    ///
    /// * `begin` `end`-dən çox olmamalıdır.
    /// * `begin` və `end` simli dilim içərisində bayt mövqeləri olmalıdır.
    /// * `begin` və `end`, UTF-8 ardıcıllığı hüdudlarında olmalıdır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // TƏHLÜKƏSİZLİK: zəng edən `get_unchecked` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır;
        // `self` etibarlı bir istinad olduğu üçün dilim ayrılır.
        // Geri qaytarılan göstərici təhlükəsizdir, çünki `SliceIndex`-in imlaları buna zəmanət verməlidir.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Təhlükəsizlik yoxlamalarını atlayaraq başqa bir simli dilimdən bir simli dilim yaradır.
    /// Bu ümumiyyətlə tövsiyə edilmir, ehtiyatla istifadə edin!Təhlükəsiz alternativ üçün [`str`] və [`IndexMut`]-ə baxın.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Bu yeni dilim, `begin` daxil olmaqla `end` xaricində `begin`-dən `end`-ə keçir.
    ///
    /// Əvəzində dəyişməz simli dilim almaq üçün [`slice_unchecked`] metoduna baxın.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Bu funksiyanı axtaranlar üç şərtin yerinə yetirilməsindən məsuldurlar:
    ///
    /// * `begin` `end`-dən çox olmamalıdır.
    /// * `begin` və `end` simli dilim içərisində bayt mövqeləri olmalıdır.
    /// * `begin` və `end`, UTF-8 ardıcıllığı hüdudlarında olmalıdır.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // TƏHLÜKƏSİZLİK: zəng edən `get_unchecked_mut` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır;
        // `self` etibarlı bir istinad olduğu üçün dilim ayrılır.
        // Geri qaytarılan göstərici təhlükəsizdir, çünki `SliceIndex`-in imlaları buna zəmanət verməlidir.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Bir sətir dilimini indeksdə ikiyə bölün.
    ///
    /// Arqument, `mid`, sətrin başlanğıcından bir bayt ofset olmalıdır.
    /// Həm də bir UTF-8 kod nöqtəsinin sərhədində olmalıdır.
    ///
    /// Geri dönən iki dilim simli dilimin başlanğıcından `mid`-ə, `mid`-dən isə simli dilimin sonuna qədər davam edir.
    ///
    /// Bunun əvəzinə dəyişdirilə bilən simli dilimlər əldə etmək üçün [`split_at_mut`] metoduna baxın.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// `mid` bir UTF-8 kod nöqtəsi sərhədində deyilsə və ya simli dilimin son kod nöqtəsinin sonundan keçibsə Panics.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary, indeksin [0, .len()]
        if self.is_char_boundary(mid) {
            // TƏHLÜKƏSİZLİK: yalnız `mid`-in bir sərhəddə olduğunu yoxladı.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Bir dəyişkən simli dilimi indeksdə ikiyə bölün.
    ///
    /// Arqument, `mid`, sətrin başlanğıcından bir bayt ofset olmalıdır.
    /// Həm də bir UTF-8 kod nöqtəsinin sərhədində olmalıdır.
    ///
    /// Geri dönən iki dilim simli dilimin başlanğıcından `mid`-ə, `mid`-dən isə simli dilimin sonuna qədər davam edir.
    ///
    /// Bunun əvəzinə dəyişilməz simli dilimlər əldə etmək üçün [`split_at`] metoduna baxın.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// `mid` bir UTF-8 kod nöqtəsi sərhədində deyilsə və ya simli dilimin son kod nöqtəsinin sonundan keçibsə Panics.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary, indeksin [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // TƏHLÜKƏSİZLİK: yalnız `mid`-in bir sərhəddə olduğunu yoxladı.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Bir simli dilimin [`char`] ləri üzərində təkrarlayıcı qaytarır.
    ///
    /// Simli dilim etibarlı UTF-8-dən ibarət olduğundan [`char`]-dən bir simli dilimdən təkrarlaya bilərik.
    /// Bu metod belə bir iteratoru qaytarır.
    ///
    /// [`char`]-nin Unicode skaler dəyərini təmsil etdiyini və 'character'-nin nə olduğuna dair fikirlərinizə uyğun olmaya biləcəyini xatırlamaq vacibdir.
    ///
    /// Qrafem qrupları üzərində təkrarlama əslində istədiyiniz ola bilər.
    /// Bu funksiya Rust-nin standart kitabxanası tərəfindən təmin edilmir, bunun əvəzinə crates.io yoxlayın.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Unutmayın, ['char`] simvollarla əlaqəli intuisiyanızla uyğun olmaya bilər:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' deyil
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Bir simli dilimin [`char`] lərinin üstündəki iteratoru və onların mövqelərini qaytarır.
    ///
    /// Simli dilim etibarlı UTF-8-dən ibarət olduğundan [`char`]-dən bir simli dilimdən təkrarlaya bilərik.
    /// Bu metod həm bu [`char`] lərin, həm də bayt mövqelərinin bir iteratorunu qaytarır.
    ///
    /// Yineleyicidən kanallar verilir.Mövqe birinci, [`char`] ikinci.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Unutmayın, ['char`] simvollarla əlaqəli intuisiyanızla uyğun olmaya bilər:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // deyil (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // Burada 3-ə diqqət yetirin, son xarakter iki bayt götürdü
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Bir simli dilimin baytları üzərində bir iterator.
    ///
    /// Simli dilim bayt ardıcıllığından ibarət olduğu üçün simli dilimdən bayt-təkrar təkrarlaya bilərik.
    /// Bu metod belə bir iteratoru qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Bir boşluq dilimini boşluqla bölür.
    ///
    /// Qaytarılmış təkrarlayıcı, istənilən miqdarda boşluqla ayrılmış, orijinal simli dilimin alt dilimləri olan sətir dilimlərini qaytaracaqdır.
    ///
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` şərtlərinə görə müəyyən edilir.
    /// Bunun əvəzinə yalnız ASCII boşluqda bölmək istəyirsinizsə, [`split_ascii_whitespace`] istifadə edin.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Bütün boşluqlar nəzərə alınır:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Bir simli dilimi ASCII boşluğuna bölür.
    ///
    /// Geri qaytarılmış təkrarlayıcı, hər hansı bir miqdarda ASCII boşluğu ilə ayrılmış, orijinal simli dilimin alt dilimləri olan sətir dilimlərini qaytaracaqdır.
    ///
    ///
    /// Bunun əvəzinə Unicode `Whitespace` ilə bölmək üçün [`split_whitespace`] istifadə edin.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Hər növ ASCII boşluğu hesab olunur:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Simli sətirlərin üstündəki sətir dilimləri kimi bir iterator.
    ///
    /// Xətlər ya yeni bir xətt (`\n`), ya da (`\r\n`) xəttli bir daşıyıcı geri qayıtmaqla başa çatır.
    ///
    /// Son sətir bitmə isteğe bağlıdır.
    /// Son bir sətir sonu ilə bitən bir sətir, başqa bir şəkildə eyni sətirlə eyni sətirləri son sətir bitmədən qaytaracaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Son sətir bitməli deyil:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Bir simli xətlərin üstündə bir iterator.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 olaraq kodlanmış sətrin üzərində `u16` təkrarlayıcıını qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Verilən naxış bu sətir diliminin alt diliminə uyğun gəlsə `true` qaytarır.
    ///
    /// Olmazsa `false` qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Verilən naxış bu sətir diliminin bir prefiksi ilə uyğun gəlsə `true` qaytarır.
    ///
    /// Olmazsa `false` qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Verilən naxış bu sətir diliminin bir şəkilçisinə uyğun gəlsə `true` qaytarır.
    ///
    /// Olmazsa `false` qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Nümunəyə uyğun bu sətir diliminin ilk simvolunun bayt indeksini qaytarır.
    ///
    /// Desen uyğun gəlmirsə [`None`] qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Nöqtəsiz stil və bağlamalardan istifadə edərək daha mürəkkəb naxışlar:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Nümunəni tapmaq:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Bu sətir dilimindəki nümunənin ən sağdakı uyğunluğunun ilk simvolu üçün bayt indeksini qaytarır.
    ///
    /// Desen uyğun gəlmirsə [`None`] qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Bağlanan daha mürəkkəb naxışlar:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Nümunəni tapmaq:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Bu simli dilimin alt sətirləri üzərində bir naxışla uyğunlaşdırılmış simvollarla ayrılmış bir iterator.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Nümunə tərs axtarışa imkan verərsə və forward/reverse axtarışı eyni elementləri verərsə, qaytarılmış iterator [`DoubleEndedIterator`] olacaqdır.
    /// Bu, məsələn, [`char`] üçün doğrudur, lakin `&str` üçün deyil.
    ///
    /// Nümunə tərs axtarışa imkan verirsə, lakin nəticələri irəli axtarışdan fərqli ola bilərsə, [`rsplit`] metodundan istifadə edilə bilər.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Nümunə bir dilim işarəsidirsə, hər hansı bir simvolun meydana çıxmasına bölün:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Bağlanmadan istifadə edərək daha mürəkkəb bir model:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Bir sətirdə bir-birinə bitişik ayırıcılar varsa, nəticədə boş sətirlərlə başa çatacaqsınız:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Bitişik ayırıcılar boş sətirlə ayrılır.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Bir simlin başlanğıcında və ya sonunda olan ayırıcılar boş simlərlə qonşu olur.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Boş simli ayırıcı kimi istifadə edildikdə, simlin əvvəlində və sonunda simvoldakı hər bir simvolu ayırır.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Bitişik ayırıcılar boşluq ayırıcı kimi istifadə edildikdə ehtimal olunan təəccüblü davranışa səbəb ola bilər.Bu kod düzgündür:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ sizə verir:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Bu davranış üçün [`split_whitespace`] istifadə edin.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Bu simli dilimin alt sətirləri üzərində bir naxışla uyğunlaşdırılmış simvollarla ayrılmış bir iterator.
    /// `split` tərəfindən istehsal olunan təkrarlayıcıdan fərqli olaraq, `split_inclusive` uyğunlaşan hissəni alt telin terminatoru olaraq qoyur.
    ///
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Sətrin son elementi uyğun gəlsə, həmin element əvvəlki alt sətrin sonlandırıcısı hesab ediləcəkdir.
    /// Bu alt sətir təkrarlayıcı tərəfindən qaytarılmış son maddə olacaqdır.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Verilən simli dilimin alt sətirləri üzərində bir naxışla uyğunlaşdırılmış və tərs qaydada verilmiş simvollarla ayrılan təkrarlayıcı.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Qaytarılmış təkrarlayıcı, nümunənin tərs bir axtarışı dəstəkləməsini tələb edir və forward/reverse axtarışı eyni elementləri verərsə [`DoubleEndedIterator`] olacaqdır.
    ///
    ///
    /// Öndən təkrarlamaq üçün [`split`] metodundan istifadə edilə bilər.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Bağlanmadan istifadə edərək daha mürəkkəb bir model:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Nümunə ilə uyğunlaşdırılmış simvollarla ayrılmış verilmiş sətir diliminin alt sətirləri üzərində bir iterator.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Boş olduqda arxa alt sətrin atlandığı istisna olmaqla, [`split`]-ə bərabərdir.
    ///
    /// [`split`]: str::split
    ///
    /// Bu metod bir nümunə ilə _separated_ deyil, _terminated_ olan simli məlumatlar üçün istifadə edilə bilər.
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Nümunə tərs axtarışa imkan verərsə və forward/reverse axtarışı eyni elementləri verərsə, qaytarılmış iterator [`DoubleEndedIterator`] olacaqdır.
    /// Bu, məsələn, [`char`] üçün doğrudur, lakin `&str` üçün deyil.
    ///
    /// Nümunə tərs axtarışa imkan verirsə, lakin nəticələri irəli axtarışdan fərqli ola bilərsə, [`rsplit_terminator`] metodundan istifadə edilə bilər.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` alt sətirləri üzərində bir naxışla uyğunlaşdırılmış və tərs qaydada verilmiş simvollarla ayrılan təkrarlayıcı.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Boş olduqda arxa alt sətrin atlandığı istisna olmaqla, [`split`]-ə bərabərdir.
    ///
    /// [`split`]: str::split
    ///
    /// Bu metod bir nümunə ilə _separated_ deyil, _terminated_ olan simli məlumatlar üçün istifadə edilə bilər.
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Qaytarılmış təkrarlayıcı, nümunənin tərs bir axtarışı dəstəkləməsini tələb edir və forward/reverse axtarışı eyni elementləri verərsə ikiqat başa çatacaqdır.
    ///
    ///
    /// Öndən təkrarlamaq üçün [`split_terminator`] metodundan istifadə edilə bilər.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Verilən simli dilimin alt sətirləri üzərində, bir nümunə ilə ayrılmış, ən çox `n` maddəni qaytarmağı məhdudlaşdıran bir iterator.
    ///
    /// `n` alt sətirləri qaytarılsa, son alt sətir (`n`-ci sətir) sətrin qalan hissəsini ehtiva edəcəkdir.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Geri dönən təkrarlayıcı iki dəfə bitməyəcək, çünki dəstəkləmək səmərəli deyil.
    ///
    /// Nümunə tərs bir axtarışa imkan verirsə, [`rsplitn`] metodundan istifadə edilə bilər.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Bağlanmadan istifadə edərək daha mürəkkəb bir model:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Bu simli dilimin alt sətirləri üzərində simli ucundan başlayaraq bir naxışla ayrılmış təkrarlayıcı, ən çox `n` maddənin qayıtması ilə məhdudlaşdı.
    ///
    ///
    /// `n` alt sətirləri qaytarılsa, son alt sətir (`n`-ci sətir) sətrin qalan hissəsini ehtiva edəcəkdir.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Geri dönən təkrarlayıcı iki dəfə bitməyəcək, çünki dəstəkləmək səmərəli deyil.
    ///
    /// Ön hissədən ayrılma üçün [`splitn`] metodundan istifadə edilə bilər.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Bağlanmadan istifadə edərək daha mürəkkəb bir model:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Sətri göstərilən ayrıcının ilk meydana çıxmasına ayırır və ayrıcısından əvvəl prefiksini, ayırıcıdan sonra şəkilçisini qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Sətri göstərilən ayrıcının son meydana gəlməsinə ayırır və ayrıcısından əvvəl prefiksini, ayrıcısından sonra şəkilçisini qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Verilən simli dilim içərisindəki bir nümunənin ayrılmış uyğunluqları üzərində bir iterator.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Nümunə tərs axtarışa imkan verərsə və forward/reverse axtarışı eyni elementləri verərsə, qaytarılmış iterator [`DoubleEndedIterator`] olacaqdır.
    /// Bu, məsələn, [`char`] üçün doğrudur, lakin `&str` üçün deyil.
    ///
    /// Nümunə tərs axtarışa imkan verirsə, lakin nəticələri irəli axtarışdan fərqli ola bilərsə, [`rmatches`] metodundan istifadə edilə bilər.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Bu simli dilim içərisindəki bir nümunənin ayrılmış matçları üzərində bir təkrarlayıcı, tərs qaydada verildi.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Qaytarılmış təkrarlayıcı, nümunənin tərs bir axtarışı dəstəkləməsini tələb edir və forward/reverse axtarışı eyni elementləri verərsə [`DoubleEndedIterator`] olacaqdır.
    ///
    ///
    /// Öndən təkrarlamaq üçün [`matches`] metodundan istifadə edilə bilər.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Bu simli dilim içərisindəki bir nümunənin ayrılmış qarışıqları üzərində bir iterator və eyni zamanda matçın başladığı indeks.
    ///
    /// `pat` arasındakı `pat`-nin üst-üstə düşdüyü matçlar üçün yalnız ilk matça uyğun olan indekslər qaytarılır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Nümunə tərs axtarışa imkan verərsə və forward/reverse axtarışı eyni elementləri verərsə, qaytarılmış iterator [`DoubleEndedIterator`] olacaqdır.
    /// Bu, məsələn, [`char`] üçün doğrudur, lakin `&str` üçün deyil.
    ///
    /// Nümunə tərs axtarışa imkan verirsə, lakin nəticələri irəli axtarışdan fərqli ola bilərsə, [`rmatch_indices`] metodundan istifadə edilə bilər.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // yalnız ilk `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` içərisindəki bir parçanın ayrılmış qarşılaşmalarının üzərində bir iterator, matçın göstəricisi ilə birlikdə tərs qaydada nəticə verdi.
    ///
    /// `self` içərisindəki üst-üstə düşən `pat` matçları üçün yalnız son matça uyğun olan indekslər qaytarılır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Təkrarlayıcı davranış
    ///
    /// Qaytarılmış təkrarlayıcı, nümunənin tərs bir axtarışı dəstəkləməsini tələb edir və forward/reverse axtarışı eyni elementləri verərsə [`DoubleEndedIterator`] olacaqdır.
    ///
    ///
    /// Öndən təkrarlamaq üçün [`match_indices`] metodundan istifadə edilə bilər.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // yalnız son `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Boşluq çıxarılan və arxada qalan bir simli dilim qaytarır.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` şərtlərinə görə müəyyən edilir.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Ön boşluq silinmiş bir simli dilim qaytarır.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` şərtlərinə görə müəyyən edilir.
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// `start` bu kontekstdə həmin bayt sətirinin ilk mövqeyi deməkdir;İngilis və ya Rus dili kimi soldan sağa bir dil üçün bu, soldan və ərəb və ya ibrani kimi sağdan sola dillər üçün sağ tərəf olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Aradakı boşluq silinmiş bir simli dilim qaytarır.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` şərtlərinə görə müəyyən edilir.
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// `end` bu kontekstdə həmin bayt sətirinin son vəziyyəti deməkdir;İngilis və ya Rus dili kimi bir soldan sağa bir dil üçün bu sağ tərəf olacaq və ərəb və ya İbrani kimi sağdan sola dillər üçün bu sol tərəf olacaq.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Ön boşluq silinmiş bir simli dilim qaytarır.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` şərtlərinə görə müəyyən edilir.
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// 'Left' bu kontekstdə həmin bayt sətirinin ilk mövqeyi deməkdir;'soldan sağa' deyil, 'sağdan sola' olan ərəb və ya ibrani dili üçün bu, sol deyil, _right_ tərəfi olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Aradakı boşluq silinmiş bir simli dilim qaytarır.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` şərtlərinə görə müəyyən edilir.
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// 'Right' bu kontekstdə həmin bayt sətirinin son vəziyyəti deməkdir;ərəb və ya ibrani kimi 'soldan sağa' deyil 'sağdan sola' olan bir dil üçün bu, sağ deyil, _left_ tərəfi olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Dəfələrlə silinmiş bir naxışla uyğun gələn bütün önək və şəkilçilərlə bir simli dilim qaytarır.
    ///
    /// [pattern] bir [`char`], [`char`] s dilimi və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Bağlanmadan istifadə edərək daha mürəkkəb bir model:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Ən erkən bilinən matçı xatırlayın, aşağıda düzəldin
            // son matç fərqlidir
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // TƏHLÜKƏSİZLİK: `Searcher`-nin etibarlı indeksləri qaytardığı bilinir.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Bir dəfələrlə silinmiş bir naxışla uyğun gələn bütün prefikslərlə bir simli dilim qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// `start` bu kontekstdə həmin bayt sətirinin ilk mövqeyi deməkdir;İngilis və ya Rus dili kimi soldan sağa bir dil üçün bu, soldan və ərəb və ya ibrani kimi sağdan sola dillər üçün sağ tərəf olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // TƏHLÜKƏSİZLİK: `Searcher`-nin etibarlı indeksləri qaytardığı bilinir.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Sökülən prefiksli bir simli dilim qaytarır.
    ///
    /// Sətir `prefix` naxışından başlayırsa, `Some` bükülmüş alt sətri prefiksdən sonra qaytarır.
    /// `trim_start_matches`-dən fərqli olaraq, bu metod əvvəlcədən düz bir dəfə silinir.
    ///
    /// Sətir `prefix` ilə başlamazsa, `None` qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Silinmiş şəkilçi ilə bir dilim dilimini qaytarır.
    ///
    /// Sətir `suffix` naxışı ilə bitərsə, alt sətri `Some`-ə bükülmüş şəkilçidən əvvəl qaytarır.
    /// `trim_end_matches`-dən fərqli olaraq bu metod şəkilçini tam bir dəfə silir.
    ///
    /// Sətir `suffix` ilə bitmirsə, `None` qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Bir dəfələrlə silinmiş bir naxışa uyğun gələn bütün şəkilçilərlə bir simli dilim qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// `end` bu kontekstdə həmin bayt sətirinin son vəziyyəti deməkdir;İngilis və ya Rus dili kimi bir soldan sağa bir dil üçün bu sağ tərəf olacaq və ərəb və ya İbrani kimi sağdan sola dillər üçün bu sol tərəf olacaq.
    ///
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Bağlanmadan istifadə edərək daha mürəkkəb bir model:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // TƏHLÜKƏSİZLİK: `Searcher`-nin etibarlı indeksləri qaytardığı bilinir.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Bir dəfələrlə silinmiş bir naxışla uyğun gələn bütün prefikslərlə bir simli dilim qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// 'Left' bu kontekstdə həmin bayt sətirinin ilk mövqeyi deməkdir;'soldan sağa' deyil, 'sağdan sola' olan ərəb və ya ibrani dili üçün bu, sol deyil, _right_ tərəfi olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Bir dəfələrlə silinmiş bir naxışa uyğun gələn bütün şəkilçilərlə bir simli dilim qaytarır.
    ///
    /// [pattern] bir `&str`, [`char`], bir dilim [`char`] s və ya bir xarakterin uyğun olub olmadığını təyin edən bir funksiya və ya bağlanma ola bilər.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Mətn istiqaməti
    ///
    /// Sətir bayt ardıcıllığıdır.
    /// 'Right' bu kontekstdə həmin bayt sətirinin son vəziyyəti deməkdir;ərəb və ya ibrani kimi 'soldan sağa' deyil 'sağdan sola' olan bir dil üçün bu, sağ deyil, _left_ tərəfi olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Sadə nümunələr:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Bağlanmadan istifadə edərək daha mürəkkəb bir model:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Bu simli dilimi başqa bir növə ayırır.
    ///
    /// `parse` çox ümumi olduğundan tip çıxarma ilə problem yarada bilər.
    /// Beləliklə, `parse`, 'turbofish' olaraq sevilən sintaksisini görəcəyiniz bir neçə dəfə biridir: `::<>`.
    ///
    /// Bu nəticə çıxarmaq alqoritminin hansı növü təhlil etməyə çalışdığınızı konkret anlamasına kömək edir.
    ///
    /// `parse` [`FromStr`] trait tətbiq edən hər hansı bir növü təhlil edə bilər.
    ///

    /// # Errors
    ///
    /// Bu simli dilimi istənilən növə ayırmaq mümkün deyilsə, [`Err`] qaytaracaq.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Əsas istifadə
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four`-yə izahat vermək əvəzinə 'turbofish'-dən istifadə:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Ayrışmaq alınmadı:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Bu sətirdəki bütün simvolların ASCII aralığında olub olmadığını yoxlayır.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Hər bir bayta burada xarakter kimi baxa bilərik: bütün çox baytlı simvollar ascii aralığında olmayan bir baytla başlayır, ona görə də orada dayanacağıq.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// İki sətrin ASCII halda həssas bir uyğunluq olduğunu yoxlayır.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ilə eyni, ancaq müvəqqəti olaraq ayrılmadan və kopyalanmadan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Bu sətri ASCII böyük hərflə əvəzinə çevirir.
    ///
    /// 'a'-'z' arasında ASCII hərfləri 'A'-'Z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Mövcud dəyərini dəyişdirmədən yeni bir üst səviyyəli dəyəri qaytarmaq üçün [`to_ascii_uppercase()`] istifadə edin.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // TƏHLÜKƏSİZLİK: təhlükəsizdir, çünki iki növü eyni tərtibata keçiririk.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Bu sətri ASCII kiçik hərflə əvəzinə çevirir.
    ///
    /// 'A'-'Z' arasında ASCII hərfləri 'a'-'z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Mövcud dəyərini dəyişdirmədən yeni kiçik bir dəyər qaytarmaq üçün [`to_ascii_lowercase()`] istifadə edin.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // TƏHLÜKƏSİZLİK: təhlükəsizdir, çünki iki növü eyni tərtibata keçiririk.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// [`char::escape_debug`] ilə `self`-də hər bir xaricdən qaçan bir iteratoru qaytarın.
    ///
    ///
    /// Note: yalnız simli başlayan genişləndirilmiş qrafem kod nöqtələrindən qaçacaq.
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// [`char::escape_default`] ilə `self`-də hər qrafikdən qaçan bir iteratoru qaytarın.
    ///
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// [`char::escape_unicode`] ilə `self`-də hər qrafikdən qaçan bir iteratoru qaytarın.
    ///
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Boş bir str yaradır
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Boş dəyişdirilə bilən bir str yaradır
    #[inline]
    fn default() -> Self {
        // TƏHLÜKƏSİZLİK: Boş simli UTF-8 etibarlıdır.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Adı, klonlaşdırıla bilən bir fn növü
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // TƏHLÜKƏSİZLİK: təhlükəsiz deyil
        unsafe { from_utf8_unchecked(bytes) }
    };
}