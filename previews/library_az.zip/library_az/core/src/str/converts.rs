//! Bayt dilimindən `str` yaratmaq yolları.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Bayt dilimini simli dilimə çevirir.
///
/// ([`&str`]) simli dilim ([`u8`]) baytdan, ([`&[u8]`][byteslice]) bayt dilim baytdan hazırlanır, ona görə bu funksiya ikisi arasında çevrilir.
/// Bütün bayt dilimləri etibarlı sətir dilimləri deyil, lakin: [`&str`] bunun UTF-8 etibarlı olmasını tələb edir.
/// `from_utf8()` baytların UTF-8-nin etibarlı olmasını yoxlayır və sonra çevirmə edir.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Bayt diliminin UTF-8-nin etibarlı olduğuna əminsəniz və etibarlılıq yoxlanışının yuxarı xərclərini çəkmək istəmirsinizsə, bu funksiyanın eyni davranışa sahib olan, lakin çeki atlayan təhlükəli bir versiyası [`from_utf8_unchecked`] var.
///
///
/// Bir `&str` əvəzinə bir `String` ehtiyacınız varsa, [`String::from_utf8`][string] düşünün.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Bir `[u8; N]`-i yığmaqla ayırmaq və ondan bir [`&[u8]`][byteslice] götürə bildiyiniz üçün bu funksiya yığın ayrılmış simli olmağın bir yoludur.Aşağıdakı nümunələr hissəsində bunun bir nümunəsi var.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Dilim UTF-8 deyilsə, verilən dilimin nə üçün UTF-8 olmadığını izah edən `Err` qaytarır.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::str;
///
/// // bəzi baytlar, bir vector-də
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Bu baytların etibarlı olduğunu bilirik, buna görə `unwrap()` istifadə edin.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Yanlış baytlar:
///
/// ```
/// use std::str;
///
/// // bəzi etibarsız baytlar, bir vector-də
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Geri qaytarıla bilən səhv növləri haqqında daha ətraflı məlumat üçün [`Utf8Error`] sənədlərinə baxın.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // yığın ayrılmış bir sıra içərisində bəzi bayt
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Bu baytların etibarlı olduğunu bilirik, buna görə `unwrap()` istifadə edin.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // TƏHLÜKƏSİZLİK: Yalnız doğrulama qaçdı.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Dəyişdirilə bilən bayt dilimini dəyişilə bilən sətir diliminə çevirir.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" dəyişdirilə bilən vector olaraq
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Bu baytların etibarlı olduğunu bildiyimiz üçün `unwrap()` istifadə edə bilərik
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Yanlış baytlar:
///
/// ```
/// use std::str;
///
/// // Dəyişdirilə bilən vector-də bəzi etibarsız baytlar
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Geri qaytarıla bilən səhv növləri haqqında daha ətraflı məlumat üçün [`Utf8Error`] sənədlərinə baxın.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // TƏHLÜKƏSİZLİK: Yalnız doğrulama qaçdı.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Sətrin etibarlı UTF-8 olduğunu yoxlamadan bayt dilimini simli dilimə çevirir.
///
/// Daha çox məlumat üçün təhlükəsiz versiyaya, [`from_utf8`] baxın.
///
/// # Safety
///
/// Bu funksiya təhlükəlidir, çünki ona ötürülən baytların UTF-8 etibarlı olduğunu yoxlamır.
/// Bu məhdudiyyət pozulursa, Rust-nin qalan hissəsi [`&str`] 'lərin UTF-8 etibarlı olduğunu düşündüyü üçün təyin olunmamış davranış yaranır.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::str;
///
/// // bəzi baytlar, bir vector-də
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // TƏHLÜKƏSİZLİK: zəng edən `v` baytlarının UTF-8 etibarlı olmasına zəmanət verməlidir.
    // Eyni düzeni olan `&str` və `&[u8]`-ə də etibar edir.
    unsafe { mem::transmute(v) }
}

/// Sətrin etibarlı UTF-8 olduğunu yoxlamadan bir dilim baytı sətir diliminə çevirir;dəyişdirilə bilən versiya.
///
///
/// Daha çox məlumat üçün dəyişməz versiyaya, [`from_utf8_unchecked()`]-ə baxın.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // TƏHLÜKƏSİZLİK: arayan baytların `v` olduğuna zəmanət verməlidir
    // etibarlı UTF-8, beləliklə `*mut str`-ə aktarma təhlükəsizdir.
    // Həm də, göstəricinin ayrılması təhlükəsizdir, çünki bu göstərici yazmaq üçün etibarlı olduğu zəmanət edilən bir istinaddan gəlir.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}