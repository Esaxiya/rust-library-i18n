//! Yaddaşla əlaqəli əsas funksiyalar.
//!
//! Bu modul tiplərin ölçüsünü və düzəldilməsini soruşmaq, yaddaşın işə salınması və manipulyasiya edilməsi üçün funksiyaları ehtiva edir.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Dağıdıcısını **işə salmadan** dəyəri haqqında mülkiyyət və "forgets" alır.
///
/// Yığın yaddaş və ya bir fayl sapı kimi dəyərin idarə olunduğu bütün mənbələr, əlçatmaz vəziyyətdə əbədi qalacaqdır.Bununla birlikdə, bu yaddaşa işarə edənlərin qüvvədə qalacağına zəmanət vermir.
///
/// * Yaddaşdan sızdırmaq istəyirsinizsə, [`Box::leak`]-ə baxın.
/// * Yaddaşa xam bir göstərici əldə etmək istəyirsinizsə, [`Box::into_raw`]-ə baxın.
/// * Dağıdıcısını işlədərək bir dəyəri düzgün şəkildə atmaq istəyirsinizsə, [`mem::drop`]-ə baxın.
///
/// # Safety
///
/// `forget` `unsafe` olaraq qeyd edilmir, çünki Rust-in təhlükəsizlik zəmanətləri destruktorların hər zaman çalışacağı zəmanəti daxil etmir.
/// Məsələn, bir proqram [`Rc`][rc] istifadə edərək bir istinad dövrü yarada və ya destruktorlar olmadan çıxmaq üçün [`process::exit`][exit]-yə zəng edə bilər.
/// Beləliklə, `mem::forget`-in təhlükəsiz koddan istifadəyə verilməsi Rust-in təhlükəsizlik zəmanətlərini əsaslı şəkildə dəyişdirmir.
///
/// Yaddaş və ya I/O obyektləri kimi mənbələrin sızması ümumiyyətlə arzuolunmazdır.
/// Ehtiyac FFI və ya təhlükəli kod üçün bəzi ixtisaslaşdırılmış istifadə hallarında ortaya çıxır, lakin buna baxmayaraq, [`ManuallyDrop`] tipik olaraq seçilir.
///
/// Bir dəyəri unutmağa icazə verildiyi üçün yazdığınız hər hansı bir `unsafe` kodu bu ehtimala imkan verməlidir.Bir dəyəri qaytara bilməzsiniz və zəng edən şəxsin dəyər məhv edicisini mütləq işlədəcəyini gözləyə bilərsiniz.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`-in kanonik təhlükəsiz istifadəsi, `Drop` trait tərəfindən tətbiq olunan bir dəyərin məhv edicisini atlamaqdır.Məsələn, bu bir `File` sızdıracaq, yəni
/// dəyişənin götürdüyü boşluğu geri qaytarın, lakin heç vaxt əsas sistem mənbəyini bağlamayın:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Bu, əsas mənbənin mülkiyyəti əvvəllər Rust xaricindəki kodlara köçürüldükdə faydalıdır, məsələn xam fayl təsvirini C koduna ötürməklə.
///
/// # `ManuallyDrop` ilə əlaqələr
///
/// `mem::forget`*yaddaş* sahibliyini köçürmək üçün də istifadə edilə bilsə də, bunu etmək səhvdir.
/// [`ManuallyDrop`] əvəzinə istifadə edilməlidir.Məsələn, bu kodu nəzərdən keçirin:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` içeriğini istifadə edərək bir `String` yaradın
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` sızdır, çünki yaddaşı indi `s` tərəfindən idarə olunur
/// mem::forget(v);  // XATA, v etibarsızdır və bir funksiyaya ötürülməməlidir
/// assert_eq!(s, "Az");
/// // `s` dolayı olaraq yıxılır və yaddaşı bölüşdürülür.
/// ```
///
/// Yuxarıdakı nümunə ilə iki məsələ var:
///
/// * `String` quruluşu ilə `mem::forget()` çağırışı arasında daha çox kod əlavə olunarsa, eyni panic ikiqat sərbəstliyə səbəb olardı, çünki eyni yaddaş həm `v`, həm də `s` tərəfindən idarə olunur.
/// * `v.as_mut_ptr()`-i çağırdıqdan və məlumatların sahibliyini `s`-ə ötürdükdən sonra `v` dəyəri etibarsızdır.
/// Bir dəyər `mem::forget`-ə yeni köçürüldükdə belə (onu yoxlamayacaq), bəzi növlərin dəyərlərində sərt tələblər var ki, onları asma zamanı və ya artıq sahib olmur.
/// Yanlış dəyərləri hər hansı bir şəkildə istifadə etmək, bunlara ötürmək və ya funksiyalardan geri qaytarmaq da daxil olmaqla, təyin olunmamış bir davranış təşkil edir və tərtibçinin verdiyi fərziyyələri poza bilər.
///
/// `ManuallyDrop`-ə keçid hər iki məsələnin qarşısını alır:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v`-ni xammal hissələrinə ayırmazdan əvvəl onun düşməməsinə əmin olun!
/////
/// let mut v = ManuallyDrop::new(v);
/// // İndi `v` sökün.Bu əməliyyatlar panic edə bilməz, buna görə bir sızıntı ola bilməz.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Nəhayət, bir `String` düzəldin.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` dolayı olaraq yıxılır və yaddaşı bölüşdürülür.
/// ```
///
/// `ManuallyDrop` möhkəm bir şəkildə ikili sərbəstliyi qarşısını alır, çünki başqa bir şey etməzdən əvvəl `v`s destruktorunu söndürürük.
/// `mem::forget()` buna imkan vermir, çünki arqumentini sərf edir və bizi yalnız `v`-dən lazım olan hər hansı bir şeyi çıxardıqdan sonra çağırmağa məcbur edir.
/// `ManuallyDrop` qurulması ilə simli qurma arasında bir panic tətbiq olunsa belə (göstərildiyi kimi kodda baş verə bilməz), sızma ilə nəticələnəcək və ikiqat sərbəst olmaz.
/// Başqa sözlə, `ManuallyDrop` (cüt) düşmə tərəfində səhv yerinə sızma tərəfində səhvdir.
///
/// Ayrıca, `ManuallyDrop`, mülkiyyət hüququnu `s`-ə köçürdükdən sonra "touch" `v`-ə sahib olmağımızı maneə törədir-`v` ilə məhv edəni məhv etmədən atmaq üçün qarşılıqlı əlaqənin son mərhələsi tamamilə qaçınılır.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] kimi, eyni zamanda ölçüsüz dəyərləri qəbul edir.
///
/// Bu funksiya, `unsized_locals` xüsusiyyəti sabitləşdikdə çıxarılması nəzərdə tutulmuş bir parıldamaqdır.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Bir növün ölçüsünü baytda qaytarır.
///
/// Daha spesifik olaraq, bu, hizalama doldurma da daxil olmaqla həmin maddə növü olan bir sıra içərisindəki ardıcıl elementlər arasındakı bayt əvəzliyi.
///
/// Beləliklə, istənilən `T` və `n` uzunluğu üçün `[T; n]` `n * size_of::<T>()` ölçüsünə malikdir.
///
/// Ümumiyyətlə, bir növün ölçüsü derlemeler arasında sabit deyil, ancaq primitivlər kimi spesifik növlərdir.
///
/// Aşağıdakı cədvəldə primitivlərin ölçüsü verilmişdir.
///
/// Yazın |ölçüsü_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Bundan əlavə, `usize` və `isize` eyni ölçüyə malikdir.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` və `Option<Box<T>>` tiplərinin hamısı eyni ölçüyə malikdir.
/// `T` ölçülüdürsə, bu növlərin hamısı `usize` ilə eyni ölçüyə malikdir.
///
/// Bir göstəricinin dəyişkənliyi onun ölçüsünü dəyişdirmir.Beləliklə, `&T` və `&mut T` eyni ölçüyə malikdir.
/// Eyni şəkildə `*const T` və `* mut T` üçün.
///
/// # `#[repr(C)]` əşyaların ölçüsü
///
/// Maddələr üçün `C` nümayəndəliyi müəyyən bir tərtibə malikdir.
/// Bu tərtiblə, bütün sahələr sabit bir ölçüyə sahib olduğu müddətdə əşyaların ölçüsü də sabitdir.
///
/// ## Quruluşların ölçüsü
///
/// `structs` üçün ölçü aşağıdakı alqoritmlə təyin olunur.
///
/// Bəyannamə qaydasında sifariş edilən strukturdakı hər bir sahə üçün:
///
/// 1. Sahənin ölçüsünü əlavə edin.
/// 2. Cari ölçünü növbəti sahənin [alignment]-in ən yaxın qatına qədər yuvarlaqlaşdırın.
///
/// Nəhayət, strukturun ölçüsünü [alignment]-in ən yaxın qatına qədər yuvarlaqlaşdırın.
/// Strukturun hizalanması ümumiyyətlə bütün sahələrin ən böyük hizalanmasıdır;bu, `repr(align(N))` istifadəsi ilə dəyişdirilə bilər.
///
/// `C`-dən fərqli olaraq, sıfır ölçülü quruluşlar bir bayta qədər yuvarlaqlaşdırılmır.
///
/// ## Enums ölçüsü
///
/// Diskriminantdan başqa heç bir məlumat daşımayan eynilər, tərtib etdikləri platformadakı C eni ilə eynidir.
///
/// ## Birliklərin ölçüsü
///
/// Birliyin ölçüsü ən böyük sahənin ölçüsüdür.
///
/// `C`-dən fərqli olaraq, sıfır ölçülü birliklər bir bayta qədər yuvarlaqlaşdırılmır.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Bəzi primitivlər
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Bəzi massivlər
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Göstərici ölçüsü bərabərliyi
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` istifadə.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Birinci sahənin ölçüsü 1-dir, buna görə ölçüyə 1 əlavə edin.Ölçü 1-dir.
/// // İkinci sahənin hizalanması 2-dir, dolğu üçün ölçüyə 1 əlavə edin.Ölçü 2-dir.
/// // İkinci sahənin ölçüsü 2-dir, buna görə ölçüyə 2 əlavə edin.Ölçü 4.
/// // Üçüncü sahənin hizalanması 1-dir, dolğunluq üçün ölçüyə 0 əlavə edin.Ölçü 4.
/// // Üçüncü sahənin ölçüsü 1-dir, buna görə ölçüyə 1 əlavə edin.Ölçü 5-dir.
/// // Nəhayət, strukturun hizalanması 2-dir (çünki sahələri arasındakı ən böyük hizalama 2-dir), dolum üçün ölçüyə 1 əlavə edin.
/// // Ölçü 6-dır.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple konstruksiyaları eyni qaydalara riayət edir.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Nəzərə alın ki, sahələrin yenidən sıralanması ölçünü aşağı sala bilər.
/// // Hər iki doldurma baytını `second`-dən əvvəl `third` qoyaraq çıxara bilərik.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Birliyin ölçüsü ən böyük sahənin ölçüsüdür.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Bayt şəklində göstərilən dəyərin ölçüsünü qaytarır.
///
/// Bu ümumiyyətlə `size_of::<T>()` ilə eynidır.
/// Bununla birlikdə, `T`* * statik olaraq bilinən bir ölçüsü olmadıqda, məsələn, bir dilim [`[T]`][slice] və ya [trait object] olduqda, dinamik olaraq bilinən ölçüsü əldə etmək üçün `size_of_val` istifadə edilə bilər.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // TƏHLÜKƏSİZLİK: `val` bir istinaddır, ona görə də etibarlı bir xam göstəricidir
    unsafe { intrinsics::size_of_val(val) }
}

/// Bayt şəklində göstərilən dəyərin ölçüsünü qaytarır.
///
/// Bu ümumiyyətlə `size_of::<T>()` ilə eynidır.Bununla birlikdə, `T`* * statik olaraq bilinən bir ölçüsü olmadıqda, məsələn, bir dilim [`[T]`][slice] və ya [trait object] olduqda, dinamik olaraq bilinən ölçüsü əldə etmək üçün `size_of_val_raw` istifadə edilə bilər.
///
/// # Safety
///
/// Bu funksiya yalnız aşağıdakı şərtlər olduqda zəng etmək üçün təhlükəsizdir:
///
/// - `T` `Sized`-dirsə, bu funksiya hər zaman zəng etmək üçün təhlükəsizdir.
/// - `T`-in ölçüsüz quyruğu:
///     - bir [slice], onda dilim quyruğunun uzunluğu başlanğıc edilmiş bir tam olmalıdır və *bütün dəyərin* ölçüsü (dinamik quyruq uzunluğu + statik ölçülü prefiks) `isize`-ə uyğun olmalıdır.
///     - bir [trait object], daha sonra göstəricinin vtable hissəsi ölçüsüz bir məcburetmə ilə əldə edilmiş etibarlı bir vtable-ı göstərməli və *bütün dəyərin* ölçüsü (dinamik quyruq uzunluğu + statik ölçülü prefiks) `isize`-ə uyğun olmalıdır.
///
///     - bir (unstable) [extern type], bu funksiyanı çağırmaq həmişə təhlükəsizdir, ancaq xarici tipin düzeni bilinmədiyi üçün panic və ya başqa bir şəkildə səhv dəyəri qaytara bilər.
///     Xarici tip quyruğu olan bir növə istinad [`size_of_val`] ilə eyni davranışdır.
///     - əks halda mühafizəkar olaraq bu funksiyanı çağırmağa icazə verilmir.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // TƏHLÜKƏSİZLİK: zəng edən şəxs etibarlı bir işarə göstərməlidir
    unsafe { intrinsics::size_of_val(val) }
}

/// Bir növün [ABI] tələb olunan minimum hizalanmasını qaytarır.
///
/// `T` tipli bir dəyərə edilən hər istinad bu sayın çoxluğu olmalıdır.
///
/// Bu, struktur sahələri üçün istifadə edilən hizalamadır.Tercih olunan hizalamadan daha kiçik ola bilər.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val`-nin göstərdiyi dəyər tipinin [ABI] tələb olunan minimum hizalanmasını qaytarır.
///
/// `T` tipli bir dəyərə edilən hər istinad bu sayın çoxluğu olmalıdır.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // TƏHLÜKƏSİZLİK: val bir istinaddır, buna görə də etibarlı bir xam göstəricidir
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Bir növün [ABI] tələb olunan minimum hizalanmasını qaytarır.
///
/// `T` tipli bir dəyərə edilən hər istinad bu sayın çoxluğu olmalıdır.
///
/// Bu, struktur sahələri üçün istifadə edilən hizalamadır.Tercih olunan hizalamadan daha kiçik ola bilər.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val`-nin göstərdiyi dəyər tipinin [ABI] tələb olunan minimum hizalanmasını qaytarır.
///
/// `T` tipli bir dəyərə edilən hər istinad bu sayın çoxluğu olmalıdır.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // TƏHLÜKƏSİZLİK: val bir istinaddır, buna görə də etibarlı bir xam göstəricidir
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val`-nin göstərdiyi dəyər tipinin [ABI] tələb olunan minimum hizalanmasını qaytarır.
///
/// `T` tipli bir dəyərə edilən hər istinad bu sayın çoxluğu olmalıdır.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Bu funksiya yalnız aşağıdakı şərtlər olduqda zəng etmək üçün təhlükəsizdir:
///
/// - `T` `Sized`-dirsə, bu funksiya hər zaman zəng etmək üçün təhlükəsizdir.
/// - `T`-in ölçüsüz quyruğu:
///     - bir [slice], onda dilim quyruğunun uzunluğu başlanğıc edilmiş bir tam olmalıdır və *bütün dəyərin* ölçüsü (dinamik quyruq uzunluğu + statik ölçülü prefiks) `isize`-ə uyğun olmalıdır.
///     - bir [trait object], daha sonra göstəricinin vtable hissəsi ölçüsüz bir məcburetmə ilə əldə edilmiş etibarlı bir vtable-ı göstərməli və *bütün dəyərin* ölçüsü (dinamik quyruq uzunluğu + statik ölçülü prefiks) `isize`-ə uyğun olmalıdır.
///
///     - bir (unstable) [extern type], bu funksiyanı çağırmaq həmişə təhlükəsizdir, ancaq xarici tipin düzeni bilinmədiyi üçün panic və ya başqa bir şəkildə səhv dəyəri qaytara bilər.
///     Xarici tip quyruğu olan bir növə istinad [`align_of_val`] ilə eyni davranışdır.
///     - əks halda mühafizəkar olaraq bu funksiyanı çağırmağa icazə verilmir.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // TƏHLÜKƏSİZLİK: zəng edən şəxs etibarlı bir işarə göstərməlidir
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `T` növünün dəyərlərinin düşməsi vacibdirsə, `true` qaytarır.
///
/// Bu, tamamilə optimallaşdırma ipucu və mühafizəkar şəkildə tətbiq oluna bilər:
/// həqiqətən atılması lazım olmayan növlər üçün `true` qaytara bilər.
/// Hər zaman `true`-i geri qaytarmaq bu funksiyanın etibarlı bir tətbiqi olacaqdır.Lakin bu funksiya həqiqətən `false` qaytararsa, `T`-in düşməsinin heç bir yan təsiri olmadığına əmin ola bilərsiniz.
///
/// Verilərini əl ilə buraxması lazım olan koleksiyonlar kimi aşağı səviyyəli tətbiqlər, məhv edildikdə bütün məzmunu lazımsız yerə atmağa çalışmamaq üçün bu funksiyanı istifadə etməlidir.
///
/// Bu, buraxılış quruluşlarında bir fərq yaratmaya bilər (yan təsirləri olmayan bir döngənin asanlıqla aşkar edildiyi və aradan qaldırıldığı yer), lakin tez-tez ayıklama quruluşları üçün böyük bir qazancdır.
///
/// Qeyd edək ki, [`drop_in_place`] bu yoxlamanı artıq həyata keçirir, buna görə iş yükünüz az sayda [`drop_in_place`] zənginə endirilə bilərsə, bu istifadə etmək lazım deyil.
/// Xüsusilə bir dilim [`drop_in_place`] edə biləcəyinizi və bütün dəyərlər üçün tək bir ehtiyac_drop yoxlamasını edəcəyinizi unutmayın.
///
/// Vec kimi növlər, buna görə `needs_drop`-i açıq şəkildə istifadə etmədən yalnız `drop_in_place(&mut self[..])`.
/// Digər tərəfdən [`HashMap`] kimi növlər dəyərləri bir-bir aşağı salmalı və bu API-dən istifadə etməlidir.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Bir kolleksiyanın `needs_drop`-dən necə istifadə edə biləcəyinə dair bir nümunə:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // məlumatları buraxın
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Tam sıfır bayt nümunəsi ilə təmsil olunan `T` növünün dəyərini qaytarır.
///
/// Bu o deməkdir ki, məsələn, `(u8, u16)`-də doldurma baytı mütləq sıfırlanmır.
///
/// Tam sıfır bayt naxışının bəzi `T` tiplərinin etibarlı bir dəyərini təmsil etdiyinə zəmanət yoxdur.
/// Məsələn, tamamilə sıfır bayt naxışı istinad növləri (`&T`, `&mut T`) və funksiya göstəriciləri üçün etibarlı bir dəyər deyil.
/// Bu tiplərdə `zeroed` istifadə dərhal [undefined behavior][ub]-ə səbəb olur, çünki [the Rust compiler assumes][inv] hər zaman başlanğıc hesab etdiyi dəyişəndə etibarlı bir dəyər var.
///
///
/// Bu, [`MaybeUninit::zeroed().assume_init()`][zeroed] ilə eyni təsirə malikdir.
/// FFI üçün bəzən faydalıdır, lakin ümumiyyətlə qarşısını almaq lazımdır.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Bu funksiyanın düzgün istifadəsi: bir ədədi sıfırla başlatma.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Bu funksiyanın *Yanlış* istifadəsi: bir referansı sıfırla başlatmaq.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Tərifsiz davranış!
/// let _y: fn() = unsafe { mem::zeroed() }; // Və yenidən!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // TƏHLÜKƏSİZLİK: zəng edən bir sıfır dəyərin `T` üçün etibarlı olmasını təmin etməlidir.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Rust-nin normal yaddaş başlanğıcını heç bir şey etmədən `T` tipli bir dəyər istehsal edən kimi göstərərək yoxlayır.
///
/// **Bu funksiya köhnəlmişdir.** Bunun əvəzinə [`MaybeUninit<T>`] istifadə edin.
///
/// Amortizasiyanın səbəbi funksiyanın əsasən düzgün istifadə edilə bilməməsidir: [`MaybeUninit::uninit().assume_init()`][uninit] ilə eyni təsirə malikdir.
///
/// [`assume_init` documentation][assume_init]-in izah etdiyi kimi, [the Rust compiler assumes][inv] dəyərlərin düzgün başlanğıc edildiyini göstərir.
/// Nəticə olaraq, məsələn
/// `mem::uninitialized::<bool>()` mütləq `true` və ya `false` olmayan bir `bool`-i qaytarmaq üçün dərhal təyin olunmayan davranışa səbəb olur.
/// Daha pisi, buraya qayıdan şeylər kimi həqiqətən başlanğıc olunmamış yaddaş, tərtibçinin sabit bir dəyəri olmadığını bilməsi ilə xüsusidir.
/// Bu, dəyişən bir tam tipə sahib olsa belə, bir dəyişkən içində başlanğıc edilməmiş məlumatların olmasını təyin edilməmiş bir davranış halına gətirir.
/// (Diqqət yetirin ki, başlanğıc olunmamış tam ədədlər ətrafında olan qaydalar hələ yekunlaşdırılmayıb, lakin bunlara qədər onlardan qaçınmaq məsləhətdir.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // TƏHLÜKƏSİZLİK: zəng edən şəxs vahid bir dəyərin `T` üçün etibarlı olmasını təmin etməlidir.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Dəyişdirilə bilən iki yerdəki dəyərləri, ikisini deinisallaşdırmadan dəyişdirir.
///
/// * Varsayılan və ya saxta bir dəyərlə dəyişdirmək istəyirsinizsə, [`take`]-ə baxın.
/// * Keçmiş dəyəri qaytararaq keçmiş bir dəyərlə dəyişdirmək istəyirsinizsə, [`replace`]-ə baxın.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // TƏHLÜKƏSİZLİK: xam göstəricilər, hamısını təmin edən təhlükəsiz dəyişkən referanslardan yaradıldı
    // `ptr::swap_nonoverlapping_one`-də məhdudiyyətlər
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest`-i əvvəlki `dest` dəyərini qaytararaq standart `T` dəyəri ilə əvəz edir.
///
/// * İki dəyişənin dəyərlərini dəyişdirmək istəyirsinizsə, [`swap`]-ə baxın.
/// * Varsayılan dəyər əvəzinə ötürülmüş bir dəyərlə əvəz etmək istəyirsinizsə, [`replace`]-ə baxın.
///
/// # Examples
///
/// Sadə bir nümunə:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` bir struktur sahəsini "empty" dəyəri ilə əvəz edərək sahiblik hüququnu əldə etməyə imkan verir.
/// `take` olmadan aşağıdakı kimi problemlərlə qarşılaşa bilərsiniz:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T`-in mütləq [`Clone`] tətbiq etmədiyinə görə `self.buf`-i klonlayaraq sıfırlaya bilməyəcəyini unutmayın.
/// Ancaq `take`, `self.buf`-in orijinal dəyərini `self`-dən ayırmaq üçün istifadə edilə bilər və geri qaytarılmasına imkan verir:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src`-i əvvəlki `dest` dəyərini qaytararaq istinad olunan `dest`-ə keçir.
///
/// Heç bir dəyər düşmür.
///
/// * İki dəyişənin dəyərlərini dəyişdirmək istəyirsinizsə, [`swap`]-ə baxın.
/// * Varsayılan bir dəyər ilə əvəz etmək istəyirsinizsə, [`take`]-ə baxın.
///
/// # Examples
///
/// Sadə bir nümunə:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` bir struktur sahəsini başqa bir dəyərlə əvəz edərək istehlakına imkan verir.
/// `replace` olmadan aşağıdakı kimi problemlərlə qarşılaşa bilərsiniz:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Qeyd edək ki, `T` mütləq [`Clone`] tətbiq etmir, buna görə hərəkətdən qaçmaq üçün `self.buf[i]`-i klonlaya bilmərik.
/// Ancaq `replace`, bu indeksdəki orijinal dəyəri `self`-dən ayırmaq üçün istifadə edilə bilər və bunun qaytarılmasına imkan verir:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // TƏHLÜKƏSİZLİK: `dest`-dən oxuyuruq, ancaq sonra birbaşa `src` yazırıq,
    // köhnə dəyərin təkrarlanmaması üçün.
    // Heç bir şey atılmır və burada heç bir şey panic edə bilməz.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Bir dəyəri atır.
///
/// Bunu, arqumentin [`Drop`][drop] tətbiqini çağıraraq edir.
///
/// Bu, `Copy` tətbiq edən növlər üçün effektiv bir şey etmir, məsələn
/// integers.
/// Belə dəyərlər kopyalanır və _then_ funksiyaya köçürülür, buna görə dəyər bu funksiya çağırışından sonra da davam edir.
///
///
/// Bu funksiya sehr deyil;sözün əsl mənasında
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` funksiyaya köçürüldüyü üçün funksiya qayıtmadan əvvəl avtomatik olaraq düşür.
///
/// [drop]: Drop
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector-ni açıq şəkildə buraxın
/// ```
///
/// [`RefCell`] borc qaydalarını iş vaxtında tətbiq etdiyindən, `drop` bir [`RefCell`] borc azad edə bilər:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // bu yuvadakı dəyişdirilə bilən borcdan imtina edin
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Tamsayılar və [`Copy`] tətbiq edən digər növlər `drop`-dən təsirlənmir.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x`-nin bir nüsxəsi köçürülür və atılır
/// drop(y); // `y`-nin bir nüsxəsi köçürülür və atılır
///
/// println!("x: {}, y: {}", x, y.0); // hələ də mövcuddur
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src`-i `&U` tipli kimi şərh edir və sonra içərisində olan dəyəri dəyişdirmədən `src` oxuyur.
///
/// Bu funksiya, `src` pointerinin `&T`-dən `&U`-ə keçərək `&U`-i oxuyaraq [`size_of::<U>`][size_of] baytları üçün etibarlı olduğunu qəbul edəcəkdir (istisna olmaqla, bu, `&U` `&T`-dən daha sərt hizalama tələbləri irəli sürdükdə belə düzgün şəkildə aparılır).
/// Ayrıca, `src`-dən çıxmaq əvəzinə, ehtimal olunan dəyərin bir kopyasını da təhlükəli şəkildə yaradır.
///
/// `T` və `U` fərqli ölçülərə sahib olduqda bir kompilyasiya vaxtı xətası deyil, ancaq bu funksiyanı yalnız `T` və `U` eyni ölçülü olduqda işə salmaq tövsiyə olunur.Bu funksiya, `U` `T`-dən daha böyükdürsə, [undefined behavior][ub]-i işə salır.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Veriləri 'foo_array'-dən kopyalayın və 'Foo' kimi qəbul edin
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Kopyalanan məlumatları dəyişdirin
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array'-in məzmunu dəyişməməli idi
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U-nun daha yüksək bir hizalama tələbi varsa, src uyğun olaraq hizalanamayabilir.
    if align_of::<U>() > align_of::<T>() {
        // TƏHLÜKƏSİZLİK: `src` oxunması üçün etibarlı olduğuna zəmanət verən bir istinaddır.
        // Zəng edən şəxs, həqiqi transmutasiyanın təhlükəsiz olmasına zəmanət verməlidir.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // TƏHLÜKƏSİZLİK: `src` oxunması üçün etibarlı olduğuna zəmanət verən bir istinaddır.
        // Yalnız `src as *const U`-in düzgün bir şəkildə hizalandığını yoxladıq.
        // Zəng edən şəxs, həqiqi transmutasiyanın təhlükəsiz olmasına zəmanət verməlidir.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Enumun diskriminantını təmsil edən qeyri-şəffaf tip.
///
/// Daha çox məlumat üçün bu moduldakı [`discriminant`] funksiyasına baxın.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Bu trait tətbiqləri əldə edilə bilməz, çünki T-də heç bir sərhəd istəmirik.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v`-də enum variantını unikal şəkildə müəyyənləşdirən bir dəyəri qaytarır.
///
/// `T` bir enum deyilsə, bu funksiyanı çağırmaq təyin edilməmiş davranışla nəticələnməyəcək, lakin qaytarma dəyəri dəqiqləşdirilməyib.
///
///
/// # Stability
///
/// Enum tərifinin dəyişməsi halında bir enum variantının diskriminantı dəyişə bilər.
/// Bəzi variantın diskriminantı eyni tərtibçi ilə tərtiblər arasında dəyişməyəcəkdir.
///
/// # Examples
///
/// Bu, həqiqi məlumatlara məhəl qoymadan məlumat daşıyan enumları müqayisə etmək üçün istifadə edilə bilər:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// `T` enum tipindəki variant sayını qaytarır.
///
/// `T` bir enum deyilsə, bu funksiyanı çağırmaq təyin edilməmiş davranışla nəticələnməyəcək, lakin qaytarma dəyəri dəqiqləşdirilməyib.
/// Eyni şəkildə, `T`, `usize::MAX`-dən daha çox dəyişikliyə sahib bir enum olarsa, dönüş dəyəri təyin olunmamışdır.
/// Yaşayış olmayan variantlar sayılacaqdır.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}