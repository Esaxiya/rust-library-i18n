use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T`-nin başlanğıc olunmamış nümunələrini qurmaq üçün bir sarğı növü.
///
/// # Başlanğıc dəyişməzdir
///
/// Tərtibçi ümumiyyətlə dəyişənin tipin tələblərinə uyğun olaraq dəyişənin düzgün başlanğıc olduğunu qəbul edir.Məsələn, bir istinad növü dəyişəninin hizalanması və NULL olmaması lazımdır.
/// Bu, təhlükəli kodda belə *həmişə* dəstəklənməlidir.
/// Nəticə olaraq, bir referans növü dəyişəninin sıfır başlanğıc edilməsi, ani [undefined behavior][ub]-ə səbəb olur, nə olursa olsun bu arayış yaddaşa giriş üçün istifadə olunur:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // tərifsiz davranış!⚠️
/// // `MaybeUninit<&i32>` ilə bərabər kod:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // tərifsiz davranış!⚠️
/// ```
///
/// Bu, iş müddəti yoxlamalarının seçilməsi və `enum` tərtibinin optimallaşdırılması kimi müxtəlif optimallaşdırmalar üçün tərtibçi tərəfindən istifadə olunur.
///
/// Eynilə, tamamilə başlanğıc olunmamış yaddaş hər hansı bir məzmuna sahib ola bilər, `bool` isə həmişə `true` və ya `false` olmalıdır.Beləliklə, başlanğıc edilməmiş bir `bool` yaratmaq, təyin olunmamış bir davranışdır:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // tərifsiz davranış!⚠️
/// // `MaybeUninit<bool>` ilə bərabər kod:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // tərifsiz davranış!⚠️
/// ```
///
/// Üstəlik, başlanğıc olunmamış yaddaş sabit bir dəyərə sahib olmaması ilə xüsusidir ("fixed", "it won't change without being written to" mənasını verir).Eyni başlanmamış baytı bir neçə dəfə oxumaq fərqli nəticələr verə bilər.
/// Bu, dəyişkən bir tam tipə sahib olsa da, başlanğıc edilməmiş bir məlumatın bir dəyişkəndə olmasını, əks halda hər hansı bir *sabit* bit naxışını saxlaya biləcəyini müəyyənləşdirməmiş bir davranışa çevirir:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // tərifsiz davranış!⚠️
/// // `MaybeUninit<i32>` ilə bərabər kod:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // tərifsiz davranış!⚠️
/// ```
/// (Diqqət yetirin ki, başlanğıc olunmamış tam ədədlər ətrafında olan qaydalar hələ yekunlaşdırılmayıb, lakin bunlara qədər onlardan qaçınmaq məsləhətdir.)
///
/// Bunun üzərinə, əksər növlərin yalnız növ səviyyəsində başlanğıc hesab edildiyindən əlavə əlavə dəyişkənliklərə sahib olduğunu unutmayın.
/// Məsələn, `1`-başlanılmış [`Vec<T>`] başlanğıclı sayılır (mövcud tətbiqetmə şəraitində; bu sabit bir zəmanət təşkil etmir), çünki kompilyatorun bildiyi yeganə tələb, məlumat göstəricisinin sıfır olmamasıdır.
/// Belə bir `Vec<T>` yaratmaq *dərhal* təyin olunmayan bir davranışa səbəb olmaz, əksər təhlükəsiz əməliyyatlarla (onu atmaq da daxil olmaqla) təyin olunmamış davranışa səbəb olur.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` təhlükəli kodun başlanğıc edilməmiş məlumatlarla məşğul olmasına imkan verir.
/// Buradakı məlumatların başlanğıc edilə bilməyəcəyini göstərən bir tərtibçiyə bir siqnaldır:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Açıq şəkildə başlanmamış bir istinad yaradın.
/// // Tərtibçi bir `MaybeUninit<T>` içindəki məlumatların etibarsız ola biləcəyini bilir və bu səbəbdən UB deyil:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Etibarlı bir dəyəri qoyun.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Başlanğıc məlumatları çıxarın-buna yalnız * `x` düzgün işə salındıqdan sonra icazə verilir!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Daha sonra tərtibçi bu kodla bağlı hər hansı bir səhv fərziyyə və ya optimallaşdırma etməməyi bilir.
///
/// `MaybeUninit<T>`-i bir az `Option<T>` kimi düşünə bilərsiniz, amma iş vaxtı izlənmədən və təhlükəsizlik yoxlanışlarından keçmədən.
///
/// ## out-pointers
///
/// "out-pointers" tətbiq etmək üçün `MaybeUninit<T>` istifadə edə bilərsiniz: bir funksiyadan məlumatları qaytarmaq əvəzinə nəticəni qoymaq üçün onu bir göstəricini bəzi (uninitialized) yaddaşına ötürün.
/// Bu, zəng edənin nəticənin yaddaşda necə saxlandığına nəzarət etməsi vacib olduqda və lazımsız hərəkətlərdən qaçınmaq istədiyiniz zaman faydalı ola bilər.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` vacib olan köhnə məzmunu atmaz.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // İndi bilirik ki, `v` işə salındı!Bu, vector-nin düzgün bir şəkildə düşməsini təmin edir.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Bir sıra elementi-elementi işə salınır
///
/// `MaybeUninit<T>` geniş bir element element-başlanğıc üçün istifadə edilə bilər:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` başlanğıc olunmamış bir sıra yaradın.
///     // `assume_init` etibarlıdır, çünki burada başlatdığımızı iddia etdiyimiz tip, başlanğıc tələb etməyən bir sıra `BəlkəUninit`dir.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit`-in düşməsi heç bir şey etmir.
///     // Beləliklə, `ptr::write` əvəzinə xam göstərici təyinatından istifadə köhnə başlanğıc edilməmiş dəyərin düşməsinə səbəb olmur.
/////
///     // Ayrıca, bu döngə zamanı bir panic varsa, yaddaş sızıntısı var, ancaq yaddaş təhlükəsizliyi problemi yoxdur.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Hər şey başlanğıcdır.
///     // Dizini başlanğıc tipinə köçürün.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Aşağı səviyyəli məlumat strukturlarında tapıla bilən qismən başlanğıc edilmiş massivlərlə də işləyə bilərsiniz.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` başlanğıc olunmamış bir sıra yaradın.
/// // `assume_init` etibarlıdır, çünki burada başlatdığımızı iddia etdiyimiz tip, başlanğıc tələb etməyən bir sıra `BəlkəUninit`dir.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Təyin etdiyimiz elementlərin sayını hesablayın.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Dizidəki hər bir maddə üçün ayırsaq, buraxın.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Sahə-sahə strukturunu işə salmaq
///
/// Konstruksiyalar sahəsini sahəyə başlamaq üçün `MaybeUninit<T>` və [`std::ptr::addr_of_mut`] makrosundan istifadə edə bilərsiniz:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` sahəsini işə salmaq
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` sahəsinin işə salınması Burada bir panic varsa, `name` sahəsindəki `String` sızır.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Bütün sahələr başlanğıcdır, buna görə başlanmış bir Foo almaq üçün `assume_init`-ə zəng edirik.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` ilə eyni ölçüyə, hizalanmaya və ABI-yə sahib olmasına zəmanət verilir:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Bununla birlikdə `MaybeUninit<T>` ehtiva edən bir növün * mütləq eyni tərtibat olmadığını unutmayın;Rust, ümumiyyətlə `T` və `U` eyni ölçüdə və uyğunlaşma olsa da, `Foo<T>` sahələrinin `Foo<U>` ilə eyni qaydada olmasına zəmanət vermir.
///
/// Bundan əlavə, hər hansı bir bit dəyəri bir `MaybeUninit<T>` üçün etibarlı olduğundan, kompilyator non-zero/niche-filling optimallaşdırmalarını tətbiq edə bilməz və potensial olaraq daha böyük bir ölçüyə səbəb olur:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI təhlükəsizdirsə, `MaybeUninit<T>` də belədir.
///
/// `MaybeUninit` `#[repr(transparent)]` olsa da (`T` ilə eyni ölçüyə, hizalanmaya və ABI-yə zəmanət verildiyini göstərir), bu əvvəlki xəbərdarlıqların heç birini dəyişdirmir *.
/// `Option<T>` və `Option<MaybeUninit<T>>` hələ də fərqli ölçülərə sahib ola bilər və `T` tipli bir sahəni ehtiva edən növlər, bu sahə `MaybeUninit<T>` olandan fərqli olaraq düzülə bilər (və ölçülü).
/// `MaybeUninit` birlik növüdür və həmkarlar ittifaqlarıdakı `#[repr(transparent)]` qeyri-sabitdir (bax [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Vaxt keçdikcə `#[repr(transparent)]`-nin həmkarlar ittifaqları ilə bağlı zəmanətləri inkişaf edə bilər və `MaybeUninit` `#[repr(transparent)]` olaraq qala da bilər.
/// Dedi ki, `MaybeUninit<T>`*həmişə*`T` ilə eyni ölçüyə, hizalanmaya və ABI-yə sahib olmasını təmin edəcəkdir;sadəcə `MaybeUninit`-in zəmanəti tətbiqetmə yolu inkişaf edə bilər.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang elementi, buna görə digər növlərini də bükə bilərik.Bu generatorlar üçün faydalıdır.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()`-yə zəng etməyək, bunun üçün kifayət qədər başlanğıc olub olmadığını bilmirik.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Verilən dəyərlə başlanğıc edilmiş yeni bir `MaybeUninit<T>` yaradır.
    /// Bu funksiyanın qaytarma dəyərində [`assume_init`]-yə zəng etmək təhlükəsizdir.
    ///
    /// `MaybeUninit<T>`-in düşməsi heç vaxt "T"-in açılan kodunu axtarmayacağını unutmayın.
    /// `T`-in başlanğıc verildiyi təqdirdə düşməsinə əmin olmaq sizin məsuliyyətinizdir.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Başlanmamış vəziyyətdə yeni bir `MaybeUninit<T>` yaradır.
    ///
    /// `MaybeUninit<T>`-in düşməsi heç vaxt "T"-in açılan kodunu axtarmayacağını unutmayın.
    /// `T`-in başlanğıc verildiyi təqdirdə düşməsinə əmin olmaq sizin məsuliyyətinizdir.
    ///
    /// Bəzi nümunələr üçün [type-level documentation][MaybeUninit]-ə baxın.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Başlanmamış vəziyyətdə yeni bir `MaybeUninit<T>` elementi yaradın.
    ///
    /// Note: bir future Rust versiyasında, sıra literal sintaksisinin [repeating const expressions](https://github.com/rust-lang/rust/issues/49147)-ə icazə verdiyi zaman bu metod lazımsız ola bilər.
    ///
    /// Aşağıdakı nümunə daha sonra `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` istifadə edə bilər.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Həqiqətən oxunan (bəlkə də daha kiçik) bir dilim qaytarır
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // TƏHLÜKƏSİZLİK: Başlanmamış `[MaybeUninit<_>; LEN]` etibarlıdır.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Yaddaş `0` baytla doldurularaq, başlanğıc olunmamış vəziyyətdə yeni bir `MaybeUninit<T>` yaradır.Bunun `T`-dən asılıdır ki, onsuz da düzgün başlanğıcın olub-olmaması.
    ///
    /// Məsələn, `MaybeUninit<usize>::zeroed()` işə salındı, lakin `MaybeUninit<&'static i32>::zeroed()` deyil, çünki istinadlar sıfır olmamalıdır.
    ///
    /// `MaybeUninit<T>`-in düşməsi heç vaxt "T"-in açılan kodunu axtarmayacağını unutmayın.
    /// `T`-in başlanğıc verildiyi təqdirdə düşməsinə əmin olmaq sizin məsuliyyətinizdir.
    ///
    /// # Example
    ///
    /// Bu funksiyanın düzgün istifadəsi: strukturun bütün sahələrinin bit nümunəsini 0 etibarlı bir dəyər kimi saxlaya biləcəyi sıfır ilə bir quruluşu başlanğıc etmək.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Yanlış* bu funksiyanın istifadəsi: `0` tip üçün etibarlı bir bit nümunəsi olmadıqda `x.zeroed().assume_init()` çağırmaq:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Bir cütün içində, etibarlı bir ayrıseçkiliyə sahib olmayan bir `NotZero` yaradırıq.
    /// // Bu, təyin olunmayan bir davranışdır.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // TƏHLÜKƏSİZLİK: `u.as_mut_ptr()` ayrılmış yaddaşa işarə edir.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` dəyərini təyin edir.
    /// Bu, əvvəlki hər hansı bir dəyəri düşmədən yazır, buna görə də destruktoru işə salmaq istəməsəniz, bunu iki dəfə istifadə etməyin.
    ///
    /// Rahatlığınız üçün, bu da `self`-in (indi etibarlı şəkildə başlanğıc edilmiş) məzmununa dəyişkən bir istinad gətirir.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // TƏHLÜKƏSİZLİK: Bu dəyəri yeni başlatdıq.
        unsafe { self.assume_init_mut() }
    }

    /// İçindəki dəyərə bir göstərici alır.
    /// Bu göstəricidən oxumaq və ya bir referansa çevirmək, `MaybeUninit<T>` başlanğıc edilmədiyi müddətdə təyin olunmamış davranışdır.
    /// Bu göstəricinin (non-transitively)-nin göstərdiyi yaddaşa yazmaq, təyin olunmamış davranışdır (`UnsafeCell<T>` daxilində istisna olmaqla).
    ///
    /// # Examples
    ///
    /// Bu metodun düzgün istifadəsi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>`-ə bir istinad yaradın.Başlanğıc üçün hazırladığımız üçün bu yaxşıdır.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Bu metodun *səhv* istifadəsi:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Başlanmamış vector-yə istinad yaratdıq!Bu, təyin olunmayan bir davranışdır.⚠️
    /// ```
    ///
    /// (Diqqət yetirin ki, başlanğıc olunmamış məlumatlara istinadlar qaydaları hələ yekunlaşdırılmayıb, lakin bunlara qədər onlardan qaçınmaq məsləhətdir.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` və `ManuallyDrop` hər ikisi də `repr(transparent)`-dir, buna görə göstəricini ata bilərik.
        self as *const _ as *const T
    }

    /// Daxil olan dəyərə dəyişkən bir göstərici alır.
    /// Bu göstəricidən oxumaq və ya bir referansa çevirmək, `MaybeUninit<T>` başlanğıc edilmədiyi müddətdə təyin olunmamış davranışdır.
    ///
    /// # Examples
    ///
    /// Bu metodun düzgün istifadəsi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>`-ə bir istinad yaradın.
    /// // Başlanğıc üçün hazırladığımız üçün bu yaxşıdır.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Bu metodun *səhv* istifadəsi:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Başlanmamış vector-yə istinad yaratdıq!Bu, təyin olunmayan bir davranışdır.⚠️
    /// ```
    ///
    /// (Diqqət yetirin ki, başlanğıc olunmamış məlumatlara istinadlar qaydaları hələ yekunlaşdırılmayıb, lakin bunlara qədər onlardan qaçınmaq məsləhətdir.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` və `ManuallyDrop` hər ikisi də `repr(transparent)`-dir, buna görə göstəricini ata bilərik.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` konteynerindən dəyəri çıxarır.Bu, məlumatların düşməsini təmin etmək üçün əla bir yoldur, çünki ortaya çıxan `T` adi açılan rəftara tabedir.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>`-in həqiqətən başlanğıc vəziyyətində olmasını təmin etmək zəng edənə aiddir.Məzmunun hələ tam başlanğıc olunmadığında bunun adlandırılması dərhal təyin olunmayan davranışa səbəb olur.
    /// [type-level documentation][inv], bu başlatma dəyişməzliyi haqqında daha çox məlumat ehtiva edir.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Bunun üzərinə, əksər növlərin yalnız növ səviyyəsində başlanğıc hesab edildiyindən əlavə əlavə dəyişkənliklərə sahib olduğunu unutmayın.
    /// Məsələn, `1`-başlanılmış [`Vec<T>`] başlanğıclı sayılır (mövcud tətbiqetmə şəraitində; bu sabit bir zəmanət təşkil etmir), çünki kompilyatorun bildiyi yeganə tələb, məlumat göstəricisinin sıfır olmamasıdır.
    ///
    /// Belə bir `Vec<T>` yaratmaq *dərhal* təyin olunmayan bir davranışa səbəb olmaz, əksər təhlükəsiz əməliyyatlarla (onu atmaq da daxil olmaqla) təyin olunmamış davranışa səbəb olur.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Bu metodun düzgün istifadəsi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Bu metodun *səhv* istifadəsi:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` hələ başlanğıc edilməmişdi, bu səbəbdən bu son sətir təyin olunmamış davranışa səbəb oldu.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in işə salındığına zəmanət verməlidir.
        // Bu da `self`-in bir `value` variantı olması lazım olduğunu göstərir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` konteynerindəki dəyəri oxuyur.Nəticədə `T` adi damla işlənməsinə tabedir.
    ///
    /// Mümkün olduqda, bunun yerinə [`assume_init`] istifadə etmək üstünlük təşkil edir, bu da `MaybeUninit<T>`-in tərkibinin təkrarlanmasının qarşısını alır.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>`-in həqiqətən başlanğıc vəziyyətində olmasını təmin etmək zəng edənə aiddir.Məzmunun hələ tam başlanğıc olunmadığında buna zəng etmək, təyin olunmamış davranışa səbəb olur.
    /// [type-level documentation][inv], bu başlatma dəyişməzliyi haqqında daha çox məlumat ehtiva edir.
    ///
    /// Üstəlik, bu eyni məlumatların bir nüsxəsini `MaybeUninit<T>`-də geridə qoyur.
    /// Verilərin birdən çox nüsxəsini istifadə edərkən (`assume_init_read`-ə bir neçə dəfə zəng edərək və ya əvvəlcə `assume_init_read` və sonra [`assume_init`]-yə zəng edərək), məlumatların həqiqətən də təkrarlanmasını təmin etmək sizin məsuliyyətinizdir.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Bu metodun düzgün istifadəsi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy`-dir, buna görə dəfələrlə oxuya bilərik.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` dəyərinin kopyalanması yaxşıdır, buna görə dəfələrlə oxuya bilərik.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Bu metodun *səhv* istifadəsi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // İndi eyni vector-nin iki nüsxəsini yaratdıq, ikisi də düşdükdə ikiqat pulsuz to️ əldə etdik!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in işə salındığına zəmanət verməlidir.
        // `self.as_ptr()`-dən oxumaq təhlükəsizdir, çünki `self` başlanğıc vəziyyətinə gətirilməlidir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// İçindəki dəyəri yerə düşür.
    ///
    /// `MaybeUninit` sahibliyiniz varsa, bunun əvəzinə [`assume_init`] istifadə edə bilərsiniz.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>`-in həqiqətən başlanğıc vəziyyətində olmasını təmin etmək zəng edənə aiddir.Məzmunun hələ tam başlanğıc olunmadığında buna zəng etmək, təyin olunmamış davranışa səbəb olur.
    ///
    /// Bunun üzərinə `T` tipli bütün əlavə dəyişməzlər təmin edilməlidir, çünki `T`-in (və ya üzvlərinin) `Drop` tətbiqi buna etibar edə bilər.
    /// Məsələn, `1`-başlanılmış [`Vec<T>`] başlanğıclı sayılır (mövcud tətbiqetmə şəraitində; bu sabit bir zəmanət təşkil etmir), çünki kompilyatorun bildiyi yeganə tələb, məlumat göstəricisinin sıfır olmamasıdır.
    ///
    /// Bununla belə bir `Vec<T>`-in atılması, müəyyən olmayan bir davranışa səbəb olacaqdır.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in işə salındığına zəmanət verməlidir
        // `T`-in bütün dəyişməzlərini təmin edir.
        // Əgər vəziyyət belədirsə, dəyəri yerində salmaq təhlükəsizdir.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// İçindəki dəyərə paylaşılan bir istinad əldə edir.
    ///
    /// Bu işə salındığı, lakin `MaybeUninit`-ə sahib olmadığı bir `MaybeUninit`-ə daxil olmaq istədiyimiz zaman faydalı ola bilər (`.assume_init()`)-nin istifadəsinin qarşısını alır).
    ///
    /// # Safety
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında buna zəng etmək, təyin olunmamış bir davranışa səbəb olur: `MaybeUninit<T>`-in həqiqətən başlanğıc vəziyyətində olduğunu zəmanət verən şəxsin özünə aiddir.
    ///
    ///
    /// # Examples
    ///
    /// ### Bu metodun düzgün istifadəsi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` başlanğıc:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Artıq `MaybeUninit<_>`-nin başlanğıclandığı məlum olduğu üçün ortaq bir istinad yaratmaq yaxşıdır:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // TƏHLÜKƏSİZLİK: `x` işə salındı.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Bu metodun *səhv* istifadəsi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Başlanmamış vector-yə istinad yaratdıq!Bu, təyin olunmayan bir davranışdır.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` istifadə edərək `MaybeUninit`-i başladın:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Başlanmamış `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in işə salındığına zəmanət verməlidir.
        // Bu da `self`-in bir `value` variantı olması lazım olduğunu göstərir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Daxil olan dəyərə dəyişdirilə bilən bir (unique) istinadını alır.
    ///
    /// Bu işə salındığı, lakin `MaybeUninit`-ə sahib olmadığı bir `MaybeUninit`-ə daxil olmaq istədiyimiz zaman faydalı ola bilər (`.assume_init()`)-nin istifadəsinin qarşısını alır).
    ///
    /// # Safety
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında buna zəng etmək, təyin olunmamış bir davranışa səbəb olur: `MaybeUninit<T>`-in həqiqətən başlanğıc vəziyyətində olduğunu zəmanət verən şəxsin özünə aiddir.
    /// Məsələn, `.assume_init_mut()` bir `MaybeUninit` başlatmak üçün istifadə edilə bilməz.
    ///
    /// # Examples
    ///
    /// ### Bu metodun düzgün istifadəsi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Giriş tamponunun baytlarını *hamısını* başlatır.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` başlanğıc:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // İndi bilirik ki, `buf` işə salındı, buna görə `.assume_init()` edə bildik.
    /// // Bununla birlikdə, `.assume_init()` istifadə 2048 baytın bir `memcpy`-ni tetikleyebilir.
    /// // Tamponumuz kopyalanmadan başlatıldığını iddia etmək üçün `&mut MaybeUninit<[u8; 2048]>`-i `&mut [u8; 2048]`-ə yüksəldirik:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // TƏHLÜKƏSİZLİK: `buf` işə salındı.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // İndi `buf`-dən normal bir dilim kimi istifadə edə bilərik:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Bu metodun *səhv* istifadəsi:
    ///
    /// Bir dəyəri başlamaq üçün `.assume_init_mut()` istifadə edə bilməzsiniz:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Başlanmamış `bool`-ə bir (mutable) istinad yaratdıq!
    ///     // Bu, təyin olunmayan bir davranışdır.⚠️
    /// }
    /// ```
    ///
    /// Məsələn, başlanğıc olunmamış bir tampona [`Read`] edə bilməzsiniz:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) başlanğıc olunmamış yaddaşa istinad!
    ///                             // Bu, təyin olunmayan bir davranışdır.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Tədricən başlanğıc etmək üçün birbaşa sahə girişindən də istifadə edə bilməzsiniz:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) başlanğıc olunmamış yaddaşa istinad!
    ///                  // Bu, təyin olunmayan bir davranışdır.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) başlanğıc olunmamış yaddaşa istinad!
    ///                  // Bu, təyin olunmayan bir davranışdır.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Hal-hazırda yuxarıdakıların səhv olduğuna inanırıq, yəni başlanğıc olunmamış məlumatlara istinadlarımız var (məsələn, `libcore/fmt/float.rs`-də).
    // Sabitləşmədən əvvəl qaydalarla bağlı son qərarı verməliyik.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // TƏHLÜKƏSİZLİK: zəng edən `self`-in işə salındığına zəmanət verməlidir.
        // Bu da `self`-in bir `value` variantı olması lazım olduğunu göstərir.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Bir sıra `MaybeUninit` konteynerlərindən dəyərləri çıxarır.
    ///
    /// # Safety
    ///
    /// Dizinin bütün elementlərinin başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // TƏHLÜKƏSİZLİK: Bütün elementləri işə saldığımız üçün təhlükəsizdir
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Zəng edən şəxs massivin bütün elementlərinin başlanğıc olmasına zəmanət verir
        // * `MaybeUninit<T>` və T-nin eyni tərtibata sahib olmasına zəmanət verilir
        // * BəlkəUnint düşmür, buna görə ikiqat sərbəstlik yoxdur və beləliklə dönüşüm təhlükəsizdir
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Bütün elementlərin başlanğıc edildiyini düşünsək, onlara bir dilim alın.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` elementlərinin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında buna zəng etmək, təyin olunmamış davranışa səbəb olur.
    ///
    /// Daha ətraflı məlumat və nümunələr üçün [`assume_init_ref`]-ə baxın.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // TƏHLÜKƏSİZLİK: `*const [T]`-ə dilim tökmək təhlükəsizdir, çünki zəng edən zəmanət verir
        // `slice` işə salındı və "BəlkəUninit" in `T` ilə eyni tərtibata sahib olmasına zəmanət verilir.
        // Əldə edilmiş göstərici etibarlıdır, çünki `slice`-ə məxsus olan və istinad üçün etibarlı olduğuna zəmanət verilən yaddaşa aiddir.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Bütün elementlərin başlanğıc edildiyini düşünsək, onlara dəyişdirilə bilən bir dilim alın.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` elementlərinin həqiqətən başlanğıc vəziyyətində olmasına zəmanət vermək zəng edənə aiddir.
    ///
    /// Məzmunun hələ tam başlanğıc olunmadığında buna zəng etmək, təyin olunmamış davranışa səbəb olur.
    ///
    /// Daha ətraflı məlumat və nümunələr üçün [`assume_init_mut`]-ə baxın.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // TƏHLÜKƏSİZLİK: `slice_get_ref` üçün təhlükəsizlik qeydlərinə bənzəyir, ancaq bir
        // yazmaq üçün etibarlı olduğu zəmanət verilən dəyişkən istinad.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Dizinin ilk elementinə bir göstərici alır.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Dizinin birinci elementinə dəyişkən bir göstərici alır.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Elementləri `src`-dən `this`-ə kopyalayır və `this`-in indiki məzmununa dəyişdirilə bilən bir istinad gətirir.
    ///
    /// `T` `Copy` tətbiq etmirsə, [`write_slice_cloned`] istifadə edin
    ///
    /// Bu, [`slice::copy_from_slice`]-ə bənzəyir.
    ///
    /// # Panics
    ///
    /// İki dilimin fərqli uzunluqları varsa, bu funksiya panic olacaqdır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // TƏHLÜKƏSİZLİK: bütün len elementlərini ehtiyat gücünə köçürdük
    /// // vecin ilk src.len() elementləri indi etibarlıdır.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // TƏHLÜKƏSİZLİK: &[T] və&[Bəlkə də Uninit<T>] eyni tərtibə sahibdirlər
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // TƏHLÜKƏSİZLİK: Etibarlı elementlər `this`-ə yeni köçürüldü, beləliklə initalize edildi
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Elementləri `src`-dən `this`-ə klonlayır və `this`-in indisializasiya edilmiş məzmununa dəyişkən bir istinad gətirir.
    /// Onsuz da initalize edilmiş elementlər atılmayacaq.
    ///
    /// `T` `Copy` tətbiq edirsə, [`write_slice`] istifadə edin
    ///
    /// Bu, [`slice::clone_from_slice`]-ə bənzəyir, lakin mövcud elementləri atmır.
    ///
    /// # Panics
    ///
    /// İki dilim fərqli uzunluqlara sahib olduqda və ya `Clone` panics tətbiq olunduqda bu funksiya panic olacaqdır.
    ///
    /// Bir panic varsa, onsuz da klonlanmış elementlər atılacaq.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // TƏHLÜKƏSİZLİK: bütün len elementlərini ehtiyat gücünə yeni klonladıq
    /// // vecin ilk src.len() elementləri indi etibarlıdır.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice-dən fərqli olaraq bu dilimdəki clone_from_slice adlandırmır, çünki `MaybeUninit<T: Clone>` Clone tətbiq etmir.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // TƏHLÜKƏSİZLİK: bu xam dilim yalnız başlanğıc edilmiş obyektləri ehtiva edəcəkdir
                // buna görə də onu atmağa icazə verilir.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Onları açıq şəkildə eyni uzunluqda dilimləməliyik
        // hüdudların yoxlanılması üçün optimizator sadə hallarda memcpy əmələ gətirəcəkdir (məsələn T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // gözətçi lazımdır b/c panic bir klon zamanı ola bilər
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // TƏHLÜKƏSİZLİK: Etibarlı elementlər `this`-ə yeni yazılıb, beləliklə, işə salındı
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}