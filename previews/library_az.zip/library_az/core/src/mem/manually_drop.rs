use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Kompilyatorun avtomatik olaraq "T``nin destruktoru" çağırmasını maneə törətmək üçün bir bükücü.
/// Bu sarğı 0 maliyetlidir.
///
/// `ManuallyDrop<T>` `T` ilə eyni layout optimallaşdırmalarına tabedir.
/// Nəticə olaraq, tərtibçinin məzmunu barədə irəli sürdüyü fərziyyələrə * heç bir təsiri yoxdur.
/// Məsələn, `ManuallyDrop<&mut T>`-i [`mem::zeroed`] ilə işə salmaq, təyin olunmamış davranışdır.
/// Başlanğıcsız məlumatları idarə etmək lazımdırsa, bunun əvəzinə [`MaybeUninit<T>`] istifadə edin.
///
/// Bir `ManuallyDrop<T>` içərisindəki qiymətə girməyin təhlükəsiz olduğunu unutmayın.
/// Bu o deməkdir ki, məzmunu atılmış bir `ManuallyDrop<T>`, ictimai təhlükəsiz bir API vasitəsilə məruz qalmamalıdır.
/// Müvafiq olaraq, `ManuallyDrop::drop` təhlükəlidir.
///
/// # `ManuallyDrop` və sifariş buraxın.
///
/// Rust, yaxşı müəyyən edilmiş [drop order] dəyərlərə malikdir.
/// Sahələrin və ya yerlilərin müəyyən bir qaydada buraxıldığından əmin olmaq üçün, bəyannamələrin üstünü örtülü enmə əmrinin düzgün olduğu şəkildə yenidən düzəldin.
///
/// Düşmə sifarişinə nəzarət etmək üçün `ManuallyDrop` istifadə etmək mümkündür, lakin bunun üçün təhlükəli kod tələb olunur və açılma hüzurunda düzgün bir şəkildə etmək çətindir.
///
///
/// Məsələn, müəyyən bir sahənin digərlərindən sonra atıldığından əmin olmaq istəyirsinizsə, onu bir strukturun son sahəsinə çevirin:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children`-dən sonra düşəcək.
///     // Rust, bəyannamə qaydasında sahələrin atıldığına zəmanət verir.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Əl ilə düşəcək bir dəyəri sarın.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Hələ dəyərlə təhlükəsiz şəkildə işləyə bilərsiniz
    /// assert_eq!(*x, "Hello");
    /// // Ancaq `Drop` burada işlədilməyəcək
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` konteynerindən dəyəri çıxarır.
    ///
    /// Bu, dəyərin yenidən düşməsinə imkan verir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Bu `Box` düşür.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` konteynerindəki dəyəri çıxarır.
    ///
    /// Bu metod ilk növbədə dəyərləri düşmə şəklində köçürmək üçün nəzərdə tutulmuşdur.
    /// Dəyəri əl ilə aşağı salmaq üçün [`ManuallyDrop::drop`] istifadə etmək əvəzinə, dəyəri almaq və istədiyiniz şəkildə istifadə etmək üçün bu metodu istifadə edə bilərsiniz.
    ///
    /// Mümkün olduqda, bunun yerinə [`into_inner`][`ManuallyDrop::into_inner`] istifadə etmək üstünlük təşkil edir, bu da `ManuallyDrop<T>`-in tərkibinin təkrarlanmasının qarşısını alır.
    ///
    ///
    /// # Safety
    ///
    /// Bu funksiya, daha çox istifadəni əngəlləmədən ehtiva olunan dəyəri semantik olaraq çıxarır və bu konteynerin vəziyyətini dəyişməz vəziyyətə gətirir.
    /// Bu `ManuallyDrop`-in yenidən istifadə edilməməsini təmin etmək sizin məsuliyyətinizdir.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // TƏHLÜKƏSİZLİK: zəmanət verilən bir istinaddan oxuyuruq
        // oxunması üçün etibarlı olmalıdır.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// İçindəki dəyəri əl ilə düşür.Bu, ehtiva olunan dəyərə bir göstərici ilə [`ptr::drop_in_place`] çağırmağa tam bərabərdir.
    /// Beləliklə, ehtiva olunan dəyər paketlənmiş bir quruluş olmadığı təqdirdə, destruktor dəyəri dəyişdirmədən yerində çağırılacaq və beləliklə [pinned] məlumatlarını etibarlı şəkildə buraxmaq üçün istifadə edilə bilər.
    ///
    /// Dəyər sahibliyiniz varsa, bunun əvəzinə [`ManuallyDrop::into_inner`] istifadə edə bilərsiniz.
    ///
    /// # Safety
    ///
    /// Bu funksiya ehtiva olunan dəyərin destruktorunu işlədir.
    /// Dağıdıcının özü tərəfindən edilən dəyişikliklərdən başqa, yaddaş dəyişməz olaraq qalır və derleyiciye gəlincə `T` tipi üçün etibarlı olan bir bit nümunəsi var.
    ///
    ///
    /// Bununla birlikdə, bu "zombie" dəyəri təhlükəsiz kodlara məruz qalmamalı və bu funksiya bir dəfədən çox çağırılmamalıdır.
    /// Bir dəyər düşdükdən sonra istifadə etmək və ya bir dəyəri bir neçə dəfə düşmək, Tərifsiz Davranışa səbəb ola bilər (`drop`-in işinə görə).
    /// Bunun normal olaraq tip sistemi tərəfindən qarşısı alınır, lakin `ManuallyDrop` istifadəçiləri kompilyatorun köməyi olmadan bu təminatları təmin etməlidirlər.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // TƏHLÜKƏSİZLİK: dəyişdirilə bilən bir istinadla göstərilən dəyəri salırıq
        // yazmaq üçün etibarlı olduğu zəmanətlidir.
        // `slot`-in yenidən enməməsinə əmin olmaq zəng edənə aiddir.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}