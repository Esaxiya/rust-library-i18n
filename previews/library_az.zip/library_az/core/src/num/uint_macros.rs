macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Bu tamsayı növü ilə təmsil oluna bilən ən kiçik dəyər.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Bu tamsayı növü ilə təmsil edilə bilən ən böyük dəyər.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Bu tam ədədin növünün ölçüsü.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Verilmiş bazada bir simli dilimi tam ədədə çevirir.
        ///
        /// Sətrin isteğe bağlı bir `+` işarəsi və ardından rəqəmlər olacağı gözlənilir.
        ///
        /// Aparıcı və arxada qalan boşluq bir səhv təmsil edir.
        /// Rəqəmlər, `radix`-dən asılı olaraq bu simvolların bir alt hissəsidir:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Bu funksiya panics, əgər `radix` 2 ilə 36 arasında deyilsə.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` ikili nümayəndəliyindəki sayını qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` ikili nümayəndəliyindəki sıfır sayını qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` ikili nümayəndəliyindəki aparıcı sıfır sayını qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` ikili nümayəndəliyində arxada qalan sıfır sayını qaytarır.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` ikili nümayəndəliyində aparıcı sayını qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` ikili nümayəndəliyində arxada qalanların sayını qaytarır.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Bitləri müəyyən bir miqdarda sola keçir, `n`, kəsilmiş bitləri ortaya çıxan tam ədədin sonuna bükərək.
        ///
        ///
        /// Xahiş edirəm bu `<<` dəyişən operatorla eyni əməliyyat deyil!
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Bitləri müəyyən bir miqdarda sağa keçir, `n`, kəsilmiş bitləri ortaya çıxan tam ədədin əvvəlinə bükərək.
        ///
        ///
        /// Xahiş edirəm bu `>>` dəyişən operatorla eyni əməliyyat deyil!
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Tam ədədin bayt sırasını dəyişdirir.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// qoy m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Tam ədədə bitlərin sırasını dəyişdirir.
        /// Ən az əhəmiyyətli bit ən əhəmiyyətli bit, ikinci ən az əhəmiyyətli bit ikinci ən əhəmiyyətli bit olur və s.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// qoy m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Tam endian-dan hədəfin indianness-ə bir tam ədədi çevirir.
        ///
        /// Böyük bir anda, bu, əlverişsizdir.
        /// Kiçik bir anda baytlar dəyişdirilir.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } başqa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Kiçik endian'dan hədəfin indianness bir tam ədədi çevirir.
        ///
        /// Kiçik bir endian-da bu, əlverişsizdir.
        /// Böyük endianda baytlar dəyişdirilir.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } başqa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` yi hədəfin artıqlığından böyük endiana çevirir.
        ///
        /// Böyük bir anda, bu, əlverişsizdir.
        /// Kiçik bir anda baytlar dəyişdirilir.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } başqa { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // yoxsa olmamaq?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` yi hədəfin artıqlığından kiçik endiana çevirir.
        ///
        /// Kiçik bir endian-da bu, əlverişsizdir.
        /// Böyük endianda baytlar dəyişdirilir.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } başqa { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Tam əlavə əlavə olundu.
        /// `self + rhs`-i hesablayır, daşma baş verərsə `None`-i qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Seçilməmiş tam ədədi əlavə etmək.Daşmağın baş verə bilməyəcəyini düşünərək `self + rhs` hesablayır.
        /// Bu zaman təyin olunmamış davranışla nəticələnir
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // TƏHLÜKƏSİZLİK: zəng edən `unchecked_add` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Tam çıxarma çıxarıldı.
        /// `self - rhs`-i hesablayır, daşma baş verərsə `None`-i qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Seçilməmiş tam çıxma.Daşmağın baş verə bilməyəcəyini düşünərək `self - rhs` hesablayır.
        /// Bu zaman təyin olunmamış davranışla nəticələnir
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // TƏHLÜKƏSİZLİK: zəng edən `unchecked_sub` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Tamamlı vurma yoxlanıldı.
        /// `self * rhs`-i hesablayır, daşma baş verərsə `None`-i qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Seçilməmiş tam vurma.Daşmağın baş verə bilməyəcəyini düşünərək `self * rhs` hesablayır.
        /// Bu zaman təyin olunmamış davranışla nəticələnir
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // TƏHLÜKƏSİZLİK: zəng edən `unchecked_mul` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Tam bölünmə yoxlandı.
        /// `self / rhs` hesablayır, `rhs == 0` olarsa `None` qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // TƏHLÜKƏSİZLİK: sıfıra div yuxarıda yoxlanılıb və imzasız növlərin başqa heç biri yoxdur
                // bölünmə üçün uğursuzluq rejimi
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Öklid bölgüsü yoxlandı.
        /// `self.div_euclid(rhs)` hesablayır, `rhs == 0` olarsa `None` qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Tamam qalıq yoxlanıldı.
        /// `self % rhs` hesablayır, `rhs == 0` olarsa `None` qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // TƏHLÜKƏSİZLİK: sıfıra div yuxarıda yoxlanılıb və imzasız növlərin başqa heç biri yoxdur
                // bölünmə üçün uğursuzluq rejimi
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Öklid modulu yoxlanıldı.
        /// `self.rem_euclid(rhs)` hesablayır, `rhs == 0` olarsa `None` qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Yoxlanılmış inkar.`-self`-i hesablayır, `None`-i "self==" olmadıqda qaytarır
        /// 0`.
        ///
        /// Diqqət yetirin ki, hər hansı bir müsbət ədədi inkar etmək çoxalacaq.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nöqtə dəyişdirildi.
        /// `self << rhs`-i hesablayır, `rhs`, `self`-dəki bit sayından daha böyük və ya bərabərdirsə, `None`-i qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sağa keçid yoxlanıldı.
        /// `self >> rhs`-i hesablayır, `rhs`, `self`-dəki bit sayından daha böyük və ya bərabərdirsə, `None`-i qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// İstifadəni yoxladı.
        /// `self.pow(exp)`-i hesablayır, daşma baş verərsə `None`-i qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 olduğundan, exp 1 olmalıdır.
            // İstifadənin son biti ilə ayrı-ayrılıqda məşğul olun, çünki bazanı kvadrat şəklində düzəltmək lazım deyil və ehtiyacsız bir daşqına səbəb ola bilər.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Doyma tam ədədi əlavə etmək.
        /// Doldurma yerinə ədədi hüdudlarda doymuş `self + rhs` hesablayır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Doymuş tam çıxma.
        /// Doldurma yerinə ədədi hüdudlarda doymuş `self - rhs` hesablayır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Doymuş tam vurma.
        /// Doldurma yerinə ədədi hüdudlarda doymuş `self * rhs` hesablayır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Doyma tam ədədi göstərici.
        /// Doldurma yerinə ədədi hüdudlarda doymuş `self.pow(exp)` hesablayır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) əlavə ambalaj.
        /// `self + rhs` hesablayır, növün hüdudlarında dolanır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) çıxarma qablaşdırma.
        /// `self - rhs` hesablayır, növün hüdudlarında dolanır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) vurulmasının sarılması.
        /// `self * rhs` hesablayır, növün hüdudlarında dolanır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// Xahiş edirik unutmayın ki, bu nümunə tam ədədlər arasında bölüşdürülür.
        /// Burada `u8`-in niyə istifadə olunduğunu izah edir.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) bölməsinin sarılması.`self / rhs` hesablayır.
        /// İmzasız növlər üzrə sarılmış bölmə sadəcə normal bölgüdür.
        /// Sarmağın heç vaxt ola biləcəyi bir yol yoxdur.
        /// Bu funksiya mövcuddur ki, bütün əməliyyatlar sarma əməliyyatlarında hesaba alınsın.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Öklid bölgüsünün sarılması.`self.div_euclid(rhs)` hesablayır.
        /// İmzasız növlər üzrə sarılmış bölmə sadəcə normal bölgüdür.
        /// Sarmağın heç vaxt ola biləcəyi bir yol yoxdur.
        /// Bu funksiya mövcuddur ki, bütün əməliyyatlar sarma əməliyyatlarında hesaba alınsın.
        /// Müsbət tam ədədlər üçün bölmənin bütün ümumi tərifləri bərabər olduğundan, bu, tamamilə `self.wrapping_div(rhs)`-ə bərabərdir.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) qalığının sarılması.`self % rhs` hesablayır.
        /// İmzasız növlərə bükülmüş qalıq hesablama yalnız müntəzəm qalıq hesablanmasıdır.
        ///
        /// Sarmağın heç vaxt ola biləcəyi bir yol yoxdur.
        /// Bu funksiya mövcuddur ki, bütün əməliyyatlar sarma əməliyyatlarında hesaba alınsın.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Öklid modulunun sarılması.`self.rem_euclid(rhs)` hesablayır.
        /// İmzasız növlərə bükülmüş modul hesablanması yalnız müntəzəm qalan hesablamadır.
        /// Sarmağın heç vaxt ola biləcəyi bir yol yoxdur.
        /// Bu funksiya mövcuddur ki, bütün əməliyyatlar sarma əməliyyatlarında hesaba alınsın.
        /// Müsbət tam ədədlər üçün bölmənin bütün ümumi tərifləri bərabər olduğundan, bu, tamamilə `self.wrapping_rem(rhs)`-ə bərabərdir.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) inkarının sarılması.
        /// `-self` hesablayır, növün hüdudlarında dolanır.
        ///
        /// İmzasız növlərin mənfi ekvivalenti olmadığından, bu funksiyanın bütün tətbiqləri sarılacaq (`-0` istisna olmaqla).
        /// Müvafiq imzalanmış tipin maksimumundan kiçik dəyərlər üçün nəticə müvafiq imzalanmış dəyərin tökülməsi ilə eynidır.
        ///
        /// Hər hansı bir böyük dəyər `MAX + 1 - (val - MAX - 1)`-ə bərabərdir, burada `MAX` müvafiq imzalanmış tipin maksimumudur.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// Xahiş edirik unutmayın ki, bu nümunə tam ədədlər arasında bölüşdürülür.
        /// Burada `i8`-in niyə istifadə olunduğunu izah edir.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic sərbəst bit sürüşmə ilə sola;
        /// `self << mask(rhs)` verir, burada `mask`, dəyişmənin növün genişliyini aşmasına səbəb olan hər hansı bir yüksək dərəcəli `rhs` bitini silir.
        ///
        /// Diqqət yetirin ki, bu, sola döndürmə ilə eyni deyil;LHS-dən çıxarılan bitlər digər ucuna qaytarılmaqdansa, sola bir sürüşmə RHS növü ilə məhdudlaşır.
        /// İbtidai tam ədədlərin hamısı bir [`rotate_left`](Self::rotate_left) funksiyasını yerinə yetirir, bunun əvəzinə istədiyin şey ola bilər.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // TƏHLÜKƏSİZLİK: növün bit ölçüsü ilə maskalanma dəyişməməyimizi təmin edir
            // hüdudlarından kənarda
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic sərbəst bit sürüşmə ilə sağa;
        /// `self >> mask(rhs)` verir, burada `mask`, dəyişmənin növün genişliyini aşmasına səbəb olan hər hansı bir yüksək dərəcəli `rhs` bitini silir.
        ///
        /// Diqqət yetirin ki, bu, sağa döndürməklə eyni deyil;LHS-dən kənara çıxan bitlər digər ucuna qaytarılmaqdansa, bir bükülmə sağa doğru RHS tipin üçündür ilə məhdudlaşır.
        /// İbtidai tam ədədlərin hamısı bir [`rotate_right`](Self::rotate_right) funksiyasını yerinə yetirir, bunun əvəzinə istədiyin şey ola bilər.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // TƏHLÜKƏSİZLİK: növün bit ölçüsü ilə maskalanma dəyişməməyimizi təmin edir
            // hüdudlarından kənarda
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) göstəricilərini sarma.
        /// `self.pow(exp)` hesablayır, növün hüdudlarında dolanır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 olduğundan, exp 1 olmalıdır.
            // İstifadənin son biti ilə ayrı-ayrılıqda məşğul olun, çünki bazanı kvadrat şəklində düzəltmək lazım deyil və ehtiyacsız bir daşqına səbəb ola bilər.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` hesablayır
        ///
        /// Aritmetik daşqının baş verəcəyini göstərən bir mantıksal ilə birlikdə əlavənin toplağını qaytarır.
        /// Daşma baş verərsə, bükülmüş dəyər qaytarılır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` hesablayır
        ///
        /// Aritmetik daşqının baş verəcəyini göstərən bir məntiqi ilə birlikdə çıxarma toplağını qaytarır.
        /// Daşma baş verərsə, bükülmüş dəyər qaytarılır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` və `rhs`-nin vurulmasını hesablayır.
        ///
        /// Aritmetik daşqının baş verəcəyini göstərən bir boole ilə birlikdə vurmanın bir toplunu qaytarır.
        /// Daşma baş verərsə, bükülmüş dəyər qaytarılır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// Xahiş edirik unutmayın ki, bu nümunə tam ədədlər arasında bölüşdürülür.
        /// Burada `u32`-in niyə istifadə olunduğunu izah edir.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs`-ə bölündüyündə böləni hesablayır.
        ///
        /// Aritmetik daşqının baş verəcəyini göstərən bir boole ilə birlikdə bölücünün toplağını qaytarır.
        /// Qeyd edək ki, imzasız tam ədədlər üçün heç vaxt daşma baş vermir, buna görə ikinci dəyər həmişə `false`-dir.
        ///
        /// # Panics
        ///
        /// `rhs` 0 olduqda bu funksiya panic olacaqdır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Öklid bölməsinin `self.div_euclid(rhs)` hissəsini hesablayır.
        ///
        /// Aritmetik daşqının baş verəcəyini göstərən bir boole ilə birlikdə bölücünün toplağını qaytarır.
        /// Qeyd edək ki, imzasız tam ədədlər üçün heç vaxt daşma baş vermir, buna görə ikinci dəyər həmişə `false`-dir.
        /// Müsbət tam ədədlər üçün bölmənin bütün ümumi tərifləri bərabər olduğundan, bu, tamamilə `self.overflowing_div(rhs)`-ə bərabərdir.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 olduqda bu funksiya panic olacaqdır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` `rhs`-ə bölünəndə qalığı hesablayır.
        ///
        /// Bir aritmetik daşqının baş verəcəyini göstərən bir boole ilə bölündükdən sonra qalıq bir toplu qaytarır.
        /// Qeyd edək ki, imzasız tam ədədlər üçün heç vaxt daşma baş vermir, buna görə ikinci dəyər həmişə `false`-dir.
        ///
        /// # Panics
        ///
        /// `rhs` 0 olduqda bu funksiya panic olacaqdır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Qalan `self.rem_euclid(rhs)`-ni sanki Öklid bölgüsü ilə hesablayır.
        ///
        /// Bir arifmetik daşqının baş verəcəyini göstərən bir boole ilə bölündükdən sonra modulun bir qapağını qaytarır.
        /// Qeyd edək ki, imzasız tam ədədlər üçün heç vaxt daşma baş vermir, buna görə ikinci dəyər həmişə `false`-dir.
        /// Müsbət tam ədədlər üçün bölmənin bütün ümumi tərifləri bərabər olduğundan bu əməliyyat tamamilə `self.overflowing_rem(rhs)`-ə bərabərdir.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 olduqda bu funksiya panic olacaqdır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Doldurma şəklində özünə mənfi təsir göstərir.
        ///
        /// Bu imzasız dəyərin inkarını təmsil edən dəyəri qaytarmaq üçün sarma əməliyyatlarından istifadə edərək `!self + 1` qaytarır.
        /// Qeyd edək ki, pozitiv imzasız dəyərlər üçün hər zaman daşqın olur, ancaq 0-ı inkar etmək daşmaz.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` bit tərəfindən buraxılan özünü dəyişdirir.
        ///
        /// Keçid dəyərinin bit sayından daha böyük və ya bərabər olduğunu göstərən bir boole ilə birlikdə özünün sürüşdürülmüş versiyasının bir nişanını qaytarır.
        /// Dəyişmə dəyəri çox böyükdürsə, dəyər (N-1) maskalanır, burada N bit sayıdır və bu dəyər keçidi yerinə yetirmək üçün istifadə olunur.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Özünü `rhs` bitlə dəyişdirir.
        ///
        /// Keçid dəyərinin bit sayından daha böyük və ya bərabər olduğunu göstərən bir boole ilə birlikdə özünün sürüşdürülmüş versiyasının bir nişanını qaytarır.
        /// Dəyişmə dəyəri çox böyükdürsə, dəyər (N-1) maskalanır, burada N bit sayıdır və bu dəyər keçidi yerinə yetirmək üçün istifadə olunur.
        ///
        /// # Examples
        ///
        /// Əsas istifadə
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Kvadraya vuraraq eksponentləşdirmədən istifadə edərək özünü `exp` gücünə qaldırır.
        ///
        /// Daşmanın baş verib-vermədiyini göstərən bool ilə birlikdə eksponentləşdirmə römorkunu qaytarır.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, doğru));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Doldurma_mul nəticələrini saxlamaq üçün cızıq boşluğu.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 olduğundan, exp 1 olmalıdır.
            // İstifadənin son biti ilə ayrı-ayrılıqda məşğul olun, çünki bazanı kvadrat şəklində düzəltmək lazım deyil və ehtiyacsız bir daşqına səbəb ola bilər.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Kvadraya vuraraq eksponentləşdirmədən istifadə edərək özünü `exp` gücünə qaldırır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 olduğundan, exp 1 olmalıdır.
            // İstifadənin son biti ilə ayrı-ayrılıqda məşğul olun, çünki bazanı kvadrat şəklində düzəltmək lazım deyil və ehtiyacsız bir daşqına səbəb ola bilər.
            //
            //
            acc * base
        }

        /// Öklid bölünməsini həyata keçirir.
        ///
        /// Müsbət tam ədədlər üçün bölmənin bütün ümumi tərifləri bərabər olduğundan, bu, tamamilə `self / rhs`-ə bərabərdir.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 olduqda bu funksiya panic olacaqdır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)`-nin ən az qalığını hesablayır.
        ///
        /// Müsbət tam ədədlər üçün bölmənin bütün ümumi tərifləri bərabər olduğundan, bu, tamamilə `self % rhs`-ə bərabərdir.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 olduqda bu funksiya panic olacaqdır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Yalnız bir az `k` üçün `self == 2^k` olduqda `true` qaytarır.
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // İkisinin növbəti gücündən birinə az qaytarır.
        // (8u8 üçün ikinin növbəti gücü 8u8 və 6u8 üçün 8u8-dir)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Bu metod, aça bilməz, çünki `next_power_of_two` daşqın vəziyyətində, bunun əvəzinə tipin maksimum dəyərini qaytarır və 0 üçün 0 qaytara bilər.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // TƏHLÜKƏSİZLİK: `p > 0` olduğundan tamamilə öndə gedən sıfırlardan ibarət ola bilməz.
            // Bu, dəyişmənin həmişə sərhəddə olduğu və mübahisənin sıfır olmadığı zaman bəzi prosessorların (intel pre-haswell kimi) daha səmərəli ctlz daxili xüsusiyyətlərinə sahib olması deməkdir.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self`-dən böyük və ya bərabər olan ikisinin ən kiçik gücünü qaytarır.
        ///
        /// Dönüş dəyəri daşdıqda (yəni `uN` tipi üçün `self > (1 << (N-1))`), deboq rejimində panics və buraxılış rejimində qaytarma dəyəri 0-a bükülür (metodun 0-a qayıda biləcəyi yeganə vəziyyət).
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n`-dən böyük və ya bərabər olan ikisinin ən kiçik gücünü qaytarır.
        /// Əgər ikisinin növbəti gücü tipin maksimum dəyərindən çoxdursa, `None` qaytarılır, əks halda ikisinin gücü `Some`-ə bükülür.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n`-dən böyük və ya bərabər olan ikisinin ən kiçik gücünü qaytarır.
        /// İkisinin növbəti gücü tipin maksimum dəyərindən böyükdürsə, qaytarma dəyəri `0`-ə bükülür.
        ///
        ///
        /// # Examples
        ///
        /// Əsas istifadə:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Bu tam ədədin yaddaş təqdimatını bir bayt massivi olaraq böyük endian (network) bayt sırasına qaytarın.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Bu tam ədədin yaddaş təqdimatını bayt sıra kimi az-endian bayt sırasına qaytarın.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Bu tam ədədin yaddaş təqdimatını bayt sırası ilə bir bayt massivi kimi qaytarın.
        ///
        /// Hədəf platformanın yerli endianness istifadə edildiyi üçün, portativ kod yerinə uyğun olaraq [`to_be_bytes`] və ya [`to_le_bytes`] istifadə etməlidir.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bayt, əgər cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } başqa {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // TƏHLÜKƏSİZLİK: const səsi, çünki tam ədədlər düz köhnə məlumat tipləridir, buna görə hər zaman edə bilərik
        // onları bayt massivlərinə dəyişdirin
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // TƏHLÜKƏSİZLİK: tam ədədlər düz köhnə məlumat tipləridir, beləliklə onları daima dəyişə bilərik
            // bayt massivləri
            unsafe { mem::transmute(self) }
        }

        /// Bu tam ədədin yaddaş təqdimatını bayt sırası ilə bir bayt massivi kimi qaytarın.
        ///
        ///
        /// [`to_ne_bytes`] mümkün olduqda bundan üstün tutulmalıdır.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// bayt= num.as_ne_bytes();
        /// assert_eq!(
        ///     bayt, əgər cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } başqa {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // TƏHLÜKƏSİZLİK: tam ədədlər düz köhnə məlumat tipləridir, beləliklə onları daima dəyişə bilərik
            // bayt massivləri
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Böyük endianda bir bayt massivi kimi təmsil olunduğundan yerli endian tamsayı dəyəri yaradın.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto istifadə edin;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * giriş=istirahət;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Kiçik endian'da bir bayt massivi kimi təqdimatından yerli endian tamsayı dəyəri yaradın.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto istifadə edin;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * giriş=istirahət;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Yaddaş nümayəndəliyindən yerli endiannessdə bir bayt massivi olaraq yerli endian tam ədədi dəyəri yaradın.
        ///
        /// Hədəf platformanın yerli endianness istifadə edildiyi üçün, portativ kod, ehtimal ki, yerinə uyğun olaraq [`from_be_bytes`] və ya [`from_le_bytes`] istifadə etmək istəyir.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } başqa {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto istifadə edin;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * giriş=istirahət;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // TƏHLÜKƏSİZLİK: const səsi, çünki tam ədədlər düz köhnə məlumat tipləridir, buna görə hər zaman edə bilərik
        // onlara dəyişdirin
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // TƏHLÜKƏSİZLİK: tam ədədlər düz köhnə məlumat tipləridir, ona görə də hər zaman onları dəyişdirə bilərik
            unsafe { mem::transmute(bytes) }
        }

        /// Yeni kod istifadə etməyi üstün tutmalıdır
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Bu tam sayı ilə təmsil oluna bilən ən kiçik dəyəri qaytarır.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Yeni kod istifadə etməyi üstün tutmalıdır
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Bu tamsayı növü ilə təmsil oluna bilən ən böyük dəyəri qaytarır.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}