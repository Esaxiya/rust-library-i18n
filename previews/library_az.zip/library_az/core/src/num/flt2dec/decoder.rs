//! Üzən nöqtə dəyərini ayrı-ayrı hissələrə və səhv aralıklarına ayırır.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodlaşdırılmış imzasız sonlu dəyər, belə ki:
///
/// - İlkin dəyər `mant * 2^exp`-ə bərabərdir.
///
/// - `(mant - minus)*2^exp`-dən `(mant + plus)* 2^exp`-dək hər hansı bir rəqəm ilkin dəyərə doğru çevriləcəkdir.
/// Aralıq yalnız `inclusive` `true` olduqda daxil edilir.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Miqyaslı mantissa.
    pub mant: u64,
    /// Aşağı səhv aralığı.
    pub minus: u64,
    /// Üst səhv aralığı.
    pub plus: u64,
    /// Baza 2-də paylaşılan eksponent.
    pub exp: i16,
    /// Xəta diapazonu daxil olduqda doğrudur.
    ///
    /// IEEE 754-də, orijinal mantissa bərabər olduqda bu doğrudur.
    pub inclusive: bool,
}

/// İmzasız dəyər deşifrə edildi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Həm müsbət, həm də mənfi sonsuzluqlar.
    Infinite,
    /// Sıfır ya müsbət, ya da mənfi.
    Zero,
    /// Daha çox dekodlanmış sahələri olan sonlu rəqəmlər.
    Finite(Decoded),
}

/// `Deşifrə`d ola bilən üzən nöqtə növü.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimum müsbət normallaşdırılmış dəyər.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Verilən üzən nöqtə sayından bir işarə (mənfi olduqda doğru) və `FullDecoded` dəyərini qaytarır.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // qonşular: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode həmişə eksponenti qoruyur, buna görə mantissa subnormals üçün miqyaslanır.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // qonşular: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // burada maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // qonşular: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}