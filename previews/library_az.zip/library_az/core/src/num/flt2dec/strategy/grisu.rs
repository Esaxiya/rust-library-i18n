//! Grisu3 alqoritminin Rust uyğunlaşması "Üzən Nöqtəli Ədədlərin Tamamla Tez və Dəqiqlıqla Çap edilməsi" [^ 1].
//! Təxminən 1KB hesablanmış cədvəldən istifadə edir və öz növbəsində əksər girişlər üçün çox sürətli olur.
//!
//! [^1]: Florian Loitsch.2010. Üzən nöqtəli nömrələrin sürətlə çap edilməsi və
//!   tam ədədlərlə dəqiq.Nişan deyil.45, 6 (iyun 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// əsaslandırılması üçün `format_shortest_opt`-də şərhlərə baxın.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` verildikdə, `(k, 10^k)`-i `10^k <= x < 10^(k+1)`-ə bərabər qaytarır.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Grisu üçün ən qısa rejim tətbiqi.
///
/// Əks təqdirdə qeyri-dəqiq bir nümayişi qaytardığı zaman `None` qaytarır.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // ən az üç bit əlavə dəqiqliyə ehtiyacımız var

    // paylaşılan göstərici ilə normallaşdırılmış dəyərlərlə başlayın
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // `ALPHA <= minusk + plus.e + 64 <= GAMMA` qədər `cached = 10^minusk` tapın.
    // `plus` normallaşdığından, bu `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` deməkdir;
    // `ALPHA` və `GAMMA` seçimlərimizi nəzərə alsaq, bu `plus * cached` i `[4, 2^32)`-ə qoyur.
    //
    // açıq şəkildə `GAMMA - ALPHA`-i maksimum dərəcədə artırmaq istənilir, beləliklə 10-luq çox önbelleğe alınmış gücə ehtiyacımız yoxdur, amma bəzi fikirlər var:
    //
    //
    // 1. `floor(plus * cached)`-i `u32`-də saxlamaq istəyirik, çünki bahalı bir bölməyə ehtiyac duyur.
    //    (bu həqiqətən qaçılmazdır, dəqiqliyin qiymətləndirilməsi üçün qalıq tələb olunur.)
    // 2.
    // qalan `floor(plus * cached)` dəfələrlə 10-a vurulur və daşmamalıdır.
    //
    // birincisi `64 + GAMMA <= 32`, ikincisi `10 * 2^-ALPHA <= 2^64` verir;
    // -60 və -32 bu məhdudiyyət ilə maksimum aralıqdır və V8 bunlardan da istifadə edir.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // miqyaslı fps.bu, 1 ulp maksimum səhvini verir (5.1 Teoremindən sübut edilmişdir).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-mənfi faktiki aralıq
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus`-dən yuxarı, `v` və `plus`*kəmiyyət* yaxınlaşmalardır (səhv <1 ulp).
    // Səhvin müsbət və ya mənfi olduğunu bilmədiyimiz üçün bərabər şəkildə yerləşdirilmiş iki təxmini istifadə edirik və maksimum səhv 2 ulps olur.
    //
    // "unsafe region", əvvəlcə yaratdığımız bir liberal intervaldır.
    // "safe region" yalnız qəbul etdiyimiz mühafizəkar bir intervaldır.
    // Təhlükəsiz bölgədə doğru repr ilə başlayırıq və təhlükəsiz bölgədə olan `v`-ə ən yaxın repr tapmağa çalışırıq.
    // bacarmırıqsa, imtina edirik.
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f, 1;//yalnız izahat üçün minus0 = minus.f + 1;//yalnız izahat üçün
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // paylaşılan eksponent

    // `plus1`-i inteqral və kəsr hissələrə bölmək.
    // ayrılmaz hissələrin u32-ə sığacağına zəmanət verilir, çünki önbelleğe alınan güc `plus < 2^32` və normallaşdırılmış `plus.f`-in dəqiqlik tələbinə görə həmişə `2^64 - 2^4`-dən az olmasına zəmanət verir.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ən böyük `10^max_kappa`-i `plus1`-dən çox olmayan hesablayın (beləliklə `plus1 < 10^(max_kappa+1)`).
    // bu aşağıda `kappa`-nin yuxarı sərhədidir.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorem 6.2: əgər `k` ən böyük tam ədədi olarsa
    // `0 <= y mod 10^k <= y - x`,              onda `V = floor(y / 10^k) * 10^k` `[x, y]`-də və bu aralığın ən qısa təsvirlərindən biridir (minimum rəqəmlərin sayı ilə).
    //
    //
    // 6.2 teoreminə görə `(minus1, plus1)` arasında `kappa` rəqəm uzunluğunu tapın.
    // 6.2 teoremi əvəzinə `y mod 10^k < y - x` tələb etməklə `x`-i xaric etmək üçün qəbul edilə bilər.
    // (məsələn, `x` =32000, `y` =32777; `kappa` =2 bəri `y mod 10 ^ 3=777 <y, x=777`.) alqoritm `y`-ni xaric etmək üçün sonrakı doğrulama mərhələsinə əsaslanır.
    //
    let delta1 = plus1 - minus1;
    // delta1int=(delta1>> e) istifadə kimi istifadə edək;//yalnız izahat üçün
    let delta1frac = delta1 & ((1 << e) - 1);

    // hər addımda dəqiqliyi yoxlayarkən ayrılmaz hissələri göstərin.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // rəqəmlər göstərilməyib
    loop {
        // `plus1 >= 10^kappa` dəyişməzləri kimi göstərmək üçün həmişə ən azı bir rəqəmimiz var:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (buradan `remainder = plus1int % 10^(kappa+1)` çıxır)
        //
        //

        // `remainder`-i `10^kappa`-ə bölün.hər ikisi `2^-e` ilə ölçülür.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; doğru `kappa` tapdıq.
            let ten_kappa = (ten_kappa as u64) << e; // miqyaslı 10 ^ kappa paylaşılan eksponentə qayıt
            return round_and_weed(
                // TƏHLÜKƏSİZLİK: yuxarıdakı yaddaşı işə saldıq.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // bütün inteqral rəqəmləri göstərdiyimiz zaman döngəni pozun.
        // rəqəmlərin dəqiq sayı `plus1 < 10^(max_kappa+1)` olaraq `max_kappa + 1`-dir.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // dəyişməzləri bərpa edin
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // hər addımda dəqiqliyi yoxlanarkən kəsr hissələrini göstərin.
    // bu dəfə bölünmənin dəqiqliyini itirəcəyi üçün təkrar vurmalara etibar edirik.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // növbəti rəqəm, `m = max_kappa + 1` (ayrılmaz hissədəki rəqəmlər) olduğu dəyişməzləri sınamadan əvvəl sınadığımız üçün əhəmiyyətli olmalıdır.
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // daşmayacaq, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder`-i `10^kappa`-ə bölün.
        // hər ikisi `2^e / 10^kappa` ilə ölçülür, buna görə sonuncusu burada örtülüdür.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // gizli bölücü
            return round_and_weed(
                // TƏHLÜKƏSİZLİK: yuxarıdakı yaddaşı işə saldıq.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // dəyişməzləri bərpa edin
        kappa -= 1;
        remainder = r;
    }

    // `plus1`-in bütün əhəmiyyətli rəqəmlərini yaratdıq, lakin bunun optimal rəqəm olduğuna əmin deyilik.
    // məsələn, `minus1` 3.14153 ... və `plus1` 3.14158 ... olduqda, 3.14154-dən 3.14158-ə qədər 5 ən qısa təsvir var, ancaq bizdə ən böyüyü var.
    // ardıcıl olaraq son rəqəmi azaltmalı və bunun ən yaxşı repr olub olmadığını yoxlamalıyıq.
    // ən çox 9 namizəd var (..1-..9), buna görə də bu olduqca sürətlidir.("rounding" fazası)
    //
    // funksiya bu "optimal" repr-nin həqiqətən ulp aralığında olub olmadığını yoxlayır və "second-to-optimal" repr-nin yuvarlaqlaşdırma səhvinə görə həqiqətən optimal ola biləcəyini də yoxlayır.
    // hər iki halda da bu `None` qaytarır.
    // ("weeding" fazası)
    //
    // buradakı bütün mübahisələr ümumi (lakin gizli) `k` dəyəri ilə ölçülür, belə ki:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (və həmçinin, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (və əvvəlki dəyişməzlərdən `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 xoralar içərisində `v` (əslində `plus1 - v`) ilə iki yaxınlaşma yaradın.
        // nəticələnən nümayəndəlik hər ikisinə ən yaxın nümayəndəlik olmalıdır.
        //
        // burada `plus1 - v` istifadə olunur, çünki overflow/underflow-dən qaçmaq üçün `plus1`-ə münasibətdə hesablamalar aparılır (adları dəyişdirilmiş kimi görünür).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // son rəqəmi azaldın və `v + 1 ulp`-ə ən yaxın nümayəndəlikdə dayandırın.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // əvvəlcə `plus1 - plus1 % 10^kappa`-ə bərabər olan təxmini `w(n)` rəqəmləri ilə işləyirik.loop gövdəsini `n` dəfə işlədikdən sonra, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa`-i təyin etdik (beləliklə yoxlamaları asanlaşdırmaq üçün qalıq= plus1w(0)`).
            // `plus1w(n)`-in daim artdığını unutmayın.
            //
            // xitam vermək üçün üç şərtimiz var.bunlardan hər hansı biri döngüyü davam etdirə bilməyəcək, ancaq bundan sonra `v + 1 ulp`-ə ən yaxın olduğu bilinən ən azı bir etibarlı nümayəndəliyimiz var.
            // qısalıq üçün onları TC1-dən TC3-ə kimi göstərəcəyik.
            //
            // TC1: `w(n) <= v + 1 ulp`, yəni bu, ən yaxın olan son repr.
            // bu, `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`-ə bərabərdir.
            // TC2 ilə birlikdə (`w(n+1)` is valid) olub olmadığını yoxlayır, bu `plus1w(n)` hesablanmasında mümkün daşqının qarşısını alır.
            //
            // TC2: `w(n+1) < minus1`, yəni növbəti repr mütləq `v`-ə dəymir.
            // bu, `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`-ə bərabərdir.
            // sol tərəf daşa bilər, ancaq `threshold > plus1v`-i bilirik, buna görə TC1 yalan olarsa, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` və bunun əvəzinə `threshold - plus1w(n) < 10^kappa` olub olmadığını test edə bilərik.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, yəni növbəti repr
            // `v + 1 ulp`-ə mövcud repr-dən daha yaxın deyil.
            // verilən `z(n) = plus1v_up - plus1w(n)`, bu `abs(z(n)) <= abs(z(n+1))` olur.yenə də TC1-in yalan olduğunu fərz edərək, bizdə `z(n) > 0` var.nəzərdən keçirməli iki işimiz var:
            //
            // - `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)` olduqda.
            // `plus1w(n)` artdıqca, `z(n)` azalmalı və bu açıq-aşkar yanlışdır.
            // - `z(n+1) < 0` olduqda:
            //   - TC3a: ilkin şərt `plus1v_up < plus1w(n) + 10^kappa`-dir.TC2-in yalan olduğunu, `threshold >= plus1w(n) + 10^kappa` olduğu üçün daşmağı bacara bilməz.
            //   - TC3b: TC3 `z(n) <= -z(n+1)` olur, yəni `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   inkar edilmiş TC1 `plus1v_up > plus1w(n)` verir, buna görə TC3a ilə birləşdikdə aşıb-aça bilməz.
            //
            // dolayısıyla `TC1 || TC2 || (TC3a && TC3b)` olduğunda dayanmalıyıq.aşağıdakı onun tərsinə bərabərdir, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ən qısa təkrar `0` ilə bitə bilməz
                plus1w += ten_kappa;
            }
        }

        // bu nümayəndəliyin `v - 1 ulp`-ə ən yaxın nümayəndəliyi olub olmadığını yoxlayın.
        //
        // bu, sadəcə `v + 1 ulp` üçün sonlandırma şərtləri ilə eynidir, əksinə bütün `plus1v_up` əvəzinə `plus1v_down` ilə əvəz olunur.
        // daşqın analizi bərabər tutur.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // indi `plus1` ilə `minus1` arasında `v`-ə ən yaxın nümayəndəliyimiz var.
        // bu çox liberaldır, buna görə `plus0` ilə `minus0` arasında, yəni `plus1 - plus1w(n) <= minus0` və ya `plus1 - plus1w(n) >= plus0` arasında olmayan hər hansı bir `w(n)`-i rədd edirik.
        // `threshold = plus1 - minus1` və `plus1 - plus0 = minus0 - minus1 = 2 ulp` faktlarından istifadə edirik.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Dragon geri dönüşü olan Grisu üçün ən qısa rejim tətbiqi.
///
/// Bu, əksər hallarda istifadə olunmalıdır.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // TƏHLÜKƏSİZLİK: Borc yoxlayıcısı `buf` istifadə etməyimiz üçün ağıllı deyil
    // ikinci branch-də, buna görə ömrü burada yuyuruq.
    // Ancaq `buf`-i yalnız `format_shortest_opt` `None`-i qaytardığı təqdirdə yenidən istifadə edirik, belə ki bu yaxşıdır.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Grisu üçün dəqiq və sabit rejim tətbiqi.
///
/// Əks təqdirdə qeyri-dəqiq bir nümayişi qaytardığı zaman `None` qaytarır.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // ən az üç bit əlavə dəqiqliyə ehtiyacımız var
    assert!(!buf.is_empty());

    // normallaşdırın və `v` miqyasını.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v`-i inteqral və kəsr hissələrə bölmək.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // həm köhnə `v`, həm də yeni `v` (`10^-k` ilə ölçüldü) <1 ulp (Teorem 5.1) səhvinə malikdir.
    // Səhvin müsbət və ya mənfi olduğunu bilmədiyimiz üçün bərabər şəkildə yerləşdirilmiş iki təxmini istifadə edirik və maksimum səhv 2 ulps (ən qısa vəziyyətlə eyni) olur.
    //
    //
    // məqsəd həm `v - 1 ulp`, həm də `v + 1 ulp` üçün ortaq olan tam yuvarlaq rəqəmləri tapmaqdır, beləliklə maksimum dərəcədə özümüzə əminik.
    // bu mümkün deyilsə, `v` üçün hansının doğru çıxdığını bilmirik, buna görə imtina edib geri qayıdırıq.
    //
    // `err` burada `1 ulp * 2^e` olaraq təyin edilir (`vfrac`-də ulp ilə eyni) və `v` miqyaslandıqca onu ölçüyə qoyacağıq.
    //
    //
    //
    let mut err = 1;

    // ən böyük `10^max_kappa`-i `v`-dən çox olmayan hesablayın (beləliklə `v < 10^(max_kappa+1)`).
    // bu aşağıda `kappa`-nin yuxarı sərhədidir.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // son rəqəm məhdudiyyəti ilə işləyiriksə, ikiqat yuvarlaqlaşdırmanın qarşısını almaq üçün həqiqi göstərilmədən əvvəl buferi qısaltmalıyıq.
    //
    // yuvarlaqlaşdırma baş verəndə buferi yenidən böyütməliyik!
    let len = if exp <= limit {
        // Ups,*bir* rəqəmi belə istehsal edə bilmərik.
        // bu, 9.5 kimi bir şey əldə etdiyimiz və 10-a yuvarlandığı zaman mümkündür.
        //
        // prinsipcə dərhal boş bir tamponla `possibly_round`-yə zəng edə bilərik, lakin `max_ten_kappa << e`-in 10-a ölçülməsi daşqına səbəb ola bilər.
        //
        // Beləliklə, burada təmkinli davranırıq və səhv aralığını 10 dəfə artırırıq.
        // bu saxta mənfi dərəcəni artıracaq, ancaq çox,*çox* biraz;
        // mantisanın 60 bitdən çox olduğu zaman yalnız nəzərəçarpacaq dərəcədə əhəmiyyətli ola bilər.
        //
        // TƏHLÜKƏSİZLİK: `len=0`, bu səbəbdən bu yaddaşın başlanğıc edilməsi vacibdir.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // ayrılmaz hissələr göstərmək.
    // səhv tamamilə kəsrlidir, ona görə də bu hissədə yoxlamağımıza ehtiyac yoxdur.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // rəqəmlər göstərilməyib
    loop {
        // dəyişməzlər göstərmək üçün həmişə ən azı bir rəqəmimiz var:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (buradan `remainder = vint % 10^(kappa+1)` çıxır)
        //
        //

        // `remainder`-i `10^kappa`-ə bölün.hər ikisi `2^-e` ilə ölçülür.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bufer doludur?yuvarlaqlaşdırma keçidini qalıqla aparın.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // TƏHLÜKƏSİZLİK: `len` çox bayt hazırladıq.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // bütün inteqral rəqəmləri göstərdiyimiz zaman döngəni pozun.
        // rəqəmlərin dəqiq sayı `plus1 < 10^(max_kappa+1)` olaraq `max_kappa + 1`-dir.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // dəyişməzləri bərpa edin
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // kəsirli hissələr göstərmək.
    //
    // prinsipcə mövcud son rəqəmə davam edə bilərik və düzgünlüyünü yoxlaya bilərik.
    // təəssüf ki, sonlu ölçülü tam ədədlərlə işləyirik, buna görə də daşqını aşkarlamaq üçün bir neçə meyara ehtiyacımız var.
    // V8 `remainder > err` istifadə edir, bu `v - 1 ulp` və `v`-in ilk `i` əhəmiyyətli rəqəmləri fərqləndikdə yalan olur.
    // lakin bu, başqa bir çox etibarlı girişi rədd edir.
    //
    // sonrakı mərhələ düzgün daşqın aşkarlamasına sahib olduğundan, daha sıx kriteriyanı istifadə edirik:
    // `err`-dən `10^kappa / 2`-i keçməyə davam edirik, beləliklə `v - 1 ulp` və `v + 1 ulp` arasındakı aralıq mütləq iki və ya daha çox yuvarlaq təsviri ehtiva edir.
    //
    // istinad üçün `possibly_round`-dən alınan ilk iki müqayisə ilə eynidir.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // dəyişməzlər, burada `m = max_kappa + 1` (ayrılmaz hissədəki rəqəm):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // daşmayacaq, `2^e * 10 < 2^64`
        err *= 10; // daşmayacaq, `err * 10 < 2^e * 5 < 2^64`

        // `remainder`-i `10^kappa`-ə bölün.
        // hər ikisi `2^e / 10^kappa` ilə ölçülür, buna görə sonuncusu burada örtülüdür.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bufer doludur?yuvarlaqlaşdırma keçidini qalıqla aparın.
        if i == len {
            // TƏHLÜKƏSİZLİK: `len` çox bayt hazırladıq.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // dəyişməzləri bərpa edin
        remainder = r;
    }

    // əlavə hesablama faydasızdır (`possibly_round` mütləq uğursuz olur), buna görə imtina edirik.
    return None;

    // `v`-in bütün tələb olunan rəqəmlərini yaratdıq, bu da `v - 1 ulp`-in müvafiq rəqəmləri ilə eyni olmalıdır.
    // indi həm `v - 1 ulp`, həm də `v + 1 ulp` tərəfindən paylaşılan unikal bir nümayəndəliyin olub olmadığını yoxlayırıq;bu, yaradılan rəqəmlərlə və ya bu rəqəmlərin yuvarlaqlaşdırılmış versiyası ilə eyni ola bilər.
    //
    // aralıq eyni uzunluğun birdən çox təsvirini ehtiva edirsə, əmin ola bilmərik və bunun yerinə `None` qaytarmalıyıq.
    //
    // buradakı bütün mübahisələr ümumi (lakin gizli) `k` dəyəri ilə ölçülür, belə ki:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // TƏHLÜKƏSİZLİK: ilk `len` bayt `buf` başlanğıc vəziyyətinə gətirilməlidir.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (istinad üçün nöqtəli xətt, verilən rəqəm sayında mümkün təsvirlər üçün dəqiq dəyəri göstərir.)
        //
        //
        // `v - 1 ulp` və `v + 1 ulp` arasında ən azı üç mümkün nümayəndəliyin olduğu üçün səhv çox böyükdür.
        // hansının doğru olduğunu müəyyən edə bilmirik.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // əslində 1/2 ulp iki mümkün nümayəndəliyi təqdim etmək üçün kifayətdir.
        // (həm `v - 1 ulp`, həm də "v + 1 ulp" üçün unikal bir nümayəndəliyə ehtiyacımız olduğunu unutmayın.) bu ilk yoxlamadan `ulp < ten_kappa` kimi daşmayacaq.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // əgər `v + 1 ulp` yuvarlaqlaşdırılmış nümayəndəliyə daha yaxındırsa (bu artıq `buf`-dədir), o zaman etibarlı şəkildə geri qayıda bilərik.
        // `v - 1 ulp` * indiki göstəricidən az ola biləcəyini unutmayın; lakin `1 ulp < 10^kappa / 2` olaraq bu şərt kifayətdir:
        // `v - 1 ulp` ilə cari nümayəndəlik arasındakı məsafə `10^kappa / 2`-dən çox ola bilməz.
        //
        // şərt `remainder + ulp < 10^kappa / 2`-ə bərabərdir.
        // asanlıqla aça biləcəyi üçün əvvəlcə `remainder < 10^kappa / 2` olub olmadığını yoxlayın.
        // `ulp < 10^kappa / 2`-i təsdiqləmişik, belə ki `10^kappa` axırda daşmadığı müddətdə, ikinci yoxlama yaxşıdır.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // TƏHLÜKƏSİZLİK: zəng edənimiz bu yaddaşı işə saldı.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------qalıq------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // digər tərəfdən, `v - 1 ulp` yuvarlaqlaşdırılmış nümayəndəliyə daha yaxındırsa, yuvarlanıb qayıtmalıyıq.
        // eyni səbəbdən `v + 1 ulp`-i yoxlamağımıza ehtiyac yoxdur.
        //
        // şərt `remainder - ulp >= 10^kappa / 2`-ə bərabərdir.
        // yenə də əvvəlcə `remainder > ulp` olub olmadığını yoxlayırıq (`remainder >= ulp` heç vaxt sıfır olmadığına görə bunun `remainder >= ulp` olmadığını unutmayın).
        //
        // `remainder - ulp <= 10^kappa`-ni də unutmayın, buna görə ikinci çek daşmaz.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // TƏHLÜKƏSİZLİK: zəng edənimiz bu yaddaşı işə salmış olmalıdır.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // yalnız sabit dəqiqlik tələb edildikdə əlavə bir rəqəm əlavə edin.
                // orijinal tampon boş olsaydı, əlavə rəqəmin yalnız `exp == limit` (edge halında) əlavə edilə biləcəyini yoxlamalıyıq.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // TƏHLÜKƏSİZLİK: biz və zəng edənimiz bu yaddaşı işə saldıq.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // əks halda biz məhkumuq (yəni `v - 1 ulp` ilə `v + 1 ulp` arasındakı bəzi dəyərlər yuvarlanır, bəziləri yuvarlanır) və imtina edirik.
        //
        None
    }
}

/// Dragon geri dönüşü ilə Grisu üçün dəqiq və sabit rejim tətbiqi.
///
/// Bu, əksər hallarda istifadə olunmalıdır.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // TƏHLÜKƏSİZLİK: Borc yoxlayıcısı `buf` istifadə etməyimiz üçün ağıllı deyil
    // ikinci branch-də, buna görə ömrü burada yuyuruq.
    // Ancaq `buf`-i yalnız `format_exact_opt` `None`-i qaytardığı təqdirdə yenidən istifadə edirik, belə ki bu yaxşıdır.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}