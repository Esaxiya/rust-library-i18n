//! İntegral növlərə çevrilmə üçün səhv növləri.

use crate::convert::Infallible;
use crate::fmt;

/// Yoxlanılan inteqral tipli dönüşüm uğursuz olduqda, səhv növü döndü.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Yuxarıdakı `From<Infallible> for TryFromIntError` kimi kodun `Infallible` `!` üçün bir təxəllüs halına gəldikdə işləməyə davam edəcəyinə əmin olmaq üçün məcbur etmək əvəzinə uyğunlaşdırın.
        //
        //
        match never {}
    }
}

/// Bir tam ədədi təhlil edərkən qaytarılacaq bir səhv.
///
/// Bu səhv, [`i8::from_str_radix`] kimi ibtidai tam say tiplərindəki `from_str_radix()` funksiyaları üçün səhv növü olaraq istifadə olunur.
///
/// # Potensial səbəblər
///
/// Digər səbəblər arasında, standart girişdən əldə edildikdə, məsələn, simli boşluqda qabaqcıl və ya arxada olduğu üçün `ParseIntError` atıla bilər.
///
/// [`str::trim()`] metodundan istifadə edərək təhlil etmədən əvvəl boşluğun qalmamasını təmin edir.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Bir tam ədədin təhlil edilməsinə səbəb ola biləcək müxtəlif növ səhvləri saxlamaq üçün enum.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Ayrışdırılan dəyər boşdur.
    ///
    /// Digər səbəblər arasında, bu variant boş bir simli təhlil edərkən qurulacaqdır.
    Empty,
    /// Kontekstində etibarsız bir rəqəm var.
    ///
    /// Digər səbəblər arasında, bu variant, ASCII olmayan bir char olan bir sətri analiz edərkən qurulacaqdır.
    ///
    /// Bu variant, bir `+` və ya `-` bir simli içərisində ya təkbaşına, ya da bir ədədin ortasında yerləşdirildikdə qurulur.
    ///
    ///
    InvalidDigit,
    /// Tamsayı hədəf tam sayda saxlamaq üçün çox böyükdür.
    PosOverflow,
    /// Tamsayı hədəf tam sayda saxlamaq üçün çox kiçikdir.
    NegOverflow,
    /// Dəyər sıfır idi
    ///
    /// Bu variant, təhlil sətri sıfır dəyərinə malik olduqda yayılacaq, bu sıfır olmayan növlər üçün qanunsuz olacaqdır.
    ///
    Zero,
}

impl ParseIntError {
    /// Bir tam ədədin ayrılmasının təfərrüatlı səbəbini çıxarır.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}