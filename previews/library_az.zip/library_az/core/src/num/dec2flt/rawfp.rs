//! Pozitiv IEEE 754-də bir az səhv.Mənfi rəqəmlər ələ alınmır və lazım deyil.
//! Normal üzən nöqtə nömrələri, (frac, exp) kimi bir kanonik təqdimata malikdir ki, dəyəri 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) olduğu yerdə N bit sayıdır).
//!
//! Subnormallar bir az fərqli və qəribədir, lakin eyni prinsip tətbiq olunur.
//!
//! Ancaq burada onları (sig, k) şəklində f pozitiv şəkildə təmsil edirik, belə ki dəyər f *
//! 2 <sup>e</sup> .Bu, "hidden bit"-ni açıq etməklə yanaşı, mantisya dəyişikliyi ilə göstəricini dəyişdirir.
//!
//! Başqa bir şəkildə desək, normalda üzənlər (1) olaraq yazılır, amma burada (2) kimi yazılır:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1)-yə **kəsrli nümayəndəliyə**, (2)-ə **inteqral nümayəndəliyə** deyirik.
//!
//! Bu moduldakı bir çox funksiya yalnız normal rəqəmlərlə işləyir.Dec2flt rutinləri mühafizəkar şəkildə çox kiçik və çox sayda üçün ümumdünya doğru yavaş yolu (Alqoritm M) tutur.
//! Bu alqoritmin alt normaları və sıfırları idarə edən yalnız next_float()-ə ehtiyacı var.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` və `f64` üçün bütün dönüşüm kodlarının təkrarlanmasının qarşısını almaq üçün bir köməkçi trait.
///
/// Bunun nə üçün lazım olduğunu öyrənmək üçün ana modulun sənəd şərhinə baxın.
///
/// Digər növlər üçün **heç vaxt** tətbiq edilməməli və ya dec2flt modulundan kənarda istifadə edilməlidir.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` və `from_bits` tərəfindən istifadə edilən tip.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Xam transmütasiyanı tam ədədə keçirir.
    fn to_bits(self) -> Self::Bits;

    /// Tam birdən xam transmütasiya həyata keçirir.
    fn from_bits(v: Self::Bits) -> Self;

    /// Bu sayın daxil olduğu kateqoriyanı qaytarır.
    fn classify(self) -> FpCategory;

    /// Mantisanı, eksponenti və işarəni tam ədəd olaraq qaytarır.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Şamandıranı deşifrə edir.
    fn unpack(self) -> Unpacked;

    /// Tam olaraq göstərilə bilən kiçik bir tam rəqəmdən atılır.
    /// Panic tam ədədi təmsil etmək mümkün deyilsə, bu moduldakı digər kod heç vaxt bunun baş verməməsinə əmin olur.
    fn from_int(x: u64) -> Self;

    /// Əvvəlcədən hesablanmış bir cədvəldən 10 <sup>e</sup> dəyərini alır.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` üçün Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ad nə deyir.
    /// Sərt kodlama daxili maddələrin hoqqabazlıq etməkdən və LLVM sabit qatlanmasını ümid etməkdən daha asandır.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Taşma və ya sıfır və ya istehsal edə bilməyən girişlərin ondalık rəqəmlərinə bağlı mühafizəkar
    /// subnormals.Yəqin ki, maksimum normal dəyərin ondalık göstəricisi, buna görə də ad.
    const MAX_NORMAL_DIGITS: usize;

    /// Ən əhəmiyyətli onluq rəqəmin bundan daha böyük bir yer dəyəri olduqda, rəqəm mütləq sonsuzluğa qədər yuvarlanır.
    ///
    const INF_CUTOFF: i64;

    /// Ən əhəmiyyətli onluq rəqəmin yer dəyəri bundan az olduqda, rəqəm mütləq sıfıra qədər yuvarlanır.
    ///
    const ZERO_CUTOFF: i64;

    /// Eksponentdəki bit sayı.
    const EXP_BITS: u8;

    /// Gizli bit daxil olmaqla * işarədəki bitlərin sayı.
    const SIG_BITS: u8;

    /// Gizli bitdən *istisna olmaqla* işarədəki bitlərin sayı.
    const EXPLICIT_SIG_BITS: u8;

    /// Kesirli təqdimatda maksimum qanuni göstərici.
    const MAX_EXP: i16;

    /// Subnormallar istisna olmaqla, fraksiya təmsilçiliyində minimum qanuni göstərici.
    const MIN_EXP: i16;

    /// `MAX_EXP` ayrılmaz təmsil üçün, yəni növbə tətbiq olunur.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodlanmış (yəni ofset qərəzli)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ayrılmaz təmsil üçün, yəni növbə tətbiq olunur.
    const MIN_EXP_INT: i16;

    /// İnteqral nümayəndəlikdə maksimum normallaşmış əhəmiyyət və.
    const MAX_SIG: u64;

    /// İnteqral nümayəndəlikdə minimum normallaşmış məna.
    const MIN_SIG: u64;
}

// #34344 üçün əsasən həll yolu.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mantisanı, eksponenti və işarəni tam ədəd olaraq qaytarır.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponent yanlılığı + mantissa dəyişməsi
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe, `as`-un bütün platformalarda düzgün bir şəkildə yuvarlanıb-vurulmadığına şübhə edir.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mantisanı, eksponenti və işarəni tam ədəd olaraq qaytarır.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponent yanlılığı + mantissa dəyişməsi
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe, `as`-un bütün platformalarda düzgün bir şəkildə yuvarlanıb-vurulmadığına şübhə edir.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp`-i ən yaxın maşın şamandıra növünə çevirir.
/// Subnormal nəticələri idarə etmir.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bitdir, buna görə xe'nin mantissa sürüşməsi 63 olur
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-bit işarəni, yarıdan cütə qədər T::SIG_BITS bitə qədər yuvarlaqlaşdırın.
/// Eksponent daşqınını idarə etmir.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Mantissa sürüşməsini tənzimləyin
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Normallaşdırılmış nömrələr üçün `RawFloat::unpack()`-in tərsinə.
/// Panics işarəsi və ya göstəricisi normallaşdırılmış rəqəmlər üçün etibarlı deyilsə.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Gizli biti çıxarın
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Eksponent qərəzi və mantissa dəyişməsi üçün göstəricini seçin
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+")-də işarə bitini buraxın, nömrələrimiz hamısı müsbətdir
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Subnormal qurun.0 mantisasına icazə verilir və sıfır qurur.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodlanmış eksponent 0, işarə biti 0, buna görə bitləri yenidən şərh etməliyik.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Bir Fp ilə bignum təxminən.0.5 ULP içərisində yarıdan cütə qədər.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // `start` indeksindən əvvəl bütün bitləri kəsdik, yəni `start` miqdarında effektiv sağa keçdik, bu da ehtiyac duyduğumuz göstəricidir.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Kəsilmiş bitlərdən asılı olaraq (half-to-even) dəyirmi.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Arqumentdən tamamilə kiçik olan ən böyük üzən nöqtə sayını tapır.
/// Subnormal, sıfır və ya eksponent altını idarə etmir.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Arqumentdən qat-qat böyük olan ən kiçik üzən nöqtə sayını tapın.
// Bu əməliyyat doymuşdur, yəni next_float(inf) ==inf.
// Bu moduldakı əksər kodlardan fərqli olaraq, bu funksiya sıfır, alt normalar və sonsuzluqları idarə edir.
// Lakin, buradakı bütün digər kodlar kimi NaN və mənfi rəqəmlərlə də məşğul olmur.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Bu həqiqət olmaq üçün çox yaxşı görünür, amma işləyir.
        // 0.0 sıfır söz olaraq kodlanır.Subnormals 0x000m ... m, burada m mantisadır.
        // Xüsusilə, ən kiçik subnormal 0x0 ... 01, ən böyüyü 0x000F ... F-dir.
        // Ən kiçik normal rəqəm 0x0010 ... 0 olduğu üçün bu künc qutusu da işləyir.
        // Artım mantissanı aşıbsa, daşıyıcı bit göstəricini istədiyimiz kimi artırır və mantissa bitləri sıfır olur.
        // Gizli bit konvensiyasına görə bu da tam olaraq istədiyimiz şeydir!
        // Nəhayət, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}