//! Kağızdan müxtəlif alqoritmlər.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp-də əhəmiyyət və bit sayı
const P: u32 = 64;

// Sadəcə *bütün* eksponentlər üçün ən yaxşı təxmini saxlayırıq, beləliklə dəyişən "h" və əlaqəli şərtlər buraxıla bilər.
// Bu, bir neçə kilobayt yer üçün performans göstərir.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Əksər arxitekturalarda üzən nöqtə əməliyyatları açıq bit ölçüsünə malikdir, bu səbəbdən hesablamanın dəqiqliyi əməliyyat başına müəyyən edilir.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86-də, SSE/SSE2 uzantıları mövcud deyilsə, x87 FPU şamandıra əməliyyatları üçün istifadə olunur.
// x87 FPU, varsayılan olaraq 80 bit dəqiqliklə işləyir, yəni əməliyyatlar dəyərlərin sonunda göstərildiyi zaman ikiqat yuvarlaqlaşmaya səbəb olan 80 bitə qədər yuvarlaqlaşdırılması deməkdir
//
// 32/64 bit float dəyərləri.Bunun öhdəsindən gəlmək üçün FPU nəzarət sözü elə edilə bilər ki, hesablamalar istənilən dəqiqliklə yerinə yetirilsin.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU nəzarət sözünün orijinal dəyərini qorumaq üçün istifadə olunan bir quruluş, struktur atıldıqda bərpa edilə bilər.
    ///
    ///
    /// x87 FPU, sahələri aşağıdakı kimi 16 bitlik bir qeyddir:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Bütün sahələr üçün sənədlər IA-32 Architectures Software Developer Təlimatında mövcuddur (Cild 1).
    ///
    /// Aşağıdakı kodla əlaqəli yeganə sahə PC, Həssas Nəzarətdir.
    /// Bu sahə FPU tərəfindən həyata keçirilən əməliyyatların dəqiqliyini təyin edir.
    /// Bunu qurmaq olar:
    ///  - 0b00, tək dəqiqlik, yəni 32-bit
    ///  - 0b10, ikiqat dəqiqlik, yəni 64 bit
    ///  - 0b11, ikiqat genişlənmiş dəqiqlik, yəni 80 bit (standart vəziyyət) 0b01 dəyəri qorunur və istifadə edilməməlidir.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // TƏHLÜKƏSİZLİK: `fldcw` təlimatı düzgün işləyə bilmək üçün yoxlanılmışdır
        // hər hansı bir `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM 8 və LLVM 9-u dəstəkləmək üçün ATT sintaksisindən istifadə edirik.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU-nun dəqiq sahəsini `T` olaraq təyin edir və bir `FPUControlWord` qaytarır.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` üçün uyğun olan Həssas Nəzarət sahəsi üçün dəyəri hesablayın.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // standart, 80 bit
        };

        // `FPUControlWord` quruluşu düşdükdə, daha sonra bərpa etmək üçün nəzarət sözünün orijinal dəyərini əldə edin GÜVƏNLİK: hər hansı bir `u16` ilə düzgün işləyə bilmək üçün `fnstcw` təlimatı yoxlanıldı.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM 8 və LLVM 9-u dəstəkləmək üçün ATT sintaksisindən istifadə edirik.
                options(att_syntax, nostack),
            )
        }

        // İdarə sözünü istədiyiniz dəqiqliyə uyğunlaşdırın.
        // Buna köhnə dəqiqliyi (bit 8 və 9, 0x300) gizlətmək və yuxarıda hesablanmış dəqiqlik bayrağı ilə əvəz etməklə nail olunur.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Maşın ölçülü tam ədədlərdən və üzənlərdən istifadə edən Bellerophonun sürətli yolu.
///
/// Bu, ayrı bir funksiyaya çıxarılır ki, bignum qurmadan əvvəl cəhd edilsin.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Dəqiq dəyəri sona yaxın MAX_SIG ilə müqayisə edirik, bu yalnız sürətli, ucuz bir rədddir (həmçinin kodun qalan hissəsini daşqından narahat olmaqdan azad edir).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Sürətli yol son dərəcə vacibdir ki, aritmetik heç bir ara yuvarlaqlaşdırma olmadan düzgün bit sayına qədər yuvarlaqlaşdırılır.
    // x86-də (SSE və ya SSE2 olmadan) bunun üçün x87 FPU yığınının dəqiqliyinin dəyişdirilərək birbaşa 64/32 bitinə yuvarlanması lazımdır.
    // `set_precision` funksiyası, qlobal vəziyyəti dəyişdirərək (x87 FPU-nun nəzarət sözü kimi) təyin edilməsini tələb edən arxitekturalarda dəqiqliyin təyin olunmasına diqqət yetirir.
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // E <0 vəziyyəti digər branch-yə qatlana bilməz.
    // Mənfi güclər ikili olaraq yuvarlaqlaşdırılan təkrarlanan bir hissə hissəsinin son nəticədə həqiqi (və bəzən olduqca əhəmiyyətli!) Səhvlərə səbəb olması ilə nəticələnir.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Alqoritm Bellerophon, əhəmiyyətsiz ədədi analizlə əsaslandırılmış əhəmiyyətsiz bir koddur.
///
/// 64 bitlik işarəli və "f" düyməsini bir üzgüçülüyə yuvarlayır və ən yaxşı `10^e` təqribi ilə artırır (eyni üzən nöqtə formatında).Bu, çox vaxt düzgün nəticə əldə etmək üçün kifayətdir.
/// Bununla birlikdə, nəticə iki qonşu (ordinary) üzgəcinin yarısına yaxın olduqda, iki yaxınlaşmanın çarpılmasından əmələ gələn yuvarlaqlaşdırma xətası nəticənin bir neçə bit söndürülə biləcəyini göstərir.
/// Bu baş verdikdə, təkrarlanan Alqoritm R işləri düzəldir.
///
/// Əl dalğalı "close to halfway", kağızdakı ədədi analizlə dəqiqləşdirilmişdir.
/// Clingerin sözləri ilə:
///
/// > Ən az əhəmiyyətli bit vahidləri ilə ifadə edilən yamaq, səhv üçün hərtərəfli bir cəbhədir
/// > f * 10 ^ e-yə yaxınlaşmanın üzən nöqtə hesablanması zamanı yığılmışdır.(Eğimdir
/// > həqiqi səhv üçün bir məhdudiyyət deyil, z ilə yaxınlaşma arasındakı fərqi məhdudlaşdırır
/// > p bit əhəmiyyətini istifadə edən mümkün olan ən yaxşı yaxınlaşma.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) halları fast_path()-dədir
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // N bitə qədər yuvarlaqlaşdırarkən bir fərq yaratacaq qədər yamac varmı?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// `f * 10^e` üzən nöqtə yaxınlaşmasını yaxşılaşdıran təkrarlanan bir alqoritm.
///
/// Hər bir iterasiya son yerdə bir vahid yaxınlaşır, bu da əlbəttə ki, `z0` hətta yumşaq olduqda yaxınlaşmaq olduqca uzun çəkir.
/// Xoşbəxtlikdən, Bellerophon üçün geri dönüş olaraq istifadə edildikdə, başlanğıc yaxınlaşması ən çox bir ULP ilə bağlanır.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x`, `y` müsbət tam ədədlərini tapın ki, `x / y` tam `(f *10^e) / (m* 2^k)` olsun.
        // Bu, yalnız `e` və `k` əlamətləri ilə məşğul olmaqdan çəkinmir, eyni zamanda rəqəmləri kiçikləşdirmək üçün `10^e` və `2^k` üçün ortaq olan ikisinin gücünü də aradan qaldırırıq.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Bignumlarımız mənfi rəqəmləri dəstəkləmədiyi üçün mütləq dəyər + işarə məlumatlarını istifadə etdiyimiz üçün bu bir az yöndəmsiz şəkildə yazılmışdır.
        // M_digits ilə vurma aça bilməz.
        // Əgər `x` və ya `y` kifayət qədər böyükdürsə, daşqından narahat olmağımız lazımdır, o zaman onlar da `make_ratio`-in hissəni 2 ^ 64 və ya daha çox azaltdığı qədər böyükdür.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Artıq x-ə ehtiyac yoxdur, clone() qeyd edin.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Hələ y lazımdır, bir kopyasını çıxarın.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `f`-in hər zamanki kimi ondalık rəqəmi təmsil etdiyi və `m`-in üzən nöqtə yaxınlaşmasının əhəmiyyəti olduğu `x = f` və `y = m` nəzərə alınmaqla, `x / y` nisbətini `(f *10^e) / (m* 2^k)`-ə bərabərləşdirin, ehtimal ki, ikisinin gücü ilə azaldı.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, yalnız hissəni ikisinin gücünə görə azaltdıq.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Bu artıq ola bilməz, çünki yalnız 1-ə çox yaxın dəyərlər üçün baş verə biləcək müsbət `e` və mənfi `k` tələb edir, yəni `e` və `k` nisbətən kiçik olacaqdır.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Bu da aça bilməz, yuxarıya baxın.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), yenə ikisinin ümumi gücü ilə azalır.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konseptual olaraq, Alqoritm M, bir onluq rəqəmi şamandıra çevirməyin ən sadə yoludur.
///
/// `f * 10^e`-ə bərabər bir nisbət meydana gətiririk, sonra etibarlı bir şamandıra işarəsi verənə qədər iki gücə atırıq.
/// İkili göstərici `k` sayını və məxrəcini ikiyə vurma sayımızdır, yəni `f *10^e` hər zaman `(u / v)* 2^k`-ə bərabərdir.
/// Diqqəti aşkar etdikdə, yalnız aşağıda köməkçi funksiyalarda yerinə yetirilən bölmənin qalan hissəsini yoxlamaqla yuvarlaqlaşdırmalıyıq.
///
///
/// Bu alqoritm, hətta `quick_start()`-də təsvir olunan optimallaşdırma ilə birlikdə super ləngdir.
/// Bununla birlikdə, daşma, aşma və normal olmayan nəticələrə uyğunlaşmaq üçün alqoritmlərin ən sadə variantıdır.
/// Bu tətbiq Bellerophon və Algorithm R yükləndikdə ələ keçir.
/// Daşmağı və daşmağı aşkarlamaq asandır: Bu nisbət hələ bir sıra əhəmiyyəti deyil, lakin minimum/maximum göstəricisinə çatıldı.
/// Daşma halında sadəcə sonsuzluğu qaytarırıq.
///
/// Alt və normal olmayanlarla işləmək daha hiyləgərdir.
/// Böyük bir problem ondan ibarətdir ki, minimum göstərici ilə nisbət hələ bir məna üçün çox böyük ola bilər.
/// Ətraflı məlumat üçün underflow()-ə baxın.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Mümkün optimallaşdırmanı düzəldin: big_to_fp-i ümumiləşdirin ki, burada fp_to_float(big_to_fp(u))-in ekvivalentini yalnız ikiqat yuvarlaqlaşdırma olmadan edə bilək.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Minimum göstəricidə dayanmalıyıq, əgər `k < T::MIN_EXP_INT`-yə qədər gözləsək, iki dəfə qalmış olarıq.
            // Təəssüf ki, bu, normal rəqəmləri minimum göstərici ilə xüsusi hala gətirməliyik deməkdir.
            // FIXME daha zərif bir formulasiya tapın, amma həqiqətən düzgün olduğundan əmin olmaq üçün `tiny-pow10` testini keçirin!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Bit uzunluğunu yoxlayaraq əksər Alqoritm M təkrarlamalarını atlayır.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bit uzunluğu, baza iki loqarifmin qiymətləndirilməsidir və log(u / v) = log(u), log(v).
    // Qiymətləndirmə ən çox 1-ə bərabərdir, lakin hər zaman bir az qiymətləndirilir, buna görə log(u) və log(v)-dəki səhv eyni işarəlidir və ləğv edilir (hər ikisi də böyükdürsə).
    // Bu səbəbdən log(u / v) üçün ən çox da səhv var.
    // Hədəf nisbəti, u/v in bir aralığın içində olduğu nisbətdir.Beləliklə, sonlandırma şərtimiz log2(u / v), əhəmiyyətli və bit olan plus/minus dir.
    // DÜZELTME İkinci bitə baxaraq təxminləri yaxşılaşdırmaq və daha çox bölünmədən çəkinmək olar.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Alt və ya normal olmayan.Əsas funksiyaya buraxın.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Daşqın.Əsas funksiyaya buraxın.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Oran, minimum göstərici ilə bir aralığın içində deyil və bu səbəbdən artıq bitləri yuvarlaqlaşdırmalı və göstəricini buna görə tənzimləməyimiz lazımdır.
    // Həqiqi dəyər indi belə görünür:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(rem ilə təmsil olunur)
    //
    // Buna görə yuvarlaq bitlər== 0.5 ULP olduqda, yuvarlaqlaşdırmaya özləri qərar verirlər.
    // Onlar bərabər olduqda və qalan sıfır olmadıqda, dəyərin hələ yuvarlaqlaşdırılması lazımdır.
    // Yalnız yuvarlaqlaşdırılmış bitlər 1/2 olduqda və qalan sıfır olduqda, yarıdan bərabər vəziyyətə sahibik.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Adi cüt-cüt, bölünmənin qalan hissəsinə əsasən yuvarlaqlaşdırmaq məcburiyyətində qaldı.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}