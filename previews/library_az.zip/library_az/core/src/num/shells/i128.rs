//! 128-bit işarəli tam ədəd növü üçün sabitlər.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Yeni kod əlaqəli sabitləri birbaşa ibtidai tipdə istifadə etməlidir.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }